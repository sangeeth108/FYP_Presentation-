# Serendib engine build and deterministic validation worker.
ARG PYTHON_IMAGE=python:3.12-slim
FROM ${PYTHON_IMAGE}

ENV PYTHONUNBUFFERED=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    PIP_NO_CACHE_DIR=1 \
    HOME=/home/serendib \
    PLAYWRIGHT_BROWSERS_PATH=/opt/playwright

RUN groupadd --system --gid 10001 serendib \
    && useradd --system --uid 10001 --gid serendib --create-home serendib

WORKDIR /workspace/services/brain

COPY services/brain/ /workspace/services/brain/
COPY services/worker/ /workspace/services/worker/
COPY contracts/ /workspace/contracts/
COPY capabilities/ /workspace/capabilities/
COPY content/ /workspace/content/
COPY engine/templates/ /workspace/engine/templates/
COPY engine/serendib/assist/ /workspace/engine/serendib/assist/
COPY eval/ /workspace/eval/

RUN pip install --upgrade pip \
    && pip install /workspace/services/brain '/workspace/services/worker[validation]' \
    && playwright install --with-deps chromium \
    && mkdir -p /workspace/artifacts /work /tmp/serendib \
    && chown -R serendib:serendib /workspace /opt/playwright /tmp/serendib

USER 10001:10001

CMD ["celery", "-A", "worker.celery_app", "worker", "-Q", "serendib_build", "-c", "1", "-l", "info"]
