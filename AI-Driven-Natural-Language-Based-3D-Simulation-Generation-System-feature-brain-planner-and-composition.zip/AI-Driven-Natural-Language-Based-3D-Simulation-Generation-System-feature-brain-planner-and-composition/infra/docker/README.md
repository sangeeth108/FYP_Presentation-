# infra/docker

Dockerfiles referenced by `docker-compose.yml` and the deployment runbooks.

| File | Purpose | Status |
|---|---|---|
| `brain.Dockerfile` | FastAPI brain image (VPS + local) | **P0 skeleton** — not wired into compose until the hello-job app exists |
| `worker.Dockerfile` | GPU worker image (5090 + rented failover) | Planned (P1) — same image runs locally and on rented GPUs |

**P0 note:** `docker compose up -d postgres redis` brings up the data stores now. The `brain` service in `docker-compose.yml` is commented out to keep P0 runnable without a real app; uncomment it (and this Dockerfile's uvicorn CMD) when `services/brain` serves `/healthz`.

**Owner:** M1 (Platform), worker image with M2/M4.
