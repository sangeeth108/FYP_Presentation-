# Serendib API/planning image. Build from the repository root:
#   docker build -f infra/docker/brain.Dockerfile .

ARG PYTHON_IMAGE=python:3.12-slim
FROM ${PYTHON_IMAGE}

ENV PYTHONUNBUFFERED=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    PIP_NO_CACHE_DIR=1 \
    HOME=/home/serendib

RUN groupadd --system --gid 10001 serendib \
    && useradd --system --uid 10001 --gid serendib --create-home serendib

WORKDIR /workspace/services/brain

COPY --chown=serendib:serendib services/brain/ /workspace/services/brain/
COPY --chown=serendib:serendib contracts/ /workspace/contracts/
COPY --chown=serendib:serendib capabilities/ /workspace/capabilities/
COPY --chown=serendib:serendib content/ /workspace/content/
COPY --chown=serendib:serendib engine/templates/ /workspace/engine/templates/
COPY --chown=serendib:serendib engine/serendib/assist/ /workspace/engine/serendib/assist/
COPY --chown=serendib:serendib eval/ /workspace/eval/

RUN pip install --upgrade pip \
    && pip install . \
    && mkdir -p /workspace/artifacts /tmp/serendib \
    && chown -R serendib:serendib /workspace/artifacts /tmp/serendib

USER 10001:10001

EXPOSE 8000

CMD ["uvicorn", "main:app", "--host=0.0.0.0", "--port=8000", "--proxy-headers"]
