# Governed GPU-training worker.
# Supply a vulnerability-scanned, digest-pinned base that already contains the
# approved CUDA/PyTorch/Unsloth/TRL/PEFT/bitsandbytes combination, for example:
#   docker build --build-arg TRAINING_BASE_IMAGE=registry/image@sha256:... ...
ARG TRAINING_BASE_IMAGE
FROM ${TRAINING_BASE_IMAGE}

ENV PYTHONUNBUFFERED=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    PIP_NO_CACHE_DIR=1 \
    HOME=/home/serendib

RUN groupadd --system --gid 10001 serendib \
    && useradd --system --uid 10001 --gid serendib --create-home serendib

WORKDIR /workspace/services/brain
COPY services/brain/ /workspace/services/brain/
COPY eval/ /workspace/eval/
COPY contracts/ /workspace/contracts/

RUN pip install --upgrade pip \
    && pip install /workspace/services/brain \
    && python -c "import bitsandbytes, datasets, peft, torch, trl, unsloth" \
    && mkdir -p /workspace/artifacts/training /run/serendib-training \
    && chown -R serendib:serendib /workspace /run/serendib-training

USER 10001:10001

CMD ["celery", "-A", "worker.celery_app", "worker", "-Q", "gpu_training", "-c", "1", "-l", "info"]
