# infra/cloudflare — Pages, R2, Tunnel

The delivery + storage edge, and the outbound-only path to the GPU worker.

## Files here

| File | Purpose |
|---|---|
| `_headers` | Cloudflare Pages headers. Copy to `apps/web/public/_headers` at build. Single-threaded default needs nothing special; COOP/COEP scoped to optional threaded builds; correct `.wasm` type. |
| `cloudflared-vps.example.yml` | OPTIONAL VPS-side tunnel exposing only the queue to the worker behind Access. |

## Pages (frontend + /play)

- Build `apps/web` → deploy to Pages (`wrangler pages deploy` or Git integration).
- Env: `NEXT_PUBLIC_API_BASE_URL=https://api.your-domain`.
- The game `/play/*` bundles and downloadable project zips are served from **R2** (signed URLs; $0 egress).

## R2 buckets

| Bucket | Contents |
|---|---|
| `promptplay-builds` | web builds, downloadable project zips, logs |
| `promptplay-assets` | resolved/generated assets, credits.json |

Credentials go in `.env` (`R2_*`) from the vault — never in the repo.

## Worker connectivity (outbound-only — pick ONE)

1. **Tailscale (recommended, simplest):** join the VPS + 5090 to one tailnet; ACL allows `worker → vps:6379` only. The worker dials out; no inbound ports on the home network. Steps in [`docs/runbooks/GPU_WORKER_SETUP.md`](../../docs/runbooks/GPU_WORKER_SETUP.md).
2. **Cloudflare Tunnel:** run `cloudflared-vps.example.yml` on the VPS to expose only the queue endpoint behind Cloudflare Access (service token); the worker uses the token to reach it. Still no inbound ports at home.

Either way the invariant holds: **the RTX 5090 never accepts an inbound connection.**

## Owner

M1 (Platform) with M2/M4 for the worker side.
