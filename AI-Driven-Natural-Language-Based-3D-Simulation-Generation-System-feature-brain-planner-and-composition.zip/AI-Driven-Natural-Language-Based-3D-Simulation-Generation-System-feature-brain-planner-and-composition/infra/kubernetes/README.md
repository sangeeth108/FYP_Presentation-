# Serendib production topology

These manifests are a secure baseline, not a claim that a public cluster has
already passed launch review. Replace every image placeholder with a verified
Cosign-signed digest. Runtime secrets are supplied by External Secrets from the
cloud secret manager; never create the referenced Secret from a checked-in file.

Apply order: namespace, config, externally managed secrets, API, workers,
network policy, then KEDA. Managed PostgreSQL must have multi-zone failover and
15-minute-or-better point-in-time recovery. Managed Redis must use TLS and
authentication. Add regional allowlists to `network-policy.yaml` before deploy;
the checked-in default intentionally denies application egress.

The planning and build queues are isolated. GPU model-generation workers use
the same signed worker digest with a GPU runtime class and a third
`gpu_generation` queue; their provider-specific node pool belongs in a regional
overlay because accelerators and runtime classes differ by cloud.

Required release evidence:

- 100 concurrent-job load run and queue-fairness report.
- Restore drill showing RPO ≤15 minutes and RTO ≤4 hours.
- Cross-tenant API/database/object-storage test report.
- Container signature, SBOM, dependency and secret scans.
- External penetration test with no unresolved critical findings.
- Alert routes, on-call owner, and incident exercise record.
