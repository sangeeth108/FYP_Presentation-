# infra/hetzner — VPS deployment

The always-on cloud host (CX32/CX42): FastAPI brain + Celery + PostgreSQL/pgvector + Redis via `docker-compose.yml`, fronted by Caddy for TLS. Full step-by-step: [`docs/runbooks/VPS_SETUP.md`](../../docs/runbooks/VPS_SETUP.md).

## Files here

| File | Purpose |
|---|---|
| `Caddyfile` | Reverse proxy + auto-TLS in front of `127.0.0.1:8000`. The only public listener. |

## Deploy summary (one screen)

```bash
# 0. Provision Ubuntu LTS VPS; SSH-key auth only; create `deploy` user.
# 1. Firewall — only SSH + HTTPS in. DB/Redis stay private (compose binds 127.0.0.1).
ufw default deny incoming && ufw allow OpenSSH && ufw allow 443/tcp && ufw enable
apt update && apt install -y docker.io docker-compose-plugin caddy unattended-upgrades

# 2. App
git clone <repo-url> /opt/promptplay && cd /opt/promptplay
cp .env.example .env         # fill from the team vault (never from chat)
docker compose up -d         # postgres + redis + brain (migrates then serves) + celery

# 3. TLS proxy
cp infra/hetzner/Caddyfile /etc/caddy/Caddyfile   # edit the domain first
systemctl reload caddy

# 4. Verify
curl -s https://api.your-domain/healthz            # {"status":"ok"}
```

## Security invariants (do not violate)

- Postgres/Redis are **never** published beyond `127.0.0.1` (enforced in `docker-compose.yml`).
- Only 443 (Caddy) + 22 (SSH) inbound. The GPU worker is **outbound-only** and not hosted here.
- Secrets live in the vault + `.env` (gitignored) — never in the repo.
- Nightly `pg_dump` → R2/B2; test a restore each phase (see VPS_SETUP runbook).

## Owner

M1 (Platform).
