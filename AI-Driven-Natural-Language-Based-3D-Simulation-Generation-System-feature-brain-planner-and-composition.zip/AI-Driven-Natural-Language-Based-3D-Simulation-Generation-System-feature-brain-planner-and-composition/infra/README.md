# infra/ — deployment & CI configuration

**What this is:** everything that describes *where and how* the system runs. No application code.

| Folder | Purpose | Notes |
|---|---|---|
| `docker/` | Dockerfiles (`brain.Dockerfile`, `worker.Dockerfile`) referenced by `docker-compose.yml` | Same worker image locally + on rented failover GPUs |
| `cloudflare/` | Pages config, `_headers` (COOP/COEP only if threaded builds are enabled — default is single-threaded), R2 bucket notes, Tunnel config templates | Never store Tunnel credentials here — vault only |
| `hetzner/` | VPS provisioning notes, reverse-proxy (Caddy/nginx) configs, firewall rules, backup cron | DB/Redis stay localhost-bound |
| `github-actions/` | Workflow sources copied to `.github/workflows/` at repo root once the GitHub repo exists: lint/test (P0), engine build matrix (P1), nightly regression benchmark (P2+), license check | CI from day 1 — nothing merges untested |

**Owner:** M1 (Platform), engine build matrix with M3.

**When updated:** P0 (CI skeleton + compose), P1 (engine builds), P3 (hybrid deploy live). Every change that affects deployment → update `docs/DEPLOYMENT_PLAN.md` + relevant runbook.

**Common mistakes to avoid:**
- Secrets in any config file — placeholders + vault references only.
- Exposing Postgres/Redis ports in a compose override.
- CI installing the whole GPU stack — CI tests with fixtures; GPU work happens on the worker.
- Forgetting `_headers` implications: threaded builds need COOP/COEP, which breaks some embeds — default stays single-threaded.
