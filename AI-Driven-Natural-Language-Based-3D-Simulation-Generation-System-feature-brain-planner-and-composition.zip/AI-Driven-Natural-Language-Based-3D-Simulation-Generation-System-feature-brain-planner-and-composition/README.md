# Serendib

Serendib converts natural-language requirements into deterministic, executable
and evidence-verified 3D simulations. It targets general simulations—not only
games—and produces browser and desktop artifacts from one canonical world plan.

## Current status

The production foundation and neutral planning path are implemented, but this
repository is **not yet approved for public production**. Canonical runs fail
truthfully when a mandatory external validator, Serendib build, vision critic,
or cross-platform probe is unavailable. They do not publish an unfinished world
as a successful simulation.

The canonical `WorldPlan` now drives a neutral Serendib project writer directly.
The qualified dog-village slice compiles measured assets and procedural
capability geometry, runs deterministic interaction/navigation probes, exports
and executes in Chromium, captures canonical views, and compares native/browser
logical state. Release publication still fails closed until a signed Serendib
binary, matching desktop export templates, and pinned production critic models
are available.

Implemented foundations include:

- versioned simulation, asset, capability, behaviour, world-plan, patch,
  requirement and validation contracts;
- neutral `/api/v1/simulations` APIs plus a deprecated `/games` adapter;
- seeded semantic placement using measured bounds and hard constraints;
- measured procedural building shells with doorway voids, independent hinged
  door leaves, connected paths, and autonomous navigation agents;
- data-only behaviour graphs and bounded typed repair;
- tenant identity, quotas, PostgreSQL row-level security and private artifact
  object keys;
- opt-in consent, teen/guardian controls, rights review, deletion tombstones,
  governed datasets and manual model promotion;
- planner, critic and vision model registries with recorded routing;
- schema-bound model critics plus deterministic native/browser runtime evidence;
- the Serendib Engine rebrand patch series, pinned to upstream
  `4.6.3-stable`, with visible-brand verification;
- a Next.js interface that displays artifacts only after mandatory validation
  evidence passes.

See [production implementation status](docs/SERENDIB_PRODUCTION_STATUS.md) for
completed work and remaining launch gates.

**Start here for the current picture** (all re-inspected against the code, 2026-07-31):

- [System architecture](docs/ARCHITECTURE.md) — how it actually works, with measured
  figures and an explicit list of what is declared but not built.
- [Defects and wrong decisions](docs/DEFECTS_AND_DECISIONS.md) — 15 recorded defects with
  measured cost and mechanism, written as evidence for the dissertation.
- [Build checklist](docs/BUILD_CHECKLIST.md) — what remains, in priority order.

## Repository map

| Path | Purpose |
|---|---|
| `contracts/` | Versioned JSON contracts |
| `capabilities/` | Pluggable semantic capability manifests |
| `services/brain/` | FastAPI orchestration, governance, PCG and learning control plane |
| `services/worker/` | Asset, Serendib project, export and runtime validation tooling |
| `apps/web/` | Serendib no-code web interface |
| `engine/serendib/` | Pinned upstream fork, patches, identity assets and checks |
| `eval/` | Frozen benchmarks, research metrics and controlled-data tooling |
| `infra/` | Container and Kubernetes deployment baselines |

## Local checks

```bash
python scripts/validate_contracts.py
python scripts/check_licenses.py

cd services/brain
python -m pytest tests -q

cd ../../services/worker
python -m pytest tests -q

cd ../..
npm run build:web
```

Copy `.env.example` to `.env` for local services. Production startup refuses
incomplete OIDC, private storage, pseudonymization, CORS or engine
configuration.

## Legal

Serendib Engine is based on Godot Engine under the MIT licence. Required
copyright and licence notices are retained. Godot’s name and logo are
trademarks of the Godot Foundation; Serendib is not affiliated with or endorsed
by the Godot Foundation. See [the licensing ledger](docs/LICENSING_LEDGER.md).
