# CLAUDE.md — PromptPlay 3D & Serendib Engine

This file tells Claude Code how to work inside this repository. Read it fully before making any change.
Source-of-truth planning documents live in `../ReferenceDocuments/` (Full Project Report v4.0 + Implementation Checklist, July 2026). When this file and those documents conflict, ask the user.

---

## 1. Project identity

- **PromptPlay 3D** — a web platform where a user types a natural-language game idea and receives a **browser-playable, stylized low-poly 3D single-player game**, with live generation progress, a shareable play URL, and a **downloadable editable engine project**.
- **Serendib Engine** — a rebranded **Godot 4.x fork** (pinned stable tag, patch-series maintenance) with a bundled AI assistant dock (**Serendib Assist**) that round-trips edits through the same brain.
- The project is simultaneously a **capstone**, a **dissertation** (ablation study + user study), and the seed of a **future SaaS**.
- **v1 scope is frozen:**
  - Single-player only.
  - Four-genre allowlist: `topdown_survival_escape_3d`, `arena_combat_3d`, `collect_explore_3d`, `dungeon_crawl_3d`.
  - Three cameras: `third_person`, `top_down_3d`, `isometric_3d`.
  - One contiguous level; 50–200 props; 5–25 enemies; 3–8 minute sessions.
  - WebGL2 Compatibility renderer, **≤90 MB** web build, single-threaded export default (Safari/iOS reach).
  - Deep C++ engine changes are **banned** (Tier 3). Branding = Tier 1. GDScript EditorPlugin features = Tier 2.
- **Core promise:** the output is a *beginning, not an end* — a real, editable, engine-native project.

## 2. Claude Code role

Act as: senior implementation architect · careful full-stack developer · AI/ML orchestration engineer · Godot/Serendib build engineer · QA engineer · documentation maintainer · **beginner-friendly teacher** (the user is a student team; explain what you do and why in simple English).

## 3. Hard implementation rules

1. **Plan before coding.** State what files will change and why, then change them.
2. **Read existing files before editing.** Never edit blind.
3. **Small safe changes.** One concern per change. No multi-feature mega-commits.
4. **Work phase by phase** (P0→P6, §11). Do not start a later phase's work early without being asked.
5. **Never delete important files without asking.**
6. **No secrets in the repo, ever.** Only `.env.example` with placeholders. Real secrets live in a password manager/vault.
7. **Update docs after meaningful changes** (see §10).
8. **Always explain: what changed, why, and how to test it.**
9. **Run available tests** or explain exactly why they cannot run.
10. **Never ship AI-written gameplay-critical code.** The LLM selects template IDs and fills parameters; behavior comes from vetted GDScript templates in `engine/templates/`. The only exception is small non-authoritative adapter code that passes the 5-step promotion gate.
11. **Every generated artifact needs lineage** (prompt, seed, model digests, spec hash, build hash) **and validation metadata**.
12. **Re-check licenses** before any model/asset/tool enters the product path; log it in `docs/licensing_ledger.csv`. Quarantined to research-only: FLUX.1[dev] (non-commercial), Hunyuan3D-2.1 (UK/EU/Korea excluded).
13. **Validators emit machine-readable error objects, not strings.**
14. **Seed everything.** Any randomness must be reproducible from the recorded seed.
15. **Ambiguity up / determinism down:** LLMs decide *what*; deterministic, seeded, testable code decides *how*.

## 4. Technology stack and how it connects

| Piece | Role | Connects to |
|---|---|---|
| Next.js (`apps/web`) | UI: prompt, progress, play, download | Calls FastAPI over HTTPS; WebSocket/SSE for live progress |
| FastAPI (`services/brain`) | API gateway + orchestration brain | Creates jobs, returns `job_id`; enqueues to Redis/Celery; reads/writes PostgreSQL |
| Redis + Celery | Job queue + working state | Brain enqueues; GPU worker pulls; buffers jobs while workstation is offline |
| PostgreSQL | Users, games, jobs, specs, artifacts, validation reports, repair attempts, lineage, registries | Brain + worker read/write; LangGraph PostgresSaver checkpoints here |
| pgvector + bge-m3 | RAG embeddings for design knowledge | Extension inside the same PostgreSQL (no separate vector DB) |
| Cloudflare R2 | Object storage: web builds, assets, logs, downloadable projects; $0 egress | Worker uploads artifacts; play/download pages use signed URLs |
| Cloudflare Pages | Hosts frontend + `/play` pages | Serves Next.js build and game bundles |
| Hetzner VPS | Always-on host (Docker Compose: FastAPI, Postgres, Redis, Celery) | The cloud half of the hybrid topology |
| GPU worker (`services/worker`, RTX 5090, 32 GB) | All heavy work: LLM, assets, Godot builds, bots | **Outbound-only** tunnel (Cloudflare Tunnel/Tailscale); pulls jobs; never opens inbound ports |
| vLLM / Ollama | Local model serving (Qwen-family Apache-2.0 planner) | Worker's `llm_gateway`; guided decoding via xgrammar |
| xgrammar / guided JSON | Token-level JSON-Schema enforcement | Every LLM output that must match `contracts/game_spec.schema.json` |
| LangGraph + PostgresSaver | Agent orchestration as a state graph | Durable, resumable jobs; repair loops bounded ≤3 attempts/failure class |
| Godot/Serendib headless (`engine/`) | Project assembly + WebGL2 export | Worker's `godot_client` drives it; CI builds editor + export templates per pinned tag |
| Validation bots (`services/worker/bots`) | Playtest generated games by **reading state via a debug singleton** (never vision) | Verdicts feed the validation stack and repair loop |
| GitHub Actions | CI: lint, test, engine build matrix | Runs on every PR |

**GPU constraint:** the 32B planner, TRELLIS.2 (≥24 GB) and diffusion cannot be co-resident in 32 GB. The worker sequences modes: plan → assets → validation.

## 5. System interconnection

**Beginner version:** User writes a prompt → website sends it to the backend → backend creates a job → the AI brain turns the idea into a structured plan (game_spec JSON) → deterministic builders create the level and place everything → the engine exports a web build → bots test it → the user plays it in the browser and can download the editable project.

**Technical version:** Next.js → FastAPI (`POST /api/v1/games` → 202 `{game_id, job_id}`) → Redis/Celery → GPU worker pulls via outbound tunnel → LangGraph agent chain emits JSON patches → arbiter merges under a constraint priority stack (platform limits > scope allowlist > playability > designer intent > user preference > cost > aesthetics) → frozen canonical spec (JSON Schema 2020-12, guided decoding) → seeded PCG zone graph → GridMap materialization + navmesh + placement → template-bound GDScript assembly → Serendib headless export (web + project) → 8-gate validation + playtest bots → localized repair (re-run only the failing node, ≤3/class) → artifacts to R2 → status streamed via WebSocket/SSE → play/download UI.

## 6. Architecture layers

1. **Presentation** — Next.js, live progress (WS/SSE), play page, downloads. Host: Cloudflare Pages.
2. **Orchestration brain** — FastAPI, agent chain (Prompt Analyzer, Game Designer, World, Mechanics, Asset, Animation+Audio, gated Code adapter, Integrator/Arbiter, Validation, Repair), job planner. Host: Hetzner VPS. Agents are **modules, not microservices**.
3. **Knowledge** — PostgreSQL registries (templates/kits/animations/presets with allowlist enforcement), pgvector + bge-m3 RAG, canonical schema. Host: Hetzner VPS.
4. **GPU worker** — vLLM/Ollama, asset farm (SDXL → TRELLIS.2 → Blender headless → GLB; Stable Audio Open), Serendib headless builds, playtest bots. Host: local RTX 5090, outbound-only.
5. **State & storage** — PostgreSQL (jobs/specs/lineage), Redis/Celery, Cloudflare R2.

## 7. Generation pipeline (S0–S8)

Full stage-by-stage detail (inputs, outputs, failure modes, repair, tests) lives in `docs/GENERATION_PIPELINE.md`. Summary:

| Stage | What | AI or deterministic |
|---|---|---|
| S0 | Prompt intake + safety/scope check | AI (classifier) + allowlist rules |
| S1 | Intent parsing → structured brief | AI (guided JSON) |
| S2 | Game spec planning → full game_spec | AI (guided JSON, RAG, agents) |
| S3 | Schema validation | Deterministic |
| S4 | PCG: seeded zone graph + level materialization plan | Deterministic |
| S5 | Asset resolution: cache (≥0.92) → curated (≥0.85) → generate → QA gate → curated fallback | AI generation inside deterministic decision tree |
| S6 | Serendib project assembly from templates | Deterministic |
| S7 | Headless export + 8-gate validation + bots | Deterministic |
| S8 | Upload artifacts, play URL, download package, lineage record | Deterministic |

Failures are classified (schema / asset / build / logic / quality) and repaired by **re-invoking only the responsible node**, capped at 3 attempts per class with monotonic-progress checks. Never regenerate the whole game.

## 8. Design rules (UI)

Use Claude design skills where available. **Before coding any UI:** create user flows → text wireframes → screen list → component inventory → design system (`docs/DESIGN_SYSTEM.md`) → mobile-first layout plan → empty/loading/error/success states for every screen.

Main screens: Home/prompt · Job progress (live phases) · Browser play page · Download page · (later) gallery, login, dashboard, admin/research. Keep the UI simple for students, hobbyists, educators, and rapid prototypers — approachability is a competitive lesson learned from Rosebud. Live progress is **required** (generation takes minutes; users must see it working). Errors must be friendly and actionable.

## 9. Coding standards

- **TypeScript** for all frontend code; **Python with type hints** for backend.
- JSON spec fields: `snake_case`. Godot scene nodes: `PascalCase` with meaningful names (`SkeletonArcher_03`, never `Node3D_17`) — editability depends on this.
- Template scripts: one concern each, `@export` tunables mirroring spec fields, header comment linking the spec path.
- **Conventional commits** (`feat:`, `fix:`, `docs:`) on **feature branches** (`feature/<area>-<name>`).
- Reusable components; clear REST names (see `docs/API_DOCUMENTATION.md`).
- Validators return machine-readable error objects (`{code, path, message, hint}`), never bare strings.
- Tests for critical paths (schema, PCG determinism, template behavior, API contract).
- No large unreviewed files; no secrets; no unsafe `eval`/dynamic code execution anywhere.
- Artifact naming: `game_id = g3d_<slug>_<hash>`; assets keyed by `brief_hash`.

## 10. Documentation rules

After each phase (or meaningful change) update: `README.md`, `docs/IMPLEMENTATION_PLAN.md`, `docs/IMPLEMENTATION_CHECKLIST.md`, `docs/ARCHITECTURE.md`. Additionally: `docs/API_DOCUMENTATION.md` when APIs change · `docs/DATABASE_SCHEMA.md` when the DB changes · `docs/DESIGN_SYSTEM.md` when UI changes · `docs/LICENSING_LEDGER.md` + `docs/licensing_ledger.csv` when models/assets/tools are added · `docs/CHANGELOG.md` after meaningful changes · a new ADR in `docs/adr/` for every major technical decision.

## 11. Implementation phases

| Phase | Goal | Gate (definition of done) |
|---|---|---|
| **P0 Foundation** | Monorepo, CLAUDE.md, docs, CI skeleton, Compose skeleton (FastAPI+Postgres+Redis), Next.js skeleton, hello-job endpoint, `game_spec.schema.json` v2 + validator, pinned Godot tag + Emscripten documented, golden-game planning | **Golden game** plays in browser, ≤90 MB, on Chrome/Firefox/Edge/Safari |
| **P1 Deterministic spine** | PCG zone graph, template registry, project writer, build/export pipeline, job states, basic validation, Serendib rebrand v0.1 | Hand-written valid game_spec → playable web game with **zero manual steps** |
| **P2 Brain online (MID DEMO)** | Guided-JSON planner, LangGraph orchestration, agents-as-patches, schema validation + localized repair, live progress UI, repair tracking | Prompt → playable browser game end-to-end; ≥80% of 20 frozen prompts pass unaided |
| **P3 Asset farm + AI dock** | Asset cache, generated props/textures/skybox/audio, license tracking, Serendib Assist dock, edit round-trip | Download project → open in Serendib → AI-dock edit → re-export works |
| **P4 Fine-tune + evaluation** | Benchmark prompts, ablation runners, metrics dashboard, QLoRA-tuned Qwen3-8B **behind a flag only** (untuned 32B stays default) | Evaluation data proves what improves reliability |
| **P5 User study + polish** | Ethics/DPIA docs, user testing, bug fixing, performance, doc polish | Study run and analyzed |
| **P6 Ship + dissertation** | Final release, deployment docs, 5 cached showcase games + 1 live generation, demo script, backup plan | Defense-ready package |

**Ordering is deliberate:** golden game before AI (proves the hardest constraint); deterministic spine before brain (specs need a working target); assets after spine (graceful degradation); fine-tuning late (it's an ablation, not a dependency).

**Pre-agreed cut list (drop first if time is short):** TTS barks → UniRig characters → day-night → module kit B → threaded web build.

## 12. Current first action

Only Phase **P0** is in progress. Before touching P1+ work: inspect the folder, state exactly what files will be created, create only safe foundation files, do **not** install heavy dependencies without confirming the OS/environment, never run destructive commands, and give exact Windows PowerShell **and** macOS/Linux commands with explanations.

## 13. Git, commit, and credential rules (MANDATORY — STRICT)

**Default = HARD NO.** Claude Code must **NOT** run `git commit` or `git push`, must **NOT** create commits, and must **NOT** push changes — ever — **unless the user gives explicit permission in that same request, naming the exact command to run.** A general "let's commit" is not enough; blanket or past approval does not carry forward to future changes. When in doubt, do not commit.

**Always allowed (read-only / advisory):** `git status`, `git diff`, `git log`, showing changed files, **suggesting** commit messages, explaining what changed, preparing a change summary.

**Never without explicit per-action permission:** `git commit`, `git push`, `git merge`/`rebase`, `git reset --hard`, creating GitHub repositories, adding/changing remotes, configuring Git `user.name`/`user.email`, tags, or force operations. Never use Claude's own identity for commits — commits use the logged-in user's Git identity only.

**Standard workflow when changes are ready:**
1. Run `git status` and list every changed file.
2. Explain what each change does and why.
3. **Suggest** a commit message (Conventional Commits; no `Co-Authored-By: Claude` trailer — commits are authored as the human).
4. **Stop and hand off** — the user runs the commit/push manually. Do it for them **only** if they reply with explicit permission and the exact command.

**Credentials:** if Git identity is missing, check config, do not invent credentials, ask the user, and give the exact `git config` command. If GitHub auth is missing, never ask for tokens/passwords in chat — point to `gh auth login`, SSH keys, or the credential manager. Never write tokens into `.env`, README, docs, or chat.

> History note: the single P0 scaffold commit + push (`86ef630`) was made under a prior explicit user instruction with the exact remote. That was a one-time authorization and does **not** authorize any future commit or push.

## 14. Safety, privacy, licensing (always-on)

- Godot code is MIT — keep LICENSE + copyright notices + license viewer in the About dialog. The **Godot name/logo are trademarks** and must not be used as the product name: the Serendib rebrand is legally required. Credit "based on Godot Engine" + non-affiliation disclaimer.
- DPIA + ethics approval **before** any user study; educational users may include minors → child-safety duty, pseudonymized logs, retention limits.
- Product path: MIT/Apache/OpenRAIL-commercial only (TRELLIS.2, Qwen-family ≤32B Apache cards, SDXL, FLUX.1-schnell, Stable Audio Open under threshold, bge-m3, LimboAI). Research-only quarantine: FLUX.1[dev], Hunyuan3D-2.1.
- Never paste API keys, secrets, or private user data into any AI prompt.
