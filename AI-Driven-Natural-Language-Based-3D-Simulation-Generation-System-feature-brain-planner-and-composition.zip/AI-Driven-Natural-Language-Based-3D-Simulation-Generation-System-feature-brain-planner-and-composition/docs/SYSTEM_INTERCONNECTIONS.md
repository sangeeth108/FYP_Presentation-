# System Interconnections

## Beginner explanation

1. **User writes a prompt** on the website (Next.js).
2. **Website sends the request** to the backend (FastAPI) and immediately gets back a job ID.
3. **Backend creates a job** in the database (PostgreSQL) and puts it in the queue (Redis).
4. **The GPU workstation pulls the job** through a secure outbound-only tunnel (it never opens its own doors to the internet).
5. **The AI brain makes a structured plan** — a `game_spec` JSON document describing the whole game. The AI only fills in a strict form; it cannot write free-form code.
6. **Deterministic builders create the game**: level layout from a seed, assets from cache/curated packs/generation, gameplay from vetted script templates.
7. **The engine exports a web build**, and robot playtesters verify the game is actually completable.
8. **Files upload to storage** (Cloudflare R2), and the website shows a play URL.
9. **The user plays in the browser** and can **download the editable project** to open in Serendib Engine.

The whole time, the website shows live progress so the user watches the game being built.

## Technical explanation

```
Next.js (apps/web)
  │  POST /api/v1/games {prompt, seed?, options} → 202 {game_id, job_id}
  ▼
FastAPI brain (services/brain, Hetzner VPS)
  │  job row → PostgreSQL · task → Redis/Celery
  ▼
GPU worker (services/worker, RTX 5090) — pulls via Cloudflare Tunnel/Tailscale (outbound-only)
  │
  ├─ LangGraph agent chain (vLLM + xgrammar guided JSON)
  │    agents emit partial JSON patches → arbiter merges (constraint priority stack)
  │    → canonical game_spec frozen (JSON Schema 2020-12, contracts/)
  ├─ Deterministic PCG: seeded zone graph → GridMap materialization → navmesh → placement
  ├─ Asset resolution: cache ≥0.92 → curated ≥0.85 → generate (SDXL→TRELLIS.2→Blender) → QA → fallback
  ├─ Template-bound GDScript assembly (engine/templates/, project writer)
  ├─ Serendib headless export: web build (≤90 MB) + editable project zip
  ├─ Validation: 8 gates + playtest bots (state-reading debug singleton, never vision)
  │    failure → classify → localized repair (responsible node only, ≤3/class) → re-validate
  ▼
Artifacts → Cloudflare R2 (web build, project zip, logs, credits.json, lineage)
  │
  ├─ status events → WebSocket/SSE → live progress UI
  └─ GET /play/{game_id} (Pages + R2 signed URLs) · GET download (signed URL)

Serendib Engine desktop → POST /api/v1/engine/sync {nl_request | spec_patch}
  → same brain, same validators → {patch, regen_jobs} → diff preview in Serendib Assist dock
```

## Who talks to whom (matrix)

| From → To | Channel | What flows |
|---|---|---|
| Next.js → FastAPI | HTTPS REST | prompts, job queries, download requests |
| FastAPI → Next.js | WS/SSE | phase/asset/log/verdict events |
| FastAPI → PostgreSQL | SQL (asyncpg) | jobs, specs, artifacts, lineage, registries |
| FastAPI → Redis | Celery protocol | job tasks, working state |
| Worker → Redis/FastAPI | outbound tunnel | job pull, progress push |
| Worker → vLLM/Ollama | localhost HTTP | guided-JSON LLM calls |
| Worker → Godot headless | subprocess | project assembly + export |
| Worker → R2 | S3 API | artifact upload |
| Browser → R2/Pages | HTTPS | game bundle download ($0 egress) |
| Serendib dock → FastAPI | HTTPS REST | NL edit → spec patch round-trip |

## Key invariants

- The GPU workstation **never** accepts inbound connections.
- The LLM can only reference IDs that exist in the PostgreSQL registries (allowlist enforcement).
- Every artifact is hash-linked into the lineage chain; any demo is regenerable byte-for-byte.
- A failed sub-step degrades gracefully (curated fallback, localized repair) — the build never blocks.
