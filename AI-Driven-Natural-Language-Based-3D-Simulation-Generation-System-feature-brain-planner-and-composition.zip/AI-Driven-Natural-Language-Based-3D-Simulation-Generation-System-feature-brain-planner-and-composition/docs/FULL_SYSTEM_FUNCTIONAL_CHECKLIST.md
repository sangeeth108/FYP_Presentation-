# Serendib full-system functional checklist

Last updated: 2026-07-21.

This checklist is the release authority for the natural-language-to-3D-
simulation system. A checked implementation box means the repository contains
the feature and deterministic tests. It does not replace the separate local,
staging and production evidence boxes.

Status markers:

- `[x]` implemented and covered by deterministic repository tests.
- `[~]` implementation started or present but not end-to-end qualified.
- `[ ]` not yet complete.
- `[owner]` requires credentials, licensed content, infrastructure, legal
  approval or another decision that cannot be created safely in source code.

## A. Canonical planning and contracts

- [x] Neutral `/api/v1/simulations` API is canonical; `/games` is compatibility
  only.
- [x] Atomic `RequirementContract` records retain prompt text and observable
  success conditions.
- [x] Schema-bound `SimulationSpec`, `AssetDescriptor`, `WorldPlan`, behavior
  plan and validation evidence.
- [x] Planner decomposes composite objects into independently functional parts.
  The qualified village uses a measured house shell plus a separate hinged door
  leaf with its own state and collision.
- [~] Planner creates explicit connected paths for the qualified village;
  general road, utility and process-network planning remains domain-pack work.
- [x] Planner creates domain-appropriate autonomous agents, schedules and
  processes for words such as “living,” “operating,” and “ecosystem.”
- [~] Deterministic prompt completeness runs before asset expenditure; the
  independent model critic is integrated and exercised locally but still needs
  a pinned production deployment and digest.
- [ ] Mutation tests demonstrate the critic catches omitted prompt contracts.

Acceptance evidence:

- [x] “As a dog, explore a living village with usable doors and navigable
  paths” produces separate dog, resident, house, door and path semantics.
- [x] No whole building receives a door-only state machine.
- [x] No game-only objective, enemy, genre or win-state field is required.

## B. Capability packs and deterministic behavior

- [x] Capability manifests and behavior graphs are versioned data contracts.
- [x] Generated simulations cannot inject scripts into the runtime.
- [x] Asset-qualified partial capabilities: a capability may pass only when its
  manifest-declared rig/animation requirements are measured on every consumer.
- [~] Door hinge pivot, approach volume and state-dependent collision execute
  in the runtime; a dedicated blocked-door obstruction mutation probe remains.
- [x] Controlled quadruped locomotion and animation-map qualification.
- [x] Autonomous navigation controller for scheduled/behavior-tree agents.
- [ ] Dialogue, vehicles, machines, sensors and ecosystem packs reach
  `supported` only after runtime probes exist.
- [ ] Capability SDK conformance suite for third-party packs.

Acceptance evidence:

- [x] A rigged animated dog passes `animal`; an unrigged dog mesh fails.
- [x] Interacting with a door moves only its door leaf and changes collision.
- [x] An autonomous animal follows a navigation path and changes observable
  runtime state.

## C. Assets and real-model generation

- [x] Curated semantic retrieval, exact/semantic cache, generation backend and
  deterministic mesh QA.
- [x] Imported bounds, rig, clips, triangle count, hashes and provenance are
  measured rather than accepted from the planner.
- [x] Generated output is preserved through canonical scene compilation.
- [ ] Add licensed village buildings, standalone doors, people, roads, machines
  and general simulation-domain assets to the farm.
- [x] Procedural building, door and path surfaces receive the same measured
  descriptor and provenance contract as retrieved meshes.
- [x] Generate static assets only for static roles; retrieve or rig animated
  characters before claiming animation support.
- [ ] Generate LODs, collision, material validation and canonical renders for
  every accepted asset.
- [ ] Malware/archive/format scanning for uploaded assets.
- [owner] Approve exact asset licences and generation-model licences.

Acceptance evidence:

- [x] Every required entity in the qualified village resolves to a semantically
  compatible measured asset; no unrelated barrel/capsule substitutions.
- [ ] The same guarantee is demonstrated across every supported production
  domain, not only the qualified village slice.
- [x] Dog, house, door and path dimensions are plausible in metres in the
  qualified village slice.

## D. Semantic PCG and simulation runtime

- [x] Seeded bounds-aware placement, zones, support, clearance, measured AABBs
  and localized typed repair.
- [x] Composite parent/local transform constraints, including Godot-compatible
  yaw composition and inverse local transforms.
- [ ] Road/path graph is solved before buildings and remains connected.
- [ ] Door approach areas stay clear and reachable from both required sides.
- [ ] Interior/exterior containment and portals where requested.
- [x] Navigation mesh includes the intended traversable surfaces and excludes
  blockers.
- [ ] Plausible real-time physics profiles for dynamic entities.
- [ ] Deterministic initialization and replay hashes.

Acceptance evidence:

- [x] No invalid overlap or unsupported placement in the qualified slice.
- [~] Runtime agents navigate and every village door changes state; generalized
  probes for every future domain interaction and required zone remain.
- [ ] Same seed, contracts, assets and engine produce the same logical trace.

## E. Compilation, validation and repair

- [x] Canonical WorldPlan compiler produces an editable Serendib project.
- [x] Mandatory `FAIL`, `NOT_RUN` and `UNAVAILABLE` block publication.
- [x] Revalidation after runtime/validator upgrades creates a new immutable,
  quota-governed run and never rewrites historical evidence.
- [x] Requirement, schema, asset, placement and offline behavior validation.
- [~] Native runtime, navigation, canonical render and browser execution pass
  locally. Desktop packaging awaits the matching Windows export template and
  release qualification awaits a signed Serendib binary.
- [~] Visual critic is independently routed and passed six single-subject views
  in the completed local slice; a separately deployed production artifact and
  approved immutable digest remain owner work.
- [ ] Independent text critic model is deployed and frozen for evaluation.
- [ ] Three-cycle localized repair is exercised with runtime and visual faults.
- [~] Native-project/browser logical state and interaction parity passes;
  packaged desktop/browser parity awaits the Windows export template.
- [owner] Supply signed Serendib binaries and matching export templates.

## F. Production platform

- [x] Tenant identity, roles, quotas, audit, privacy records and PostgreSQL RLS.
- [x] Planning and native build have separate persisted queue boundaries.
- [ ] Split asset generation, engine build and validation into separately
  retryable queues with content-addressed private stage artifacts.
- [ ] Configure regional PostgreSQL, Redis, object storage, KMS, OIDC, WAF/CDN
  and signed images.
- [ ] 100-concurrent-generation load/fairness test passes.
- [ ] Backup restore, disaster recovery and cross-tenant isolation pass.
- [ ] External penetration test has no unresolved critical issue.
- [owner] Choose providers, regions, domains, budgets and incident owners.

## G. Consent-qualified fine-tuning

- [x] Training is off by default and export eligibility fails closed.
- [x] Guardian/teen consent, global/private scope, rights, deletion and research
  exclusions are enforced.
- [x] Governed manifests, encrypted datasets/artifacts and signed model
  evaluations.
- [x] Planner, asset-ranker and placement-ranker deployment contracts.
- [ ] Collect 500 or more eligible neutral verified examples.
- [ ] Train planner and ranker challengers in the signed GPU image.
- [ ] Add automatic shadow comparison, canary observation aggregation and timed
  rollback.
- [ ] Add decrypt-to-tmpfs serving and deletion-deadline retraining scheduler.
- [owner] Approve base-model licence, KMS keys, dataset/model cards and model
  owner promotion.

## H. Serendib rebrand and release governance

- [x] Rebrand patch series, assets and visible-brand checks exist.
- [ ] Build editor, project manager, desktop templates and web templates from
  the pinned upstream source.
- [ ] Sign binaries, publish SBOMs and run screenshot branding checks.
- [ ] Complete DPIA, child-safety assessment, AI-risk assessment, transfer
  review, copyright/trademark review and regional legal sign-off.
- [ ] Publish child-readable/adult notices, takedown and rights workflows.
- [owner] Approve public launch only after all applicable gates above pass.

## Current vertical slice

The current implementation target is the dog/living-village benchmark. Work is
performed in this order:

1. [x] Correct composite specification and attachment contracts.
2. [x] Asset-qualified animal capability validation.
3. [x] Measured house/door/path resolution.
4. [x] Door and autonomous-agent runtime behavior.
5. [x] Path connectivity, approach clearance and navigation probes.
6. [x] Native project/browser execution, six-view visual verification, parity
   and gated Web/editable-project publication pass in
   `run_0a7fbd3644f8487987253c1fd6902160`.
7. [owner] Packaged Windows desktop export remains blocked by the missing signed
   Serendib engine and matching export templates.
8. [ ] Admit a run as training data only when its separate consent, rights,
   moderation, tenant-policy and dataset-quality gates pass. Runtime success
   alone does not make this user prompt training-eligible.
