# System Architecture

**Re-inspected against the code on 2026-07-31 at `c164c1d`.** Every number here was
measured, not estimated; where something is planned rather than built it says so.
Companion documents: [`DEFECTS_AND_DECISIONS.md`](DEFECTS_AND_DECISIONS.md) (what we got
wrong and what it cost), [`BUILD_CHECKLIST.md`](BUILD_CHECKLIST.md) (what is left),
[`GENERATION_PIPELINE.md`](GENERATION_PIPELINE.md) (stage detail).

---

## 1. What the system is

Serendib turns a natural-language prompt into a **verified, playable, editable 3D
simulation**. Not a game generator: an *environment* generator. The canonical route
(`/api/v1/simulations`, `SimulationSpec`) has no genre, no win condition, no enemies. The
older `/api/v1/games` route (`game_spec`, four frozen genres) survives as a compatibility
subsystem and is **not** the production path.

The central design rule, from `CLAUDE.md` §3.15:

> **Ambiguity up, determinism down.** The LLM decides *what* exists. Seeded, testable,
> deterministic code decides *where it goes and how it behaves*.

Every architectural decision below follows from that sentence.

## 2. Measured size

| Area | Files | Lines | Notes |
|---|---:|---:|---|
| `services/brain` (source) | 71 | 15,959 | agents, pcg, api, core, worker, learning |
| `services/worker` | 89 | 16,097 | asset farm, godot client, bots |
| `contracts/` | 7 schemas | 1,713 | JSON Schema 2020-12 |
| `engine/templates/simulation` | 5 `.gd` | — | the only runtime code that ships |
| `apps/web` | 15 | 1,304 | Next.js |
| **Tests** | **90** | **11,700** | **632 tests** (376 brain + 256 worker) |
| Migrations | 13 | 1,574 | 36 tables |
| REST routes | 43 | — | |
| Docs | 30 + 8 ADRs | — | |

Test-to-source ratio is roughly **1 : 3** by line count. That is deliberate: for a system
whose output is non-deterministic by nature, tests are the only place the guarantees live.

## 3. Four products, five layers

```
┌──────────────────────────────────────────────────────────────────┐
│ L1 PRESENTATION   Next.js · live progress · /play · /inspect      │ Cloudflare Pages
└───────────────┬──────────────────────────────────────────────────┘
                │ HTTPS REST + WebSocket/SSE
┌───────────────▼──────────────────────────────────────────────────┐
│ L2 BRAIN      FastAPI · planner · PCG · arbiter · repair          │ Hetzner VPS
│ L3 KNOWLEDGE  Postgres registries · pgvector + bge-m3 · contracts │ (Docker Compose)
│ L5 STATE      PostgreSQL (36 tables) · Redis/Celery · ────► R2    │
└───────────────┬──────────────────────────────────────────────────┘
                │ outbound-only tunnel — the worker never listens
┌───────────────▼──────────────────────────────────────────────────┐
│ L4 GPU WORKER (RTX 5090, 31.8 GB usable)                          │
│ Ollama/vLLM planner · asset farm · Serendib headless · bots       │
└──────────────────────────────────────────────────────────────────┘
```

The worker is **outbound-only** on purpose: a student workstation must never expose an
inbound port, and jobs must survive it being switched off (Redis buffers them).

## 4. The generation pipeline as built

`services/brain/core/stages.py` declares nine stages. **Five are implemented.** That gap is
still the single most important thing to understand about the current system:

| # | Stage | Status | What it does |
|---|---|---|---|
| 1 | `expand` | **live** | prompt → rich description, then planned from it (`expand_enabled`) |
| 2 | `extract` | **not built** | description → structured brief |
| 3 | `deliberate` | **not built** | propose → anonymised critique → revise → agree |
| 4 | `scene_spec` | **live** | brief (or prompt) → `SimulationSpec`, guided JSON |
| 5 | `assets` | **live** | cache → curated → generate → QA → fallback |
| 6 | `layout` | **live** | seeded semantic placement + scatter instancing |
| 7 | `materialize` | folded into `layout` | WorldPlan → `.tscn` project |
| 8 | `verify` | **live** | 15 gates |
| 9 | `publish` | gated by `verify` | artifacts, play URL, download |

`expand` now gives the model somewhere to reason before it must be precise, which was the
root cause in §6 of `DEFECTS_AND_DECISIONS.md`. `extract` and `deliberate` remain unbuilt,
so the spec is still produced by a single guided-JSON call — one that is now informed by an
agreed description rather than by the bare prompt.

### Data flow (canonical route)

```
prompt
  │  guided JSON (Ollama `format=`, canonical schema minus conditionals)
  ▼
SimulationSpec ──► normalisation ──► canonical validation
  │                 (procedural_type, species ids, numeric ranges)
  ▼
asset resolution ──► measurement ──► AssetDescriptor per entity AND species
  │                                  (world_dimensions_m, normalization_scale)
  ▼
semantic placement (seeded)          scatter instancing (seeded, Poisson-disk)
  │  entities first: solved             │  many, sampled — laid down LAST so it
  │  few, exact, constraint-bound       │  can never displace what matters
  └──────────────┬──────────────────────┘
                 ▼
            WorldPlan 1.1.0
                 ▼
     Serendib project (.tscn + world_plan.json + 5 vetted .gd)
                 ▼
     headless export ──► 15 gates ──► bounded repair (≤3/class) ──► publish
```

**Why placement comes after assets:** you cannot decide a temple sits 3 m from a stream
until you know how big the temple's mesh actually is. `measurement_status: MEASURED` is a
hard gate in the WorldPlan contract. Spatial *intent* (`spatial_relations`: inside, near,
along) is authored at spec time; spatial *coordinates* are solved at layout time from real
geometry. Those are different things and the split is deliberate.

## 5. The few and the many

The placement mechanisms exist because worlds contain three kinds of thing:

| | **Entities** | **Linear structures** | **Scatter species** |
|---|---|---|---|
| Meaning | one listed object | one continuous *run* | a *kind*, expanded by density |
| Count | 1–500 (schema cap) | ≤12 runs, ≤16 segments each | up to **12,000** instances (budget) |
| Method | constraint solving, exact | divided along its own line | Poisson-disk sampling on a spatial hash |
| Placed | first | with entities — it *is* entities | last — never displaces entities |
| Rendered | one node each | one solid node per segment | one `MultiMeshInstance3D` per species |
| Identity matters | yes | the run's, not the segment's | no — only the distribution reads |

**A run is the middle case, and the contract had no word for it.** A wall is one thing to
a person and many to a renderer, so declaring it as an entity understates it and
declaring it as a species destroys it — the village's boundary wall came back as 59
scattered panels the player walked through. `linear_structures[]` is declared once and
*materialised* into spec entities before anything else looks at the spec, which is why the
middle column mostly says "it is entities": the mechanism is a translation, not a fourth
solver (`ADR-0016`).

Solving 12,000 ferns would be pointless and O(n²). Nobody cares which fern is where; they
care that the forest looks like a forest. Blue noise is what makes that true — uniform
random clumps and overlaps, a grid looks planted.

**Honesty is built into the layer** (rule 11/13): requested density is frequently
physically impossible. 6 trees per 100 m² with an 8 m canopy cannot pack — the sampler
achieves 1.11/100 m² and reports `shortfall_reason: "packing_limit"` rather than
overlapping geometry or silently dropping the request.

**Measured:** a rainforest spec planning 1,949 instances compiles to a **2,817-byte**
`main.tscn`, because transforms live in `world_plan.json` (the lineage file) and the scene
holds two nodes.

## 6. Safety: the LLM never writes running code

Only **5 vetted GDScript templates** ship, in `engine/templates/simulation/`:

`simulation_runtime.gd` · `simulation_controller.gd` · `simulation_agent.gd` ·
`capability_state_machine.gd` · `scatter_field.gd`

The model selects capability IDs from a registry allowlist and fills parameters. Behaviour
is compiled to **data-only state machines** interpreted by `capability_state_machine.gd`.
No generated string is ever executed. A test asserts the runtime directory contains exactly
these five files — adding a sixth is a deliberate, reviewed act.

Registry allowlist enforcement means **invented capability IDs are impossible by
construction**, not caught by a validator afterwards.

## 7. Verification — 15 gates

`capability_resolution` · `requirement_traceability` · `behavior_compilation` ·
`asset_geometry` · `asset_animation_compatibility` · `semantic_placement` ·
`native_world_plan_compilation` · `import_export` · `navigation_reachability` ·
`runtime_interactions` · `deterministic_critic` · `independent_model_critic` ·
`visual_semantic` · `cross_platform_parity` · `lineage`

Failures are **classified** (schema / asset / build / logic / quality) and repaired by
re-invoking only the responsible node, capped at **3 attempts per class** with
monotonic-progress checks. The whole world is never regenerated.

Gates emit machine-readable error objects (`{code, path, message, hint}`), never strings —
so repair can act on them and the UI can explain them.

## 8. Determinism and lineage

Every random draw is seeded and reproducible:

- world seed: `meta.seed`, masked to signed 32-bit (`& 0x7FFFFFFF`)
- per-species: `random.Random(f"{seed}:scatter:{species_id}")` — so editing one species'
  density **cannot reshuffle any other species**
- placement: seeded rejection sampling against measured bounds

Recorded per run: prompt, prompt hash, seed, planner model ID, spec hash, WorldPlan hash,
asset content hashes, tier per asset, licence per component, and every approximation the
system made.

**Approximations are user-visible.** When the system distorts a request — clamping a 500 m
river to 200 m, raising a 15 m rooftop to the 20 m floor, substituting a rigged body for an
unrigged one — it says so in `approximations[]` with `user_visible: true`. A distorted world
the user is told about beats a generic one they are not.

## 9. GPU sequencing (a hard constraint, not a preference)

31.8 GB usable on the RTX 5090:

| Model | VRAM | Role |
|---|---:|---|
| Qwen 3.6 27B Q4 | 17.4 GB | planner (pinned) |
| Qwen2.5-VL 7B | 6.0 GB | vision critic |
| bge-m3 | 1.2 GB | embeddings / RAG |
| SDXL + TripoSR | ~9 GB | asset farm (current) |
| Hunyuan3D-2.1 | 10 → 21 GB | asset farm (planned, sequential) |

The planner and the mesh generator **can never be co-resident**. The worker sequences
modes — plan → assets → validation — and explicitly releases model memory between them.
This is why generation takes minutes, and why the live progress UI is required rather than
nice to have.

## 10. Learning (built, unwired)

`learning/` and `model_router/` exist (2,505 lines, 13 governance tables) but **no signal
is wired into them yet**. The intended ladder, with honest data requirements:

| Level | Mechanism | Needs |
|---|---|---|
| L1 | RAG few-shot from good runs | *tens* of runs — start here |
| L2 | rankers over K candidate specs | hundreds |
| L3 | QLoRA distillation | thousands |
| L4 | preference pairs from inspector edits | thousands of edits |

Claiming L3 before thousands of runs exist would be dishonest; L1 works immediately and is
the correct first move.

## 11. The inspector

`/inspect/<run_id>` plus `stage_artifacts` (migration 0013, unique on `run_id, stage`) and
three REST endpoints. It shows **every stage's real output JSON**, allows editing a stage
payload, and marks it `edited` so the change survives re-runs.

Built: view, edit, download. **Not built:** step/pause execution — there is no `mode=step`
or `advance` endpoint, so the pipeline still runs to completion, and an edited stage is
stored but not yet consumed downstream.

## 12. Engine strategy

- **Tier 1** — branding only (`patches/*.patch` on a pinned tag). The Godot *name and logo*
  are trademarks; the Serendib rebrand is legally required, and MIT attribution stays.
- **Tier 2** — Serendib Assist: a GDScript EditorPlugin dock that round-trips edits through
  the same brain and the same validators. **Never executes returned code.**
- **Tier 3 — banned** — deep C++ engine changes. GDExtension if a native need is proven.

## 13. Known architectural gaps

Listed here so the architecture is not read as a description of a finished system:

1. `extract` / `deliberate` — declared, not built (§4); `expand` landed 2026-07-31
2. no terrain field — slope and water are accepted in the contract and **not enforced**
3. no constraint solver for `spatial_relations` beyond seeded rejection sampling —
   the four composition primitives (`linear_structures`, `routes[]`,
   `placement.frontage`, `regions[]`, 2026-08-20/21) do not rely on it, so rejection
   sampling is now the fallback rather than the default; what remains unsolved is a
   cluster with no street to address
4. TripoSR output measured at **mean saturation 5/255** — grey blobs; replacement pending
5. a controlled agent still ships a rigged skeleton, because nothing can rig a generated
   mesh yet (§B of the checklist)
6. `stage_artifacts` has no RLS policy while its sibling evidence tables do
7. LangGraph is the planned orchestration upgrade; today the chain is sequential and a
   dead job restarts from the beginning

---

## Related documents

[`DEFECTS_AND_DECISIONS.md`](DEFECTS_AND_DECISIONS.md) ·
[`BUILD_CHECKLIST.md`](BUILD_CHECKLIST.md) ·
[`GENERATION_PIPELINE.md`](GENERATION_PIPELINE.md) ·
[`SYSTEM_INTERCONNECTIONS.md`](SYSTEM_INTERCONNECTIONS.md) ·
[`DATABASE_SCHEMA.md`](DATABASE_SCHEMA.md) ·
[`API_DOCUMENTATION.md`](API_DOCUMENTATION.md) ·
[`adr/`](adr/)
