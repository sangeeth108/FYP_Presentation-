# Ablation results — cited evidence

The numbers the dissertation cites. Every table here regenerates exactly from the
slim rows in this folder — run `python eval/reproduce.py` to check (it recomputes
each p-value from the raw per-prompt outcomes and asserts a match).

- Planner: `qwen3.6:27b`, local Ollama · Baseline arm: **R** (rules, no LLM)
- Tests: McNemar exact (paired binary), Wilcoxon signed-rank (paired continuous),
  Cliff's delta (effect size), Holm–Bonferroni (family-wise correction)
- Provenance (git SHA, seeds): `PROVENANCE.json`

## Finding 1 — reliability comes from the architecture, not the model

`v1_frozen`, 20 prompts, arms R/B/C/D (`ablation_RBCD_seed1.json`):

| arm | pass | schema | latency p50 |
|---|---|---|---|
| R — no LLM | 20/20 | 20/20 | 28 ms |
| B — structured | 20/20 | 20/20 | 95.9 s |
| C — + repair (product) | 20/20 | 20/20 | 95.0 s |
| D — + RAG | 20/20 | 20/20 | 101.6 s |

The deterministic spine passes **every static gate with no LLM**. pass/schema vs
R: p=1.0 (no headroom above 100%). Latency vs R: significant (Holm p≈0.001,
Cliff's δ=1.0) — the LLM's cost is real; its static-quality benefit is
unmeasurable here because everything already passes. *That ceiling is the
finding:* the architecture, not the model, guarantees a playable game.

## Finding 2 — design intent comes from the model

`ablation_RC_content.json`, C vs R, paired McNemar:

| design choice | R | C | McNemar p | effect |
|---|---|---|---|---|
| picks `collect_n` win condition | 0/20 | **7/20** | 0.016 | — |
| authors a player identity | 0/20 | **20/20** | 2e-6 | — |

The Game Designer chooses `collect_n` on exactly the collection prompts (all 5
`expl_*` + 2 loot dungeons) and `reach_zone` elsewhere; rules mode emits
`reach_zone` for all 20, including *"collect ancient relics"*. The LLM authors
"who you are" on every prompt (spec v2.1.0); rules never does.

## Finding 3 — the model understands intent, not keywords

`v2_ambiguous` (keyword-adversarial), C vs R (`comparison_v2_RC.json`):

| metric | R | C | McNemar p | Holm | effect |
|---|---|---|---|---|---|
| genre_match | 1/12 | **11/12** | 0.002 | 0.008 | large (δ=0.83) |

Every v2 prompt describes a genre without the parser's trigger words. Rules mode
defaults all but one to `collect_explore`; the LLM reads the meaning (*"the dead
are clawing from the earth and the last boat leaves at dawn"* → survival). Both
arms still pass 100% of static gates on v2 — a game is valid even when the genre
is wrong, which is why genre understanding needed its own metric.

## The thesis, measured

Reliability is the **architecture's** (Finding 1); design intent and
understanding are the **model's** (Findings 2–3). That split is
"ambiguity up, determinism down" — the LLM decides *what*, deterministic seeded
code decides *how* — with paired significance on frozen prompt sets.

## Honest caveats

- **1 seed, n=20 (v1) / 12 (v2).** Enough for the reported effects (identity is
  p≈2e-6), but the pass-rate ceiling means more seeds won't move the pass
  finding — only harder prompts or richer metrics would.
- The **1 v2 miss** (*"guard the lighthouse lamp to keep it burning"* → survival)
  is kept as-is; a human might waver too.
- Ablations **A/F** (free generation) are external baselines, not run (banned
  in-product, rule 10). **E** (tuned 8B) awaits fine-tune weights.
- These runs used the frozen-seed planner; the seed-derivation fix (unique games
  per seed) landed after, and does not change these single-design-per-prompt
  results.
