# Reproducing the dissertation's evidence

Everything the thesis claims is regenerable from seeds + this repo + the local
planner. The cheap deterministic core verifies in seconds; the expensive LLM
arms are documented exactly. A reproducibility package that demanded 5 GPU-hours
just to *check* itself would not be one.

## Verify the cited numbers (seconds, no GPU)

```bash
python eval/reproduce.py
```

This recomputes **every reported p-value and effect size** from the slim
per-prompt rows in `docs/dissertation/results/` and asserts they match the
frozen comparison files — so a reader confirms the statistics were not fudged,
without re-running a model. It also re-runs the rules-mode control live (R =
20/20, instant) to confirm the deterministic spine still passes unaided, and
prints the commands for the expensive arms. Expect `REPRODUCIBILITY: PASS`.

The evidence itself lives in `docs/dissertation/results/`:

| file | what |
|---|---|
| `RESULTS.md` | the three findings, as cited |
| `ablation_*.json` | slim per-prompt outcomes (metrics only; level-plan bulk removed) |
| `comparison_*.json` | the reported statistics (McNemar/Wilcoxon/Cliff's/Holm) |
| `PROVENANCE.json` | git SHA, planner model, seeds |

## Regenerate from scratch (needs the GPU planner)

Prerequisites: Ollama serving `qwen3.6:27b` + `bge-m3`, Godot for `--full`
(see `docs/runbooks/RUN_FULL_LOCAL.md`).

```bash
# Finding 1 (reliability) + Finding 2 (design intent) — v1, 20 prompts
python eval/ablation_runners/run_ablation.py --conditions R,B,C,D --seeds 1
python eval/ablation_runners/compare.py eval/reports/ablation_R-B-C-D_*.json --baseline R

# Finding 3 (genre understanding) — v2 adversarial, 12 prompts
python eval/ablation_runners/run_ablation.py --conditions R,C --seeds 1 \
  --prompts eval/benchmark_prompts/v2_ambiguous.json
python eval/ablation_runners/compare.py eval/reports/ablation_R-C_*.json --baseline R

# then re-freeze the cited evidence from the fresh runs
python eval/reproduce.py --freeze
```

Seeds are fixed (`SEEDS = (0, 1, 2)`), and the planner sampling seed derives from
the game seed, so a given seed reproduces a given design (rule 14). Same seed →
same numbers.

## What is NOT reproduced here, and why

- **Ablations A and F** (free, unstructured generation) are *external* baselines —
  LLM-authored gameplay is permanently banned in-product (CLAUDE.md rule 10), so
  they belong to a separate harness, scored by the same gates afterward.
- **Ablation E** (tuned Qwen3-8B vs untuned) awaits fine-tune weights; the runner
  and stats are built and it slots in via `--conditions E`
  (`docs/runbooks/FINE_TUNING.md`).
- **Wall-clock latency** is order-of-magnitude (a shared box under a 27B model),
  not a tuned figure; the *significance* of the R-vs-LLM latency gap is the claim,
  not the exact seconds.
