# Research Notes

Working notes for the dissertation. Keep `references.bib` (create alongside this file when the first citation lands) updated **as sources are used**, not at the end. Separate verified facts from assumptions, mirroring the report's tables.

## Research questions & hypotheses

| RQ | Question | Hypothesis | Ablation |
|---|---|---|---|
| RQ1 | Multi-agent orchestration vs monolithic generation? | H1: orchestration > one-shot on playability | A vs C |
| RQ2 | Does schema validation + repair improve playability/editability? | H2: repair raises playability, cuts cleanup | B vs C |
| RQ3 | Does RAG improve controllability / reduce spec drift? | H3: RAG improves controllability + fidelity | C vs D |
| RQ4 | Deterministic hybrid vs LLM-only assembly? | H4: hybrid → higher crash-free + better frame time | D vs F |

## Study design

50–100 frozen prompts × 3 seeds × 4 genres. Ablations: A one-shot · B structured no-repair · C structured+repair · D +RAG · E tuned-8B vs untuned-32B planner · F (optional) deterministic vs free LLM assembly. Statistics: Wilcoxon signed-rank on per-prompt outcomes; effect sizes (Cliff's delta / rank-biserial); bootstrap 95% CIs; Holm-Bonferroni correction. Threats to validity: internal (seed variance → frozen prompts/seeds + lineage), external (genre generalization), construct (playability ≠ fun → human study), conclusion (multiplicity → corrected).

## Novelty claim (to defend)

*"A prompt-to-game system becomes academically and commercially stronger when it generates a canonical engine specification first, validates and repairs that specification iteratively, and only then materialises a browser build and an editable engine project."* Ingredients exist in the literature (ReAct, RAG, PCGML, constrained decoding, VGDL/Ludii generation); the combination + first-party AI-native engine is the contribution.

## Key literature anchors (verify each citation before use)

- Summerville et al., PCGML, IEEE ToG 2018 — frames ML generation for co-creativity, repair, critique.
- LLM-and-games scoping reviews: arXiv:2403.02613 (76 papers), arXiv:2411.00308 (177 articles, 56 PCG); Gallotta et al., IEEE ToG 2024 (definitive survey).
- "Game Generation via LLMs" (IEEE CoG 2024) — VGDL rules + levels co-generation.
- GAVEL (NeurIPS 2024) — evolves Ludii games; 185 variations, 130 playable.
- DreamGarden (CHI 2025) — hierarchical LLM planning in Unreal; closest conceptual cousin.
- Genie 3 (DeepMind, Aug 2025), Muse/WHAM (Microsoft, Nature 2025) — world models; no editable artifact.
- GlitchBench (CVPR 2024) — 43.4% vision glitch-detection ceiling → justifies state-reading bots.

## To refresh at build time

- Skim 2–3 newest (2026) papers on LLM game generation each phase.
- Re-verify Godot current stable + web-export constraints; model licenses; cloud prices.
- P0 exit: write a one-page research summary confirming the stack is still valid.

## Build-time spikes (P0)

1. TRELLIS.2 runs on the 5090 within VRAM budget + acceptable time.
2. Godot web export ≤90 MB plays on 4 browsers.
3. vLLM guided decoding yields valid spec JSON on 20 sample prompts.
4. Outbound tunnel + pull-worker completes a job end-to-end.
