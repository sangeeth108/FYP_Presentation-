# Technology Stack

Every choice below was validated in the planning report against 2025–2026 sources. **Rule: re-verify each model license at build time before it enters the product path** (log in `licensing_ledger.csv`).

| Area | Technology | Why chosen | Connected with | Alternatives | Risks / notes |
|---|---|---|---|---|---|
| Frontend | Next.js (TypeScript) | Mature React framework; static + dynamic pages; easy Cloudflare Pages deploy | FastAPI (REST + WS/SSE); Pages hosting | SvelteKit, Remix | Keep the play page a thin shell around the Godot web export |
| Backend/API | FastAPI (Python 3.11+) | Async, typed, OpenAPI for free; same language as ML tooling | Redis/Celery, PostgreSQL, LangGraph | Django/DRF, Node | Agents are modules inside one service — not microservices |
| Database | PostgreSQL 16 | Jobs, specs, artifacts, lineage, registries; battle-tested | Brain, worker, LangGraph PostgresSaver | MySQL, SQLite | Bind to localhost on VPS; nightly backups to R2/B2 |
| Vector search | pgvector + bge-m3 (MIT) | Consolidates on existing Postgres — no separate vector DB host | RAG in the brain's knowledge layer | Qdrant, Weaviate | bge-m3 license verified MIT |
| Queue | Redis + Celery | Simple, proven job queue; buffers jobs while the 5090 is offline | Brain enqueues; GPU worker pulls | RabbitMQ, RQ | Working state in Redis; permanent lineage in Postgres |
| Object storage | Cloudflare R2 | **$0 egress** — viral play traffic costs nothing; S3-compatible | Worker uploads; play/download signed URLs | S3, B2 | Serving cost scales with storage, not traffic |
| Frontend hosting | Cloudflare Pages | Free tier, global CDN, `_headers` support (COOP/COEP if threaded builds later) | Next.js build, R2 game bundles | Vercel, Netlify | Single-threaded builds are the default (Safari/iOS) |
| Backend hosting | Hetzner VPS (CX32/CX42) + Docker Compose | Cheap always-on host (€7–16/mo) for brain + DB + queue | All stateful services | DigitalOcean, Fly.io | Watch Hetzner's 2026 price adjustments |
| GPU worker | Local RTX 5090 (32 GB) workstation | Owned hardware; all heavy AI + build work | Outbound-only tunnel to cloud queue | Rented cloud GPU | Single point of failure → queue buffers + rented-GPU failover runbook |
| Tunnel | Cloudflare Tunnel or Tailscale | No inbound ports on home network — security requirement | 5090 ↔ VPS queue | WireGuard manual | Non-negotiable: outbound-only |
| LLM serving | vLLM (primary) / Ollama (fallback) | Production guided decoding; grammar caching | xgrammar, LangGraph agents | TGI, llama.cpp | 32 GB VRAM: plan → assets → validation time-slicing; never co-resident |
| Guided decoding | xgrammar (JSON Schema 2020-12) | Token-level schema enforcement — spec valid by construction | game_spec.schema.json, vLLM | Outlines, guidance | Keep schema xgrammar-friendly (avoid exotic constructs) |
| Orchestration | LangGraph + PostgresSaver | State graph fits validate→repair loops; durable resumable jobs | FastAPI brain, PostgreSQL | Temporal, DBOS | Honest limit: single-process durability; Temporal/DBOS is the scale-out path |
| Planner model | **`Qwen/Qwen3.6-27B`** (Apache-2.0, pinned 2026-07-08) | Latest Apache-2.0 dense Qwen; vLLM + tool-call/guided-JSON; 262K ctx; also covers the gated adapter-coder | vLLM, xgrammar | Qwen3-32B, other Apache/MIT LLMs | License verified on HF model card; quantize (AWQ/GPTQ 4-bit) to share the 32 GB 5090 with time-slicing |
| Tuned planner (P4) | small Qwen dense + QLoRA (Unsloth/PEFT/TRL) | Distillation ablation — research contribution | Eval harness | — | Behind a flag only; untuned 27B remains the default; pick the exact small dense SKU at P4 |
| Image gen | SDXL / FLUX.1-schnell (product) | Product-safe licenses | ComfyUI, style anchors | FLUX.1[dev] — **research only (non-commercial)** | Style anchor per game prevents drift |
| 3D gen | TRELLIS.2 (MIT) | Product-safe; runs on single consumer GPU | SDXL concept → mesh → Blender cleanup → GLB | Hunyuan3D-2.1 — **research only (UK/EU/Korea excluded)**; TripoSR fallback | Spike: verify VRAM fit on the 5090 |
| Audio gen | Stable Audio Open | SFX/short loops ≤47 s; product-safe under $1M revenue threshold | Cue-text hash cache; CC0 fallback library | AudioCraft (check license) | Loudness QA gate |
| Engine | Godot 4.x pinned stable tag → **Serendib Engine** fork | MIT code; WebGL2 export; GDScript templates | engine/serendib patches, CI builds | Unity/Unreal (licensing/weight) | Godot name/logo trademarked → rebrand legally required |
| Engine build | SCons 4.4+, Python 3.9+, Emscripten (pinned) | Godot's build system | GitHub Actions build matrix | — | **Emscripten version must match the Godot tag** — top build-failure cause |
| CI | GitHub Actions | Free for the repo; lint/test/build matrix | Everything | GitLab CI | Add day 1 — nothing merges untested |
| Containers | Docker + Docker Compose | Same images locally, on VPS, and for GPU failover | VPS stack, worker | Podman | — |
| Docs | Markdown + ADRs + runbooks + licensing ledger + references.bib | Dissertation + reproducibility demands | docs/ | Wiki | Update after every meaningful change |

## Verified facts vs. assumptions to re-check at build time

**Verified (2025–2026):** Godot web = WebGL2 Compatibility renderer only, no C# web export, single-thread default since 4.3 · Qwen3 dense ≤32B Apache-2.0 · vLLM+xgrammar production-ready · Godot name/logo trademarked separately from MIT code · Hunyuan3D-2.1 excludes UK/EU/Korea · FLUX.1[dev] non-commercial · R2 egress $0 · RTX 5090 = 32 GB GDDR7 · stock Godot 4 does **not** import Draco meshes; VRAM-compressed textures fail on web export.

**Current reproducible engine pin (re-verified 2026-07-20):** Godot
`4.6.3-stable` + Serendib Emscripten pin `4.0.11`. Planner, critic and vision
roles are selected from the provider-independent model registry by recorded
version and digest.
**Still to re-verify at build time:** Serendib name clearance (trademark DBs / registries) · cloud prices · TRELLIS.2 VRAM on the 5090 · other asset-model licenses before product use.
