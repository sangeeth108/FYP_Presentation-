# Validation Plan — the 8-gate stack

Every generated game passes these gates **in order** (cheapest/earliest first — a wrong order wastes GPU time on games that would fail a cheap check). Each gate emits a machine-readable verdict into `validation_reports`.

| # | Gate | Checks | Implemented by | On failure |
|---|---|---|---|---|
| 1 | Schema | Spec is valid JSON Schema 2020-12 | Guided decoding (by construction) + `services/brain/contracts/` validator | Repair agent patches the failing path only |
| 2 | Constraint | Camera/genre/kit/animation compatibility; budgets within grammar | Deterministic cross-field rules | Localized repair on owning agent's lane |
| 3 | Asset QA | Manifold geometry, tri/texture budgets, CLIP similarity, style classifier, audio loudness | `services/worker/asset_farm/` QA gate | 1 regen attempt → curated substitute (never blocks) |
| 4 | Import/export | Godot imports cleanly; web + project export exit 0; build ≤90 MB | `services/worker/godot_client/` | Classify → route (assets→S5, assembly→S6) |
| 5 | Static playability | Navmesh path spawn→objective exists; lock-key solvable; timer plausible | `services/worker/validators/` (graph solvers) | Layout repair (S4) or mechanics repair (S2) |
| 6 | Dynamic | ≥1 playtest bot completes the game; ChaosBot finds no fall-through/stuck anomalies | `services/worker/bots/` via debug singleton | Classify by anomaly type → responsible node |
| 7 | Quality | Critic rubric: prompt fidelity + style consistency | LLM critic (advisory scores recorded) | Below threshold → flagged, optionally repaired |
| 8 | Lineage | Prompt, seeds, model digests, spec hash, build hash all recorded | `services/brain/services/` lineage writer | Blocks DEPLOYED until complete |

## Repair policy

- Failures classified into: `schema | asset | build | logic | quality`.
- Re-invoke **only the responsible node** — never regenerate the whole game.
- Cap: **3 attempts per failure class**, with monotonic-progress checks (each attempt must reduce the error set, else FAIL fast).
- Every attempt recorded in `repair_attempts` (this table is dissertation data — RQ2).

## Validator error object shape

```json
{
  "code": "OBJECTIVE_UNREACHABLE",
  "gate": 5,
  "path": "$.objectives[0]",
  "message": "No navmesh path from player_spawn to objective 'escape_boat'.",
  "hint": "Zone graph edge z3->z7 missing or blocked; check ramp insertion.",
  "failure_class": "logic"
}
```
Strings-only errors are banned (CLAUDE.md §3.13) — repair automation and the dissertation both depend on structured errors.

## Reproducibility spot-check

Each phase: pick 10 generated games, regenerate from lineage, confirm byte-level reproduction of spec hash + build hash.
