# Golden Game — Build-Ready Task List

Operational task list derived from [GOLDEN_GAME_PLAN.md](GOLDEN_GAME_PLAN.md). This is the P0 gate. **Owner:** M4 (content/validation) + M3 (build/export). **Where it lives:** a standalone Godot project (not `services/`); curated assets under `content/`; the validated spec at `contracts/examples/golden_game.spec.json`.

> **Engine pinned (2026-07-07):** Godot **`4.7-stable`** + Emscripten **`4.0.11`** ([runbooks/GODOT_BUILD.md](runbooks/GODOT_BUILD.md)).
> **You can start building now** with the **official Godot 4.7 stable editor** download — you do NOT need to compile from source for the P0 golden game (official editor + official web templates satisfy the gate). Source-building the engine (with Emscripten 4.0.11) is a P1 concern for the Serendib rebrand.

Legend: ☐ todo · every hand-written GDScript here becomes a **vetted template** in `engine/templates/` during P1, so write it clean and name every node in **PascalCase** (`SkeletonZombie_03`, never `Node3D_17`).

---

## 0. Decisions (lock first)

- **Chosen genre:** `arena_combat_3d` — "Castle Gate Trial". ✅ confirmed in `DECISION_LOG.md` (item 6, resolved 2026-07-09)
  - (Original plan was `topdown_survival_escape_3d` "Foggy Village Escape" — superseded once the souls-like base proved faster to a real, license-clean, working export.)
- **Camera:** `third_person`.
- **Seed:** `0` (hand-placed level; no procedural placement in the golden game — matches `contracts/examples/golden_game.spec.json`).

## 1. Player controller ☐

- Node: `CharacterBody3D` named `Player`, top-down movement (WASD / stick), `move_speed ≈ 5.5`, `health = 100`.
- Verbs: `move`, `sprint`, `interact`, `collect`, `hide`.
- Script → future template `controller_topdown_3d` (`engine/templates/controllers/`).
- ☐ Camera rig: fixed overhead `Camera3D` with slight angle; follows `Player`.
- ☐ Interact ray/area for pickups + door.

## 2. Enemy behavior ☐

- ~8 `CharacterBody3D` "shambler zombies" (`SkeletonZombie_01..08`).
- Behavior: **patrol → chase on sight → melee** using `NavigationAgent3D`. Stats: `health 40, damage 10, speed 2.5`.
- Scripts → future templates `ai_patrol_chase` (`engine/templates/ai/`) + `combat_melee_basic` (`engine/templates/combat/`).
- ☐ Line-of-sight / detection radius; return-to-patrol when player lost.
- ☐ Damage the player on contact; player death triggers lose.

## 3. Objectives & win/lose ☐

- **Objective 1:** `collect_n` — collect **5** `supply_crate` pickups.
- **Objective 2 (win):** `reach_zone` — reach the `escape_boat`; **requires** objective 1 complete (dependency = the "lock/key" pattern).
- **Lose:** `player_death`.
- Scripts → future templates `collect_n`, `reach_zone` (`engine/templates/objectives/`), `player_death` fail state.
- ☐ Objective manager tracks counts + gates the boat until 5 crates collected.
- ☐ Boat interaction only "wins" when the gate is satisfied (else a "need supplies" hint).

## 4. Level layout ☐

- One contiguous foggy village, **~7 zones**, single elevation tier, guaranteed path spawn → crates → boat.
- Built from a small grid-aligned low-poly kit; **doorframe modules carry a `Marker3D` socket** (the door is a separate `door_hinged` template scene, never a baked-shut mesh).
- ☐ Lay out zones (houses, paths, shoreline with the boat at the critical-path end).
- ☐ Place 5 crates along/near the path; place ~8 zombies with safe-spawn distance from the player start.
- ☐ Bake the navmesh (`NavigationRegion3D`) at build time — confirm zombies + player path correctly.
- ☐ Add a `door_hinged` on at least one enterable house (open/close, creak SFX, toggles a `NavigationLink3D`).

## 5. Props / assets ☐

- ~40–60 props total: supply crates, fences, houses, the escape boat, foliage. **Hand-made / CC0 curated low-poly only — no AI generation.**
- ☐ Source or model the kit; keep tris modest (see `tri_budget` per asset in the spec; ≤ ~8000 for characters).
- ☐ **Log every asset** (model + license + source) in `docs/licensing_ledger.csv` with a `license_ref`.
- ☐ One per-game style anchor (muted, desaturated, soft fog) so everything reads as one set.
- ☐ glTF/GLB interchange; atlas textures; cap resolutions.

## 6. Lighting / mood ☐

- `WorldEnvironment` preset `dusk_fog` + a few budgeted local lights + emissive materials (free glow).
- ☐ Bake lighting at build time (never at web runtime).
- ☐ Verify fog reads well and doesn't tank frame time on web.

## 7. UI / HUD ☐

- Minimal HUD: supplies collected `x / 5`, player health, an objective hint line, win + lose screens.
- ☐ `CanvasLayer` HUD, PascalCase nodes (`HudRoot`, `SuppliesLabel`, `HealthBar`).
- ☐ Win screen ("You escaped!") + Lose screen ("You died") with a restart button.
- Keep it simple/friendly (approachability lesson from the design system).

## 8. Audio ☐

- 1 ambient loop (eerie wind) + 2 SFX (door creak, pickup). **CC0 or hand-made**, ≤47 s each.
- ☐ Wire cues to events; log each audio asset + license in the ledger.
- ☐ Confirm loudness is comfortable (a QA concern that becomes gate 3 later).

## 9. Export checklist ☐

- ☐ Import the pinned web export template (`godot.web.template_release.wasm32.zip`).
- ☐ Renderer = **Compatibility (WebGL2)**; **single-threaded** export preset (Safari/iOS reach).
- ☐ Headless/editor export to `build/index.html` (+ wasm/pck/js).
- ☐ Brotli enabled; **no Draco meshes, no VRAM-compressed textures** (unsupported on Godot web).
- ☐ Custom HTML shell with a themed loading card.
- ☐ Navmesh + lighting baked into the build.

## 10. ≤ 90 MB size checklist ☐

- ☐ Measure the total exported bundle size — **record the actual number** (must be **≤ 90 MB** post-Brotli).
- If over budget, in this order: mesh decimation → texture atlasing → resolution caps → drop/merge props.
- ☐ Re-measure after each reduction; note the final size in the gate evidence.

## 11. Four-browser test checklist ☐

Play start → win on each; note version + result:
- ☐ **Chrome** — loads, playable, completes, no console errors.
- ☐ **Firefox** — same.
- ☐ **Edge** — same.
- ☐ **Safari** — same (the one people skip — **do not skip it**; most constrained target).
- ☐ **Mobile/tablet smoke test** (single-threaded build loads + is controllable).
- ☐ No crash in a 5-minute session; objective reachable; no fall-through / stuck.

## 12. Schema fields needed to represent the golden game

The hand-built game must be fully describable by `contracts/game_spec.schema.json` (this is the schema's first real-world test — the draft example already mirrors it at `contracts/examples/golden_game.spec.json`). Coverage map:

| Game element | Schema path |
|---|---|
| Title / genre / camera / seed / mood / style anchor | `meta.*` (`genre`, `camera`, `seed`, `mood`, `style_anchor`) |
| Village biome / kit / fog preset / zone graph | `world.biome`, `world.kit_id`, `world.lighting_preset_id`, `world.zone_graph.{algorithm,zone_count,verticality_tiers}` |
| Player controller / speed / health / verbs | `player.{controller_template_id,move_speed,health,verbs}` |
| Zombies (AI, combat, count, stats, asset) | `entities.enemies[]` (`ai_template_id`, `combat_template_id`, `count`, `stats`, `asset_brief`) |
| Crates / door / boat props | `entities.props[]` (`interactable_template_id`, `asset_brief`, `placement_tags`) |
| Collect-5 → reach-boat (with dependency) | `objectives[]` (`collect_n`, `reach_zone`, `params.requires_objective`, `is_win_condition`) |
| Player death | `fail_states[]` (`player_death`) |
| Ambient + creak + pickup cues | `audio.cue_sheet[]` |
| ≤90 MB / session / prop+enemy caps / tri caps | `budgets.*` |
| Prompt / seeds / digests / hashes | `lineage.*` (filled by the system, not by hand — but recorded manually for the golden game) |

☐ Confirm every built element maps to a field above; if something has no home, that's a **schema gap to fix before freeze** (raise it, do not freeze around it).

## 13. Gate sign-off (all must pass → then freeze schema v2)

> **Build shipped 2026-07-09:** "Castle Gate Trial" (`arena_combat_3d`, third_person) — souls-like base (Unlicense) + team-added `WinZone` (lever → unlock door → reach zone → win). Export: single-threaded WebGL2, VRAM compression off, zero export errors.

- ☑ Plays start-to-win in the browser (lever → unlock → escape → win card; **user-confirmed 2026-07-09**).
- ☑ Bundle ≤ 90 MB (actual: **77 MB uncompressed**; post-Brotli will be smaller — record served size at deploy).
- ☑ Chrome / Firefox / Edge / Safari + mobile smoke — **all pass (user-confirmed 2026-07-09)**.
- ☑ `python scripts/validate_contracts.py` passes with the golden-game spec (rewritten to the actual build, 2026-07-09).
- ☑ Built from the pinned editor + web template — **CI waiver recorded** (`DECISION_LOG.md` 2026-07-09): the golden game is a standalone gitignored project, so CI cannot build it; local Godot 4.7-stable headless export (zero errors) is the accepted P0 evidence. CI-built applies from P1 (project-writer output lives in-repo).
- ☑ No crash in 5 min; objective reachable; no fall-through (**user-confirmed 2026-07-09**).
- ☑ Lineage recorded (seed 0 hand-placed, asset source + Unlicense in ledger, build hash `7166ef96…` in spec).

**GATE MET 2026-07-09** → `DECISION_LOG.md` updated, golden-game row ticked in `IMPLEMENTATION_CHECKLIST.md`, `game_spec.schema.json` **frozen as v2.0.0**. P1 is open.
