# Requirements

## Functional requirements

| ID | Requirement | Phase |
|---|---|---|
| FR-01 | User submits a natural-language prompt and receives a job ID immediately (202) | P0–P2 |
| FR-02 | Live generation progress (phases, logs, verdicts) via WebSocket/SSE | P2 |
| FR-03 | Generated game playable in browser at a shareable `/play` URL | P1–P2 |
| FR-04 | Game downloadable as an editable Serendib Engine project (zip) | P1–P3 |
| FR-05 | Unsafe / out-of-scope prompts rejected with a friendly explanation (S0 gate) | P2 |
| FR-06 | Every game reproducible from recorded lineage (prompt, seeds, model digests, hashes) | P1+ |
| FR-07 | Failed generations repaired locally (responsible node only, ≤3 attempts/class) | P2 |
| FR-08 | Serendib Assist dock: NL edit request → spec patch → diff preview → per-hunk apply → re-export | P3 |
| FR-09 | Four genres, three cameras selectable/inferable | P2–P3 |
| FR-10 | Asset resolution: cache → curated → generate → QA gate → curated fallback (build never blocks) | P3 |

## Non-functional requirements

| ID | Requirement |
|---|---|
| NFR-01 | Web build ≤90 MB (Brotli; decimation + atlasing; NO Draco / VRAM texture compression — unsupported on Godot web) |
| NFR-02 | Works on Chrome, Firefox, Edge, Safari; single-threaded export default for Safari/iOS |
| NFR-03 | Latency: cold generation minutes-scale; cache + parallel asset farm are the levers; p50/p95 tracked from P2 |
| NFR-04 | Schema validity >97%, build success >90%, playability >95%, repair success >70% |
| NFR-05 | No inbound ports on the GPU workstation — outbound-only tunnel |
| NFR-06 | No secrets in repo; machine-readable validator errors; everything seeded/reproducible |
| NFR-07 | Navmesh + lighting baked at build time, never at web runtime |
| NFR-08 | Cost within chosen tier (Low ≈$18 / Medium ≈$36 / Ideal ≈$90 per month) |

## Academic requirements

- Dissertation with ablations A–F (frozen 50–100 prompts × 3 seeds × 4 genres; Wilcoxon signed-rank, effect sizes, Holm-Bonferroni).
- Ethics approval + DPIA **before** the user study; child-safety duty if minors involved.
- Reproducibility package: schema, frozen prompts, lineage, licensing ledger.
- `references.bib` maintained continuously in `docs/`.
- Mid-project demo at end of P2; final defense with 5 cached showcase games + 1 live generation.

## Constraint grammar (locked at P0 gate — schema v2)

- Genres: `topdown_survival_escape_3d` · `arena_combat_3d` · `collect_explore_3d` · `dungeon_crawl_3d`
- Cameras: `third_person` · `top_down_3d` · `isometric_3d`
- Budgets: 50–200 props · 5–25 enemies · 3–8 min sessions · ≤90 MB build
- Schema is versioned (`schema_version`); freeze v2 at the P0 gate; validator supports N-1.
