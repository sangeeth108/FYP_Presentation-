# Serendib — Build Checklist

What remains, in priority order. Re-inspected against the code **2026-07-31 at `8c84f81`**.
Companions: [`ARCHITECTURE.md`](ARCHITECTURE.md) (how it works now),
[`DEFECTS_AND_DECISIONS.md`](DEFECTS_AND_DECISIONS.md) (what we got wrong and what it cost).

Legend: `[x]` done and pushed · `[~]` partly done · `[ ]` not started · **⚠** = broken today
· **[you]** = needs your decision, not my time.

---

## Where the system actually stands

| | |
|---|---|
| Pipeline stages implemented | **5 of 9** (`expand`, `scene_spec`, `assets`, `layout`, `verify`) |
| Verification gates | 15 |
| Tests | 632 (376 brain + 256 worker), all green |
| Prompt success rate, n=10 | **10/10** after today's clamp (was 8/10) |
| Vetted GDScript templates | 5 |
| Known ⚠ blockers below | 4 |

The system plans well and verifies honestly. Its weakest links are **what the meshes look
like** (B) and **how little reasoning happens before planning** (C).

---

## A. Scatter — built, one confirmation left

Everything here shipped today (`3309f72`, `4c1d8ef`). It had been worse than invisible: a
scatter-bearing plan declares WorldPlan `1.1.0` against a writer that accepted only
`1.0.0`, so those worlds **failed to build at all**.

- [x] Accept WorldPlan 1.1.0 · render a `Scatter` node per species ·
      `MultiMeshInstance3D` via `scatter_field.gd` · measure `spc_` descriptors ·
      constrain species ids · placeholder for unresolved species · shadows off
- [x] **Ran a generated project in Godot 4.7** — and it was worth doing. The engine
      built 2,299 instances across 2 fields and the GPU buffer matched the plan to 7
      decimal places, but every instance was **half-buried**: a `BoxMesh` is modelled
      centred on its origin while the plan gives a point *on* the ground, so a 25 m tree
      showed 12.5 m and ferns read as flat slabs. Fixed by lifting each instance by its
      mesh's own lowest extent, which is correct for a centred primitive and a no-op for a
      glTF authored base-at-origin.
- [x] Regression test using the existing `GODOT_BIN` skip pattern, verified to fail
      (`-1.21`) when the lift is removed. Note: **headless cannot test this** — the dummy
      renderer never allocates the MultiMesh buffer, so `get_instance_transform` returns
      identity for every index (confirmed against a hand-built MultiMesh with known
      values). It needs a real rendering driver.
- [x] **≤90 MB web budget confirmed with a dense world.** Exported a 200×200 m world
      carrying **11,947 instances** (at the 12,000 budget) across 6 species:
      **42.22 MB total**, of which `index.wasm` is 39.5 MB and the entire world —
      scene, assets and all 11,947 transforms — is a **2.38 MB** `.pck`. Content is
      nearly free; the engine binary is the cost. Nothing here needs shrinking.
- [ ] Distance LOD — **not a size problem.** The budget has 48 MB of headroom, so the
      only reason to trim instances is frame rate, and that cannot be measured headless.
      Needs a real browser on target hardware before choosing a default for
      `max_visible_instances` (the manual knob already exists).
- [ ] Note for later: `world_plan.json` is 2.28 MB of that 2.38 MB `.pck`, because it
      carries every transform as readable JSON. That is the deliberate trade for
      editability and lineage, and it scales linearly if the instance budget is raised.

## B. Asset quality — ⚠ **the weakest part of the system**

- [x] Skeleton no longer ships for every unmatched character (`d58dcd3`)
- [ ] **⚠ Replace TripoSR.** Measured: vertex colours only, **mean saturation 5/255** —
      grey blobs, ~120k triangles of slivers. The vision critic correctly rejects them, so
      this blocks G3 as well. → **Hunyuan3D-2.1** (shape 10 GB → texture 21 GB
      *sequentially*, peak 21 GB of 31.8 GB), **TRELLIS.2** (MIT) as the ablation arm.
      *Biggest single visual improvement available.*
- [x] **PBR already survives the pipeline** — I checked before building anything and
      this item was a phantom. Queried the live renderer: `albedo`, `roughness 0.88` and
      `metallic 0.00` arrive intact through trimesh → GLB → Godot import → merged mesh →
      MultiMesh, and *per-part* materials survive the merge (a teak's three green crowns
      and one brown trunk are four distinct surfaces). The real gap is **textures**, which
      procedural geometry has no UVs for and which generated meshes only gain with a
      better model — so it belongs to the model swap, not to the pipeline.
- [ ] **[you] The controlled agent still gets a skeleton.** The planner marks it
      `requires_animation: true`, nothing can rig a generated mesh, so the rule correctly
      prefers a body that moves. Options: auto-rigging (UniRig — on your cut list), a CC0
      human/robot pack, or accept a static player. *I recommend the CC0 pack: cheapest, and
      it fixes NPCs too.*
- [ ] Real procedural species (trunk+canopy tree, rock, fern, log) — deterministic, no GPU,
      ideal for 12,000 instances. **Today every procedural asset is a box.**
- [ ] Semantic retrieval (CLIP + bge-m3) over a larger library

## C. Brain quality — the root cause of most defects

- [x] Prompt rules verified live; `size_m` made required (`b407f2a`)
- [x] Verified across 10 varied prompts, not one — found a **20% total-loss rate** and
      fixed it as a class (`c164c1d`)
- [x] **Expand stage** — built, wired, recorded as stage 1, toggled by `expand_enabled`
      so both ablation arms run on one build. **Measured, and the first result was a
      regression**: 4 of 10 worlds lost all scatter because a brief made the planner
      enumerate (`ent_apple_core_01`) instead of abstract. Fixing that exposed four more
      defects — `uniqueItems` unenforceable by the grammar, zero-density species whose
      meshes were still being generated, and three contract bounds that punished accurate
      answers. After the fixes: no fallbacks, no empty worlds, species at parity, and
      physically real species (the baseline was scattering *smoke particles* as meshes).
      Full record in `DEFECTS_AND_DECISIONS.md` §18-21.
- [ ] **[you] Entity count tripled** (4.3 → 14.1 mean; the market emitted
      `ent_market_stall_01`…`_08`, eight numbered copies of one kind). Richer, but it costs
      asset generation and constraint solving. Should numbered repeats collapse into a
      species, or is a detailed market what you want? *No evidence either way, so nothing
      changed.*
- [ ] **Extract stage**: description → structured brief
- [ ] **Deliberation loop**: propose → *anonymised* critique → revise → agree, with a
      Skeptic, stability detection, hard round cap. *Expensive; do it after `expand` has
      moved the baseline, so its value is measurable.*
- [ ] Open-vocabulary fallback ladder: decompose-and-retry → noun extraction → generic
      terrain → fail truthfully
- [ ] Re-run the spread at n=20 (your frozen P2 set) once `expand` lands — 10 prompts is a
      smoke test, not a benchmark

## D. Placement realism

- [ ] Terrain field: heightfield, slope, water mask, distance-to-water
- [ ] Region masks, so "inside deep_canopy" is checkable rather than assumed
- [ ] Constraint solver for `spatial_relations` (near/inside/on/facing/between/along)
- [x] **The quiet lie is now spoken.** `near_tags`/`avoid_tags` *are* honoured;
      `slope_max_degrees` is accepted by the contract and used by nothing. Since the ground
      is one flat slab that limit is not satisfied, it is meaningless, so each species
      report now carries `ignored_constraints` and a spec can never claim a guarantee
      nothing enforces. Tested that declaring it changes no placement — which is exactly
      why the disclosure is honest.
- [ ] Honour it for real once a terrain field exists (below)
- [ ] Navmesh repair: remove the minimal blocking set, never a landmark
- [ ] Spawn-visibility guarantee (generalising the 500 m → 79 m right-sizing fix)

## E. Inspector

- [x] `stage_artifacts` table, 3 endpoints, `/inspect/<run_id>`, view + edit + download
- [ ] **Step/pause control.** I built *view and edit*, not step-through execution — there
      is no `mode=step` or `advance` endpoint, so the pipeline still runs to completion.
      This is the part you asked for and the part I have not finished.
- [ ] Re-run downstream from an edited stage (edits are stored and flagged; nothing
      consumes them yet)
- [ ] Show concept images and validation screenshots inline
- [ ] Record `expand`/`extract`/`deliberate` once they exist

## F. Learning — wire it, do not rebuild it

`learning/` + `model_router/` already exist: **2,505 lines, 13 governance tables**, no
signal flowing in.

- [ ] Wire what the inspector already captures (spec, verdicts, edits) into
      `TrainingEligibility`
- [ ] **L1 — RAG few-shot.** Works at *tens* of runs. Start here.
- [ ] L2 — rankers over K candidate specs (hundreds of runs)
- [ ] L3 — QLoRA distillation (thousands — do not promise it sooner)
- [ ] L4 — preference pairs from inspector edits
- [ ] **[you]** Consent/DPIA gate before any human-derived training data

## G. Verification, security, CI

- [ ] **⚠ [you] CI run #130 fails and I cannot reproduce it.** Clean venv, fresh Postgres
      16.14, clean checkout, new tests — all pass. Repo is private, `gh` unavailable.
      **Needs the `brain (api + celery hello-job)` job log.** Single blocker on this section.
- [x] **`stage_artifacts` RLS policy** — migration `0014`, same run-scoped shape as its
      siblings, plus a test asserting the whole `generation_runs` family is covered so the
      next table added cannot quietly miss out.
- [ ] **⚠ [you] Every RLS policy is inert: the app role is a superuser.** Found while doing
      the item above. `promptplay` has `rolsuper=t, rolbypassrls=t`, and PostgreSQL exempts
      such roles from every policy — `FORCE ROW LEVEL SECURITY` does not change that.
      Measured: with `app.tenant_id` set to one tenant, an ordinary role sees 1 row and the
      app's superuser sees 2. The policies are correct; the *role* is wrong.
      **Fix is a deployment change** (create a non-superuser service role, grant only what
      it needs, repoint `DATABASE_URL`) — yours to make, and I have not touched your
      credentials. Audit it any time with:
      `RLS_AUDIT_DATABASE_URL=postgresql+psycopg://... pytest -k bypass`
- [ ] Vision critic passing on a real scene — blocked on **B**, since it correctly fails
      grey blobs
- [ ] `combat_template_id` resolves to `frozenset()` — an empty allowlist rejects
      **everything**, on purpose, until templates exist
- [ ] Extension-point conformance tests

## H. Housekeeping

- [x] Docs refreshed — `ARCHITECTURE.md` rewritten, `DEFECTS_AND_DECISIONS.md` added,
      `CHANGELOG.md` + `README.md` updated
- [ ] Delete the stale `fix/golden-game-bias` branch (still present locally *and* on
      origin; its content is superseded) — **ask before deleting** (CLAUDE.md §3.5)
- [ ] ADR for the scope pivot (games → explorable environments) — the largest undocumented
      decision in the project
- [ ] `docs/FINAL_PLAN.md` and `docs/SYSTEM_INSPECTION.md` now overlap `ARCHITECTURE.md`;
      fold or mark superseded

---

## Needs you, not me

| Decision | Why it is yours | My recommendation |
|---|---|---|
| CI #130 job log | private repo, no `gh` | paste the failing job output |
| Mesh model | licence + territory terms | Hunyuan3D-2.1 primary, TRELLIS.2 as ablation arm |
| Player character body | product trade-off | add a CC0 human/robot pack |
| Asset library | scope + cost | a small CC0 nature kit pays for itself in scatter |
| ADR sign-off for the pivot | it changes the frozen v1 scope | write it before P5 |
| DPIA / ethics | required before any user study | start now; it gates F |

## Suggested order

1. **A** — open a project in the editor *(30 min; confirms today's work is real)*
2. **G2** — `stage_artifacts` RLS *(small, security)*
3. **C1** — the `expand` stage *(highest leverage: upstream of most defects)*
4. **B1** — Hunyuan3D-2.1 + PBR *(largest visible improvement)*
5. **E1** — step/pause control *(the inspector feature you actually asked for)*
6. **D** — terrain field and constraint solver
7. **F** — L1 RAG few-shot

`C1` before `B1` deliberately: better meshes on a poorly-reasoned world still give a poorly
reasoned world, and `expand` improves every prompt rather than every asset.
