# Project Overview — PromptPlay 3D & Serendib Engine

**Source of truth:** `ReferenceDocuments/PromptPlay3D_Serendib_Full_Project_Report.pdf` (v4.0, Jul 2026) and the Implementation Checklist PDF. This file is the working summary.

## In simple words

A person types a sentence describing a game ("a foggy abandoned village where I scavenge supplies by day and hide from zombies at night until I can escape by boat"). Minutes later they play that game in the browser: a real 3D world with enemies, objectives, sound, and lighting. They can then download it as a real project and open it in **Serendib Engine**, where the **Serendib Assist** AI dock lets them keep editing by talking to it. The system hands back an **editable game**, never a locked black box.

## Main goal

Prove — academically and as a product — that a custom orchestration **brain** can reliably convert natural-language prompts into **validated, repairable, editable, engine-native** single-player 3D games, using structured multi-agent AI, retrieval of design knowledge, deterministic PCG, safe template-bound scripting, an asset pipeline, layered validation with playtest bots, and hybrid local/cloud model serving.

## North-star vision (team-agreed 2026-07-13 — ADR-0002, ADR-0003)

The long-term objective is broader than games: a **natural-language → 3D experience** platform for **games, education, and visualization alike**. Two agreed principles make this safe to pursue without derailing v1:

1. **Domain-pack platform (ADR-0002).** The engine core is domain-agnostic; "games" is the first *domain pack* (kits + experience-types + templates + validators). Education/visualization become future packs on the same engine — never a rewrite, never unconstrained generation.
2. **Compositional, "thinking-based" uniqueness (ADR-0003).** The LLM's creativity rises to *composition* — reasoning about how to combine vetted parts (richer authored specs now; behavior-graph composition in v2) — so each output is genuinely unique, yet every atom stays a tested template. Free LLM gameplay code is permanently banned; that boundary is what keeps output playable and editable.

**v1 stays frozen on games** to hit the dissertation deadline and prove the reliability thesis once; the broad vision is the explicitly-scoped post-v1 program.

## Three identities at once

1. **Capstone** — a working platform delivered by a 4-member team in 12 months (Jul 2026 – Jun 2027).
2. **Dissertation** — an ablation study (orchestration / repair / RAG / hybrid assembly) + a user study on editability. Novelty claim: *generate a canonical engine specification first, validate and repair it iteratively, and only then materialize a browser build and an editable engine project.*
3. **Future SaaS** — the only system offering the full chain prompt → browser-playable → editable engine-native project in a first-party AI-native engine.

## Who benefits

| Beneficiary | Benefit |
|---|---|
| Students / hobbyists | Playable 3D prototype in minutes; learn by editing a real engine project |
| Educators | Generate teaching artifacts; students dissect and extend specs |
| Designers / prototypers | Concept → testable playable in minutes |
| Research community | Reproducible pipeline + benchmark for editable game generation |
| The team | Defensible product in an unoccupied niche |

## v1 scope (frozen)

- Single-player · browser (WebGL2 Compatibility renderer) · stylized low-poly 3D.
- Genres: `topdown_survival_escape_3d`, `arena_combat_3d`, `collect_explore_3d`, `dungeon_crawl_3d`.
- Cameras: `third_person`, `top_down_3d`, `isometric_3d`.
- One contiguous level · 50–200 props · 5–25 enemies · 3–8 min sessions · ≤90 MB web build.

**Out of scope v1:** multiplayer, open world, first-person (stretch), voice, marketplace, photorealism, deep C++ engine changes, mobile-native export, LLM-authored gameplay code.

**Cut list (drop in this order if time is short):** TTS barks → UniRig characters → day-night → module kit B → threaded web build.

## Core strategy

1. **Golden-game-first:** hand-build one complete browser-playable game before any AI exists; automate backward from a working target.
2. **Ambiguity up / determinism down:** LLMs decide *what* content is needed; deterministic, seeded, testable code decides *how* it is instantiated.

## Success KPIs (targets)

Schema validity >97% · build success >90% · playability pass >95% · repair success >70% · crash-free >95% · prompt fidelity ≥3.8/5 · bundle ≤90 MB · editability ≥4.0/5 · positive continuation intent.
