# Licensing Ledger

The machine-readable ledger is **`docs/licensing_ledger.csv`** — one row per model/asset/tool/library that touches the system. `scripts/check_licenses.py` validates it (CI job from P0).

## Rules

1. **Nothing enters the product path before its license is verified against the primary source** (the actual model card / LICENSE file, not a blog post) and logged.
2. Product path allows: **MIT, Apache-2.0, CC0, OpenRAIL-commercial** (and Stable Audio Open community terms under the revenue threshold — re-check terms at build time).
3. `research_only` components must never appear in a shipped game's lineage.
4. Re-verify licenses when versions change — licenses change between releases.
5. Per-game `credits.json` is generated from this ledger + the game's asset lineage.

## CSV columns

`component, kind (model|asset_pack|library|tool|engine), version, license, license_url, territory_restrictions, commercial_ok (yes|no|conditional), product_path (product|research_only), verified_date, verified_by, notes`

## Current status snapshot (initial — every row must be re-verified at build time)

| Component | License (planned) | Path | Note |
|---|---|---|---|
| Godot 4.x (pinned tag) | MIT | product | Name/logo trademarked → Serendib rebrand mandatory |
| Qwen-family planner ≤32B | Apache-2.0 (verify exact card) | product | Pin exact SKU in week 1; unconfirmed "Qwen3-Coder-14B" must be replaced |
| bge-m3 | MIT | product | |
| TRELLIS.2 | MIT | product | Spike VRAM on 5090 |
| SDXL | OpenRAIL++ | product | |
| FLUX.1-schnell | Apache-2.0 | product | |
| FLUX.1[dev] | Non-commercial | **research_only** | Quarantined |
| Hunyuan3D-2.1 | Excludes UK/EU/Korea | **research_only** | Quarantined |
| Stable Audio Open | Community (revenue threshold) | product (conditional) | Re-check terms |
| Cat's souls-like template SFX | Unlicense (public domain) | product | 13 curated WAVs = enemy activity sounds; Kenney CC0 upstream, no Mixamo. Attribution not required, given anyway |
| LimboAI | MIT | product | GDExtension behavior trees (v1.0+) |
| vLLM, xgrammar, LangGraph, FastAPI, Next.js, Celery, pgvector | Apache/MIT/BSD | product | Standard OSS |
