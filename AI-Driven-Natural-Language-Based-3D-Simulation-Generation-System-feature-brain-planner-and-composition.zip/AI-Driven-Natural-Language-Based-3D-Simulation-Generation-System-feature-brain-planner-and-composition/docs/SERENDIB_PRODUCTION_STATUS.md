# Serendib production implementation status

Last verified: 2026-07-21.

This document separates repository implementation from external qualification.
No external service, model, engine binary or legal review is considered complete
merely because its integration contract exists.

## Implemented and test-verified in this repository

- `/api/v1/simulations` is canonical. It compiles `SimulationSpec` directly and
  no longer passes through `compile_to_legacy_game`, `Game`, `Job`, golden-castle
  corrections or a template game writer. `/games` remains a deprecated adapter.
- CPU planning and build are separate persisted Celery stages. Planning stores
  the immutable spec before the independently retryable build task starts.
- `POST /api/v1/simulations/{id}/revalidate` creates a new quota-governed,
  auditable run against the same immutable spec after runtime or validator
  upgrades. Historical validation evidence is never rewritten. Canonical edit
  runs now reserve and release generation quota as well.
- The neutral asset resolver uses canonical entity IDs, semantic selection,
  measured descriptors and real generation backends when configured. Missing
  structures/vehicles are unresolved instead of being disguised as barrels or
  unrelated proxies.
- Generated concepts pass deterministic alpha/component checks and a
  schema-bound vision critic before 3D lifting. Rejected candidates are removed
  from downstream state, so they cannot be lifted accidentally. Vision is
  fail-closed in production.
- Reusable content-addressed procedural assets provide measured semantic boxes,
  pitched building shells with real doorway voids, and independent hinged door
  leaves. These are capability geometry types, not prompt-specific scene
  templates.
- Seeded semantic PCG uses transformed measured bounds, support, containment,
  clearance, composite hierarchy, approach zones and localized typed repair.
  Hard constraints never silently relax.
- Reviewed capability-state interpreters provide observable interaction state;
  no agent can inject executable scripts into a production world.
- Native Serendib projects include the canonical spec, world plan, fixed runtime,
  navigation probes, canonical render capture, desktop/web exports and a neutral
  Serendib Assist plugin. Assist submits edits to the canonical simulation API
  and never writes an unverified local spec.
- The fixed runtime performs synchronous navigation baking, controlled and
  autonomous locomotion, state-dependent door collision, interaction probes and
  machine-readable logical traces. Browser builds expose the same trace through
  a fixed, non-generated DOM bridge.
- Mandatory runtime, navigation, visual, export and cross-platform validators
  use `PASS`, `FAIL`, `NOT_RUN` or `UNAVAILABLE`; every non-PASS mandatory result
  blocks publication.
- Release checks use one authoritative 18-layer contract. A missing evidence row
  is treated as `NOT_RUN`, including on immutable-spec revalidation, and the
  public artifact API independently requires the same exact layer set.
- Independent text critic and visual critic executors use schema-bound model
  responses. Deterministic evidence remains authoritative.
- Identity, tenant ownership, quotas, audit, OIDC/JWKS, guardian relationships,
  privacy APIs and PostgreSQL RLS migrations are present.
- Training is ineligible by default. Dataset construction and export fail closed
  across consent, guardian consent, rights, moderation, tenant scope, deletion
  tombstones, research exclusions and final validator evidence.
- Governed planner training accepts only neutral `SimulationSpec` rows with an
  immutable manifest. Legacy game data requires a research-only flag that the
  production worker never uses.
- Completed trainer artifacts bind model digests. Promotion metrics must arrive
  as signed immutable `ModelEvaluation` evidence; admins cannot type arbitrary
  passing metrics into a promotion request.
- Tenant-private/global deployment routing, deterministic 5%/25% canaries,
  rollback, and real planner request routing are implemented. Trained asset and
  placement rankers load from digest-verified JSON and can order only hard-valid
  candidates.
- Production dataset/model copies support streaming AES-GCM envelope encryption
  with managed KMS data keys; plaintext training work is constrained to tmpfs.
- The canonical pipeline unloads the routed Ollama planner before real asset
  generation and releases in-process SDXL/TripoSR state afterwards, preventing
  cross-stage GPU memory starvation.
- Python wheels now contain every runtime package. Separate API, engine-worker
  and governed GPU-training Dockerfiles and Kubernetes worker/KEDA templates are
  present.
- Serendib identity assets, upstream patch series, legal attribution checks,
  runtime splash/icon/browser checks and a neutral editor plugin are present.

## Verification completed locally

- Full brain non-benchmark and worker test suites passed on 2026-07-21; four
  worker tests requiring optional external tools were skipped.
- Contract compilation and contract examples passed.
- Targeted Ruff checks for the neutral planner, PCG, asset, project writer,
  runtime probe, model critic and native pipeline passed.
- Repository diff whitespace checks passed.
- Licence policy passed, with eight existing ledger components still warning
  that their primary-source verification dates are absent.
- Governed encryption round-trip and tamper detection passed.
- Brain and worker wheels built successfully and were inspected for the formerly
  missing packages.
- Using the installed Godot 4.7 development binary, canonical run
  `run_0a7fbd3644f8487987253c1fd6902160` completed with all 18 mandatory layers
  `PASS`: spec/traceability, capabilities, measured assets, behavior, placement,
  native compilation, runtime interactions, navigation, Web import/export,
  independent critic, six single-subject visual checks, lineage, parity and
  publication.
- The run published a gated Web build and editable project archive. Both
  artifact URLs returned HTTP 200; the archive was 1,549,182 bytes.
- A real 41,646,562-byte Web export executed in installed Chrome and published a
  passing runtime trace. Native-project/Web logical state and interaction parity
  passed.
- Windows desktop export was attempted and failed truthfully because
  `windows_debug_x86_64.exe` and `windows_release_x86_64.exe` are absent from the
  installed export templates. Only Web templates are installed.

This is development evidence, not a release artifact: the available binary is
official Godot 4.7, while production requires the pinned, visibly rebranded,
signed Serendib 4.6.3 binary and matching Web/desktop templates.

The live Qwen planning call for the source run was schema-valid but took 238
seconds on the local workstation. Correctness is qualified for this slice;
planner latency and independent production model deployment are not.

## Repository work still remaining

- Split asset generation, engine compilation and validation into separate
  persisted queue stages. Today they are isolated from planning but still share
  the build task and its retry boundary.
- Add a durable stage-artifact exchange for those future queues (private object
  storage plus hashes), rather than relying on a shared worker volume.
- Add automated shadow inference comparison. Live canary/production routing is
  implemented, but a shadow deployment record does not yet duplicate requests
  asynchronously for comparison.
- Add automated canary metric aggregation and timed rollback. Signed canary
  evaluation and rollback gates exist; collecting the observation window is an
  operations integration.
- Add an approved decrypt-to-tmpfs deployment component for encrypted ranker and
  enterprise-adapter artifacts. The training side is encrypted; serving requires
  the target model platform/KMS choice.
- Add the deadline scheduler that retrains or retires quarantined private/global
  derivatives within the applicable deletion window. Withdrawal already removes
  dataset copies, writes tombstones, disables deployments and quarantines models.
- Expand semantic capability packs beyond the initial locomotion, animal,
  openable/lockable, pickup, sittable, dialogue, vehicle, machine, weather and
  sensor primitives as research domains are selected.
- Build region-specific Terraform/Helm overlays after the cloud, GPU provider,
  managed KMS and model-serving platform are chosen.

## Actions and evidence required from the owner/operator

1. Build the pinned upstream engine with the Serendib patch series and matching
   web/desktop export templates. Supply `GODOT_BIN` and
   `SERENDIB_BIN_HOST_PATH`; run engine launch, screenshot, export and parity
   qualification on Windows/Linux and target browsers.
2. Supply or license a real asset library for buildings, vehicles, machines,
   rigged characters and animations. Configure and capacity-test the approved
   3D generation backend. The dog-village slice now has safe measured procedural
   structures and curated animated animals, but arbitrary-domain prompts still
   fail when neither a qualified asset nor a declared procedural capability
   exists.
3. Choose and deploy independent planner, critic and vision models. Record exact
   licences and immutable digests, provide endpoints, then run the frozen
   semantic benchmark. Critic and vision roles must not silently share the
   planner artifact.
4. Choose cloud regions, managed PostgreSQL/Redis, private object storage,
   managed KMS and an OIDC provider. Create secrets outside Git and replace every
   image placeholder with a signed digest.
5. Obtain verified KMS keys, mount `/run/serendib-training` as tmpfs, build the
   GPU training image from a signed CUDA/PyTorch base, and verify the exact base
   model licence before enabling either training switch.
6. Collect at least 500 eligible high-quality examples (or approve the monthly
   window), then execute planner/ranker training, privacy extraction tests,
   frozen evaluation, shadow, 5% canary, 25% canary and rollback exercises.
7. Complete DPIA, child-safety/age-assurance assessment, transfer/retention
   review, copyright and trademark review, regional counsel sign-off, child-
   readable notices and rights/takedown operations.
8. Execute PostgreSQL non-owner RLS tests, 100-concurrent-job load and fairness
   tests, backup restore/DR exercises, cross-tenant storage tests, SBOM/signature
   verification and an external penetration test with no open critical issue.
9. Assign on-call owners, incident severities, alert destinations, cost limits
   and model owners. Run breach, rollback and unavailable-validator exercises.

Until all applicable external gates pass, production configuration must remain
disabled. Missing mandatory evidence correctly produces a failed run and no
user-facing final artifact.
