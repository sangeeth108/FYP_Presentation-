# Generation Pipeline (S0–S8)

Every job flows through nine stages. Only S0–S2 (and generation inside S5) involve AI; the rest is deterministic code, engine build, or validation gates. Failures are classified (schema / asset / build / logic / quality) and repaired by re-invoking **only the responsible node**, ≤3 attempts per class, with monotonic-progress checks.

---

### S0 — Prompt intake & safety/scope check
- **Input:** raw user prompt, options (camera, genre?, seed?), budgets.
- **Output:** accepted job (QUEUED) or friendly rejection with reason.
- **AI or deterministic:** AI safety/scope classifier + deterministic allowlist rules.
- **Files:** `services/brain/api/` (endpoint), `services/brain/agents/prompt_analyzer` (S0/S1 share it).
- **Failure modes:** unsafe content, out-of-scope request (multiplayer, photorealism...), ambiguous prompt.
- **Repair:** none — reject with explanation and suggestions; never silently proceed.
- **Tests:** fixture prompts (safe/unsafe/out-of-scope/ambiguous) → expected verdicts.

### S1 — Intent parsing → structured brief
- **Input:** accepted prompt.
- **Output:** normalized intent JSON: genre, biome, mood, entities, player_verbs, constraints.
- **AI:** guided JSON (xgrammar) against the brief sub-schema.
- **Files:** `services/brain/agents/prompt_analyzer`, `contracts/` brief schema.
- **Failure modes:** wrong genre classification, hallucinated entities.
- **Repair:** re-invoke analyzer with validator feedback (≤3).
- **Tests:** 20 fixture prompts → expected genre/biome fields.

### S2 — Game spec planning (agents + RAG)
- **Input:** structured brief.
- **Output:** full canonical `game_spec` (frozen after arbitration).
- **AI:** agent chain (Designer, World, Mechanics, Asset, Anim+Audio) each emitting partial JSON patches via guided decoding; RAG (bge-m3 + pgvector) supplies design-pattern notes; registries enforce ID allowlists.
- **Files:** `services/brain/agents/`, `services/brain/orchestrator/` (LangGraph graph + arbiter), `services/brain/knowledge/`.
- **Failure modes:** conflicting fields, invented template/kit IDs, unwinnable rules, over-scope.
- **Repair:** arbiter resolves conflicts by priority stack; invented IDs impossible by construction (allowlist); logic issues → re-invoke the owning agent.
- **Tests:** agent fixtures → schema-valid patches; arbiter merge cases; allowlist enforcement test.

### S3 — Schema validation
- **Input:** frozen spec.
- **Output:** pass, or machine-readable error objects `{code, path, message, hint}`.
- **Deterministic.**
- **Files:** `services/brain/contracts/` (validator), `contracts/game_spec.schema.json`, `scripts/validate_contracts.py`.
- **Failure modes:** structural violation (rare — guided decoding), cross-field semantic violations (camera/genre/kit compatibility).
- **Repair:** localized patch by Repair agent on the failing path only.
- **Tests:** valid + deliberately broken fixture specs → exact error objects.

### S4 — Deterministic PCG & level graph
- **Input:** spec (world params, seed).
- **Output:** zone graph with guaranteed critical path + materialization plan (GridMap cells, elevation, ramps) + placement plan.
- **Deterministic** (seeded BSP / room-corridor / cellular caves / WFC dressing).
- **Files:** `services/brain/pcg/`.
- **Failure modes:** disconnected zones, unreachable objective, spawn-in-wall.
- **Repair:** re-run with adjusted params (same seed family); connectivity validator gates it.
- **Tests:** same seed → identical graph (byte-equal); connectivity property tests across 100 seeds.

### S5 — Asset resolution
- **Input:** asset briefs from spec.
- **Output:** concrete asset files (GLB/textures/audio) + cache records + license refs.
- **Mixed:** deterministic decision tree (cache ≥0.92 → curated ≥0.85 → generate → QA → curated fallback); generation itself is AI (SDXL → TRELLIS.2 → Blender headless; Stable Audio Open for SFX).
- **Files:** `services/worker/asset_farm/`, `content/`.
- **Failure modes:** non-manifold mesh, budget overrun, style drift, model OOM.
- **Repair:** one regeneration attempt → curated substitute (build never blocks).
- **Tests:** decision-tree unit tests; QA-gate tests with known-bad meshes; budget enforcement.

### S6 — Serendib project assembly
- **Input:** spec + PCG plans + resolved assets.
- **Output:** complete Godot/Serendib project (scenes, template-bound scripts, export presets), PascalCase-named nodes.
- **Deterministic** (project writer instantiates vetted templates with spec parameters).
- **Files:** `services/worker/godot_client/`, `engine/templates/`.
- **Failure modes:** missing template param, broken scene reference, import failure.
- **Repair:** parameter-level fix from validator feedback; template registry prevents unknown IDs upstream.
- **Tests:** golden-game spec → byte-stable project; each template has its own scene-level test.

### S7 — Headless export & validation
- **Input:** assembled project.
- **Output:** web build (≤90 MB) + editable project zip + validation verdicts.
- **Deterministic** (Godot headless export + 8-gate stack + playtest bots reading state via debug singleton).
- **Files:** `services/worker/godot_client/`, `services/worker/validators/`, `services/worker/bots/`.
- **Failure modes:** export non-zero exit, budget exceeded, bot cannot complete, fall-through/stuck anomalies.
- **Repair:** classify → route to responsible node (assets → S5, layout → S4, rules → S2 Mechanics).
- **Tests:** golden game passes all 8 gates in CI; deliberately broken builds produce correct classifications.

### S8 — Publish & lineage
- **Input:** validated artifacts.
- **Output:** R2 uploads, `/play` URL, signed download URL, `credits.json`, complete lineage record (prompt, seeds, model digests, spec hash, build hash).
- **Deterministic.**
- **Files:** `services/worker/` (uploader), `services/brain/services/` (URLs, lineage), `content/credits/`.
- **Failure modes:** upload failure, missing lineage field, missing license ref.
- **Repair:** retry with backoff; lineage gate blocks DEPLOYED until complete.
- **Tests:** lineage completeness check; re-generation from lineage reproduces the build hash.

---

## The 8-gate validation stack (run in this order — cheapest first)

1. **Schema gate** — valid JSON Schema 2020-12 (guaranteed by guided decoding).
2. **Constraint gate** — camera/genre/kit/animation compatibility.
3. **Asset QA gate** — manifold, budgets, CLIP similarity, style, audio loudness.
4. **Import/export gate** — Godot imports cleanly; exports exit 0; build ≤90 MB.
5. **Static playability gate** — navmesh path spawn→objective; lock-key solvable; timer plausible.
6. **Dynamic gate** — ≥1 playtest bot completes; no fall-through/stuck anomalies.
7. **Quality gate** — critic rubric on prompt fidelity + style consistency.
8. **Lineage gate** — prompt, seeds, model digests, hashes all recorded.
