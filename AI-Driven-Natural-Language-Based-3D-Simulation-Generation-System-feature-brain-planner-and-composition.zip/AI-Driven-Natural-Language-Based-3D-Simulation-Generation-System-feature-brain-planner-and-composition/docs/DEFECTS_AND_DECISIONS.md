# Defects and Wrong Decisions — an evidence record

**Purpose.** A dissertation needs to report what failed, not only what shipped. This file
records every wrong decision and defect found in Serendib, what it actually cost in
measured terms, how it was found, and what general lesson it supports. It is written to be
cited: each entry has numbers, a mechanism, and a commit.

Compiled 2026-07-31 at `c164c1d`. Companion: [`ARCHITECTURE.md`](ARCHITECTURE.md),
[`BUILD_CHECKLIST.md`](BUILD_CHECKLIST.md).

**A note on method.** Several entries below were found only because a result was checked
against reality instead of accepted. Three were found because a *single* passing example was
distrusted and re-tested at n=10. That pattern — the anecdote that agrees with you is the
most dangerous evidence in the project — is the strongest methodological finding here.

---

## Summary table

| # | Wrong decision / defect | Measured cost | Class |
|---|---|---|---|
| 1 | Golden-game spec used as the generation base | every world inherited a castle demo | anchoring |
| 2 | Scatter never rendered, then blocked the build | 1,949 planned instances → 0 visible; build failed outright | integration gap |
| 3 | Skeleton shipped for every unmatched character | 100% of unmatched characters | wrong predicate |
| 4 | Numeric ranges left to guided decoding | **2 of 10 prompts** lost entirely | grammar limits |
| 5 | `size_m` optional | **10 of 10 species** omitted it; 25 m tree → 1.5 m | optional ≠ supplied |
| 6 | One LLM call for the whole spec | root cause of #4 and #5 | missing reasoning stage |
| 7 | Seed stored unsigned in a signed column | **~50% of all prompts** failed | type boundary |
| 8 | World extent taken from the model | 500×500 m for 13 objects; spawn 276 m from content | unbounded trust |
| 9 | Per-species instance cap applied before scaling | 120,000 instances; density mix destroyed | order of operations |
| 10 | Capability gate ignored runtime bindings | 9 of 13 capabilities blocked; 6 needlessly | fail-closed too early |
| 11 | Verifying with one favourable example | hid #4 and #5 | evaluation design |
| 12 | Work left uncommitted across reverts | 6 fixes lost, re-done | process |
| 13 | Commits split without independent verification | 1 non-runnable commit | process |
| 14 | Licence rule applied to a research project | delayed the best mesh model | misapplied constraint |
| 15 | Fixed biome/archetype fallback lists | the golden-game error at finer grain | anchoring (repeat) |
| 16 | ⚠ **Every RLS policy is inert** — the app role is a superuser | 30+ policies enforce nothing | security theatre |
| 17 | Scatter instances placed at ground level, mesh centred | 100% half-buried; 25 m tree showed 12.5 m | pivot convention |
| 18 | A brief made the planner enumerate instead of abstract | **4 of 10 worlds lost all scatter** | shape copying |
| 19 | `uniqueItems` left to guided decoding | 1 of 10 prompts lost entirely | grammar limits (repeat of #4) |
| 20 | Zero-density species kept and their meshes generated | wasted GPU on invisible species | clamp side-effect |
| 21 | Three contract bounds punished accurate answers | density 200, world 20 m, height 5 m | conservative guesses |

---

## 1. The golden game became the base of every world

**Decision.** `golden_game.spec.json` — a complete castle demo — was used as the starting
point the planner edited.

**Cost.** Every generated world inherited castle entities, castle zones and castle
proportions regardless of prompt. A test encoded the bias explicitly:
`expected_entities = 5 + len(golden["entities"]["props"])`.

**Fix.** A deterministic `blank_spec()` derived from the prompt. 9 tests added, including
one asserting no example-game identifier can reach a generated spec.

**Lesson.** A rich example is the most attractive possible starting point and the most
dangerous. Few-shot anchoring at the *artefact* level is not few-shot learning; it is
copying. This recurs as #15.

---

## 2. Scatter reached the plan but never the scene — then failed the build

**Defect.** The scatter layer was built end to end in the brain: contract, seeded
instancer, budget, asset resolution. The project writer had **no scatter handling at all**.

Verified by absence:
```
grep -n scatter services/worker/godot_client/*.py   → nothing
grep -n MultiMesh  services/worker/godot_client/*.py → nothing
```

**Then it got worse.** A plan carrying scatter declares WorldPlan `1.1.0`; the writer
accepted only `1.0.0`. So the moment the instancer produced anything, native compilation
failed at `world_plan_version_unsupported`. The feature did not merely fail to appear — it
**broke worlds that used it**.

**Cost.** 1,949 planned instances → 0 rendered; any scatter-bearing world unbuildable.

**Fix** (`3309f72`, `4c1d8ef`). Accept 1.1.0; add `scatter_field.gd`; one
`MultiMeshInstance3D` per species reading transforms from `world_plan.json`.

**Measured after:** 1,949 instances → **2 nodes**, `main.tscn` **2,817 bytes**.

**Lesson.** A feature is not done when its data is correct. Every producer needs a named
consumer, and "the data is in the plan" is not a delivery. The version bump made a
missing consumer *destructive* rather than merely absent — additive changes are only safe
when every consumer accepts the new version first.

---

## 3. Every unmatched character shipped as a skeleton

**First diagnosis — wrong.** Recorded in the checklist as *"raise the curated-match
similarity threshold."* That would have changed nothing.

**Actual mechanism.** The shipping policy asked *"is the asset being DISPLACED animated?"*
The curated library contains **4 characters, all skeletons**, all rigged. So every
character the matcher could not place appeared to be displacing motion, its generated body
was rejected as "not rigged", and `Skeleton_Warrior` shipped — in a jungle, a museum, a
hospital.

**Cost.** 100% of unmatched characters. Planning and generation both produced the right
answer; it was discarded at the last step.

**Fix** (`d58dcd3`). Condition on the entity's own `requires_animation`, which the manifest
already carried and nothing read. A missing flag reads as "needs motion", so nothing
silently loosens. Swaps now emit a machine-readable `substitution` record.

**Lesson.** Two lessons. First: *the predicate was about the wrong object* — a property of
the replacement was used to decide something about the replaced. Second: **the first
diagnosis was confidently wrong and written into a planning document.** Diagnosis before
reading the code is a guess wearing a plan's clothing.

---

## 4. Numeric ranges cannot be enforced by guided decoding

**Wrong assumption.** That guided JSON decoding enforces the schema. It enforces
*structure* — shape, types, required fields, enums. It cannot enforce `minimum` /
`maximum`, because a numeric range is not expressible in a context-free grammar.

**Cost — measured at n=10.** Ten varied prompts; **2 fell back** to the deterministic empty
world:

| Prompt | Field | Value | Bound |
|---|---|---|---|
| Mars research base | `scatter[0].density_per_100m2` | 10000 | max 200 |
| Rooftop garden | `environment.dimensions_m.depth` | 15 | min 20 |

**A 20% total-loss rate**, and the failure mode is the worst possible one: not a degraded
world, but a *generic* one, identical for every prompt.

The rooftop case is instructive: **15 m is a correct answer for a roof.** The schema's 20 m
floor is the thing that is wrong, and the model was punished for being more sensible than
the contract.

**History of the same bug.** It had been patched one field at a time — seed overflow (#7),
then a 500 m entity bbox (#8) — and each patch left every other bounded field exposed.

**Fix** (`c164c1d`). One schema-driven clamp: walk the candidate against the canonical
schema, resolve `$ref`s, bound every number, round integers *into* the range. Any bounded
field added later is covered with no new code. Disclosed as a user-visible approximation.

**Measured after:** both prompts plan on the LLM path (Mars 0 → 5 species, rooftop 0 → 6).

**Lesson.** Know precisely what your constraint mechanism guarantees. "Schema-constrained
generation" sounds total and is not. Fix the class, not the instance — three instance fixes
cost more than the general one and left the exposure intact.

---

## 5. Optional fields are not supplied

**Decision.** `size_m` on a scatter species was optional, with the requirement stated in
the prompt instead.

**Cost — measured.** A live 27B run on a rainforest prompt omitted `size_m` on **10 of 10
species**. Consequence chain: asset farm falls back to `[1.0, 1.5, 1.0]` → the descriptor
normalises the generated mesh to that → **a 25 m teak and a 0.15 m mushroom ship the same
size**.

**Fix** (`b407f2a`). Marked `required`. Guided decoding *does* enforce required fields, so
this is a hard guarantee rather than a request.

**Measured after:** same prompt, sizes from **0.1 m** (moss) to **25.0 m** (teak), a 250×
spread.

**Lesson.** An instruction in a prompt is a hope; a required field is a constraint. Put the
requirement in the mechanism that enforces it. Note this cuts against #4 — the same schema
is authoritative for `required` and powerless for `maximum`, and knowing which is which is
the whole skill.

---

## 6. One LLM call does everything (root cause)

**Decision.** `plan_simulation` sends the prompt and receives the entire `SimulationSpec` —
environment, entities, capabilities, requirements, scatter species, densities, sizes — in a
single guided-JSON response.

**Declared but not built.** `stages.py` names nine stages; `expand`, `extract` and
`deliberate` are names with nothing behind them. **4 of 9 implemented.**

**Cost.** This is the *upstream cause* of #4 and #5. A 27B model doing intake, design,
sizing, density and capability selection in one pass has nowhere to reason before it must
be precise. `density_per_100m2: 10000` is what "how many boulders on Mars?" looks like when
nobody ever asked the question separately.

**Status.** Not fixed. The clamp in #4 makes these failures survivable; it does not make the
numbers good.

**Lesson.** Robustness patches downstream of a missing reasoning stage treat symptoms. The
literature (3D-GPT's conceptualization agent; Holodeck) separates *conceive* from
*formalise* for exactly this reason.

---

## 7. Seed stored unsigned in a signed column

**Defect.** The seed came from the first 8 hex digits of `sha256(prompt)` — a 32-bit
**unsigned** value — while `simulations.seed` is a signed 32-bit `INTEGER`.

**Cost.** Any prompt hashing ≥ `0x80000000` — **roughly half of all prompts** — failed at
creation with `DataError: integer out of range`. `"Explore a lush jungle..."` hashed to
3,943,104,326 and could never be generated.

**Misdiagnosed first as a CORS error.** The browser reported "No 'Access-Control-Allow-Origin'
header" because the 500 response bypassed the CORS middleware entirely. Time was spent on
CORS configuration before the real cause was found.

**Fix.** Mask with `& 0x7FFFFFFF`.

**Lesson.** A 50%-failure bug hid behind a plausible wrong symptom for as long as the
symptom was believed. When an error message points at infrastructure, check whether the
error *path* can even produce that message.

---

## 8. The world was whatever size the model said

**Defect.** `environment.dimensions_m` was used verbatim. The planner routinely asked for
500×500 m to hold a handful of objects.

**Cost — measured.** A run with 13 entities produced a 250,000 m² world; the player spawned
**276 m** from the only building and **353 m** from the machine. The opening view was empty
ground, and the visual-semantic critic correctly failed the world as showing *"no
identifiable objects"*.

**Fix.** `_content_scaled_dimensions()` derives extent from declared entity footprints and
only ever *reduces*, never grows — so a deliberately small world stays small.
**Measured: 500×500 m → 79.3×79.3 m.**

**Lesson.** An LLM's numbers are intent, not measurement. Sizes must be derived from
content wherever content exists.

---

## 9. Instance budget applied in the wrong order (twice)

**Defect, attempt 1.** A per-species cap applied *before* global scaling flattened the mix:
six species with densities from 4.5 to 15 all clipped to the same number, destroying the
proportions the planner intended.

**Defect, attempt 2.** A ceiling applied *after* scaling clipped the densest species: a
3.33× density ratio came out as **2.17×**.

**Cost.** A real run wanted **120,000 instances** (6 species × a 20,000 default) — more than
any ≤90 MB web build can carry.

**Fix.** Compute what every species wants, scale the whole set proportionally to the 12,000
budget, apply no per-species ceiling afterwards. If the planner wants a world that is mostly
ferns, that is a legitimate design choice.

**Both attempts were caught by tests, not by inspection.**

**Lesson.** Budget enforcement and proportion preservation are separate concerns and their
order is load-bearing. Property tests ("the density ratio survives") catch what
example tests ("the total is under budget") cannot.

---

## 10. The capability gate ignored runtime bindings

**Defect.** A capability whose registry `status != "supported"` was rejected even when it
carried a working `runtime_binding`.

**Cost — counted from the registry when this defect was found.** Of 13
capabilities, only 4 were `supported` (`locomotion`, `camera_control`, `openable`,
`lockable`). Six more were `partial` **but carried a working runtime binding**
(`animal`, `machine`, `pickup_carry_drop`, `sensor_trigger`, `time_weather`,
`vehicle`); three were genuinely unbound (`dialogue`, `ecosystem_process`,
`sittable`).

> **As of 2026-08-19** the registry reads 6 `supported`, 6 `partial`, and one
> genuinely unbound (`ecosystem_process`). Six capabilities were bound to real
> runtime behaviour in the meantime: `sittable` and `pickup_carry_drop` are now
> `supported`, while `machine`, `sensor_trigger`, `vehicle` and `dialogue` are
> `partial` with limitations that name what is actually missing. See the
> 2026-08-19 entries in `CHANGELOG.md`. The counts above are left as they were,
> because they are the measurement that justified the fix.

The gate rejected everything not `supported`, so **9 of 13 were blocked and 6 of those
were blocked needlessly** — every capability the runtime could actually perform beyond
doors and walking. That silently constrained every world the system could express: an
`ecosystem_process` gap still appears on rainforest and Mars prompts today, correctly,
because that one really is unbound.

**Fix.** A bound capability qualifies as `PASS_WITH_LIMITATIONS`; only an *unbound* one
fails closed.

**Lesson.** Fail-closed is correct, but the predicate must be "can the runtime do this?",
not "has someone marked this supported?". Registry metadata drifted from runtime reality
and the gate believed the metadata.

---

## 11. Verifying a feature with one favourable example

**Wrong decision.** Scatter, `size_m` and prompt compliance were all verified with a
**jungle** prompt — the single most favourable case for a vegetation-scatter feature.

**Cost.** Two defects (#4, #5) survived verification and would have shipped. The
one-prompt check reported success on both.

**Corrected method.** 10 deliberately varied prompts — car factory, art museum, coral reef,
Mars base, medieval market, flooded subway, rooftop garden, desert canyon, hospital ward,
snowy forest — scored on: LLM vs fallback, placeholder echo, species count, `size_m`
presence, **size spread ratio**, generic-type count, id canonicality.

The spread ratio matters: a planner can satisfy `required` by emitting `[1,1,1]` for every
species. Presence is not sufficiency. Observed ratios ran **2.2× to 1200×**.

**Result: 2 of 10 total losses**, invisible at n=1.

**Lesson.** Choose test cases that are *hostile* to the feature. Testing vegetation scatter
with a rainforest is testing a spellchecker with a word you know it can spell. This is the
most transferable finding in this document.

---

## 12. Work left uncommitted across reverts

**Cost.** Six independent fixes were lost and had to be re-derived: capability gating, seed
overflow, CSP script externalisation, CSP `blob:` icon, the probe-quit bug, and world
right-sizing. Two of them (capability gating, seed overflow) were lost **twice**.

**Lesson.** Uncommitted work is not work. Commit frequency should track *risk of loss*, not
perceived completeness.

---

## 13. Commits split without verifying each independently

**Defect.** A logical split produced commit `8fc0f28` containing a *caller* of
`unload_models` but not the *function*, which arrived later in `0bd5d55`. The commit could
not run.

**Fix then.** A `try/except ImportError` guard. **Fix now:** each commit in this session was
verified in isolation — `git stash -u`, run the full suite, `git stash pop`.

Related: a test-environment leak caused a suite to take **71 minutes** with real SDXL
instead of **66 seconds** clean, because one commit's `conftest.py` did not pin the mock
backend that `main`'s did.

**Lesson.** "Logically separate" is not "independently valid". If commits are split for
reviewability, each must build and pass on its own or the history lies.

---

## 14. A product licence rule applied to a research project

**Wrong decision.** `CLAUDE.md` §14 restricts the *product path* to
MIT/Apache/OpenRAIL-commercial, quarantining Hunyuan3D-2.1 and FLUX.1[dev]. This was
applied to a **research** project where it does not bind.

**Cost.** The best available mesh model was excluded from consideration. Meanwhile the
model actually in use, TripoSR, produces measured **mean saturation 5/255** — grey blobs,
~120k triangles of slivers — which the vision critic correctly rejects.

**Correction.** User direction: *"why not use Hunyuan3D 2.1. you can use freely any
suitable models."* Research and product paths need separate licence policies.

**Lesson.** A constraint inherited from one context must be re-justified in another. Rules
in a project document are not automatically in force for every activity in the project.

---

## 15. Fixed biome and archetype fallback lists

**Wrong decision.** A biome-archetype fallback table was proposed so unknown environments
had sensible defaults.

**User correction.** *"why you think like this. this is a system. i gave jungle prompt as an
example. user can give many prompt types."*

**Why it was wrong.** It is defect #1 at finer granularity. A fixed list of biomes is a
golden game per biome: it works for the enumerated cases and silently produces the wrong
world for everything else — while *looking* like it worked, which is worse than failing.

**Lesson.** In an open-vocabulary system, any enumeration is a ceiling. The correct fallback
is a *mechanism* (decompose, retry, degrade, disclose), never a *list*.

---

## 16. ⚠ Every row-level security policy is currently inert

**Found while** adding the missing `stage_artifacts` policy (a small, self-contained task).

**Defect.** Migrations 0009–0014 install more than thirty tenant policies. The application
connects as the `promptplay` role, which is a **superuser with BYPASSRLS**. PostgreSQL
exempts such roles from every policy, so none of them enforce anything.

**Measured on the development stack**, same table, same policy, `app.tenant_id` set to one
tenant:

| Role | `app.tenant_id` | Rows visible |
|---|---|---|
| ordinary role | `tenant_a` | **1** — correct |
| ordinary role | unset | **0** — fails closed, correct |
| **superuser (the app)** | `tenant_a` | **2** — both tenants |

`ALTER TABLE ... FORCE ROW LEVEL SECURITY` does **not** fix this. `FORCE` extends
enforcement to the table *owner*; superusers and `BYPASSRLS` roles are exempt regardless.
Verified directly: with `FORCE` applied, the superuser still saw both rows.

**Why it survived.** The only existing test read the migration *file* and asserted the
table names appeared in it. That assertion passes against a database with no policies at
all, and passed here for months. It tested that we had written SQL, not that the SQL did
anything.

**Status.** The policies themselves are correct — proven above against an ordinary role.
The fix is a deployment change (create a non-superuser service role, grant only what it
needs, repoint `DATABASE_URL`), which is the operator's call and is **not applied**. An
audit test now states the requirement and fails loudly against any environment where it
does not hold:

```
RLS_AUDIT_DATABASE_URL=postgresql+psycopg://... pytest -k bypass
```

It deliberately does not key on `DATABASE_URL`, because `conftest.py` overwrites that with
SQLite for every test — a check keyed on it could never run while appearing to.

**Lesson.** A control you have not *observed blocking something* is not a control. This is
F1 again in a security setting: the migration file agreed with us, so nobody asked the
database.

---

## 17. Scatter instances were buried in the ground

**Defect.** The instancer emits a point *on* the ground (`position_m.y = 0`). A `BoxMesh`
is modelled *centred* on its origin. Placing instances at the planned point therefore sank
half of every one: a 25 m teak showed 12.5 m, and 0.8 m ferns read as flat slabs lying in
the dirt.

**Cost.** 100% of scatter instances, in every world.

**Why every test passed.** The transforms were *exactly* what the plan specified. The unit
tests asserted the writer emitted the planned values, and it did. The defect lived in the
gap between "the number is right" and "the object is in the right place".

**Found by** running a generated project in Godot 4.7 and looking at it — the one
checklist item that needed an engine rather than an assertion.

**A false lead worth recording.** The first probe ran headless and showed every instance
origin as `(0,0,0)`, which looked like proof the transforms never arrived. It was not:
Godot's dummy renderer never allocates the MultiMesh buffer, so `get_instance_transform`
returns identity for every index. Confirmed by round-tripping a hand-built MultiMesh with
known values `(11,22,33)` — also read back as identity, `buffer_size=0`. Establishing that
first prevented "fixing" a bug that did not exist while missing the one that did.

**Fix** (`0f6348e`). Lift each instance by its mesh's own lowest extent, scaled by that
instance's jittered scale — correct for a centred primitive, a no-op for a glTF authored
base-at-origin, so better assets need no special case.

**Lesson.** Data-level tests cannot see convention mismatches. Two components can both be
correct about a number and still disagree about what it means.

---

## 18-21. What building the expand stage exposed

The expand stage (prompt → prose → spec) is defect #6's fix. Building it produced four
findings, three of them only visible because the stage was **measured rather than
admired**.

### The ablation

Ten varied prompts, identical seeds, one flag apart. First run:

| metric | baseline | +expand | |
|---|---:|---:|---|
| **worlds with ZERO scatter** | **0** | **4** | worse |
| fell back to the empty world | 0 | 1 | worse |
| mean scatter species | 5.40 | 2.80 | worse |
| mean entities | 4.30 | 8.80 | — |

**The stage made the system worse.** The expansions read beautifully — Sinharaja,
*Mesua ferrea*, measurements throughout — and judging by that would have shipped a
regression in the single property the scatter layer exists to provide.

### 18. A brief makes the planner enumerate instead of abstract

Prose describes things one at a time because it has no other way to. The planner copied
that shape rather than the content. Real output: `ent_apple_core_01`,
`ent_broken_pottery_01`, and straw as a `static_debris` **entity**. The medieval market
went from 3 entities / 5 species to **12 entities / 0 species**.

**Fix.** The planner is told explicitly that a described thing is not automatically an
entity: anything occurring in quantity is one species with a density, however lovingly the
brief describes a single one of them, and *a place with no scatter is a bug*.

### 19. `uniqueItems` is unenforceable by a grammar

`["camera_control", "locomotion", "camera_control"]` cost a coral reef its entire world. A
grammar can emit enum values but has no memory of which it already used — the same class
as #4, discovered the same way, one prompt of ten lost. Deduped schema-wide, order
preserved.

### 20. Zero-density species were kept, and their meshes built

Expanded runs emitted `density_per_100m2: 0`. The range clamp from #4 then lifted 0 to the
exclusive minimum, **preserving a species that can never place an instance while still
paying to generate its mesh** — a fix creating waste downstream of itself. Zero of a kind
is the same statement as not naming the kind, so those species are now dropped.

### 21. Three contract bounds punished accurate answers

| Bound | Was | Reality | Now |
|---|---|---|---|
| `density_per_100m2` max | 200 (= 2/m²) | a fern mat whose fronds touch is ~400 | 5000 |
| world `width`/`depth` min | 20 m | a museum gallery is 8 m across | 8 m |
| `max_height` min | 5 m | a hospital corridor is 2.7 m | 2.5 m |

Nothing about physical plausibility rested on any of them: spacing comes from the measured
footprint, total cost from the instance budget, and placement only ever *reduces* a
declared extent. They were conservative guesses that became visible only once the model
started being right.

### After the fixes

| metric | baseline | +expand | |
|---|---:|---:|---|
| fell back to the empty world | 0 | **0** | fixed |
| worlds with ZERO scatter | 0 | **0** | fixed |
| mean scatter species | 5.10 | 5.00 | parity |
| mean entities | 4.30 | 14.10 | **unproven** |

Parity on the count hides a real quality gain the aggregate could not see. Medieval market
species, baseline vs expanded:

- baseline: `cobblestone_paving@600`, `straw_bales@15`, **`smoke_particles@5`** — scattering
  smoke as meshes
- expanded: `straw_litter@400`, `apple_cores@50`, `pottery_shards@30`, `cabbage_heads@25`

**What is not claimed.** Entity count tripled, and the market emitted
`ent_market_stall_01`…`_08` — eight numbered copies of one kind. That is richer *and*
costs more asset generation and constraint solving. There is no evidence it is better, so
it is not recorded as an improvement.

**Lesson.** A generation stage must be judged on the artefact it produces, never on how
good its own output reads. The expansions were the most impressive text the system has
ever produced and the worlds got worse.

---

## 22-24. Concluding a Working Component Was Broken

The deliberation stage was measured as returning `sound` on all ten prompts and
detecting none of three planted defects. On that evidence it was a candidate for
deletion. The conclusion was wrong.

Inspecting the raw model response rather than the aggregate showed the critic
computing that 900 beds of 0.63 m² require 567 of 100 available square metres,
naming the correction and assigning the right severity. Three faults were
discarding that work:

**22 — the verdict gated the findings.** `verdict == "sound" or not findings`
short-circuited, and the model routinely reports findings while setting the
verdict to `sound`. A field the model treats as a formality cannot gate one it
treats as work.

**23 — the critique never received the schema repair.** Its plausibility working
exceeded a length bound and the whole critique was rejected. Third appearance of
one class in a third artefact, which is the clearest argument that the repair
belongs at every guided boundary by default rather than by memory.

**24 — the control was not clean.** The unmodified brief contained an object the
description never mentioned, so the critic's correct objection to it presented
as a false positive and masked the other two.

**Measured after correction:** `sound` on a genuinely clean brief, all three
planted classes detected with the right severity. On ten real prompts the stage
acts on four and declines on six, raising mass content 26%, doubling size
spread, and eliminating the one world that had no mass content.

**Lesson.** An aggregate metric can conceal a working component. "Ten of ten
sound, zero changes" was a precise measurement and the inference from it was
confidently wrong. When a measurement says a component does nothing, read its
raw output before judging it.

---

## Cross-cutting findings

**F1 — Anecdotes that agree with you are the most dangerous evidence.** (#11, #1, #15, #16.)
Four defects trace to a favourable signal being accepted as verification — a favourable
prompt, a favourable example spec, or a migration file that agreed with us.

**F2 — Know exactly what your guarantees guarantee.** (#4, #5.) The same JSON Schema is
authoritative for `required` and powerless for `maximum` under the same decoder.

**F3 — Fix classes, not instances.** (#4, #7, #8, #19.) The general clamp did not cover
`uniqueItems`, because "numbers" was still an instance of the real class: *anything a
context-free grammar cannot express*. Enumerating that class up front would have found
both at once.

**F4 — Every producer needs a named consumer.** (#2, #3, #10, #17.) Four defects are
correct data reaching code that ignored it, tested the wrong property, or interpreted it
by a different convention.

**F7 — A control you have not watched block something is not a control.** (#16.) The
strongest form of F1: it is not enough for the mechanism to exist and be spelled correctly.

**F5 — Disclosure beats silence and beats failure.** Clamping with a user-visible
approximation is better than a total loss (#4) *and* better than a silent distortion (#5,
#8). "Fail truthfully" is a design principle with measurable value: 20% of prompts
recovered.

**F6 — Order of operations is load-bearing in deterministic code.** (#9, twice; #20, where
a clamp ran before a filter that should have preceded it.)

**F8 — Judge a stage by its artefact, not by its own output.** (#18.) The most articulate
intermediate output in the project accompanied its worst worlds.

**F9 — Constraints are guesses until something tests them.** (#21, #4.) Six bounds have now
been found wrong, every one of them conservative, and each surfaced only when the model
became accurate enough to violate it honestly.

---

## Numbers most useful for the report

| Quantity | Value |
|---|---|
| Prompts lost to unenforceable numeric ranges | **2 / 10 (20%)** |
| Prompts lost to the seed overflow | **~50%** |
| Species omitting an optional field | **10 / 10 (100%)** |
| Capabilities blocked before the gate fix | **9 / 13**, of which **6 needlessly** |
| Scatter instances planned vs rendered (before) | 1,949 → 0 |
| Instances requested before budgeting | 120,000 → 12,000 |
| Density ratio distortion from wrong-order capping | 3.33× → 2.17× |
| World right-sizing | 500×500 m → 79.3×79.3 m |
| Player spawn distance to nearest content (before) | 276 m |
| Scene size for 1,949 instances | 2,817 bytes |
| Species size spread after making `size_m` required | 0.1 m → 25.0 m |
| TripoSR output mean saturation | 5 / 255 |
| Planner latency (Qwen 3.6 27B Q4, cold) | 45–65 s |
| Test suite | 632 tests (376 + 256) |
| Pipeline stages implemented | 5 / 9 |
| Verification gates | 15 |
| RLS policies installed / actually enforcing | **30+ / 0** |
| Vetted GDScript templates | 5 |
