# Golden Game Plan (P0 gate)

The **golden game** is one complete, hand-built, browser-playable 3D game created **before any AI exists**. It proves the hardest external constraint (real 3D in the browser, ≤90 MB, 4 browsers) and becomes the target the deterministic spine (P1) automates backward from. **If this gate is not met, P1 does not start.**

## Why golden-game-first

- De-risks the single most likely project-killer: Godot web export weight / Safari support.
- Gives P1 a guaranteed-working reference build (byte-comparable target).
- Forces the team to hand-walk the full asset → scene → export → play → test loop once, manually, so every later automated step maps to a known-good manual step.

## Chosen genre & concept (proposal — confirm at kickoff)

**Recommended:** `topdown_survival_escape_3d` — "Foggy Village Escape" (matches the flagship prompt in the report and the existing `contracts/examples/golden_game.spec.json`).

- **Camera:** `top_down_3d` (simplest to frame; forgiving of low-poly detail).
- **Loop:** explore a foggy village → collect 5 supply crates → reach the escape boat → win. Zombies patrol/chase; player death = lose.
- **Why this one:** exercises the load-bearing mechanics we must automate later — navmesh pathing, patrol/chase AI, pickups, a lock/gate-style objective dependency (boat requires supplies), a socketed door, fog/mood lighting, and audio cues.

**Alternative (if scope feels heavy):** `collect_explore_3d` with no enemies — smallest viable loop to prove export first, then add enemies.

> This choice is a P0 decision — record the final pick in `DECISION_LOG.md` (item 6).

## Build scope (deliberately small)

| Element | Golden game target |
|---|---|
| Level | One contiguous village, ~7 zones, single elevation tier |
| Props | ~40–60 (crates, fences, houses, boat, foliage) |
| Enemies | ~8 shambler zombies, one AI behavior |
| Objectives | collect_n (5 crates) → reach_zone (boat), win; player_death, lose |
| Assets | Hand-made / CC0 curated low-poly kit — **no AI generation** |
| Audio | 1 ambient loop + 2 SFX (CC0 or hand-made) |
| Session | 3–6 minutes |

Everything must map to a field in `contracts/game_spec.schema.json` so the hand-built game doubles as the schema's first real-world test (the example spec already mirrors it).

## Web-export constraints (must all hold)

- WebGL2 / Compatibility renderer only; GDScript only; **single-threaded export** (Safari/iOS reach).
- **≤90 MB** post-Brotli. Meet it via mesh decimation + texture atlasing + resolution caps — **NOT** Draco meshes or VRAM-compressed textures (unsupported on Godot web).
- Bake navmesh + lighting at build time, never at web runtime.
- Custom HTML shell with a themed loading card.

## The P0 gate checklist (all must pass)

- [ ] Game plays start-to-win in the browser.
- [ ] Export bundle **≤90 MB** (record the actual number).
- [ ] Playable on **Chrome, Firefox, Edge, and Safari** (Safari is the one people skip — do not).
- [ ] Mobile/tablet smoke test (single-threaded build loads and is controllable).
- [ ] Its `game_spec` validates against the frozen schema v2 (`python scripts/validate_contracts.py`).
- [ ] Built by CI from the Serendib (or, for P0, unbranded Godot at the pinned tag) editor + web template.
- [ ] No crash in a 5-minute session; objective reachable; no fall-through.

## Build steps (manual, once)

1. Pin the Godot stable tag + matching Emscripten (`runbooks/GODOT_BUILD.md`, `upstream-notes.md`) and compile the unbranded editor + web export template.
2. Assemble the level by hand in the editor using a small curated low-poly kit (grid-aligned tiles; doorframe carries a Marker3D socket).
3. Wire gameplay with hand-written GDScript that will later become the **vetted templates** in `engine/templates/` (controller, patrol/chase AI, pickup, objective trigger, door state machine). Name every node in PascalCase (`SkeletonArcher_03`, not `Node3D_17`) — editability depends on it.
4. Add the `dusk_fog` mood (WorldEnvironment) + budgeted lights + emissive materials.
5. Add audio: 1 ambient loop + door creak + pickup SFX (CC0/hand-made; log each in `licensing_ledger.csv`).
6. Export the web build; measure size; test on the 4 browsers + a phone.
7. Author the matching `game_spec` (already drafted as `contracts/examples/golden_game.spec.json`) and validate it.
8. Record lineage manually (seed, asset sources, build hash) — the first row of the reproducibility discipline.

## Ownership & timing

- **Owner:** M4 (3D Content & Validation), with M3 on the export/build toolchain.
- **Estimate:** ~8 working days (report's P0 table).
- **Where it lives:** a standalone Godot project (not `services/`); curated assets under `content/`; the validated spec under `contracts/examples/`.

## Common mistakes to avoid

- Skipping Safari — it is the most constrained target and the one that fails late.
- Reaching for AI generation — the whole point is a hand-made known-good baseline.
- One baked mesh for enterable buildings — doors must be socketed kit modules (the "door philosophy").
- Un-named nodes — kills the editability story the project is built on.
- Assuming asset sizes — measure real bounding boxes and the real bundle size.
