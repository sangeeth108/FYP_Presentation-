# Serendib research protocol

## Field and contribution

Primary field: **AI for Software Engineering**.

Main technical contribution: schema-bound multi-agent synthesis of executable
3D simulations, combining semantic procedural content generation, deterministic
compilation and evidence-driven repair.

Secondary fields:

- semantic procedural content generation;
- neuro-symbolic and constraint-guided generation;
- LLM planning and multi-agent orchestration;
- executable specification and program synthesis;
- AI assurance and runtime verification;
- consent-qualified continual learning;
- human–AI no-code authoring.

## Research questions

RQ1. Does requirement-contract planning improve prompt-to-executable semantic
correctness compared with game templates and unconstrained direct generation?

RQ2. Does measured, constraint-based semantic placement improve collision,
reachability, interaction clearance and user-rated plausibility?

RQ3. Does layered deterministic plus model-based verification and localized
typed repair improve final correctness without excessive latency or cost?

RQ4. Does consent-qualified user-data fine-tuning improve planner and ranking
quality beyond synthetic distillation without increasing memorization, PII
leakage, safety failure or tenant leakage?

RQ5. Do isolated enterprise adapters improve tenant-domain accuracy while
preserving global-model isolation?

## Systems compared

1. Legacy game-template baseline.
2. Untuned neutral planner.
3. Synthetic-data fine-tuned planner.
4. Consenting-user-data fine-tuned planner.
5. Combined synthetic and consenting-user-data planner.
6. Global model and, where the data threshold is met, isolated tenant adapter.

Ablations remove requirement contracts, capability resolution, measured
placement, critic, runtime probes or localized repair one at a time.

## Dataset integrity

- Register benchmark, user-study and research-holdout prompts through the
  research-exclusion API before any collection.
- Never store the raw excluded prompt in the exclusion registry; store exact
  and prompt-family fingerprints.
- Freeze datasets with immutable consent and rights snapshots.
- Re-evaluate current consent, guardian approval, rights, moderation, quality,
  deletion and legal-hold state immediately before dataset construction.
- Use temporal holdouts containing only users, tenants and prompt families not
  present before the cutoff. Exclude boundary-crossing recent examples instead
  of leaking them.
- Report exclusions, deduplication and dataset-manifest hashes.
- Study data cannot train a model evaluated in that study. Later training use
  requires separate research-training consent.

## Primary metrics

- Executable semantic correctness: proportion of required contracts with
  runtime PASS evidence.
- Technical completion: actual build, launch and mandatory-validator success.
- Asset ranking: NDCG@k, Recall@k and hard-constraint violation rate.
- Placement ranking: pairwise accuracy after hard constraints, collision rate,
  reachability and interaction-clearance success.
- Repair: success rate, cycles, affected-region size and regression count.
- Cross-platform parity: deterministic state-trace agreement.
- Efficiency: wall-clock latency, GPU/CPU time, token use and cost.
- Privacy/safety: memorization extraction, PII extraction, tenant leakage,
  disallowed-content and prompt-injection success rates.
- Generalization: held-out domains, prompt families, users, tenants and time.

Report 95% bootstrap confidence intervals and paired effect sizes. Use a
mixed-effects model with prompt family and participant as random effects where
appropriate. Correct multi-hypothesis comparisons and publish negative results.

## Benchmark protocol

- Freeze prompt IDs, hashes, seeds, platform budgets, model/container digests
  and capability versions before evaluation.
- Execute every condition in a clean, signed environment.
- A run counts as successful only if the world was built, launched and all
  mandatory validators ran and passed.
- `NOT_RUN`, `UNAVAILABLE`, build failure and launch failure are failures, not
  missing observations.
- Preserve full `GenerationRun`, validator evidence and repair lineage.
- Vision models judge appearance only; runtime probes judge behaviour.

## User study

Use the approved 48-participant, mixed-expertise, counterbalanced design.
Participants author and edit comparable simulation tasks under counterbalanced
conditions. Measure task completion, semantic correctness, edit count, time,
NASA-TLX, SUS and trust/calibration. Keep researchers blind to system condition
when scoring qualitative output where feasible.

Obtain ethics approval and separate product, study and optional future-training
consent. Teen participation requires the study’s approved assent/guardian
process and is not implied by product guardian consent.

## Reproducibility package

- frozen benchmark prompt fingerprints and held-out raw prompts under controlled
  access;
- contract and capability versions;
- container, engine, asset and model digests;
- dataset/model cards and training manifests;
- evaluation scripts and environment lock files;
- anonymized aggregate results and analysis notebooks;
- documented exclusions and failures;
- Serendib upstream pin and patch-series hash.

## Paper outline

1. Introduction and research gap.
2. Related work.
3. Requirement contracts and neutral `SimulationSpec`.
4. Capability-based deterministic compilation.
5. Asset synthesis and semantic PCG.
6. Verification and localized repair.
7. Consent-qualified learning and isolation.
8. Experimental design.
9. Quantitative results.
10. User-study results.
11. Privacy, safety, legal and validity threats.
12. Limitations and future work.
13. Conclusion.
