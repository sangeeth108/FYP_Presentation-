# Design System & UX Plan

**Rule (CLAUDE.md §8):** no UI code before flows, wireframes, screen list, component inventory, and state definitions exist here. Audience: students, hobbyists, educators, rapid prototypers — the UI must feel approachable, not like an ops dashboard.

> **Implementation status (2026-07-08):** Home/prompt page + **job-progress route (`/jobs/[id]`)** built in `apps/web` (Next.js 15 App Router). Home has prompt input, genre/camera pickers, example chips, all four states, theme-aware, mobile-first; **Generate** now creates a real job and routes to the progress page, which **polls `GET /api/v1/jobs/{id}`** and renders the S0–S8 `PhaseTimeline` until a terminal state. Verified end-to-end against the running brain (SQLite + eager Celery). Play + download screens remain planned (P1–P2); live phase *logs*/asset previews arrive with the real pipeline (P2).

## User flows

**Play flow:** Home (prompt) → live progress → play in browser → share URL.
**Edit flow:** Play → download project → open in Serendib → Serendib Assist edit → re-export.

## Screen list (v1)

| Screen | Route | Purpose | Why it matters |
|---|---|---|---|
| Home / prompt | `/` | One big prompt box + optional genre/camera pickers + example prompts | First impression; example prompts teach the design space and reduce out-of-scope rejections |
| Job progress | `/jobs/{id}` | Live S0–S8 phase timeline, logs, asset previews as they resolve | Generation takes minutes — visible progress is the difference between "broken" and "magical" |
| Play page | `/play/{game_id}` | Godot web build in a themed shell + share button + "Download project" CTA | The product's proof; the CTA drives the core differentiator (continuation) |
| Download page | `/games/{id}/download` | Project zip + web build + "open in Serendib" instructions + credits | Editability promise fulfilled; credits satisfy licensing |
| Later (P3+) | `/gallery`, `/login`, `/dashboard`, `/admin` | Showcase, accounts, research telemetry | Not v1-critical — do not build early |

## Text wireframe — Home

```
┌──────────────────────────────────────────────┐
│  PromptPlay 3D            [Gallery] [About]  │
│                                              │
│   Describe the game you imagine…             │
│  ┌────────────────────────────────────────┐  │
│  │ (multiline prompt input)               │  │
│  └────────────────────────────────────────┘  │
│  Camera: (Auto ▾)   Genre: (Auto ▾)          │
│            [ ✦ Generate my game ]            │
│                                              │
│  Try: "foggy village, hide from zombies…"    │
│       "arena where waves of slimes attack…"  │
└──────────────────────────────────────────────┘
```

## Text wireframe — Job progress

```
┌──────────────────────────────────────────────┐
│  Building your game…            job g3d_x1   │
│  ●──●──●──◐──○──○──○──○──○                   │
│  S0 S1 S2 S3 S4 S5 S6 S7 S8                  │
│  ✔ Understood your idea (survival, village)  │
│  ✔ Designed the game plan                    │
│  ◐ Building the level (seed 4521)…           │
│  [live log / asset thumbnails appear here]   │
│  Repair note (if any): fixed unreachable key │
└──────────────────────────────────────────────┘
```

## Component inventory (build these once, reuse)

`PromptInput` · `GenreCameraPicker` · `ExamplePromptChips` · `PhaseTimeline` (S0–S8) · `LiveLogFeed` · `AssetPreviewGrid` · `GameCanvas` (Godot embed shell) · `ShareButton` · `DownloadCard` · `CreditsList` · `ErrorPanel` (friendly, actionable) · `LoadingCard` (themed, used in the game shell too).

## Screen states (every screen defines all four)

- **Empty:** helpful guidance + example prompts (never a blank void).
- **Loading:** phase-aware progress, not a generic spinner ("Placing 34 props…").
- **Error:** what happened in plain words + what to do next ("Your idea needs multiplayer — v1 is single-player. Try…"). Machine error codes stay in a collapsible details block.
- **Success:** clear next action (Play → Share → Download → Edit in Serendib).

## Visual direction

- Mobile-first responsive layout (players share URLs to phones; generation UI must at least read well on mobile).
- Stylized, friendly, low-poly-inspired aesthetic matching the games; dark-mode-first for the play page.
- One accent color for primary actions; system font stack until the brand pass (P3, alongside the Serendib brand: original cleared name, logo, splash, editor theme).
- Accessibility: keyboard-completable flows, visible focus, WCAG AA contrast, reduced-motion respected in progress animations.

## Why these choices

Approachability is the lesson from Rosebud (competitor analysis); live progress is required because minutes-long silent waits kill trust; the download CTA embodies the one-line promise: *"a playable prototype in minutes — then keep building it in Serendib instead of starting from scratch."*


---

# Product site (2026-08-20)

The site was a single prompt box. That is the right *tool* and not a product: a
visitor arriving cold learns nothing about what Serendib makes, what makes it
different from a chatbot that emits a scene file, or that the engine to continue
the work is downloadable. This section plans the promotional surface around the
tool, plus the engine's own page.

**It also closes a compliance gap.** The frontend carried the "based on Godot
Engine" credit and non-affiliation disclaimer *nowhere* — only inside the engine
download component, from an API field. CLAUDE.md section 14 requires that credit
wherever the product is presented, and a marketing page naming "Serendib Engine"
is exactly that. There was no footer at all.

## Flows

**Cold visitor:** Home hero → *how it works* → *what a visitor can do* → *how it
is verified* → prompt box → live progress → play.
**Continuation:** Home → Engine page → download editor → open the project zip.
**Returning:** Home → Simulations → an earlier run's report.

The prompt box stays **above the fold on the home page**. Promotion is what a
visitor reads while deciding; it must not push the action off screen.

## Screen list (added)

| Screen | Route | Purpose | Why it matters |
|---|---|---|---|
| Home (rebuilt) | `/` | Hero + prompt, then how it works, capabilities, verification, engine, footer | A prompt box alone cannot say why this is not a toy |
| Engine | `/engine` | Editor + export template downloads, checksums, what it is, how to open a project, legal credit | The promise is "a beginning, not an end" and it is only redeemable by someone holding the engine |

## Text wireframe — Home

```
┌──────────────────────────────────────────────────────────┐
│ S Serendib      Home  Simulations  Engine  Privacy       │
├──────────────────────────────────────────────────────────┤
│  VERIFIED SIMULATION GENERATION                          │
│  Describe a world.                                       │
│  Serendib builds the working simulation.                 │
│  ┌────────────────────────────────────────────────────┐  │
│  │ (prompt)                                           │  │
│  │ size ▾   [browser][desktop]   ✦ Generate           │  │
│  └────────────────────────────────────────────────────┘  │
│  try: a farm yard…  a railway platform…  a forest…       │
│  ── 18 gates ──── 12 of 13 capabilities ──── 0 manual ── │
├──────────────────────────────────────────────────────────┤
│  HOW IT WORKS         (4 steps, plain language)           │
│  1 read  2 plan  3 build  4 verify                       │
├──────────────────────────────────────────────────────────┤
│  WHAT A VISITOR CAN DO   (capability cards, honest)      │
│  walk · open · sit · carry · talk · drive · machines ·    │
│  sensors · and things that CAUSE each other              │
├──────────────────────────────────────────────────────────┤
│  HOW IT IS VERIFIED   (the gate story + refusal promise) │
├──────────────────────────────────────────────────────────┤
│  THE ENGINE COMES WITH IT   → /engine                    │
├──────────────────────────────────────────────────────────┤
│  footer: attribution · licence · privacy                 │
└──────────────────────────────────────────────────────────┘
```

## Text wireframe — Engine

```
┌──────────────────────────────────────────────────────────┐
│  Serendib Engine                                         │
│  A rebranded Godot 4.7 build. Your project opens in it.   │
│  upstream 4.7-stable · built 2026-08-15                   │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐      │
│  │ Editor       │ │ Web template │ │ Win template │      │
│  │ Windows      │ │ Browser      │ │ Windows      │      │
│  │ 163.8 MB     │ │   9.9 MB     │ │  ~68 MB      │      │
│  │ sha256 09e0… │ │ sha256 2bc8… │ │ sha256 …     │      │
│  │ [ Download ] │ │ [ Download ] │ │ [ Download ] │      │
│  └──────────────┘ └──────────────┘ └──────────────┘      │
│  OPENING A PROJECT  1 unzip  2 open project.godot  3 F5  │
│  Based on Godot Engine (MIT). Not affiliated.            │
└──────────────────────────────────────────────────────────┘
```

## Components added

| Component | Responsibility |
|---|---|
| `SiteFooter` | Legal attribution + non-affiliation, licence note, nav. Rendered on every page from the root layout, because the credit is a condition of use and not page decoration |
| `HowItWorks` | Four steps in plain language. No jargon: "reads your description", not "S1 intent parsing" |
| `CapabilityShowcase` | What a visitor can actually do, with the honest split — what is fully supported, what is partial, what is absent |
| `TrustPanel` | The verification story: gates, and the refusal promise |
| `EngineDownload` (existing, reused) | Build list with size + checksum, and its three distinct states |
| `StatStrip` | Three verifiable numbers under the hero |

## States

| Surface | Empty | Loading | Error | Success |
|---|---|---|---|---|
| Prompt (home) | idle, chips visible | "Extracting requirements…", button disabled | Inline `role="alert"`, prompt preserved | Route to the run |
| Engine list | "Not built yet — your project is still editable in any compatible build" | Nothing rendered until resolved (avoids a flash of empty state) | "Cannot reach the download service" — distinct from not-built | Cards with size + checksum |
| Marketing sections | n/a — static content, no fetch, so they cannot fail | | | |

The engine list keeps **not-built** and **unreachable** as separate messages.
"No builds yet" and "the build machine is down" are different facts and merging
them into one blank space tells the visitor nothing they can act on.

## Honesty rules for promotional copy

This is a dissertation artefact before it is a product, so the marketing surface
carries the same standard as the code:

- **No capability is advertised beyond its registry status.** The showcase reads
  the real split — 6 supported, 6 partial, 1 unavailable — and says which is
  which. A landing page claiming "simulate any ecosystem" while
  `ecosystem_process` has no runtime binding would be the exact failure the
  capability manifests exist to prevent.
- **Numbers are the ones the system can produce.** 18 validation layers, 17
  mandatory. No invented percentages, no fabricated user counts, no testimonials.
- **The refusal promise is stated plainly**, because it is the actual
  differentiator: a run that cannot satisfy a mandatory validator is reported as
  failed rather than published as a preview.

## Visual direction (extends the existing system)

Same teal palette and CSS custom properties; no new dependency, no CSS framework.
Additions:

- `--maxw-wide` (1080px) for marketing sections. The 720px column is right for
  reading a form and too narrow for a feature grid.
- Grid sections collapse to one column under 720px — mobile-first, as before.
- Section rhythm via a `.band` wrapper with alternating surface, so the page
  reads as distinct chapters rather than one long scroll.
- No animation beyond existing hover transitions; the reduced-motion query
  already in the sheet continues to cover it.
