# Testing Plan

Three layers (from the planning report §18):

## Layer 1 — Unit & contract tests

| Target | What is tested | Where |
|---|---|---|
| Canonical schema | valid + broken fixture specs → exact machine-readable errors | `services/brain/tests/`, `scripts/validate_contracts.py` |
| Agents | fixture context → schema-valid patches (no live LLM in CI; recorded fixtures) | `services/brain/tests/` |
| PCG | same seed → byte-identical zone graph; connectivity property tests over 100 seeds | `services/brain/tests/` |
| Templates | each GDScript template has a scene-level behavior test | `engine/templates/` + Godot headless in CI |
| API | contract tests on every endpoint (status codes, error shapes, 202 semantics) | `services/brain/tests/` |
| Frontend | component tests for progress timeline, error panels | `apps/web/tests/` |

## Layer 2 — 8-gate validation stack (every generated game)

Schema → constraint → asset QA → import/export → static playability (navmesh path spawn→objective, lock-key solver, timer plausibility) → dynamic (bots) → quality (critic rubric) → lineage. Order = cheapest first. See `VALIDATION_PLAN.md`.

## Layer 3 — Playtest bots + regression benchmark

- Bots read game state via an approved **debug singleton — never vision** (justified by GlitchBench's 43.4% ceiling on vision-based glitch detection).
- Bots: GreedyObjectiveBot (P1), ChaosBot for fall-through/stuck anomalies (P2).
- **Nightly regression benchmark** over 20 frozen prompts from P2 onward; investigate any >5% drop.

## Cross-cutting testing

- Browser matrix monthly: Chrome / Firefox / Edge / **Safari** (golden game + 2 generated games).
- Mobile/tablet smoke test (single-threaded build).
- Performance: latency p50/p95 within target; GPU VRAM never OOMs (mode scheduler).
- Security: no inbound ports on the 5090; no arbitrary code execution; template allowlist enforced; no secrets in repo (CI secret scan).
- Data: lineage complete; licensing ledger has no gaps (`scripts/check_licenses.py` in CI).

## Functional acceptance (per phase gate)

- P2+: prompt → job → playable URL for all supported genres.
- P3+: download project → opens in Serendib → runs; AI-dock edit applies; repair loop fixes a deliberately broken spec.

## Bug tracking format (mandatory fields)

```
[BUG] <short title>
severity: blocker|high|med|low     area: brain|engine|pcg|assets|web|infra
game_id / job_id:                  seed:
steps to reproduce:                expected vs actual:
lineage link:                      owner:            status: open|fixing|verify|done
```
A bug without `game_id` + `seed` cannot be reproduced and will be bounced back.

## KPI targets

Schema validity >97% · build success >90% · playability >95% · repair success >70% · crash-free >95% · fidelity ≥3.8/5 · ≤90 MB · editability ≥4.0/5.
