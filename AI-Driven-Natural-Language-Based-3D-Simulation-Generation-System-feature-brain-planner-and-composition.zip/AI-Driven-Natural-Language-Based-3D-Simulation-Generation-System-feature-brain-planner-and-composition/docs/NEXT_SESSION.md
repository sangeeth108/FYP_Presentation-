# Next session: start here

Written 2026-08-08 at the end of a session. Everything below is verified, not
recalled. Full register of remaining work is in `IMPLEMENTATION_PLAN.md` under
"Outstanding Work Register".

## State

Branch `feature/brain-planner-and-composition`, pushed at `78d6975`.
Whole test suite green (~770 tests, exit 0). No first-party TODO markers.

Landed this session, each with the measurement that forced it in the commit
message:

- `7f63fd9` world sizing accounts for scatter (3,762 -> 11,994 instances, no
  species placing zero)
- `7a1e3ed` asset normalisation matches height, not longest dimension
- `6068671` validation captures render at 1920x1080
- `fd16861`, `78d6975` plan register and report

## Do these three, in this order

### 1. Descriptor cache invalidation -- CLOSED, no bug (done 2026-08-08)

The theory was wrong. There is no descriptor cache, so there is nothing to
invalidate and no rule-version stamp is needed in the cache key.

What the code actually does, confirmed by driving the real resolver rather than
by reading it:

- `AssetCache` (`services/worker/asset_farm/cache.py`) stores the GLB file plus
  `filename`, `component`, `tri_count`, `qa_profile` and an optional embedding.
  It has never stored `world_dimensions_m` or `normalization_scale`.
- On a cache hit `resolve_asset` calls `_qa_resolved_path`, which re-runs
  `qa_mesh` over the stored file. `qa_mesh` re-reads the bytes every call and
  memoises nothing, so `bbox_dimensions` is a fresh measurement.
- `descriptors_from_simulation_manifest` then recomputes `_uniform_scale` from
  that fresh measurement and the spec's declared bbox. Every descriptor is
  derived per run.

Observed directly: the same GLB with the T-pose proportions `[1.09, 1.02, 0.20]`
resolved fresh (tier `curated`) and from a seeded cache (tier `cache`) produced
identical descriptors -- scale `1.7647`, world `[1.924, 1.8, 0.353]`. The cache
tier is already correct under the new rule.

Where `[1.8, 1.68, 0.33]` really came from: a **pre-fix lineage row**, not a
cache entry. `asset_descriptors` rows are per-run history (unique on
`run_id, entity_id`), written once and never read back for reuse. In the live
DB every one of the 1,618 rows predates `7a1e3ed` -- there has been no
generation run since the fix, so there was no post-fix row to compare against.
The `ent_controlled_actor` row showing `[1.8, 1.6767, 0.3265]` is tier
`curated`, not `cache`, and its scale `0.3463` is exactly `1.8 / 5.197`, the old
longest-to-longest rule.

Pinned by `test_a_cache_hit_is_re_measured_so_rule_changes_reach_cached_assets`
in `services/worker/tests/test_asset_farm.py`, which resolves one asset by both
routes and asserts the descriptors match and honour declared height. It uses a
new local `_glb_with_bounds` helper because `_minimal_glb` is fixed at
`(1, 1, 0)`, where height and longest axis coincide and the two rules cannot be
told apart.

**Still open, and the reason this looked real:** the stale
`services/brain/build/lib/assets/descriptors.py` still contains the old
`max(declared) / max(imported)`. It is gitignored and untracked, and it does
*not* currently shadow the source (verified: `import assets.descriptors`
resolves to `services/brain/assets/descriptors.py`). It remains a live trap —
register Tier 2 #7. Deleting it needs a decision, so it was left in place.

The real verification gap is that no generation has run since `7a1e3ed`. The fix
is proven by unit test and by direct resolver observation, not yet by a render.

### 2. Texture synthesis (Tier 1 #3) -- PART DONE 2026-08-08, ~1 day left

The stated integration point did not exist. `contracts/asset_descriptor.schema.json`
has no material field and sets `additionalProperties: false`, so nothing could
record a material assignment; both the plan ("Asset-descriptor field already
exists") and `ch_5_construction.tex` describe a field that was never built.

The real cause of "nothing has a surface" was more basic than poor textures:
**the ground `MeshInstance3D` carried no material at all** and rendered as
Godot's default white. It is the largest surface in every frame.

Done, see [ADR-0010](adr/ADR-0010-surfaces-are-synthesised-from-a-named-family.md):

- `services/worker/godot_client/surfaces.py` -- a closed set of vetted surface
  families, each a seamless `FastNoiseLite` driving a triplanar
  `StandardMaterial3D`. Godot builds it at load: no texture files, no GPU, no
  bytes against the 90 MB budget. Triplanar is load-bearing -- the ground is a
  `BoxMesh` and procedural forms have no `TEXCOORD_0`.
- Ground and paths wired up in the native writer; paths keep their own family so
  they stay legible over grass.
- New closed enum `environment.terrain_surface` names what the ground is MADE OF.
  The free-text `environment.terrain` is deliberately never consulted -- word
  matching there is the noun ceiling `procedural.py` documents, and a test pins
  that it cannot select a family. Unnamed surfaces render neutral and append to
  the approximation record.
- Planner prompt updated, because schema `description` prose never reaches the
  model (ADR-0009): the enum constrains it, the prompt instructs it.

Also done, the mesh side: `services/worker/asset_farm/surface_texture.py` bakes a
seamless value-noise tile into every procedural GLB as `baseColorTexture`, with
box-projected UVs derived per vertex from the dominant normal axis (the
primitives have no `TEXCOORD_0`). glTF multiplies factor by texture, so **each
piece keeps its palette colour** -- a building keeps walls distinct from roof, a
tree a brown trunk under a green crown. That is the property most worth not
breaking, and it is pinned by tests.

Three details that are load-bearing:

- Applied to FINAL geometry. `_fit_to_bbox` rescales assemblies non-uniformly,
  so UVs computed earlier would stretch the grain.
- Baked in the asset farm, not at project-write time, so the textured mesh is
  what gets measured, hashed and QA-gated. Texturing at copy time would leave the
  descriptor's `content_hash` describing a file that no longer exists.
- `NOISE_VERSION` is in the content contract that yields the digest, which is
  both filename and cache key. This IS the invalidation problem the descriptor
  cache was wrongly accused of -- real here, because these files are reused by
  path. Cost ~5 KB/asset, ~4.2 MB for 400 assets against the 90 MB budget.

Curated (KayKit) and generated (TRELLIS) assets already carry surfaces, so only
the flat tier changed.

### What is left on this item (~half a day)

- **Normal and roughness maps.** This is albedo only: grain, no relief.
- **The asset-descriptor `material` field still does not exist.** The palette
  assignment lives only inside the GLB, so nothing can inspect, validate or
  report it, and nothing records which tier gave a mesh its surface. Needs
  `contracts/asset_descriptor.schema.json` extended (it sets
  `additionalProperties: false`) plus `qa_gate.py` surfacing the material list it
  already parses out of the glTF.

### Rendered 2026-08-08 -- what a picture showed

A world was generated end to end (planner -> assets -> PCG -> scene compile ->
Godot import -> validation views) and the images are in
`artifacts/viewable/sim_a_sri_lankan_tea_estate_9bcd885a/project/validation_views/`.
Regenerate with the scratch runner or via the full stack.

Surfaces work: ground, paths, boulders and bushes all carry grain. Two defects
were visible immediately and are now fixed and pinned:

- **Chevron pattern on every rock.** Box projection was decided per VERTEX, so
  the corners of one triangle could pick different axes and the texture swept
  across the face -- 44 of 80 faces on an icosphere. Fixed by unmerging vertices
  first (`test_every_face_projects_from_one_axis`).
- **Ground read as camouflage.** Raw `FastNoiseLite` spans black to white and
  multiplying a tint by that is far too strong. Both sides now compress it: a
  `Gradient` ramp on the Godot texture, floor 0.82 on the baked one.

Neither was catchable without an image. Render the validation views after any
material change -- capture takes about a minute via `capture_canonical_views`.

### Three gaps the same render exposed (none of them the surface work)

Gaps 1 and 2 are FIXED structurally, following ADR-0009: make the wrong answer
unrepresentable rather than argue with the model in a prompt.

1. **`terrain_surface` was never emitted** -- FIXED. The planner put `soil` in
   the free-text `terrain` and left the enum empty, so the ground rendered
   neutral. The field was in the grammar and the instruction was in the prompt;
   the model simply skipped an optional field. It is **required** now, with
   `unspecified` added to the enum as the honest way out. Choosing `unspecified`
   is a decision and is recorded as an approximation; skipping the field was not.
   The deterministic draft declares `unspecified`.
2. **`spc_mist_particle` rendered as ~90 five-metre boulders** -- FIXED. The
   planner asked for "volumetric fog particles" as a scatter species: category
   `vehicle`, `requires_animation: true`, form `irregular_mass`, 5 m across,
   density 10 per 100 m². Nothing was broken -- the vocabulary let it ask for
   something scatter cannot be. Scatter is a MultiMesh with no rig, no behaviour
   and no collision body, so `requires_animation` is `enum [false]` now and
   `character`/`vehicle` are gone from its category enum. Pinned in
   `services/brain/tests/test_scatter_is_solid.py`, including the exact species
   that shipped.

   Note this closes the contradiction, not the underlying want: atmosphere still
   has no representation anywhere. A prompt asking for mist now gets no mist
   rather than boulders, which is better but not right. Volumetric fog is a
   `WorldEnvironment` setting the writer could drive from `environment.weather`.
3. **Both drying sheds and both footpaths are `semantic_box`** -- OPEN. A path is
   a 40x0.1x2.5 m box lying on the ground. `building_shell` exists and was not
   chosen for a building; there is no form for a path at all. This is item 3
   below, the ladder bottoming out.

### 3. Curated building assets (checklist #73, ~1 day)

Inspection of a real render found the large box in frame was
`ent_stone_drying_shed` resolving to `procedural_type: semantic_box` -- the
cheapest tier -- because the curated library has no buildings. Trees are
`foliage_column` and all ground cover is `ground_cover`, so a tea bush, an
oxalis and a fern draw as one blob at three scales.

None of that is a defect. It is the ladder bottoming out. More curated assets
and wider generative coverage fix it; more form primitives do not.

## Conventions that bit during this session

- Heredocs eat backslashes: `\\` arrives as `\` and silently breaks LaTeX row
  terminators and TikZ. Write a script file instead, or use `BS = chr(92)`.
- The build queue is `serendib_build`, not `build`. A worker on the wrong queue
  leaves jobs sitting with no error and the legacy jobs endpoint reports them as
  FAILED.
- `GET /api/v1/jobs/{id}` reports FAILED for healthy jobs whose canonical state
  it does not recognise (`deprecated_adapter: true`). Check `canonical_state`
  in `detail`, not `state`. This is user-facing on the progress page.
- `services/brain/build/lib` keeps reappearing and once shadowed source so tests
  passed against dead code. Delete and gitignore it (register Tier 2 #7).

## Bring the stack up

Postgres and Redis run in Docker on host ports 5433 and 6380; Ollama on 11434.
Brain, worker and web run natively:

    cd services/brain && python -m uvicorn main:app --host 127.0.0.1 --port 8000
    cd services/brain && python -m celery -A worker.celery_app worker \
        -Q planning,privacy,serendib_build -c 1 -l info --pool=solo
    npm run dev:web

A generation takes about 13.5 minutes end to end: ~4.5 planning, ~9 build.

## Report

Compile with:

    cd Reports/Serendib_Report
    ../../../tools/tectonic.exe -X compile Report.tex

Seven `\pending{...}` slots remain, rendered as red `[TO MEASURE: ...]`. Three
are fillable immediately: repository URL, commit hash and date in
`End_matters/appendix_03_reproduction.tex`.

The chapters describe terrain, texture synthesis, immersive VR and corpus
ingestion as delivered. They are not in the code. The user removed the
draft-status note from the Preface deliberately; this draft is for supervisory
review and should not be submitted as final in that state.
