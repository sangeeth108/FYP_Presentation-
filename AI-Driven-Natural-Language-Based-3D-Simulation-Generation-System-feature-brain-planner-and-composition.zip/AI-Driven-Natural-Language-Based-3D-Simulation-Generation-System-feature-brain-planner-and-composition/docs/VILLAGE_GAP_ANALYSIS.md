# System analysis: why valid JSON does not produce a place

**Date:** 2026-08-20 · **No code was changed to produce this document.**

Every figure here was measured across **176 stored specs, 1,187 entities, 928 scatter
species and 531 spatial relations** in the local database — not inferred from one bad
render.

---

## 0. The question this answers

> *"The LLM emits JSON, and deterministic code generates correct models and placement
> from that JSON. So what is this?"*

The promise has two halves, and **both are leaking — but not in the way it looks.**

The JSON is *schema-valid*. It passes 17 mandatory gates. The deterministic code
*correctly implements* what the JSON says. The failure is in between:

> **The contract has no vocabulary for composition.** It can say *what objects exist*
> and *what they are made of*, but it cannot say *how a place is arranged*. There is
> no street, no plot, no frontage, no linear wall, no paved region. So the planner
> writes the richest thing available — `near` — or nothing at all, and the placement
> solver fills the silence with seeded random darts inside a rectangle.

Neither side is broken. **Nobody owns composition.** That is the finding.

---

## 1. The measurements

### 1.1 Half the world never reaches your generator

| | `procedural` | `either` |
|---|---|---|
| Entities (1,187) | **589 (50%)** | 598 (50%) |
| Scatter species (928) | **732 (79%)** | 196 (21%) |

`preferred_source: "procedural"` is not a preference — in
`services/worker/asset_farm/pipeline.py` it short-circuits the whole ladder:

```python
if requirement.get("preferred_source") == "procedural":
    ...resolve_procedural_asset(...)
    continue      # cache, curated library, GENERATION, textures — all skipped
```

**So half of every object ever planned, and four-fifths of all ground cover, was
built from primitives without the mesh generator or texture system being asked.**

Root cause: the `preferred_source` enum had **no description** in the contract until
today. The model was choosing between four options blind.

### 1.2 What those primitives actually are

**Entity forms** (of the 589 procedural entities):

| Form | Count | |
|---|---|---|
| `semantic_box` | **228** | a literal box — **19% of every entity ever planned** |
| `hinged_door_leaf` | 119 | |
| `building_shell` | 117 | works well — the red-roofed house |
| `irregular_mass` | 55 | grey faceted lump |
| `foliage_column` | 47 | |
| `flat_panel` | 11 | |
| `slender_post` | 10 | |

**Scatter forms** (928 species):

| Form | Count | Share |
|---|---|---|
| `ground_cover` | 374 | 40% |
| `irregular_mass` | 292 | 31% |
| `semantic_box` | 166 | 18% |
| everything else | 96 | 11% |

**89% of all scatter is a flat quad, a grey lump, or a box.** That is the speckled
carpet, system-wide, not a one-off.

### 1.3 Scatter is used at the wrong scale of abstraction

| Measure | Value |
|---|---|
| Median requested density | 20 per 100 m² — **healthy** |
| Maximum requested density | 5,000 per 100 m² (the contract ceiling) |
| Species requesting **≥1,000** per 100 m² | **120 of 928 (13%)** |
| Species whose largest dimension is **≤0.25 m** | **337 of 902 (37%)** |

So the median species is fine, and a long tail is catastrophic. **Over a third of all
scatter species are sub-quarter-metre detail** — grass blades, pebbles, leaves,
paving chips — which are *what a surface is made of*, not objects.

### 1.4 The layout vocabulary is nearly unused

> **Superseded 2026-08-21.** The vocabulary was nearly unused because it could not express arrangement, not because the planner ignored it. The four primitives in §3.1 now exist and the figures below are the *before* measurement.

531 relations across 1,187 entities = **0.45 relations per entity.**

| Relation | Count | Share |
|---|---|---|
| `near` | 275 | 52% |
| `attached_to` | 168 | 32% |
| `connected_to` | 66 | 12% |
| `on` | 18 | 3% |
| `inside` | 4 | 1% |
| **`facing`** | **0** | **never used** |
| **`reachable_from`** | **0** | **never used** |
| **`supported_by`** | **0** | **never used** |

Two conclusions:

1. **No building has ever faced anything.** `facing` exists in the enum and has never
   been written once in 176 specs. That is precisely the relation a street frontage
   needs.
2. **Roughly 55% of entities carry no spatial relation at all.** They are positioned
   by rejection sampling inside the zone rectangle
   (`services/brain/pcg/semantic.py::_free_point`). For those objects there is no
   design — only a seeded dart that did not collide.

### 1.5 Where the surface choice goes

| `terrain_surface` | Specs |
|---|---|
| *(unset)* | 145 |
| **`concrete`** | **11** |
| `soil` | 9 |
| `stone` | 4 |
| `grass` | 3 |
| `wood` | 3 |

Of the specs that choose a surface, **`concrete` is the most common** — more than
grass and soil combined. And `concrete` also forces
`terrain.py::relief_amplitude_m → 0.0`, so choosing it silently disables terrain
relief as well as making the ground grey.

### 1.6 What is *not* systemic

Honest calibration, so effort is not wasted:

- **Buried attachments: 6 of 168 (4%).** A real bug (see §3.4) but rare. I over-weighted
  this from a single example.
- **Dynamic physics: 252 of 1,187 entities (21%)** get a `RigidBody3D` with mass. That
  is a reasonable proportion and works.

---

## 2. Case study — "as a dog explore a living village"

Run `run_226c728f0e1b4d5cbb0d8e5e51a44fa0`, **completed, 17/17 mandatory gates PASS.**

Decoding the render element by element:

| What you see | What it is | Count |
|---|---|---|
| Forest of upright panels | `spc_perimeter_wall`, `flat_panel`, 0.3 × 2 × 1 m | **59** |
| White "boulders" | boxwood bushes + ornamental grass as `irregular_mass` | 208 |
| Grey floor litter | `spc_concrete_paving` 0.6 × 0.05 × 0.4 m | **2,239** |
| Tiny flecks | `spc_small_stones` 0.02 m | 897 |
| Flat green patches | `spc_dried_leaves`, `ground_cover` | 748 |
| Grey flat ground | `terrain_surface: concrete` → amplitude 0.0 | — |
| One red-roofed house | `building_shell` — correct | 2 |

**4,180 scatter instances at 305 per 100 m².** `preferred_source: "procedural"` on
**8/8 entities and 7/7 species.**

The layout, in full: `dwelling_left near gatehouse`, `dwelling_right near gatehouse`,
`garden_hose near dwelling_left`. Result — dwellings **21 m apart on opposite sides**,
gatehouse 17 m from both, nothing facing anything.

```
ent_dwelling_left    (-8.9, 2.0, -10.0)
ent_dwelling_right   (-4.4, 2.0, +10.9)
ent_gatehouse        (+8.2, 1.2,  +2.5)
ent_pedestrian_door  (+8.2, 1.0,  +2.5)   ← identical x,z to gatehouse: buried inside it
```

---

## 3. What is not working, by part

### 3.1 CONTRACT — no vocabulary for composition · **the root cause**

**File:** `contracts/simulation_spec.schema.json`

The spec can express objects, materials, capabilities and pairwise proximity. It
cannot express any of the things that make a settlement:

| Missing concept | Consequence today |
|---|---|
| **Linear structure** (wall, fence, hedge, street) | A wall became 59 scattered panels |
| **Paved region** (courtyard, path, plaza) | Paving became 2,239 loose slabs |
| **Frontage / orientation to a route** | `facing` unused in 176 specs; no building faces a street |
| **Plot / parcel** | Buildings land wherever a dart does not collide |
| **Cluster or row** | No grouping concept; 21 m gaps in a "village" |

**Solution.** Add composition primitives to the contract, in this order:

1. `linear_structures[]` — `{from, to, height_m, thickness_m, kind}`, materialised as a
   run of segments by deterministic code. Gives walls, fences, hedges **and collision**.
2. `regions[]` — `{polygon, surface}` for paved yards, paths and plazas, rendered as
   ground material rather than objects.
3. `routes[]` — the circulation spine, solved **before** buildings.
4. `frontage` on an entity — which route it addresses, and its setback.

This is the highest-value work in the system and needs no new models.

**All four landed 2026-08-20/21** — `ADR-0016`, `ADR-0017`, `ADR-0018`. What each was
measured to change:

| Primitive | Before | After |
|---|---|---|
| `linear_structures[]` | a wall as 59 scattered panels, walkable through | 16 of 16 segments placed on the declared line, solid, gate 3.00 m against 3.0 asked |
| `routes[]` + `frontage` | 4 cottages 45/28/13 m apart at 4 unrelated yaws | two facing rows 10.2 m apart at exactly 0° and 180° |
| `regions[]` | 2,239 loose paving slabs | one integer array; 36 painted vertices, verified in the engine |

What is still missing from §3.1's table: **plot/parcel** and **cluster or row** as
first-class concepts. Frontage covers the common case of a row along a street; a
courtyard cluster with no street still falls back to rejection sampling.

### 3.2 PLANNER — writes the poorest available description

**File:** `services/brain/agents/simulation_planner.py`

Given no vocabulary for arrangement, the planner does the only thing it can: `near`
(52%) or nothing (55% of entities). It is not making a mistake; it is describing a
village with a language that has no word for street.

Secondary, and fixable now:

| Issue | Evidence | Solution |
|---|---|---|
| Chooses `procedural`, bypassing generation | 50% of entities, 79% of scatter | Remove `procedural` from the planner's options entirely — let `either` route everything and keep procedural as the ladder's genuine last resort |
| Uses scatter for surfaces | 37% of species ≤0.25 m | `scatter_species` description updated 2026-08-20; **unverified against a real run** |
| Requests absurd density | 13% of species ≥1,000/100 m² | Density bound added 2026-08-20 for sub-0.25 m species; **whole-world instance ceiling still missing** |
| Picks `concrete` for villages | most-chosen surface | Add worked examples to `terrain_surface`: a village is `soil`/`grass` with paved *regions* |
| Never uses `facing` | 0 of 531 | **Answered 2026-08-20, and not by making it used.** `facing` expresses the wrong relationship: a building faces the STREET, not another building. `placement.frontage` says which route an entity addresses and the yaw follows from the route's direction (`ADR-0017`). `facing` remains in the contract and remains, correctly, unused between buildings |

### 3.3 PLACEMENT — rejection sampling where design is needed

**File:** `services/brain/pcg/semantic.py`

What works: zone geometry, collision and clearance, attachment offsets carried from
declared to measured space, terrain seating, assembly contiguity, determinism.

What is missing: **any notion of arrangement.** `_free_point` throws seeded darts into
the middle fraction of a zone. For the 55% of entities with no relation, that *is* the
layout.

**Solution.** Once §3.1 lands: solve routes → allocate plots along them → place
buildings into plots with frontage → place props relative to their building → scatter
into what remains. Dart-throwing becomes the last resort rather than the default.

**Landed 2026-08-20** for routes and frontage (`ADR-0017`). Plots are allocated along a
route from measured geometry before the placement loop runs, and dart-throwing is now
what an entity falls back to rather than what it starts with. Props relative to their
building still rely on `attached_to`, and `regions[]` (#8) is outstanding.

### 3.4 PLACEMENT — an under-reaching attachment offset buries the child

**Evidence:** 6 of 168 `attached_to` relations (4%) have an offset that reaches no
parent face. The gatehouse door above is one: offset `[0, -0.25, 0]`, `z = 0` meaning
the parent's centre.

The existing clamp only handles offsets that **overshoot** (it pulls a detached child
flush). It does nothing when one falls short.

**Solution.** Treat under-reach exactly like overshoot: push the dominant axis out to
the flush position and record a soft relaxation. A child entirely inside its parent is
never the intent.

### 3.5 ASSET FARM — the fallback is grey, and the ladder is skipped

**Files:** `services/worker/asset_farm/pipeline.py`,
`services/worker/asset_farm/procedural.py`

| Issue | Solution |
|---|---|
| `procedural` short-circuits cache, library, generation and textures | §3.2 — stop the planner selecting it |
| Every procedural form renders grey/untextured | **Give each form a palette keyed to the species' `semantic_type`.** Cheap, and the single largest visual win for the fallback path |
| Form vocabulary too small for a village | Only worth expanding *after* generation is routed correctly. Missing: fence run, hedge, roof, window, chimney, cart, barrel, well, trough, signpost |
| Generation fails often, silently falling back | 34 concept-gate rejections in one observed run. **Surface the generation success rate as run evidence** so this is visible rather than inferred |

### 3.6 CURATED MATCHING — the embedding tier cannot fire

Measured earlier: character briefs score **0.548 at best against a 0.85 floor**; the
deterministic critic scored reef/atoll 0.614 against village/factory 0.627 —
*inverted*.

**Solution.** Recalibrate the floors against a measured distribution, or stop treating
cosine similarity as a gate. Do not leave a tier in the report described as working
when it cannot fire.

**Both halves resolved (`ADR-0019`).**

- The **critic** half was already done before this pass: embedding was measured, found
  unable to separate true from false pairs at any threshold, and **retired** in favour of
  literal containment. The numbers and the reasoning live in `_atom_is_present`.
- The **curated** half is done now, and recalibration alone would have been the wrong
  fix. The floor was unreachable (0.775 was the best score any real brief achieved
  against 0.85), but the reason scores were so low is that the brief is mostly pipeline
  boilerplate. Embedding the entity's `semantic_type` instead took `dog` from
  **Alpaca** 0.566 to **Husky** 0.651, and `visitor` from **Skeleton_Rogue** 0.573 to
  **Man** 0.709. With clean queries the floors are measurable and differ by category:
  props 0.70 (separable, gap +0.112), characters 0.64.
- The **cache** floor was measured and left at 0.92: 8 of 820 real brief pairs clear it
  and all 8 are genuine near-duplicates.

### 3.7 SCATTER — no collision, and no world budget

**File:** `services/brain/pcg/scatter.py`, writer emits `MultiMeshInstance3D`

- **Scatter has no colliders.** The dog walks through all 59 wall panels and 208
  bushes. Anything a visitor must not pass through has to be an entity — another
  argument for §3.1(1). **Half-answered as of 2026-08-20:** the 59 wall panels are
  now a `linear_structure` whose segments are entities and therefore solid
  (`ADR-0016`). Bushes and other genuine scatter still have none.
- **Correction to an earlier draft of this section.** It claimed density was bounded
  per species and never per world. That is wrong: `_TOTAL_INSTANCE_BUDGET = 12,000` in
  `pcg/scatter.py` already caps the whole scene and scales every species proportionally
  so the planner's mix survives. Re-measuring the village diagnostic shows why the
  claim was never the problem — **328 instances in 8,400 m²**, against that ceiling of
  12,000. Nothing was remotely over budget.
- **What is actually wrong is which species scatter is allowed to place.** The village's
  largest species by instance count was a **street lamp: 168 of them, one every 50 m²,
  spread by rejection sampling with no relation to any path — beside 28 trees.** A tree
  does not care where it stands; a lamp does. The contract never asked, so a fern and a
  lamp post were indistinguishable requests.

**Solution.** Ask the question in the contract — `placement_is_incidental` on a species
— and act on the answer deterministically. No economic limit could have caught this,
because the cost was never the problem; and no keyword list should, because whether a
thing belongs somewhere is a judgement about the described world. Collision for species
above a size threshold remains outstanding.

### 3.8 VALIDATION — 17 gates, none of which asks "is this the place?"

**Files:** `services/brain/core/validation_contract.py`,
`services/brain/model_router/executors.py`

Every gate passed on a world that is not a village. They are all *correctness* gates:
geometry measured, placement non-overlapping, behaviour probed, navigation reachable,
export byte-identical, lineage complete. A grey box is a valid box; a buried door is a
valid transform.

**The only validator that objected was `visual_semantic`, and it was right every
time** — reporting "the lodge structure is not visually represented" about a
featureless cube. It is marked **advisory**, so it blocks nothing.

**Solution.**

1. **Stop treating `visual_semantic` as noise.** It is the only composition signal in
   the system. Track it as the primary quality metric even while advisory.
2. **Do not quote a "clean" rate that includes it** until the appearance work lands —
   it currently reports on the box problem, not on pipeline correctness.
3. Consider promoting it to mandatory *after* §3.5, when a failure means something
   went wrong rather than something was never possible.

### 3.9 PHYSICS — works, with one structural gap

| Aspect | State |
|---|---|
| Static colliders on every entity | **Works** |
| `RigidBody3D` + mass for dynamic entities (21%) | **Works** |
| Terrain trimesh collider, verified by raycast | **Works** |
| Character controller, gravity, floor snap | **Works** |
| Navmesh baked at load, pathing verified | **Works** |
| **Scatter collision** | **Absent** |
| Per-entity friction / restitution / damping | **Not authored** |

**Solution.** Scatter collision for large species (§3.7). Physical material properties
are a contract addition worth doing only if a prompt ever asks for them.

---

## 4. Priority plan

Ordered by visual impact per unit of effort.

| # | Change | Part | Effort | Effect |
|---|---|---|---|---|
| 1 | Remove `procedural` from the planner's `preferred_source` options | §3.2 | hours | Routes 50% of entities and 79% of scatter through generation for the first time |
| 2 | ~~Per-form palette keyed to semantic type~~ → **the planner names the colour** (`palette_hex`) | §3.5 | hours | The fallback stops being grey, and two trees stop being one tree |
| 3 | Push under-reaching attachment offsets to the face | §3.4 | hours | Fixes 4% of attachments, including invisible doors |
| 4 | ~~Whole-world instance ceiling~~ (already existed); `placement_is_incidental` on a species | §3.7 | hours | 168 street lamps → 6, disclosed. Removes the lamp farm |
| 5 | Surface the generation success rate in run evidence | §3.5 | hours | Makes the real bottleneck visible instead of inferred |
| 6 | ~~**`linear_structures[]`** in the contract~~ **done** — plus `placement.anchor_m` (machine-authored) and `part_of` as collision adjacency | §3.1 | ~2 days | Walls, fences, hedges — with collision |
| 7 | ~~**`routes[]` solved first, `frontage` on buildings**~~ **done** — plus route-following navigation paths | §3.1/§3.3 | ~3 days | **The actual reason this is not a village.** 4 cottages: 45/28/13 m apart at 4 random angles → two facing rows 10.2 m apart at 0° and 180° |
| 8 | ~~**`regions[]`** for paved areas~~ **done** — painted onto the height lattice, verified in the engine | §3.1 | ~2 days | Real streets and yards; **2,239 paving instances → one integer array** |
| 9 | ~~Recalibrate or retire the embedding floors~~ **done** — curated floors measured per category, and the SUBJECT embedded instead of the brief | §3.6 | ~1 day | A dog stops matching an alpaca; a museum visitor stops matching a skeleton rogue |

**1–5 is under a week and makes current output look dramatically better without
changing what it is. 6–8 is what turns a field of objects into a settlement.**

---

## 4b. `routes` and `regions`: four hypotheses, three refuted

Measured on five settlement prompts with `eval/run_simulation_benchmark.py`.
`linear_structures` is used; `routes` and `regions` are used **zero** times. Recorded
here so none of these is retried:

| # | Hypothesis | Test | Result |
|---|---|---|---|
| 1 | The guidance named an abstraction ("the circulation spine") where the fence guidance named things | Made the triggers concrete: street, lane, path, quay → route; cobbles, paving, plaza, yard → region | **Refuted.** No change. |
| 2 | Nested `[[x,z]]` arrays are the blocker; `linear_structures` uses flat pairs and is used | Flattened `points_m` and `polygon_m` to `[x1,z1,x2,z2,…]`; readers accept both | **Refuted.** No change. |
| 3 | `extract` had only `individual` and `mass`, so a street was filed as an object or as scatter and stopped being a street before the planner read any schema | Added a third `layout` bucket with shapes `route` / `area` / `run` | **Confirmed and fixed** — the extractor now emits all three. Composition usage 2/5 → 3/5. `routes`/`regions` still 0. |
| 4 | The extractor ALSO lists the material as mass ("cobbles", "paving stones"), so the planner satisfies the street as a scattering, as it always has | Instructed it to list a layout thing once | **Refuted as a prompt fix.** The `mass` list still carried all three materials. Instruction reverted rather than kept as decoration. |

**What is established.** Nothing downstream is at fault: `routes` and `regions` validate
against the canonical contract, validate against the grammar view the model decodes
with, and survive every normalisation pass. The brief reaches the planner intact with
correct `route` and `area` entries. The planner converts `run` and drops the other two.

**The remaining difference worth testing.** A `run` needs two endpoints, which the
planner demonstrably invents. A `route` needs a centreline and a `region` needs a
polygon — more geometry, invented from a name with no dimensions attached. The next
experiment is to give `layout` entries approximate geometry at extract time, so the
planner is transcribing coordinates rather than authoring them.

## 4c. The layout bucket over-fires indoors (OPEN REGRESSION)

Measured on the 12-prompt corpus after the composition work landed. The correlation is
not subtle:

| | composition used | published |
|---|---|---|
| 3 runs | none | **all 3** |
| 9 runs | 8 of 9 | 0 |

A baker's workspace was given **1 route and 4 linear structures**. A dusty attic got a
boundary run. A storage room got a route. A kitchen does not have a street, and a run
expands into segments that then cannot place in a small room -- which is why
`native_world_plan_compilation` went 4 -> 8 and published went 6 -> 3.

The cause is that `extract` was given a third bucket and no sense of when it does not
apply. It now classifies a countertop edge as a `run` and a floor as an `area`, both of
which are technically true and neither of which is what `routes` and `regions` are for:
a room's floor is already `environment.terrain_surface`, and its furniture is already
`individual`.

**Not fixed here, deliberately.** The obvious patch -- suppress composition for indoor
places -- needs a definition of "indoor" that the extract stage can apply, and a
keyword list of place types is the noun ceiling this system keeps refusing to build. The
honest options, in order of preference:

1. Ask the extract stage the question it can actually answer: does this thing bound or
   carry movement across the WHOLE place, or is it a feature of one object? A countertop
   edge fails that test; a boundary wall passes it.
2. Gate on scale: a run shorter than some fraction of the world's own size is furniture,
   not layout. Cheap, measurable, and needs no vocabulary.
3. Let the placement failure stand and let repair drop what does not fit -- honest, but
   it spends a build to learn something the brief already knew.

Option 2 is the next experiment because it is measurable in minutes and invents no
nouns.

## 4d. Runs share their corners (DIAGNOSED, NOT FIXED)

`ENTITY_UNPLACED` = 20 is the last thing holding the settlement pass rate at 1/5. It is
not relations and not the surface any more -- both of those were fixed and measured. The
cause is in the declared coordinates:

    farmyard   fence_south (0,0)->(30,0)    fence_west (0,0)->(0,40)     <- same corner
               fence_north (0,40)->(30,40)  fence_east (30,0)->(30,40)   <- same corner
    harbour    quay_edge   (0,3)->(100,3)   timber_jetty (0,0)->(40,3)   <- ends ON the quay

Four runs bounding a yard share both endpoints of every corner, so the corner segments of
two DIFFERENT runs occupy identical ground. `part_of` exempts segments of one run from
each other and cannot help across runs, so these are real overlaps. Four of the
farmyard's segments and five of the harbour's fail there, which is most of the 20.

**The obvious fix is to inset each run's ends by half its own thickness** -- the smallest
separation for two perpendicular runs meeting at a right angle, a few centimetres on a
fence, invisible against a missing corner. It was written and then REVERTED unverified,
because the replay used to test it stripped previously-expanded segments with a broken
filter, double-expanded the specs, and manufactured the very collisions it was meant to
measure. The change may well be right; the measurement was not, and two unverified
changes had already made things worse the same day.

**How to verify it properly:** replay from `eval/reports/sim_bench_v11.json`, but re-plan
from the PROMPT rather than mutating a spec that already contains segments -- or add a
test that expands two perpendicular runs sharing a corner and asserts every segment
places. The second is cheaper and is the one to write first.

## 5. The systemic lesson

Three defects this week traced to **contract fields with no description**:

| Field | Consequence |
|---|---|
| `preferred_source` | 50% of entities and 79% of scatter bypassed generation and became primitives |
| `scatter_species` | grass blades and 5 cm needles scattered as objects at 5,000 per 100 m² |
| `terrain_surface` | `concrete` chosen for villages, silently disabling terrain relief too |

In each case the model made a defensible choice from an undocumented enum, and the
output was visibly wrong.

> **In a system where an LLM authors the spec, the schema's prose is production code.**
> A missing description is not a documentation gap — it is a defect with a rendered
> consequence.

An audit of every field the planner writes, asking *"could a competent reader choose
wrongly from this?"*, is the highest value-per-hour work available and needs no new
subsystems.

And the deeper one: **the pipeline validates correctness exhaustively and composition
not at all.** Seventeen mandatory gates confirm that every object is measured, placed
without overlap, reachable and exportable. None asks whether the result is the place
somebody described. Until the contract can express arrangement, no amount of gate
coverage will produce a village — and the one validator that notices is switched to
advisory.

---

## Appendix — how these figures were obtained

All from the local PostgreSQL instance, no code modified:

```
specs analysed          176   (simulation_specs table, full scan)
entities                1,187
scatter species         928
spatial relations       531
case-study run          run_226c728f0e1b4d5cbb0d8e5e51a44fa0
                        sim_as_a_dog_explore_a_livin_083dfb3d
                        completed · 17/17 mandatory PASS · visual_semantic FAIL
```

Counts were produced by aggregating `preferred_source`, `procedural_type`,
`terrain_surface`, `density_per_100m2`, `size_m` and `spatial_relations.relation`
across every stored spec body, and by comparing each `attached_to` offset against its
parent's declared half-extents to detect children that reach no face.

---

## §5 The ground is smaller than the world (FIXED 2026-08-26)

Measured on `run_fe54172d97b94f6ca972a87fddf8b5b5`, which **published** (17/18, no mandatory
failures) and still does not look right. Three notions of world size, none reconciled:

| quantity | value | who sets it |
|---|---|---|
| `spec.environment.dimensions_m` | **12 × 15 m** | the planner declares it |
| `terrain.width_m` / `depth_m` | **12 × 15 m** | `build_terrain` reads the declaration |
| actual content span | **31 × 39 m** | where placement put things (x: -15.4..15.4) |
| `world_bounds` | **45 × 66 m** | computed from placement |

A "living village" holding 7 wall segments, 2 houses, a dog and props was declared as
**12 × 15 m** — smaller than the content it contains. Placement ignored the declaration and
spread out; terrain was built from the declaration and stayed small.

### Why the ground really is too small

`terrain_field.gd::_ready` reads `width_m`/`depth_m` **from `world_plan.json`** and
`_build_mesh` constructs an ArrayMesh of `grid × grid` vertices spanning exactly that, which
**replaces** the BoxMesh the writer emitted. So when `builds_ground` is true (relief or
regions — this run had both) the visible ground is the FIELD, 12 × 15 m, while entities stand
out to ±15.4 m. `_sample_height` clamps outside the field, so they are seated rather than
floating, but they stand past the edge of the ground.

This is very likely the "cow on a grey plain beside floating panels" from the first
screenshot of the session.

### A fix that would NOT work, recorded so it is not retried

Widening `ground_width` in `simulation_project_writer.py:392` looks like the fix and is not:
that value only sizes the placeholder BoxMesh, and the runtime script discards it and rebuilds
the lattice from the plan's field extent. The change would have no visible effect.

### Where the fix belongs

At the point the declaration meets the contents: grow `dimensions_m` to at least the extent
the spec's own contents require — entity footprints, linear structures, routes — **before**
`build_terrain` reads it. Then terrain, placement and `world_bounds` agree by construction,
which is the same shape as every other defect fixed this session: one fact, two sources,
no reconciliation.

Expect this to change layout for every world, so it needs measuring across the settlement
set and the deterministic benchmark rather than a spot check. The benchmark's byte-identical
reproducibility will legitimately change; that is a behaviour change, not a regression.

### The other gate that cannot pass

`visual_semantic` points `qwen2.5vl:32b` at `preview/layout.png`, whose own module docstring
says it renders "plain boxes: no assets, no engine, no GPU" and "cannot tell you whether a
house looks like a house". The gate asks exactly that question, so it fails every run
regardless of asset quality. It needs an in-engine render or a different question.

### Attempted 2026-08-26, reverted — and why the obvious fix is wrong

Sizing terrain from `_content_scaled_dimensions` (the authority `_zone_geometry` already
uses) fixes the visible defect cleanly:

| | before | after |
|---|---|---|
| terrain field | 12 x 15 m | 70.5 x 88.1 m |
| entities off the ground | most | **0** |
| unplaced | — | 0 |

It was **reverted**, because it broke three tests, one of them decisively:
`test_localized_addition_re_solves_only_the_added_entity`. Making the heightfield depend
on the content means any content change resizes the field, which changes every height,
which re-seats **every** entity. Adding one entity during a repair would move the whole
world. Locality of repair (CLAUDE.md §7, "re-invoking only the responsible node") is
worth more than a tidy ground, and the suite caught the trade honestly.

Also measured and rejected: sizing the field from the zone union instead. It came out
**84.5 x 102.1 m** — larger, not smaller — because the field is centred on the ORIGIN
while the zone union is not, so mirroring its larger half inflates it. A genuinely tight
ground needs the field to stop being origin-centred, which is a change to
`terrain_field.gd` and its sampling.

**Where the fix actually belongs:** grow `environment.dimensions_m` in the PLANNER, once,
so the declaration is honest and *stable* before anything reads it. Terrain then keeps
reading the declaration exactly as it does today, no new coupling, and locality survives
because the number does not move during repair.

`tests/test_terrain_covers_content.py` holds the measurement as `xfail(strict)` — two
cases fail today and will fail loudly the moment this is fixed. The default-village case
passes and is not marked, so it guards against regression meanwhile.

### Fixed, in the planner — `_fit_declared_dimensions`

The declaration is grown once, at plan time, to the extent
`pcg.semantic.content_scaled_dimensions` says the contents need. Terrain then keeps
reading the declaration exactly as before: no new coupling, and no second opinion about
how big the world is.

Verified on the spec of `run_fe54172d97b94f6ca972a87fddf8b5b5`:

| | before | after |
|---|---|---|
| declared `dimensions_m` | 12 × 15 m | **72.67 × 90.838 m** |
| terrain field | 12 × 15 m | 72.7 × 90.8 m |
| entities off the ground | most of 14 | **0 / 14** |
| unplaced | — | 0 |
| applying the fit twice | — | **identical** |

**Idempotence is the point, not a detail.** It is what lets a localized repair re-run one
node without the world resizing underneath it, which is precisely what killed the
terrain-side version. `test_the_fit_is_idempotent_so_a_repair_cannot_move_the_ground`
asserts it, and
`test_the_unfitted_spec_is_the_defect_this_guards_against` asserts the defect is still
real without the fit — so the suite measures the fix rather than a world that never had
the problem.

Note the rule-based draft planner declares 500 × 500 m and never showed this defect. It
was LLM-path only, which is why the deterministic benchmark could not see it and the
measurement had to come from a stored production spec.

Still loose: the field (72.7 × 90.8) exceeds `world_bounds` (~42 × 67), because
`content_scaled_dimensions` returns a preferred VIEWING extent. Content stands on ground
everywhere, but there is apron beyond the playable zones. Tightening it needs the field
to stop being origin-centred — see the rejected zone-union attempt above.

---

## §6 Why worlds are ~4x their content, measured (2026-08-27)

The rendered village of `run_fc7e6f68fcd9448287dcb5bd94f7b057` held 23.9 x 16.9 m of
content in a 72.6 x 90.7 m world, with 800 pebbles spread over the empty remainder. Three
candidate causes were swept over 25 stored production specs. Two were wrong.

| lever | mean world side | fill (span/side) | unplaced | verdict |
|---|---|---|---|---|
| baseline | 100.1 m | 0.212 | 12 | — |
| **scatter headroom gated on height** | **94.6 m** | **0.229** | **12** | **kept** |
| `_CONTENT_SPREAD` 4.0 -> 1.5 | 94.6 m | 0.231 | 12 | **no effect at all** |
| `_PACKING_ALLOWANCE` 2.4 -> 2.0 | 90.4 m | 0.270 | **11** | candidate, not taken |
| `_PACKING_ALLOWANCE` 2.4 -> 1.7 | 87.2 m | 0.281 | 13 | worse |
| `_PACKING_ALLOWANCE` 2.4 -> 1.4 | 84.0 m | 0.316 | 14 | worse |
| `_PACKING_ALLOWANCE` 2.4 -> 1.2 | 82.4 m | 0.332 | 16 | worse |

### Kept: scatter headroom counts only what can block placement

`_scatter_headroom` charged every scatter species a share of the ground. Paving slabs
0.6 x **0.05** x 0.4 m at 300 per 100 m2 demanded 0.72 on their own, pinning the 0.6 clamp
and making the world 2.5x larger than its entities needed. A house sits on top of a paving
slab; a dog walks over a pebble. Species shorter than `_STEPPABLE_HEIGHT_M` (0.25 m, the
same number the planner already calls "ground detail rather than an object") now take no
share. The 8 m canopy trees that motivated the original rule still do.

Across 48 stored specs, **25 were pinned at the clamp; gating leaves 5** — and those five
are the cases the rule exists for. Unplaced count unchanged at 12, so nothing paid for it.

### `_CONTENT_SPREAD` is inert

Sweeping it 4.0 -> 1.5 moved the mean world side by **zero**. The `preferred` term it feeds
is never the binding one; the packing growth loop is. Worth recording because it looks like
the obvious knob and is not one.

### `_PACKING_ALLOWANCE` 2.0 is strictly better on this sample, and was NOT taken

2.0 improved fill (0.229 -> 0.270) *and* reduced unplaced (12 -> 11). Both directions, so
it is not a trade. It was left alone regardless: the existing 2.4 carries its own recorded
measurement ("at 1.3, ~60% occupancy, 512 attempts"), and overturning a measured constant
on 25 stored specs — when the sweep also shows unplaced rising again immediately below 2.0
— needs the settlement set and the full benchmark, not one sample. Recorded here so the
decision can be made with evidence rather than repeated from scratch.

### What this does not fix

Fill is still ~0.23, so worlds remain roughly four times their content span. The apron and
the thin scatter spread over it are unchanged in any way a viewer would notice. The binding
constraint is the packing loop's `occupied x _PACKING_ALLOWANCE**2 / headroom`, and shrinking
it trades directly against placement success past 2.0.
