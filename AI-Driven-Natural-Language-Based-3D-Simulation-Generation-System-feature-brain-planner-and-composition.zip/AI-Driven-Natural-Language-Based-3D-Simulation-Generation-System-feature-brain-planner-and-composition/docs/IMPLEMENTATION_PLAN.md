# Implementation Plan (P0–P6)

> Historical game-prototype schedule. The user-approved production objective is
> now the neutral simulation plan tracked by
> [`FULL_SYSTEM_FUNCTIONAL_CHECKLIST.md`](FULL_SYSTEM_FUNCTIONAL_CHECKLIST.md)
> and [`SERENDIB_PRODUCTION_STATUS.md`](SERENDIB_PRODUCTION_STATUS.md). New work
> must use `SimulationSpec` and `/api/v1/simulations`; the phases below remain
> useful only for legacy compatibility and historical research evidence.

12 months, Jul 2026 – Jun 2027, 4 members (M1 Platform, M2 Brain/ML, M3 Engine/Build, M4 3D Content/Validation). Each phase ends with a demo + written go/no-go gate signed by all four members.

**Current phase: P2 — Brain online.** P0 (foundation + golden-game gate) and P1 (deterministic spine) are complete; P2 has guided-JSON planning, the Arbiter, the 8-gate validation stack, localized repair, live SSE progress, and a CI-enforced 20-prompt benchmark. Status detail lives in `IMPLEMENTATION_CHECKLIST.md`.

> **Post-v1 direction (team-agreed 2026-07-13, ADR-0002 / ADR-0003):** after v1 ships, the platform grows beyond games into **education + visualization domain packs** on the same engine, and generation evolves from template-labelling to **compositional, "thinking-based" uniqueness** (richer LLM-authored specs → v2 behavior-graph composition), with free gameplay code permanently banned. v1 scope stays frozen until then.

## Phase P0 — Foundation (Jul–Aug 2026)

**Goal:** repo, docs, CI skeleton, VPS Compose skeleton, Godot build investigation, canonical schema v2, one hand-built golden game.

Key tasks: monorepo + CLAUDE.md + docs ✅ · `.gitignore`/`.env.example` ✅ · Compose skeleton (FastAPI+Postgres+Redis) ✅ · Next.js skeleton · FastAPI hello-job endpoint · `contracts/game_spec.schema.json` v2 + validator ✅ (draft) · GitHub Actions lint/test skeleton · document pinned Godot tag + matching Emscripten · golden-game planning.

**Gate:** golden game plays in browser, exports ≤90 MB, works on Chrome/Firefox/Edge/Safari. **If this gate fails, do not proceed — reduce scope until browser export is proven.**

## Phase P1 — Deterministic spine (Sep–Oct 2026)

**Goal:** hand-written spec → deterministic PCG → Serendib project assembly → web export, **zero manual steps**.

Key tasks: PCG zone graph (BSP/rooms/caves/WFC, seeded) · GridMap materialization + elevation + ramps · navmesh + placement (distance field, rejection sampling on real bounding boxes) · controller/AI/door templates · template registry · project writer · build/export pipeline · job states · basic validation + GreedyObjectiveBot v1 · Serendib rebrand v0.1 via CI.

**Gate:** hand-written valid game_spec builds into a playable web game automatically.

## Phase P2 — Brain online (Nov–Dec 2026) — MID DEMO

**Goal:** prompt → spec → repair → playable game end-to-end.

Key tasks: one agent harness shape ×9 agents · vLLM guided_json + xgrammar · RAG (bge-m3 + pgvector) + registries with allowlists · arbiter (priority stack, logged decisions) · 8-gate validation stack · localized repair loop (≤3/class) · live progress UI · repair attempt tracking.

**Gate:** user prompt generates a playable browser game end-to-end; ≥80% of 20 frozen test prompts pass unaided.

## Phase P3 — Asset farm + AI dock (Jan–Feb 2027)

**Goal:** generated props/textures/skybox/audio + Serendib Assist dock.

Key tasks: asset cache · generation pipelines (SDXL → TRELLIS.2 → Blender → GLB; Stable Audio SFX) · per-game style anchor · license tracking wired into the pipeline · Serendib Assist dock (spec inspector, NL edit, diff viewer, sync API) · hybrid deploy live (Pages + R2 + VPS + tunnel).

**Gate:** user downloads a project, opens it in Serendib, requests an edit via the dock, and re-exports.

## Phase P4 — Fine-tune & evaluation (Mar 2027)

**Goal:** tuned planner behind a flag + evaluation harness.

Key tasks: benchmark prompts frozen · ablation runners · metrics dashboard · distillation dataset (teacher outputs, validator-filtered) · QLoRA fine-tune Qwen3-8B — **behind a flag; untuned 32B stays default**.

**Gate:** evaluation data proves what improves reliability; nightly regression benchmark green.

## Phase P5 — User study & polish (Apr–May 2027)

**Goal:** controlled user study, UX improvements, failure fixing.

Key tasks: ethics approval + DPIA **first** · user testing (novice + intermediate; editability, SUS, continuation intent) · developer sub-study (one AI-dock task) · bug fixing · performance optimization · documentation polish.

**Gate:** ablations A–F executed; studies run and analyzed; latency/budgets within targets.

## Phase P6 — Ship & dissertation (Jun 2027)

**Goal:** defense/demo package.

Key tasks: final release + deployment docs · final testing · 5 cached showcase games + 1 rehearsed live generation (×2) · dissertation artifacts · demo script · backup plan (never bet the demo on live infrastructure alone).

## Why this order

Golden game before AI (proves the hardest external constraint — 3D in the browser); deterministic spine before brain (specs need a guaranteed-working target); assets after spine (failures degrade gracefully); fine-tuning late (ablation, not dependency); evaluation fast because the harness is telemetry from P2 onward.

---

# Outstanding Work Register (opened 2026-08-07)

Derived from a full audit of the codebase against the report, not from memory.
Verification basis: whole test suite green (~770 tests, exit 0, a few skips); no
TODO or FIXME anywhere in first-party code (all such markers are in vendored
TripoSR); 28 unchecked items in `FULL_SYSTEM_FUNCTIONAL_CHECKLIST.md`.

The register is ordered by *consequence of the gap*, not by size. Tier 1 exists
because the report describes these as delivered, so the gap is now asserted
rather than merely present.

## Tier 1 — Claimed in the report, absent from the code

| # | Item | Est. | Notes |
|---|---|---|---|
| 1 | `xr_runtime.gd`: OpenXR init, XROrigin, two controllers, teleport arc validated against the navmesh, smooth locomotion | 1 d | Logic testable without a headset; frame rate is not |
| 2 | Terrain heightfield: seeded noise, slope/water/region masks | ~done | **Heightfield and slope done, 2026-08-20** ([ADR-0012](adr/ADR-0012-one-heightfield-generated-once-and-shipped.md)). Water/region masks deliberately not attempted — see note |
| 3 | Material synthesis: albedo/normal/roughness, palette fallback | ~0.5 d left | **Albedo done, 2026-08-08.** See note below — the stated premise was wrong |
| 4 | RAG corpus ingestion: harvest specs from clean runs into retrieval | 2–4 h | Retrieval today is 10 hand-written notes |

**Correction to item 3.** "Asset-descriptor field already exists" is not true.
`contracts/asset_descriptor.schema.json` has no material field and sets
`additionalProperties: false`, so nothing could record a material assignment.
The real cause of "nothing has a surface" was more basic: the ground carried no
material at all and drew as default white.

Done ([ADR-0010](adr/ADR-0010-surfaces-are-synthesised-from-a-named-family.md)),
albedo on both sides of the divide:

- **Ground and paths** — Godot `FastNoiseLite` + triplanar materials emitted by
  the writer, selected by a new closed `environment.terrain_surface` enum, with
  a neutral default recorded in the approximation record. Zero bytes.
- **Procedural meshes** — a seamless value-noise tile baked into each generated
  GLB as `baseColorTexture` with box-projected UVs, keeping the builder's palette
  colour as `baseColorFactor` (glTF multiplies the two, so per-piece colours
  survive). Baked in the asset farm so the textured mesh is what gets measured
  and hashed; `NOISE_VERSION` is in the cache key so flat meshes are not reused.
  ~5 KB per asset, ≈4.2 MB for 400 unique assets.

Still open, roughly half a day:

- **Normal and roughness maps.** This is albedo only, so surfaces have grain but
  no relief — the remaining part of "albedo/normal/roughness".
- **The asset-descriptor `material` field**, which still does not exist. Without
  it the palette assignment lives only inside the GLB and cannot be inspected,
  validated or reported, and nothing records which tier gave a mesh its surface.
  Needs `contracts/asset_descriptor.schema.json` extended (it sets
  `additionalProperties: false`) and `qa_gate.py` surfacing the material list it
  already parses out of the glTF.

**Dependency for item 2 — resolved 2026-08-20.** The claim that this was "the one
place the flat-ground assumption is written down" was wrong: there were **five**,
and two of them (`INVALID_TERRAIN_SUPPORT` asserting a body's underside sits at
`y=0`, and zone bounds with `min[1] = 0.0` checked on all three axes) surfaced only
when a plan was actually solved on relief. The scatter sampler now consults the
field and enforces the limit; it declares the constraint ignored only when no field
is supplied, which is a narrower and still-true statement.

**Water and region masks are NOT done, and are blocked rather than pending.**
Deriving water from the open-vocabulary `terrain` string is the keyword-matching
antipattern `simulation_spec.schema.json` warns against in its own
`terrain_surface` description. It needs a contract field that does not exist —
the same shape of gap as the absent asset-descriptor `material` field in ADR-0010.

## Tier 2 — Quality and correctness

| # | Item | Est. |
|---|---|---|
| 5 | Move the layout preview before asset generation | 30 m |
| 6 | Raise layout preview resolution (960x540 constant in `pcg/preview.py`) | 10 m |
| 7 | Delete `services/brain/build/lib` and gitignore it (regression: it once shadowed source) | 10 m |
| 8 | Solve the road/path graph before buildings; keep it connected | 1 d |
| 9 | Keep door approach areas clear and reachable from both required sides | 0.5 d |
| 10 | Interior/exterior containment and portals | 1–2 d |
| 11 | Asset LODs and material validation | 1 d |
| 12 | Roof z-fighting (visible as white speckling at capture resolution) | 1 h |

## Tier 3 — Evidence the report depends on

| # | Item | Est. | Unblocks |
|---|---|---|---|
| 13 | Re-run the corpus loop | 2 h GPU | 31%/54% predate the six determinism fixes |
| 14 | Generate the three worlds named in the conclusion (rainforest, subway, Mars base) | 1 h | No imagery for them exists |
| 15 | Browser automation for web screenshots and real end-to-end tests | 2 h | Heavy dependency; needs approval |
| 16 | Run the QLoRA fine-tune | GPU hours | Ablation condition E |
| 17 | Deploy and freeze the independent text critic | 0.5 d | Gate 13 evaluation |
| 18 | Mutation tests proving the critic catches omitted prompt contracts | 0.5 d | Critic credibility |
| 19 | Exercise three-cycle repair with runtime and visual faults | 0.5 d | Repair chapter evidence |
| 20 | Fill the three reproduction fields (repo URL, commit, date) | 2 m | Appendix 3 |

## Tier 4 — Production hardening

The 28 unchecked items in `FULL_SYSTEM_FUNCTIONAL_CHECKLIST.md`, predominantly
scale and compliance rather than core function: regional Postgres/Redis/KMS/
OIDC/WAF, 100-concurrent load and fairness, backup and disaster recovery,
cross-tenant isolation, external penetration test, the RLS superuser role,
signed binaries and SBOMs, the capability SDK conformance suite, licensed asset
packs, upload malware scanning, DPIA and child-safety assessment, CI #130.

## Tier 5 — Future work

Automatic rigging. The only item with no specified integration path: inferring a
skeleton and binding weights on generated geometry of unknown topology is a
research problem rather than an integration task.

## Suggested sequence

1. Items 5, 6, 7, 12 — under two hours in total.
2. Item 2 (terrain), which also clears the `ignored_constraints` line.
3. Item 13 (re-run corpus) for honest headline numbers.
4. Items 1 and 4, then 14 for figures.
5. Item 3, then 8 and 9, then the Tier 3 evidence items.


---

# Asset quality plan (added 2026-08-29)

## Why this plan exists

`run_5246669909ea46da8687ab8f4fa040e3` **published** — 17 of 18 gates, no mandatory
failures — and still looks like grey boxes on a plain. That is the whole finding. The
pipeline plans, sizes, places, validates and ships a world correctly; what it ships is
built out of primitives.

```
tiers: curated 1, cache 7, procedural 12, generated 0
```

Twelve of twenty assets are procedural boxes and none was generated. No further work on
planning, placement or validation changes what a viewer sees. The remaining problem is
entirely one of what there is to draw with.

## The root cause: the planned generator has never been switched on

| | |
|---|---|
| CLAUDE.md §4 specifies | SDXL -> **TRELLIS.2** -> Blender headless -> GLB |
| `.env` actually sets | `ASSET_GEN_BACKEND=local` |
| `backends_local.py` runs | SDXL -> rembg -> **TripoSR** -> decimate |

`backends_gpu.py` implements the TRELLIS-2 path in full (WSL `Ubuntu-24.04`,
`/root/TRELLIS`, CUDA 12.8) and `docs/ASSET_FARM_SETUP.md` documents the setup. It has
never been enabled, so every run has used the fallback.

The fallback is the visual defect. TripoSR emits **vertex-coloured** meshes — never
textured — normalised to 1.5 units at ~1,000-2,800 triangles. Measured on the last
completed run, every generated/cached mesh is the same 1.5-unit blob regardless of what
was asked for:

| entity | declared | TripoSR produced |
|---|---|---|
| `ent_dwelling_a` | 8.0 x 4.0 x 6.0 | 1.22 x 1.43 x 1.50 |
| `ent_dwelling_b` | 8.0 x 4.0 x 6.0 | 1.48 x 1.28 x 1.50 |
| `ent_gatehouse` | 2.0 x 2.5 x 1.0 | 1.26 x 1.33 x 1.50 |

Stretched to a declared house, a 1.5-unit blob becomes a smeared slab.

Separately, the flat white planes seen in earlier renders were `banner_red`, resolved for
briefs reading "a detached residential building shell" — fixed 2026-08-29, see
`VILLAGE_GAP_ANALYSIS.md`, and verified absent in `run_93c70fae32134e5a85c3c3c410bd0c3f`.

## Phases

### Phase A — Enable TRELLIS-2 (largest win)
Stand up TRELLIS-2 per `ASSET_FARM_SETUP.md`, set `ASSET_GEN_BACKEND=gpu`, generate one
world and compare meshes against TripoSR side by side. TRELLIS-2 produces **textured**
meshes at far higher fidelity. Requires WSL and a multi-gigabyte model download.
VRAM sequencing is already in place — the planner unload is implemented and verified.

### Phase B — Raise generation yield
Generation refuses more than it delivers. Two known refusals:
`concept subject gate failed: expected exactly one significant foreground component,
found 3` (which killed both dwellings), and characters by design (a rig cannot be
generated). Fix SDXL prompt shaping for building briefs and add one bounded retry with a
tightened concept prompt.

### Phase C — Make the procedural floor look deliberate
`_building_shell` already exists (`building_shell_v5_outward_roof_lifted_ceiling`).
Walls as boxes is correct; houses as boxes is not. Route every `structure` that fails
generation to `building_shell` rather than `semantic_box`, so the worst case is a
house-shaped house. No setup required, so this is the safety net that holds whether or
not Phase A lands.

### Phase D — Materials
Procedural meshes carry vertex colours only, which reads as flat plastic. Add simple PBR
material properties — roughness, subtle albedo variation — with no texture files.

### Phase E — A real 3D asset library
The kit owns 10 props, ~19 characters and **zero buildings**, which is why a house can
never be matched and must always be generated or approximated. Vendor CC0/MIT packs
(product-path clean per CLAUDE.md §14), describe every model for the semantic matcher,
extend `STRUCTURE_MODELS`, and log each pack in `docs/licensing_ledger.csv`. Serves both
the web build and the downloadable engine project, since both read the same kit.

## Sequence

C and E first — neither needs setup and both raise the floor immediately. Then B, then A
once WSL is available. D last, as polish.


---

# Vision in the loop, and the low-poly target (verified 2026-08-30)

## The target

Reference: stylised low-poly worlds — a village of pitched-roof cottages along a road
with a fenced pond and trees; a factory of red-brick sheds and chimneys; a forest
clearing. **This is the product's own stated art direction**, not a new ambition:
CLAUDE.md §1 freezes it as "browser-playable, **stylized low-poly** 3D", and
`agents/style.py` names "low-poly stylized" the frozen v1 look.

So the question is not whether the target is in scope. It is why the system does not
reach it. Five findings, each checked against the code and the database rather than
assumed.

## Finding 1 — generated assets share no art direction (BLOCKS the target)

`agents/style.py` derives a per-world style anchor from genre and lighting; the backend
prepends it to every SDXL prompt (`backends_gpu.py:131`); the pipeline reads it from
`spec.meta.style_anchor`. The whole chain works.

**The simulation planner never writes it.** Measured: `style_anchor` appears in
**0 of 30** stored simulation specs, and the string does not occur in
`simulation_planner.py` at all. Its docstring describes exactly the consequence:

> "each asset's SDXL prompt is only its own brief, so a crypt's sarcophagus and its
> torch can come out in different styles — the game looks incoherent."

Every generated asset is therefore made in isolation. A cottage, a cart and a tree each
get their own look, and no amount of placement or lighting work makes an incoherent set
read as one world. **This is the single largest blocker to the reference style.**

## Finding 2 — the system has eyes and ignores them

`qwen2.5vl:32b` and `qwen2.5vl:7b` are installed. Canonical in-engine views are captured
every run (`capture_canonical_views`), and the critic returns STRUCTURED findings
("the environment overview does not visually represent 2 detached houses").

`ADVISORY_LAYERS = frozenset({"visual_semantic"})` — the verdict is reported and
discarded. Nothing acts on it.

**Correction to the record:** this plan previously claimed the gate was mis-wired and
judged a schematic. That was wrong. It reads the real renders and has been the most
accurate signal in the system; its verdicts were dismissed rather than believed.

## Finding 3 — the planner never sees where things end up

`pcg/preview.py` renders the plan as plain boxes in ~200 ms, and its docstring states the
purpose: "the planner authors a VISUAL artifact with no way to see one", listing the
failure modes "an empty plain, everything in one corner, the player nowhere near the
content". The preview is produced and never shown to any model. Layout intent is written
blind and never checked.

## Finding 4 — the repair loop cannot use sight

`bounded_localized_repair` runs at `native_pipeline.py:365`, BEFORE the build. The visual
verdict arrives around line 710, after it. The eye and the hands exist and are not
connected.

## Finding 5 — the library was pre-empting generation (FIXED)

CLAUDE.md S5 specifies `cache -> curated (>=0.85) -> generate`. The code pre-empted
generation at the curated FALLBACK floors (0.64 character / 0.70 prop), so an approximate
library match claimed briefs the generator should have made. Fixed 2026-08-30:
`PREEMPT_GENERATION_FLOOR = 0.85`. Measured after: a windmill and a garden hose now
generate; a fence, cart and wall (owned near-exactly) still come from the library.

That is the intended relationship — **generation is the product, the library is external
help** — and it is now what the code does.

## Also missing

No `water` surface family, so the reference pond is not expressible. Small, additive.

## The plan

### Step 1 — one art direction per world (unblocks the style)
Derive `meta.style_anchor` in the simulation planner from `environment.semantic_type`,
`time_of_day` and `weather`, reusing `agents/style.py`. Deterministic, so a spec's look is
reproducible (rule 14). Every generated asset then shares a palette and material
language. **Highest value: nothing else makes a generated set look like one world.**

### Step 2 — show the planner its own layout (fixes placement)
Render `preview/layout.png` (already built, ~200 ms) and put it to `qwen2.5vl:7b`: is the
content clustered along the route, or scattered on an empty plain? Feed the answer back
into placement BEFORE the 20-minute build. This is the cheap loop the preview module was
written for and never got.

### Step 3 — let the verdict act (closes the loop)
Move `visual_semantic` out of `ADVISORY_LAYERS`, map its `MISSING_ENTITY` findings to a
repair class, and re-resolve only those assets. Build -> look -> "the houses are not
there" -> regenerate those -> rebuild, bounded by the existing 3-attempt cap.

### Step 4 — water, and the remaining content gaps
Add a `water` surface family and a `pond` region so a fenced pond is expressible.

## GPU, decided by measurement

- `qwen2.5vl:7b` is **6 GB** — small enough to stay resident during planning and
  placement. Use it for the in-loop checks of Steps 2 and 3.
- `qwen2.5vl:32b` is **21 GB** — final verdict only, after the planner unloads.
- The tuned planner (`promptplay-planner-8b`) is **16 GB** against the 27B teacher's
  **17 GB**: it does NOT free VRAM. Its case is latency (11.8 s vs ~109 s p50, Ablation E,
  equal pass rate) and it stays flag-gated, because its ledger row records training on 150
  pairs against the 500 the governed runbook requires.
- TRELLIS needs >=24 GB of 32 GB, so the planner must unload before generation either
  way. `_unload_planner_for_asset_generation` does this and is verified working.

## Honest assessment of the target

Reachable in style and content: low-poly cottages, roads, fences, trees and a factory are
all within generation plus the procedural vocabulary (22 forms) and the vendored CC0 kits.

Not reachable by tuning alone: the references are hand-authored sets with one artist's
palette. The nearest honest equivalent is Step 1 — one style anchor per world — which is
what makes an independently generated set cohere. Without it the target is not
approachable at all; with it, it is a matter of asset quality rather than of kind.
