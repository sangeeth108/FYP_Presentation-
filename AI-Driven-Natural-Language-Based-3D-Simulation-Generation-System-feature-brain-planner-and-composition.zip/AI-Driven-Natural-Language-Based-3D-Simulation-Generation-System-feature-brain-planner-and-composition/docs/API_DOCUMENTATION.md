# API Documentation

Base: `https://<vps-host>/api/v1` (FastAPI, OpenAPI auto-docs at `/docs`). Update this file whenever an endpoint changes.

## Key surface (from the planning report — implement incrementally)

| Method & path | Purpose | Request → Response | Phase |
|---|---|---|---|
| `POST /api/v1/games` | Start a generation | `{prompt, seed?, options{camera, genre?}, budgets?}` → **202** `{game_id, job_id}` | P0 (hello-job) → P2 (real) |
| `GET /api/v1/jobs/{id}` | Job status snapshot | → `{state, phases[], artifacts[]}` | P1 |
| `WS /api/v1/jobs/{id}/events` | Live progress stream | phase/asset/log/verdict events | P2 |
| `GET /api/v1/games/{id}/spec` | Canonical spec | → spec JSON, `ETag: <spec_hash>` | P1 |
| `POST /api/v1/games/{id}/repair` | Re-enter REPAIRING with operator hints | `{hints}` → 202 | P2 |
| `POST /api/v1/engine/sync` | Serendib Assist round-trip | `{nl_request \| spec_patch}` → `{patch, regen_jobs}` | P3 |
| `GET /api/v1/games/{id}/download/{kind}` | Signed R2 URL | `kind ∈ {project, web}` → `{url, expires_at}` | P1 |
| `GET /healthz` | Liveness | → `{status: "ok"}` | P0 |

## Conventions

- **202 + job id** for anything long-running; never block a request on generation.
- Errors: RFC 7807 problem+json style — `{type, title, status, detail, errors:[{code, path, message, hint}]}`.
- All spec fields `snake_case`. IDs: `game_id = g3d_<slug>_<hash>`, `job_id = uuid`.
- Auth: none in P0–P2 dev (rate-limit by IP); token auth added before public exposure (P3).
- Versioned under `/api/v1`; breaking changes require `/api/v2` + ADR.

## P0 deliverable ("hello job") — ✅ IMPLEMENTED (2026-07-07)

`POST /api/v1/games` accepts a prompt, writes `games` + `jobs` rows, enqueues a Celery task that advances the job to `DEPLOYED`, and returns 202 `{game_id, job_id}`. `GET /api/v1/jobs/{id}` shows the state. `GET /healthz` → `{"status":"ok"}`. This proves web → API → queue → worker → DB round-trip before any AI exists.

**Implemented shapes:**
- `POST /api/v1/games` body `{prompt (8–2000 chars), seed?, options?{genre?, camera?}}`; invalid genre/camera or short prompt → **422**. Response **202** `{game_id: "g3d_<slug>_<hash>", job_id: <uuid>}`.
- `GET /api/v1/jobs/{id}` → `{game_id, state, detail, phases[], artifacts[]}`; unknown id → **404**. (`phases`/`artifacts` populate once the S0–S8 pipeline exists.)

Live code: `services/brain/` (routers in `api/`, models/schemas in `core/`, Celery in `worker/`). Not yet implemented: WS events, spec/repair/engine-sync/download endpoints (P1–P3).
