# Runbook — Local Development Setup

Applies to every dev machine. Heavy GPU tooling is only for the 5090 workstation (see `GPU_WORKER_SETUP.md`).

> **Just want the whole system running end to end on one PC (prompt → playable game → downloadable project, $0, no cloud)?** That is [`RUN_FULL_LOCAL.md`](RUN_FULL_LOCAL.md) — this page is the prerequisites it assumes.

## Prerequisites (all platforms)

| Tool | Version | Why |
|---|---|---|
| Git | latest | version control |
| Docker Desktop / Engine + Compose | latest | local VPS-mirror stack |
| Node.js | 20 LTS+ | Next.js frontend |
| Python | 3.11+ | brain, worker, scripts |
| uv (recommended) or pip | latest | Python dependency management |
| VS Code + Python/ESLint/Prettier extensions | — | shared editor baseline |

## Windows (PowerShell)

```powershell
# Check what you already have
git --version; node --version; python --version; docker --version

# Install missing tools via winget (each command explained):
winget install Git.Git                      # version control
winget install OpenJS.NodeJS.LTS            # Node 20 LTS for Next.js
winget install Python.Python.3.12           # Python for backend + scripts
winget install Docker.DockerDesktop         # containers (needs WSL2 enabled)

# Clone (after the GitHub repo exists) and enter
git clone <repo-url> promptplay; cd promptplay

# Copy env template — NEVER commit .env
Copy-Item .env.example .env

# Run the P0 sanity checks
python scripts/validate_contracts.py        # schema + examples valid?
python scripts/check_licenses.py            # ledger complete?

# Bring up the local stack (after brain Dockerfile exists)
docker compose up -d
```

## macOS / Linux

```bash
# macOS: brew install git node python@3.12 docker
# Debian/Ubuntu: sudo apt install git nodejs npm python3 python3-venv docker.io docker-compose-plugin

git clone <repo-url> promptplay && cd promptplay
cp .env.example .env                # never commit .env
python3 scripts/validate_contracts.py
python3 scripts/check_licenses.py
docker compose up -d
```

## Per-workspace setup (when implementation starts)

```bash
# Frontend (P0: after create-next-app scaffolds apps/web)
npm install            # root — installs workspaces
npm run dev:web        # http://localhost:3000

# Brain (P0: after services/brain gets its pyproject.toml)
cd services/brain
uv venv && uv pip install -e ".[dev]"     # or: python -m venv .venv && pip install -e ".[dev]"
uvicorn main:app --reload                 # http://localhost:8000/docs
```

## Common mistakes

- Committing `.env` — the `.gitignore` blocks it, but never force-add it.
- Running Postgres/Redis on public interfaces — Compose binds them to 127.0.0.1; keep it that way.
- Installing the Godot build toolchain on every machine — only the engine machine(s) need it (`GODOT_BUILD.md`).
