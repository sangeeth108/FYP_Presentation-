# Runbook — Hetzner VPS Setup

Target: one CX32/CX42 VPS running the always-on stack (FastAPI brain, PostgreSQL+pgvector, Redis, Celery) via Docker Compose. Owner: M1.

## 1. Provision

1. Create the Hetzner Cloud project; add a CX32 (upgrade to CX42 at P3 if needed).
2. Choose Ubuntu LTS; add **SSH key auth only** (disable password auth).
3. Set a spend alert matching the chosen budget tier.

## 2. Harden (before anything else)

```bash
adduser deploy && usermod -aG sudo,docker deploy    # never operate as root
ufw default deny incoming && ufw allow OpenSSH && ufw allow 443/tcp && ufw enable
# Postgres/Redis are NOT exposed: Compose binds them to 127.0.0.1 only
apt update && apt install -y unattended-upgrades docker.io docker-compose-plugin
```

## 3. Deploy the stack

```bash
git clone <repo-url> /opt/promptplay && cd /opt/promptplay
cp .env.example .env      # fill values from the team password manager — never from chat
docker compose up -d
curl -s localhost:8000/healthz    # expect {"status":"ok"} once the brain exists
```

## 4. TLS / reverse proxy

Put Caddy or nginx (or Cloudflare proxied DNS) in front of `127.0.0.1:8000` for HTTPS. Config lives in `infra/hetzner/` when written.

## 5. Backups

- Nightly `pg_dump` → R2/B2 (cron + rclone or a sidecar container). Test a restore once per phase.
- Keep the last 3 Serendib engine releases downloadable.

## 6. Verify the P0 gate item

"Hello job" passes: `POST /api/v1/games` returns 202, the Celery task runs, `GET /api/v1/jobs/{id}` shows completion.

## Common mistakes

- Exposing DB ports publicly (bind to localhost — checklist explicitly warns).
- Secrets in the repo or pasted into chat — vault only.
- Skipping the spend alert, then discovering a surprise bill during evaluation crunch.
