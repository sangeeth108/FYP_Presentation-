# Runbook — GPU Worker Setup (RTX 5090 workstation)

The workstation does **all heavy work** (LLM serving, asset generation, Godot builds, bots) and connects **outbound-only**. It never opens an inbound port. Owner: M2 (models) + M4 (asset tooling).

## 1. Base software

- Latest NVIDIA driver + CUDA toolkit compatible with vLLM/PyTorch.
- Python 3.11+, Docker (optional but preferred — same images as cloud failover), Git.
- vLLM (primary LLM server) and/or Ollama (fallback).
- ComfyUI + SDXL/FLUX-schnell checkpoints (P3), TRELLIS.2 (P3), Blender headless (P3).
- Godot/Serendib headless build + export templates at the pinned tag.

## 2. Outbound-only tunnel (security-critical)

Choose one (record the decision in `DECISION_LOG.md`):

- **Cloudflare Tunnel:** `cloudflared tunnel create promptplay-worker` — worker reaches the VPS queue through Cloudflare; no inbound.
- **Tailscale:** join VPS + workstation to one tailnet; ACLs allow worker→VPS only.

Verify: `netstat`/`ss` shows **no listening ports** reachable from outside the LAN.

## 3. VRAM time-slicing (the 32 GB constraint)

The 32B planner, TRELLIS.2 (≥24 GB), and diffusion pipelines cannot be co-resident. The worker daemon sequences modes per job phase:

```
MODE plan       → load planner (vLLM)          → unload
MODE assets     → load SDXL / TRELLIS.2 / audio → unload
MODE validation → Godot headless + bots (low VRAM)
```

Never assume co-residency. OOM = a scheduling bug, not a hardware problem.

## 4. Worker daemon behavior

- Pull jobs from the cloud Redis queue (`WORKER_POLL_INTERVAL_SECONDS`).
- Stream phase progress back to the brain (drives the live UI).
- Cache model weights + export templates on disk; keep a documented re-download script.
- On shutdown/offline: the queue buffers jobs — nothing is lost.

## 5. P0 spike checklist

☐ vLLM serves the pinned planner and answers a guided-JSON request.
☐ Tunnel up; worker pulls one hello-job end-to-end.
☐ TRELLIS.2 VRAM fit verified (can slip to P3, but do it before committing the asset plan).
☐ No inbound ports (verified with a port scan from outside).

## Failover (demo insurance)

Rented GPU (RunPod/Vast.ai) runs the same worker container images. Keep the image pushed to a registry and this runbook's env-var list current. See `DEPLOYMENT_RUNBOOK.md`.
