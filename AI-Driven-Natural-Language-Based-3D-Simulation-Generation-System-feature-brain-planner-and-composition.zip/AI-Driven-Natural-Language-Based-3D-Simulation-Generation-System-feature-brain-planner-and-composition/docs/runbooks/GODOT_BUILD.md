# Serendib Engine build runbook

## Reproducible pins

| Component | Pin |
|---|---|
| Godot upstream | `4.6.3-stable` |
| Emscripten SDK | `4.0.11` (Serendib reproducible build pin) |
| Web renderer | Compatibility/WebGL2, single-threaded |

Godot’s official 4.6 web build documentation requires Emscripten 4.0.0 or
newer. Serendib pins 4.0.11 inside that supported range for reproducibility:
<https://docs.godotengine.org/en/stable/engine_details/development/compiling/compiling_for_web.html>.

The upstream version must match `engine/serendib/rebrand.py`,
`.env.example`, the patch series and CI. Never invent or pre-announce an
unreleased upstream tag.

## Prepare upstream

```bash
git clone --depth 1 --branch 4.6.3-stable \
  https://github.com/godotengine/godot.git engine/serendib/upstream

python engine/serendib/rebrand.py --upstream engine/serendib/upstream
python engine/serendib/verify_branding.py
```

The rebrand command verifies the exact tag, applies the patch series and checks
that the upstream MIT licence and Godot attribution remain present.

## Build

Install the platform’s documented compiler prerequisites, Python, SCons and the
pinned Emscripten SDK. From the patched upstream checkout:

```bash
scons platform=windows target=editor production=yes
scons platform=web target=template_release production=yes threads=no
scons platform=web target=template_debug production=yes threads=no
```

Use the equivalent `platform=linuxbsd` editor target for Linux builders. CI
must start from a clean upstream clone and produce checksummed, signed binaries
and software bills of materials.

## Mandatory release checks

- `python engine/serendib/verify_branding.py`
- editor launches with Serendib title, icon, project manager and About dialog;
- boot, loading, runtime splash and web shell show Serendib identity;
- no visible inherited Godot product branding outside required attribution and
  licence surfaces;
- both desktop and web export templates build from the same commit;
- generated projects import and export without errors;
- attribution, MIT licence viewer and non-affiliation notice remain intact.

The engine has not passed the release gate merely because patches apply. A
clean CI build plus launch screenshots is required.
