# Run Serendib locally

Local mode is for development and deterministic tests. Without a configured
Serendib binary, independent critic, vision validator and dual-platform probes,
generation is expected to end in a truthful failed-validation state.

## Prerequisites

- Python 3.12
- Node.js 20+
- Docker Desktop for PostgreSQL/Redis/Celery, or equivalent local services
- optional pinned Serendib 4.6.3 editor plus export templates

## Configure

Copy `.env.example` to `.env`. Keep `PROMPTPLAY_ENV=development`. Configure
`GODOT_BIN` only with the verified pinned Serendib binary.

## Start services

```bash
docker compose up --build
npm install
npm run dev:web
```

Open <http://localhost:3000>. The API is at <http://localhost:8000>.

## Run without containers

```bash
cd services/brain
alembic upgrade head
uvicorn main:app --reload
```

Start workers in separate shells:

```bash
celery -A worker.celery_app worker -Q planning,privacy -c 2 -l info
celery -A worker.celery_app worker -Q serendib_build -c 1 -l info
```

## Verify

```bash
python scripts/validate_contracts.py
python engine/serendib/verify_branding.py

cd services/brain
python -m pytest tests -q

cd ../../services/worker
python -m pytest tests -q

cd ../..
npm run build:web
```

Do not treat a local proxy, missing validator or `NOT_RUN` gate as a successful
artifact. The simulation report is the release authority.
