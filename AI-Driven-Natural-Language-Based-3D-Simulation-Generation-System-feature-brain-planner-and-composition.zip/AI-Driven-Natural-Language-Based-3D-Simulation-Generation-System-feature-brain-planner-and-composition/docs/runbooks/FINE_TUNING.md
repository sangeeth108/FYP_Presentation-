# Governed planner and ranker fine-tuning

Production learning is periodic, consent-qualified and manually approved. It is
not online learning, and no runtime simulation depends on an LLM.

## Safety boundary

- Product and training consent are separate; training is off by default.
- Teen data requires current teen and verified-guardian consent.
- Global datasets contain only global opt-ins. Tenant-private data is never
  merged into a global dataset.
- Dataset creation, export and training each recheck consent, ownership,
  moderation, deletion tombstones and research exclusions.
- Planner examples require a completed canonical run where every mandatory
  validator passed.
- Frozen benchmark and user-study prompt families are excluded from training.
- Production plaintext exists only in the configured tmpfs. Durable dataset and
  model directories use KMS envelope encryption.
- Only the allowlisted trainer commands in `worker/learning_tasks.py` execute.

## Operator sequence

1. Keep `PRODUCTION_TRAINING_ENABLED=false` while collecting data. Review
   consent, age assurance, guardian consent, content rights and moderation.
2. Build and freeze a dataset through `POST /api/v1/admin/learning/datasets`.
   Use at least 500 new high-quality examples, or record the approved monthly
   window exception.
3. Create a training candidate, have the model owner approve it, and queue it.
   The worker preserves the dataset's user/tenant/prompt-family/time-disjoint
   splits.
4. Run the signed GPU-training image with:

   - an exact, licence-approved base model;
   - `TRAINING_PLAINTEXT_DIR` mounted as memory-backed `emptyDir`/tmpfs;
   - separate KMS keys for global training copies and enterprise adapters;
   - network access limited to the approved model registry, KMS, database and
     queue endpoints.

5. Register the resulting model. The API derives the digest from the completed
   trainer record; clients cannot supply or replace it.
6. Evaluate on frozen benchmarks and recent temporal holdouts. The isolated
   evaluator signs the canonical evaluation payload with
   `MODEL_EVALUATION_SIGNING_KEY`; ordinary administrators cannot invent passing
   metrics.
7. Promote only through `CANDIDATE -> EVALUATED -> SHADOW -> CANARY ->
   PRODUCTION`. Canary traffic advances from 5% to 25% only with another signed
   evaluation. Failed gates set the deployment inactive and preserve rollback
   evidence.

## Planner artifact

The trainer accepts a governed manifest by default. A raw legacy JSONL file is
rejected unless `--allow-legacy-research-data` is explicitly supplied, and the
production worker never supplies that flag. Every governed target must be a
neutral canonical `SimulationSpec`, not a game schema.

The model card must include:

```json
{
  "dataset_card": {"manifest_hash": "..."},
  "training_manifest": {"base_model": "exact/model-card-id"},
  "limitations": ["supported capability packs only"],
  "runtime": {
    "provider": "ollama",
    "model_id": "serendib-planner-challenger",
    "endpoint": "https://approved-model-service.internal",
    "modalities": ["text"],
    "structured_output": true
  }
}
```

The serving service must load the digest-bound adapter before promotion. A
database production record alone does not install weights on a model server.

## Rankers

Asset and placement rankers are deterministic JSON linear models. Runtime loads
them only after verifying the complete artifact-directory digest. They order
only candidates that already satisfy licence, capability, collision,
reachability and performance constraints; they cannot override hard gates.

For encrypted production artifacts, deploy an approved decrypt-to-tmpfs sidecar
or init job and put that verified plaintext mount in the model card runtime
manifest. Never place KMS-decrypted adapters on a persistent volume.

## Promotion gates

- no critical safety regression;
- executable semantic correctness delta at least -0.01;
- primary metric improvement, or material cost/latency improvement at
  non-inferior correctness;
- memorization, PII extraction and tenant-leakage tests pass;
- no research-training overlap;
- reproducible dataset/model cards, artifact digest and benchmark digest.

Study data cannot train a model evaluated in the same study. Any later use
requires separate research-training consent and a new frozen evaluation.
