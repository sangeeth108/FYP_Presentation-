# Runbook — Deployment, Worker-Offline, Demo Failover

## Standard deploy

| Component | Procedure |
|---|---|
| Frontend | Push to main → Cloudflare Pages builds `apps/web` (or `wrangler pages deploy`) |
| Brain/API | SSH to VPS → `cd /opt/promptplay && git pull && docker compose up -d --build` |
| Worker | On the 5090: pull latest, restart the worker daemon (systemd service or `docker compose` on the workstation) |
| Engine release | CI builds editor + templates from pinned tag + patches → tagged GitHub release; keep last 3 |
| Game artifacts | Worker uploads to R2 automatically at S8; no manual step |

Post-deploy smoke: `GET /healthz` → 202 hello-job → open the golden game `/play` URL.

## Worker-offline procedure

Symptoms: jobs stuck in QUEUED; worker heartbeat stale.

1. Don't panic — the queue buffers jobs by design; nothing is lost.
2. Check the workstation: power, tunnel process (`cloudflared`/`tailscale status`), daemon logs.
3. If down for a while: post ETA in the team channel; the progress UI shows queued state honestly.
4. If down for a demo/user-study window → **failover** below.

## GPU failover (rented cloud GPU)

1. Rent a GPU instance (RunPod/Vast.ai, ~$0.35–0.79/hr) with the same CUDA baseline.
2. Pull the worker container image from the registry (same image as the 5090 — this is why we containerize).
3. Provide `.env` values from the vault (tunnel token or tailnet key, queue URL, R2 keys).
4. Start the worker; it pulls from the same queue. Verify with one benchmark prompt.
5. Tear down after the window; check billing.

## Demo-day protocol (defense)

- **5 cached showcase games deployed and tested the day before** — the demo never depends on live generation.
- 1 live generation rehearsed twice beforehand; failover GPU on standby.
- If live generation fails on stage: play the cached games, show the recorded live run.
- Golden rule: *never bet the demo on live infrastructure and conference wifi.*

## Rollback

- Brain: `git checkout <previous-tag> && docker compose up -d --build` (DB migrations must be backward-compatible one version — N-1 rule).
- Frontend: re-deploy previous Pages build (dashboard, one click).
- Engine: previous Serendib release remains downloadable (last 3 retained).
