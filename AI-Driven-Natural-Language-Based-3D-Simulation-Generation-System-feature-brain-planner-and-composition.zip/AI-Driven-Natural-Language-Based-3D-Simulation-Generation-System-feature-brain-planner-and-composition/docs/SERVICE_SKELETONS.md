# Service Skeleton Plans (Next.js frontend + FastAPI brain)

P0 deliverable = **plans**, not running services. This document specifies exactly how each skeleton will be scaffolded so the next P0 tasks (hello-job, home page) are unambiguous. No heavy dependencies are installed until the OS/environment is confirmed (CLAUDE.md §12).

---

## 1. Next.js frontend skeleton (`apps/web/`) — plan

**Scaffold command (run when the frontend task starts):**
```bash
# from repo root
npx create-next-app@latest apps/web --ts --app --eslint --no-tailwind --no-src-dir --import-alias "@/*"
```
(Adjust flags to taste; TypeScript + App Router are required by CLAUDE.md §9.)

**Target structure (matches the folders already scaffolded):**
```
apps/web/
├── app/
│   ├── page.tsx              # Home / prompt page (P0: static shell + example prompts)
│   ├── layout.tsx            # Root layout, theme
│   ├── jobs/[id]/page.tsx    # Job progress (P2 — placeholder route in P0)
│   └── play/[gameId]/page.tsx# Play page shell (P1/P2)
├── components/               # PromptInput, ExamplePromptChips, PhaseTimeline, ErrorPanel … (see DESIGN_SYSTEM.md)
├── lib/
│   ├── api.ts                # typed FastAPI client (base URL from env)
│   └── types.ts              # types generated from contracts/game_spec.schema.json
├── styles/
├── public/
└── tests/                    # component tests
```

**P0 acceptance for the frontend skeleton:** `npm run dev:web` serves a Home page shell (prompt box + example prompts, no live backend call required yet). Empty/loading/error/success states stubbed per `DESIGN_SYSTEM.md`.

**Rules:** TypeScript only; no LLM/DB access from the browser (everything via the FastAPI brain); mobile-first; the play page is a thin shell around the Godot web export.

---

## 2. FastAPI brain skeleton (`services/brain/`) — plan

**Own dependency file (created when the hello-job task starts, not in P0 scaffold):**
```toml
# services/brain/pyproject.toml (planned)
[project]
name = "promptplay-brain"
requires-python = ">=3.11"
dependencies = [
  "fastapi>=0.110",
  "uvicorn[standard]>=0.29",
  "celery>=5.3",
  "redis>=5.0",
  "sqlalchemy>=2.0",
  "asyncpg>=0.29",
  "pydantic>=2.6",
]
# LangGraph / vLLM client / bge-m3 are added later (P2), NOT now.
```

**Target structure (folders already scaffolded):**
```
services/brain/
├── main.py            # FastAPI app entrypoint (P0: /healthz only; hello-job next)
├── api/               # routers: games, jobs, health
├── services/          # db.py, queue.py (Celery app), r2.py, lineage.py
├── contracts/         # spec validator (wraps scripts/validate_contracts logic)
├── orchestrator/ agents/ knowledge/ pcg/ repair/   # EMPTY until P1/P2 — do not fill in P0
└── tests/             # contract + endpoint tests
```

**Hello-job flow (first real P0 endpoint — the very next task after this plan):**
```
POST /api/v1/games {prompt, seed?, options?}
  → insert jobs row (state=QUEUED)
  → enqueue Celery task that just marks the job DONE (no AI)
  → return 202 {game_id, job_id}
GET /api/v1/jobs/{id} → {state, phases[], artifacts[]}
GET /healthz → {"status":"ok"}
```
This proves **web → API → Redis/Celery → worker → Postgres** round-trips before any AI. See `API_DOCUMENTATION.md`.

**P0 acceptance for the brain skeleton:** `uvicorn main:app --reload` serves `/healthz` returning `{"status":"ok"}`. The hello-job endpoints follow immediately as the next P0 task.

**Rules:** anything long-running returns 202 + job id; agents will be modules (not microservices); the `orchestrator/agents/knowledge/pcg/repair` folders stay empty until their phases.

---

## Docker note

`docker-compose.yml` currently runs **Postgres (pgvector) + Redis** for P0. The `brain` service is commented out until this skeleton has a real app + `services/brain/pyproject.toml`; `infra/docker/brain.Dockerfile` is a ready skeleton for that moment. Bring up the P0 stack with:
```bash
docker compose up -d postgres redis
```
