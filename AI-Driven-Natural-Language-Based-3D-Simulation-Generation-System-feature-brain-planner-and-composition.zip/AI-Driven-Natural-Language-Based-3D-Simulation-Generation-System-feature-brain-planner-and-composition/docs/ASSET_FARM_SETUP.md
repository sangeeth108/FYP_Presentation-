# Asset Farm Setup — the real GPU generation backend (P3)

> ## Install status on the RTX 5090 workstation (2026-07-14, in progress)
> The stack is being installed on this machine. What is **confirmed**:
> - **RTX 5090 (32 GB) + CUDA 12.9 + Python 3.12** on Windows; **Blender 5.1** on PATH.
> - **WSL2 Ubuntu 24.04 with 5090 GPU passthrough verified** (`nvidia-smi` works inside
>   WSL). TRELLIS runs here, not on bare Windows — its CUDA submodules (flash-attn,
>   nvdiffrast, diffoctreerast, …) build reliably under conda+Linux and are a
>   high-failure source on native Windows.
> - **Miniconda + TRELLIS** cloned in WSL at `/root/TRELLIS`, `/root/miniconda3`.
> - **ComfyUI** at `D:\asset-farm\ComfyUI` (Windows), its own venv, torch cu129.
>
> ### ⚠ The Blackwell trap (do not skip)
> The 5090 is **Blackwell, sm_120**. TRELLIS's default env pins **PyTorch + CUDA 11.8**,
> which **cannot see a 5090** (`torch.cuda.is_available()` → False, silently). Build its
> conda env against **CUDA 12.8** instead:
> ```bash
> conda create -n trellis python=3.11 -y && conda activate trellis
> pip install torch torchvision --index-url https://download.pytorch.org/whl/cu128
> python -c "import torch; assert torch.cuda.is_available(), 'Blackwell needs cu128+'"
> ```
> Then run TRELLIS's `setup.sh` **without `--new-env`** (so it uses this env, not its
> 11.8 default) for `--basic --flash-attn --diffoctreerast --spconv --nvdiffrast`.
> The compiled submodules must build against cu128 for sm_120.
>
> ### ✅✅ GpuAssetBackend VERIFIED END-TO-END through wired code (2026-07-14)
> `GpuAssetBackend.generate("a mossy stone golem idol with glowing runes")` produced
> a **QA-passing GLB** (18791 tris, unit scale, 2.95 MB) driving all three stages
> through production code: SDXL (Windows ComfyUI) → TRELLIS (WSL2) → Blender
> (Windows) → QA gate. Enable it in a real job with `ASSET_GEN_ENABLED=true`,
> `ASSET_GEN_BACKEND=gpu`, `BLENDER_BIN=C:\...\blender.exe`. The Windows↔WSL
> plumbing that had to be right: `wsl … bash -c` (not `-lc`, which injects the
> space-laden Windows PATH), the trellis env's **absolute** python (conda activate
> is unreliable non-interactively), and exporting `XFORMERS_DISABLED=1` in the
> command. All handled by the backend now.
>
> ### ✅ FULL PIPELINE VERIFIED on the 5090 (2026-07-14)
> **brief → SDXL image → TRELLIS mesh → GLB → QA PASS** ran end-to-end: a
> 17748-triangle, unit-scale, 1.59 MB GLB that passes the asset-farm QA gate, from
> the brief "a cracked marble sarcophagus draped in rotting velvet". The exact
> TRELLIS build sequence that worked, in order (all inside the WSL2 `trellis` env,
> `CUDA_HOME=/usr/local/cuda-12.8`, `TORCH_CUDA_ARCH_LIST=12.0`):
> 1. `cuda-toolkit-12-8` (nvcc) from NVIDIA's wsl-ubuntu repo — the gate for all builds.
> 2. **kaolin from source** (`git clone NVIDIAGameWorks/kaolin && pip install -e . --no-build-isolation`) — no wheel exists for torch 2.11+cu128; then `pip uninstall kaolin` first to drop the PyPI *placeholder* that shadows the source build.
> 3. **nvdiffrast**: `pip install . --no-build-isolation` (build isolation hides torch → "Cannot compile CUDA extension").
> 4. **diff-gaussian-rasterization** (from `autonomousvision/mip-splatting/submodules/`) and **diffoctreerast** (`JeffreyXiang/diffoctreerast`): both `pip install --no-build-isolation`. TRELLIS's `setup.sh` installs these WITHOUT that flag, so it fails "No module named 'torch'" — build them directly.
> 5. `xformers` + `spconv-cu120` (wheels, ABI-compatible with cu128).
> 6. Two runtime fixes, now baked into `trellis_cli.py`: patch `torch.hub._validate_not_a_forked_repo` (the DINOv2 hub load `KeyError: 'Authorization'` with no GITHUB_TOKEN), and `XFORMERS_DISABLED=1` (DINOv2 runs float32; xformers has no float32/Blackwell kernel).
>
> ### The torch/torchvision/torchaudio trio MUST be one consistent channel
> ComfyUI imports all three (`torchaudio` via its audio-VAE path, even for image
> models), and they share a compiled C++/CUDA ABI. Mixing versions crashes at
> import: torchvision built for a different torch → `operator torchvision::nms
> does not exist` / access violation; torchaudio hard-checks the CUDA string →
> `PyTorch and TorchAudio were compiled with different CUDA versions`.
>
> **Trap:** the `cu129` channel is *inconsistent* — it ships torch 2.9.0 but only
> torchvision 0.23.0 / torchaudio 2.8.0 (which are built for torch **2.8.0**).
> Use a channel where all three match. For a 5090 the clean set is **cu128**
> (supports Blackwell) at torch **2.9.0** + torchvision **0.24.0** + torchaudio
> **2.9.0** — install all three from `--index-url .../whl/cu128`. (Downloading the
> big torch wheel with `curl -L -C -` and `pip install`ing it locally avoids the
> connection breaks; then add the two small wheels.)
>
> Also: `pip install -r requirements.txt` re-pulls **CPU** torch/vision/audio from
> PyPI and silently clobbers the CUDA build (`torch.cuda.is_available()` → False).
> Install the CUDA trio **after** the requirements, or pin them out of the reqs.
>
> ### Downloads are the slow part
> torch cu129 wheel (~3.5 GB), SDXL checkpoint (~6.9 GB), TRELLIS cu128 torch (~3 GB),
> plus CUDA toolkit in WSL for `nvcc`. Use **`curl -L -C -`** (resumable) for the big
> files — a plain `pip install` of torch broke twice on connection drops under
> bandwidth contention; the resumable curl wheel survives it.



This is the runbook for standing up the **real** S5 generation tier
(`asset_gen_backend=gpu`) on the RTX 5090 workstation. Until it is done, the
platform ships the curated CC0 kit — nothing here is required to run the product,
and **a misbehaving backend can never break a game**: the resolver falls back to
curated on any generation failure (proven by `test_asset_farm.py`).

The deterministic spine (resolver, cache, QA gate, license guard, config seam) is
already built, tested, and merged. This document is only about the heavy,
GPU-bound, environment-specific pieces that must be installed and confirmed by a
human (CLAUDE.md §12).

---

## What the backend does

For each `asset_brief` the Content Designer wrote:

```
brief text ──SDXL──▶ concept image ──TRELLIS──▶ raw 3D mesh ──Blender──▶ web GLB ──▶ QA gate
```

1. **SDXL** (`stabilityai/stable-diffusion-xl-base-1.0`, CreativeML Open RAIL++-M)
   — a single centered object on a plain background, served via **ComfyUI**.
2. **TRELLIS** (`microsoft/TRELLIS-image-large`, MIT) — image → textured mesh.
   *(Note: there is no "TRELLIS.2"; the real model is `TRELLIS-image-large`.)*
3. **Blender headless** — decimate to the brief's tri budget, export a clean GLB
   (`asset_farm/blender_finish.py`, already written).

All three are **license-verified for the product path** (see
`docs/licensing_ledger.csv`, verified 2026-07-14).

> **GPU sequencing (32 GB constraint):** the 27B planner, TRELLIS (≥24 GB) and
> SDXL cannot be co-resident. The worker already sequences modes plan → assets →
> validation; run generation as its own phase, not alongside the planner.

---

## Install (run on the GPU box, confirm each step)

```bash
# 1. ComfyUI (SDXL host)
git clone https://github.com/comfyanonymous/ComfyUI && cd ComfyUI
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
# SDXL base checkpoint into models/checkpoints/ (from the HF card above)
#   sd_xl_base_1.0.safetensors  (~6.9 GB)
python main.py --listen 127.0.0.1 --port 8188   # leave running

# 2. TRELLIS (image -> 3D) — in WSL2 Ubuntu, NOT native Windows
#   Verified groundwork (2026-07-14): WSL2 Ubuntu 24.04 + 5090 passthrough,
#   Miniconda, conda env 'trellis' with torch 2.11.0+cu128 (Blackwell), gcc 13,
#   TRELLIS cloned with --recurse-submodules at /root/TRELLIS.
wsl -d Ubuntu-24.04 -u root
  conda create -n trellis python=3.11 -y && conda activate trellis
  conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/main   # conda now requires this
  pip install torch torchvision --index-url https://download.pytorch.org/whl/cu128     # cu128 = Blackwell
  apt-get install -y build-essential ninja-build      # gcc for the submodule builds
  cd /root/TRELLIS
  # Use xformers, NOT flash-attn (xformers ships as a wheel; flash-attn compiles
  # ~30min and is the top failure source). setup.sh WITHOUT --new-env uses our env:
  . ./setup.sh --basic --xformers --spconv --nvdiffrast --diffoctreerast --mipgaussian --kaolin
  #   CONFIRMED BLOCKER (2026-07-14): nvcc. The pip nvidia-cuda-nvcc-cu12 package
  #   did NOT place a findable nvcc, so nvdiffrast/diffoctreerast cannot compile.
  #   FIX: install the real CUDA 12.8 toolkit in WSL (has nvcc), then set CUDA_HOME:
  #     wget https://developer.download.nvidia.com/compute/cuda/repos/wsl-ubuntu/x86_64/cuda-keyring_1.1-1_all.deb
  #     dpkg -i cuda-keyring_1.1-1_all.deb && apt-get update
  #     apt-get install -y cuda-toolkit-12-8      # ~3GB; provides nvcc, no driver (comes from Windows)
  #     export CUDA_HOME=/usr/local/cuda-12.8 PATH=$CUDA_HOME/bin:$PATH
  #   The wheel parts (--basic --xformers --spconv) install WITHOUT nvcc; only the
  #   compiled renderers (nvdiffrast/diffoctreerast) need it. spconv: no cu128 wheel
  #   yet — try `pip install spconv-cu126` (ABI-compatible). First pipeline run
  #   downloads TRELLIS-image-large (~gigs).
  #   Everything else is ready: conda env, torch cu128, gcc, TRELLIS+submodules,
  #   trellis_cli.py. This nvcc/toolkit step is the one remaining gate.
  # Then deploy the CLI wrapper (services/worker/asset_farm/trellis_cli.py):
  #   python trellis_cli.py --image X.png --out Y.glb   # xformers forced inside

# 3. Blender (already scriptable; 4.x)
#   ensure `blender` is on PATH:  blender --version
```

Approx footprint: **~20 GB** of models. Do this deliberately, not unattended.

---

## Enable it

`.env` on the worker:

```ini
ASSET_GEN_ENABLED=true
ASSET_GEN_BACKEND=gpu
COMFYUI_BASE_URL=http://localhost:8188
```

With `ASSET_GEN_ENABLED=false` (default) the farm is a no-op that ships curated.
`ASSET_GEN_BACKEND=mock` produces deterministic placeholder GLBs (dev/tests).

### Sound is a separate switch

```ini
AUDIO_GEN_ENABLED=true
AUDIO_GEN_BACKEND=gpu     # mock = deterministic real WAVs, no GPU
```

Deliberately independent of `ASSET_GEN_*`: Stable Audio and TRELLIS are
different models that **cannot be co-resident in 32 GB**, so they are enabled,
sequenced and failed separately. Each character's clips are derived from *who it
is* × *what it is doing* (`asset_farm/sound_brief.py`) and gated by `qa_audio`;
any failure falls back **per activity** to the curated CC0 set, so a partly
working generator never leaves a character with a silent attack.

**The recommended combination today is `ASSET_GEN_ENABLED=false` +
`AUDIO_GEN_ENABLED=true`:** the curated models are rigged and animated, while a
generated character is still a static mesh, so the shipping policy holds it back
anyway (ADR-0005). Unique *voices* on animated bodies is the win available now.

> ⚠ `AUDIO_GEN_BACKEND=gpu` needs Stable Audio Open installed in ComfyUI, and its
> node graph in `backends_audio.py` has **not** been verified against a live
> install — check `CHECKPOINT` and the workflow node names first, exactly as the
> SDXL graph had to be smoke-tested before it was trusted. `mock` is fully
> verified end-to-end.
>
> Licence (§14): Stable Audio Open is **conditional** product-path — free for
> commercial use below USD $1M/yr revenue (Stability AI Community License,
> ledger-verified 2026-07-14). The license guard blocks it if the ledger ever
> says otherwise. Revisit if revenue crosses $1M.

---

## The one code task left on the GPU box

`asset_farm/backends_gpu.py` is complete except the **ComfyUI result polling**,
which depends on your exported workflow graph. Two functions to finish:

- `_comfy_sdxl_workflow(prompt, seed)` — return your ComfyUI **API-format**
  workflow JSON (export it from the ComfyUI UI: *Save (API Format)*), with the
  positive-prompt node's text and the KSampler seed injected.
- `_await_comfy_image(client, submit_response)` — poll `GET /history/{prompt_id}`
  until the output node reports an image, then `GET /view?filename=...` to
  download the PNG bytes.

Until these are wired, selecting the `gpu` backend **safely falls back to
curated** (the polling stub raises, the resolver catches it). So you can enable it
incrementally and watch the manifest.

---

## Smoke test (GPU box)

```bash
cd services/worker
python - <<'PY'
from pathlib import Path
from asset_farm.brief import AssetBrief
from asset_farm.backends_gpu import GpuAssetBackend
from asset_farm.qa_gate import qa_mesh
b = AssetBrief("a cracked marble sarcophagus draped in rotting velvet", "prop", 2000)
res = GpuAssetBackend().generate(b, Path("/tmp/farm_smoke"))
print("QA:", qa_mesh(res.path, b).to_dict())
PY
```

A pass here means the resolver will start choosing `generated` over `curated` in
the job manifest (`asset_tiers`). Then run the full gate
(`python eval/run_benchmark.py --llm --full`) and confirm builds stay ≤90 MB and
the bot still wins — a generated mesh that blows the tri budget is caught by the
QA gate and falls back to curated automatically.
