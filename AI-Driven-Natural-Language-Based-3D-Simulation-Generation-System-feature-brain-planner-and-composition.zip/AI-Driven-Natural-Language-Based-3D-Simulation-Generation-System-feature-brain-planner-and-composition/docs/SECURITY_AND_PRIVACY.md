# Security & Privacy

## Security rules (always-on)

1. **No secrets in the repo.** Only `.env.example` with placeholders. Real secrets in the team password manager / secrets vault. CI secret-scanning enabled.
2. **Never paste API keys, credentials, or private user data into AI prompts** (including Claude Code sessions).
3. **GPU workstation: outbound-only.** Cloudflare Tunnel / Tailscale; zero inbound ports; queue buffers jobs when offline.
4. **VPS:** DB + Redis bound to localhost/private network only; TLS on the public API; SSH key auth only; unattended upgrades.
5. **No arbitrary code execution anywhere:** the LLM emits template IDs + parameters; Serendib Assist never executes returned code — only spec patches + assets through the validators; no unsafe `eval`.
6. **Template allowlist enforced at the registry level** — the LLM cannot reference non-existent or unvetted artifacts.
7. Adapter code (the only LLM-written code) passes a **5-step promotion gate** with human review before it may run.
8. Prompt intake (S0) filters unsafe content before any processing.

## Privacy & research governance

- **DPIA required before any user study.** UK-GDPR/ICO assumed jurisdiction (re-verify if team is not UK-based).
- **Educational users may include minors** → children's higher-protection duty applies: flag child-safety risks, minimal data collection, guardian consent paths.
- **Pseudonymize logs**; set retention limits; user prompts are personal data — treat accordingly.
- Ethics approval for the user study starts **early** (P5 preparation begins in P4).
- Publish a privacy policy + retention limits before any external testers.

## Legal / trademark

- Godot code = MIT: retain LICENSE + copyright notices; license viewer in the About dialog.
- **Godot name + logo are trademarks, not covered by MIT.** Rebrand to Serendib Engine is legally required. Credits state "based on Godot Engine" + non-affiliation disclaimer.
- Before any commercial launch: clear the Serendib name (trademark DBs, Steam, package registries) and engage the Godot Foundation about the commercial-fork license. Not needed for the academic prototype.

## Licensing safety

Product path: MIT / Apache-2.0 / OpenRAIL-commercial only. Research-only quarantine: FLUX.1[dev] (non-commercial), Hunyuan3D-2.1 (UK/EU/Korea excluded). Every model/asset/tool logged in `docs/licensing_ledger.csv` **before** first use. `scripts/check_licenses.py` fails CI on violations.

## Incident basics

If a secret leaks into git history: rotate the credential immediately (rotation > history rewriting), then clean history. If the 5090 is compromised: revoke tunnel credentials; the cloud side holds no inbound trust in it beyond queue access.
