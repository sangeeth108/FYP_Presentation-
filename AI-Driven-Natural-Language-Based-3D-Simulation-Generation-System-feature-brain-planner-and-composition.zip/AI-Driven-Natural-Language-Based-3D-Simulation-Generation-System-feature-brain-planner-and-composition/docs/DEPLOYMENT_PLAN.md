# Deployment Plan — hybrid topology

**Principle:** the cloud is small, cheap, always-on; the RTX 5090 is powerful, local, **outbound-only**. No inbound ports ever open on the home network.

## Topology

| Component | Where | How deployed |
|---|---|---|
| Frontend + `/play` pages | Cloudflare Pages | Pages build from `apps/web`; `_headers` file for COOP/COEP only if threaded builds are ever enabled |
| Game bundles, project zips, assets, logs | Cloudflare R2 | Worker uploads; signed URLs for downloads; $0 egress |
| API + brain + queue + DB | Hetzner VPS (CX32/CX42) | Docker Compose (`docker-compose.yml`); DB/Redis bound to localhost; reverse proxy w/ TLS in front of FastAPI |
| GPU worker | RTX 5090 workstation | Daemon pulls jobs via Cloudflare Tunnel / Tailscale; streams progress back; queue buffers while offline |
| CI | GitHub Actions | Lint/test on PR; engine build matrix per pinned tag; nightly regression benchmark (P2+) |
| Backups | R2/B2 | Nightly DB dumps; last 3 Serendib releases retained |

## Environments

- **development** — everything local (Compose + local worker), `PROMPTPLAY_ENV=development`.
- **staging = production** for this project size; feature flags (e.g. `FEATURE_TUNED_PLANNER`) gate risky components.

## Failover (demo-day insurance)

Rented cloud GPU (RunPod/Vast.ai, ~$0.35–0.79/hr) runs the **same worker container images**; runbook in `runbooks/DEPLOYMENT_RUNBOOK.md`. Showcase games are pre-cached — never bet a demo on live infrastructure.

## When do you actually need to pay? (budget reality)

**Not yet.** Through **P0–P2 (including the mid-demo) you spend $0**: the whole stack — Postgres, Redis, brain, Celery — runs locally on Docker on your own machine, and the GPU work runs on the RTX 5090 you already own. A public URL for a demo can use a **free** Cloudflare Tunnel / `cloudflared` link or Cloudflare Pages' free tier.

A **paid always-on host is only needed at P3**, when the platform must be reachable 24/7 without your laptop on. Even then, cheap/free options exist before committing to Hetzner:
- **Free-tier VMs** for the small always-on services (e.g. Oracle Cloud Free Tier, Fly.io free allowance) — enough for the API + Postgres + Redis at low traffic.
- **Cloudflare Pages + R2** stay on free tiers for a long time ($0 egress).
- **Hetzner CX32 (~€7–16/mo)** is the *recommended* target once you have a small budget — not a prerequisite.

So: keep building locally now (no card required); pick a host only when you genuinely need public always-on hosting, and start with a free tier if budget is tight.

## Cost tiers (choose + set spend alert)

| Tier | Monthly | Contents | When |
|---|---|---|---|
| Low | ≈$18 | Free Pages/R2 tiers, smallest VPS, 5090 electricity | P0–P2 |
| Medium (recommended) | ≈$36 | CX32/42, R2 builds, CI, steady 5090 | P3+, demos, user study |
| Ideal | ≈$90 | + burst GPU, larger VPS, more storage | Evaluation crunch, showcase |

Watch: Hetzner 2026 price adjustments · burst GPU if 5090 over-subscribed · fork-rebase time cost.

## Deployment checklists

Live in `runbooks/`: `VPS_SETUP.md`, `GPU_WORKER_SETUP.md`, `GODOT_BUILD.md`, `DEPLOYMENT_RUNBOOK.md` (incl. worker-offline and demo-failover procedures).
