# Database Schema (design — implemented in P1)

PostgreSQL 16 + pgvector. Keep this document in sync with migrations once they exist.

## Design principles

- Every generated artifact is hash-linked into a **lineage chain** — byte-level reproducibility.
- Registries are **allowlists**: agents can only reference IDs present here.
- `schema_version` on every spec; validator supports N-1.
- Machine-readable everything: verdicts and errors are JSONB objects, not strings.

## Implemented so far (P0)

`games` and `jobs` exist via Alembic migration `services/brain/migrations/versions/0001_initial.py` (verified). Minimal columns for the hello-job: `games(id, title, prompt, genre, camera, seed, created_at)`, `jobs(id, game_id→games.id, state, detail JSON, created_at, updated_at)`. The columns below are the fuller target these grow into (add via new migrations, never by editing tables in place).

## Planned tables

| Table | Purpose | Key columns (draft) |
|---|---|---|
| `users` | Accounts (later phases; anonymous OK in P0–P2) | id, email, role, created_at |
| `games` | One row per generated game | id (`g3d_<slug>_<hash>`), user_id, title, genre, camera, current_spec_id, play_url, status |
| `jobs` | Generation/repair jobs | id, game_id, state (QUEUED…DEPLOYED/FAILED), seed, budgets JSONB, created/started/finished_at |
| `job_phases` | Per-stage progress (drives live UI) | job_id, stage (S0–S8), state, started_at, finished_at, detail JSONB |
| `specs` | Canonical game_spec documents | id, game_id, schema_version, body JSONB, spec_hash (ETag), frozen_at |
| `spec_revisions` | Patch history (edits, repairs) | spec_id, patch JSONB (RFC 6902), source (agent/repair/dock), created_at |
| `agent_decisions` | Which agent/arbiter rule decided what | job_id, agent, patch JSONB, arbiter_rule, tie_break_used, created_at |
| `validation_reports` | 8-gate verdicts per build | job_id, gate (1–8), verdict, errors JSONB, created_at |
| `repair_attempts` | Bounded repair tracking | job_id, failure_class (schema/asset/build/logic/quality), attempt_no (≤3), node, patch JSONB, outcome |
| `artifacts` | Everything produced | id, job_id, kind (web_build/project_zip/asset/log/credits), r2_key, bytes, content_hash |
| `lineage` | Reproducibility chain | game_id, prompt, seeds JSONB, model_digests JSONB, spec_hash, build_hash, created_at |
| `asset_cache` | Reusable generated/curated assets | brief_hash (PK), embedding vector, source (curated/generated/fallback), model+digest, seed, files JSONB, qa_scores JSONB, license_ref |
| `registry_templates` | Vetted GDScript template allowlist | template_id, category (controller/ai/combat/objective/interactable), params_schema JSONB, version, reviewed_by |
| `registry_kits` | Module kits | kit_id, biome, grid_size, tiles JSONB, license_ref |
| `registry_animations` | Animation sets | anim_set_id, rig_profile, clips JSONB |
| `registry_presets` | Lighting/mood presets | preset_id (dusk_fog, cave_torchlit…), params JSONB |
| `design_notes` | RAG corpus | id, text, embedding vector(1024), tags |

## Indexing notes

- `asset_cache.embedding` + `design_notes.embedding`: pgvector HNSW/IVFFlat indexes.
- `jobs.state` + `job_phases(job_id, stage)`: hot paths for the live progress UI.
- `specs.spec_hash` unique — ETag for `GET /games/{id}/spec`.

## Update rules

Update this file **and** `docs/CHANGELOG.md` whenever a migration is added. Owner: M2 (schema/brain tables), M1 (platform tables).
