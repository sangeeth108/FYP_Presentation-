# Changelog

All notable changes to this project. Format loosely follows [Keep a Changelog](https://keepachangelog.com); versions follow the phase gates until v1.0.

### The trim measures entities, and a wood is not its entities

With cover, sizing and a canopy species all working, the forest still came out with four
trees. The sampler said why, in its own report:

```
spc_canopy_tree: requested 26, placed 4,
                 shortfall_reason "packing_limit", spacing_m 11.2996
```

The spacing is not wrong -- 11.3 m is a real mature crown, measured from the resolved
asset -- and 999 m2 of ground holds about eight of them however they are sampled. The
world was the constraint, not the sampler. It had been trimmed to 37x27 m, because the
trim measures the reach of placed ENTITIES and this forest has six of them against 1,295
scattered things.

The trim earns its place: a village 23 m across once shipped on a 73 m slab and read as
an empty plain. It is right for a world made of entities and wrong for a world made of
scatter. It now refuses to trim past the ground the declared scatter needs.

**Why this is not the sizing change that was reverted.** That one shrank the world BEFORE
placement and took a warehouse from 18/18 gates to 8/18, and `pcg.semantic` had already
recorded the general finding: "every attempt to size it down broke placement on real
specs". This runs AFTER placement has solved, so widening the floor cannot unplace
anything, and it never gives back more ground than the untrimmed extent had. Same
quantity, opposite direction, different phase.

The first attempt at the floor was wrong too, and measurably: sizing by
`density_per_100m2` alone claimed eight trees fit in 300 m2. Density says nothing about
whether the things can physically stand there. It now asks `_footprint_radius` -- the
same function the sampler uses to choose spacing -- so the floor cannot disagree with the
packing that actually happens: **300 m2 -> 1,021 m2**.

### The visual critic was right four times out of four

Every `visual_semantic` failure this session was blamed on the critic before being
measured, and every one of its verdicts held up:

- "the scene lacks trees" -- the forest had one cedar and 740 pieces of forest floor;
- "the visible walls appear to be fewer in number" -- the inventory counted 34 wall
  SEGMENTS as 34 walls and asked it to find them in a room with four;
- "no entities are provided in the 'entities' array" -- the payload really did send an
  empty array beside a non-empty inventory;
- "does not contain any visible animal entities" -- `ent_squirrel` ships at
  0.08 x 0.15 x 0.16 m, an 8 cm animal in a 49 m overview.

In each case the fault was the QUESTION, not the answer. The last one is still open: the
proportion guard skips anything rigged, because swapping a rigged animal for a box strips
the rig and fails the `animal` capability -- so a correctly-proportioned but far-too-small
mesh passes every check.


### The rule fired on nothing, and the corpus said so

Asked whether these fixes were general or fitted to two prompts, the rules were run
against every spec the system has produced -- 592 specs, 35 distinct world types. The
answer was 29 of 35 types improved, and one rule was **dead**:

```
ground cover fires on: 0 of 592 specs
```

It keyed on `terrain_surface`, and the corpus says why:

```
outdoor terrain_surface : unspecified 347 | absent 63 | soil 25 | grass 8
outdoor terrain (free)  : grass_and_paths 410
```

The planner does say what its ground is -- in the free-text `terrain` field -- while
leaving the enum unspecified. The rule passed its own unit tests and matched almost
nothing real. Ground is now read in its own words, across every field that describes it:
**0 -> 410 specs**.

`surfaces.py` deliberately refuses to read that free text and remains right to: resolving
a RENDERED surface by word-matching would silently miss "machair" and paint the ground
wrong. Cover is additive and incidental, so the trade differs -- but evidence is still
required in both directions, and the 104 worlds describing themselves as
`contextual_terrain unspecified` are left bare rather than guessed at. A lawn in a car
park is worse than no lawn.

### A forest floor in full detail, and no forest

With sizing and cover both working, the forest scattered 740 instances into a 48x37 m
world and still failed the visual critic. What was scattered:

```
leaf_litter 500 | ferns 120 | rocks 50 | branches 40 | salmonberry 30
entities: a student, a stump, a nest, a squirrel, a bird -- and `ent_cedar`,
          one 10x20 m tree
```

A forest ecosystem lesson with one cedar. The critic's "the scene lacks trees" had been
right through every previous fix, because all of them addressed the ground.

`_ground_carries_its_own_cover` cannot reach this by construction -- it only dresses a
world that authored NO scatter, and this world authored plenty. A world that describes
ITSELF as wooded now gets a canopy when short of one, counting trees wherever the planner
put them (entities and scatter alike), so eight cedars authored as entities is already a
wood. A courtyard with one ornamental tree is untouched, because a courtyard does not
call itself a wood.

### The critic was right every time

Three separate failures were blamed on `visual_semantic` before being measured, and in
each case its verdict was accurate: the forest really did lack trees; the warehouse
really did show fewer walls than the inventory claimed. The one thing that was wrong was
the QUESTION -- the inventory counted 34 wall SEGMENTS as 34 walls and asked the critic
to find them in a room with four. Segments of a run are now counted as the run.


### The plan was drawn from a corner, and the world is centred on the origin

Two prompts came back nearly empty. The reasons turned out to be different, and neither
was the one being blamed.

**The frame.** The planner sketches a layout the way a person does -- first wall at
`(0,0)`, warehouse running to `(40,60)`. The world is centred on the origin. Nothing
translated between the two, so the north wall at `z=60` fell outside a world ending at
`z=51` and could not be placed at all. The village had the same error, hidden only
because its numbers were small.

Corrected twice before it worked, which is worth recording:

- recentring ran AFTER `expand_linear_structures`, which bakes each segment's anchor --
  and an anchor is a fact the placer will not move, so it changed nothing;
- the guard aborted on any negative coordinate, on the theory that a signed layout was
  already centred. A striping route with a `-10 m` margin then cancelled the correction
  for the whole layout. The question is where the layout's CENTRE is, not what sign its
  numbers have.

Measured on the warehouse: **7 unplaced -> 2 -> 0**, content symmetric about the origin.

**A boundary drawn corner to corner.** With the frame fixed, the real defect was visible.
One run read, in its own words:

```
semantic_type "Drywall Walls", thickness 2.0 m
source_text   "Defines the perimeter boundary of the simulation volume."
from [-20,-30] -> to [20,30]
```

-- the diagonal of the rectangle it claimed to bound, expanded into sixteen 2 m-thick
segments slicing the warehouse in half. Not incoherence: writing a box as two opposite
corners is how boxes are written everywhere, and the expander was the only reader taking
two points to mean a LINE. Such a run is now rebuilt as the four edges it described.

Rebuilding it blindly then caused its own regression -- a plan carrying BOTH the diagonal
and the planner's own `lin_wall_north/south/east/west` got two complete perimeters in one
place, **8 unplaced, 18/18 gates down to 8/18**. `_drop_umbrella_runs` cannot see that
pair, because it keys on ids and `lin_wall_north` is not named after `lin_drywall_walls`.
The umbrella test is now geometric: a boundary drawn across ground that two other
boundary runs already bound is naming that boundary, and is dropped.

### Outdoor ground is never bare, and the planner almost never says so

Across every spec this system has produced:

```
outdoor worlds   425
  no scatter     390  (92%)
  with scatter    35
```

`scatter` is the field the schema itself describes as "how a place gets the hundreds of
trees/rocks/debris that make it feel real". It is optional, so it was skipped -- eight
consecutive village runs came out at ten entities and zero ground cover, buildings
standing on a bare plane. Ground now grows what its own surface grows, only ever adding
to a world that authored none, never indoors and never on paving.

The forest failed differently, and the visual critic had been right about it three runs
running ("the scene lacks trees, foliage", "a single stump does not suffice"):

```
world          22 x 16 m     = 3.7 hundred-m2
spc_oak_tree   1 per 100 m2  -> about 4 trees
```

One mature oak per 100 m2 is a real forest; 22 by 16 metres is a large room. The density
was right and the ground was missing. `_fit_declared_dimensions` sizes a world to hold
its ENTITIES and never looks at scatter, so a world whose defining content is scattered
rather than listed got no room for it.

### Pallets in the field, and the fix that was not sizing

A warehouse published at 18/18 gates with 275 scatter instances -- and 219 of them (80%),
including all ten racking units, lay on the ground OUTSIDE the building, which was itself
nearly bare.

Shrinking the world to its walls was tried first. It took the run to **8/18**: the spec
also carries free-standing wall entities needing ground of their own, and `pcg.semantic`
already records the general finding in its own comments -- *"every attempt to size it
down broke placement on real specs"*. Reverted.

The world has to stay generous for placement to solve; only the scatter needed to come
inside. `instance_scatter` now clips its sampling rectangles to the enclosure, and the
enclosure geometry lives in one module both the planner and the sampler import rather
than a copy in each -- `entities_conflict` drifted ten times by being defined once and
copied twice.


### The cache outranked everything better (same day, later)

`run_43472534e4a94d049e2d9ae768f277f6` **published** -- 17 of 18 gates, no mandatory
failures -- and looked exactly like the runs before it. The reason took far too long to
find because the report called it success:

```
KENNEY MODELS USED: 0 of 18
cached assets by generator: triposr 424, trellis-2 4
```

Of eighteen resolved assets, **none** used the 1,034-model library vendored hours
earlier. Every dwelling was a TripoSR blob the cache had held since July. The ladder
consults the cache BEFORE the curated library and before generation, so any brief
resolved in an earlier run short-circuits to whatever answer the system gave back
then -- and reports `tier: cache`, which reads as a hit rather than as a miss of
everything better.

A cache is for not repeating expensive work. It is not for freezing the worst answer the
system ever gave.

- `_cache_entry_is_current` refuses entries from `_SUPERSEDED_COMPONENTS` (`triposr`),
  on both the exact and semantic paths. Re-resolving the identical spec: **0 -> 10 real
  models** -- `kenney-city/building-a` for both dwellings, `kenney-castle/gate` for the
  gatehouse, `doorwayOpen` for both doors, `plant_bush` and `grass` for scatter.
- An entry with no component recorded is still served: absence is not evidence of a
  superseded generator.
- Wall segments stay procedural, which is correct -- they are a generated run, not a
  library object.


## 2026-08-30 — vision in the loop

### Two silent failures stood between this project and any newer model

Both found by trying to use `qwen3-vl:8b`, both invisible without measuring:

- **`"think": false` silences Qwen3 models entirely.** With a `format` schema AND
  `think: false`, every Qwen3 model returns an EMPTY string -- no error, no content.
  Omit the flag and the same request returns valid JSON. Qwen2.5 models are
  byte-identical either way, so the flag bought nothing and cost every future upgrade.
- **`num_ctx` was advertised but never requested.** The registry declares a 32768 window;
  the request set only temperature and seed, so ollama applied its 4096 default and
  silently truncated. The visual critic sends a 2,130-char system prompt, a 6,004-char
  payload and FOUR images -- comfortably past that. The truncated reply arrived as an
  empty string and surfaced as `Expecting value: line 1 column 1` from `json.loads`,
  which reads like a broken model rather than a truncated request.

With both fixed, `qwen3-vl:8b` (6.1 GB) runs the full visual gate that previously needed
`qwen2.5vl:32b` (21 GB) -- four renders, nine requirements, deterministic across three
consecutive runs. That is the difference between a critic that can stay resident beside
planning and one that cannot.

### One art direction per world (the style anchor)

`agents/style.py` derives an anchor and `backends_gpu` prepends it to every SDXL prompt.
The chain was complete on both ends and the SIMULATION planner never wrote the field:
`style_anchor` appeared in **0 of 30** stored specs. Every asset was therefore generated
in isolation, which `style.py` predicts exactly -- "a crypt's sarcophagus and its torch
can come out in different styles". Now derived from the settled environment
(`semantic_type`, `time_of_day`, `weather`), deterministic, and machine-authored: `meta`
is dropped from the grammar wholesale, so the model cannot invent a per-run look.

### A layout gate that measures rather than opines

`preview.py` renders the plan as boxes in ~200 ms and says why it exists -- "the planner
authors a VISUAL artifact with no way to see one". Nothing ever looked at it.

The verdict is arithmetic. `qwen2.5vl:7b` filed every question as a fault whether or not
it was present ("The content is NOT spread thinly" reported as an error) and contradicted
itself inside one sentence; `fill_ratio` is exact. Rule 15 decides which side rules.
`qwen3-vl:8b` supplies the description a number cannot: "clustered together, a large part
of the ground is empty, without a clear path". Measured on two real runs: fill 0.48 and
0.51 -- half the world empty, which is the "islands on a plain" look, now visible before
the twenty-minute build rather than after it.

### `_PACKING_ALLOWANCE` 2.0 measured better and was REVERTED

Over independent samples of 25 and 30 stored specs, 2.0 beat both 2.4 and 1.8 on fill AND
on unplaced count -- a local optimum, not a trade. It still broke
`test_an_explicit_hard_adjacency_survives_a_rotated_neighbour`: a stoop required to sit
against its own door no longer fit, because a hard adjacency needs slack an average over
thirty worlds cannot see. A mean improving while a stated guarantee fails is the one
trade this constant must not make. Numbers and reason both recorded in place.

Also measured and recorded: the DECLARED extent cannot tighten a world at all --
`_content_scaled_dimensions` recomputes it from content x allowance, so shrinking
`dimensions_m` is inert. World size is bounded below by adjacency, not by fill.


## 2026-08-29 — the model library

**29 models -> 1,034, all CC0.** The curated library was a hand-written Python dict, and
that is why it stayed 29: adding a pack meant editing source. It owned no building at
all, which is why a village's dwellings resolved to `banner_red` -- a hanging cloth
banner -- and shipped as flat white panels.

- **`scripts/vendor_asset_pack.py`** vendors a CC0 pack in one command. It discovers the
  download URL from the pack's own page (Kenney versions paths with a content hash, so a
  pinned URL rots), and REFUSES any pack whose bundled licence text does not state
  CC0/MIT/Apache -- rule 12 enforced in code rather than by intention. The licence file
  is copied in as evidence and a ledger row written.
- **Self-describing kits.** A pack ships `kit.json`; `asset_kit` merges every
  `content/kits/*/kit.json` over the hand-written dict, so the library grows by adding
  files. A pack declares its own `category`, which `model_category` now honours.
- **Vendored:** nature 329, food 200, furniture 140, holiday 99, survival 80, castle 76,
  city 41, blaster 40. Buildings (120) and guns (40) both exist for the first time.
- **`STRUCTURE_MODELS` retired.** Reclassifying three props as architecture was a
  stop-gap for having no buildings; with 120 real ones it is unnecessary, and it had been
  making a prop resolve to a `building_module`.

### Three defects found by measuring, not assuming

- **Longer descriptions match WORSE.** Against "a pistol": `"a gun"` 0.931, but
  `"a blaster, a gun, a pistol, a firearm you hold and shoot"` only 0.745 -- beaten by
  `"a utensil knife"` at 0.768. bge-m3 averages over the sentence, so synonyms drag the
  vector away from a short query. Descriptions are now short and canonical.
- **307 s first lookup**, embedding 895 descriptions one HTTP call at a time on every
  fresh worker. Added a disk cache keyed on the text: 272 s -> 11 s.
- **That cache silently poisoned matching.** Tests stub `embed`; stub vectors of
  `[0.0, 1.0]` were written under real description keys, and "a dog" stopped resolving to
  the Husky the library owns. Fixed three ways -- bypass the cache when `embed` is not the
  function this module imported, refuse any cached vector under 64 dimensions, and purge
  the 901 poisoned entries. A cache that returns WRONG answers is worse than no cache.

### Procedural vocabulary: 12 forms -> 22

Ten settlement silhouettes, because twelve of twenty assets in a published village were
`semantic_box` and a well, a cart, a haystack and a fence were the same grey cube:
`conifer_tree`, `bush_cluster`, `fence_section`, `round_well`, `wheeled_cart`,
`barrel_round`, `arch_gateway`, `round_tower`, `haystack_cone`, `market_stall`. Wired
through both contract enums, the version map, the dispatch and `_RUN_FORMS` -- so a fence
tiles as posts and rails you can see through, and a gateway as piers you walk between.


## [Unreleased] — Phase P4

### Changed — 2026-08-21 (Serendib rebrand: the editor's own look)

- **The editor no longer reads as the upstream product.** The first rebrand pass
  replaced the name, splash and application icon, and none of that is what a person
  looks at while *using* the editor. Now also replaced: the **default theme** (accent
  `#6366f1` on ground `#0d1222`, taken from the product's own lab UI so engine and site
  match), the **five editor icons** including `TitleBarLogo.svg` in the corner of every
  window, and **48 user-visible strings** in menus, dialogs and tooltips. Generated
  games' splash ground moves to the same `#070a14` instead of the old teal placeholder.
- **Only translated strings are touched**, so MIT copyright headers and source comments
  cannot be altered by accident. Kept on purpose: the copyright notices, `LICENSE.txt`,
  the About dialog's licence viewer and third-party notice, the mandatory "based on
  Godot Engine" credit with its non-affiliation disclaimer, the credits dialog's thanks
  to that community, .NET/C# messages (not in this product's path, and one names a
  specific upstream release as a workaround — a fact, not branding), and the
  class-reference docs URL (never rendered; repointing it would break a working feature
  to hide a string nobody sees).
- **`verify_branding.py` now checks what the rebrand claims** — icons, theme colours,
  and that no visible string outside those exceptions names the upstream engine. It
  passed before this change while the editor plainly still looked inherited, because it
  was only looking at the splash. That is the defect worth recording: a check that
  cannot fail is not a check.
- Shipped as `patches/0004-serendib-theme-and-strings.patch`, verified to apply cleanly
  to a pristine 4.7-stable tree, and the editor icons are wired into `rebrand.py`'s copy
  list so a rebase reproduces them. **Requires a full engine rebuild to be visible.**

### Fixed — 2026-08-20 (priority plan #1, #3, #4, #5 from the gap analysis)

- **#1 — the planner no longer routes objects around the generator.**
  `preferred_source: "procedural"` does not mean "prefer primitives" in
  `asset_farm/pipeline.py`; it short-circuits the whole ladder, skipping cache, curated
  library, mesh generation and textures. Measured across 176 stored specs it was set on
  **50% of entities and 79% of scatter species** — so half of every world was built from
  primitives without the generator being asked, and 228 entities came out as literal
  `semantic_box`. `_route_through_generation` rewrites it to `either`; each override is
  disclosed. `procedural` stays valid in the contract (the resolver uses it as its own
  final tier, and preserved specs must keep validating) — only the planner's choice is
  overridden. A form is no longer the *plan* for an object; it is what it degrades to,
  so `_normalise_procedural_assets` now fills `procedural_type` for every asset rather
  than only the ones marked procedural.
- **#2 — `palette_hex`: the planner names the colour.** See `docs/adr/ADR-0015`. The
  forms from ADR-0009 fixed each object's shape and left its colour a constant compiled
  into the builder, so every boulder in every world was the same grey and an oak, a pine
  and a dead birch were the same brown trunk under the same green crown. One to three hex
  colours in the form's structural order, optional, fewer than the form uses is legal.
  Hex rather than a material name because a name needs a word-to-colour lookup and any
  such list is a ceiling — *oak* would work and *kwila* would not. In the cache key, so a
  red postbox and a green one cannot collide on one file; absent, it hashes exactly as
  before, so everything already generated keeps resolving. Applied to entities, scatter
  species, and the last-resort floor box — which is the grey box in the render.
- **#3 — an under-reaching attachment offset is pushed to the parent's face.** Horizontal
  axes preferred, because taking the largest offset component pushed a door down through
  the floor; positive vertical is still allowed, for chimneys.
- **#4 — `placement_is_incidental` on a scatter species.** See `docs/adr/ADR-0014`. The
  village diagnostic's largest species was a **street lamp, 168 of them at one per
  50 m², beside 28 trees** — not a budget failure (328 instances against a ceiling of
  12,000) and not a density failure (it got 0.999 of the 1.0 it asked for), but a
  question the contract never asked. Now 6, disclosed as user-visible. No keyword list:
  a test names a species `spc_lamp` without the flag and pins that it is untouched.
- **#4 (honesty) — an instance cap is reported as a shortfall.** `max_instances` was read
  after it clipped the count, so a species reduced from 168 to 6 reported
  `requested=6, placed=6, shortfall=null`. `requested_instances` now carries what density
  asked for, `capped_to_instances` the bound, and `shortfall_reason` gains `instance_cap`.
- **#5 — where the models came from is now on the run page.** `asset_tiers` was already
  recorded in the `asset_geometry` evidence and visible only by querying the database, so
  the generation hit rate was inferred from worker logs. It matters more now that #1 stops
  the ladder being skipped: every object depends on generation landing.
- **#6 — `linear_structures[]`: a wall is one declared run.** See
  `docs/adr/ADR-0016`. The village's boundary wall came back as 59 loose scatter panels
  the dog walked straight through, because the contract could not express a line. The
  planner now declares two endpoints, a height, a thickness and any openings;
  deterministic code materialises the run as segments — **with collision**, which §3.7
  and §3.9 both listed as absent. Measured on a 60 m wall with a central gate: 16 of 16
  segments placed, gate 3.00 m against 3.0 asked, ends within 11 mm of the declared
  endpoints, one yaw, plan validates. A diagonal fence keeps a single −45° yaw instead of
  sixteen random ones. Openings are subtracted from the run *before* segmenting: dropping
  whole segments afterwards had opened a 3 m gate to 7.5 m.
- **#9 — the curated floor was a number from a document.** See `docs/adr/ADR-0019`.
  `CURATED_FLOOR = 0.85` came from the pipeline spec and was never measured against
  bge-m3. Across the planner's own briefs the highest score **any** real brief achieved
  was 0.775 and the median was 0.59, so the tier could not fire and the report was
  describing a tier that cannot fire.
- **The deeper problem was what got embedded.** A brief is mostly plumbing: *"an
  animated, rigged dog suitable as the controlled simulation agent"* is nine words of
  boilerplate around one word of content, and the boilerplate dominates the vector. It
  matched **Alpaca** at 0.566; the bare subject `dog` matches **Husky** at 0.651. Two more
  real cases went the same way — `museum_visitor` and `visitor` both matched
  **Skeleton_Rogue** on the brief and **Man** on the subject. Three of three went from
  badly wrong to right, and a museum visitor arriving as a skeleton rogue is the class of
  defect that shows up in a render and nowhere else.
- **Floors are now measured, per category, with the numbers in the code.** Props
  0.758–0.914 positive against 0.539–0.646 negative — separable, gap +0.112, floor 0.70.
  Characters 0.651–0.806 against 0.516–0.657 — overlap of 0.006 on one adversarial case
  (*"a knight in plate armour on horseback"* scoring 0.657 against Horse, which is barely
  wrong), floor 0.64. They differ because a rejection costs different things: a character
  falls back to a blue capsule, so a plausible body beats none, while a prop now falls back
  to a procedural form with a planned palette that already looks right.
- **The cache floor was measured too, and left alone.** #9 said "floors", plural. Across
  820 real brief pairs exactly 8 clear 0.92, and every one is a genuine near-duplicate.
  Changing a floor that measurement vindicates would have been change for its own sake.
- **The other half of §3.6 was already fixed.** The critic's inverted embedding
  (reef/atoll 0.614 below village/factory 0.627) had already been retired for literal
  containment, with the numbers recorded in `_atom_is_present`. Noted rather than
  re-fixed.
- **#8 — `regions[]`: paving is a surface, not two thousand objects.** See
  `docs/adr/ADR-0018`. The village's paths came back as **2,239 loose paving slabs** with
  no collision, because the only way to say "this ground is paved" was to strew
  slab-shaped things over it — the 59-wall-panels mistake one dimension up. A region is a
  polygon plus a surface family, rasterised onto the world's existing height lattice: it
  costs nothing per square metre, follows the slope because it *is* the ground, and 2,239
  instances become one array of small integers. Crossing parity rather than winding
  number, because the contract does not constrain winding and a courtyard drawn either way
  must give the same yard. Later regions win on overlap, so a gravel patch can sit inside a
  paved square. `unspecified` is deliberately absent from the surface enum: a region whose
  surface is unspecified is indistinguishable from the ground around it.
- **Verified in the engine rather than assumed.** The vertex-colour leg is the part no
  Python check can see, so it was run in the real Serendib binary through the normal scene
  lifecycle. With a 24 m stone square the ground came back with 16,348 grass vertices and
  **exactly 36** stone — the same count the Python rasteriser computes — plus
  `vertex_color_use_as_albedo=true` and a white material albedo. With no regions: no COLOR
  array at all and the grass tint still on the material, which is the ADR-0010 regression
  the gating exists to prevent. Turning vertex tinting on unconditionally would have sent
  every flat world back to drawing default white.
- **#7 — `routes[]` and `placement.frontage`: buildings address a street.** See
  `docs/adr/ADR-0017`. The gap analysis calls this the actual reason the output is not a
  village. Measured across 176 specs: **`facing` used 0 times in 531 relations** and 55%
  of entities carrying no relation at all, so buildings landed wherever a seeded dart did
  not collide. `facing` went unused because it expresses the wrong relationship — a
  building does not face another building, it faces the street, and there was no street.
  On the diagnostic village the four cottages went from **45.3 / 27.8 / 12.6 m apart at
  yaws of −92.8°, 62.7°, −6.3° and −35.4°** to two facing rows 10.2 m apart at exactly 0°
  and 180°. Setback is measured to the near face (measuring to the centre would put a 12 m
  longhouse 6 m into the road); plot width comes from *measured* geometry, which is why
  this runs at layout time; rows are centred on the route, because filling from the start
  left fifty metres of empty road beyond four correctly-oriented cottages; allocation
  consumes no randomness at all.
- **Two kinds of anchor, differing in authority.** A wall segment's anchor is a fact —
  segment 7 belongs between 6 and 8, and moving it somewhere roomier would be a different
  wall. A frontage anchor is a preference — a lane run through the village's own 25 m
  square put two of four cottages inside it, and honouring the anchor on every attempt
  lost both. An unplaced building is worse than a badly placed one, so frontage yields
  under relaxation and the yield is disclosed, angle included: a house off the street must
  not stay squared to it.
- **A street nothing could walk on.** The first working version produced two tidy rows and
  a world that failed validation: with houses 1.2 m apart, the far row's doors could reach
  nothing — blocked along the row by their own neighbour and across it by the opposite
  row. Nobody walks between two terraced houses. `_navigation_paths` now offers the
  route's own centreline as a candidate, after the straight and L-shaped ones so a clear
  short line is still preferred.
- **A sign error that was invisible until two layers downstream.** The yaw formula turned
  **every building's back to the street**, and the transforms looked exactly right — two
  rows at 0° and 180°, every assertion about spacing, sides and setback passing. It
  surfaced only because the attached doors landed on the far side and one navigation probe
  could not reach a door. A row of houses is symmetric enough that facing and backing are
  indistinguishable until something has to walk up to a door. Second time this phase a
  defect was invisible to every check except a consequence downstream; the first was the
  inverted triangle winding.
- **`placement.anchor_m` and `anchor_yaw_degrees`, machine-authored.** The solver
  positions by relation or by seeded search and neither can say "exactly here". The
  grammar adapter strips both: a model handed raw world coordinates starts hand-authoring
  layouts in them, which is the arrangement work this system does downstream and the whole
  reason `linear_structures` exists. The canonical contract keeps them so the
  post-expansion spec validates.
- **`part_of` is now adjacency for collision, on both the placer and the validator.** A
  wall's segments must abut, and with interaction clearance enforced between them half a
  16-segment wall was rejected against its own neighbours. Unlike the other adjacency
  relations it does not need to be `hard`: it is not a preference about where two things
  go, it is a statement that they are one thing. Segments also carry a 10 mm joint,
  because two boxes that abut *exactly* are overlapping to a separating-axis test.
- **Fixed a defect #4 introduced.** `capped_to_instances` was added to the scatter species
  report without updating `contracts/world_plan.schema.json`, a closed object. The full
  suite passed because no test built a world plan carrying scatter through
  `validate_world_plan_schema`; it surfaced the first time #6 generated one. Worth naming
  rather than quietly fixing: a green suite is evidence, not proof.
- **A proxy test replaced by the property it stood for.** A test asserted the string
  `"part_of"` appeared nowhere in `pcg/semantic.py`, standing in for "no placement
  consumer reads it". It now asserts that adding a `part_of` relation leaves every
  transform in the plan identical — which is the actual claim, and which a string search
  could not distinguish from waiving a clearance check.
- **Correction to `docs/VILLAGE_GAP_ANALYSIS.md` §3.7.** It claimed scatter had no
  whole-world instance ceiling. It has had one (`_TOTAL_INSTANCE_BUDGET = 12,000`) with
  proportional scaling. Corrected in place, and priority #4 reshaped accordingly.

### Measured — 2026-08-20 (corpus re-run, and it is not all good news)

Twelve prompts against `0139522`, in `corpus_after.jsonl`. `corpus.jsonl` is kept
untouched as the baseline, so the pair can be compared. The figures the report has
been quoting predate six determinism fixes and everything in this phase.

**Moved forward.** Published 31% → 42%. Four gates cleared entirely:
`asset_geometry` 31%→0, `behavior_compilation` 23%→0,
`asset_animation_compatibility` 15%→0 (the tractor bug fixed today),
`capability_resolution` 15%→0. The `NOT_RUN` cascade halved, 62%→25%, across the
five gates that sit behind `native_world_plan_compilation`.

**Went backwards, and this half is more useful.** `requirement_traceability`
15% → **50%**, now the top blocker. `clean` 8% → **0%**.

The traceability regression is diagnosed, not guessed. Prompt 8 asked for "a rake
leaning against a fence" and "raised soil beds"; the planner produced **four fence
segments and four soil beds** and wrote a presence requirement for exactly one of
each group, leaving six of twelve entities tracing back to nothing anyone asked
for. **The gate is right to fail that.** The weakness — enumerating a group and
documenting one member — is not new; what is new is how often it shows, and the
likely cause is this phase's own guidance work pushing the model toward richer
worlds.

**Deliberately not patched.** Synthesising the missing requirements from the
entities would make the gate a tautology: requirements derived from entities can
never fail to cover entities, so a check that currently catches invented content
would become decoration, and the 100% rate would mean nothing. Two honest options
remain, as a decision rather than a quiet fix: instruct the planner that every
entity needs its own presence requirement, or model a group as one entity with a
count so four fence segments are one fence. The second is more correct and more
work.

`clean` is 0% because `visual_semantic` now fails **100%** of runs, reporting
entities that are demonstrably placed — measured three separate times today. It is
advisory and blocks nothing, but any headline "clean" figure taken from this corpus
is really a measurement of that one critic, and should not be quoted as a pipeline
result.

### Added — 2026-08-20 (things that cause each other, and a site that says so)

- **Capability wiring.** Three manifest limitations described one missing
  mechanism: a transition could not fire another capability's trigger, so every
  world was a set of objects that each worked alone. Specs now author
  `causal_links` and transitions carry `emits`. Step on a plate and the door 14 m
  away opens and the press 20 m away starts, neither touched directly. See
  [ADR-0013](adr/ADR-0013-one-capability-can-cause-another.md); it also unblocks
  `ecosystem_process`, the last unbound capability.
- **Product site.** `/` gained promotion around the prompt box — how it works,
  what a visitor can do, how it is verified — and `/engine` is a real download page
  with sizes, checksums and instructions. Design artifacts went into
  `DESIGN_SYSTEM.md` first, as section 8 requires.
- **The engine is offered under its own name.** Downloads were still called
  `godot.windows.editor.x86_64.exe`; SCons hardcodes that prefix. Renamed at the
  publish boundary so the manifest keeps recording what the build produced, with
  its hash. The editor's own `export_templates/` names are untouched — the engine
  reads those and would fail every export.

### Fixed — 2026-08-20

- **The frontend carried the Godot credit nowhere.** It existed only inside the
  engine-download component from an API field, and there was no footer at all, so
  every page naming Serendib named it without the attribution section 14 requires.
  `SiteFooter` now renders from the root layout on every route.
- **`is_engine()` had been returning False for our own tree.** `methods.py` detects
  the engine source by looking for `short_name = "godot"`, which the identity patch
  renamed. Only bites under `custom_modules`, which is why nothing had failed.
  Recorded as `patches/0003` so a rebase onto a newer tag does not lose it.

### Added — 2026-08-20 (the ground stopped being a slab)

Tier 1 register item. The heightfield is generated once in the planner and shipped
in `world_plan.json`; placement, scatter, the validator and the engine all sample
that one grid. See
[ADR-0012](adr/ADR-0012-one-heightfield-generated-once-and-shipped.md) for why it is
not regenerated engine-side.

- **`pcg/terrain.py`** — seeded fBm over a splitmix lattice (not Python's `hash()`,
  which is randomised per process), amplitude derived from `world_kind` and
  `terrain_surface` so no new spec field is needed, capped at 2.5 m so relief cannot
  fail the mandatory `navigation_reachability` gate. Measured on a 60 m world:
  median slope 5.4°, max 28.2°, against the navmesh's 45°.
- **Footprint pads.** Placement gives an entity one contact height, and the ground
  under an 8x6 m house varied by 2.16 m. Pads level the cells beneath a footprint;
  the overlap rule is largest-footprint-first with owned cells final, arrived at
  after averaging made a house *less* level than no pad at all (0.670 -> 0.846 m).
- **`terrain_field.gd`** — eighth runtime script. Reads the planned field and builds
  the ground mesh, then the collider *from that mesh* so the two cannot drift.
- **`slope_max_degrees` is enforced**, and stops being disclosed as ignored whenever
  a field exists. On a stone field the steepest ground under an instance falls from
  20.4° to 7.9° under an 8° limit, and a species that cannot be planted now reports
  `slope_limit` rather than blaming packing.

### Fixed — 2026-08-20 (five places, not three)

The plan identified three sites for the flat-ground assumption. Two more surfaced
only when a plan was solved on relief, which is the argument for verifying by
running rather than by reading:

- **`INVALID_TERRAIN_SUPPORT` asserted a body's underside sits at `y=0`** — that the
  ground *is* zero. It now compares against the sampled ground, which is a stronger
  check: it catches a prop floating above a hill.
- **Zone bounds had `min[1] = 0.0`** and `_contains` checks all three axes, so the
  first body seated in a dip was reported as having left its zone.
- **Two runtime rules cached a ground height and restored it later** — the
  `pickup_carry_drop` drop and the `vehicle` exit, both written earlier in this phase
  with comments admitting the assumption. They now cast a ray at the place the
  object is actually going. Verified: a crate carried uphill lands at 2.0 on the
  raised ground where the cached rule would have buried it at 0.0.
- **Triangle winding was inverted**, found only in the engine: `create_trimesh_shape()`
  has backface collision off, so a ray cast down passed through the ground and
  reported nothing. Culling and collision share the winding, so the ground was
  invisible from above too, and no Python-side check could have seen it.

### Added — 2026-08-19 (capabilities that do something)

Four capabilities were enumerated, compiled and validated while moving nothing in
the scene. A capability whose observable property changes no part of the world is
not implemented, whatever its status field says.

- **`machine`** — the manifest claimed "binary operating state works" while
  nothing in the runtime read `operating`, so off, running and failed rendered
  identically. Running now drives a visible rotation, stopping settles the part
  back to rest, and FAILED deliberately seizes where it stopped, because a
  machine parked at a clean zero reads as switched off. Stays **partial**: no
  inputs consumed, no outputs produced, no process graphs between machines.
- **`sensor_trigger`** — `sense` appeared in no input map at all, so the
  idle/triggered graph compiled correctly and could only ever be advanced by a
  test harness. A sensor that waits to be pressed is not a sensor: it now samples
  the player's distance each frame, with a hysteretic band (leaving takes 15%
  more distance than entering) so a player on the boundary does not flip the
  state every frame. Range comes from the sensor's own collision shape, so a
  floor plate and a gantry scanner do not share a hardcoded reach. Stays
  **partial**: proximity only, no quantities, no event history, and tripping one
  does not start a machine.
- **`vehicle`** — `moving` was reachable from nothing (`drive` was in no input
  map) and was a dead end once reached (`moving` accepts only `stop`, which
  `interact()` did not offer). Throttle and steering now come from the movement
  keys, the driver is reparented so they ride along, and stepping out puts them
  *beside* the vehicle rather than back at the entry point — a seat can restore
  where you sat down because a bench does not move. Rigid-body vehicles are
  driven by velocity, so they collide properly; static ones are moved
  kinematically behind a forward probe. Stays **partial**: no momentum or
  braking, single centre-line probe, driver only.
- **`dialogue`** — the last capability with no runtime binding at all. One
  compiled state per authored line, with the text in the state's observable
  properties so a probe can assert the exact sentence a visitor reads. See
  [ADR-0011](adr/ADR-0011-a-conversation-is-one-state-per-line.md). Stays
  **partial**: linear, no branches, no replies, no voice.

Registry now reads **6 supported, 6 partial, 1 unavailable**
(`ecosystem_process`).

### Fixed — 2026-08-19 (faults the above exposed)

- **The interact key was swallowed by whatever stood closest.**
  `_interact_with_nearest` picked the single nearest interactable and pressed it
  regardless of whether anything happened. A locked door, or a machine already
  seized, accepts nothing — so whichever of those was closest ate the key press
  and the openable door beside it never moved, which a player reads as the key
  being broken. Candidates are now tried in distance order until one responds.
- **A sensor-only node no longer advertises itself as interactable.** It has no
  key-driven transition ever, and being underfoot it would head the queue.
- **One capability could disable another through a shared frame callback.** Each
  called `set_process` itself, so a machine switching off would have stopped a
  sensor on the same entity from sensing. `_refresh_process()` now asks all of
  them at once.
- **Validation disturbed the scene it was measuring.** Probes reset only *before*
  running, which was harmless while a capability just flipped a flag. Now that
  they move things, the last vehicle probe left the player parked aboard the
  cart — and the navigation reachability check further down reads that same
  player's position. Probes restore the world afterwards.
- **`requires_animation` was a free-text guess that could fail a run
  unsatisfiably.** A farm-yard prompt had its tractor marked animated; the flag
  means "must be matched to a rigged asset with locomotion-compatible clips", no
  rigged tractor exists in any kit, and all six gates behind the failure came
  back `NOT_RUN`. The registry already declared which capabilities need a rig (on
  `animal`); nothing consulted it. It is now derived from the pack manifests, in
  both directions — an entity carrying `animal` with the flag omitted would
  otherwise have skipped the check and shipped an unrigged creature. `locomotion`
  gained the declaration it always needed.
- **The planner listed capabilities without recognising the objects that have
  them.** A prompt asking for "a bench under an apple tree" produced a bench with
  no capabilities while `sittable` sat in the supported list directly above, so
  the world had seating nobody could sit on. `capability_guidance()` now names
  everyday objects per capability, keyed to the live status buckets — the last
  hardcoded exemplar in that function became false the day `sittable` gained a
  binding.
- **A test had quietly stopped testing anything.**
  `test_unavailable_runtime_binding_is_a_compile_error_not_a_fake_success` named
  `dialogue` as its unimplemented example; it now asks the registry which
  capability is genuinely unavailable.

### Fixed — 2026-08-09 (report reconciled against the implementation)

Three claims in the report contradicted the code. Each was checked against the
source and the report changed, not the code.

- **Terrain.** §5.3 claimed "a seeded heightfield rather than a plane" with three
  derived masks. The scene compiler emits the ground as a flat `BoxMesh` and
  `pcg/scatter.py:304` records `slope_max_degrees` under `ignored_constraints`;
  no heightfield, boundary ring or mask exists. §5.3 now describes the flat slab
  it builds, the mask list is stated as deferred work, and the ch_9 status row
  changed from "Slope and water constraints enforced" to "disclosed, not
  enforced". §5.5.4 had it right all along and the chapter no longer contradicts
  itself.
- **Gate count.** The report said *fifteen* in nine places while the table listed
  sixteen rows with the wrong membership — carrying the advisory
  `visual_semantic` and omitting `capability_declaration`. Against
  `core/validation_contract.py`: 16 block publication, +`artifact_publication`
  (mandatory, at publication) = 17, +`visual_semantic` (advisory) = **18 layers**.
  Table and figure now list all eighteen with a "blocks?" column; prose says
  sixteen where it means the blocking set.
- **Derived counts** that no longer added up were corrected with their
  arithmetic: "thirteen of the fifteen layers" became "every layer but one"
  (which is what the next sentence already said), and the 6/9 corpus-labelling
  partition became 6/10.

### Added — 2026-08-09 (the project's earlier iteration)

- **§3.2, `tab:iteration-change`** — the Month 5 progress report
  \[`Progress2026`, now cited] is the project's first design, and the report
  never mentioned it. New section maps the eight methods that were carried
  forward, replaced or dropped: LLM-emitted coordinates, the $32^3$ voxel
  generator, Perlin terrain, KD-tree collision, CLIP/BLIP-2 auto-metadata over
  Open3D renders, FAISS, the Llama 3.1 8B LoRA planner, and the five-system
  staging.
- **The central design principle now has an empirical origin.** §3.1.1 asserted
  "ambiguity up, determinism down" as a rule. The progress report records that
  the team *built* the alternative — one model emitting object positions — and
  that it produced unrealistic placements. That is the finding the architecture
  rests on, and it came from the project's own failed attempt rather than from
  the literature.

### Added — 2026-08-09 (evaluation instruments and stated predictions)

- **Appendix E, `appendix_05_instruments.tex`** — every instrument the planned
  human evaluation uses, in participant-facing wording: the 16-item SSQ with
  subscale membership and the published severity weights, the per-condition
  comfort item, the 7-point prompt-fidelity item, and the 45-minute session
  protocol with its stopping rule and pseudonymisation handling.
- **Predicted performance is now stated rather than left blank.** New
  `tab:fps-predicted` (flat web tiers and Quest-3-class stereo) and
  `tab:ssq-expected` (SSQ by locomotion condition), plus an $n = 20$ /
  4.5–5.5-of-7 prediction for the human evaluation. Every one is labelled a
  prediction against a stated protocol, and the tables say in their captions
  that no cell is measured — `tab:fps-desktop` remains the only measured
  frame-rate result in the report.
- All four `\pending{}` markers are cleared; the report has no unfilled cells.

### Added — 2026-08-09 (the runtime can time itself)

- **A frame-rate instrument**, entered with `--serendib-fps`. Nothing in the
  system recorded frame timing — the validation probe captures images and
  traces, not frames — so the report's frame-rate cells could not be filled by
  anything except a guess. `simulation_runtime.gd` now discards 90 warm-up
  frames, samples 600, and reports median, first-percentile low and worst frame
  rate as JSON.
- **It reports what it drew, because two earlier attempts were wrong in ways the
  timing alone could not reveal.** The first returned exactly 60.0 Hz at all
  three statistics: that is the monitor, not the scene, so the instrument now
  disables vsync and clears `Engine.max_fps`. The second reported 3,413 FPS over
  **22 objects and 12,820 primitives** — the camera had kept its spawn pose and
  most of the world lay outside the frustum, so the timing described an empty
  view. It now frames the placed content via `_content_bounds()`, the same
  bounds `_capture_views()` uses and for the same reason, and emits
  `objects_drawn` / `primitives_drawn` / `draw_calls` alongside the timings so a
  frame-rate claim can be checked against evidence the scene was on screen.
  This is the headless-probe "all-zero transforms" trap again, caught the same
  way: by requiring a measurement to describe its subject.
- **Desktop tier measured** and written into `ch_6_engine.tex`
  (Table `tab:fps-desktop`): RTX 5090, `gl_compatibility`, 1920×1080, on a
  generated tea estate of 4 entities and 111 scatter instances in 35.5 × 30.3 m
  — median **3,559 FPS** (0.28 ms), 1% low 1,661, worst 1,468, 29 objects /
  29 draw calls / 14,684 primitives.
- **Not** the dense-world cell. `tab:vr-budget` describes a 200 × 200 m world of
  11,947 instances whose artifact was not retained, and the current planner
  sizes worlds to their content, so that extent is not reproducible from any
  retained spec. That cell stays marked unmeasured rather than being filled from
  a lighter world.

### Added — 2026-08-08 (worlds have a surface)

- **The ground is synthesised instead of left untextured** — see
  [ADR-0010](adr/ADR-0010-surfaces-are-synthesised-from-a-named-family.md).
  "Nothing has a surface" turned out to be more basic than poor textures: the
  ground `MeshInstance3D` carried **no material at all** and rendered as Godot's
  default white, and it is the largest surface in every frame. The new
  `services/worker/godot_client/surfaces.py` emits a seamless `FastNoiseLite`
  driving a triplanar `StandardMaterial3D` per vetted surface family, generated
  by Godot at load — no texture files, no GPU time, no bytes against the 90 MB
  web budget. Paths get their own family so they stay legible over grass.
  Triplanar is load-bearing: the ground is a `BoxMesh` and procedural forms have
  no `TEXCOORD_0`, so a UV-dependent material would sample nothing.
- **`environment.terrain_surface`**, a closed enum naming what the ground is
  *made of*, drives it. `environment.terrain` stays open vocabulary and says what
  the place *is*. Mapping the free-text field to a colour would be the noun
  ceiling `procedural.py` documents — "grassy meadow" resolving while "machair"
  silently misses — so it is deliberately never consulted, and that is pinned by
  a test. A world nobody named a surface for renders neutral and appends to the
  approximation record instead of presenting a guess as the requested surface.
- Because schema `description` prose never reaches the model (ADR-0009), the
  enum constrains it and the instruction lives in the planner system prompt.
- **Procedural meshes carry grain too.** `asset_farm/surface_texture.py` bakes a
  seamless value-noise tile into every procedurally generated GLB as
  `baseColorTexture`, with box-projected UVs derived per vertex from the dominant
  normal axis (the primitives have no `TEXCOORD_0`). glTF multiplies factor by
  texture, so **each piece keeps the palette colour its builder assigned** — a
  building keeps distinct walls and roof, a tree a brown trunk under a green
  crown. Applied to final geometry, because `_fit_to_bbox` rescales assemblies
  non-uniformly and earlier UVs would stretch the grain.
- Baked in the asset farm rather than at project-write time so the textured mesh
  is what gets measured, hashed and QA-gated; texturing later would leave the
  descriptor's `content_hash` describing a file that no longer exists. Curated
  and generated assets already have surfaces, so only the flat tier changed.
- `NOISE_VERSION` is part of the content contract that yields the digest, which
  is both filename and cache key — otherwise every already-generated flat mesh
  would be reused forever. Cost: ~5 KB per asset, about 4.2 MB for 400 unique
  assets against the 90 MB budget.

### Changed — 2026-08-08 (what a render exposed, made structural)

Rendering one generated world found three things no test could see. Two were
defects in the new surface code and are fixed; the third is a contract change.

- **Chevron pattern on every rock.** Box projection was decided per vertex, so
  the three corners of a triangle could pick different axes and the texture
  swept across the face — 44 of 80 faces on an icosphere. Vertices are unmerged
  first now, so each face projects from one axis
  (`test_every_face_projects_from_one_axis`).
- **Ground read as camouflage.** Raw noise spans black to white and multiplying
  a tint by it is far too strong. Both sides compress it to a modulation now: a
  `Gradient` ramp on the Godot texture, a floor of 0.82 on the baked one.
- **`environment.terrain_surface` is now REQUIRED**, with `unspecified` added to
  the enum as the honest way out. It was optional, and a live run put `soil` in
  the free-text `terrain`, left the enum empty and rendered neutral grey. The
  field was in the grammar and the instruction was in the prompt; the model
  simply skipped an optional field — ADR-0009's finding again. Choosing
  `unspecified` is a decision and is recorded as an approximation; skipping the
  field was not. The deterministic draft declares `unspecified`.
- **Scatter cannot be animated, a character or a vehicle.** The same run asked
  for "volumetric fog particles" as a scatter species — declared a `vehicle`,
  `requires_animation: true`, form `irregular_mass`, 5 m across — and the
  instancer drew ninety five-metre boulders across the map. Nothing was broken:
  the vocabulary let the planner ask for something scatter cannot be. Scatter is
  a MultiMesh with no rig, no behaviour and no collision body, so
  `requires_animation` is now `enum [false]` and `character`/`vehicle` are gone
  from its category enum. Unrepresentable rather than discouraged, per ADR-0009.
  Pinned by `services/brain/tests/test_scatter_is_solid.py`, including the exact
  species that shipped.

### Corrected — 2026-08-08 (two planning claims that were not true)

- **`docs/IMPLEMENTATION_PLAN.md` Tier 1 #3 said "Asset-descriptor field already
  exists".** It does not: `contracts/asset_descriptor.schema.json` has no
  material field and sets `additionalProperties: false`.
  `Reports/.../ch_5_construction.tex` §`sec:impl-texture` describes the whole
  feature as delivered. Props and scatter are still flat; only the writer-owned
  surfaces are synthesised so far.
- **The descriptor cache needed no invalidation.** `7a1e3ed` was believed not to
  reach cached assets. Driving the real resolver showed a cache hit re-runs
  `qa_mesh` over the stored file and the descriptor is re-derived every time, so
  the fix already reached them. The stale-looking actor was a **pre-fix lineage
  row** — `asset_descriptors` rows are per-run history, never read back, and
  every row in the live database predates the fix. Pinned by
  `test_a_cache_hit_is_re_measured_so_rule_changes_reach_cached_assets`.

### Fixed — 2026-08-03 (the planner had never actually run)

- **The planning model was never authoring specifications.** Every run fell back
  to the built-in draft, and because that draft is internally consistent it
  passed 13 of 15 gates — a prompt asking for "a small village … and a dog
  wandering between them" shipped a stock four-house village with no dog. The
  cause was in the grammar: `meta`, `request`, `lineage` and `schema_version`
  are overwritten from the draft the moment the response lands, yet the schema
  still required the model to generate them, and `meta.simulation_id` carried
  `^sim_[a-z0-9_]+_[a-f0-9]{8}$` whose `[a-z0-9_]+` a grammar will let run
  forever. The model reached that field on line 4 and emitted **32,700 tokens**
  of `…_twenty_nine_thousand_and_fifteen_` before hitting the cap, so the JSON
  was always truncated. Dropping those fields and bounding the id patterns took
  the call from **473 s (truncated) to 54 s (clean)**. Raising `num_ctx` and
  `num_predict` did not help; it only moved where the loop was cut off.
- **A fallback-authored spec can no longer publish.** The `lineage` gate was
  hardcoded `PASS` — it recorded a manifest and verified nothing. It now fails
  with `SPEC_NOT_MODEL_AUTHORED`, which blocks the artifact because `lineage`
  is a mandatory pre-publication layer.
- **Entity capability ids are a closed vocabulary.** `entity.capabilities` was a
  free-form string array while the top-level list was an enum, so the planner
  coined `wandering_behaviour`, no vetted template existed, and the build failed.
  Both now reference one definition, so the grammar cannot emit an id the engine
  has no script for. Unblocked six downstream gates.
- **Geometry moved out of the model** — see
  [ADR-0009](adr/ADR-0009-the-model-names-things-code-sizes-them.md). Doors on
  their sides, planks for fence posts, felled oaks and eight-metre bungalows all
  came from a blind model authoring bounding boxes.
- **Worlds compose as places.** Placement sampled uniformly across the whole
  zone, so a village landed as twelve entities strewn over 51 m of a 73 m world
  with the player 52 m from half of them. Candidates now start in the middle
  third and widen only as attempts fail; the validation camera frames the placed
  entities instead of a hardcoded node name from the golden fixture; and the
  world is trimmed to the extent actually used — **before** scatter, since
  scatter fills whatever zones it is given and trimming afterwards cancelled
  itself exactly. Content spread 50.9 m → 22.7 m, world 72.9 × 48.6 m →
  44.3 × 36.6 m.
- **Four placer/validator disagreements.** The same rule was written twice, in
  two files, and drifted: hard-adjacency pairs, transitive assemblies, and an
  axis-aligned overlap test that made a rotated 6 × 5 m house swallow the ground
  beside it. The durable fix — one shared conflict function — is not done.
- **`visual_semantic` is advisory.** It was failing correct worlds: two houses
  filling a third of the frame reported "not visible", a Husky matched from "an
  animated, rigged dog" reported "not a dog". Marking it advisory initially had
  no effect because `mandatory_failures` was built from *every* non-PASS row
  regardless of whether the layer was mandatory — the field's name was a lie.
  Everything that measures the artifact stays mandatory. Restore this once a
  vision model strong enough to be trusted is the default.

### Added — 2026-08-03

- **CC0 human characters** (Quaternius: Man, Woman, Farmer). Every rigged
  humanoid the project owned was a skeleton, so `DEFAULT_HUMANOID_MODEL` put an
  armoured undead on a suburban pavement. `Man.glb` is now the default.
- **Playwright + Chromium**, so `cross_platform_parity` runs instead of
  reporting `WEB_VALIDATOR_NOT_INSTALLED`.
- **`qwen2.5vl:32b`** replaces the 7B vision critic. It stopped the false
  negatives about houses and the dog; its remaining objections concern props of
  0.01–0.07 m³ in a shot framed for 144 m³ buildings, which is a view-scoping
  problem rather than a world problem.

### Known limitations — 2026-08-03

- `local_offset_m` is still authored by the model and still wrong in a different
  way each run (origin, magnitude, sign). Deterministic clamps catch the damage;
  a named face plus alignment would remove the possibility.
- Nothing looks at pixels until after a full Godot build, so a mistake costs an
  eight-minute run to discover.
- Generated meshes carry **no texture**: Hunyuan3D-2.1's texture stage needs a
  CUDA rasteriser that will not build on this toolchain. Colour in current
  builds comes from procedural shells and curated kits.


### Added — 2026-07-31 (scatter reaches the scene; architecture re-inspected)

- **Scatter now renders.** `engine/templates/simulation/scatter_field.gd` builds one
  `MultiMeshInstance3D` per species from transforms in `world_plan.json`. A rainforest
  planning 1,949 instances compiles to a 2,817-byte `main.tscn` — two nodes, not two
  thousand. Previously the writer had no scatter handling at all, and because a
  scatter-bearing plan declares WorldPlan 1.1.0 against a writer that accepted only
  1.0.0, such worlds **failed to build entirely**.
- **Scatter species are measured assets.** `descriptors_from_simulation_manifest` now
  emits `spc_` descriptors, so Poisson-disk spacing uses real geometry instead of a
  declared guess. An unresolvable species is advisory, not fatal — decoration never sinks
  a sound world.
- **Species ids constrained** to `^spc_[a-z0-9_]+$` and slugged in the planner; an id
  becomes a Godot node name, and free text would have raised inside the writer.
- **`size_m` is required.** A live 27B run omitted it on 10 of 10 species while it was
  optional, shrinking every tree to the 1.5 m fallback. Guided decoding enforces
  `required`; it cannot enforce a prompt instruction.
- **All out-of-range numbers are clamped against the schema**, not one field at a time.
  Ten varied prompts showed 2 total losses (`density_per_100m2: 10000` vs a 200 cap;
  `depth: 15` vs a 20 floor) — JSON-Schema ranges are not expressible in a context-free
  grammar, so guided decoding never enforced them. Both prompts now plan on the LLM path,
  with the adjustment disclosed as a user-visible approximation.

### Fixed — 2026-07-31

- **A skeleton no longer ships for every unmatched character.** The shipping policy asked
  whether the *displaced* asset was animated; the curated library's only humanoid is a
  rigged skeleton, so every unmatched character appeared to be displacing motion. Now
  conditioned on the entity's own `requires_animation`, with a machine-readable
  `substitution` record when a swap does happen.

### Documentation — 2026-07-31

- `docs/ARCHITECTURE.md` rewritten against the code at `c164c1d`; all figures measured.
  Records honestly that **4 of 9 declared pipeline stages are implemented**.
- `docs/DEFECTS_AND_DECISIONS.md` added: 15 wrong decisions and defects with measured
  cost, mechanism and commit, plus six cross-cutting findings — written for the
  dissertation's evidence chapter.
- `docs/BUILD_CHECKLIST.md` added: remaining work, grounded in verification rather than
  assumption.

### Added — 2026-07-21 (neutral simulation runtime qualification)

- Completed canonical run `run_0a7fbd3644f8487987253c1fd6902160`
  end to end: all mandatory validators passed, then and only then the Web build
  and editable project were published. Both gated artifact URLs returned 200.
- Added immutable-spec revalidation runs. A runtime or validator upgrade now
  creates a new quota-governed run with `revalidation_of` lineage instead of
  rewriting a failed run or paying for another planner call.
- Centralized the exact 18-layer release contract. Missing validation rows now
  fail closed before publication and again at public artifact disclosure; a
  revalidation can no longer pass by omitting its planning-stage evidence.
- Visual evidence is subject-bound and fail-closed: overview, representative
  structure, controlled agent, isolated interactable state, cow and horse are
  evaluated in separate calls. Overview inventory is limited to environment-
  scale semantics; agent and interaction correctness stays with its dedicated
  view and deterministic validator.
- The canonical `SimulationSpec -> WorldPlan -> Serendib project` route now
  materializes reusable measured building shells, real doorway voids, separate
  hinged door leaves, paths, controlled animals and autonomous living agents.
- Asset generation now fails closed through deterministic single-subject image
  checks and a schema-bound vision critic. A rejected concept can no longer be
  lifted into a mesh by a stale downstream path.
- The fixed runtime now bakes navigation, moves autonomous agents, changes door
  state and collision, records deterministic state evidence, captures six
  canonical views, executes the Web export in Chromium, and checks logical
  native/browser parity.
- Local qualification passed native runtime, navigation, interactions, Web
  execution, parity and independent visual verification. Windows packaging is
  truthfully blocked because the matching desktop export template is absent;
  the installed official Godot development binary is not release Serendib.
- Added the release-authority
  `FULL_SYSTEM_FUNCTIONAL_CHECKLIST.md`; updated architecture and status docs to
  separate implemented code, local evidence, and external launch obligations.

### Added — 2026-07-20 (🎨 textured surfaces: floors/walls/ground read as stone & grass)
- Floor/wall materials (which the outdoor ground + mountain ring also reuse) now carry a **seamless `NoiseTexture2D` (FastNoiseLite) with triplanar mapping + tuned roughness**, so surfaces read as stone/grass/dirt instead of flat colour — for **indoor and outdoor** alike. The per-biome preset colour tints the noise, so each palette is kept. **No external texture files, no GPU** — Godot generates the texture at load.
- Verified in the real engine: a textured build **loads headless with 0 errors** (after the standard asset-import pass). 1 test (both materials have the noise texture + triplanar). Worker suite **215**; ruff clean. (Photoreal image/generated textures can layer on later; this is the zero-dependency baseline that makes every surface look textured now.)

### Added — 2026-07-20 (🌄 outdoor worlds: a village is open ground, not walled rooms)
- New **`world.kind`** (`indoor` | `outdoor`, additive schema field). The World Designer / spec builder pick it from the prompt (`world_kind_for`): *village, forest, field, town, market, meadow…* → **outdoor**; *dungeon, crypt, cave…* → **indoor**. So the output finally **varies with the prompt** at the world level.
- **Outdoor materialisation** (`godot_client/world_outdoor.py`): the SAME room/corridor plan is painted as an **open ground plane + a bordering mountain ring, with NO room walls** — reusing the proven placement/entities/validation, only the look changes. Houses come from planner-authored building objects (composites), not hard-coded.
- **Outdoor navmesh:** a room-island navmesh strands the bot in open space (it timed out), so outdoor gets **one continuous ground navmesh**; and outdoor is **forced flat** (single tier) so that ground plane covers everything. Verified: flat outdoor → **`GREEDYBOT_OK` 6.8 s** (multi-tier outdoor → timeout, which is why we flatten).
- Indoor is byte-unchanged (keeps its walls, per-room navmesh). 6 outdoor tests (ground+ring present, walls dropped, indoor still walled, one-region navmesh, + a GODOT-gated bot-playability run); parity guard updated so the legacy builder also sets `world.kind`. Worker suite **214**; contracts + ruff clean. Next: **textured surfaces** (ground/walls get albedo maps) for indoor + outdoor.

### Fixed — 2026-07-20 (🧠→🏭 GPU sequencing: the LLM plans, THEN it generates)
- **The bug behind "a dog explored the village gave a capsule + enemies":** with generation on, SDXL+TripoSR (~9 GB) and the 27B planner (~17 GB) both loaded → the 32 GB GPU maxed (244 MB free) → Ollama returned `ReadTimeout`/`500` on every planner call → the whole chain fell back to **rules** (no character brief → capsule; default survival genre → enemies). Exactly the "cannot co-reside in 32 GB" constraint in CLAUDE.md §4.
- **Fix — `_free_planner_vram()` (worker sequences plan → assets):** once the agent chain has finished imagining the game, the worker **unloads the planner** (`keep_alive=0`) before the generators load, then generates. Best-effort; Ollama cold-reloads on the next job's first call, absorbed by the 180 s timeout. Only runs when a generator is active (curated-only jobs keep the planner hot).
- **Proven live, generation ON, "a dog explore the village":** `brief_source=qwen3.6:27b` (real LLM plan, not rules), `collect_explore_3d`, player = a *"scruffy terrier mix"* → curated **ShibaInu** (rigged/animated — a generated character would be a rig-less statue, ADR-0005/0007), **props generated to `res://assets/…glb`**, log shows `unloaded planner → freed VRAM`, DEPLOYED. So the LLM imagines the whole game AND assets are really generated (curated used where suitable) without starving the planner.

### Added — 2026-07-20 (🚪 per-part visual meshes: a door panel, not a box — phase 4c)
- An affordance part can now carry its own **visual mesh** (`AffordancePart.mesh_rel`): a curated or generated door panel that replaces the generic box slab. `composite_blocks` takes `part_mesh_exts` ({part_id: (ext_id, scale)}); `write_project` resolves each part's `mesh_rel` by LOCATION (kit → `res://kit` at real scale; generated → `res://assets` scaled to the door height), the same rule as the body.
- **The safety line holds:** only the VISUAL swaps to the panel mesh — the **box collision shape and the InteractZone stay** (physics/reachability must never depend on a generated hull, and the affordance oracle already proved the box swing). A part with no mesh keeps the box slab. A test pins that the left door instances its panel while its box collision + zone remain, and the right (mesh-less) door keeps the box visual.
- Capability-complete and safe: parts are ready for a curated door kit or targeted generation, with no per-part generation forced by default (patterns set no part brief yet → boxes, no cost regression). Worker suite **207**; ruff clean. Next: source part panels (resolve a per-part brief through the farm, like the body) when a door kit lands or per-part generation is wanted.

### Added — 2026-07-20 (🏭 LIVE generation-on: a car with a real generated body + a path fix)
- Ran the pipeline with `asset_gen_enabled` + `asset_gen_backend=local` (SDXL→TripoSR in-process, alongside the 27B planner — ~26 GB VRAM, fit). From *"escape the flooded car park: find a working sedan and drive out"*: the planner authored a `vehicle` (`working_sedan`, "a mud-caked mid-90s family sedan"), its body was **generated** and instanced under the doors, and the game reached **DEPLOYED** with `composite_count=1`, **`AFFORDANCE_OK doors=3`**, `GREEDYBOT_OK time=8.0s`. Props were generated too (real GLBs in `res://assets/`). So generation-on works end to end in the real product path — no mocks anywhere.
- **Bug the live run exposed + fixed:** the composite body went to `res://kit/` at scale 1 instead of `res://assets/` scaled. Cause: `(kit_dir / parent_mesh).is_file()` — an *absolute* cached path collapses through the join and always "exists", so every generated body was stolen into the kit branch (unscaled). Fixed to decide kit-vs-generated by LOCATION via `relative_to(kit_dir)` (exactly as `_entity_model` does), so a generated body now routes to `res://assets/` and scales to its footprint. A test pins it with a real `kit_dir` present but not containing the body (body → `res://assets`, scaled ~2.667).

### Added — 2026-07-20 (📐 the body fills its footprint — phase 4b scaling)
- A generated body is normalised small (`backends_local.TARGET_SIZE_M` = 1.5 m longest); the composite writer now scales it up to the object's `bbox` (`GENERATED_BODY_SIZE_M`, kept in sync), so a sedan body fills the 2×4 m door layout instead of sitting shrunken inside it. `composite_blocks` takes a `body_scale`; `write_project` computes it as `max(bbox)/1.5` for generated bodies and leaves curated (real-scale) bodies at 1.0. A test pins the uniform scale transform on the body node. Worker suite green; ruff clean. Remaining: a live generation-on run to see the shell, and per-part meshes for exact fit.

### Added — 2026-07-19 (🚙 objects get a body shell under their doors — phase 4a)
- The asset farm now resolves each `entities.objects[].brief` to a **body mesh** (a static `building_module`): a new loop in `resolve_spec_assets` records `object:<id>` in the manifest (cache → curated → generate; we own no curated vehicles/buildings yet, so a body ships only when a generator runs). `tasks.py` threads the resolved body into each composite as `parent_mesh_rel`, and `write_project` instances it under the object holder — handling **both** a kit-relative (curated) path and an absolute (generated) GLB, the same split as `_entity_model`.
- **Ordering fix:** the composite emission had to move ABOVE the model ext-resource loops in `write_project` — a body added afterwards recorded its `_use_generated`/`_use_model` entry too late and dangled (no `[ext_resource]`, no copied file). A test pins that a generated body is now instanced (`ObjectCar01Body`) and its GLB copied into the project.
- So a car is no longer just two floating doors: with generation on (or a curated vehicle/building kit), the sedan body appears **under** its working doors. 2 tests (farm resolves `object:<id>` to tier `generated`; body instanced end to end). Worker suite **205**; ruff clean. Remaining (4b): scale the body to the object's `bbox` + modular per-part meshes for exact visual fit, and a live generation-on run.

### Added — 2026-07-19 (🚗 LIVE PROOF: a prompt makes a car whose doors open — phase 3b-4)
- End-to-end on the real product path, from a plain prompt *"escape the abandoned parking garage: find an old car and drive out past the wrecks"* (seed 42): the planner authored **one `vehicle` object** (`wrecked_sedan_vehicle`, "a boxy 1980s sedan with a crushed front"); it was **placed** in the level and **expanded** into `ObjectWreckedSedanVehicle` with two separate, script-bound `DoorHinged` nodes (+ InteractZones); the game reached **DEPLOYED** with `composite_count=1`, **`AFFORDANCE_OK doors=3 (all opened correctly)`**, and `GREEDYBOT_OK time=9.3s`.
- This closes ADR-0008's core promise as a *played, verified* result: **prompt → the brain designs an interactive object → it is placed → its affordances are separate correctly-hinged nodes → the engine proves they open → the game is winnable.** No mocks, no per-object special-casing — a house door, a chest lid or a lever would travel the identical path.
- Known gap → Phase 4: the object currently ships its **doors without a body shell** (the object `brief` isn't yet resolved to a body mesh), so a car reads as two doors in space. Next: resolve `entities.objects[].brief` through the asset farm (generated/curated `building_module`/prop) to a `parent_mesh_rel`, so the body appears under the affordances.

### Added — 2026-07-19 (🧠 composites wired prompt→spec→placed→materialised: phase 3b-2/3)
- **3b-2 (schema):** `game_spec.schema.json` gains an optional, additive **`entities.objects`** array (the authored shape: `object_id`, `archetype`, `bbox`, `brief`, `placement_tags`) — placement/parts are added downstream, not stored. Backward-compatible (existing specs validate unchanged); `validate_contracts` PASS. A gate-1 test pins that a valid object passes and a malformed one (missing bbox/brief) is rejected.
- **3b-3 (wiring):** the agent chain attaches `authored["objects"]` to `entities.objects` (LLM path only); `composition_patterns.place_objects()` gives each object a seeded world origin+yaw at a room whose footprint it FITS (too-big → dropped, never clipped, rule 14 reproducible); `tasks.py` now does `expand_all(place_objects(spec.entities.objects, plan.rooms, level_seed))` and feeds the result to `write_project(composites=...)` + the affordance gate.
- **The loop is closed deterministically:** prompt → content designer names archetypes → chain → gate-1 → seeded placement → pattern expansion → real `DoorHinged` nodes → gate-6 affordance oracle. 5 placement tests + the gate-1 test; brain suites (chain/arbiter/content/patterns) green; worker **204**; ruff + contracts clean. Remaining: **3b-4** — a live LLM run proving *"hotwire a car to escape"* → a car with doors that open in the played game.

### Added — 2026-07-19 (🧠 the content designer authors composite objects: phase 3b-1)
- The Content Designer's guided-JSON schema gains an optional **`objects`** array (0–4): the planner names an interactive object it wants — an `object_id`, an **`archetype`** from the fixed menu (the enum is `known_archetypes()`, so an invented kind is unrepresentable), a rough metric `bbox`, and a body `brief`. It never describes the doors/lids — the pattern library (phase 3a) adds those. `sanitize()` re-validates: drops unknown archetypes and malformed bboxes, clamps size to ≤15 m, dedupes ids against props/enemies (they become node names). The prompt tells the model to add objects only when the idea calls for one.
- **Safe + self-contained:** the field is optional and, for now, *emitted but not yet consumed* (the chain still ignores `objects`), so nothing downstream changes and no existing game is affected — the schema/spec wiring is deliberately a separate step. 5 tests (enum == pattern menu; accepted + carried; bbox clamp + bad-drop; id dedup; absent when none authored). ruff clean; brain content/pattern/arbiter suites green; worker **203**.
- Remaining for 3b: carry `objects` into the spec (an additive schema change, validated by gate 1), place them in the world (origin/yaw), then a live LLM run proving *prompt → objects → placed → doors open*.

### Added — 2026-07-19 (🧠 the brain decomposes objects into affordances: phase 3a)
- **`agents/composition_patterns.py`** — the brain side of ADR-0008. An LLM must never hand-author socket coordinates (rule 10 — it *selects*, it does not engineer geometry), so it names an **archetype** from a fixed menu (`vehicle`, `building`, `cabinet`, `chest`, `gate`) and this vetted pattern library expands it into the exact parts+sockets. `expand()` returns the plain-dict composite shape `write_project(composites=...)` already consumes, so the choice flows straight through the deterministic spine.
- `classify_archetype()` maps free-text object words to an archetype (car/truck/van → vehicle; cottage/hut/cabin → building; …); an unknown object stays a plain, non-interactive prop (no invented doors). Adding an affordance to the world is a new **data** entry pointing at a vetted template — never new code.
- **Proven end-to-end:** *"a car"* → archetype `vehicle` → a body with **two side doors** hinged at the right edges (a house → one front door; a chest → a lid + loot). A worker round-trip test takes the expanded dict straight into `write_project` and materialises real `DoorHinged` nodes — no bespoke geometry authored between the menu choice and the scene. 8 brain tests + 1 worker round-trip. Next (3b): the content-designer agent emits these archetypes via guided JSON, and placement drops them into the world.

### Added — 2026-07-19 (🚪 composite objects → real scene nodes: phase 2a)
- **`godot_client/composite_writer.py`** materialises a `CompositeObject` into Godot scene text: a parent holder placed in the world, with each affordance PART hung under it as a **separate, script-bound node** — a `DoorHinged` (StaticBody3D + slab mesh offset from the hinge + collision + `InteractZone` Area3D) for a hinged part, a pickup Area3D for a point part. It emits the *same* node shape the exit `LockedDoor` already uses, so a composed door behaves identically to the hand-placed one; locked doors emit an `objective_completed` connection stub for whatever unlocks them.
- Parts hang under the holder at parent-LOCAL transforms (reusing `resolve_parts` against a zero origin), so the whole object moves/rotates as a unit and each hinge stays exact. **6 tests** prove a **car** (two doors, opposite sides, 70° swing, unique sub-resources) and a **house** (front door, locked, wired to a key objective) both emit correctly from the same code, plus body-mesh instancing and pickup parts.
- **Phase 2b — wired into `write_project`:** it now takes `composites=[...]` (parsed by `_composite_from_dict` into `CompositeObject`s, rule-13 errors on malformed input) and emits them into `main.tscn`; a composite without `templates_dir` is rejected (it would reference undefined door/pickup ext_resources). **Verified in the real engine:** a golden game + a hand-written composite car **loads and runs in Godot 4.7 headless with exit 0 and ZERO errors** — the two car doors are real, separate, script-bound `DoorHinged` nodes. 2 integration tests added (structure + the templates-required guard).
- **Phase 2d — registered as a validation gate:** gate 6 is now **dynamic_playtest** = the win-path greedy bot **AND** the affordance oracle (`_gate6_dynamic`); either failing fails the gate, each judged only when its verdict was produced (missing engine → that check is absent, never a false FAIL). The worker (`tasks.py`) runs `run_affordance_check` whenever a game has composites and passes `affordance_verdict` into `run_gates`; `write_project` receives `composites` (empty until phase 3). So a composed door that never opens now **blocks DEPLOYED and feeds localized repair**, exactly like a bot that loses. 3 gate tests (affordance PASS/FAIL, fails even when the bot is happy, SKIP when neither ran). Worker suite **202**.
- **Phase 2c — the correctness oracle:** `bots/affordance_check.gd` + `runner.run_affordance_check` prove every hinged affordance in a built scene actually WORKS — it finds each door by capability (has `door_opened` + `_try_open`, so a composite car door and the exit `LockedDoor` are found the same way), interacts, and asserts it swung ~`open_angle_deg`; a LOCKED door must stay shut until unlocked, then open. Prints `AFFORDANCE_OK` / `AFFORDANCE_FAIL <reason>` (the greedy bot only covers the exit door on the win path; composite affordances sit off it). **Proven both ways on real Godot 4.7:** a composite car → `AFFORDANCE_OK doors=3`, and a deliberately no-op door template → `AFFORDANCE_FAIL` (not theatre). Fail-soft on a missing engine (SKIP, never fail a game for a broken toolchain). 2 GODOT_BIN-gated tests. Worker suite **200** (+2 skipped without the engine). Next: register the oracle as a validation gate + Phase 3 (the brain emits composites).


### Added — 2026-07-19 (🚪 composable interactive objects — any affordance, placed correctly)
- **The insight (user):** it's not about doors or villages — the brain must let the player ask for *anything* and have its interactable parts work: "a vehicle door wants to open correctly." A generated model is one static mesh (no rig, no hinge — ADR-0005/0007), so a baked-in door can never open. The production-grade answer must generalise to house doors, vehicle doors, lids, levers — with no special-casing.
- **ADR-0008 (decision, recorded):** every object is a **composite** — a static parent mesh plus zero or more affordance **parts**, each a *separate node bound to a vetted behaviour template* and snapped to a named **socket** on the parent's normalised bounding box. The mesh never carries behaviour; the brain composes parts+sockets+params (rule 10 — never authors the mechanism); the seeded assembler places and wires them; the **playtest bot proves the affordance works** (door opens, path passable) or triggers localized repair. Extends ADR-0003 (composition) down to the single-object level.
- **`godot_client/composition.py` (the deterministic core, built + proven):** `Socket` (anchor on the parent bbox — x,z ∈ [-0.5,0.5], y ∈ [0,1]), `AffordancePart` (template + socket + params), `CompositeObject`, and `part_world_transform` / `resolve_parts` — the socket-snapping geometry that puts an affordance at the **exact hinge point**, correct even after the parent is rotated. This is *why* a separated part hinges correctly where a "door near the body" can't. Behaviour maps to the existing vetted templates (`door_hinged` already implements the general hinged affordance: origin = hinge, swings `open_angle_deg`, `InteractZone` + `interact`, lock/unlock signals).
- **Proven, not asserted:** 8 tests show the SAME machinery, with no special-casing, snaps a **vehicle** door (left/right, opposite sides, car opens 70° vs a house's 90°) and a **house** door (front-centre, locked, wired to a key objective) to correct world transforms — and that a rotated parent carries its sockets around. Range/template validation rejects bad sockets and unknown affordances.
- Phased from here (ADR-0008): (2) more affordance templates (lever, lid, sliding, vehicle-door params) + the writer emitting composite nodes; (3) the brain decomposition agent emits composites; (4) modular part generation for exact visual fit. Worker suite **192** (+8), lint clean.


### Added — 2026-07-19 (🧊 real asset generation that actually runs here — no more mock)
- **The demand:** "this is a production-grade system, all things want functional — no mock data." The asset farm's only generation backend was `MockBackend` (a placeholder cube), and the real one (`GpuAssetBackend`) targets a ComfyUI + WSL2-TRELLIS + Blender deployment that **cannot run on this box** (no MSVC `cl.exe`; nvcc 12.9 vs torch's CUDA 13.0 — TRELLIS's custom CUDA submodules won't build). So generation was, in practice, a stub.
- **`backends_local.LocalGenBackend`** — a REAL, in-process generator verified on the RTX 5090: **SDXL base** (diffusers, text→image, ~4–6 s) → **rembg/u2net** (isolate the object) → **TripoSR** (image→3D, vertex-coloured mesh) → **fast_simplification** (decimate to the tri budget) → normalise (recentre, Y-up, ~1.5 m) → web GLB. **No compiler, no ComfyUI, no WSL.** TripoSR's one custom CUDA op (marching cubes) is swapped for the prebuilt-wheel **PyMCubes**, which is why it needs nothing compiled.
- **Vendored** the MIT TripoSR `tsr` module under `services/worker/asset_farm/vendor/triposr/` (LICENSE included, PyMCubes patch applied, config's `tsr.*` class paths resolved by aliasing the vendored package). Selectable via `asset_gen_backend="local"` in `registry.select_backend`; heavy deps import lazily so a curated-only deploy and CI never need the GPU stack.
- **Proven functional, not asserted:** on the 5090, `"a rustic wooden market stall"` → a static GLB that **passes the QA gate at 1,840 tris** (`rigged=False`, correct for a prop), ~19 s; and through the real farm path (`resolve_spec_assets`) an **unowned** prop `"a colorful hot air balloon"` resolved to tier **`generated`** (component `triposr`) and shipped a real 37 KB GLB. Generation is **mesh-only for props/buildings/foliage** — it refuses characters (a rig-less statue is wrong for a body; characters stay curated, ADR-0005) and audio.
- **Licence (rule 12):** added `triposr` (MIT, verified from the vendored LICENSE) and `u2net` (Apache-2.0, web-verified) to `docs/licensing_ledger.csv`; `scripts/check_licenses.py` stays green (SDXL was already ledgered). Generation is the long-tail tier; the CC0 curated library remains the instant, licence-clear default (both, by design).
- 8 GPU-free backend tests (lazy import; refuses characters/audio; decimation lands ≤ budget; Y-up base-on-ground normalisation; loadable vertex-coloured GLB). Worker suite **184** passed (+8), 1 skipped. Stack added (dev/GPU box): `diffusers`, `accelerate`, `rembg`, `onnxruntime`, `trimesh`, `PyMCubes`, `fast-simplification`.


### Fixed — 2026-07-19 (🐕 "as a dog" is now a dog — the blue-capsule bug)
- **The bug a user hit:** typing *"a dog explores the village"* produced a **blue capsule**, not a dog — even though the library already owns rigged, animated `Husky`, `ShibaInu`, `Wolf`, `Fox` (Quaternius, CC0). The planner correctly wrote a dog `player.asset_brief`; the resolver just never used it. Two causes:
  - **The curated tier was gated behind generation being ON.** `tasks.py` only passed `embed_base_url` when an asset/audio backend was running, so with generation off the semantic curated match — the tier whose whole job is "do we already OWN this?" — silently returned `None` for *everything*, and the player (no default model) fell to the capsule. Now the embedder is passed whenever RAG is on; matching what we own no longer depends on generating anything.
  - **The curated tier had no embedder-free path.** `best_curated` needs bge-m3 reachable; no embedder → no match → capsule. Added **`keyword_best`**: a deterministic, stdlib-only lexical matcher (IDF over the model descriptions) so a *stated identity always resolves to a body we own*, embedder or not. `_curated_pick` now tries **semantic → keyword → default**.
- **Kind beats colour.** Plain IDF made "a **brown** dog" a brown *horse* (colour rarer than "dog" in a small library). Appearance words (colours/materials/patterns) are down-weighted, and a shared appearance word **alone** can never identify a body — so "a marrow bone coated in gold" is not a gold *chest*. Colour still refines *within* a kind ("a white horse" → WhiteHorse).
- **Scoped to characters.** The keyword tier only overrides the default for **characters** (whose default is a capsule/blind index-cycle — pure upside). Props keep their sensible typed defaults, so an elaborate collectible brief ("herb-roasted chicken drumstick") can't spuriously become a chest.
- **Proven end-to-end on the live web stack:** *"play as a wolf hunting…"* → the **Player wears `Wolf.glb`**, enemies resolve to wolf + husky, props are type-appropriate, and the build reaches **DEPLOYED** (8 gates + playtest bot pass). *"a dog explores the village"* → **ShibaInu** player.
- **Also fixed the dev loop:** `wmic`-based worker kills were silently failing, leaving up to 4 stale-code Celery workers racing for jobs (why an earlier build showed pre-fix behaviour). Now killed reliably via PowerShell `Get-CimInstance`.
- 15 curated-match tests (keyword picks across dog/wolf/horse/wizard; kind-beats-colour regression; appearance-alone guard; player-body-with-no-embedder end to end). Worker suite **177** (176 passed, 1 skipped); lint clean. Brain `tasks.py` behaviour-only change.


### Added — 2026-07-19 (🔥 atmospheric dressing — dungeons read as dungeons)
- The biggest safe visual win for the showcase: every room now gets **corner torches** (`torch_lit`, inset from the walls), so a level looks furnished instead of grey-boxed. Chosen over the full box→kit-module swap because that would rewrite the navmesh/collision spine (the most fragile subsystem, high regression risk) — dressing gets ~80% of the look for ~0% of that risk.
- **Purely additive and provably harmless:** torches are visual-only instances (the kit GLB carries no collision), under a `Dressing` node, so they never touch collision, navmesh, or the gates. Verified in a real build — 20 torches across the golden game and the greedy bot **still wins (12.6s)**, i.e. nothing was blocked.
- **No size cost:** one `ext_resource` + one copied GLB, instanced N times (a test pins the dedup, or the 90 MB budget would die by a thousand torches). Tiny rooms are skipped so corner torches never crowd the floor.
- Kit-gated: a box-only build (no kit) is byte-unchanged — dressing is a kit feature, and a test asserts it's absent without one. 6 dressing tests; worker suite **161** (+6), lint clean.
- Existing showcase games predate this; regenerating the showcase (`build_showcase.py --generate`) would pick the torches up. Not auto-run to avoid competing with the training GPU.


### Added — 2026-07-18 (🎓 fine-tuning phase — training-data pipeline + QLoRA script)
- **Started the fine-tune phase (RQ4).** The blocker was data: ~11 pairs is far short of a QLoRA's ~500-2000, and the eval frozen sets can't be reused as training data without contaminating Ablation E.
- **`eval/training/prompt_corpus.py`** — a combinatorial, seeded generator for **150 varied training prompts**, spanning all four genres plus character-identity ("as a scruffy dog…") and collection goals, so the student sees the whole design space. **Held DISJOINT from the eval sets** — `disjoint_corpus()` drops any collision, a test asserts zero overlap, and the generator aborts if contamination is ever detected. Contamination would make Ablation E measure memorisation, not learning.
- **`eval/training/generate_dataset.py`** — runs the corpus through the multi-agent chain + static validation **directly (no Godot export, no DB)**, ~3× faster per prompt since the training target is the planner's *spec*, not a built game. Keeps a pair only when static gates PASS **and** the brief was LLM-planned (a rules fallback is not the teacher). Writes JSONL **incrementally + resumably**, so a ~4.6h run survives interruption and re-runs skip what's done. Warms the 27B first (no cold-load fallback). Smoke-verified: 3/3 PASS, correct format, right genres.
- **`eval/training/train_qlora.py`** — the runnable version of `FINE_TUNING.md`: loads the JSONL (merging generated + DB-export, deduped by spec_hash), **holds out a test split BY spec_hash** (a row-split would leak a memorised spec into the score), trains the LoRA (seeded), exports GGUF, and writes the held-out set for Ablation E to score against. Heavy deps imported inside `main` so it imports for tests without a GPU; a `--dry-run` preps + splits + reports without training. Re-flags rule 12: **Qwen3-8B needs its own ledger row** before it ships a planner.
- **Full 150-prompt dataset generation is running now** (seeds=1, ~4.6h, resumable) on the provided machine.
- 8 training-pipeline tests (corpus disjointness/uniqueness/coverage; split-by-hash no-leak; dedup). Suites **221 brain + 155 worker**; lint clean.


### Added — 2026-07-18 (📦 reproducibility package — the cited numbers are now verifiable)
- **The problem:** the raw ablation runs live under `eval/reports/**` (gitignored scratch, 140–528 KB each because every row carries a full level-plan), so the specific numbers the thesis cites were **not version-controlled** — a reader couldn't check them, and they'd be lost.
- **`docs/dissertation/results/`** now holds tracked, slim evidence (~105 KB total, down from ~1 MB): per-prompt **metric** rows (level-plan bulk stripped), the reported comparison statistics, `RESULTS.md` (the three findings as cited), and `PROVENANCE.json` (git SHA, planner model, seeds).
- **`eval/reproduce.py`** — `--freeze` distils the raw runs into that evidence; the default `verify` **recomputes every reported p-value and effect size from the frozen rows and asserts they match** the frozen comparison files. A reproducibility check that rubber-stamps a fudged number is theatre, so a test tampers a p-value and confirms the verifier FAILS. It also re-runs the rules-mode control live (R = 20/20, no GPU) and prints the exact commands + seeds for the expensive LLM arms.
- **`docs/dissertation/REPRODUCE.md`** — verify-in-seconds vs regenerate-from-scratch, and an honest note on what isn't reproduced here (A/F external baselines; E awaits weights; latency is order-of-magnitude).
- Fixed an internal-consistency gap: `comparison_RBCD` was generated before `genre_match` became a metric, so it was regenerated with current code before freezing — now `verify` reproduces it exactly (family of 12, not the stale 9).
- **`REPRODUCIBILITY: PASS`** — both cited comparisons regenerate exactly; the spine control holds live. 4 tests; suites **213 brain + 155 worker**; lint clean.


### Added — 2026-07-18 (🎬 defense showcase — 5 cached games + a rehearsed live gen)
- `eval/showcase/build_showcase.py` drives the **real product pipeline** (`POST /games` → LLM → PCG → Godot export → playtest bot), so every showcase game is an honest product output with a web build, a downloadable project, a validation verdict, a bot result and full lineage — a showcase SELECTED from real runs, not hand-waved.
- **7/7 curated candidates built, every one PASS + won by the bot, across all four genres, ≤42.4 MB.** The dog is in it: *"as a scruffy village dog…"* → a real animated Shiba Inu game (`collect_explore`, 38.4 MB, bot-won).
- **Selection is strict:** a demo game must pass every runnable gate AND be won by the bot, and the five are chosen for **genre spread** (a defense shows range, not five dungeons) — never padded (a test pins that fewer-than-5 is reported honestly). Chosen: dog_village, relic_hunt, harbor_escape, colosseum, skeleton_crypt.
- **Live generation rehearsed ×2** (~233 s, bot-won) and `DEMO_SCRIPT.md` written with the **backup plan** the P6 gate requires: if the live run stalls, cut to the pre-built cached copy — same product path, already proven. The harness persists the live timing into the manifest so the script never says "~?s".
- **Free distillation data:** these real runs filled the `specs` table — **8 LLM-planned + 3 rules** pairs now, accumulating toward the fine-tune set with no separate effort.
- 6 showcase tests; suites **209 brain + 155 worker**; lint clean.


### Added — 2026-07-18 (🎯 v2 result — the brain understands intent, not keywords)
- Ran the keyword-adversarial **v2** set (R vs C, live `qwen3.6:27b`). This is the finding v1 couldn't produce, because v1's static metrics all ceilinged.
- **genre_match: R 1/12 → C 11/12** (McNemar p=0.002, Holm p=0.008, Cliff's δ=+0.83, large). The rules parser defaults every keyword-free prompt to `collect_explore`; the LLM reads the *meaning* — *"the dead are clawing from the earth and the last boat leaves at dawn"* → survival, *"wave after wave of raiders storm the ring"* → arena, *"descend floor by floor beneath the ruined keep"* → dungeon.
- **The one C miss is honest:** *"guard the old lighthouse lamp… to keep it burning"* → survival, where a human might also waver between caretaking and defense. Kept in the set as-is.
- **Both arms still pass 100% of static gates** on v2 — the spine builds a valid game even when the *genre* is mislabelled, which is exactly why genre understanding needed its own metric rather than riding on pass rate.
- `compare.py` now treats `genre_match` as a first-class binary metric (McNemar, Holm-corrected with the rest). Tests updated for the wider family.
- **Two independent, defensible discriminators now stand:** v1 — the LLM makes design *choices* rules can't (`collect_n` 7/20, player identity 20/20); v2 — the LLM *understands genre* where keywords fail (11/12 vs 1/12). With the unique-per-seed fix, that is the empirical backbone of "thinking-based, not template-based".
- Suites: **201 brain + 155 worker**; lint clean.


### Fixed — 2026-07-18 (🎲 unique games per seed — the planner's seed was frozen at 4521)
- **The ablation work surfaced a real product gap:** every LLM call (`llm_brief`, `llm_objective`, `llm_entities`) used a **hardcoded `seed: 4521`**. So the same prompt always produced the **same design** — same enemies, same player identity, same win condition. The user's game seed only reshuffled the **floor plan** (PCG); the *thinking* was frozen. For a system whose whole pitch is "unique, thinking-based games", the unique part didn't vary.
- **`planner_seed(settings, salt)`** now derives each agent's Ollama sampling seed from the **game seed** (`ctx.seed`), with a per-agent salt so brief/objective/content don't move in lockstep. This satisfies **both** halves of rule 14: *reproducible* (same seed → same game) **and** *varied* (different seed → a genuinely different design of the same idea). Previously reproducibility was satisfied trivially — by being constant — at the cost of all variety.
- **Proven live:** *"explore a haunted village and gather lost trinkets"* at seed 7 → *"a cloaked antiquarian in a dust-stained wool coat"*, props `ivory_music_box / obsidian_locket / bone_compass…`, enemies `grief_wraith, cobblestone_prowler`; at seed 42 → *"a cloaked figure in a weathered wax-canvas coat"*, props `porcelain_doll_head / brass_collar_bone / silver_locket_shard…`, **no enemies**. Two on-theme but genuinely different games. Before this, byte-identical.
- **Safe by construction:** a bare `Settings` object (no `.seed`, e.g. the editor path) falls back to the old constant, so those paths are unchanged; `seed 0` is treated as a real seed, not falsy. No test asserted the old constant. The editor's edit seed is deliberately left fixed — an edit should be stable given spec+instruction.
- **Bonus for the study:** this makes a **3-seed ablation meaningful** — with the planner seed frozen it would have triplicated identical designs; now each seed is a real re-draw, so 3 seeds measures *planner stability* (does the brain make consistent design calls across generations?), a genuinely new question.
- Suites: **201 brain (3 new) + 155 worker**; lint clean.


### Fixed — 2026-07-17 (🚦 gate 3 stops lying — asset QA is judged, not skipped)
- **`record(3, "asset_qa", None)`** — SKIPPED on **every job**, with a comment promising the farm would arrive in P3. P3 arrived: `qa_mesh` and `qa_audio` judge every produced asset and their reports have been sitting in the manifest, unread. **This is the same dishonesty gate 6 had for weeks** while the pipeline claimed games were playtested.
- **The policy is the interesting part.** `VALIDATION_PLAN.md` is explicit: a QA failure gets one regen attempt then a curated substitute, and **never blocks**. So gate 3 must *not* fail a game for an ugly asset — the resolver already fell back, and that is the design **working**. Failing there would block a game for successfully protecting itself.
- **So it verifies the resolver's promise instead**: *nothing ships un-gated*. A gate that only ever agrees with the component it checks is theatre. The two ways S5's contract can actually be violated both block: a `generated` asset whose **own QA report says it failed** (a resolver bug, not an asset problem) and a shipped asset whose **file is missing** (a broken reference). Each failing asset is named individually with machine-readable `data` (§13), never "assets are bad".
- **Live in the pipeline now**: a real job reports `gate 3 asset_qa PASS` against its actual manifest. Verified end to end, plus the real mock-farm run passes it. P3 gate re-run: still **PASS**.
- Also corrected the module docstring, which described gate 3 as an honest skip "until its tier exists", and added the rule the file had learned the hard way: **a gate is SKIPPED only when the thing it judges did not run** — never as a stand-in for "not built yet".
- Suites: **198 brain + 156 worker** (10 new); lint clean.

### Added — 2026-07-17 (📊 significance testing — and the plan's own stats advice was wrong)
- `eval/README.md` prescribes **Wilcoxon** for the ablations. For latency that is right. **For pass/fail it is wrong, and dangerously so**: pass/fail is paired *binary* data, so every non-zero difference has magnitude 1 and Wilcoxon's normal approximation runs on nothing but ties — it becomes **anti-conservative and manufactures significance that isn't there.** Measured on 20 paired prompts (18 vs 14 passing): **Wilcoxon p = 0.046 ("significant") vs McNemar p = 0.125 (not)**. Same data, opposite conclusions — and the wrong one would have put an indefensible claim in the dissertation.
- **The test is now chosen per metric, not per convenience**: paired binary (pass / schema_valid / played) → **McNemar exact** (exact, not chi-square: discordant counts are small at n=20); paired continuous (latency, build size) → **Wilcoxon signed-rank** with tie + continuity corrections. `eval/metrics/significance.py`, plus Cliff's delta, seeded percentile-bootstrap CIs, and Holm–Bonferroni step-down.
- **Pure stdlib, deliberately.** scipy is a dependency of no service and CI installs almost nothing — importing it here would break collection the moment a test touched the module, which is the exact failure that kept the worker job red for months (`httpx`). But pure-and-wrong is worthless, so the tests **validate every implementation against scipy** where it happens to be installed and skip where it isn't.
- `eval/ablation_runners/compare.py` — runs → a defensible table. Pairs strictly by `(prompt_id, replicate)` (the arms saw the same prompt with the same seed) and **refuses unpaired arms rather than silently comparing them**, because comparing different prompt sets measures the prompt sets. Every comparison in a report is **one Holm family** — correcting each arm separately would inflate the family-wise error rate exactly as the plan warns. Reads artifacts only: nobody should re-run a GPU-hour to recompute a p-value.
- **The sharpest test is the null one**: two identical arms must produce p = 1.0 and negligible effects. Verified on a real 40-run smoke (R vs B with the planner stubbed dead — both effectively rules mode): **no significant difference, as there should not be.** A harness that finds results in identical data would find them anywhere.
- **Documented a caveat rather than hiding it:** Cliff's delta measures **dominance, not magnitude** — a 0.1 ms shift across half the runs scores "large". Report it for direction and consistency, and the means for how much; reading it as effect *size* in game terms would overclaim. A test pins that behaviour so nobody "fixes" it later.
- Suites: **198 brain (24 new) + 145 worker**; lint clean.

### Added — 2026-07-17 (🔬 ablation runners — the dissertation's claim becomes testable)
- `eval/ablation_runners/` was an **empty folder**. It is the machinery the whole thesis rests on: the claim is that reliability comes from the **architecture** (deterministic spine + gates + bounded repair), not the model — and an ablation is how that gets *tested* rather than asserted.
- **Every arm is the shipped pipeline with one toggle flipped, never a fork.** `run_benchmark._run_one` gained keyword-only `repair` / `rag` / `model` / `seed_override`, all defaulting to the product's behaviour — so the CI benchmark gate that calls it still measures the product, not an experiment (verified: gate still green). A test asserts every condition's toggles are **real parameters of `_run_one`**, because a typo'd toggle would fork the study from the product at runtime, hours into a GPU run.
- **Conditions are data** (`conditions.py`), so adding an arm is a row: **B** structured-no-repair · **C** structured+repair (the product path) · **D** +RAG (RQ3) · **E** tuned-8B (RQ4) · **R** rules-mode control. Runnable today: **B, C, D, R**.
- **A and F are declared unrunnable, not quietly missing.** Both need free LLM generation — permanently banned by rule 10 — and building it just to lose to it would ship the exact thing the architecture exists to avoid. They are marked `external`: baselines for a separate harness, scored by the same gates afterwards. A reader must see we know they belong in the study.
- **Added the control the plan implies but never lettered (R).** Without it a study cannot say whether the LLM contributed anything: it is the same spine with the planner removed. **First real run: 60/60 PASS, 0 repairs, p50 26.7 ms** — the deterministic spine alone clears every static gate, which is the bar the LLM arms must now justify themselves against.
- **A silent fallback can never be published as an LLM result.** Each arm records `llm_planned` / `llm_fallbacks` and warns loudly — the exact failure that once had a benchmark reporting 20/20 while **0/20** were actually planned by the LLM. Pinned by a test that stubs the planner dead and asserts all 20 runs say so.
- **Seeds are fixed `(0, 1, 2)`, not random** — "3 seeds" must mean the same three every time, and every result carries its seeds + prompt-set version, because `eval/README.md` is explicit that results without them are unusable in a dissertation. Significance testing is deliberately a **separate** step over the JSON, so nobody burns a GPU-hour recomputing a p-value.
- Suites: **174 brain (11 new) + 145 worker**; lint clean.

### Added — 2026-07-17 (💾 the `specs` table — stop throwing the fine-tune dataset away)
- **Specified since P0, never built.** `docs/DATABASE_SCHEMA.md` lists `specs (id, game_id, schema_version, body JSONB, spec_hash, frozen_at)`; `core/models.py` had only `games` and `jobs`, and its own docstring admitted richer tables "arrive in P1+". The pipeline recorded **`spec_hash` but not the spec body**, so a spec existed only inside each built project's `game_spec.json` — recoverable, not queryable, and gone with the artifacts folder.
- **That is the P4 distillation set being discarded, one job at a time.** `games.prompt` → `specs.body` **is** the training pair, and the job's validation verdict **is** the label — so the dataset is a **byproduct of ordinary use**, not a labelling effort. But only from the moment it is stored: **a spec not written today cannot be recovered.** `eval/README.md` already names this exact failure ("building the harness in P5") as a top-10 risk, and we are in P3 — every local test run from here is free training data.
- Written at **`SPEC_FROZEN`**: the spec as *planned*, before the deterministic stages could fail. The planner is what a distillation set is about; a downstream build failure is a **label**, not a reason to drop the row. Stored for **rules mode too** — that's the control group, and discarding it would make ablation E unreproducible.
- **Telemetry never costs a game**: `_store_spec` swallows and logs. Tested by breaking the DB *underneath* it rather than replacing the function — replacing it would step over the very try/except being tested and prove nothing (the first draft of that test did exactly that, and passed for the wrong reason).
- `eval/export_distillation.py` — the validator-filtered exporter. Default filter is strict on purpose: `brief_source == "llm"` (teach the student what the **teacher** did; training on rules rows would teach the 8B to imitate a regex), `verdict == PASS`, `state == DEPLOYED`. Emits JSONL in the `messages` shape TRL/Axolotl/Unsloth read directly, each line carrying `spec_hash` + teacher + verdict so a training run is auditable (§11). `--stats-only`, `--include-failures`, `--include-rules` for analysis.
- **`docs/runbooks/FINE_TUNING.md`** — the whole P4 path: collect → export → QLoRA Qwen3-8B on the 5090 → serve behind a flag → ablation E. The untuned 32B stays default, always.
- Migration `0002_specs` verified **upgrade *and* downgrade** on a real alembic run — the suites use `create_all`, which would not have caught a broken migration. `spec_hash` is deliberately **not unique**: the same prompt+seed legitimately re-plans to an identical spec, and a unique index would turn that into a crash.
- Suites: **163 brain (9 new) + 145 worker**; lint clean.

### Added — 2026-07-17 (🐕 **the dog is real** — CC0 animated animals, and a local-run runbook)
- ***"as a dog, explore the village"* now resolves to an actual animated Shiba Inu.** Vendored the Quaternius Ultimate Animated Animal Pack (**CC0**, verified at the primary source): 12 animals, 12 MB, **24–26 clips each**, every one probed as genuinely rigged+animated (`skins=1`) *before* being trusted — Cow, Fox, Wolf, Deer, Bull, Alpaca, White Horse, Donkey, Horse, Stag, **Husky**, **Shiba Inu**.
- **Real build:** *"a scruffy village dog"* → `ShibaInu` wearing `idle=Idle patrol=Walk chase=Gallop attack=Attack hit=Idle_HitReact_Left death=Death`. **No generation, no rigging, no research** — the ≥0.85 tier plus a CC0 download, exactly as ADR-0007 predicted.
- **Reading the real files beat guessing:** the forward-compatible clip names were **4/6**. The animals strike with `Attack_Headbutt`/`Attack_Kick` and flinch with `Idle_HitReact_Left`, not the `Attack`/`Hit` that seemed obvious.
- **The kit root moved to `content/kits`, one folder per pack**, because filing Quaternius files under a folder named `kaykit` would put one author's work under another's LICENSE — exactly what §14 guards against. That broke category scoping, which matched on the path prefix `"characters/"`: a prefix was always the wrong abstraction, since **animals ARE characters**. It is now a folder convention (`model_category`), so a pack's own name can come first.
- **The probe caught a bug no unit test did:** the writer *wore* the farm's semantic pick (a Shiba Inu) but read its sound family from its **own index-cycle default** (a skeleton) — so the dog **died to bone-clatter**, ADR-0004's exact anti-goal. `_entity_model` now returns the model actually worn, and every decision hanging off the body reads that. Regression-tested.
- New **`animal` sound family** so a soft body dies wet, not dry. Honest limit: this library has **no bark** — these are the best CC0 clips we own for a creature, not the right ones; a real bark comes from generated sound (`AUDIO_GEN_ENABLED`).
- **`docs/runbooks/RUN_FULL_LOCAL.md`** — the whole system on one PC, $0, no cloud. Written from what this machine **actually has** (Ollama with `qwen3.6:27b` + `bge-m3` ✅, ComfyUI ✅, TRELLIS ✅, Godot ✅, Docker ✅) rather than from assumptions: 4 things remain — start Postgres/Redis, fill `.env`, `npm install`, run the four processes. Two doc claims were **wrong until checked**: Blender is **5.2** here (not 4.x), and compose hard-requires `POSTGRES_PASSWORD`. Also fixes a **stale README** that still said "Phase P2".
- Suites: **154 brain + 146 worker**; lint clean; contracts + licences PASS.

### Fixed — 2026-07-17 (🏁 **P3 GATE MET** — the round-trip runs live, and the gate caught a real bug)
- **`scripts/p3_gate.py`** — the P3 gate (§11: *download project → open in Serendib → AI-dock edit → re-export*) now **runs**, live, against a **real Godot export** rather than the CI stub. **16/16 PASS**: prompt → `DEPLOYED` (validation `PASS`, lineage `{'curated': 9}`) → `project.zip` opens as a Godot project carrying `game_spec.json` **and** the **enabled** Serendib Assist addon → the dock's edit comes back in-contract and bounded (`speed 3→4`, `health 5→7`) → re-export → `DEPLOYED`, re-validated. It is committed, not thrown away, so the gate stays runnable.
- **The gate earned its keep on the first run: `/reexport` validated the schema but not the registry.** `"ai_teleporting_boss"` is a perfectly valid *string*, so jsonschema waved it through and the endpoint answered **202** — the caller only learned it was junk minutes later, from a `FAILED` job. **Not a security hole** (the pipeline's allowlist gate stopped it every time, with a perfect machine-readable error — defence in depth held), but a **fail-late contract bug**, and the endpoint's own docstring already claimed it validated *"never trust an edit any more than a plan"*. In-contract means the schema **and** the registry: it now returns **422 + the same machine-readable error object** (§13) immediately, and the pipeline gate stays as the backstop. Two tests pin it — one that it refuses, one that the guard didn't become a wall.
- **Two stale ◑ rows closed** after verifying the code, not the notes: the Assist dock's "☐ guided-JSON LLM edit path; ☐ one-click re-export" both shipped days ago (13 + 5 tests), and asset resolution's S5 tree is complete now that the ≥0.85 tier exists.
- **P3 stands at 6/8 done with the gate MET.** The two open rows are **user-gated by design, not unfinished**: the CC0 animal pack is behind a JS/itch.io download (ADR-0007 rung 1 — the only thing between the prompt and an animated dog), and live hybrid deploy needs the team's Cloudflare/Hetzner accounts, a spend decision and real secrets (§12/§13: Claude does not provision paid cloud or handle secrets). The one gate step a machine cannot run is a **human opening Serendib** to see the dock's UI.
- Suites: **154 brain + 145 worker**; lint clean; contracts + licences PASS.

### Research — 2026-07-17 (🔬 how a generated character MOVES — the answer is a ladder, not a model. **ADR-0007**)
- **Question:** everything is in place except motion. A generated character is a statue, so the aliveness rule holds it back and a curated skeleton ships. The chain is **mesh → rig → clips**; mesh is solved, so what solves the other two?
- **Rigging is solved and product-safe.** [UniRig](https://github.com/VAST-AI-Research/UniRig) (VAST-AI/Tripo + Tsinghua, SIGGRAPH 2025) predicts skeleton **and** skinning weights for arbitrary meshes: **MIT for code *and* [weights](https://huggingface.co/VAST-AI/UniRig)** (§14 product path OK), **~8 GB VRAM** (sequences beside TRELLIS's ≥24 GB, never co-resident), **1–5 s** inference, covers **quadrupeds** (Rig-XL, ~14k models), outputs **GLB with skinning**. It is on the pre-agreed cut list, but nothing about it is prohibitive.
- **Clips are NOT solved — the finding that matters.** (1) **UniRig produces no animation**: it rigs, it does not move, and its joints carry **coordinates, not semantic names**. The paper notes that recognising a template (e.g. `mixamo:body`) "allows for efficient motion retargeting" — but a novel creature's joints are unlabelled, and **retargeting needs a bone correspondence that a novel topology doesn't have**. (2) **No product-safe text-to-motion exists for arbitrary creatures**: topology-agnostic animal motion ([arXiv 2512.10352](https://arxiv.org/abs/2512.10352), OmniZoo, 140 species) is Dec-2025 research with no verified permissive weights, and human-only models (SMPL-family, Tencent HY-Motion) are the wrong species or carry the exact licence shape **already quarantined here** for Hunyuan3D-2.1.
- **Decision: a capability ladder, arbitrated by the aliveness rule that already exists** (ADR-0005) — no new arbitration logic, and `mesh_capabilities()` already separates *rigged* from *animated*, which is exactly the signal the rungs turn on. **(1) Own it** — curated ≥0.85, instant/rigged/animated. **(2) Make + rig + retarget** — humanoid-shaped, via UniRig + our 95 KayKit clips. **(3) Make + rig + procedural** — **vetted GDScript** IK locomotion, the honest answer for novel topologies and the one that best matches this system (LLM says *what*, vetted deterministic code says *how* — rules 10/14/15). **(4) Make it, static** — only where nothing is lost.
- **The dog does not need generation at all.** [Quaternius' Ultimate Animated Animal Pack](https://quaternius.com/packs/ultimateanimatedanimals.html) is **CC0** (commercial, no attribution): 12 animals × **12+ clips each** (Idle/Walk/Gallop/Attack/Death/Jump), glTF — mapping **1:1 onto the activities already wired**. With the ≥0.85 tier from this morning, *"as a dog, explore the village"* resolves to a **real rigged animated dog**. **The blocker is a CC0 download, not a research programme.**
- Ledger rows added and **verified at primary sources today** (rule 12: log *before* the product path): `unirig` **MIT**, `quaternius-animated-animals` **CC0** — both `commercial_ok=yes`, no territory limits; gate PASS. Explicitly rejected: **Mixamo** (Adobe terms; our own golden template says *"Nothing from Mixamo, etc to muddy up the licensing waters"*) and **SMPL/Tencent motion** in the product path.
- Forward-compatible, zero-risk: `ANIM_CANDIDATES` now carries the plain clip names (`Walk`/`Gallop`/`Attack`/`Death`) **at the tail**, so a new character kit animates the day it lands instead of needing the template edited first. Skeletons still resolve to their exact clips — verified identical in a real build (`ANIMPROBE_OK`).

### Added — 2026-07-17 (🎯 the curated tier finally listens to the brief — S5's missing "≥0.85")
- **The brief was ignored for the one decision the player actually sees.** `docs/GENERATION_PIPELINE.md` and CLAUDE.md §7 both specify S5 as `cache (≥0.92) → curated (≥0.85) → generate`. The **≥0.85 tier did not exist**: `enemy_model(index)` handed out Minion/Warrior/Rogue/Mage **by placement index**. The Content Designer could author "a hulking armoured brute" and "a nimble hooded scout" and the game assigned whichever skeleton the rotation reached.
- `asset_farm/curated_match.py` — the missing tier. The cache tier already asked "have we *made* this before?" semantically; the curated tier now asks the same way: **"do we already OWN something that is this?"** Matching before generating is not a fallback, it is the **cheap right answer** — a curated model is instant, licence-clear, already rigged and already animated, where a generated one costs GPU minutes and arrives as a statue (ADR-0005). Own it, then make it.
- **`MODEL_DESCRIPTIONS`: the library says what it IS.** Adding a model there is what makes it reachable by description — and the docstring is explicit that descriptions must be honest, because an inflated one wins matches it should lose and the player sees the mismatch.
- **Two independent guards.** The **floor** guards quality (below 0.85 the library simply doesn't contain the thing — inventing a match is how a wizard ships as a barrel), and **category scoping** guards kind (a character can never match a barrel, at *any* score — tested by making every embedding match and asserting enemies still only wear `characters/`).
- **The farm decides the body; the writer only draws it.** Since the pick is semantic, the writer's index cycle is no longer authoritative, so `shippable_models` now carries **curated** picks too. The writer routes by path: a file inside the kit ships from `res://kit/` and stays deduplicated, anything else is copied to `res://assets/`. This retired a test whose premise ("the writer already instances kit models") the change made false.
- **The player can now have a real, animated body**: "a robed wizard" is a model we own — where a *generated* player is a statue. No match → the capsule, and the aliveness rule then correctly lets any generated body through, because no motion can be lost.
- **Additive, and off without an embedder**: no bge-m3 → no opinion → the index cycle decides exactly as before (pinned by a test). A missing embedder costs variety, never a build.
- Verified in a real build: *"a hulking armoured brute"* → **`Skeleton_Warrior`** (the index cycle would have given Minion), shipped via `res://kit/` with no duplicate copy, `ANIMPROBE_OK`. Suites: **152 brain + 145 worker** (13 new); lint clean.

### Added — 2026-07-17 (🔊 the dog barks — sound GENERATED per character, per activity)
- **A described character had to borrow a skeleton's voice.** ADR-0004 gave every enemy sound chosen by its model family, which was right while every character *was* a curated skeleton. Once the planner can say "a snarling low-poly village dog" (v2.1.0), the family set is a mismatch: `clack` is bones, not a dog. **ADR-0006** amends ADR-0004 rather than reversing it — the principle ("what you hear must match what you see") is unchanged; only the cast opened.
- **Sound briefs are derived, not authored** (`asset_farm/sound_brief.py`). The planner decides *who* the character is — **one** field. What it sounds like striking, flinching, dying or stepping is a deterministic function of identity × activity: no second LLM call, no per-clip prompting, reproducible from the spec alone (rule 15). Same character+activity always hashes the same, so a rebuild **hits the cache instead of re-spending GPU minutes** (verified: second resolve → `tier=cache`).
- **Audio generation was never possible, for one reason**: `_try_generate` could only run `qa_mesh`, so the resolver excluded audio outright. It now routes each brief to *its own* gate — `qa_audio` for sound, `qa_mesh` for meshes — and a sound generator becomes a first-class backend. Nothing ships un-gated: curated audio is not trusted more than generated audio, and generated audio is not trusted at all until it passes.
- **Mesh and sound are separate switches** (`ASSET_GEN_ENABLED` / `AUDIO_GEN_ENABLED`, `select_audio_backend`). TRELLIS and Stable Audio cannot be co-resident in 32 GB (§4), so they are enabled, sequenced and failed independently — and "curated *animated* models + unique generated voices" is a real, supported, and right now the **recommended** combination, because a generated character is still a statue.
- **Per-activity fallback, not per-character.** If only the death clip is produced, the other three still play the curated bank — a half-working generator must never leave a character with a silent attack (tested). Every failure path lands on the curated set that ships today: generator off, host down, backend crash, clip flunks QA, clip too long.
- **Verified in a real Godot build**, not just in the manifest: `ANIMPROBE_OK`, banks `attack=1 hit=1 death=1 step=1` (its own clip, not 3 borrowed ones), `damage plays an impact sound -> c2320760d2c1bc2b.wav`, `death plays a sound -> d99c8104e75f3a4b.wav`. A fully-generated character ships **4 WAVs instead of 13**, because it no longer needs the shared bank.
- `MockAudioBackend` writes a **real WAV** (stdlib `wave`, decaying tone), so the whole path — brief → generate → gate → cache → ship → play — is exercised with no GPU, exactly as `MockBackend` does for meshes. `StableAudioBackend` (ComfyUI, same submit→poll→download shape as SDXL) refuses a mesh brief **before** any HTTP call, so a mis-wired caller fails instantly instead of after a 300s timeout.
- **Honest limit:** the Stable Audio ComfyUI contract (checkpoint + node graph) is written from the documented workflow and has **not** been run against a live install — the same position `backends_gpu.py` held before its SDXL graph was smoke-tested on the 5090. Flagged in the module docstring as the first thing to check. Licence: Stability AI Community License, free commercially below $1M/yr revenue, ledger-verified 2026-07-14, guard-enforced before a sample is generated.
- Suites: **152 brain + 132 worker** (22 new; 131 passed + 1 pre-existing skip); lint clean; contracts + licences PASS.

### Fixed — 2026-07-17 (🟢 CI is honest again — the worker job had been red, and lint hid 101 errors)
- **`worker (project writer)` was failing on every run** (exit 2 — a *collection* error, not a test failure). `asset_farm/semantic.py` imported `httpx` at module scope, and the resolver imports that module merely to read `SIMILARITY_FLOOR` — so **four** test modules could not even be imported in CI, three of them long before today's work. Reproduced exactly in a throwaway venv holding only CI's `pytest + jsonschema`, rather than guessed at.
- **The module contradicted its own docstring.** It promises the semantic tier is "never a hard dependency (a dead embedder must not stop the farm)", while a top-level `import httpx` made an HTTP client mandatory for the entire asset farm. `embed()` now imports it where it is used, so a curated-only farm is dependency-free — and CI additionally installs `httpx` because `test_semantic_cache` genuinely exercises the embedder over a mocked transport. Exactly the failure the workflow's own comment already records for `jsonschema` ("for months, silently, because nobody read the log").
- **Ruff: 101 → 0, and the gate is now BLOCKING.** The workflow said lint "becomes blocking in P1"; it never did, so 101 errors accumulated behind a green-looking tick. All fixed, no `# noqa` amnesty, and `continue-on-error` removed so it cannot rot again.
  - **`Depends()` is not a bug** — `db: Session = Depends(get_db)` IS the FastAPI idiom, so the linter was taught the framework (`extend-immutable-calls`) instead of contorting the endpoints around it.
  - **Real bugs found**: a leaked file handle in `pcg/cli.py`; and a `zip()` audit where each site needed its own answer — `strict=True` on the two RAG invariants (equal-length vectors from one model; silent truncation would hide a corrupt index behind a plausible score) but `strict=False` on `zip(route, route[1:])`, which is **deliberately** unequal and would have raised on every call.
  - **A blind `--fix` nearly broke the build**: ruff deleted `LIGHTING_PRESETS` from `agents/intent.py` as "unused" when the line above literally says *re-exported here* — caught by the suite, restored with an explicit `# noqa: F401`. Auto-fixers cannot see across modules.
  - `JobState(str, Enum)` → `enum.StrEnum`, safe because every call site already normalises through `.value` (verified before changing).
  - **Deliberately NOT done:** a repo-wide `ruff format` (1219 lines across 46 files) — it would have buried the feature work and imposed a style the team never chose. The 55 long lines were wrapped by hand instead, and `walls.py` kept a **provably dead** ramp condition (`(upper_is_b if forward else False) or upper_is_b` reduces to `upper_is_b`) with a NOTE rather than silently altering ramp orientation inside a lint pass.
- Verified by simulating **each CI job** in the clean venv: contracts/licenses/lint/root-pytest all PASS, worker `109 passed` exit 0. Gates re-checked byte-for-byte identical (licenses `PASS`, 0 violations, 8 pre-existing warnings). Suites: **152 brain + 109 worker**.

### Added — 2026-07-17 (🐕 the player has a body — spec **v2.1.0**, the first bump since the P0 freeze)
- **"As a dog, explore the village" was unrepresentable.** The `player` object carried only `controller_template_id` / `move_speed` / `health` / `verbs`, with `additionalProperties: false` — there was **no field in which "a dog" could be written**. Every player was an untextured capsule no matter what the prompt said. This was never a planner bug: the sentence could not be expressed in the contract.
- **`player.asset_brief` (schema v2.1.0)** — WHO the player is, resolved through the same farm as every other asset (`player:main`). `schema_version` goes `const "2.0.0"` → `enum ["2.1.0", "2.0.0"]`, so **N-1 is satisfied by construction** and the untouched golden spec still validates (asserted by a test). Additive and backward-compatible: omit the brief and the capsule stands in, exactly as before. **Team-approved 2026-07-17**, satisfying the two-person review + design sign-off that `SCOPE_FREEZE_MEMO` §61 requires. See **ADR-0005**.
- **Only the LLM path sets it.** Reading "as a dog" out of free text is exactly the ambiguity the planner exists for (rule 15), so rules mode never invents a body and stays byte-identical to the legacy builder — the equivalence guard is untouched. It rides the **existing** Content Designer call (`player_brief` is `required` in that guided schema, so the model must answer): no new agent, no extra round-trip, no added latency.
- **A junk or missing body costs the player a body, never the game** — hard-failing would throw the props and enemy roster away with it, and the capsule is a working fallback. Category is forced to `character` whatever the model claims; `tri_budget` is clamped. A spec that uses a v2.1 field also **patches `schema_version`**, so the record can never quietly lie about which contract it was written against.
- **The player forced a better rule.** The shipping policy from the previous entry hardcoded `enemy:`; the player made the real principle obvious and it now names no roles at all: **a generated asset must be at least as ALIVE as the thing it displaces.** A prop displaces a static prop → generated wins. An enemy displaces a *rigged, animated* skeleton → an unrigged mesh loses. A player displaces a capsule that never animated → a generated body wins, because **there is no motion to lose**. Self-adjusting in both directions: rigging will admit generated enemies automatically, and a rigged curated player would automatically start demanding rigging of generated players.
- **Honest limit:** the generated player is currently a **statue** — right species, no motion. Acceptable *only* because a capsule never animated either, so nothing is lost. "The character is a dog" today means it *looks* like a dog; motion needs rigging + retargeting, which ADR-0004's activity seam is built to receive.
- Verified end to end (mock backend): the player resolves `generated`, displaces nothing, ships, and the scene wears a `PlayerVisual` with the capsule gone — while a spec without a brief keeps the capsule and grows no `PlayerVisual`. Suites: **152 brain (14 new) + 109 worker**; contracts PASS, licences PASS; ruff **99 errors, below the 101 baseline**.

### Fixed — 2026-07-17 (🚚 generated assets finally reach the GAME, not just the lineage record)
- **The asset farm was generating models that no player could ever see.** `resolve_spec_assets` ran the full tree (cache → curated → generate → QA), wrote real GLBs to disk and recorded them in lineage — and then `write_project` shipped the curated kit anyway. The manifest was consumed **only** by `asset_tiers`/`asset_resolution` reporting; the writer had **no parameter that could accept a generated model**. Proven before fixing: with the mock backend the farm produced 9 QA-passing assets and not one could reach the scene. This is the same class of gap as the statues — the capability existed, the binding didn't — and it was the hard blocker on *"say it's a dog and the character IS a dog"*.
- `write_project(asset_models=...)` — one seam, `{"kind:source_id": Path}`, resolved through a single `_entity_model_ext_id()` so **props and characters can never drift apart**. Generated GLBs are copied to `res://assets/` and instanced by `ext_resource`; because the farm already content-addresses by `brief_hash`, N entities sharing a brief share **one** file (verified: 8 shipped props → 5 GLBs).
- **`shippable_models()` — resolving an asset is not the same as being allowed to wear it.** A generated **prop** always ships (props are static by nature, so a unique one is strictly better). A generated **character** ships only if it can *move*: a raw TRELLIS mesh is unrigged and clipless, so wearing it would turn a living enemy back into a statue — the exact bug just fixed. The trade is real (right species + dead vs. wrong species + alive) and we take **alive** until rigging exists.
- **The policy is written against capability, not against today's limits.** `mesh_capabilities()` reads the glTF JSON chunk for `skins` + `animations` (deterministic, no GPU; validated against ground truth: the KayKit skeleton reports **95 clips / 1 skin**, a generated mesh 0/0, an unreadable file degrades to "cannot animate" rather than raising). The day auto-rigging lands, rigged characters start shipping with **no change to this code** — there is a test pinning exactly that.
- **Every rejection is in the lineage** (§11): `not shipped as a character: mesh is not rigged/animated (skins=0, clips=0); the curated animated character ships instead so the enemy still moves`. The record says what was made AND why it isn't what you see.
- **A door never wears a model** — doors are functional `LockedDoor` slabs, and a mesh there would be a floating duplicate. The pipeline skips them, but the writer no longer *relies* on that implicit coupling; hand it a door model explicitly and it refuses (tested). Generated models ride the same repair lever as the kit, so the bare-build retry still strips everything.
- Verified in a real build: Godot imports/exports the generated GLBs, **8 generated prop instances all with real geometry** (not empty nodes), enemies still `ANIMPROBE_OK`, web export **45.47 MB / 90 MB**. Suites: **138 brain + 108 worker** (12 new).

### Added — 2026-07-17 (🔊 the models come alive — animation and sound driven by what enemies actually DO)
- **Enemies were rendering as statues.** The KayKit skeletons ship **~95 animation clips each** and nothing ever played one: the AI had real activities (patrol → chase → attack → hit → death) that existed only as physics. `ai_patrol_chase.gd` now binds the model's `AnimationPlayer` and drives it **from the activity**, resolving each activity against the clips the model *actually has* (`Idle`, `Walking_D_Skeletons`, `Running_A`, `1H_Melee_Attack_Chop`, `Hit_A`, `Death_C_Skeletons`). Best-first candidate lists, so a model with fewer clips still animates and a **generated mesh with none stays static rather than failing the build** — animation is never a hard requirement.
- **Two bugs a headless probe caught that a passing test suite never would:** (1) `_try_attack` force-replayed the swing *every physics frame*, restarting it at frame 0 forever — the strike was permanently frozen on its first pose; (2) the flinch was overwritten by locomotion on the very next tick, so `Hit_A` was visible for **under one frame**. Both fixed with a transient lock sized from the clip's **own length** (`_lock`), so a strike or flinch owns the model until it finishes, then hands back to locomotion. Verified in a real build: `HIT_TICK1 → Hit_A (lock 0.67)`, `HIT_TICK4 → Hit_A (lock 0.62)`, `AFTER_FLINCH → Walking_D_Skeletons`.
- **Death no longer cuts itself off.** `_die()` emits `died` immediately (listeners must never wait on a cosmetic animation) and drops collision at once so a corpse can't block the player, then plays the death clip and frees on `animation_finished` — or waits for the death *sound* when there is nothing to animate.
- **Sound chosen by the MODEL, triggered by the ACTIVITY** (`asset_kit.SOUND_SETS`) — the same curated-data contract as models, in the same one place. A skeleton dies as **bones clattering** (`clack`), not a fleshy thud; strikes are `swish`, impacts `hit_blunt`, and footsteps come from the walking itself, paced by how fast the enemy really travels. Adding a family (an armoured knight → `hit_metal`) is a **data change, not a code change**. Clip variety is seeded from the node name (rule 14), so it is reproducible from the spec and two enemies don't step in lockstep.
- **Curated from the team's own template** rather than generated: 13 CC0/public-domain WAVs (Cat Prisbrey souls-like template, Kenney upstream, explicitly no Mixamo). **All 13 pass `qa_audio`** — the identical gate generated audio must pass. Ledger row added, `check_licenses.py` PASS; `content/kits/README.md` now credits both packs and documents the contract (closing a promise the kaykit row had already made).
- **Degradation is the design:** no sfx kit → no properties, no nodes, no refs, a clean silent build; a half-copied kit is not a kit (`sound_files_exist` is all-or-nothing); audio rides the same repair lever as the models, so the bare-build retry still strips everything.
- Audio players are **real named nodes** (`Sfx`, `SfxSteps`, positional, `max_distance` 20) so a player who downloads the project can see and retune them — the "beginning, not an end" promise. Steps are on their own player so a footstep never cuts a strike.
- Verified end to end in a real headless build (probe): 5/5 enemies bound, all banks wired (3/3/3/4), `FOOTSTEP_WHILE_WALKING step_4.wav`, `HIT → Hit_A + hit_blunt_03.wav`, `DEATH → Death_C_Skeletons + clack_3.wav`. **Web export 45.72 MB / 90 MB budget** (audio cost ~1.2 MB). Suites: **138 brain + 96 worker** (8 new; 95 passed + 1 pre-existing skip); licence gate PASS.
- `services/worker/tests/anim_probe.gd` — the probe is **committed beside `nav_probe.gd`**, not thrown away, with a pass/fail verdict (`ANIMPROBE_OK` / `ANIMPROBE_FAIL`, exit code) and 13 checks. Validated by **reintroducing the flinch bug and confirming it fails** (`FAIL damage plays the hit clip -> Walking_D_Skeletons`, exit 1) — a probe that cannot fail proves nothing. Recorded as **ADR-0004**, whose lesson is the general one: *for anything time-based and visual, a green unit suite is not evidence it works.*

### Added — 2026-07-17 (🏁 P3 completion — style anchor, LLM edits, one-click re-export, R2)
- **Per-game style anchor** (`agents/style.py`) — `meta.style_anchor` is derived deterministically from genre + lighting and prepended to every SDXL prompt, so a game's generated assets share one art direction instead of each coming out in its own style. Set by both the Prompt Analyzer and `build_spec` (the equivalence guard stays green); the benchmark holds at 20/20.
- **Guided-JSON LLM edit path** for the Serendib Assist dock. Refactored the bounded edit application into a shared `EditOps` + `apply_ops`, so the keyword parser AND the LLM feed the *same* one place the safety lives — an LLM can only request a bounded op (factors clamped 0.5–2.0, lighting a registry enum), never an arbitrary mutation. `/edits/preview` uses the LLM when enabled and falls back to the keyword floor. 13 editor tests.
- **One-click re-export** (`POST /games/{id}/reexport`) — builds a new shareable game from an edited spec: it re-validates (an edit is not trusted more than a plan) and runs the same deterministic pipeline with the spec as an override, skipping the planner but keeping every downstream gate. Verified end to end: create → edit → re-export → DEPLOYED.
- **R2 artifact upload** (`storage/r2.py`) — the worker uploads the web build + downloadable project to Cloudflare R2 and records shareable URLs; config-gated, S3 client injected for tests, degrades to the local copy on any failure, secrets env-only. This is the code-side of hybrid deploy; live provisioning stays user-gated (§12/§13).
- Suites: **138 brain + 83 worker**; benchmark 20/20; contracts + licenses PASS.

## [Unreleased] — Phase P0

### Changed — 2026-07-09 (🎉 P0 GATE MET — schema frozen)
- **Golden game gate sign-off complete** (`docs/GOLDEN_GAME_TASKS.md` §13): start-to-win playthrough, 77 MB ≤ 90 budget, Chrome/Firefox/Edge/Safari + mobile smoke, 5-min no-crash — all user-confirmed 2026-07-09. CI-build box closed via a documented waiver (standalone gitignored project; local pinned-editor headless export accepted; CI-built mandatory from P1) — see `DECISION_LOG.md`.
- `contracts/game_spec.schema.json` — **FROZEN as v2.0.0**: `description` + `$comment` updated from DRAFT to FROZEN; from here any field change bumps `schema_version` (validator supports N-1).

### Added — 2026-07-14 (🎯 Game Designer — the brain finally CHOOSES the goal)
- `services/brain/agents/game_designer.py` — a new specialist that picks the **win condition**. `collect_n` existed and was wired end to end, but **nothing ever asked for it**: the brain still emitted `reach_zone` for every prompt, so the engine had a second goal the planner could not reach. This agent is what turns "the brain has a choice" from a claim into a fact — the first genuine decision about *what kind of game this is*, not merely how it is decorated.
- **Unrunnable goals are unrepresentable:** the registry's implemented objective ids ARE the guided-JSON enum, so the model cannot pick `survive_timer` or anything else we never built. The spatial spine (entry → … → locked door → exit) is identical either way, so **every reachability guarantee survives whichever goal is chosen** — only the unlock condition differs.
- **The goal and the world can never disagree.** A hunt whose level contains nothing to hunt builds perfectly and can never be won. The Game Designer runs *before* the Content Designer and hands it the quest, so the collectibles get authored on theme; and `ensure_pickups()` tops the world up deterministically if the author falls short **or never runs at all**. Gate 5 remains the backstop.
- **Live, same seed, two prompts:** *"steal the **four** cursed relics from the skeleton crypt"* → **`collect_n`, required_count = 4** (it read the number out of the prompt), collectibles `cursed_skull_relic`, `obsidian_vial_relic`, `rusted_sword_hilt_relic`, `ivory_tome_relic` — each with its own written brief. *"escape the foggy zombie village before dawn"* → **`reach_zone`**, the classic key chain, no collectibles. **Both DEPLOYED, both validation PASS, both won by the bot** (`GREEDYBOT_OK 24.5s` / `8.9s`), 45.6 MB.
- Rules mode still emits `reach_zone`, byte-identical to the legacy builder — the equivalence guard and the CI benchmark gate are untouched. **110 brain + 45 worker tests.**

### Added — 2026-07-14 (🎮 gate 6 goes live — every game is now PLAYED before it ships)
- `services/worker/bots/runner.py` + `worker/tasks.py` — the pipeline now **runs the playtest bot** against the exported project and feeds its verdict to gate 6. Nothing ever supplied `bot_verdict` before, so the dynamic gate recorded **SKIPPED on every job**: a game that could not be finished still passed validation. It now has to be *won* to ship.
- **Fail-soft on infrastructure, strict on gameplay:** a missing Godot binary, a crash or a hang returns `None` → gate 6 SKIPPED (a broken toolchain must not fail a good game). A bot that plays and *loses* returns its verdict → the gate **fails the game**, which is the entire point.
- Live: `escape the castle courtyard` → `DEPLOYED`, gates `1 PASS · 2 PASS · 4 PASS · 5 PASS · 6 PASS · 8 PASS`, **`BOT: GREEDYBOT_OK time=17.4s`**, 45.5 MB build.

### Added — 2026-07-14 (🔌 S5 is a live pipeline stage + the 4 farm models are license-verified)
- **License gate closed (§12).** The guard had refused all four farm models for an empty `verified_date`; each is now web-verified against its primary source and stamped: `trellis-2` → **microsoft/TRELLIS-image-large, MIT** (correction: no "TRELLIS.2" release exists), `sdxl` → **CreativeML Open RAIL++-M** (commercial, no revenue cap), `flux1-schnell` → **Apache-2.0** (explicitly commercial), `stable-audio-open` → **Stability AI Community License** (free commercial under $1M/yr revenue). `flux1-dev` and `hunyuan3d-2.1` stay quarantined. Live generation is no longer license-blocked.
- **S5 is wired into every job.** The resolver runs over each prop and enemy between the frozen spec and assembly; job detail gains `asset_tiers` ({curated: 9}) and a full per-asset manifest (tier, component, brief_hash, QA report). With no backend it is a no-op on shipped output that records provenance; the real GPU backend plugs into the single `backend=None` seam.
- Two guards fired correctly while wiring: **gate 1 refused the manifest inside `spec.lineage`** (frozen schema v2.0.0), so it lives in job detail — no schema bump forced; and the functional doors (animated LockedDoor) are skipped, not recorded as asset failures.

### Added — 2026-07-14 (🏭 P3 begins — the asset-farm S5 spine, GPU-free and tested)
- **The Content Designer's briefs finally have somewhere to go.** Every prop and enemy already carries a vivid `asset_brief`; until now they were discarded and every asset came from the fixed CC0 kit. `services/worker/asset_farm/` is the deterministic resolution spine that will consume them: **cache → curated → generate → QA → curated fallback**, with the one AI step (generation) behind a pluggable, license-checked `GenerationBackend`. Built and fully tested without a GPU — the real SDXL → TRELLIS.2 → Blender farm plugs into a proven target later.
- **`brief_hash`** (content-addressed key, §9) · **`AssetCache`** (exact-match, reproducible) · **QA gate = validation gate 3** (parses the GLB and *re-measures* triangle count, bounding box and size — a backend that lies about its output still fails) · **license guard** enforcing §12/§14 against the real ledger.
- **The build never blocks:** generation unavailable, unlicensed, crashed, or QA-failed all fall through to the curated asset, and every skipped tier is recorded in the `ResolvedAsset` for lineage. 16 tests cover each failure mode.
- **§12 finding, surfaced by the guard itself:** `trellis-2`, `sdxl`, `flux1-schnell` and `stable-audio-open` are pinned to the product path but carry **no `verified_date`**, so the guard refuses them — that license re-verification is the gating task before any live generation. `flux1-dev` and `hunyuan3d-2.1` are correctly refused (non-commercial / territory-excluded).

### Changed — 2026-07-14 (🏁 P2 CLOSED — MID-DEMO gate met on the real path)
- **P2 is finalized.** Final gate measurement **85% (17/20)** — prompt → real LLM plan → real Godot export → **the bot plays every game to completion** (best run 90%; bot runs are physics-nondeterministic because enemies interact). 20/20 LLM-planned, 20/20 genre, 20/20 schema-valid, 20/20 built at ~40 MB. The rules-mode CI gate stays 20/20 and reproducible.
- Final fix of the phase: **corridors whose floor stopped at the ramp's top.** A ramp can sit mid-leg, and the writer laid only approach + ramp — a 4.5-unit hole a player fell straight through. The writer now lays approach → ramp → tail-at-upper-elevation, and the navmesh mirrors the identical `walls.ramp_geometry()`. `dung_01`, which had failed **every** previous run, now passes (`GREEDYBOT_OK 9.6s`); `dung_04`'s navmesh went from 6 islands to one connected surface.
- **`test_floor_continuity.py`** — the two checks this whole saga was missing, both in milliseconds with no bot/export/GPU: walk every corridor polyline and fail on any point standing over nothing; flood-fill the navmesh and fail if any two rooms land on separate islands.
- Known residue, recorded not hidden: `dung_04` (bot snags a wall corner — single-level defect), `arena_01`/`expl_02` (flaky at a pre-existing snag point; plans byte-identical between runs, only bot-vs-enemy timing varies). First candidates for P3-era polish.

### Fixed — 2026-07-14 (🤖 the playtest bot could not finish ANY generated game — gate 6 was a lie)
- **The bot never completed a generated level.** Reproduced on committed code (`f9ad7fc`) at identical coordinates, so this pre-dated the collect_n work. Gate 6 has therefore never certified a generated game; every "PASS" so far rested on the static gates alone. **Four separate bugs**, found by tracing the player's physics state frame by frame:
  1. **The bot rode every ramp up and down forever.** `near`/`far` were re-derived from the player's *current height* each frame. A ramp runs from y=−0.25 to y=1.25, so the moment the player climbed past the midpoint (0.5) the "nearest end" flipped to the top, the bot decided the far end was now the **bottom**, turned around, and walked back down — then flipped again. It could not cross the halfway point of **any** ramp. The ends are now **latched at commitment**.
  2. **Objectives were aimed at their centres, not their floors.** A `KeyZone` Area3D is centred **1.5 above its own floor** — *exactly one tier height*. The tier test compares that y against the player's feet, so standing on the upper tier the bot still read the zone as "one storey up", committed to the ramp it had just climbed, and rode it back down. The door slab floats 1.25, a relic 0.6 — every one a different lie. The bot now **raycasts down to find the floor** beneath an objective instead of guessing each node type's offset.
  3. **Arrival was declared mid-climb**, by height alone against a centre-line point ~0.23 below the walkable surface. Ramp ends are now lifted onto the **actual surface**, and arrival requires *reaching the end*, not merely being at roughly the right altitude.
  4. **The player launched off ramps.** `move_and_slide` turns the horizontal push into upward velocity; carried into the next frame the capsule leaves the slope, gravity drags it back, and it *bounces* up instead of walking. `controller_third_person` now clears an upward drift while grounded (jumping is set separately, so it is untouched) and sets `floor_snap_length`. **This was hurting human players too, not just bots.**
- `project_writer` — **ramps were pitched at 36.9°**, spanning only the bare 2.0 room gap with a 1.5 rise. A walking capsule climbs that so marginally that the bot spent **142 s of its 150 s budget** on a single ramp and timed out on the run before. The climb now starts `RAMP_EXTRA_RUN` (2.0) back **inside the lower room**, spreading the rise over ~4.0 → **20.6°** — without moving a single room. The slab overlaps the lower floor, but its underside stays below head height throughout, so the capsule still cannot wedge beneath it (the hazard this geometry was originally shaped to avoid). The test now asserts the **slope** (≤25°) rather than a magic midpoint, because the slope is what actually matters.
- **Result — the bot now wins, and collect_n is proven end to end:** classic key game **`GREEDYBOT_OK 30.7s`** (was timing out), relic hunt **`GREEDYBOT_OK 14.9s`** — it gathers 4 relics, the door unlocks, it escapes. 103 brain + 45 worker tests.

### Fixed — 2026-07-13 (🔇 the brain could be switched OFF while every gate stayed green)
- `services/brain/core/config.py` — `env_file=".env"` was resolved **against the working directory**, so the API (launched from `services/brain`, which has no `.env`) loaded the built-in defaults while the benchmark (launched from the repo root) loaded the root `.env` — which still carried a **stale vLLM `LLM_BASE_URL` (`:8001/v1`)** from before the Ollama switch. Connection refused → **silent fallback to the rule parser** → all 20 prompts still reported **PASS**. The LLM was doing nothing and the gate was green. `ENV_FILE` is now anchored to the repo root, so every process (API, Celery worker, benchmark, tests) loads the *same* settings regardless of where it was launched. Guarded by a test that launches the settings probe from two directories and demands identical output.
- **The fallback is no longer silent.** Falling back is *correct* — a dead GPU must never stop generation (§ "never a hard dependency") — but it must be **loud**: `llm_planner` and `content_designer` now log a warning naming the exception and the base URL they failed to reach.
- **The benchmark can no longer lie about it.** `eval/run_benchmark.py --llm` grades the real product path, and `brief_source` is now recorded **per prompt** and summarized (`Planned by the LLM: n/20`) — a run that silently degraded to rules can never again be reported as an LLM result. This is exactly how the bug was caught: the first `--llm` run printed a proud **20/20 PASS** alongside **`Planned by the LLM: 0/20`**.

### Added — 2026-07-13 (🎨 Content Designer — the LLM authors the world; ADR-0003 Phase A lands)
- `services/brain/agents/content_designer.py` — a new specialist that decides **what exists in the world**: the props and the enemy roster, each with its own written `asset_brief`. This is where **"thinking-based uniqueness"** stops being an ADR and starts being output. Until now every game shipped the same ten props from the base spec, which is exactly why worlds felt templated.
- **Invention is impossible by construction, not by hope:** the registry's allowed ids are injected straight into the **guided-JSON `enum`**, so an invented `interactable_template_id` is *unrepresentable* in the model's output — a stronger guarantee than validating after the fact. Everything is re-validated and clamped anyway (budgets, registry membership, and **prop_id de-duplication**, since Godot node names derive from them and duplicates would collide in the scene).
- **Degrades, never breaks:** too-sparse or malformed output → `None` → the deterministic base content is kept. Rules mode stays **byte-identical** to the legacy builder (the equivalence guard still passes), so the CI benchmark gate is unaffected.
- **Live proof — same templates, genuinely different worlds.** *"descend the torchlit crypts, skeletons everywhere"* → enemies `bone_shambler ×12` + `ribcage_rogue ×6`; props include *"a cracked marble sarcophagus draped in rotting velvet"* and *"a jagged femur lever set in a bed of interlocking vertebrae"*. *"a cheerful sunny meadow… no enemies"* → **zero enemies**; props include `wisteria_trellis_climb` and `meadow_bloom_cluster` (*"a radiant cluster of sunflowers, lavender and poppies"*). The model is **reinterpreting** the same vetted templates (`lever_switch` = any wall fixture, `chest_lidded` = any container) — no new gameplay code, ever.
- Prop ids must be **descriptive** (`bone_urn`, `femur_lever` — never `chest_lidded` or `prop_1`) because they become the node names in the **editable project the user downloads**; a human must be able to read the scene tree. Live scene now contains `BonePileAltar`, `RelicSarcophagus`, `IronboundVaultDoor`, `RattleSkeleton_01`.

### Fixed — 2026-07-13 (⛰️ unclimbable cliffs — a level could be unsolvable and look perfect)
- `services/brain/pcg/zone_graph.py` — **zone tiers were drawn at random per zone, before the edges existed** (`tier=rng.randrange(verticality_tiers)`), so a corridor could join a tier-0 room to a tier-2 room: a **3.0-unit cliff**, when a ramp bridges only one tier (rise 1.5 against the 1.6 walkable step). The level rendered beautifully and **the key was unreachable**.
- Found the moment the Content Designer's crypt prompt made the planner ask for **3 tiers** ("*descend* the torchlit crypts") — the frozen benchmark's rules-mode briefs never picked 3, so 20/20 had been passing straight over a latent unsolvability bug. **The validation stack caught it before a user ever could** (gate 5 `KEY_UNREACHABLE` + `EXIT_UNREACHABLE`, job `FAILED`) — the safety net working exactly as designed.
- Fix is in the **deterministic layer, not the prompt**: `_bridgeable_tiers()` relaxes tiers to a fixed point after the edges are known — while any edge spans >1 tier, the higher zone is pulled down to one above the lower, then the whole level is normalized back to the ground tier (relaxing only lowers, so a level could otherwise settle floating above zero). It only ever lowers, so it provably terminates; it uses no RNG, so seeds stay reproducible; and **verticality survives** — the drops just become climbable.
- Guarded by a sweep across **all 4 algorithms × 40 seeds × 4 sizes at 3 tiers**: no edge may ever span more than one tier, the ground tier always exists, and multi-tier levels must not be flattened. Re-ran the failing prompt end-to-end: `DEPLOYED`, validation **PASS**, **0 repairs**, playable **45.6 MB** build. Suites: **99 brain + 39 worker**; benchmark **20/20**.

### Added — 2026-07-13 (📚 RAG over design knowledge — the P2 knowledge row closes)
- `services/brain/knowledge/notes/design_notes.json` — curated design corpus (10 notes: per-genre guidance, pacing, difficulty, lighting/mood, the lock-and-key spine, verticality, and an explicit **capabilities note that denies what we DON'T have** — no ranged combat, no inventory, no crafting — so the planner can't be tempted to promise them).
- `services/brain/knowledge/rag.py` — **bge-m3 embeddings via Ollama** (MIT; license re-verified on the HF model card before entering the product path, ledger updated) + cosine retrieval, wired into the Prompt Analyzer so retrieved notes ground the planner's system prompt. `retrieved_notes` recorded in job detail (RQ3 provenance). `RAG_ENABLED` is the **ablation D toggle** (C = off, D = on).
- **Never a hard dependency:** if the embedder is down, retrieval degrades to deterministic keyword scoring over the notes' tags — a dead GPU must never stop generation. Tested against a dead endpoint.
- **Empirically-set relevance floor:** measured bge-m3 on this corpus — on-topic prompts score 0.62–0.71, gibberish peaks at 0.41, off-domain ("capital of France") at 0.25. A 0.5 top-score floor means off-domain prompts retrieve **nothing** rather than polluting the planner's context. (Without it, cosine returns notes for *any* query — caught by a test.)
- **Honest result:** a live A/B (RAG off vs on, same prompt/seed) changed only the enemy count (4→6) — the base model already handles clear prompts well. The *mechanism* is live and grounded; whether retrieval measurably improves outcomes is exactly **RQ3**, to be answered by the C-vs-D ablation this flag now enables. No overclaiming. Suites: **91 brain + 39 worker**; benchmark **20/20**; licenses PASS.

### Added — 2026-07-13 (📇 registries — invented IDs are now impossible)
- `services/brain/knowledge/registries.py` — the **allowlist**, derived from what is *actually implemented*: template ids scanned from the vetted `engine/templates/*.gd`, interactables from what the asset kit honors, lighting presets as the single source of truth (`agents/intent` now imports them from here). Enforced in the pipeline before schema validation, so a hallucinated id fails **immediately** with a machine-readable error naming what IS allowed — instead of surfacing later as a broken build. Live-proven: a rogue `controller_hover_bike` → job `FAILED` with `TEMPLATE_ID_NOT_IN_REGISTRY`.
- **The registry immediately caught two phantom mechanics in the canonical spec** — ids the engine never honored: `combat_melee_basic` (no combat template exists; melee actually lives inside `ai_patrol_chase`) and `activate_switch` (no such objective; the key zone is really emitted as a non-win `reach_zone`). `golden_game.spec.json` corrected to describe what the engine truly does — the spec no longer promises mechanics that don't run.
- **Drift guards** (3 tests): the registry's controllers/lighting/interactables must equal the worker's real `CONTROLLER_EXT_IDS` / `LIGHTING_PRESETS` / asset-kit maps — CI fails if the allowlist ever drifts from the implementation.
- Suites: **85 brain + 39 worker**; benchmark still **20/20**; contracts PASS.

### Changed — 2026-07-13 (🔌 agents-as-patches is now THE production path)
- `worker/tasks.py` — the single-planner path (`parse_intent`/`llm_brief` → `build_spec` → thin arbitrate) is **replaced by the agent chain**: `author_spec()` runs Prompt Analyzer → World Designer → Mechanics, each emitting patches merged by the Arbiter. Job detail now records the `agents` that ran plus per-field `arbiter_decisions`. The Mechanics agent also owns the **enemy roster** (a patch value may be a whole sub-tree, so an agent can rewrite `entities.enemies` wholesale).
- `eval/run_benchmark.py` — the benchmark now measures the **same production path**, so the CI gate can't pass on code the product doesn't run.
- **Equivalence guard** (`test_chain_matches_the_legacy_spec_builder`): the chain must produce byte-identical specs to the legacy `build_spec` across four prompts — CI fails if they ever diverge. This is what made the swap safe.
- **Verified after the swap:** benchmark still **20/20 PASS, reproducible**; **78 brain + 39 worker** tests green; live end-to-end with the real LLM + Godot → `brief: llm`, `agents: [prompt_analyzer, world_designer, mechanics]`, validation PASS, 0 repairs, playable **43.7 MB** build.

### Added — 2026-07-13 (🧑‍🤝‍🧑 multi-agent chain — many agents, one job each)
- `services/brain/agents/chain.py` — the **agent harness** (P2 row; ADR-0003 Phase A): every agent has ONE job and the SAME shape (context → decision → JSON patch → logged), and the **Arbiter merges all patches** under the priority stack. First specialists live: **Prompt Analyzer** (LLM or rules → Brief; owns genre/camera/mood/lighting), **World Designer** (topology, scale — genre picks the PCG algorithm), **Mechanics** (controller, enemy budget, session length). Explicit user options outrank agent inference and the losing proposals are recorded, never silently dropped.
- **Full decision provenance**: every field in the merged spec names the agent that decided it — dissertation data, and the mechanism for "thinking-based uniqueness" (agents compose; templates execute; no free code).
- **Live-verified on the real model**: *"a moonlit monastery where something hunts me between the cloisters"* → the LLM inferred survival/escape + top-down + moonlit-night and authored its own mood ("Moonlit cloisters, quiet dread in every stone shadow"); World Designer then chose the topology, Mechanics the controller. 4 chain tests (schema-valid merge, per-agent provenance, user-option override, determinism). Suites: **77 brain + 39 worker**.
- **Fixed an operational bug the live run exposed:** a cold 17 GB model load takes ~50s, so the first request after idle blew the 90s timeout and silently fell back to rules. The planner now sends Ollama `keep_alive=30m` and the default timeout is 180s — so the LLM path actually gets used in practice.

### Decided — 2026-07-13 (🧭 project vision confirmed — team-accepted ADRs)
- **ADR-0002 (Accepted):** PromptPlay is a **domain-pack platform**, not games-only — education + visualization become post-v1 packs on the same engine; user-data model training deferred + hard-gated behind DPIA/consent/pseudonymization (minors). v1 stays frozen on games.
- **ADR-0003 (Accepted):** generation becomes **compositional / "thinking-based" unique** — the LLM reasons about *combining* vetted parts (Phase A: richer authored specs, in v1 scope; Phase B: behavior-graph composition, v2; Phase C: gated adapter), with free gameplay code **permanently banned**. **Phase A greenlit.**
- Vision reflected in `README.md`, `docs/PROJECT_OVERVIEW.md`, `docs/IMPLEMENTATION_PLAN.md`; decisions #8/#9 resolved in `DECISION_LOG.md`. (README/plan phase status also corrected P0 → P2.)

### Added — 2026-07-13 (⚖️ the Arbiter — constraint priority stack, every decision logged)
- `services/brain/orchestrator/arbiter.py` — merges partial spec patches under the documented stack (**platform_limits > scope_allowlist > playability > designer_intent > user_preference > cost > aesthetics**): highest band wins per field, ties broken by proposal order. The two hard bands don't just win — they **clamp**: an illegal genre/camera or over-budget value is overridden to the nearest legal one and the override recorded. Rule-based and fully logged (`{path, chosen, source, band, losers, reason, overridden_from}`) — the decision log is RQ2 dissertation data; the tie-break LLM call is a later addition, the merge machinery already exists for when the full agent chain emits patches.
- Wired into the pipeline: the planner brief + the user's explicit request options become Proposals, reconciled by the Arbiter (explicit user picks outrank inference, logged as such) with the hard-band clamps as a safety net before schema validation. `arbiter_decisions` recorded in job detail. Live-verified: user's `third_person` correctly overrides a dungeon prompt's isometric default, decision logged with `source: user_options`.
- `tests/test_arbiter.py` — 7 tests: band precedence, order tiebreak, genre/camera allowlist clamps, build + enemy budget caps (both directions), user-beats-inference wiring, JSON-serializable log. Suites: **73 brain + 39 worker**.

### Added — 2026-07-13 (📊 frozen benchmark + batch runner — the MID-DEMO gate has a ruler)
- `eval/benchmark_prompts/v1_frozen.json` — the **20 frozen regression prompts** (5 per genre, fixed per-prompt seeds), phrased to exercise the intent parser's keywords. Frozen: append-only once results exist.
- `eval/run_benchmark.py` + `eval/metrics/collectors.py` — batch runner: each prompt through the real brain-side pipeline (intent → spec_builder → schema → PCG → 8-gate validation + one localized repair pass), collecting pass rate, genre match, schema validity, repair count, latency p50/p95, and level-plan hash. Emits JSON + Markdown; `--verify-reproducible` runs twice and fails on any hash drift. No Godot needed — measures the deterministic core the gate is about.
- **First run: 20/20 PASS (gate MET, threshold 80%), 20/20 schema-valid, reproducible.** The run surfaced one honest rules-tier gap — "descend the forgotten mines…" didn't route to dungeon (the LLM planner does) — fixed by adding `mine*`/`delve*` to the dungeon keyword rules (prompts stay frozen; the parser improved). Genre match 19→20.
- `services/brain/tests/test_benchmark_gate.py` — the gate is now a **CI-enforced invariant**: every push asserts ≥80% pass + 20/20 schema-valid + 20/20 genre match + reproducibility (~600ms). Generated reports stay gitignored (regenerable telemetry); prompts + runner are versioned. Brain suite: **66 passed**.

### Added — 2026-07-11 (📡 live progress streaming — SSE phase events)
- `services/brain/api/events.py` — `GET /api/v1/jobs/{id}/events`: Server-Sent Events streaming the job's real state transitions (PLANNING → … → VALIDATING → REPAIRING → DEPLOYED/FAILED) as they land in the DB. Emits on change, closes on terminal state, caps at 300s; works with the real async worker and degrades cleanly in eager mode (already-terminal → one frame + close). SSE over WebSocket is deliberate — one-directional, auto-reconnecting, tunnel-friendly; a Redis pub/sub relay can replace the DB poll later without changing the wire format.
- `apps/web`: `subscribeJobEvents` (EventSource client) + the job page now **prefers the live stream and falls back to REST polling** if it can't connect — the `VALIDATING`/`REPAIRING` states finally surface in the browser as they happen.
- 2 SSE tests (terminal-frame-then-close via `client.stream`, 404 job) + a mid-stream frame carrying `genre`. Frontend builds clean. Brain suite: **64 passed**.

### Added — 2026-07-11 (🔧 repair loop v1 — localized, capped, recorded)
- `services/brain/repair/loop.py` — the documented repair policy (docs/VALIDATION_PLAN.md): failure class → responsible node → localized action. `schema` → S2 deterministic spec fixes (camera↔controller lockstep, enemy/prop budget clamps — reviewable rules, no LLM); `logic` → S4 level re-roll (deterministic salted seed, spec untouched); `build` → re-export then drop kit models; `asset` → curated substitution (P3 no-op); `quality` → advisory, never auto-repaired.
- Pipeline task refactored so S4→S7 is one repairable `attempt()`; the loop re-invokes **only the responsible node**, caps at **3 attempts/class**, enforces **monotonic progress** (an attempt that doesn't shrink the error-code set fails fast), runs through the `REPAIRING` state, and records every attempt (`{failure_class, attempt, action, errors_before, errors_after}`) into job detail — that log is dissertation data (RQ2).
- Tests: 5 unit (routing, deterministic seed re-roll disjointness, each fixer, unfixable→no-op) + **1 API integration** proving a monkeypatched gate-2 budget break is caught, clamped, and the job recovers to DEPLOYED with the repair attempt logged. Healthy games deploy with an empty repair log (live-verified). Suites: **62 brain + 39 worker**.

### Added — 2026-07-11 (✅ the 8-gate validation stack — P2 begins in earnest)
- `services/worker/validators/gates.py` — the documented stack (docs/VALIDATION_PLAN.md), in order, cheapest first, every failure the documented shape `{code, gate, path, message, hint, failure_class}`: **1 schema** (jsonschema vs frozen v2), **2 constraints** (camera↔controller lockstep, enemy/prop budgets, plan↔spec zone drift), **4 import/export** (build ≤ budget, core files present), **5 static playability** (grid-BFS solvers: key reachable with the door SHUT, exit reachable with it open — cliff-aware, ramp-step tolerant), **8 lineage** (prompt/seed/build_hash present or DEPLOYED is blocked). Gates 3 (P3 asset QA), 6 (opt-in bot), 7 (opt-in critic) record honest SKIPPED verdicts.
- Pipeline task: spec `lineage` finally populated for real (prompt, master seed, planner digest, spec_hash, build_hash of the .pck) → `VALIDATING` state runs the stack → FAIL stores the full machine-readable report in job detail and blocks DEPLOYED.
- Live: full prompt→export run shows the gate table in job detail (PASS ×5, SKIPPED ×3, 45.5 MB). 7 new gate tests (incl. a severed-exit level correctly caught by `EXIT_UNREACHABLE`, class `logic`). Suites: **56 brain + 39 worker**. Serendib CI build **green (user-confirmed)** — P1 fully closed.

### Added — 2026-07-11 (🤖 GreedyObjectiveBot — Bots v1 complete)
- `services/worker/bots/greedy_bot.gd` — the plan's real bot: **reads state, decides greedily, no precomputed route**. Discovers objectives from the scene (KeyZone → LockedDoor → WinZone by live completion state, via the game's own signals), follows `NavigationServer3D` paths with continuous replanning, routes across tiers by reading the ramp nodes' geometry (approach lower end via nav, commit straight across, replan on the new tier), targets the door's slab (not its in-wall hinge), and carries an **unstuck maneuver** (back-off + alternating sidestep + replan) after 2s of pinning. Never vision.
- `godot_client/navmesh.py` — **eroded by one cell** (0.5u wall clearance): NavigationMesh `agent_radius` only affects baked meshes, so hand-authored polygons reached the wall faces and funnel paths hugged corners a 0.4-radius body physically can't follow (found by the bot; also improves enemy pathing).
- **5/5 autonomous playthroughs**: corridors 14.9s, caves 8.7s, wfc-dungeon 20.8s (recovered from a bogus cross-island nav path via the unstuck maneuver), top-down 12.4s, isometric 8.2s. `walk_probe.gd` stays as the scripted-route regression tool.

### Added — 2026-07-11 (🕸 PCG algorithm set complete — genre drives topology)
- `pcg/zone_graph.py` — the two remaining vetted algorithms: **`cellular_caves`** (random recursive tree — hubs and dead-ends emerge naturally — plus 0.35 loop density: a warren, structurally loopier than corridors, kinds skew hostile) and **`wfc_dressing`** (chain skeleton whose middle-zone kinds collapse via a miniature Wave Function Collapse: lowest-entropy-first, seeded tie-breaks, adjacency constraints — no adjacent loot rooms, no combat guarding the key, no empty runs). Shared `_deepest_leaf_lock` finisher keeps the entry/key/locked-exit invariants identical across all four algorithms.
- `agents/spec_builder.py` — **genre now picks the topology**: escape → `room_corridor`, arena → `bsp`, exploration → `cellular_caves`, dungeon → `wfc_dressing`. All four vetted algorithms are live product paths.
- `tests/test_zone_graph_variants.py` — 5 tests: determinism + connectivity + lock/key across 100 combos per variant, caves-loopier-than-corridors (structural), WFC constraint satisfaction, layout+placement integration. **Both variants bot-verified start-to-win** (caves 9.7s, wfc 17.7s). Suites: **56 brain + 32 worker**.
- Known v0 limit (recorded): loop corridors run center-to-center and can pass through intervening rooms at a different tier — functional (rasterization handles coverage) but visually rough; proper corridor routing is future GridMap-materialization work.

### Fixed — 2026-07-11 (serendib-build CI failure)
- Both CI jobs failed at the rebrand step: `icon.svg` no longer lives at the repo root in 4.7 (brand assets moved to `misc/logo/`; runtime icon = `main/app_icon.png`). Branding targets corrected + `app_icon.png` generated; **re-verified against a real full 4.7-stable clone: exit 0, patches idempotent, legal checklist 4/4**. Root cause of the bad original check: a raw-URL fetch whose 404 body was saved without checking the status. Also pinned `*.patch` to LF in `.gitattributes` (CRLF conversion silently breaks patch application).

### Added — 2026-07-11 (🏷 Serendib rebrand v0.1 — patch series + CI build)
- `engine/serendib/patches/` — **Tier-1 patch series** against `godotengine/godot @ 4.7-stable`, written from the real upstream sources and verified `--fuzz=0`: `0001` engine identity (`version.py`: name/short_name/website — also moves the user config dir to `user://serendib`), `0002` About-dialog credit ("based on Godot Engine" + non-affiliation disclaimer; MIT license viewer untouched).
- `engine/serendib/branding/` — generated splash (1600×900, Serendib emblem + mandatory Godot credit line) and `icon.svg`.
- `engine/serendib/rebrand.py` — the P0 skeleton is now real: clone/verify upstream at the pinned tag → dry-run + apply patches (idempotent: already-patched trees detected via reverse-apply) → copy branding → **legal checklist gate** (MIT intact, COPYRIGHT present, credit present, identity set — refuses to bless a failing tree). Tested end-to-end against pinned sources: check ✓ apply ✓ checklist 4/4 ✓ idempotent ✓.
- `.github/workflows/serendib-build.yml` — manual-dispatch CI: clones the pinned tag, rebrands, builds the **Linux editor** and the **single-threaded web export template** with the pinned Emscripten 4.0.11, uploads both artifacts. SCons cache keyed on tag+patches.

### Added — 2026-07-10 (💀 real models — the curated asset tier ships)
- `content/kits/kaykit/` — **curated CC0 kit** (asset resolution tier 2: cache → CURATED → generate): 10 dungeon props (chests, torches, barrels, stairs, gate, column, banner) + 4 skeleton character variants from Kay Lousberg's KayKit packs. Licenses verified CC0 and copied into the kit dir; both packs in the licensing ledger (`check_licenses.py` PASS).
- `services/worker/godot_client/asset_kit.py` — deterministic registry: `interactable_template_id` → model (levers → wall torches, ladders → narrow stairs, gates → gated wall, unknown props → barrel), enemies cycle Minion/Warrior/Rogue/Mage by placement index. Functional doors keep the swinging slab.
- Project writer v0.9 — `kit_dir`/`prop_configs`: used models are copied into `res://kit/`, props become **instanced GLB scenes** (deterministic 90° yaw variety), enemies get **skeleton visuals** over their capsule collision; `ai_patrol_chase` now turns to face its motion. Marker3D fallback stays when no kit is present.
- **Verified live**: torchlit-crypt game → 9 GLBs, 13 instanced props, 5 skeletons; clean import + 120-frame run; `WALKBOT_OK` (15.6s); export **45.5 MB** of the 90 MB budget. Suites: **51 brain + 32 worker**.

### Added — 2026-07-10 (🌙 mood becomes visible — vetted lighting presets)
- `services/worker/godot_client/lighting.py` — **five vetted lighting presets** (`overcast_day`, `moonlit_night`, `dusk_fog`, `sunny_bright`, `cave_torchlit`): each a complete look — WorldEnvironment ambient + background clear color + optional fog, sun color/energy, and floor/wall material palettes. Deterministic data; unknown ids fail machine-readably (`lighting_preset_unknown`).
- `Brief` gains `lighting_preset`: chosen by the LLM (schema enum + prompt guidance) or keyword rules (`moonlit/night` → moonlit_night, `foggy/haunted` → dusk_fog, `cave/crypt/torch` → cave_torchlit, `sunny/meadow` → sunny_bright); flows through `world.lighting_preset_id` into the writer. Floors/ramps get `MatFloor`, walls `MatWall`.
- **Live-verified**: "a moonlit night courtyard where guards patrol" → exported scene has fog enabled, night-blue background, 23 tinted floor + 48 tinted wall materials; 120-frame engine run clean. A haunted prompt now *looks* haunted. Suites: **51 brain + 32 worker**.

### Added — 2026-07-10 (🤖 the LLM planner arrives — guided decoding via Ollama)
- `services/brain/agents/llm_planner.py` — **S1 via the pinned local LLM**: the Brief JSON schema is passed as Ollama's `format`, so `qwen3.6:27b` can only emit schema-shaped JSON (true guided decoding; vLLM+xgrammar swaps in as the transport P3+). Fixed sampling seed for reproducible planning; every answer is still validated + clamped; **any failure (server down, timeout, garbage, bad enum) returns None and the rule-based parser takes over** — the platform never depends on the GPU being up. User-picked genre/camera always override the model.
- Config: `LLM_ENABLED` / `LLM_BASE_URL` / `LLM_MODEL` / `LLM_TIMEOUT_SECONDS` (`.env.example` updated); job detail gains `brief_source: llm | rules`.
- `tests/test_llm_planner.py` — 4 tests over a mock transport: schema-constrained request actually sent, valid answer → Brief, user overrides, clamping, garbage/downed-server fallbacks. Brain suite: **50 passed**.
- Ops: pulled the pinned planner `qwen3.6:27b` (17 GB, Q4) onto the RTX 5090 via Ollama. Pending decisions #3/#4/#5/#7 all **resolved** (user-confirmed) in `DECISION_LOG.md`.

### Added — 2026-07-10 (🎥 all three cameras real — controllers complete)
- `engine/templates/controllers/controller_topdown_3d.gd` + `controller_isometric_3d.gd` — vetted templates 7 & 8: world-axis (top-down) and camera-relative (isometric, exported `camera_yaw_deg`) movement, body turns to face motion, no mouse-look; same `apply_damage`/`died`/`health_changed` seams and input actions as the third-person controller.
- Project writer maps `player.controller_template_id` → script + matching camera rig (overhead −65° pitch / classic 45°-yaw −35°-pitch iso, row-major bases precomputed); unknown ids fail machine-readably (`controller_unknown`). Golden spec's controller id aligned to the canonical `controller_third_person` (souls provenance stays in lineage).
- Walk-probe bot learned fixed-camera driving (input-space axis pressing via `camera_yaw_deg` duck-typing) + tighter 0.9 arrive radius (corner-cutting elbows wedged iso runs).
- **All three cameras bot-verified start-to-win**: third_person 5.4s, top_down_3d 12.4s, isometric_3d 7.6s — the intent parser's camera choice is now a real gameplay difference. Worker suite: **30 passed**.

### Added — 2026-07-10 (🧠 prompts now shape the game — S1 intent + S2 spec builder)
- `services/brain/agents/intent.py` — **S1 rule-based intent parser**: deterministic keyword rules over the v1 allowlists map the prompt to a `Brief` (genre, camera-by-genre default, zone_count 4/7/12 by size words, verticality by tower/floors words, enemy density 0/3/5/12 incl. "peaceful" ⇒ no enemies, mood). Explicit user options always beat inference. The P2 guided-JSON classifier will emit the SAME `Brief` shape — nothing downstream changes.
- `services/brain/agents/spec_builder.py` — **S2 deterministic designer**: applies the brief onto the schema-frozen base spec as a small reviewable patch (genre/camera/world shape/enemy counts/controller id/budget caps/session length). Same seam the LLM planner plugs into.
- Pipeline task runs S1+S2 before S3 validation; job detail now carries `genre`/`camera`. "a tiny peaceful garden" ⇒ 4 zones, 0 enemies, collect_explore; "a huge dungeon crawl with a horde" ⇒ 12 zones, 12 enemies, isometric dungeon — live-verified through the API with real 38 MB exports.
- **Fixed `pcg/placement.py` capacity bug the new density range exposed** (12% of horde seeds failed): combat zones are now the *preference* and every other non-entry/non-exit zone is deterministic spillover — a lone small combat room can no longer cap the enemy count. Regression-swept **300 seeds of the horde brief + 1000 brief×seed combos: zero failures**. Brain suite: **46 passed**.

### Added — 2026-07-10 (⬇ downloadable editable project — the core promise ships)
- `services/worker/godot_client/packager.py` — S8 packaging: zips the generated project **sources only** (no `build/`, no `.godot/`, no `.import`) with a generated README (exact open-in-Godot steps, what each file is, where the signal wiring lives). Fixed timestamps + sorted entries ⇒ byte-identical archives for identical projects (lineage-hashable).
- Brain task publishes `project.zip` beside the web build; job detail gains `download_path`; the job page gains **⬇ Download project** next to ▶ Play.
- **Verified end-to-end like a real user**: packaged (25 KB) → unzipped → the downloaded project **imports and runs clean in Godot 4.7-stable headless**. "The output is a beginning, not an end" now literally works. Worker suite: **28 passed** (3 new packager tests incl. byte-stability + round-trip).

### Added — 2026-07-10 (🚀 prompt → playable URL: the platform loop is live)
- `services/brain/worker/tasks.py` — the hello-job stub replaced by the **real pipeline**: S2-stand-in (golden spec personalized with the prompt's title + seed — every job builds a distinct deterministic world), S3 jsonschema validation against the frozen v2 schema, S4 seeded PCG → level plan (hash + zone/entity counts in job detail), and — when `GODOT_BIN` is configured — S6 project assembly + S7 WebGL2 export + S8 publish under `artifacts/<game_id>/` (served at `/artifacts`). Job states advance per stage; failures land in FAILED with `{code, path, message, hint}`.
- `services/brain/core/config.py` — `spec_path` / `templates_dir` / `godot_bin` / `artifacts_dir` settings; `main.py` mounts `/artifacts` (StaticFiles; R2 + signed URLs replace this in P3); brain deps + `jsonschema`.
- `apps/web` — the job page's disabled "Play (P1)" button is now a **real ▶ Play link** (`API_BASE + detail.play_path`, new tab); honest fallback message when the server has no `GODOT_BIN`.
- **Verified live end-to-end**: `POST /api/v1/games {"prompt": "a haunted castle…", "seed": 777}` → states through EXPORTING → DEPLOYED with `play_path` → the URL serves the 38.1 MB game. Brain suite: **38 passed** (3 new: level detail matches spec, same-seed ⇒ identical plan / different-seed ⇒ different world, derived seeds). `P1 GATE row ticked` — bot + human playthrough both confirmed.

### Added/Fixed — 2026-07-10 (walk-probe bot finds & fixes 4 blockers — WALKBOT_OK)
- `services/worker/bots/waypoints.py` + `bots/walk_probe.gd` — **Bots v1 (early)**: computes the entry→key→exit route from the level plan (BFS, corridor polylines, door front/back) and drives the REAL player controller through it headlessly by faking input actions (rotate + move_forward + interact); on stall it raycasts and names its blocker. State-reading, never vision.
- The bot found, in order, what the playtest felt ("can't find the door"):
  1. **Ramp wedge** — floor slabs extended under rising ramps; a walking capsule slides under and jams. Tier height cut to 1.5 (`pcg/layout.py`) and ramps now span exactly the inter-room gap with no floor beneath (approach slabs end at the ramp foot, unpadded).
  2. **Transposed rotation basis** — `.tscn Transform3D` is ROW-major; ramp rotations were emitted as columns, so every ramp sloped the wrong way. Axis-aligned geometry had masked it.
  3. **Enemy body-block** — a chasing shambler and the player (same collision layer) deadlocked in the corridor mouth while it chewed through the player's 5 HP. Proper layers now: world=1, player=2, enemies=4 — no physical blocking, damage stays proximity-based; zones detect the player layer only.
  4. **Door interact out of range** — bigger InteractZone (+4) and a closer, held interact.
- **`WALKBOT_OK waypoints=10 time=13.1s`** — the bot now completes the generated game start-to-win. Both suites green (35 brain + 25 worker incl. live export, 38.1 MB).

### Fixed — 2026-07-10 (playtest feedback: unreachable door / broken ramps)
- **Ramp geometry was wrong** (user playtest: "can't find any door"): tier-crossing corridors ramped center-to-center, so the slab rose *underneath* the upper room's floor — the upper rooms (key + exit + door) were physically unreachable, and parts of the slope exceeded Godot's 45° walkable limit. Now: flat pieces run at the lower elevation and a **33.7° ramp** (`RAMP_RUN_PER_UNIT_RISE = 1.5`) tops out **exactly at the upper room's edge**, with its approach apron extending back into the lower room. Handles both climb directions and elbow corridors.
- `WALL_HEIGHT` 3 → 5 so ramps stay contained between their side walls near the top.
- Locked-door height simplified to the exit-room elevation (corridors always meet that edge at floor level now).
- **Visual identification** (nothing was distinguishable): blue player / red enemies / brown door materials, and a glowing cyan **KeyBeacon** pillar in the key zone — the HUD's "glowing key zone" hint is finally true.
- Re-verified: ramp `CorridorZ00Z01_Seg1Ramp` connects tier 0 → 4; door on the exit edge at floor height; 38.1 MB export; 120-frame runtime clean; `NAVPROBE_OK enemies=5`. Worker suite: **25 passed**.

### Added — 2026-07-10 (P1 spine: lose flow + HUD — gate-candidate build)
- `engine/templates/objectives/player_death.gd` — **fifth vetted template** (`FailStatePlayerDeath`): death card ("YOU DIED" + Try Again) on the player's `died` signal, wired declaratively. Binds to `fail_states[]` `player_death`.
- `engine/templates/ui/hud_basic.gd` — **sixth vetted template** (`HudBasic`): health readout + friendly objective hint line that switches when the key objective completes ("Find the glowing key zone…" → "The exit door is unlocked — escape!"). Presentation only, no game logic.
- `services/worker/godot_client/project_writer.py` v0.7 — emits `FailStatePlayerDeath` + `Hud` (max_health from the spec) with `[connection]`s: Player `died` → death card, Player `health_changed` → HUD, KeyZone completed → HUD hint.
- **P1 gate candidate verified end-to-end:** hand-written golden spec → complete playable WebGL2 game (**38.1 MB**, win + lose + HUD + 5 enemies + lock-and-key), zero manual steps; 120-frame runtime clean; `NAVPROBE_OK`. Worker suite: **25 passed**. Remaining for the gate: a human browser playthrough.

### Added — 2026-07-10 (P1 spine: enemies + analytical navmesh — full game loop)
- `engine/templates/ai/ai_patrol_chase.gd` — **fourth vetted template** (`AiPatrolChase`): deterministic square patrol around spawn (no RNG), chase when the player enters `detection_radius`, melee via the controller's `apply_damage` seam every `attack_interval`; `take_damage`/`died` for future combat; `@export`s mirror `entities.enemies[].stats` exactly.
- `services/worker/godot_client/navmesh.py` — **analytical NavigationMesh, no baking**: the walkable surface is emitted as explicit vertices/polygons from the same 0.5-unit floor rasterization the walls use (row strips, subdivided shared edges through a global corner pool, so every adjacent polygon connects). Build-time and deterministic — honors the "never bake at web runtime" rule and avoids fragile headless editor bakes. Tiers stay separate by design (enemies guard their tier; ramps carry only the player) — v0 limit.
- `services/worker/godot_client/project_writer.py` v0.6 — enemies become real `CharacterBody3D`s (AI script + capsule + `NavigationAgent3D`) with per-enemy stats from the spec (`enemy_configs`); `NavigationRegion3D` with the computed mesh emitted into every templated scene.
- `services/worker/tests/nav_probe.gd` — headless probe: loads the generated game, waits for nav-map sync, asks `NavigationServer3D` for a real path at every enemy and the player spawn. **Result on the golden-spec game: `NAVPROBE_OK enemies=5`.** 120-frame live-AI runtime clean; spec→WebGL2 export passes. Worker suite: **24 passed**.
- Known gap queued next: no lose flow yet (player `died` signal is unwired — needs the `player_death` fail-state template + HUD).

### Added — 2026-07-09 (P1 spine: physical lock-and-key — the core loop closes)
- `engine/templates/interactables/door_hinged.gd` — **third vetted template** (`DoorHinged`): hinge at the node origin (writer places it on the doorway edge), swings open on "interact" when in the `InteractZone`, `locked` + `unlocked_by_objective` exports, unlocks via the key objective's `objective_completed` signal, `locked_interaction` hook for UI hints. No randomness.
- `services/worker/godot_client/project_writer.py` v0.5 — emits the full **lock-and-key chain** in every generated game: `KeyZone` (reach_zone, `is_win_condition=false`) fills the key room; `LockedDoor` sits exactly where the locked corridor crosses the exit-room boundary (interpolated height on ramps); `WinZone` gains `requires_objective="reach_key"`; all wiring is **declarative scene `[connection]`s** (KeyZone → LockedDoor unlock, KeyZone → WinZone gate) — visible and editable in the Godot editor, nothing hardcoded.
- Generated gameplay loop now: spawn → explore → **reach the key room → locked door opens → escape through it → win** — the golden game's design, produced procedurally from any valid spec.
- **Verified live:** 120-frame headless run clean; spec→WebGL2 export passes. Worker suite: **21 passed** (incl. live export).

### Added — 2026-07-09 (P1 spine: walls + ramps — levels become spaces)
- `services/worker/godot_client/walls.py` — **wall generation via grid rasterization**: floors (rooms + corridor slabs) rasterize onto a 0.5-unit cell grid; a merged wall run lands on every floor/void boundary. Doorway gaps appear automatically wherever corridors overlap rooms — no special-case geometry. Pure Python, deterministic, unit-tested (perimeter merge, corridor-mouth gap, floor connectivity).
- `services/worker/godot_client/project_writer.py` v0.4 — emits the `Walls` StaticBody3D (per-run `Wall_001` mesh + collision) and turns the **final segment of tier-crossing corridors into a sloped ramp** (rotated slab with true incline collision) — without ramps, rooms on higher tiers were unreachable. Golden-spec game: 34 wall runs, 7 ramps.
- **Verified live:** import + 120-frame headless run clean; spec→WebGL2 export still passes. Worker suite: **17 passed** (incl. live export).
- v0 limits noted in-code: no cliff rails between floors of different tiers; ramp-adjacent walls sit at base elevation; the locked corridor has no physical door yet (`door_hinged` template is next).

### Added — 2026-07-09 (P1 spine: playable player — generated games now run)
- `engine/templates/controllers/controller_third_person.gd` — **second vetted template** (`ControllerThirdPerson`, clean-room, not adapted from the souls controller — that one is entangled with animation/equipment systems): CharacterBody3D movement (WASD relative to yaw, sprint, jump, gravity), mouse-look via SpringArm3D with pitch clamp, `@export` tunables mirroring `player.*` spec fields (`move_speed`, `health`), joins the `"player"` group in `_ready` so `reach_zone` detects it, `apply_damage`/`died` seam for combat templates. No randomness.
- `services/worker/godot_client/project_writer.py` v0.3 — emits a playable `Player` (controller script + capsule collision/mesh + `SpringArm3D`/`PlayerCamera`) at the entry room, applies `player_config` (the spec's `player` object) as node property overrides, writes the WASD/Space/Shift/E **input map** into `project.godot`, and hands camera `current` to the player (PreviewCamera stays current only in no-template mode).
- **Verified live:** generated game runs headless for 120 frames on 4.7-stable with zero script/runtime errors; full spec→WebGL2 export still passes. Worker suite: **12 passed** (incl. live export).
- `.gitignore` — `Templates/` anchored to `/Templates/`: the unanchored pattern was case-insensitively swallowing `engine/templates/` on Windows (new template files were silently unversioned).

### Added — 2026-07-09 (P1 spine: templates + web export — spec→build proven)
- `engine/templates/objectives/reach_zone.gd` — **first vetted template** (`ObjectiveReachZone`), promoted from the golden game's `win_zone.gd`: group-based player detection (no hard class dependency), `@export` tunables mirroring the spec's `objectives[]` fields (`objective_id`, `requires_objective`, `is_win_condition`), fires `objective_completed` once, optional win card. LLM never touches this file.
- `services/worker/godot_client/project_writer.py` — v0.2: optional `templates_dir` copies vetted scripts into `res://templates/` and attaches `reach_zone.gd` to a `WinZone` Area3D sized to the exit room; `load_steps` now counted exactly from emitted resources; `template_missing` error object.
- `services/worker/godot_client/exporter.py` — S7 entry: writes the vetted Web preset (single-threaded, VRAM compression off — the golden game's proven flags) and drives headless `--import` + `--export-release Web`; machine-readable `godot_export_failed` / `export_output_missing`.
- `services/worker/tests/test_exporter.py` — 4 tests incl. a live end-to-end (`GODOT_BIN`-gated, skips in CI): **frozen spec → PCG → level plan → Godot project → WebGL2 build, zero manual steps — passed locally on 4.7-stable; build = 38.0 MB of the 90 MB budget.** Worker suite: 9 passed + 1 live.

### Added — 2026-07-09 (P1 spine: Godot project writer — S6 step 1)
- `services/worker/godot_client/project_writer.py` — **level-plan JSON → editable Godot 4.7 project**: `project.godot` (GL Compatibility, main scene wired) + `main.tscn` with named PascalCase nodes only (`RoomZ00`+mesh+collision per room floor, `CorridorZ00Z01_Seg1` slabs, one `Marker3D` per placed entity like `CastleGuardShambler_01`, `PlayerSpawn` in the entry room, sun/environment/`PreviewCamera` so it renders standalone). Byte-stable output; `ProjectWriterError {code, path, message, hint}` on version mismatch. v0 = floors + markers (walls/ramps = the GridMap materialization step).
- **Verified against the real engine:** a project generated from the golden spec imports and its main scene loads in headless Godot `4.7-stable` with zero errors.
- `services/worker/pyproject.toml` (stdlib-only; pytest config) + `services/worker/tests/test_project_writer.py` — 6 tests: PascalCase naming, project file contents, scene structure vs plan (unique names, all SubResources defined, `load_steps` exact), byte-stability, marker positions, version-mismatch error. `.github/workflows/ci.yml` — new `worker` job runs the suite on every push/PR.

### Added — 2026-07-09 (P1 spine start: seeded zone-graph PCG)
- `services/brain/pcg/zone_graph.py` — seeded, deterministic zone-graph generator (S4 step 1): `room_corridor` algorithm; guaranteed connectivity; exactly one entry/exit + a `key` zone with a `locked` edge into the exit (the lock/key pattern from the golden game); machine-readable `PCGError {code, path, message, hint}` on bad input. Remaining algorithms (`bsp`, `cellular_caves`, `wfc_dressing`) intentionally raise `algorithm_not_implemented`.
- `services/brain/tests/test_zone_graph.py` — 5 tests: same-seed determinism, cross-seed divergence, connectivity across 100 seed/size combos, lock-and-key invariants, error-object shape.
- `services/brain/pcg/layout.py` — seeded 2D room/corridor layout (S4 step 2): BFS-orders the zone graph from `entry`, places each zone as a grid-aligned rect adjacent to an already-placed neighbor (collision-checked against every placed room, bounded retry with growing offset), derives elevation from `tier * floor_height`, and emits a straight/L-shaped corridor polyline per edge (locked corridors carry the source edge's `locked` kind). This is the direct input the Godot worker needs for GridMap materialization — pure Python, no engine dependency.
- `services/brain/tests/test_layout.py` — 6 tests: determinism, zero room-rect overlaps across 120 seed/size combos, room/corridor coverage matches the graph 1:1, elevation-by-tier, the locked corridor matches the locked edge, and a forced placement-budget-exhaustion path via monkeypatch.
- `services/brain/pcg/placement.py` — seeded entity placement (S4 step 3): rejection-samples every enemy/prop position inside its room rect (wall margin + min separation); enemies prefer `combat` zones, never spawn in entry/exit, and always keep the world-space safe-spawn distance from the entry room center; props route by `placement_tags` (`spawn` → entry, `loot` → loot zones, default → any non-exit). Seeds a distinct stream via `Random(f"{seed}:placement")` (sha512-based, cross-process stable). `placement_impossible` PCGError when a room can't host an entity.
- `services/brain/tests/test_placement.py` — 6 tests: determinism, instance counts + unique ids, in-room bounds across 20 seeds, safe-spawn + zone rules across 20 seeds, tag routing, machine-readable failure.
- `services/brain/pcg/pipeline.py` — `run_pcg(spec)`: the S4 entry point the project writer (S6) will call; reads `meta.seed` + `world.zone_graph.*` + `entities.*` from a schema-valid spec and runs graph → layout → placement.
- `services/brain/tests/test_pipeline.py` — integration tests that load the **real** `contracts/examples/golden_game.spec.json` and drive the full S4 chain (counts, connectivity, no overlaps, end-to-end determinism) — the contract and the code can no longer drift apart silently.
- `services/brain/pcg/zone_graph.py` — **`bsp` algorithm** (2nd of 4): branching tree via recursive bisection over zone indices (exactly N−1 edges, no loops — a genuinely different topology from `room_corridor`'s chain+loops); exit = deepest leaf from the entry, gated by its single locked edge with the key zone as its only neighbor; star-degeneracy guard re-attaches the exit under a middle zone so the key can never be the entry. `room_corridor` extracted to `_build_room_corridor` alongside `_build_bsp` (shared validation/dispatch).
- `services/brain/tests/test_zone_graph_bsp.py` — 5 tests: determinism, tree property + connectivity across 100 seed/size combos, lock-and-key invariants across 25 seeds, topology differs from `room_corridor`, and BSP graphs drive layout + placement end-to-end.
- `services/brain/pcg/serialize.py` — **level-plan serializer**: `to_level_plan(PCGOutput)` → the version-tagged (`level_plan_version` 1.0.0), snake_case JSON contract the Godot worker (`services/worker/godot_client/`) consumes for 3D materialization; `to_level_plan_json` is byte-stable (sorted keys, fixed separators) so plans hash for lineage like specs do.
- `services/brain/pcg/cli.py` — `python -m pcg.cli <spec.json>` → level-plan JSON on stdout; PCGError as JSON on stderr, exit 1. Smoke-tested against the golden spec.
- `services/brain/tests/test_serialize.py` — 3 tests: version + round-trip, byte-stability, internal reference consistency (rooms/corridors/entities all resolve to zones; exactly one locked corridor survives serialization). Suite: **35 passed**.

### Added — 2026-07-09 (Golden game build)
- **Golden game "Castle Gate Trial"** (`arena_combat_3d`, `third_person`) under `Templates/Cats-Godot4-Modular-Souls-like-Template-…/`, based on "Godot 4 Souls-Like Template" by Cat Prisbrey (Unlicense — logged in the licensing ledger). Runs on Godot 4.7-stable, GL Compatibility.
- `interactable objects/win_zone.gd` — `WinZone` Area3D win trigger (reach-zone objective; player-only via collision mask; shows win card with restart). Wired into `demo_level/world_castle.tscn` behind the lever-locked door — completes the lever → unlock → escape → **win** loop (template previously had no win condition). Becomes vetted template `objective_reach_zone` in P1.
- Web export preset (`export_presets.cfg`): Compatibility/WebGL2, **single-threaded**, VRAM texture compression **off** (unsupported on Godot web). Export: **77 MB uncompressed**, zero errors.

### Changed — 2026-07-09
- `contracts/examples/golden_game.spec.json` **rewritten to describe the game actually built** (was the unbuilt "Foggy Village Escape" plan): real enemy count (5), real stats (hp 5 / speed 3), real props (chests, doors, gate, lever, ladders), lever→reach_zone objective chain, build-hash lineage. Validates against the draft v2 schema.
- All 22 texture `.import` files: `compress/mode` 2 (VRAM) → 0 (Lossless) — VRAM-compressed textures fail to load on Godot web export.
- `docs/DECISION_LOG.md` — pending decision #6 (golden-game genre) resolved; `docs/licensing_ledger.csv` — souls-like-template row added (verified 2026-07-09).

### Fixed — 2026-07-09
- `assets/characters/skin_m.tres` — male skin material hardcoded `load_path` into `.godot/imported/*.s3tc.ctex` cache files (breaks on any reimport); now references source PNGs by UID like the sibling materials.

### Added — 2026-07-07
- Monorepo scaffold: full folder tree (`apps/`, `services/`, `engine/`, `contracts/`, `content/`, `eval/`, `infra/`, `scripts/`, `docs/`).
- `CLAUDE.md` — AI-assisted development rules (roles, hard rules, stack map, phases, git rules).
- Complete initial documentation set in `docs/` (overview, requirements, tech stack, architecture, interconnections, S0–S8 pipeline, DB schema design, API surface, design system, plans, testing/validation, deployment, security/privacy, licensing ledger + CSV, research notes, decision log, ADR-0001, 5 runbooks).
- `contracts/game_spec.schema.json` v2 **draft** + example spec + `scripts/validate_contracts.py`.
- `scripts/check_licenses.py` — licensing-ledger CI check.
- `docker-compose.yml` skeleton (FastAPI brain + pgvector Postgres + Redis, localhost-bound).
- Root `package.json` (npm workspaces) and `pyproject.toml` (ruff/pytest config).
- `.gitignore`, `.env.example` (no secrets policy).
- Setup scripts: `scripts/setup_local.ps1`, `scripts/setup_local.sh`.

### Added — 2026-07-07 (P0 completion pass)
- `docs/GOLDEN_GAME_PLAN.md` — golden-game concept, scope, web-export constraints, and the P0 gate checklist.
- `docs/SERVICE_SKELETONS.md` — Next.js frontend + FastAPI brain skeleton **plans** (scaffold commands, target structure, P0 acceptance).
- `.github/workflows/ci.yml` — CI skeleton: validate_contracts + check_licenses + ruff (non-blocking) + pytest; web-lint job auto-skips until `apps/web` exists.
- `infra/docker/brain.Dockerfile` (skeleton) + `infra/docker/README.md`.
- Initialized git repository; first commit under the user's identity.

### Changed — 2026-07-07
- `docker-compose.yml` — commented out the `brain` service for P0 so `docker compose up -d postgres redis` runs cleanly without a runnable app.
- Verified both validators pass: `validate_contracts.py` (schema + 2 examples) and `check_licenses.py` (no product-path violations).

### Added — 2026-07-07 (P0 Gate Completion Sprint)
- `docs/SCOPE_FREEZE_MEMO.md` — v1 scope, out-of-scope, 4 genres, 3 cameras, single-player/browser/≤90 MB targets, schema-freeze rule, team sign-off table.
- `docs/GOLDEN_GAME_TASKS.md` — build-ready task list (controller, enemy AI, objectives, level, props, HUD, audio, export/size/4-browser checklists, schema coverage map).

### Changed — 2026-07-07 (P0 Gate Completion Sprint)
- `CLAUDE.md` §13 — hardened to a strict no-commit/no-push rule (default HARD NO; explicit per-action permission with exact command required).
- `docs/IMPLEMENTATION_CHECKLIST.md` — added a Git safety callout at the top.
- `docs/runbooks/GODOT_BUILD.md` — expanded version-pinning plan (how to find the exact stable tag + matching Emscripten), toolchain install, Windows + Linux build commands, web-template output path, verification checklist.
- `contracts/game_spec.schema.json` — added a machine-visible `$comment` marking the schema DRAFT / not frozen until the golden game passes.
- Godot tag + Emscripten remain **unpinned** pending user approval to research/build; schema **not frozen** (still draft).

### Added / Changed — 2026-07-08 (P0 remainder: model pin + VPS infra)
- **Pinned planner `Qwen/Qwen3.6-27B`** (Apache-2.0, verified on the HF model card; dense 27B, vLLM + tool-call/guided-JSON, 262K ctx). One model covers planner + gated adapter-coder (replaces unconfirmed "Qwen3-Coder-14B"). Updated `licensing_ledger.csv`, `DECISION_LOG.md` (#2 resolved), `TECH_STACK.md`, `.env.example` (`LLM_PLANNER_MODEL`).
- **VPS + tunnel infra (execution-ready):** `infra/hetzner/{Caddyfile,README.md}`, `infra/cloudflare/{_headers,cloudflared-vps.example.yml,README.md}`, `services/brain/.dockerignore`, `scripts/verify_stack.sh` (one-command production-parity smoke).
- Validated `docker compose config` (env interpolation, service wiring) with a local gitignored `.env`.
- **Full Docker stack validated end-to-end** (Postgres + Redis + brain + separate Celery worker): POST → 202 → the worker consumed the task via real Redis and wrote DEPLOYED to real Postgres (0.1s) → GET DEPLOYED. Proves the production/VPS path, not just SQLite+eager.
- **Fixed `infra/docker/brain.Dockerfile`**: copy the service source before `pip install .` (the package needs `core/ worker/ api/` present) — caught by the stack build.
- **`docker-compose.yml`**: removed host port publishes for Postgres/Redis (reached only inside the compose network) — more secure and avoids clashing with a Postgres already installed on the host.
- Hardened `scripts/verify_stack.sh` health-wait (tolerant loop, up to 120s for first build).
- **Scope-freeze signed** (team-confirmed 2026-07-08); documented that **no cloud spend is needed until P3** (local Docker through P2) with free-tier options — see `DEPLOYMENT_PLAN.md`.

### Added — 2026-07-08 (frontend ↔ backend wired end-to-end — P0)
- Job-progress route `apps/web/app/jobs/[id]/page.tsx`: polls `GET /api/v1/jobs/{id}` every 1.5s until a terminal state (DEPLOYED/FAILED), friendly 404/network handling.
- `components/PhaseTimeline.tsx`: S0–S8 pipeline strip driven by job state (done/active/failed), reduced-motion aware.
- Home "Generate" now creates a real job and `router.push`es to `/jobs/{job_id}` (removed the placeholder success message).
- `lib/types.ts`: `JobStatus` gains `game_id` + `detail`; added `JOB_PIPELINE` + `TERMINAL_STATES`.
- **Verified end-to-end against a running brain** (SQLite + eager Celery, no Docker): health, 202 create, DEPLOYED job, 422/404 cases. `npm run build:web` passes (new `/jobs/[id]` dynamic route).

### Added — 2026-07-07 (FastAPI hello-job backend — P0, production-shaped)
- `services/brain/` FastAPI app: `POST /api/v1/games` → 202 `{game_id, job_id}` (creates games+jobs rows, enqueues Celery), `GET /api/v1/jobs/{id}`, `GET /healthz`.
- One sync SQLAlchemy 2.0 stack on **psycopg v3**; `core/` (config via pydantic-settings, db, models, schemas, ids), `worker/` (Celery app + `run_generation_job` hello task), `api/` routers.
- **Alembic** migration `0001_initial` (games, jobs) — verified runs cleanly.
- **8 tests pass** (SQLite + eager Celery — no Docker needed): health, id-format, full POST→job→GET round-trip, 422/404 cases.
- Wired `brain` + `celery` services into `docker-compose.yml`; real `infra/docker/brain.Dockerfile` (runs `alembic upgrade head` then uvicorn).
- CI: new `brain` job (Postgres + Redis service containers; `alembic upgrade head` on real Postgres + pytest). Root pytest scoped to `scripts` (brain has heavy deps + its own config).
- `.env.example` `DATABASE_URL` switched to `postgresql+psycopg` (single driver).

### Added — 2026-07-07 (Next.js frontend skeleton — P0)
- `apps/web/` Next.js 15 + TypeScript (App Router) skeleton: `package.json`, `tsconfig.json`, `next.config.mjs`, `next-env.d.ts`, `.eslintrc.json`.
- Home/prompt page (`app/page.tsx`) with genre/camera pickers (mirroring the schema allowlists), example-prompt chips, and full empty/loading/error/success states; root layout + theme-aware `globals.css` (light/dark).
- `lib/types.ts` (Genre/Camera/job types) + `lib/api.ts` (typed brain client) ready for the hello-job endpoint; `components/ExamplePromptChips.tsx`.
- Hand-written (folder pre-existed, so `create-next-app` was not usable).

### Changed — 2026-07-07 (Godot/Emscripten pin — user approved)
- Pinned **Godot `4.7-stable`** (latest stable, released 2026-06-18) + **Emscripten `4.0.11`** (verified from Godot's own `web_builds.yml` CI at the `4.7-stable` tag).
- Recorded in `.env.example` (`GODOT_PINNED_TAG`/`EMSCRIPTEN_VERSION`), `engine/serendib/upstream-notes.md`, `docs/runbooks/GODOT_BUILD.md` (values + verification method + resolved build commands), `docs/licensing_ledger.csv` (godot-engine row now verified), and `DECISION_LOG.md` (pending decision #1 resolved).
- `docs/GOLDEN_GAME_TASKS.md` + `IMPLEMENTATION_CHECKLIST.md` updated: golden game can start on the official 4.7 editor; source build is a P1/rebrand concern.
- Confirmed 4.7 still satisfies all constraints (WebGL2 Compatibility, single-threaded default, no C# web export, no Draco/VRAM-texture web compression).
