# Serendib — Master Plan (replan)

**Last replanned:** 2026-07-21 · **Supersedes:** ad-hoc phase notes in
`IMPLEMENTATION_PLAN.md`. Detailed evidence lives in
`SERENDIB_PRODUCTION_STATUS.md`; architecture decisions in `docs/adr/`.

**How to read this:** §2 is what the product is. §3 is what is **finished and
test-verified**. §4 is **everything still to do**, as checklists. §5 is the
technology stack. §6–§9 are the rules, risks and decisions you must know to work
on this safely.

---

## 1. One-paragraph summary

Serendib turns a natural-language prompt into a **verified, executable 3D
simulation** — not only games. A multi-agent brain plans a neutral
`SimulationSpec`; deterministic, seeded code compiles it into a Serendib (Godot
fork) world; layered validators and bots prove it actually works; the user gets a
browser build **and** an editable engine project. A consent-qualified learning
loop improves the planner and rankers from opted-in user data only.

---

## 2. Product decisions (frozen)

| Decision | Value |
|---|---|
| Scope | General **simulations**, not game-only |
| World size | Small ≤ 0.25 km², Medium ≤ 1 km² |
| Artifacts | Browser **and** desktop, from one canonical world |
| Physics | Plausible real-time |
| Output policy | Final **verified** outputs only; no unfinished user-facing previews |
| Authoring | No-code + developer APIs + capability SDK |
| Audience | Global, 13+ (under-13 blocked) |
| Initial capacity | 1,000 active users, ~100 concurrent jobs |
| Training on user data | **Off by default**, explicit opt-in; teens need teen + guardian consent |
| Runtime | Deterministic; **never** calls an LLM at runtime |

**Canonical API:** `/api/v1/simulations`. `/api/v1/games` is a **deprecated
adapter only**.

---

## 3. FINISHED — implemented and test-verified

> Verified locally 2026-07-21: full brain + worker suites passed (4 worker tests
> skipped needing optional external tools); contracts compiled; targeted Ruff
> clean; licence policy passed.

### 3.1 Core simulation pipeline
- [x] `/api/v1/simulations` is canonical — compiles `SimulationSpec` directly (no
      legacy `Game`/`Job`, no golden-castle corrections, no template game writer)
- [x] Neutral `SimulationSpec` contract (550-line schema) + requirement contracts
      + traceability
- [x] CPU planning and build are **separate persisted Celery stages** (planning
      stores the immutable spec before the independently retryable build)
- [x] `POST /simulations/{id}/revalidate` — quota-governed, auditable re-runs
      against the same immutable spec; historical evidence never rewritten
- [x] Seeded **semantic PCG**: transformed measured bounds, support, containment,
      clearance, composite hierarchy, approach zones, localized typed repair —
      hard constraints never silently relax
- [x] Reviewed **capability-state interpreters** for observable interaction state;
      no agent can inject executable scripts into a production world
- [x] Capability packs: `core_runtime`, `objects_and_machines`,
      `agents_and_processes`

### 3.2 Assets
- [x] Neutral asset resolver — canonical entity IDs, semantic selection, measured
      descriptors, real generation backends when configured
- [x] **Fail-truthfully**: missing structures/vehicles are recorded `unresolved`,
      never disguised as a barrel/unrelated proxy
- [x] Generated concepts pass deterministic alpha/component checks **and** a
      schema-bound vision critic before 3D lifting; rejects removed from state
- [x] Content-addressed procedural assets: measured semantic boxes, pitched
      building shells with **real doorway voids**, independent **hinged door
      leaves** (capability geometry, not scene templates)
- [x] Real generation stack verified on RTX 5090: SDXL → rembg → TripoSR →
      decimate → GLB, QA-gated
- [x] **GPU stage sequencing** — planner unloaded before generation; SDXL/TripoSR
      released after, preventing cross-stage VRAM starvation

### 3.3 Runtime, engine, export
- [x] Native Serendib projects contain canonical spec, world plan, fixed runtime,
      navigation probes, render capture, desktop/web exports, neutral Assist plugin
- [x] Fixed runtime: synchronous nav baking, controlled + autonomous locomotion,
      state-dependent door collision, interaction probes, machine-readable traces
- [x] Browser builds expose the same trace via a fixed, non-generated DOM bridge
- [x] Serendib Assist submits edits to the canonical API (never writes an
      unverified local spec)

### 3.4 Verification
- [x] Validators report `PASS` / `FAIL` / `NOT_RUN` / `UNAVAILABLE`; **every
      non-PASS mandatory result blocks publication**
- [x] One authoritative **18-layer** release contract; missing evidence row =
      `NOT_RUN`; the public artifact API independently requires the same set
- [x] Independent text critic and visual critic with schema-bound responses;
      deterministic evidence stays authoritative
- [x] **Canonical run proven:** `run_0a7fbd3644f8487987253c1fd6902160` — all 18
      mandatory layers `PASS`, gated Web build + editable archive published
      (1,549,182 B), 41.6 MB Web export ran in Chrome with a passing trace,
      native/Web parity passed
- [x] Windows desktop export **failed truthfully** (templates absent) — correct
      behaviour, not a silent pass

### 3.5 Identity, privacy, governance (repo side)
- [x] Identity, tenant ownership, quotas, audit, OIDC/JWKS, guardian
      relationships, privacy APIs, PostgreSQL **RLS** migrations
- [x] Training **ineligible by default**; dataset construction/export fail closed
      across consent, guardian consent, rights, moderation, tenant scope, deletion
      tombstones, research exclusions, final validator evidence
- [x] Governed planner training accepts only neutral `SimulationSpec` rows with an
      immutable manifest; legacy game data needs a research-only flag production
      never sets
- [x] Model promotion requires **signed immutable `ModelEvaluation`** evidence —
      admins cannot type passing metrics
- [x] Tenant-private/global routing, deterministic 5%/25% canaries, rollback,
      real planner routing; rankers load from digest-verified JSON and can only
      order hard-valid candidates
- [x] Streaming **AES-GCM** envelope encryption with managed KMS data keys;
      plaintext training constrained to tmpfs
- [x] Withdrawal removes dataset copies, writes tombstones, disables deployments,
      quarantines models

### 3.6 Packaging / infra scaffolding
- [x] Python wheels contain every runtime package
- [x] Separate API, engine-worker, governed GPU-training Dockerfiles
- [x] Kubernetes worker/KEDA templates
- [x] Serendib identity assets, upstream patch series, legal attribution checks,
      runtime splash/icon/browser checks, neutral editor plugin

### 3.7 Legacy `/games` track (⚠️ deprecated — see §7.1)
Built and green, but on the **deprecated** path:
- [x] Character resolution — a stated character never renders as a capsule
- [x] Composable interactive objects (ADR-0008): sockets, affordance parts,
      affordance oracle gate (car/house doors open, bot-verified)
- [x] Outdoor worlds (`world.kind`): open ground + mountain ring, ground navmesh,
      flat enforcement, bot-playable
- [x] Procedural triplanar surface texturing (indoor + outdoor)
- [x] Corner-torch dressing; real in-process generation backend

---

## 4. REMAINING — full task checklist

### Phase A — Consolidation (do first, ~1–2 days) 🔴
- [ ] Decide: **delete** `/games` or hard-freeze it (adapter only, no new features)
- [ ] Remove `games.router` from the default app once the adapter window closes
- [ ] Port worthwhile legacy fixes onto the canonical path (decide per item):
  - [ ] Character fallback policy — **resolve the conflict in §7.2 first**
  - [ ] Retire duplicate composite/door machinery in favour of capability geometry
  - [ ] Confirm outdoor/terrain + texturing equivalents exist canonically
- [ ] Delete or quarantine now-duplicate modules so no third path can appear
- [ ] Lock §8 golden acceptance test as the always-green gate

### Phase B — Pipeline hardening (repo work still remaining)
- [ ] Split asset generation, engine compilation and validation into **separate
      persisted queue stages** (today they share the build task + retry boundary)
- [ ] Durable **stage-artifact exchange** (private object storage + hashes)
      instead of a shared worker volume
- [ ] Automated **shadow inference comparison** (duplicate requests async)
- [ ] Automated **canary metric aggregation + timed rollback**
- [ ] Approved **decrypt-to-tmpfs** deployment component for encrypted rankers /
      enterprise adapters
- [ ] **Deadline scheduler** that retrains/retires quarantined derivatives inside
      the deletion window
- [ ] Expand capability packs beyond the initial primitives as domains are chosen

### Phase C — Assets & domains
- [ ] License/supply a real asset library: buildings, vehicles, machines, **rigged
      characters + animations**
- [ ] Configure and capacity-test the approved 3D generation backend
- [ ] Generate **+ rig** arbitrary characters (UniRig) so any prompt subject
      becomes an animated body *(explicitly scheduled last)*
- [ ] Real image/PBR textures (beyond the current procedural baseline)

### Phase D — Models
- [ ] Choose and deploy **independent** planner, critic and vision models
      (critic/vision must not silently share the planner artifact)
- [ ] Record exact licences + immutable digests; provide endpoints
- [ ] Run the frozen semantic benchmark
- [ ] Reduce planner latency (a live schema-valid Qwen call took **238 s** locally)

### Phase E — Engine (Serendib)
- [ ] Build the **pinned upstream engine + Serendib patch series** and matching
      web/desktop export templates
- [ ] Supply `GODOT_BIN` / `SERENDIB_BIN_HOST_PATH`
- [ ] Engine launch, screenshot, export and parity qualification on
      Windows/Linux + target browsers
- [ ] Install **desktop export templates** (currently only Web is installed)
- [ ] Screenshot checks that catch accidental visible Godot branding

### Phase F — Cloud & production operations
- [ ] Choose cloud regions, managed PostgreSQL/Redis, private object storage,
      managed KMS, OIDC provider
- [ ] Secrets outside Git; replace every image placeholder with a **signed digest**
- [ ] Region-specific Terraform/Helm overlays
- [ ] Autoscaled GPU workers with per-tenant quotas and time/VRAM/cost ceilings
- [ ] Observability: run/tenant/correlation IDs, queue depth, model latency/cost,
      GPU use, validator availability, consent counters
- [ ] Backups + PITR; **RPO 15 min / RTO 4 h**; quarterly restore + DR exercises
- [ ] On-call owners, severities, alert destinations, cost limits, model owners

### Phase G — Security & compliance gates
- [ ] KMS keys; `/run/serendib-training` mounted **tmpfs**; GPU training image
      from a signed CUDA/PyTorch base; verify exact base-model licence
- [ ] PostgreSQL **non-owner RLS** tests
- [ ] Cross-tenant API/DB/storage isolation tests
- [ ] 100-concurrent-job load + fairness tests
- [ ] SBOM + signature verification
- [ ] External **penetration test**, no open critical findings
- [ ] Breach, rollback and unavailable-validator exercises
- [ ] Close the 8 ledger components missing primary-source verification dates

### Phase H — Learning loop (consent-qualified)
- [ ] Collect ≥ 500 eligible high-quality examples (or approve monthly window)
- [ ] Train planner + asset/placement rankers
- [ ] Privacy **memorization / PII-extraction / tenant-leakage** tests
- [ ] Frozen evaluation → shadow → 5% canary → 25% canary → rollback exercise
- [ ] Keep continuous learning **manually approved** (no uncontrolled online loop)

### Phase I — Governance & legal (before public data collection)
- [ ] DPIA
- [ ] Child-safety / age-assurance assessment
- [ ] Data-transfer + retention review
- [ ] Copyright and trademark review
- [ ] Regional counsel sign-off per launch region
- [ ] Child-readable + adult privacy notices
- [ ] AI-generated labelling + machine-readable provenance
- [ ] Rights-complaint and asset-takedown operations

### Phase J — Research & launch
- [ ] Freeze research models + benchmark prompts
- [ ] Run the 48-person mixed-expertise counterbalanced user study
- [ ] Ablations: untuned · synthetic-tuned · user-data-tuned · combined · global
      vs enterprise adapter (user/tenant/time-disjoint splits)
- [ ] Report: executable semantic correctness, ranking quality, build/interaction
      success, latency/cost, memorization + PII probes, repair rate, cross-domain
      generalization
- [ ] Launch only after engineering, child-safety, privacy and model gates pass

---

## 5. Technology stack

### Brain / API
| Concern | Technology |
|---|---|
| API | **FastAPI** ≥0.110, Pydantic v2 + pydantic-settings |
| Jobs | **Celery** ≥5.3 + **Redis** ≥5 (separate CPU-plan / build / GPU queues) |
| Database | **PostgreSQL** + **pgvector**, SQLAlchemy 2, Alembic, psycopg3 |
| Contracts | **JSON Schema 2020-12** (`jsonschema` ≥4.21) |
| HTTP clients | httpx |
| Crypto | `cryptography` ≥43 — **AES-GCM** envelope encryption + managed KMS |
| AuthN/Z | **OIDC/JWKS**, short-lived tokens, MFA for admins, PostgreSQL **RLS** |

### AI / models
| Role | Technology |
|---|---|
| Planner | **Qwen3.6:27B** via **Ollama**, schema-bound guided JSON |
| Critic / vision | Independently routed models (must not share the planner artifact) |
| Model router | Provider-independent registry: modality, context, structured-output reliability, licence, region, cost, latency, digest |
| RAG | **bge-m3** embeddings over **pgvector** |
| Fine-tuning | **QLoRA** (unsloth / trl / peft), GGUF export, governed datasets |

### Asset generation
| Stage | Technology | Licence |
|---|---|---|
| Text→image | **SDXL base** (diffusers) | OpenRAIL++-M |
| Background removal | **rembg / u2net** | Apache-2.0 |
| Image→3D | **TripoSR** (vendored, PyMCubes-patched — no compiler needed) | MIT |
| Mesh ops | trimesh, PyMCubes, fast-simplification | BSD/MIT |
| Alt GPU path | ComfyUI + TRELLIS (WSL2) + Blender headless | MIT / GPL tooling |

### Engine & client
| Concern | Technology |
|---|---|
| Engine | **Serendib** — pinned **Godot 4.x** fork, patch series, visually rebranded |
| Rendering | **GL Compatibility / WebGL2**, ≤90 MB web budget |
| Runtime | Vetted **GDScript** capability templates (never AI-authored) |
| Web app | **Next.js** + TypeScript (`apps/web`) |
| Validation bots | Headless Godot, state-reading (never vision) |

### Infrastructure
Docker · **Kubernetes + KEDA** · Cloudflare (DNS/WAF/CDN) · regional object
storage · Hetzner (dev) · local **RTX 5090** workstation (development + governed
training only, never a public-production dependency).

### Quality
**pytest** · **Ruff** · JSON-Schema contract validation · licence ledger checker
(`scripts/check_licenses.py`) · 18-layer release contract.

---

## 6. Repository map

```
contracts/     simulation_spec, asset_descriptor, capability_pack, world_plan,
               behavior_plan, world_patch  (+ legacy game_spec)
capabilities/  capability packs (core_runtime, objects_and_machines,
               agents_and_processes)
services/brain api/ (simulations, privacy, learning, feedback, registries…)
               agents/ (requirements, spec, capability, asset, PCG, behaviour,
               critic, verification, repair) · worker/ (simulation_tasks,
               native_pipeline, learning_tasks, privacy_tasks)
services/worker asset_farm/ (resolver, backends, QA) · godot_client/
               (simulation_project_writer = canonical, project_writer = legacy)
               · bots/ (greedy bot, affordance check, probes)
engine/        serendib/ (patches, branding, Assist plugin) · templates/ (vetted
               GDScript capability templates)
eval/          benchmark_prompts, ablation_runners, metrics, training, showcase
infra/         docker, kubernetes (KEDA), cloudflare, hetzner, github-actions
apps/web       Next.js client
docs/          ADRs, this plan, SERENDIB_PRODUCTION_STATUS, runbooks, licensing
```

---

## 7. Open decisions you must make

### 7.1 🔴 Two live tracks (highest risk)
`/games` **and** `/simulations` are both routed. Two writers
(`project_writer` vs `simulation_project_writer`), two resolvers
(`resolve_spec_assets` vs `resolve_simulation_assets`). Recent legacy-path work
(character fallback, composites, outdoor, texturing) does **not** automatically
apply to the canonical path. **Decide and execute Phase A** — a
"deprecated but still routed" path keeps attracting new work.

### 7.2 🔴 Proxy substitution vs fail-truthfully
- Canonical rule: unresolved asset → recorded `unresolved`, mandatory gate
  **fails**; never a disguised proxy.
- Legacy behaviour: substitute the nearest-kind body so a player is never a capsule.

These are opposite. **Recommended resolution:** keep fail-closed for *evidence*;
allow a **labelled proxy** only when the requirement's observable success
condition does not depend on identity, recorded as an approximation. Never silent.

### 7.3 Scope split — thesis vs SaaS
- **Thesis-critical:** Phases A, B, C(assets), D(models), H(learning), J(study).
- **Deferrable past the study:** F (cloud ops), G (pen-test/scale), most of I
  beyond the DPIA needed before collecting user data.

### 7.4 World size ambition
1 km² with a ≤90 MB WebGL2 budget is a genuine streaming/LOD problem. Prove
**0.25 km² end-to-end first**; make 1 km² desktop-only or contingent on an
explicit LOD/streaming design.

---

## 8. Golden acceptance test (must stay green)

> **"A dog explores a village"** — with **no game template**: a real, animated dog
> model; correctly scaled village and structures; prompt-relevant interactions
> that change runtime state; valid placement + approach zones; desktop/browser
> logical parity; **no hard-coded golden-scene logic**.

Plus learning correctness (zero non-consented / teen-unconsented / tenant-private
examples; deletions cannot be reintroduced; splits prevent leakage) and production
correctness (no cross-tenant access; all mandatory validators execute; backups
restore; SLOs hold at 100 concurrent jobs).

---

## 9. Invariants — never break these

1. **No agent output bypasses** schema validation, deterministic compilation or
   deployment gates.
2. **No LLM at runtime.** Behaviour comes from vetted templates/capabilities; the
   model *selects and parameterises*, never authors executable gameplay code.
3. **Validators fail truthfully.** `NOT_RUN` / `UNAVAILABLE` block completion. A
   missing evidence row is `NOT_RUN`.
4. **Hard constraints never silently relax.** Soft relaxations are recorded
   approximations.
5. **Training is ineligible by default.** Every item needs consent + rights +
   moderation + tenant policy + no deletion conflict; the query **fails closed**.
6. **Benchmark and user-study prompts never enter training** used to evaluate the
   same claims.
7. **Licence before use.** Every model/asset/tool is ledgered and re-verified
   (`docs/licensing_ledger.csv`).
8. **Seed everything** — any randomness reproducible from the recorded seed.
9. **Full lineage** on every artifact: prompt, seed, model digests, spec hash,
   capability versions, asset hashes, build hash.
10. **Never ship the Godot name/logo** as product identity; keep MIT notices +
    "based on Godot Engine" + non-affiliation.

---

## 10. Recommended next action

Execute **Phase A (consolidation)**, then lock §8 as the standing gate, then
proceed Phase B → C → D. Defer F/G until after the user study unless a public
launch precedes it.
