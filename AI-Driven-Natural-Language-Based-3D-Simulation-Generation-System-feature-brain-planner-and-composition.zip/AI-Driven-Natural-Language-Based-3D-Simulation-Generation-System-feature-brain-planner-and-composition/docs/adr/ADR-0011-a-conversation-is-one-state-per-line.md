# ADR-0011 — A conversation is one state per line

**Status:** accepted · **Date:** 2026-08-19 · **Phase:** P4

## Context

`dialogue` was the last capability in the schema enum with `runtime_binding:
null` and the flat limitation "a deterministic dialogue state-machine pack is not
installed". A prompt could name a guard, a guide or a shopkeeper, the planner
could declare the capability, and behaviour compilation would fail the run.

Every other capability in `services/brain/behaviors/compiler.py` is a fixed entry
in the `_TEMPLATES` table: `openable` has two states whatever door it is on,
`vehicle` has three whatever the vehicle. Dialogue does not fit that shape. A
conversation has as many steps as it has lines, and the lines belong to the
entity, not to the capability — two people in the same world must be able to say
different things.

There was also nowhere to author the words. `$defs/entity` in
`contracts/simulation_spec.schema.json` is `additionalProperties: false` and had
no dialogue field, so the capability could be declared and carry no content at
all.

## Decision

**Each authored line becomes its own compiled state, and the line's text travels
in that state's `observable_properties`.**

```
idle        speaking=false  line=""                       line_index=-1
speaking_0  speaking=true   line="Mind the platform edge."  line_index=0
speaking_1  speaking=true   line="Trains run every ten…"    line_index=1

idle --talk--> speaking_0 --talk--> speaking_1 --talk--> idle
every speaking_i --end--> idle
```

The graph is built per entity by `dialogue_template(lines)` rather than looked up
by capability id. Lines are capped at six; the runtime reads a string it is handed
and does no indexing of its own.

## Alternatives considered

**A two-state `idle`/`speaking` graph with the runtime holding the line array.**
Rejected. The graph would then report `speaking` correctly while the runtime
decided which words a visitor actually reads, and no probe could reach that
decision. `runtime_interactions` asserts observable state; a runtime that owns the
line list could display anything at all and still pass. Keeping the text in the
state means a probe can assert the exact sentence a visitor gets, which is the
same reason every other capability asserts properties rather than appearance.

**Generating the lines at runtime from the entity's name or semantic type.**
Rejected: that fabricates content and presents it as authored.

**Leaving `dialogue` unavailable.** Rejected on the evidence — it is one of the
most common things a prompt asks for in an inhabited place, and the pack was the
only thing missing, not the mechanism.

## Consequences

- `entity.dialogue` is a new optional array in the canonical contract (1–6
  strings, ≤200 characters each). No existing spec is affected, since none has
  the field.
- It is **required only when the capability is present**, which makes it the
  third conditionally-required rule that `ollama_simulation_schema()` hides from
  the model when it strips `allOf`/`if`/`then` for the grammar adapter. Like the
  other two it is handled by a normalisation: `_normalise_dialogue` in the
  planner. Nothing there can invent a line, so a speaker with no lines **loses
  the capability and survives as scenery**, disclosed as a user-visible
  approximation. Shipping a person who does nothing when spoken to reads worse
  than one who was never offered a conversation. The top-level capability list
  drops `dialogue` with the last speaker, or `capability_declaration` fails on a
  capability no entity holds.
- Over-long lines are trimmed rather than rejected. The canonical schema caps a
  line at 200 characters and would otherwise throw out the whole spec over one
  talkative sentence, dropping the run to the deterministic fallback.
- A lineless graph reaching the compiler is reported as
  `DIALOGUE_LINES_MISSING`, not raised. Hand-written specs and edit round-trips
  do not pass through the planner normalisation, and a traceback would take the
  run down over one entity while telling the repair loop nothing.
- `simulation_project_writer.py` emits a `DialogueLine` `Label3D` per speaker,
  billboarded above the body and hidden at rest. It is authored into the scene
  rather than created by the runtime script so that whoever opens the downloaded
  project finds a node they can restyle — a label conjured at load is invisible
  in the editor, which defeats the point of an editable export.
- State count grows with lines, bounded at six. Transition ids stay unique
  because they encode from-state, trigger and to-state.

## Status of the capability

**Partial.** The conversation is linear: no choices, no branches, no replies from
the visitor, and nothing said can change the world — talking to the guard will not
unlock the gate they are warning you about. Lines are text on a billboarded
label; there is no voice.

## Verification

Probed in Serendib headless against the real compiled graph
(`capability_state_machine.gd` + an authored `DialogueLine`):

| Check | Result |
|---|---|
| At rest | `idle`, label hidden, text empty |
| Three interact presses | `speaking_0/1/2` with the exact authored lines, label visible |
| Fourth press at the last line | back to `idle`, label hidden |
| Pressing again | reopens at `speaking_0` with the first line |
| `end` from `speaking_1` | `idle`, label hidden |

Unit coverage in `services/brain/tests/test_behavior_compiler.py` (per-line states
and their text, two speakers holding different conversations, the lineless
speaker degrading to scenery, trimming, and the error object) and
`services/worker/tests/test_simulation_project_writer.py` (the label is in the
scene tree, off at rest, and the text is not duplicated into it).
