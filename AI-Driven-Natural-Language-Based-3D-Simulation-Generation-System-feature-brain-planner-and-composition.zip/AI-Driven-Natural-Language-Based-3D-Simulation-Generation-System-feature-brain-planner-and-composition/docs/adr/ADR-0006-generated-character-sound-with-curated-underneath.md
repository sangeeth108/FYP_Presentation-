# ADR-0006 — Generated per-character sound, with the curated set underneath

- **Status:** Accepted — user-directed (2026-07-17): *"sound also want to generate for those"*, as a system rather than a special case.
- **Date:** 2026-07-17
- **Deciders:** User (direction), Claude (implementation)
- **Amends:** **ADR-0004**, which decided "curated over generated for activity sound". That decision is narrowed here, not reversed — see below.
- **Relates to:** ADR-0005 (the player has a body), CLAUDE.md §3 rule 15, §7 S5, §14

## Context — why this is not a reversal of ADR-0004

ADR-0004 rejected generation for activity sound with a specific argument:

> the sounds needed are a small, closed, knowable set (a strike, an impact,
> bones, a footstep) that must be tightly synchronised with a specific state
> transition. Generation there buys unpredictability, VRAM contention, QA risk
> and licence surface, and buys it for content we already own outright.

Every word of that held **while every character was a curated KayKit skeleton.**
The set was closed because the *cast* was closed.

ADR-0005 opened the cast. Once the planner can say the character is "a snarling
low-poly village dog", the sound set is no longer closed and we no longer own it
outright: there is no curated dog. The skeleton's `clack` is not a dog — playing
it is precisely the mismatch ADR-0004 exists to prevent ("what you hear must
match what you see"). So the *same principle* now points the other way, and
ADR-0004's own escape clause already anticipated it: Stable Audio keeps the S5
seam "for what curation genuinely cannot cover".

An arbitrary character is what curation cannot cover.

## Decision

**The character's own voice wins; the curated family set is the floor.**

1. **Sound briefs are derived, not authored.** The planner decides *who* the
   character is (one field, ADR-0005). What that character sounds like when it
   strikes, flinches, dies or steps is a deterministic function of identity ×
   activity (`sound_brief.py`) — no second LLM call, no per-clip prompting, and
   reproducible from the spec alone (rule 15: ambiguity up, determinism down;
   rule 14: seed everything). The same character+activity always hashes the same,
   so a rebuild hits the cache instead of re-spending GPU minutes.
2. **The activities are the same four the AI template performs** (ADR-0004), so
   the curated tier and the generate tier answer the identical question. A test
   pins `SOUND_SETS` and `ACTIVITY_PHRASE` to the same key set, so adding an
   activity cannot silently leave one tier behind.
3. **Sound is gated exactly like a mesh.** `qa_audio` judges every produced clip
   before it can ship — curated content is not trusted more than generated
   content, and generated content is not trusted at all until it passes. This is
   why the resolver stopped excluding audio: the exclusion only ever existed
   because the QA step could not judge a WAV.
4. **Mesh and sound are separate backends and separate switches**
   (`ASSET_GEN_ENABLED` / `AUDIO_GEN_ENABLED`). TRELLIS and Stable Audio cannot
   be co-resident in 32 GB (§4), so they are enabled, sequenced and failed
   independently. "Curated animated models + unique generated voices" is a real,
   supported, and currently *recommended* combination.
5. **Per-activity fallback, not per-character.** If only the death clip is
   produced, the other three still play the curated bank. A half-working
   generator must never leave a character with a silent attack.

## Consequences

**Good**
- A described character sounds like itself. The dog barks; it does not rattle.
- Nothing can get quieter by trying: every failure path — generator off, host
  down, backend crash, clip flunks QA, clip too long — lands on the curated set
  that ships today. Four tests pin exactly those paths.
- Cheap where it counts: a generated character with all four clips ships **4
  WAVs instead of 13** curated ones, because it no longer needs the shared bank.
- The seam is honest about direction: `StableAudioBackend` refuses a mesh brief
  before making any HTTP call, so a mis-wired caller fails instantly rather than
  after a 300s timeout.

**Bad / accepted**
- **The Stable Audio ComfyUI contract is unverified against a live install.** The
  checkpoint name and node graph are written from the documented example
  workflow, and `MockAudioBackend` — a real WAV writer — is what the tests and
  the verified end-to-end run use. This is the same position `backends_gpu.py`
  was in before its SDXL graph was smoke-tested on the 5090, and it is flagged in
  the module docstring as the first thing to check when enabling it for real.
- Licence surface grows by one component: Stable Audio Open (Stability AI
  Community License, free commercially below $1M/yr revenue). Ledger row verified
  2026-07-14; product-safe for a pre-revenue project, and the license guard
  enforces it before a sample is generated. **Revisit if revenue crosses $1M.**
- Generated clips are one variant per activity where curated banks hold 3–4, so a
  generated character repeats itself more. Seeded variety across *enemies* still
  works (each picks from its bank); variety *within* a bank would cost N× the
  generation time. Accepted for now.

**Explicitly NOT decided here**
- Ambience / music (`audio.cue_sheet` exists in the schema for exactly this and
  remains unused).
- Rigging. Sound made the dog audible; it is still a statue. That remains the one
  blocker between "the character is a dog" and a dog that runs.
