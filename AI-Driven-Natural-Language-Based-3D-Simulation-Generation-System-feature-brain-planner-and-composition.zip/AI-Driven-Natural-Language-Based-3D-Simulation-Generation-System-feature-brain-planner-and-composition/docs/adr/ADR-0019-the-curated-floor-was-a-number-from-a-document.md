# ADR-0019 — The curated floor was a number from a document

- **Status:** Accepted
- **Date:** 2026-08-21
- **Phase:** P4
- **Addresses:** `docs/VILLAGE_GAP_ANALYSIS.md` §3.6, priority #9

## Context

`CURATED_FLOOR = 0.85` came from the pipeline specification document. It was never
measured against bge-m3, the model that has to clear it. A comment in `pipeline.py`
already recorded the suspicion — *"the embedding floor of 0.85 is unreachable (0.548 at
best for a person's brief)"* — and the report has been describing a tier that cannot fire.

Measured against the planner's **own** briefs, recovered from
`artifacts/debug/*/01_simulation_spec.json` so the sample is not text chosen to make the
numbers look good:

- the highest score **any** real brief achieved was **0.775**
- the median was **0.59**
- 31 briefs, 27 of which have no right answer in the library at all

So the tier never fired, and everything was being dressed by the keyword tier or by
`_unused_human`.

## The deeper problem: what was being embedded

Recalibrating alone would have been the wrong fix. The briefs are mostly pipeline
boilerplate — *"an animated, rigged dog suitable as the controlled simulation agent"* is
nine words of plumbing around one word of content, and the plumbing dominates the vector.

Measured on real specs, embedding the brief versus embedding the entity's own
`semantic_type`:

| subject | brief → pick | subject → pick |
|---|---|---|
| `dog` | 0.566 → **Alpaca** | 0.651 → **Husky** |
| `museum_visitor` | 0.573 → **Skeleton_Rogue** | 0.661 → **Man** |
| `visitor` | 0.573 → **Skeleton_Rogue** | 0.709 → **Man** |

Three of three went from badly wrong to right. A museum visitor arriving as a skeleton
rogue is exactly the class of defect that shows up in a render and nowhere else.

The phrasing is not decoration either: a bare noun scores lower than the same noun in a
phrase (`dog` 0.623, `a dog` 0.651), because the library's descriptions are phrases. And
underscores must become spaces — `museum_visitor` is not a word bge-m3 has seen.

## Decision

**Embed the subject, not the brief.** `best_curated` takes the entity's `semantic_type`
and embeds `"a {subject}"`, falling back to the brief when there is no subject so every
existing caller keeps working.

**Floors are measured, per category, and the numbers are in the code.**

| category | positives | negatives | verdict |
|---|---|---|---|
| prop | 0.758–0.914 | 0.539–0.646 | **separable**, gap +0.112 → floor **0.70** |
| character | 0.651–0.806 | 0.516–0.657 | overlap −0.006 → floor **0.64** |

Props separate cleanly, so 0.70 sits in the middle of the gap. Characters overlap on one
adversarial case — *"a medieval knight in plate armour on horseback"* scoring 0.657
against **Horse**, which is not really wrong — so 0.64 admits every genuine positive and
accepts that one documented false positive.

**The two differ because a rejection costs different things.** A character that does not
match falls back to a blue capsule or a blind index cycle, so a plausible body beats no
body. A prop that does not match now falls back to a procedural form with a planned
palette (ADR-0015), which already looks right, so only a confident match should override
it. An uncalibrated category gets the stricter default, because no evidence should mean
more convincing rather than less.

## What was NOT changed, and why

The **cache floor stays at 0.92**. Priority #9 said "the embedding floors", plural, so it
was measured too — and it is correctly calibrated. It asks a different question
(brief-to-brief near-duplication, not brief-to-library-description), and across 820 real
brief pairs exactly **8** clear 0.92, every one of them a genuine near-duplicate such as
*"a simple wooden bench for visitors to rest"* against *"…to sit on"*. Nothing spurious
gets through. Changing a floor that measurement vindicates would have been change for its
own sake.

## Consequences

- The curated tier can fire, which is the tier the S5 ladder describes and which returns
  a rigged, animated, licence-clear model instantly where generation costs GPU minutes
  and arrives as a statue.
- The live calibration is pinned by a test that talks to the real model and **skips** when
  no embedder is present, rather than being deleted. These numbers are measurements: a
  model update or an edit to the library's descriptions moves them, and a calibration
  nothing can re-check is a number nobody can trust.
- One existing test asserted `CURATED_FLOOR == 0.85` — "the floor is the pipeline spec
  value". That was true and it was the defect: it pinned provenance rather than fitness.
- Still open: the library is 29 models, so most briefs in most worlds genuinely have no
  right answer in it and correctly fall through. The floors decide the boundary; they do
  not enlarge the library.
