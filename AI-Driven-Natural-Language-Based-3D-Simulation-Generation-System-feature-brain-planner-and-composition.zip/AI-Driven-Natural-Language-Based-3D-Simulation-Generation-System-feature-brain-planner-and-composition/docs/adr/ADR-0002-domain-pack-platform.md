# ADR-0002 — Domain-pack platform (beyond games) + user-data training posture

- **Status:** Accepted — all 4 team members agreed (user-confirmed 2026-07-13). v1 scope stays frozen; this sets the v2+ direction.
- **Date:** 2026-07-13
- **Deciders:** All 4 team members
- **Supersedes:** nothing. Extends ADR-0001; the SCOPE_FREEZE_MEMO stays in force for v1.

## Context

The project title is *"Natural-Language-Based 3D Simulation Generation System"* and the
team's stated objective is broader than games — **visualization, education, and general
explorable 3D experiences**. The team also wants, eventually, to **improve the models using
user data**. But v1 is deliberately frozen to **four single-player game genres** (SCOPE_FREEZE_MEMO,
ADR-0001) to hit a 12-month dissertation deadline, and scope creep is a named top-10 risk.

We must reconcile the long-term mission with v1 discipline without (a) missing the deadline
or (b) destroying the reliability thesis ("ambiguity up / determinism down") that makes the
system defensible.

Key observation: **the core is already domain-agnostic.** The spec schema, seeded PCG, the
Arbiter, the 8-gate validation stack, localized repair, headless export, and the downloadable
editable project contain nothing intrinsically "game." "Games" is simply the first
**domain pack** = {kits, experience-types, templates, validators, lighting/biomes}.

## Decision (proposed)

1. **v1 remains frozen on games and ships as planned.** No new domains, genres, or a
   general-purpose mode in v1. The dissertation proves the reliability thesis *once*, on games.

2. **Adopt a "domain-pack" framing for v2+.** Education and visualization become additional
   packs on the *same* engine — new vetted kits + experience-types + templates + validators —
   never a core rewrite and never unconstrained LLM generation. Reliability guarantees
   (playable, editable, non-crashing) are preserved because output stays template-bound.

3. **Keep the engine core free of new game-only assumptions.** From now on, avoid hard-coding
   "game-ness" into shared code so packs slot in cheaply later. Cheap generalizations noted for
   v2 (not done now): a `gravity` spec field + controller support; `genre` → `experience_type`
   naming; "objectives/fail_states" already generic. No refactor in v1.

4. **User-data model training is deferred and hard-gated.** v1 training (P4) uses ONLY
   validator-filtered *teacher* outputs (synthetic) — no user data. Training on real user
   data is out of v1 and, when considered, is gated behind: a completed **DPIA**, explicit
   **opt-in consent**, **pseudonymized** logs, and **retention limits** — with heightened care
   because educational users may include **minors** (child-safety duty, CLAUDE.md §14). Logging
   may be *designed* so it could feed training later, but only under consent.

## Alternatives considered

| Alternative | Why rejected |
|---|---|
| Widen v1 now to cover education/visualization | Scope creep → misses the deadline; dilutes the research result |
| Stay games-only permanently | Contradicts the project mission and title |
| Rebuild as an open-ended "generate anything" system | Destroys the reliability/editability guarantees; becomes one-shot LLM generation (ablation A predicts worse) |
| Train on user data in v1 | Legal/ethical hard-stop without DPIA + consent + minor safeguards |

## Consequences

- **Positive:** v1 stays finishable and defensible; the broad mission gets a concrete, low-risk
  growth path (packs); the reliability thesis carries over to every future domain; the legal
  posture on training is explicit before any data is collected.
- **Negative / accepted:** the broad "simulation for everything" vision is explicitly a *post-v1*
  program, not a v1 deliverable — expectations must be set accordingly.
- **Follow-ups if signed:** a v2 roadmap doc listing candidate packs (education, dataviz, virtual
  tours); a pack-authoring guide; keep the core pack-clean during remaining P2–P3 work.
