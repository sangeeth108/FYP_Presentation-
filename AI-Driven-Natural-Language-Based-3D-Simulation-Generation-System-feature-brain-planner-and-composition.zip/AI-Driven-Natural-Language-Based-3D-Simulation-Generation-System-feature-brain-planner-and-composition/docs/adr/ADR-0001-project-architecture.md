# ADR-0001 — Project Architecture

- **Status:** Accepted
- **Date:** 2026-07-07
- **Deciders:** All 4 team members (per planning report v4.0)

## Context

We must convert natural-language prompts into playable, editable 3D games with a 4-person student team in 12 months. Free-form LLM game-code generation is unreliable and unverifiable; neural world models produce no editable artifact; pure procedural generation loses natural-language understanding.

## Decision

Adopt the **five-layer hybrid architecture** with the core principle **"ambiguity up / determinism down"**:

1. LLMs (multi-agent, guided JSON decoding, RAG) produce a **canonical `game_spec`** (JSON Schema 2020-12) — never gameplay code.
2. Deterministic, seeded systems perform PCG, placement, template-bound assembly, export, and validation.
3. An 8-gate validation stack + playtest bots verify every game; failures repaired **locally** (responsible node only, ≤3/class).
4. Engine output is a rebranded Godot 4.x fork (**Serendib**, patch-series on a pinned tag; C++ changes banned) with an AI dock that round-trips edits through the same brain.
5. Hybrid hosting: Hetzner VPS (stateful, always-on) + local RTX 5090 (heavy work, outbound-only tunnel) + Cloudflare Pages/R2 (delivery, $0 egress).

Build order: **golden game first** (P0 gate) → deterministic spine (P1) → brain (P2) → assets/dock (P3) → fine-tune/eval (P4–P5) → ship (P6).

## Alternatives considered

| Alternative | Why rejected |
|---|---|
| Free-form LLM writes game code | Unverifiable safety/quality; softlocks; security surface |
| Train a new foundation model | Expensive; indefensible vs frontier baselines; not the research gap |
| Neural world model (Genie-style) | No editable artifact — contradicts the core promise |
| Pure procedural (no LLM) | No natural-language understanding — loses the product |
| Microservice agents | 4 people cannot operate a dozen services — agents are modules |
| Separate vector DB (Qdrant) | pgvector on existing Postgres is cheaper and simpler |

## Consequences

- **Positive:** reliable, testable, reproducible; editable output; defensible dissertation ablations; modest cost (~$36/mo).
- **Negative / accepted:** expressive ceiling — new gameplay verbs need a human-added template (mitigated by template library growth + v1.0+ slot-filling/behavior-graph roadmap). LangGraph checkpointing is single-process durability, not distributed (Temporal/DBOS named as scale-out).
- **Risks tracked:** web-export weight (golden-game gate), asset quality (QA gates + curated fallback), license landmines (ledger + quarantine), 5090 single point of failure (queue buffering + rented-GPU failover).
