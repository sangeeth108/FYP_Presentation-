# ADR-0018 — Paving is a surface, not two thousand objects

- **Status:** Accepted
- **Date:** 2026-08-21
- **Phase:** P4
- **Completes:** the four composition primitives of `VILLAGE_GAP_ANALYSIS.md` §3.1,
  alongside ADR-0016 (`linear_structures`) and ADR-0017 (`routes` + `frontage`)
- **Depends on:** ADR-0010 (surfaces synthesised from a named family), ADR-0012 (one
  heightfield, generated once and shipped)

## Context

Measured on the village: its paths came back as **2,239 loose paving slabs**, instanced
as scatter with no collision. Not because the planner chose badly, but because the
contract could only express objects, and the only available way to say "this ground is
paved" was to strew slab-shaped things over it.

That is the 59-wall-panels mistake (ADR-0016) one dimension up. A yard is not a
collection of slabs any more than a wall is a collection of panels. It is a *region* of
ground with a different surface — and the world already has ground, already carries a
synthesised material, and already carries real relief.

## Decision

`regions[]`: a closed polygon plus a surface family, rasterised onto the world's existing
height lattice.

**Painted, not built.** A region costs nothing per square metre, follows the ground's
slope exactly because it *is* the ground, and adds no objects at all. 2,239 instances
become one array of small integers.

**The same lattice as the heights, deliberately.** Sampling at a different resolution
would put the seam between two surfaces somewhere other than where the ground changes
shape.

**`surface` reuses the closed `terrain_surface` family set.** Rule 15 again: the planner
names a family from a vetted list and this codebase alone decides what a name looks like.
An open-vocabulary surface string would be the noun ceiling — *cobbles* resolving and
*sett paving* not. `unspecified` is deliberately **absent** here, unlike on
`environment.terrain_surface`: a region whose surface is unspecified is indistinguishable
from the ground around it, so there would be nothing to paint.

**Crossing parity, not winding number.** The contract explicitly does not constrain
winding, so a courtyard drawn clockwise and one drawn anticlockwise must give the same
yard. The half-open convention on the scan line is what stops a grid-aligned rectangle —
the commonest case by far — from developing a one-cell seam along its own edge.

**Later regions win where two overlap.** Declaration order is the only tie-break the
planner can see; ranking by area would mean a small inset gravel patch could never sit
inside a large paved square, which is a perfectly normal thing to describe.

**Index 0 always means the world's own surface**, so a plan with no regions produces
nothing at all — not an array of zeros — and every spec written before this feature is
untouched.

## How it reaches the screen: vertex colours

The ground mesh is already built at load by `terrain_field.gd` from the shipped height
grid. It now reads one more array and gives each vertex its family's colour; the material
sets `vertex_color_use_as_albedo` and multiplies. No textures, no splat map, no shader
authoring, and nothing GL Compatibility cannot draw.

The palette is resolved by the **writer**, not carried in the plan. What a family *name*
looks like is that side's decision (rule 15) — the plan carries names, the scene carries
colours, and the runtime only maps one onto the other.

**Conditional on regions actually being painted.** Turning `vertex_color_use_as_albedo`
on unconditionally would have been the ADR-0010 defect all over again: a flat world's
ground is a `BoxMesh` with no `COLOR` array, vertex colour then defaults to white, and
every such world would have gone back to drawing default white. So the flag, the palette
and the terrain script are all gated on `any(surface_grid)`.

A world can also have regions and *no* relief — a courtyard on flat ground is the
commonest case of all — so the terrain script is now attached when **either** is present.
A flat field simply builds a flat lattice.

## Verified in the engine, not assumed

This is the leg no Python check can see, so it was run in the real Serendib binary
through the normal scene lifecycle (`change_scene_to_file`, not a hand-called `_ready`):

| | with a 24 m stone square | with no regions |
|---|---|---|
| ground mesh | `ArrayMesh` | `ArrayMesh` |
| `COLOR` array | present | **absent** |
| vertex colours | 16,348 grass + **exactly 36** stone | — |
| material | `vertex_color_use_as_albedo=true`, albedo white | flag off, albedo `(0.29, 0.42, 0.21)` |

36 is the same count the Python rasteriser computes for that square on a 128-vertex
lattice over a 500 m world, so the two ends agree by measurement rather than by
inspection.

The first engine run caught a real bug in the harness rather than the product — the mesh
came back as `BoxMesh` because a `SceneTree._init()` `add_child` does not put a node in
the tree, so `_ready` never fired. Worth recording because the symptom (`no COLOR array
on the ground`) was indistinguishable from the feature simply not working.

## Consequences

- The four composition primitives from §3.1 are complete: `linear_structures`, `routes`,
  `frontage`, `regions`.
- Scatter is no longer the only way to express mass ground detail, which is what the
  `scatter_species` description has been arguing against since the speckled-carpet fix.
- Still outstanding: regions do not yet **exclude** scatter, so a species could still be
  strewn across a paved yard. `avoid_tags` can express it today only if the planner
  thinks to use it; making a hard surface repel foliage automatically is a small follow-up
  and is not done here.
- Regions carry no collision and no height change: a paved yard is flat-shaded ground,
  not a raised terrace. A terrace is a `linear_structure` or an entity.
