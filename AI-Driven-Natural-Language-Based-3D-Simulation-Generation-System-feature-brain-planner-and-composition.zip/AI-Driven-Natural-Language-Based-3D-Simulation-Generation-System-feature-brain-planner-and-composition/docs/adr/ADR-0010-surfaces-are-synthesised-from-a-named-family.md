# ADR-0010 — Surfaces are synthesised from a named family

**Status:** accepted · **Date:** 2026-08-08 · **Phase:** P3

## Context

Nothing in a generated world had a surface. Inspection of the native writer
found the cause was more basic than "the textures are poor": the ground
`MeshInstance3D` carried **no material at all** and rendered as Godot's default
white. Paths were a single flat brown constant. Procedural props got their
colour from RGBA literals inlined in each form builder in
`services/worker/asset_farm/procedural.py`, baked into the GLB as a
`baseColorFactor` and never surfaced as data anywhere.

The ground is the largest surface in every frame, so this one omission decided
whether a world looked built or unfinished.

Two claims in the planning documents turned out to be wrong, and are the reason
this was believed to be a small job:

- `docs/IMPLEMENTATION_PLAN.md` (Tier 1 #3) says "Asset-descriptor field already
  exists". `contracts/asset_descriptor.schema.json` has no material field and
  sets `additionalProperties: false`, so nothing could record one.
- `Reports/Serendib_Report/Chapters/ch_5_construction.tex` §`sec:impl-texture`
  describes the whole feature as delivered.

## Decision

Surfaces are **synthesised deterministically in the writer** from a family the
planner names, not generated on the GPU.

A `SurfaceFamily` (`services/worker/godot_client/surfaces.py`) is a vetted tint,
roughness, grain frequency and world-space tile size. The writer emits a shared
seamless `FastNoiseLite` plus one `StandardMaterial3D` per family, projected
**triplanar**.

The same idea is applied twice, on the two sides of the divide:

| | Ground and paths | Procedural meshes |
|---|---|---|
| Where | `godot_client/surfaces.py` | `asset_farm/surface_texture.py` |
| When | Writer, at scene compile | Asset farm, at mesh generation |
| How | Godot `FastNoiseLite` + triplanar | Baked `baseColorTexture` + box-projected UVs |
| Cost | Zero bytes | ~+5 KB per asset |

They are split there because a procedural GLB is content-addressed and cached
across games, so its surface has to be part of the file the digest names.
Baking at generation time means the textured mesh is what gets measured, hashed,
QA-gated and copied — the lineage stays true. Doing it later, at the point the
writer copies into `assets/`, would leave the descriptor's `content_hash`
describing a file that no longer exists.

Curated (KayKit) and generated (TRELLIS) assets already carry their own
surfaces, so only the procedural tier is textured. That tier was the flat one.

Four properties are deliberate:

- **Triplanar or box projection, never authored UVs.** The ground is a `BoxMesh`
  and the procedural primitives carry no `TEXCOORD_0`, so anything depending on
  unwrapped UVs would sample nothing. On the mesh side, UVs come per vertex from
  the dominant axis of the vertex normal — the mesh equivalent of triplanar.
- **The texture modulates the palette; it never replaces it.** glTF multiplies
  `baseColorFactor` by `baseColorTexture`, so the noise is kept in the upper
  range (≥0.72) and each piece keeps the colour its builder assigned. A tree
  still has a brown trunk under a green crown. Collapsing an assembly to one
  colour would be a worse asset than the flat one it replaced, so this is the
  property most heavily pinned by tests.
- **Applied to final geometry.** `_fit_to_bbox` rescales an assembly
  non-uniformly; UVs derived before it would stretch the grain by whatever
  correction the fit happened to apply.
- **The surface rule is part of the cache key.** `NOISE_VERSION` is in the
  content contract that produces the digest, which is both the filename and the
  cache key. Without that, every already-generated flat mesh would be reused
  forever — the invalidation problem the *descriptor* cache was wrongly accused
  of having, which is real here because these files genuinely are reused by path.
- **The planner names the family; this module decides what it looks like.** This
  is ADR-0009 and CLAUDE.md §3.15 applied to surfaces. `environment.terrain` stays
  open vocabulary and says what the place *is*; the new closed enum
  `environment.terrain_surface` says what the ground is *made of*, and only it
  drives rendering.
- **An unnamed surface degrades neutrally and says so.** It renders the
  `unspecified` family and appends to the spec's approximation record, rather
  than presenting a guess as the requested surface.

Because ADR-0009 established that schema `description` prose never reaches the
model — Ollama's `format` parameter compiles structure to a grammar and discards
text — the enum constrains the model and the *instruction* lives in the planner
system prompt. The schema description is for humans.

## Consequences

**Good.** The ground, the biggest thing on screen, is textured. The look is
reproducible from the seed (rule 14), costs no GPU time, adds no texture files
and no bytes against the ≤90 MB web budget, and needs no licence entry. The
fallback rate is measurable, because an unnamed surface is recorded rather than
absorbed — which matters for the P4 ablation.

**Cost.** A closed enum has to be extended by hand, and a world whose ground is
genuinely something else (mud, ice, tile, carpet) gets the neutral default until
someone adds it. That is the intended trade: a visible, logged gap beats a
plausible wrong guess.

Measured cost: seven forms at representative sizes total 73 KB, so roughly
4.2 MB for 400 unique assets — against a 90 MB budget, and only for the tier
that had no surface at all.

**Two defects that only a render showed.** Both were introduced by this decision
and both passed every unit test before a picture was taken:

- Deriving the projection *per vertex* let the three corners of one triangle
  choose three different axes, so the texture swept across the face. On an
  icosphere boulder 44 of 80 faces disagreed, and every rock rendered with a
  chevron pattern radiating from its centre. Fixed by unmerging vertices first;
  pinned by `test_every_face_projects_from_one_axis`.
- Raw noise spans black to white, and multiplying a tint by that made the ground
  read as mottled camouflage rather than soil. Both sides now compress the range
  to a modulation — a `Gradient` ramp on the Godot texture, a floor of 0.82 in
  the baked one.

The lesson is the one ADR-0009 already records in a different form: these are
properties of an image, and a test that cannot see cannot judge them. Rendering
the validation views is cheap and should follow any change to a material.

**Not addressed.** The asset descriptor still has no `material` field, so the
palette assignment a builder makes is visible only inside the GLB and cannot be
inspected, validated or reported. Nothing records *which* tier gave a mesh its
surface, so a curated asset with a poor texture and a procedural one with
synthesised grain are indistinguishable downstream. Adding that field means
extending `contracts/asset_descriptor.schema.json` (which sets
`additionalProperties: false`) and having `qa_gate.py` read the material list it
already parses out of the glTF.

Normal and roughness maps are also still absent — this is albedo only, so
surfaces have grain but no relief. That is the remaining half of "albedo/normal/
roughness" as the plan words it.

## Alternatives rejected

- **SDXL-generated albedo/normal/roughness maps baked into GLBs.** The literal
  reading of the report. Needs GPU mode-sequencing against the 32 GB constraint,
  a new texture QA gate, licence ledger entries, and it spends the web budget on
  detail a low-poly art direction does not use. It also makes a run less
  reproducible, which the ablation depends on.
- **`material_override` on the instanced entity scenes.** Replaces *all*
  surfaces of a mesh, so a tree loses the distinction between trunk and crown.
- **Mapping the free-text `terrain` string to a colour.** This is the noun
  ceiling `procedural.py` already documents: "grassy meadow" would resolve and
  "machair" would not, and the miss would be silent. Pinned by
  `test_free_text_terrain_never_selects_a_family`.
