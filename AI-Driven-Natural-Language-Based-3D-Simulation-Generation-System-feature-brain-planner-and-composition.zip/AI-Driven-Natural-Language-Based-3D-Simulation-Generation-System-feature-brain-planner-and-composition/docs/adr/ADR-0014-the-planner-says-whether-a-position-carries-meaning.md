# ADR-0014 — The planner says whether a position carries meaning

- **Status:** Accepted
- **Date:** 2026-08-20
- **Phase:** P4
- **Relates to:** ADR-0009 (the model names things, code sizes them)

## Context

`scatter` expands one species into hundreds of seeded placements by rejection
sampling: spread out, no closer than the measured footprint, wherever there is room.
For a fern, a boulder or a tussock that is exactly right, and it is what makes a world
feel inhabited instead of empty.

Re-measuring the village diagnostic showed what it does to everything else. The
largest species by instance count was a **street lamp — 168 of them across 8,400 m²,
one every 50 square metres, with no relation to any path — beside 28 trees.**

Three explanations were available and two of them were wrong:

1. **A budget failure.** It was not. `_TOTAL_INSTANCE_BUDGET = 12,000` already caps the
   whole scene and scales species proportionally; the village used 328 instances. An
   earlier draft of `docs/VILLAGE_GAP_ANALYSIS.md` §3.7 claimed no world ceiling
   existed. That claim is corrected in place — the ceiling was never the problem, and
   building a second one would have fixed nothing.
2. **A density failure.** It was not. The planner asked for 1.0 per 100 m² and got
   0.999. It received precisely what it requested.
3. **A missing question.** This one. Nothing in the contract asked whether *where* an
   instance goes carries meaning, so a fern and a lamp post were the same request, and
   the sampler answered both the only way it can.

## Decision

The contract asks. `scatter_species.placement_is_incidental` is an optional boolean:
`true` for a thing a visitor would not notice moved three metres, `false` for a thing
that belongs somewhere — a lamp beside a path, a bench facing something, a crate
against a wall.

Three properties of that choice are deliberate.

**Optional, not required.** Requiring it would invalidate every preserved spec and
break repairs that carry an earlier one forward. Absent means "the planner did not
say" and behaves exactly as today. Only an explicit `false` changes anything.

**No noun table.** There is no list of words like *lamp*, *bench* or *fence* anywhere
in this change — the same reason `_infer_procedural_type` carries that warning. Whether
a thing belongs somewhere specific is a judgement about the described world, and the
model is the part of the system holding the description. A test names a species
`spc_lamp` without the flag and pins that it is left untouched: the name is not the
claim.

**The consequence is a count, not a deletion.** A `false` species survives at six
instances (`_POSITIONED_CEILING`) and the reduction is disclosed as user-visible. Six
lamps distributed badly reads as "there are lamps here"; 168 reads as a lamp farm,
which is the worse lie. Dropping the species entirely would be worse still — somebody
asked for a lit street.

A cap the planner chose that is already tighter is never loosened: the ceiling is an
upper bound, not a target.

## Honesty in the report (rules 11 and 13)

`max_instances` was read *after* it clipped the count, so a species reduced from 168 to
6 reported `requested_instances: 6, placed_instances: 6, shortfall_reason: null` — a row
asserting a guarantee nothing gave, in the one report whose whole purpose is disclosing
shortfall. `requested_instances` now carries what density asked for,
`capped_to_instances` records the bound, and `shortfall_reason` gains `instance_cap`.
It only speaks when the cap actually bound something; a harmless high ceiling stays
silent, so the reason column does not cry wolf.

## Consequences

- The lamp farm is gone: 168 → 6, measured end to end on the diagnostic spec, with the
  other two species byte-identical.
- One existing test asserting the old post-cap `requested_instances` semantics was
  rewritten rather than patched, with the reason recorded in its docstring.
- **This is explicitly an interim answer.** The right home for a street lamp is
  `routes[]` with frontage, where it is spaced along a street because that is what a
  street is for (priority #7 in the gap analysis). Until that exists, a system that
  cannot place a thing properly should place few of it and say so.
- The lever here was schema prose, again. Three earlier defects this phase traced to
  contract fields with no description; this one traced to a field that did not exist.
  In a system where an LLM authors the spec, the contract's prose is production code.
