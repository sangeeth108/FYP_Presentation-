# ADR-0016 — A run is declared once and materialised as segments

- **Status:** Accepted
- **Date:** 2026-08-20
- **Phase:** P4
- **Addresses:** `docs/VILLAGE_GAP_ANALYSIS.md` §3.1, the analysis's stated root cause

## Context

The spec could express objects, materials, capabilities and pairwise proximity. It could
not express a line. So the village's boundary wall came back as **59 loose scatter
panels sprinkled across the map**, which the dog walked straight through, and 2,239
paving slabs did the same for the paths.

The planner was not being careless. Given `near` and nothing else, it was describing a
settlement in a language with no word for *street*. §3.2 of the analysis makes the point
directly: no amount of prompting fixes a concept the solver cannot consume.

`linear_structures[]` is the first of four composition primitives — the others being
`regions[]`, `routes[]` and `frontage`.

## Decision

The planner declares a run: two endpoints, a height, a thickness, an asset, and any
openings. Deterministic code decides everything else.

**Segments, not one long box.** The world has real relief now (ADR-0012), and a single
60 m box either floats at one end or buries itself at the other. Dividing the run lets
each piece sit on the ground beneath it, which is what a real wall does across a slope.

**Segment count is not a planner decision.** It trades node count against draw calls
against how badly a long box reads on a slope, and the planner can see none of that. So
the contract carries the two endpoints and the cross-section (rule 3.15). The per-run
ceiling is 16: a 240 m run at the preferred 3 m would be 80 static bodies for one wall,
against a scope budget of 50–200 props for the *whole world*.

**The output is ordinary spec entities.** This is what makes the feature small rather
than large. Entities already get colliders, terrain seating, navmesh carving, the scene
writer and every validation gate; a parallel `segments` array would have needed all of
it reimplemented. It is also forced: the scene writer indexes the spec by entity id, so
a world-plan-only segment could not be written at all.

**Openings are subtracted before segmenting, not dropped after.** The first version
segmented the whole run and dropped any segment an opening touched — so a 3 m gate ate
two 3.75 m segments and opened the wall by **7.5 m**. "Slightly too wide is the safe
direction" is a fair argument for rounding and not for two and a half times. Taking the
gaps out of the run first makes a gate a hole in the input rather than a casualty of the
output, and deletes the overlap heuristic entirely.

**Traceability rides on `part_of`.** One requirement is written against the whole run,
carrying the run's own verbatim `source_text`; the later segments are `part_of` the
first. Requiring a requirement per segment would collide with the verbatim rule —
fifteen of sixteen could not be sourced — which is exactly the case `part_of` was added
for.

## `placement.anchor_m`, and why the planner cannot write it

The solver positions an entity by relation or by seeded search. Neither can express
"exactly here", which is what a wall segment needs. So the contract gains an absolute
anchor and a companion yaw.

**The grammar adapter strips both.** A model handed raw world coordinates starts
hand-authoring layouts in them, which is the arrangement work this system deliberately
does downstream and the whole reason this feature exists. The canonical schema keeps the
fields so the post-expansion spec validates; the grammar the model decodes against does
not contain them. Their descriptions say `MACHINE-AUTHORED. Do not write this field.`
for the case where some future path does expose them.

An anchored entity is *reported*, not positioned — but collision, clearance and terrain
seating all still run, so a wall driven through a house is still caught and still
disclosed.

## Two defects this uncovered

**`part_of` had to become adjacency, on both sides.** A wall's segments must abut — that
abutment is what makes it a wall rather than a row of blocks — and with interaction
clearance enforced between them, **half a 16-segment wall failed to place**, every other
segment rejected against its own neighbour. `part_of` is now exempt in both the placer
and the validator, and unlike the other adjacency relations it does not need to be
`hard`: it is not a preference about where two things go, it is a statement that they are
one thing. Getting this wrong in one place only would have been the seventh time those
two have disagreed, which is what `entities_conflict` exists to prevent.

A test that asserted the string `"part_of"` appeared nowhere in `pcg/semantic.py` failed
here. It was a *proxy* for "no placement consumer reads it", and it held only while
nothing at all read it. It now asserts the property instead: adding a `part_of` relation
must leave every transform in the plan identical. Waiving a clearance check is not moving
anything, and a behavioural test can tell the two apart where a string search cannot.

**Segments carry a 10 mm joint.** Two boxes that abut *exactly* are overlapping as far as
a separating-axis test is concerned — zero separation is not positive separation — so six
of sixteen segments still failed after the adjacency fix. Ten millimetres is below what a
stylised low-poly mesh resolves at any distance a visitor sees it from, and comfortably
above the four-decimal rounding the plan stores positions at. It comes off the length and
not the position, so each end of the run pulls in by 5 mm.

**And one defect from earlier work, found here.** #4 added `capped_to_instances` to the
scatter species report without updating `contracts/world_plan.schema.json`, which is a
closed object. The full suite passed, because no test built a world plan carrying scatter
through `validate_world_plan_schema`. It surfaced the first time this feature generated
one. The schema now carries the field, and the gap in coverage is worth naming: a green
suite is evidence, not proof.

## Consequences

- A 60 m wall with a central gate: 16 of 16 segments placed, gate 3.00 m against 3.0
  asked, ends within 11 mm of the declared endpoints, one yaw, plan validates.
- A diagonal fence keeps a single −45° yaw through placement instead of sixteen random
  ones.
- Walls now have **collision**, which §3.7 and §3.9 both listed as absent.
- `regions[]`, `routes[]` and `frontage` remain outstanding. Those are what turn a field
  of objects into a settlement; this one makes its boundaries real.
