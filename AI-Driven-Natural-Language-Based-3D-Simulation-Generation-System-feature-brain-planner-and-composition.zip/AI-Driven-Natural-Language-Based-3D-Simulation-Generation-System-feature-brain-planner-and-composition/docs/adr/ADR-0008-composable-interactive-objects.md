# ADR-0008 — Composable interactive objects: affordances are separated parts bound at sockets

- **Status:** Accepted — production-grade approach chosen on request ("not only doors… vehicle doors want to open correctly… choose the correct thing for a production-grade system", 2026-07-19).
- **Date:** 2026-07-19
- **Deciders:** user (delegated the architectural call) + Claude Code
- **Extends:** ADR-0003 (L3 compositional generation) applied *inside a single object*; ADR-0005/0007 (generated meshes are static statues — so behaviour never comes from the mesh).

## Context

A generated model is a single static mesh. Real interactive games need objects whose
**affordances work**: a house door opens, a **vehicle door opens correctly on its hinge**, a
chest lid lifts, a machine lever pulls. If the door is baked into the body mesh, the player can
never open it — and a generated mesh carries no rig, no hinge, no trigger (ADR-0005/0007). So the
interactable part must be a **separate node with vetted behaviour**, positioned exactly, not
painted onto a shell.

The requirement is general — doors, vehicle doors, lids, levers, wheels, hatches — so the
solution must not special-case "house" or "door". The brain must *reason about which parts of any
object are interactable and how they attach*, and the deterministic spine must place and wire them
correctly and **prove** they work.

## Decision

**Every object is a composite: a static parent mesh plus zero or more affordance PARTS, each part
a separate node bound to a vetted behaviour template and snapped to a named SOCKET on the parent.
The mesh never carries behaviour; behaviour comes only from templates; correctness is proven by
the playtest bot.**

- **Object = parent(mesh) + sockets[] + parts[]**, where a socket is a named anchor on the
  parent's *normalised bounding box* (`{name, offset, facing, hinge_axis}`) and a part is
  `{template_id, mesh_source, socket, params}`. Recursion gives arbitrary compounds.
- **Sockets are convention points on the bbox, not detected holes.** Generation is normalised to a
  known bbox, so "front-centre, on the ground, facing +Z" is deterministic and needs no fragile
  mesh analysis. A vehicle declares `door_L/door_R` at its side edges with a vertical hinge axis;
  a house declares `front_door` at front-centre. Same machinery.
- **Ambiguity up / determinism down (ADR-0003):** the LLM decides the *decomposition* — which
  parts are interactable, which template, which socket, which params (`open_angle_deg` ≈ 70° for a
  car door, 90° for a house door) — chosen from a vetted menu (rule 10; no authored code). The
  seeded assembler computes each part's world transform from parent⊗socket, instances the template
  with its origin at the hinge, adds the `InteractZone` + collision, and wires signals
  (door↔lock/key, pickup↔quest) declaratively.
- **The bot is the correctness oracle.** A composed affordance is not trusted because it was
  emitted; validation drives the bot to the part, fires `interact`, and asserts the state changed
  (door opened, path now passable, item collected) via the debug singleton — never vision. Failure
  → localized repair (re-place/re-socket), capped per class.
- **Modular meshes for fit.** The interactable part is its *own* mesh (generated or curated) at the
  socket, so its pivot is exact by construction. This is why the door hinges correctly where a
  "door near the body" never could — the production reason to reject near-placement.

`door_hinged.gd` already implements the general hinged affordance (origin = hinge, swings
`open_angle_deg`, `InteractZone` proximity + `interact`, lock/unlock signals). It is the first
behaviour template this model binds; `pickup_collectible.gd` is the first non-hinged one. New
affordances (lever, lid, wheel, sliding door) are new *templates*, never new code paths.

## Alternatives considered

| Alternative | Why rejected |
|---|---|
| Bake the door into the body mesh | Cannot open — fails the whole requirement |
| Door as a sibling prop "near" the body | Pivot/placement wrong — a vehicle door won't hinge correctly (the user's explicit test) |
| Brain emits the graph first, materialize later | No working target to validate against — violates "spine before brain" and gives no proof the affordance works |
| Detect openings in the generated mesh | Fragile geometry analysis; unnecessary — normalised bbox sockets are deterministic |
| LLM writes the door/vehicle behaviour | Rule 10 (banned) — behaviour stays in vetted templates |

## Consequences

- **Positive:** one mechanism makes *any* affordance on *any* object work and be verified; fits
  ADR-0003 (composition), ADR-0005/0007 (mesh is static, behaviour is template), and the bot-proof
  validation stack. Meshes stay swappable (generated ↔ curated) without touching behaviour.
- **Negative / accepted:** the spec grows a composite/socket representation; the assembler grows
  socket-snapping + per-template wiring; validation grows an affordance-exercise gate. Built in
  phases: (1) deterministic composite representation + assembler + hand-written spec proving a
  separate, bot-opened door; (2) more affordance templates (lever, lid, sliding, vehicle-door
  params); (3) brain decomposition agent emits composites; (4) modular part generation for exact
  visual fit.
- **Guardrail:** behaviour is always a vetted template bound declaratively; "thinking-based" means
  the LLM *composes* parts + sockets, never authors the mechanism.
