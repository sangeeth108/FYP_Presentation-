# ADR-0021 — A capability must name the thing that performs it (ACCEPTED)

- **Status:** Accepted — implemented and verified against the failing run
- **Date:** 2026-08-26
- **Phase:** P4

## The defect

`run_03bcc12ea42448818b0220c12ffd29d1` — *"As a dog, explore a living village with usable
doors and navigable paths"* — reached validation and stopped at 9 of 18 gates:

```
top-level capabilities : ['animal', 'camera_control', 'locomotion', 'openable']
ent_controlled_actor   : ['locomotion', 'camera_control']      <- no 'animal'
entities claiming animal: none
```

`capability_resolution` reported `CAPABILITY_INCOMPLETE` with
`missing: ["capability_consumer"]` and `entity_id: null` — null because there was no
entity to name. `behavior_compilation` reported `RUNTIME_BINDING_INCOMPLETE` for the same
root cause, reading `rigged` and `locomotion_compatible` off a descriptor it never looked
up. Both gates are mandatory, so six further gates never ran and the world did not
publish.

**The asset was never at fault.** `Husky.glb` carries 24 animation clips and one skin, and
the run's own QA record says `rigged: true, animated: true`. A correct, playable world was
discarded because one spec field was declared in one place and forgotten in another.

## Why the planner cannot be asked to fix this

The spec states capabilities twice: once at the top level (*what this world does*) and once
per entity (*which thing does it*). Two lists that must agree, both written by the model,
is a drift generator. ADR-0009 already records the finding that decides this — *guidance
improves the average and never becomes reliable* — and a JSON-Schema grammar cannot express
a cross-field constraint, so guided decoding cannot enforce agreement either.

## Decision

Reconcile deterministically in `_reconcile_capabilities`, beside the reconcilers that
already repair entities, requirements and spatial relations.

For each declared capability with no consuming entity:

- **Attach** it to every eligible entity, when eligible entities exist. The declaration is
  usually right and the omission is the slip: a dog really is an animal, and binding
  `animal` to it gains the idle and eating clips its mesh already carries. Every eligible
  entity, not just the first — a world holding a dog and a cow wants both animated, and
  qualification is checked per entity regardless.
- **Withdraw** it otherwise, recording a non-user-visible approximation. A capability
  nothing in the world can perform is a claim the spec should not make; leaving it for a
  validator to reject discards the world over a field the user never saw.

**Scope is closed, not guessed.** Only capabilities carrying a `qualification` demand a
consumer, and of the thirteen in the registry only `animal` and `locomotion` do. Eligibility
is therefore defined for exactly those two: `animal` by the head noun of `semantic_type`
against the creature vocabulary, `locomotion` by the controlled-agent role. An ambient
capability — `time_weather`, `ecosystem_process`, `camera_control` — is left untouched,
because the registry never asks who consumes it.

**The top-level list is deliberately not rebuilt** from the entities. A strict union would
be tidier and would make orphans impossible by construction, but it would silently drop any
world-level capability no entity happens to claim. Repairing the failure class is worth
doing; widening the change to a field nothing is complaining about is not.

The head-noun rule is reused rather than reinvented: it is the same principle the curated
matcher settled on (ADR-0019), so `village_dog` is a dog and `dog_kennel` is not.

## Verification

Replayed against the failing run's stored spec and its real asset manifest:

| gate | before | after |
|---|---|---|
| `capability_resolution` | `CAPABILITY_INCOMPLETE`, `entity_id: null` | **no gaps** |
| `behavior_compilation` | `RUNTIME_BINDING_INCOMPLETE` | **no errors** |

The actor's descriptor resolves to `rigged: true, locomotion_compatible: true` with 24
clips, confirming the qualification was always satisfiable.

Eight regression tests cover attachment, the head-noun rule, the modifier case
(`dog_kennel` is not an animal), withdrawal with disclosure, multiple creatures, ambient
capabilities, and idempotence on an already-consistent spec. The full brain suite passes;
the deterministic benchmark holds at 9/10 with the composition set unchanged.

## Consequences

- Two mandatory gates stop failing on a spec inconsistency the user cannot see or fix.
- Diagnostics improve even where the gate still fails: the error now names the entity
  instead of reporting `entity_id: null`, because there is always a consumer to name.
- **Blast radius is one run.** Measured across 263 stored runs, exactly one failed on
  `capability_consumer`. This fixes a real, verified defect; it is not a broad win, and
  quoting it as one would repeat the mistake ADR-0020 warns about.
- The dominant live failure remains `MISSING_ENTITY` (143 occurrences since 20 August),
  but it is **not** a planner defect and was mis-attributed here on first writing. Every
  instance is emitted by `qwen2.5vl:32b`, the vision model behind `visual_semantic`,
  looking at a rendered preview and failing to find something the inventory promised.
  One reads *"Only green cubes and debris are visible, no animals"*, which names the real
  cause: assets that fall through the ladder to procedural primitives are invisible to a
  semantic reading of the image. The next fix is therefore generation **yield**, not
  planner consistency — a distinction worth stating because the two lead to entirely
  different work.
