# ADR-0017 — Buildings address a street

- **Status:** Accepted
- **Date:** 2026-08-20
- **Phase:** P4
- **Builds on:** ADR-0016 (`anchor_m`, machine-authored)
- **Addresses:** `docs/VILLAGE_GAP_ANALYSIS.md` §3.1(3–4) and §3.3 — what the analysis
  calls "the actual reason this is not a village"

## Context

Measured across 176 specs: **`facing` used 0 times in 531 relations**, 55% of entities
carrying no spatial relation at all, and buildings landing wherever a seeded dart did not
collide — 21 m apart in something called a village. §3.3 states the cause plainly: for
the majority of entities, dart-throwing *is* the layout.

`facing` going wholly unused is the interesting part. It was in the contract the whole
time. It went unused because it expresses the wrong relationship: **a building does not
face another building, it faces the street** — and there was no street to face.

On the diagnostic village, the four cottages sat 45.3, 27.8 and 12.6 m apart at yaws of
−92.8°, 62.7°, −6.3° and −35.4°. Four correct buildings, no settlement.

## Decision

Two additions, mirroring the split this system uses everywhere.

**`routes[]`** — the circulation spine, as a polyline with a width. The planner authors
it, because where the street goes is design, and consistently with `linear_structures`
already taking its endpoints from the planner.

**`placement.frontage`** — `{route_id, setback_m, side}`. Which route an entity addresses
and how far back it stands. Position and rotation are *solved*, not authored.

The same four cottages then stand in two rows either side of the lane, 10.2 m apart along
it, every one at exactly 0° or 180° — square to the street.

### Six decisions inside that

**Setback is measured to the near face, not the centre.** Measuring to the centre would
put a 12 m-deep longhouse 6 m into the road and a 2 m stall barely at all, so one
declared number would mean something different for every building — and worst for the
biggest ones.

**Plot width comes from measured geometry**, which is why this runs at layout time rather
than spec time. A 12 m longhouse and a 2 m market stall cannot share a plot size.

**Rows are centred on the route.** Filling from the start put four cottages in the first
20 m of a 70 m lane — every building correctly oriented, and the settlement still bunched
at one end with fifty metres of empty road beyond it.

**`side: either` alternates**, because that is what fills a street. A street with one
empty side reads as half-built rather than as a choice.

**It emits `anchor_m` rather than solving transforms.** ADR-0016 already built the road
from a declared position to a placed entity, including collision, clearance and terrain
seating. A frontage that computed final transforms would be a second placement path, and
the two would drift — the failure `entities_conflict` exists to document. So a plot
landing on a pre-existing well is still caught and still disclosed.

**No randomness at all.** Allocation walks the route in the spec's own entity order, so
two runs of one spec under different seeds put the buildings in the same plots.

## The two kinds of anchor

`anchor_m` now has two producers, and they differ in authority. This is load-bearing.

- **A wall segment's anchor is a fact.** Segment 7 belongs between 6 and 8; moving it
  somewhere roomier would not be a compromise, it would be a different wall. Honoured on
  every attempt; reported unplaced if the ground is genuinely taken.
- **A frontage anchor is a preference.** "This house addresses the main lane" is
  satisfied by *a* plot on that lane, and when the plot is occupied the honest answer is
  a house elsewhere, not a missing house. Measured: a lane run through the village's own
  25 m square put two of four cottages inside it, and honouring the anchor on every
  attempt lost both. **An unplaced building is worse than a badly placed one.**

So frontage yields once relaxation begins, like every other soft preference, and the
yield is recorded — somebody asked for a building on a lane and has got one off it. A
house that gave up its plot also gives up the street's angle, because squared to a lane
it no longer stands on reads as a fault rather than as a fallback.

## A street nothing could walk on

The first working version produced two tidy rows and a world that failed validation:
with houses 1.2 m apart, the far row's doors could reach nothing. Straight and L-shaped
path candidates were blocked by the door's own neighbour along the row, and by the
opposite row going the other way. **Every building was correctly oriented onto a lane
that no path could use** — a decorative street.

Nobody walks between two terraced houses. They step out to the street, walk along it, and
turn off at the far end. So `_navigation_paths` now offers, after its straight and
L-shaped candidates, the route's own centreline between the two projections. Offered
*last*, so a clear straight line is still preferred: a path that hugs the kerb to reach
something ten metres away would be absurd.

## The sign error worth recording

The yaw formula had its second argument's sign wrong, so **every building turned its back
to the street**.

It was invisible in the transforms. Two tidy rows at 0° and 180°, exactly the shape the
feature was supposed to produce, and every assertion about spacing, sides and setback
passed. It surfaced only because the doors attached to those houses landed on the far
side and one navigation probe could not reach a door.

A row of houses is symmetric enough that facing and backing look identical until
something has to walk up to a door. That is the second time this phase a defect was
invisible to every check except a consequence two layers downstream — the first was the
inverted triangle winding that no Python check could see.

## Known limitation, pinned in a test

Under the pathological route (a lane driven through the village's own square, which no
planner drawing both would produce), one house keeps a plot whose front face lands inside
the square. Its door is attached rigidly: the door has no freedom to move aside, and the
parent is not reconsidered once a child fails. The house stands and the door is lost.

The mechanism predates frontage — `_placement_order` already documents a rigidly attached
child failing because its parent claimed ground that did not suit it — but frontage makes
it reachable, so it belongs on the record rather than in the gaps. Fixing it properly
means letting a failed child push its parent to another candidate, which is a change to
the placement loop and not to this feature.

## Consequences

- Four cottages: 45/28/13 m apart at four unrelated angles → two facing rows 10.2 m
  apart at 0° and 180°, all paths connected, plan validates.
- A bending street turns its buildings with it (0° on the straight leg, 45° on the
  diagonal) rather than averaging them onto one axis.
- `facing` remains in the contract and remains, correctly, unused between buildings.
- `regions[]` (#8) is the last of the four composition primitives: paved yards and
  streets as ground material rather than as thousands of loose slabs.
