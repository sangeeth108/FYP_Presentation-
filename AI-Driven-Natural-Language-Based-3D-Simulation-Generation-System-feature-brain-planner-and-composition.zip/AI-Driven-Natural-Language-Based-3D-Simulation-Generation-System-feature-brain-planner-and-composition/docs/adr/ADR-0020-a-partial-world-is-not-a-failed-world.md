# ADR-0020 — A partial world is not a failed world (PROPOSED)

- **Status:** Proposed — for review before implementation
- **Date:** 2026-08-26
- **Phase:** P4

## The problem, in numbers

From the settlement benchmark, current code:

| prompt | entities | unplaced | published |
|---|---|---|---|
| market_street | 19 | **0** | **no** |
| village_lane | ~30 | **1** | no |
| town_square | 5 | 0 | yes |
| farmyard | 43 | 4 | no |
| harbour_front | 46 | 5 | no |

The market street placed **everything** and still did not publish. The village lane
missed one entity out of thirty. These are not broken worlds; they are worlds discarded
over a fence corner.

`published` is a conjunction of seventeen mandatory gates. One unplaced entity fails
`semantic_placement` directly and `requirement_traceability`,
`native_world_plan_compilation` and four more by cascade. The pass rate therefore
measures *flawlessness*, not deliverability — and a stakeholder reading "3 of 12
published" concludes the pipeline is broken when most of those twelve worlds build,
load and play.

## Why this is inconsistent with the rest of the system

Every other stage already degrades and discloses:

| stage | when it cannot do the thing |
|---|---|
| asset ladder | falls through cache → curated → generated → procedural, notes the tier |
| scatter | places what geometry permits, reports `requested` vs `achieved` and why |
| frontage | yields the plot when taken, records "stands N m away instead" (ADR-0017) |
| linear structures | shares one segment budget, discloses coarser spacing |
| surfaces | falls back to a neutral family and records an approximation (ADR-0010) |
| **placement** | **fails the entire build** |

Placement is the only stage that treats a partial result as a total failure. That is not
a considered decision recorded anywhere; it is the absence of one.

## Decision

Classify an unplaced entity by whether the PROMPT asked for it. The system already
computes this — `verify_requirement_traceability` knows which entities are the subject of
an `exists` requirement, and `_presence_is_traced` already follows `part_of` chains.

**Required — remains a hard failure.** An entity that is the subject of a prompt
requirement, or the controlled actor, or the target of a declared capability. If somebody
asked for a rake and there is no rake, the world is incomplete and must not publish.

**Incidental — becomes a disclosed approximation.** An entity the planner added as
texture: segment 9 of a 16-segment fence, one of five market stalls, a scatter-adjacent
prop. The world publishes, and the shortfall appears in the user-visible approximations
beside "fewer street lamps than you asked for".

**A group is judged as a group.** One segment of a fence missing is a gap in a fence;
*every* segment missing is a missing fence. So a `part_of` group that loses more than half
its members fails as a unit — the thing itself did not get built.

## What this is not

- **Not lowering the bar on anything requested.** Required entities are unchanged.
- **Not hiding anything.** The shortfall is user-visible, in the channel that already
  carries compromises, and the world plan keeps `unplaced_entities` exactly as now.
- **Not a new mechanism.** It reuses the traceability the contract already computes and
  the approximation channel the report already renders.
- **Not a fix for the underlying defect.** Runs still fail at corners
  (`test_two_runs_meeting_at_a_corner_both_place`, strict xfail). This changes what that
  defect *costs*, from a discarded world to a reported gap, while the defect is fixed
  separately.

## Consequences

- `semantic_placement` fails only on required entities or a collapsed group.
- `requirement_traceability` keeps `REQUIRED_ENTITY_NOT_PLACED` exactly as it is — it is
  already scoped to requirements, which is the distinction this ADR is built on.
- The published rate becomes a statement about deliverability. Expect the settlement set
  to move from 1/5 toward 3-4/5 on today's code, and the corpus off 3/12 — *without any
  world getting worse*, which is the claim to verify rather than assume.
- Two numbers should be reported from then on, because they answer different questions:
  **published** (is it deliverable) and **flawless** (did every gate pass). Quoting one
  as if it were the other is what made this hard to see.

## Implementation

1. `verification/contracts.py` — expose `required_entity_ids(spec)`, the union of `exists`
   requirement subjects, the controlled actor, and capability-requirement targets. The
   logic exists inside the traceability check; lift it out.
2. `pcg/semantic.py` — classify `unplaced_entities` into `unplaced_required` and
   `unplaced_incidental` in `constraint_summary`, and apply the half-a-group rule using
   the `part_of` relations already in the spec.
3. `worker/native_pipeline.py` — `semantic_placement` fails on `unplaced_required` only;
   each incidental one becomes a user-visible approximation naming what is missing.
4. Tests: a required entity unplaced still fails; one segment of sixteen does not; nine of
   sixteen does; the approximation is user-visible and names the entity.
5. Measure on the deterministic benchmark (seconds) and the settlement set (minutes)
   **before** any corpus run.

Estimated: half a day, most of it in step 4.

## The risk, stated plainly

This makes the headline number go up without the worlds changing. That is legitimate only
if the distinction is real — a missing fence corner genuinely is not a missing fence — and
only if both numbers are reported afterwards. If it is used to quote a better pass rate
while quietly dropping the flawless count, it is a cheat. The mitigation is the two-number
rule above, and it should be treated as part of the decision rather than a nicety.
