# ADR-0015 — The planner names the colour

- **Status:** Accepted
- **Date:** 2026-08-20
- **Phase:** P4
- **Extends:** ADR-0009 (the model names things, code sizes them), ADR-0010 (surfaces
  are synthesised from a named family)

## Context

ADR-0009 solved the field-of-boxes problem by making the planner name a **form** —
`foliage_column`, `legged_platform`, `open_container` — and giving this codebase twelve
builders that know how to build forms and nothing about nouns. It worked, and it left
colour exactly where shape had been: a constant compiled into each builder.

So every boulder in every world is `[122, 118, 110]`. Every tree is one brown trunk
under one green crown, whether the prompt said oak, pine or dead birch. A terracotta
pot, a rusted drum and a wicker basket are the same tan `open_container`. The forms made
each object the right *shape* and simultaneously guaranteed that every object sharing a
form is the same *colour* — which, across fifty props, reads as a world made of one
material.

## Decision

`palette_hex` on the asset requirement: one to three hex colours, in the form's own
structural order — body first (trunk, table top, machine body, building walls, door
leaf), then its secondary part (crown, legs, head, roof, ironwork).

**Hex, not a material name.** `"weathered oak"` would need a lookup from words to
colours, and any such list is a ceiling — the same argument that produced forms in the
first place. *Oak* would work and *kwila* would not. A hex triple needs no vocabulary at
all, and naming colours for materials is something a language model is genuinely good
at.

**Optional, and fewer than the form uses is legal.** Every preserved spec still
validates. One colour on a tree repaints the trunk and leaves the crown its default
green; requiring a colour per piece would push the planner into inventing accents it has
no opinion about, and an invented accent is worse than a default one.

**The palette is in the cache key, not beside it.** The procedural cache is
content-addressed and shared across games, so a red postbox and a green one must not
collide on one file. It enters the digest only when present, so everything already
generated keeps its filename — verified by a test that an absent palette hashes exactly
as before, and that a malformed colour degrades to that same file rather than a third
one.

**One colour is derived rather than slotted.** A door has four colours and three slots:
the plank highlight is the leaf catching light, not an independent decision. Left as a
constant it stayed orange under blue paint, which reads as a rendering fault rather than
a design choice.

**Defensive parsing.** The contract's pattern rejects malformed hex, but a spec can
reach the builder from a preserved artefact or a hand-written fixture where it never
applied. A builder that raised there would fail a whole world over a colour.

## Where it is applied

Entities, scatter species, and — deliberately — the **last-resort floor**, the sized box
produced when every tier has already failed. That box is the one a viewer is most likely
to actually see, so it is the single place the planner's colour matters most: it is the
grey box in the render.

## Consequences

- The grain from ADR-0010 still works unchanged: glTF multiplies `baseColorTexture` by
  `baseColorFactor`, so the noise modulates whatever colour is in the slot. That
  property is exactly why the palette can be a factor rather than a texture.
- Twelve builders gained an optional argument; a test builds every one of them with and
  without a palette and asserts both the digest and the bytes differ, so a form that
  silently ignored the argument cannot pass.
- The `visual_semantic` validator has been the only gate objecting to these worlds, and
  it objected to *featureless* objects. Its verdict after this change is worth watching
  rather than predicting — a correctly coloured box is still a box, and the composition
  work (priorities #6–#8) is what it is really reporting on.
- The pattern is now used three times: the model names the form, the surface family, and
  the colour; deterministic code builds all three. That is rule 3.15 —  ambiguity up,
  determinism down — and it is worth stating that in each case the alternative
  considered and rejected was a table of nouns.
