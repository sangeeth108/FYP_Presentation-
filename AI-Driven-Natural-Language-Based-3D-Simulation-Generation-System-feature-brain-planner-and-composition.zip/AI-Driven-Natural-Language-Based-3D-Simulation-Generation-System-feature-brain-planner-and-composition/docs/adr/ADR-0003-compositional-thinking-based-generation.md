# ADR-0003 — Compositional ("thinking-based", unique) generation over vetted parts

- **Status:** Accepted — all 4 team members agreed (user-confirmed 2026-07-13); phased so v1 ships first. Phase A may start in v1 (it stays schema-validated + template-bound).
- **Date:** 2026-07-13
- **Deciders:** All 4 team members
- **Extends:** ADR-0001 (this is the named "v1.0+ slot-filling / behavior-graph roadmap" consequence) and ADR-0002.

## Context

The team wants the system to be **not only template-based but also "thinking-based" and to
produce genuinely unique results** — each game/experience reasoned and distinct, not a
relabelled copy of one base template. This must NOT sacrifice the core guarantees (playable,
editable, non-crashing) or the research thesis ("ambiguity up / determinism down"), and
LLM-authored gameplay code stays banned (CLAUDE.md §3 rule 10).

The apparent conflict ("templates" vs "thinking") dissolves once we see that the LLM's
creativity can live at **different layers**, from safest to riskiest:

| Layer | What the LLM controls | Safety | Uniqueness |
|---|---|---|---|
| L1 template-id select | picks from a fixed menu | total | low |
| L2 parameter fill | sets `@export` values | total | some |
| **L3 composition** | **combines vetted atoms into novel graphs/specs** | **high (atoms vetted, schema-validated)** | **high** |
| L4 gated adapter code | small non-authoritative code, 5-step promotion gate | bounded | high |
| L5 free code | arbitrary gameplay code | none — **banned** | high |

v1 lives at L1–L2. "Thinking-based unique" is **L3**, with **L4** as the escape hatch for the
rare novel bit no composition covers. L5 stays banned — it is exactly what destroys reliability
AND the dissertation's comparative result (ablation A: one-shot free generation is the baseline
we expect to beat, not become).

## Decision (proposed, phased)

**The LLM's creativity moves UP to composition, not DOWN into raw code.** The atoms stay
deterministic and vetted; uniqueness comes from how the LLM *reasons about combining* them.

- **Phase A — richer authored spec (in v1 scope, safe, buildable now):** let the planner author
  much more of the *frozen* `game_spec` via guided JSON — choose interactables per zone, compose
  the objective chain, tune per-enemy stats, place props — instead of only emitting a small Brief
  that patches a fixed base. Still 100% schema-validated and template-bound, so every guarantee
  holds; but the LLM is now genuinely *designing* the game, so outputs become far more unique.
- **Phase B — behavior-graph composition (v2):** vetted behavior/component **nodes** (patrol,
  flee-when-hurt, on-pickup-aggro, timed-gate, …) that the LLM wires into novel behavior graphs
  per game. Each node is tested; the graph is the LLM's unique "thought". Node-graph, not code.
- **Phase C — gated adapter (already in ADR-0001):** for genuinely new logic, the LLM may propose
  small non-authoritative adapter code that must pass the 5-step promotion gate before it runs.

## Alternatives considered

| Alternative | Why rejected |
|---|---|
| Stay L1–L2 forever | Outputs feel templated/repetitive — fails the "unique" objective |
| Jump straight to L5 free code | Destroys playability/editability guarantees and the research contribution |
| Do L3/L4 in v1 | Blows the dissertation deadline; v1 must prove the base thesis first |

## Consequences

- **Positive:** the system becomes genuinely generative and unique while staying safe and
  editable; "ambiguity up / determinism down" is preserved (ambiguity rises to composition);
  stronger research story (compositional control) than fixed templates.
- **Negative / accepted:** more validation surface (composed graphs need their own solvers in the
  8-gate stack); Phase B is real v2 engineering, not a v1 toggle.
- **Guardrail:** L5 (free gameplay code) remains permanently banned. "Thinking-based" never means
  "unvalidated code" — it means reasoned composition of vetted, tested parts.
