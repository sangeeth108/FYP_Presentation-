# ADR-0005 — The player has a body: spec v2.1.0 `player.asset_brief`

- **Status:** **Accepted.** User-directed and user-approved (2026-07-17); the **team approved the change** (relayed by the user, 2026-07-17), satisfying the two-person review + design sign-off that `docs/SCOPE_FREEZE_MEMO.md` §61 and `contracts/README.md` require. Recorded here as the sign-off record.
- **Date:** 2026-07-17
- **Deciders:** Team (approval), User (direction), Claude (implementation).
- **Extends:** ADR-0001 (asset resolution tiers), ADR-0003 (LLM creativity at safe layers), ADR-0004 (activity-driven animation/audio)
- **Relates to:** CLAUDE.md §3 rule 15 ("ambiguity up / determinism down"), §7 S5

## Context

The user's direction: *"when player tell as a dog i want to explore the village, then character is dog"* — and, explicitly, **as a system, not as a special case for dogs.**

Three facts stood in the way.

1. **The player had no identity at all.** `player` carried `controller_template_id`, `move_speed`, `health`, `verbs` — and `additionalProperties: false`. There was no field in which "a dog" could be written. Every player was an untextured capsule, whatever the prompt said. This was not a bug in the planner; the sentence was *unrepresentable in the contract*.
2. **The asset farm's output could not reach the game** (fixed first, see the CHANGELOG entry for `shippable_models`). The farm generated QA-passing GLBs, recorded them in lineage, and the build shipped the curated kit anyway. Without that seam, a player identity would have been a string that changed nothing.
3. **The schema is frozen.** v2.0.0 was frozen at the P0 gate; §61 requires a version bump, N-1 validator support, and a two-person review for any field change.

## Decision

**v2.1.0 adds one optional field: `player.asset_brief`** (`$ref` the existing `asset_brief` def, category `character`).

1. **Additive and backward-compatible.** `schema_version` moves from `const: "2.0.0"` to `enum: ["2.1.0", "2.0.0"]`, so N-1 is satisfied by construction and the untouched golden spec still validates — there is a test asserting exactly that.
2. **Only the LLM path sets it.** Reading "as a dog" out of free text is precisely the ambiguity the planner exists for (rule 15). Rules mode never invents a body, so it stays byte-identical to the legacy builder and the equivalence guard is untouched.
3. **It rides the existing Content Designer call** — same guided-JSON request that already authors enemy character briefs. No extra latency, no new agent, and `player_brief` is `required` in that guided schema so the model must answer.
4. **A missing or junk body costs the player a body, never the game.** Hard-failing would throw away the props and enemy roster with it. The capsule is a working fallback; the world is not worth losing over a cosmetic field. Category is forced to `character` whatever the model claims, and `tri_budget` is clamped.
5. **A spec that uses a v2.1 field must say it is v2.1.** The chain patches `schema_version` alongside the brief, so the record can never quietly lie about which contract it was written against.
6. **The player resolves through the same farm as everything else** (`player:main`), with **no curated fallback** — the stand-in is a primitive capsule, not a model.

That last point forced a better rule elsewhere. The shipping policy had hardcoded `label.startswith("enemy:")`; the player made the real principle obvious:

> **A generated asset must be at least as ALIVE as the thing it displaces.**

One rule, no roles named: a prop displaces a static prop, so a unique generated one always wins; an enemy displaces a *rigged, animated* skeleton, so a raw unrigged mesh loses (right species and dead vs. wrong species and alive — take alive); a player displaces a bare capsule that never animated anyway, so a generated body wins because **there is no motion to lose**.

## Consequences

**Good**
- "As a dog" is now representable, resolvable, and visible: the player wears a generated body and the capsule is gone (verified end to end with the mock backend).
- The aliveness rule is self-adjusting in both directions. When auto-rigging lands, generated *enemies* start shipping with no code change. When the player gains a rigged curated body, the same rule automatically starts demanding rigging of generated *players*. Neither needs a human to remember.
- No new agent, no new LLM round-trip, no latency cost.

**Bad / accepted**
- **The generated player is currently a statue** — right species, no motion. This is acceptable *only* because the thing it replaces (a capsule) never animated either, so nothing is lost. It is not the destination. Animation for generated characters needs rigging + retargeting (UniRig), and until that exists "the character is a dog" means it *looks* like a dog.
- One more field for every consumer to understand, and a governance debt (the sign-off) until reviewed.

**Explicitly NOT decided here**
- How a generated character gets *animated*. That is the next and hardest problem, and ADR-0004's activity seam is deliberately the place it will plug into: nothing in `ai_patrol_chase.gd` cares whether its clips are curated or retargeted.
- Generated per-character *sound*. `audio.cue_sheet` already exists in the schema (annotated "max clip 47s (Stable Audio Open)") and needs **no** schema change — so it is not part of this bump.
