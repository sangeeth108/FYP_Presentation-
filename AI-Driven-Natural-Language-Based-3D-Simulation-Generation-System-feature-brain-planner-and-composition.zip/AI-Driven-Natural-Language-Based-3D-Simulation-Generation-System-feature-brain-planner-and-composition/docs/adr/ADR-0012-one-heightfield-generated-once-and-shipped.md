# ADR-0012 — One heightfield, generated once and shipped

**Status:** accepted · **Date:** 2026-08-20 · **Phase:** P4

## Context

The ground was a single flat slab, and `docs/IMPLEMENTATION_PLAN.md` listed
"terrain heightfield: seeded noise, slope/water/region masks" as Tier 1 — work the
report describes as delivered.

The assumption was written down in **five** places, not the three the plan
identified. The last two only surfaced when a plan was actually solved on relief:

| Where | What it asserted |
|---|---|
| `pcg/semantic.py` | `support = {"type": "terrain", "contact_y_m": 0.0}` |
| `pcg/scatter.py` | `ignored = ["slope_max_degrees"]` — a slope limit on a plane is meaningless, not satisfied |
| `simulation_project_writer.py` | ground emitted as `BoxMesh` + `BoxShape3D` |
| `pcg/semantic.py` validator | `INVALID_TERRAIN_SUPPORT` if a body's underside is not at `y=0` |
| `_zone_geometry` | zone bounds `min[1] = 0.0`, and `_contains` checks all three axes |

Two runtime rules written earlier in the same phase also depended on it: the
`pickup_carry_drop` drop height and the `vehicle` exit height each cached a ground
height and restored it later, both with comments saying this was valid only while
the ground was flat.

## Decision

**The heightfield is generated once, in Python, and travels with the world plan as
data. Nothing regenerates it.**

`pcg/terrain.py` owns the generator and the sampler. `world_plan.json` carries a
`terrain` block — extent, grid, amplitude and a row-major array of heights in
metres. Placement, scatter, the validator and `terrain_field.gd` in the engine all
sample that one grid.

## Alternatives considered

**Generate in the engine with `FastNoiseLite`, mirror the same noise in Python so
placement can agree.** Rejected, and this is the decision the ADR exists to record.
It ships no grid, but requires two implementations of the same field to match bit
for bit forever — one in Python deciding where every prop sits, one in GDScript
deciding where the ground is. They agree until the first divergence, and then every
prop in the world is floating or buried **with nothing to report it**, because each
side remains internally consistent with itself. No validator can catch a
disagreement between two authorities that each believe they are right.

**Ship a heightmap image.** Rejected: Godot needs an import pass for image
resources, which the headless build would have to run and the runtime would have to
decode, for no gain over an array the plan already carries.

**Keep amplitude small enough that a single contact height seats any box.**
Rejected on measurement — see below. It works, and it makes the feature pointless.

## Consequences

- Amplitude is derived from `world_kind` and `terrain_surface`, which the planner
  already supplies, so no new spec field. `concrete`, `metal` and `wood` are flat,
  because a concrete yard with rolling hills is a fault rather than a style;
  `indoor` and `mixed` are flat outright, since a building's floor cannot follow a
  hillside without the walls leaving the ground.
- Capped at **2.5 m** regardless of world size. The navmesh bakes
  `agent_max_climb = 0.5` and `agent_max_slope = 45`, and `navigation_reachability`
  is a mandatory gate: relief must not be able to fail a run that would otherwise
  pass. Measured on a 60 m world: median slope 5.4°, maximum 28.2°.
- The **grid** is capped, not the cell size. A 1000 m world at 2 m spacing would be
  251k floats to ship, hash and diff, for relief a player reads over tens of metres.
- Pure Python. `numpy` is installed but is not a declared brain dependency and
  `pcg/scatter.py` runs on `random` alone.
- The lattice hash is a splitmix mix, **not** Python's `hash()`, which is randomised
  per process — the same prompt would otherwise grow different hills every run.
- `INVALID_TERRAIN_SUPPORT` became a stronger check, not a looser one: a body's
  underside must match the sampled ground under it, which is what "supported by the
  terrain" means and is what catches a prop left floating above a hill.
- A flat world takes a **byte-identical** path through the writer, so
  `test_native_writer_is_byte_stable` still describes indoor worlds, built surfaces
  and any plan preserved through a repair.
- `terrain_field.gd` is the eighth script permitted to execute in a generated
  project. It generates nothing; it reads the plan and builds a mesh, then builds
  the collider **from that mesh** so the two cannot drift apart.

## Pads: the part measurement forced

Placement gives an entity **one** contact height. On the first version of the field
— 12 m features, 2.1 m amplitude over a 60 m world — the ground under a footprint
varied by more than the object could absorb:

| Footprint | Height spread across it |
|---|---|
| bench 1.8 × 0.6 m | 0.63 m |
| house 8 × 6 m | 2.16 m |
| hall 24 × 16 m | 3.08 m |

A corner either floats or is buried by that much. Holding a house inside 0.15 m
would need amplitude down around 0.4 m over 60 m, at which point the slope masks
this whole item exists to feed can never exclude anything.

So the ground keeps real relief and footprints get **pads**: the cells under a
placed entity are levelled and blended into the field. Two overlap rules, each
arrived at by measuring the alternative:

- **Averaging overlapping pads** made things worse. A house whose blend ring met a
  hall's came out *less* level than before either pad existed — 0.670 m of spread
  became 0.846 m — because neighbours pull each other off level through their rings.
- **Nearest pad wins** left a bench standing against a 14 m barn taking those cells
  outright, since its pad covers them fully while the barn's only reaches them at
  the edge, leaving the barn 0.208 m of spread under its wall.

Final rule: **largest footprint first, a cell it fully owns is final, otherwise the
pad covering a cell most governs it.** Big structures define the ground and props
sit on what they find, which is also the right way round physically. Result on the
same field: house, barn and hall all 0.000 m; the bench absorbs 0.056 m, which is
the right object to put the residual on.

Pad levels are all read from the unpadded field and processing is ordered by
descending area, so the output is reproducible whatever order the caller supplies.

## Verification

Cross-checked in Serendib headless rather than reasoned about. A written project on
a real field, with a downward ray from every body:

| Check | Result |
|---|---|
| Planner's `contact_y_m` vs the engine's ground | **0.0000 m** for every body, all hitting `Ground` |
| Ground mesh | `ArrayMesh`, 3,200 triangles, synthesised material preserved |
| Collider | `ConcavePolygonShape3D`, built from the visual mesh |
| Entities on relief | houses at +0.97, +1.26, +0.21, −1.01 |
| Scatter | y −2.20..+1.91, every instance on the ground, x/z unchanged |
| Crate carried uphill and dropped | lands at 2.0 on the raised ground; the cached rule would have buried it at 0.0 |

Triangle winding was inverted on the first attempt, and only the engine could say
so: `create_trimesh_shape()` has backface collision off, so a ray cast straight
down passed **through** the ground and reported nothing. Culling and collision share
the winding, so the ground was also invisible from above — and the Python side had
no way to know.

## Still open

**Water and region masks.** The register asks for "slope/water/region masks" and
this delivers slope. Water is deliberately not attempted: deriving it from the
open-vocabulary `terrain` string is the keyword-matching antipattern
`simulation_spec.schema.json` explicitly warns against in its `terrain_surface`
description. It needs a contract field that does not exist — the same shape of gap
as the absent asset-descriptor `material` field recorded in
[ADR-0010](ADR-0010-surfaces-are-synthesised-from-a-named-family.md).
