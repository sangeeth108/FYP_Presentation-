# ADR-0007 — How a generated character moves: the capability ladder

- **Status:** Accepted (research + architecture). User-directed 2026-07-17: *"i want my system match solution. research and find it"*.
- **Date:** 2026-07-17
- **Deciders:** User (direction), Claude (research + implementation)
- **Extends:** ADR-0004 (activity seam), ADR-0005 (the player has a body, the aliveness rule), ADR-0006 (generated sound)
- **Relates to:** CLAUDE.md §3 rules 10/12/15, §4 (32 GB sequencing), §14 (product-path licences), the pre-agreed cut list ("UniRig characters")

## Context

Everything is in place except motion. A prompt can name a character (ADR-0005), the farm can build its mesh, the curated tier can find one we own (S5 ≥0.85), and it can sound like itself (ADR-0006). But a generated character is a **statue**, so the aliveness rule holds it back and a curated skeleton ships instead. That rule is right, and it is also the whole remaining problem.

The chain is **mesh → rig → clips**. Mesh is solved. So: what solves rig, and what solves clips?

## Research (2026-07-17, primary sources)

**Rigging — solved, and product-safe.**

[UniRig](https://github.com/VAST-AI-Research/UniRig) (VAST-AI/Tripo + Tsinghua, SIGGRAPH 2025) predicts a skeleton **and** skinning weights for arbitrary meshes.

| | |
|---|---|
| Licence | **MIT — code *and* [weights](https://huggingface.co/VAST-AI/UniRig)** → product path OK under §14 |
| VRAM | ~8 GB → fits the 32 GB box, sequenced beside TRELLIS (≥24 GB), never co-resident |
| Speed | **1–5 s** inference (vs. 1–20 min for prior work) |
| Coverage | humans, **animals/quadrupeds**, fictional, inorganic (Rig-XL, ~14k rigged models) |
| Output | skeleton + skinning weights, **FBX/GLB** → drops straight into our GLB pipeline |
| Blender | optional |

It is on the pre-agreed cut list, but nothing about it is prohibitive. **It is the right tool and it is available.**

**Clips — NOT solved. This is the finding that matters.**

1. **UniRig produces no animation.** It rigs; it does not move. Its predicted joints carry **coordinates, not semantic names** — the tokenizer recognises known templates (e.g. `mixamo:body`) and the paper notes that *"knowing that a bone belongs to a specific template (e.g. Mixamo) allows for efficient motion retargeting"*, but an arbitrary creature's joints are unlabelled. **Retargeting needs a bone correspondence, and for a novel topology there isn't one.**
2. **Product-safe text-to-motion for arbitrary creatures does not exist yet.** Topology-agnostic animal motion ([arXiv 2512.10352](https://arxiv.org/abs/2512.10352), OmniZoo, 140 species) is December-2025 research with no verified permissive weights. Human-only models (Tencent [HY-Motion](https://github.com/Tencent-Hunyuan/HY-Motion-1.0), SMPL-family) are either the wrong species or carry the exact licence shape this project **already quarantines** — Hunyuan3D-2.1 is research-only here for territory restrictions.

**The pragmatic third finding.** [Quaternius' Ultimate Animated Animal Pack](https://quaternius.com/packs/ultimateanimatedanimals.html) is **CC0** (commercial, no attribution), 12 animals × **12+ animations each** (Idle, Walk, Gallop, Attack, Death, Jump), in glTF. Those clips map **1:1 onto the activities already wired** in ADR-0004.

## Decision

**A capability ladder, arbitrated by the aliveness rule that already exists** (ADR-0005: *a generated asset must be at least as alive as the thing it displaces*). No new arbitration logic — the rule already picks the right rung automatically.

| Rung | Path | Motion | Status |
|---|---|---|---|
| **1. Own it** | curated **≥0.85** semantic tier | rigged + animated, instant, free | ✅ tier built; **needs the CC0 animal library** |
| **2. Make + rig + retarget** | TRELLIS → UniRig (template-conforming humanoids) → our 95 KayKit clips | full activity set | ⏳ next; humanoid-shaped only |
| **3. Make + rig + procedural** | TRELLIS → UniRig → **vetted GDScript** IK locomotion | approximate, deterministic | 🔭 the honest answer for novel topologies |
| **4. Make it, static** | TRELLIS only | none | ✅ today — props, and the player's capsule |

**Rung 1 is the answer to the question actually asked.** *"As a dog, explore the village"* does not need generation at all: a CC0 dog exists, rigged and animated, and the semantic tier already knows how to find it from the brief. Own it, then make it — a curated model is instant, licence-clear, rigged and animated, where a generated one costs GPU minutes and arrives dead.

**This is not a retreat to "template-based".** The system stays *thinking-based* where thinking belongs: the planner decides the genre, the goal, the world's contents, **who the character is**, and the art direction; the farm generates props and each character's **voice**. What the ladder adds is the discipline to *not* generate the one thing we can't yet generate **well** — and to be honest about which rung a game is standing on, in the lineage record.

**Rung 3 is deliberately named now**, because it is the only path that works for a genuinely novel creature and it is the one that best matches this system's philosophy: the LLM says *what* ("a crystalline golem"), and **vetted GDScript** — never generated code (rule 10) — decides *how* it moves, deterministically and seeded (rules 14/15). It plugs into ADR-0004's activity seam with no changes, because nothing in `ai_patrol_chase.gd` cares where its motion comes from.

## Consequences

**Good**
- The one thing standing between the prompt and an animated dog is a **CC0 download**, not a research programme.
- Every rung is product-safe: UniRig MIT, Quaternius CC0, KayKit CC0. No quarantine, no revenue threshold, no territory limit.
- The aliveness rule needs no change to arbitrate the ladder, and `mesh_capabilities()` already distinguishes *rigged* from *animated* — precisely the signal rung 2 vs. rung 3 turns on.

**Bad / accepted**
- **Rung 1 depends on what we own.** A species outside the library falls to rung 4 (static) until rung 2/3 land. The library is now the constraint, not the machinery — which is a far better problem than it was this morning.
- **Rung 2 only covers humanoid-shaped characters**, and depends on UniRig actually emitting template-conforming bones for them — *unverified*, and the first thing to test when the GPU work starts.
- Adding an animal family means adding its **sound set** too: `sound_family()` would otherwise default a dog to the skeleton's set and kill it with bone-clatter (ADR-0004's exact anti-goal). Generated sound (ADR-0006) covers this when enabled; the curated family must be added when the pack lands.

**Explicitly rejected**
- **Mixamo** for clips or auto-rigging — Adobe terms; and the golden-game template we build on says it plainly: *"Nothing from Mixamo, etc to muddy up the licensing waters."*
- **SMPL-family / Tencent motion models** in the product path — the same licence shape already quarantined here for Hunyuan3D-2.1.
- **Shipping a generated character as a statue** to claim the species. Right species and dead loses to wrong species and alive (ADR-0005), and rung 1 usually makes the choice unnecessary anyway.
