# ADR-0013 — One capability can cause another

**Status:** accepted · **Date:** 2026-08-20 · **Phase:** P4

## Context

Three capability manifests carried limitations that, read side by side, describe
the same missing mechanism in three different sets of words:

| Capability | What it said |
|---|---|
| `sensor_trigger` | "a sensor does not drive another entity — tripping it will not start a nearby machine" |
| `machine` | "process graphs relating one machine's output to another's input are not installed" |
| `dialogue` | "nothing said can change the world — talking to the guard will not unlock the gate they are warning you about" |

A capability's transition could not fire another capability's trigger. Every
generated world was therefore a set of objects that each worked correctly and
alone: a plate that knew it had been stepped on, next to a door that never heard
about it.

This is the difference between a place that is inhabited and a place that is
staged, and it was the highest-leverage gap left in the runtime.

## Decision

**A transition may emit triggers onto other entities, authored in the spec as
`causal_links` and compiled onto the transitions that bring the state about.**

```
"causal_links": [{
  "link_id": "lnk_plate_opens_door",
  "when": { "entity_id": "ent_plate", "capability_id": "sensor_trigger",
            "enters_state": "triggered" },
  "then": { "entity_id": "ent_door", "capability_id": "openable",
            "trigger": "interact" }
}]
```

Follows the house rule: the model says *what* causes what, deterministic code
decides how and refuses what it cannot verify.

## Alternatives considered

**Reuse the existing `effects` array.** Rejected. Its items are
`{property, value}` with `additionalProperties: false`, and it means *"what this
transition changes about itself"*. Causing something elsewhere is a different
statement, and folding both into one array behind a discriminator would have made
both harder to read. Transitions gained a sibling `emits` instead, **omitted when
empty**, so every graph without wiring serialises byte-identically to before and no
existing scene output changed.

**Attach the link to the state rather than the transition.** Rejected: it would
fire continuously while the state held. A sensor sitting in `triggered` while
somebody stands on the plate must open the door **once**, not once per frame.
Attaching to every transition that *arrives* at the state gives change semantics
for free.

**Refuse cycles at compile time.** Rejected. A machine that trips a sensor that
stops the machine is an oscillator — a world somebody might legitimately want. The
limit belongs in the runtime instead.

**Repair an unresolvable link by guessing the intended entity.** Rejected
outright. A wrong cause is worse than a missing one: the visitor watches the wrong
thing happen and believes it.

## Consequences

- Five distinct refusals, each with its own code so a repair can tell which end was
  wrong: `CAUSAL_LINK_UNRESOLVED`, `_STATE_UNKNOWN`, `_TRIGGER_UNKNOWN`,
  `_STATE_UNREACHABLE`, `_SELF_REFERENTIAL`. Nothing partial is ever wired — a
  world that *looks* wired and is not is harder to notice than one with no wiring.
- From the planner, an unresolvable link is **dropped and disclosed** as a
  user-visible approximation rather than failing an otherwise sound world. The
  model routinely writes a link against an entity it then renames or drops.
- The runtime caps chain depth at **8**, in a `static` counter shared by every
  machine in the scene, because a chain runs entity to entity rather than inside
  one node.
- A missing target at runtime is a loud `push_error`, not a shrug: the compiler
  refuses unresolvable links, so anything unresolved in the engine means the scene
  and the plan have diverged.
- Targets are found through the `serendib_entity` group and the `entity_id`
  metadata, not by node path — the path is derived from the id and reading it back
  would couple the runtime to the writer's naming rules.
- The three limitations now state what is genuinely still missing. For `machine`
  that is **quantities**: it consumes nothing and produces nothing, so a line of
  machines can be sequenced by cause while nothing is counted, stocked or depleted
  along it. A test asserts none of the old denials can return.
- This also unblocks `ecosystem_process`, the last capability with no binding,
  which needs exactly this mechanism plus a seeded tick.

## Verification

Probed in Serendib headless. Stepping on a plate, touching nothing else:

| | plate | door (14 m away) | press (20 m away) |
|---|---|---|---|
| before | idle | closed | off |
| stepped on | **triggered** | **opening** | **running** |
| stepped off | idle | opening | running |

Stepping off resets the plate and leaves both, because a link is a cause and not a
permanent binding.

### The loop test, which is the part worth recording

The first oscillator probe used two `openable` doors toggling each other. It
reported success and **proved nothing**: `openable` accepts `interact` from `closed`
and `open` but not from `opening`, so the state machine refused the second hop and
stopped the chain on its own, long before the depth cap was reached.

Exercising the cap required a ring of four links between two sensors, where every
hop lands in a state that accepts the next trigger:

```
A enters triggered -> B.sense      A enters idle -> B.reset
B enters triggered -> A.reset      B enters idle -> A.sense
```

That reports `"Serendib causal chain exceeded 8 steps; stopping to avoid a loop"`
and returns in **47 ms** instead of locking the frame. Had the first probe been
trusted, an unbounded chain would have hung a player's browser behind a guard that
was never running.
