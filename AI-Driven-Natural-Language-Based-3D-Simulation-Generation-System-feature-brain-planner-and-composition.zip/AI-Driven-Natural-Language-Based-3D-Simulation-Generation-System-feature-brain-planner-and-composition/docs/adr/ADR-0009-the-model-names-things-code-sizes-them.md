# ADR-0009 — The model names things; code sizes them

**Status:** accepted · **Date:** 2026-08-03 · **Phase:** P4

## Context

The planner is a language model asked to author geometry. Over a single day of
real runs it produced:

| declared | what it is | what it looked like |
|---|---|---|
| `[0.1, 2.1, 1.8]` | a front door | 1.8 m deep, lying on its side |
| `[0.1, 0.1, 1.8]` | a fence post | 0.1 m tall, a plank on the ground |
| `[0.4, 0.4, 8.0]` | a mature oak | felled |
| `[12.0, 8.0, 3.0]` | a house its own brief called "3 metres to the roof peak" | eight metres tall |

Every one of these is invisible in text and obvious in a picture. The model has
no picture. It was being asked to verify something it cannot perceive.

Eight rounds of prompt guidance were tried first — the axis convention stated in
the schema, then restated in the system prompt with worked examples. Behaviour
improved and never became reliable, because no wording gives a blind model a way
to check its own answer.

A related discovery matters here: schema `description` fields never reach the
model at all. The contract is passed to Ollama's `format` parameter, which
compiles structure into a grammar and discards prose. A convention documented
only in the schema is a convention nobody reads.

## Decision

Bounding boxes come from a canonical size table
(`services/brain/pcg/dimensions.py`), not from the model.

This applies CLAUDE.md §3.15 — *ambiguity up, determinism down* — to geometry.
Naming a thing is **what**, and the model is good at it. Sizing it is **how**,
and belongs in deterministic, testable code.

Three properties of the implementation are deliberate:

- **It corrects rather than overrides.** A declared size of the right shape and
  within 3× of canonical survives untouched, so a cathedral door stays 6.5 m. A
  table that flattened every door to 2.0 m would destroy real information.
- **It rescales by the longest dimension, never by volume.** The first version
  preserved volume and produced a 3.2 m door and a 2.7 m oak: when axes are
  scrambled the volume misleads, while the longest side survives an axis swap
  untouched. The tests caught this before it shipped.
- **Every correction is logged.** The planner's error rate stays measurable
  rather than being quietly absorbed — which matters for the ablation study,
  where "how often does the planner get geometry wrong" is a result.

## Consequences

**Good.** An entire defect class disappears at its source rather than being
clamped downstream. Placement, navigation and the visual critic all stop seeing
objects lying on their sides. Adding a kind is a data change.

**Cost.** The table must be extended for kinds it does not know; unknown kinds
pass through untouched, which is the safe default but means coverage is a
maintenance task. A wrong entry is now a systematic error rather than an
occasional one, so entries need review.

**Not addressed.** `local_offset_m` is the same problem in the same place — the
model authoring geometry it cannot check — and produced six defects of its own
(origin, magnitude, sign). The intended successor is a named face plus
alignment, with the transform computed from the parent's real dimensions. That
is the next decision, not this one.

## Alternatives rejected

- **More prompt guidance.** Tried eight times. Improves the average, never
  removes the failure, and cannot: the model has no way to verify the answer.
- **Validate and reject.** Turns a silent defect into a failed run. The
  information to fix it deterministically was available all along.
- **Let the vision critic catch it.** It does, eight minutes and a full Godot
  build later, using a model whose own reliability was one of today's problems.
