# ADR-0004 — Animation and audio are driven by the model's activities, from curated sets

- **Status:** Accepted — user-directed (2026-07-17): *"audio and animation want to be based on the models and activities. I gave a template, it also has sounds and animations."* **Amended by ADR-0006** (2026-07-17): decision 3 ("curated over generated for activity sound") held while every character was a curated skeleton — a *closed* cast. Once the planner can name an arbitrary character (ADR-0005), the set is no longer closed and there is no curated dog, so generation takes over per character with the curated set kept underneath as the floor. The principle here is unchanged; only the cast is.
- **Date:** 2026-07-17
- **Deciders:** User (direction), Claude (implementation)
- **Extends:** ADR-0001 (asset resolution tiers), ADR-0003 (creativity lives at safe layers)
- **Relates to:** CLAUDE.md §3 rule 10 (vetted templates own behaviour), rule 14 (seed everything), §7 S5 (asset resolution), §14 (licensing)

## Context

Two facts collided:

1. The curated KayKit skeletons ship **~95 animation clips each**, and the vetted AI template
   already performs real activities — patrol, chase, attack, hit, death. **Nothing played a
   single clip.** Enemies rendered as statues that slid around the floor. The gap was never
   missing content or a missing model; it was missing *binding*.
2. The team's own golden-game template (Cat Prisbrey's souls-like, Unlicense/public domain,
   Kenney CC0 upstream) already contains a full, licence-clean SFX library.

The planned P3 path for audio was **Stable Audio Open generation** (the S5 "generate" tier).
For enemy *activity* sound this is the wrong tool: the sounds needed are a small, closed,
knowable set (a strike, an impact, bones, a footstep) that must be **tightly synchronised with
a specific state transition**. Generation there buys unpredictability, VRAM contention, QA
risk and licence surface, and buys it for content we already own outright.

## Decision

**The activity is the interface.** Both animation and audio hang off the activities the vetted
GDScript template already performs — never off a separate "animation agent", never off
LLM-authored code, never off vision.

1. **Animation: the model decides what it can do.** Each activity carries a *best-first
   candidate list*; the template resolves it against the clips the model actually ships
   (`AnimationPlayer.get_animation_list()`). A model with fewer clips still animates. A
   generated TRELLIS mesh with no `AnimationPlayer` **stays static and never fails the build**.
2. **Audio: the model chooses the set, the activity chooses the clip.** `asset_kit.SOUND_SETS`
   maps a model family → activity → clips, in the *same one place* that already maps entities →
   models. What you hear matches what you see: a skeleton dies as **bones clattering**, not a
   fleshy thud. Adding a family (armoured knight → `hit_metal`) is a **data change, not a code
   change**.
3. **Curated over generated for activity sound.** The 13 CC0/public-domain WAVs are curated
   into `content/kits/catsfx/` and pass the **same `qa_audio` gate** any generated clip must
   pass — curated content is not trusted more than generated content, it is simply cheaper and
   already ours.
4. **Seeded variety** (rule 14): the clip variant is chosen from an RNG seeded by the node
   name, so it is reproducible from the spec alone and two enemies don't step in lockstep.
5. **Degradation is the design.** No sfx kit → no properties, no nodes, no references, a clean
   silent build. A half-copied kit is not a kit (`sound_files_exist` is all-or-nothing). Audio
   rides the same repair lever as the models, so the bare-build retry still strips everything.
   **Neither animation nor audio can ever block a build.**

Stable Audio Open is **not cancelled** — it keeps the S5 "generate" seam for what curation
genuinely cannot cover (per-game ambience, a bespoke prop's one-off sound). It is simply no
longer on the critical path for enemy activity audio.

## Consequences

**Good**
- Enemies are alive: they walk, run, swing, flinch, and collapse — the single largest jump in
  perceived quality per line of code so far, at ~1.2 MB (web export 45.72 MB / 90 MB budget).
- Zero new licence surface: public-domain assets the team already had, one ledger row,
  `check_licenses.py` PASS.
- The download promise strengthens: audio players are **real named nodes** (`Sfx`, `SfxSteps`)
  a user can see and retune in the editor — a beginning, not an end.
- No GPU cost, no VRAM contention with the planner, no QA-failure path at build time.

**Bad / accepted**
- Sound sets are hand-curated data. A genuinely novel creature ("a crystalline golem") falls
  back to the default set until someone adds a family. Accepted: a wrong-but-present sound
  beats silence, and the fix is one dict entry.
- Footsteps are timer-paced, not synced to animation method tracks. Accepted for now; the
  clips are locomotion loops and the pacing scales with real travel speed.

**Discovered while implementing (why this ADR is worth reading)**

The suite was green and the animation code *looked* correct, yet **two bugs made it nearly
worthless in a real build** — both found only by probing an actual headless Godot run:

- `_try_attack` force-replayed the swing **every physics frame**, restarting it at frame 0
  forever: the strike was permanently frozen on its first pose.
- The flinch was overwritten by locomotion on the **very next tick** — `Hit_A` was visible for
  under one frame.

Fix: a transient lock sized from the **clip's own length**, so a strike or flinch owns the
model until it finishes and then hands back to locomotion. **Lesson: for anything whose output
is time-based and visual, a passing unit test is not evidence it works. Probe the real build.**
