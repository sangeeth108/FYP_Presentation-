# Scope-Freeze Memo — PromptPlay 3D & Serendib Engine (v1)

**Status:** ✅ SIGNED / FROZEN — team-confirmed 2026-07-08 · **Date raised:** 2026-07-07 · **Owner:** All 4 members
**Purpose:** lock v1 scope before the deterministic spine (P1) begins, so no one reopens scope debates mid-project. Scope creep is a named top-10 risk; this memo is the countermeasure.

> Once all four members sign below, this scope is **frozen**. Any change requires a written amendment + a new ADR + all-four re-sign. "It's just one more genre/camera/feature" is exactly the failure this memo prevents.

---

## 1. One-sentence goal

> Type a game idea in plain language → play a stylized low-poly 3D game in the browser in minutes → download it as an editable Serendib Engine project and keep building.

## 2. In scope (v1)

- **Single-player only.** No multiplayer, no networking — locked.
- **Browser-playable** stylized low-poly 3D games (WebGL2 Compatibility renderer).
- **Four genres**, three cameras (below).
- One contiguous level per game · **50–200 props** · **5–25 enemies** · **3–8 minute** sessions.
- The full pipeline: prompt → `game_spec` → deterministic PCG → template-bound assembly → Serendib headless web export → validation + playtest bots → play URL + downloadable editable project.
- The brain (agents, RAG, guided decoding, arbitration, localized repair), asset farm, Serendib Engine rebrand + Serendib Assist dock, hybrid deployment — **added in their scheduled phases (P2–P3), not v1-day-one, but all inside v1 scope.**
- Full artifact lineage + validation reports + reproducibility for every generated game.

## 3. Out of scope (v1)

Multiplayer / networking · open-world scale · first-person (stretch only) · voice interaction · asset marketplace · photorealism · **deep Godot C++ engine changes (Tier 3 — banned)** · mobile-native export · **LLM-authored gameplay code** (only parameterized templates + gated adapter code).

**Pre-agreed cut list** (dropped first, in this order, if time runs short): TTS barks → UniRig characters → day-night cycle → module kit B → threaded web build.

## 4. Four supported genres (allowlist — the generative grammar)

| # | Genre id | One-line |
|---|---|---|
| 1 | `topdown_survival_escape_3d` | Survive/scavenge and escape (golden-game genre) |
| 2 | `arena_combat_3d` | Waves of enemies in a bounded arena |
| 3 | `collect_explore_3d` | Explore and collect objectives, low/no combat |
| 4 | `dungeon_crawl_3d` | Room-to-room crawl with enemies and objectives |

No fifth genre in v1. A new genre would need new templates + validation + re-testing — post-v1 only.

## 5. Three supported cameras (allowlist)

| # | Camera id | Notes |
|---|---|---|
| 1 | `third_person` | Follow camera behind the player |
| 2 | `top_down_3d` | Overhead; golden-game default |
| 3 | `isometric_3d` | Fixed-angle isometric |

## 6. Hard targets (non-negotiable for v1)

- **Single-player.** ✅ locked.
- **Browser-playable.** WebGL2 / Compatibility renderer; GDScript only (no C# web export); single-threaded export default (Safari/iOS reach).
- **≤ 90 MB web export**, post-Brotli. Achieved via mesh decimation + texture atlasing + resolution caps — **not** Draco meshes or VRAM-compressed textures (unsupported on Godot web). Enforced as a validator gate.
- Works on **Chrome, Firefox, Edge, Safari**.
- Navmesh + lighting baked at build time, never at web runtime.

## 7. Schema freeze rule

- The canonical contract is `contracts/game_spec.schema.json` (JSON Schema 2020-12), currently **DRAFT v2.0.0**.
- It is **frozen as v2 only when the golden game passes its P0 gate** (the golden game is the schema's first real-world test).
- After freezing: any schema change **bumps `schema_version`**; the validator must support **N-1**; changes require two-person review + a design sign-off.
- Allowlist membership (template/kit/animation IDs) is a **registry / constraint-gate** concern, not a schema concern — the schema validates shape, the registry validates catalog membership.

## 8. Team roles (for accountability on scope)

| Member | Owns |
|---|---|
| M1 Platform | frontend, API, queue, storage, deploy, /play hosting, user-study tooling |
| M2 Brain/ML | agents, schema, RAG, guided decoding, arbitration, repair, fine-tuning, eval |
| M3 Engine/Build | Serendib fork + rebrand, CI build matrix, AI dock, project writer, export, licensing ledger |
| M4 3D Content/Validation | module kits + curated packs, PCG + placement, asset farm, playtest bots, validators, metrics |

## 9. Sign-off

By signing, each member confirms the v1 scope above is understood and frozen, and agrees not to reopen it without a written amendment.

| Member | Name | Signed (date) |
|---|---|---|
| M1 Platform | __________________ | __________ |
| M2 Brain/ML | __________________ | __________ |
| M3 Engine/Build | __________________ | __________ |
| M4 3D Content/Validation | __________________ | __________ |

**Also record in `DECISION_LOG.md` when signed** (pending decision #3 / scope-freeze row) and tick the "Scope-freeze memo" task in `IMPLEMENTATION_CHECKLIST.md`.
