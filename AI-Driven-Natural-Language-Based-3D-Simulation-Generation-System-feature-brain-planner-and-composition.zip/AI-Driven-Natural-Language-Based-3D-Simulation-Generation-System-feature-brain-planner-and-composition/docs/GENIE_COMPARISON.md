# Serendib vs. Google Genie — positioning & feature map

**Status:** research note (2026-07-29). Reference project: Google DeepMind **Genie** family.
Purpose: state honestly how Serendib/PromptPlay 3D relates to Genie, which Genie
capabilities we deliberately emulate, which we structurally cannot (and should not),
and the concrete, in-scope feature backlog this comparison produces for the dissertation.

---

## 1. What Genie is

| | Genie 1 (Feb 2024) | Genie 2 (Dec 2024) | Genie 3 (Aug 2025) |
|---|---|---|---|
| Output | 2D platformer frames | Playable **3D** world | Real-time **3D** world |
| Prompt | Image / text | **Single image** | **Text** |
| Fidelity | Low-res 2D | ~360–720p | **720p @ 24 fps** |
| Consistency | seconds | ~10–60 s | **~1 minute** visual memory |
| Control | latent actions | keyboard/mouse | keyboard/mouse |
| Headline feature | learned latent action model (unlabelled video) | physics, NPCs, off-screen memory | **promptable world events** (inject weather/objects/changes via text mid-session) |
| Stated goal | generative interactive environments | foundation world model | training embodied agents → AGI |

**How it works:** Genie is a **neural world model**. A video autoencoder plus an
autoregressive transformer in latent space predict the *next frame* given the prompt
and the user's action. The "world" is pixels sampled frame-by-frame at runtime.

**What that implies (the important part for us):**
- There is **no engine, no scene graph, no assets, no code** — nothing to open or edit.
- Memory is bounded (~1 min); walk away and back and the world can drift.
- There is **no verification**: the model can hallucinate physics, geometry, or identity;
  correctness is whatever the network happens to render.
- You cannot download it, ship it, or run it offline — it is a hosted model.

## 2. What Serendib is

Serendib/PromptPlay 3D takes the **same user promise** — *type an idea, get an
explorable interactive 3D world* — and makes the **opposite architectural bet**
("ambiguity up / determinism down", CLAUDE.md §3):

- The LLM decides **what** (a schema-bound `SimulationSpec`: entities, world, capabilities,
  requirements). It never renders anything.
- Deterministic, seeded code decides **how**: semantic PCG places a real world, vetted
  GDScript templates bind behaviour, real GLB assets are resolved/generated, and the
  **Serendib engine (Godot 4.x fork)** exports a **WebGL build + a downloadable, editable
  engine-native project**.
- Every artifact is **verified** before publish (18-layer release contract: schema,
  capability, behaviour compile, asset geometry, semantic placement, requirement
  traceability, deterministic critic, **independent model critic**, **visual-semantic
  vision critic**, runtime probe, desktop/web parity, export).

## 3. Head-to-head

| Dimension | Google Genie | Serendib | Winner for our users |
|---|---|---|---|
| Time-to-first-world | seconds (neural) | minutes (plan→build→verify) | Genie |
| Visual variety / realism | very high (neural) | stylized low-poly | Genie |
| **Editability** | none (pixels) | **full engine project** | **Serendib** |
| **Persistence / consistency** | ~1 min, can drift | permanent (real scene) | **Serendib** |
| **Ownership / offline / download** | hosted only | **downloadable, self-hostable** | **Serendib** |
| **Real physics & determinism** | learned, approximate | engine physics, seeded, reproducible | **Serendib** |
| **Verifiable correctness** | none | **8/18-gate verification + lineage** | **Serendib** |
| Real-time free-roam camera | yes | 3 fixed cameras (v1 frozen) | Genie |
| Agent-training substrate | yes (its goal) | not a goal | Genie |

**Positioning statement.** Serendib is *not* a Genie competitor on neural realism or
latency — and should not try to be. Serendib is **"Genie's promise, delivered as a real,
editable, verified engine project."** The differentiators are exactly the things a neural
world model cannot give: you can **open it, change it, own it, trust it, and ship it**.
Our vision/critic gates are the direct answer to Genie's core weakness — an
un-verifiable world that can silently drift or hallucinate.

## 4. Genie-inspired backlog (in-scope, architecture-native)

Ranked by value × fit. Nothing here converts Serendib into a neural model; each item
uses existing machinery.

1. **Promptable world events** *(Genie 3 headline — strong fit).* The spec already models
   `world.weather`, `world.time_of_day`, and entity sets. A natural-language edit
   ("make it rain", "add three deer", "night time") becomes a **localized typed patch**
   to the current spec, re-validated and re-materialized through the existing
   `repair/typed_patches.py` + Serendib Assist edit round-trip. This is the P3 AI-dock
   feature reframed as Genie-style live world mutation — but persistent and verified.
2. **Objective-free explorable worlds** *(Genie's signature — already supported).* Not
   every prompt is a game; some are pure exploration. Represented today via
   `world_kind` + the `req_explorable` requirement, with no forced combat. Keep this
   first-class and prompt-driven (a "world", not always a "game").
3. **Image-conditioned intake** *(Genie 2/3 accept an image — medium fit, larger).*
   Accept an optional reference image at S0/S1 to bias palette/theme/layout of the plan.
   Uses the already-installed vision model to caption/ground the image into the brief.
4. **Free-roam explore camera** *(Genie is first-person free-roam — GATED).* v1 cameras
   are frozen to three (CLAUDE.md §1). A free-explore camera is a **scope decision for the
   owner**, not a unilateral change.

**Explicitly not adopted:** neural frame generation, agent-training substrate, and
"realism over ownership" — they contradict the core promise (an editable engine-native
project) and the v1 scope freeze.

## 5. Dissertation framing

This comparison is itself a dissertation asset: it defines the competitive niche
(verified, editable, ownable generation vs. un-verifiable neural rendering) and motivates
the verification stack as the central contribution. The ablation study should report the
verification gates (schema/placement/critic/vision) as *the* thing that distinguishes a
Serendib world from a Genie clip.
