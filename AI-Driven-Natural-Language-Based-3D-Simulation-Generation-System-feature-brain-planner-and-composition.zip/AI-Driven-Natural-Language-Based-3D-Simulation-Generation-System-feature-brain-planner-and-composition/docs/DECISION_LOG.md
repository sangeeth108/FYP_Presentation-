# Decision Log

Lightweight record of decisions. Major technical decisions also get a full ADR in `docs/adr/`. Newest first.

| Date | Decision | Why | Who | ADR |
|---|---|---|---|---|
| 2026-07-20 | Correct the active engine pin to upstream `4.6.3-stable`; earlier `4.7-stable` claims are invalid historical records, not reproducible evidence | Official upstream verification found 4.6.3 stable; an unverified/non-existent tag cannot support a release | Serendib engineering | Revisit only through a tested upstream rebase |
| 2026-07-09 | **P0 GATE MET → `game_spec.schema.json` FROZEN as v2.0.0.** Golden game passed all sign-off boxes (start-to-win, 77 MB ≤ 90, Chrome/Firefox/Edge/Safari + mobile, spec validates, lineage recorded — user-confirmed). **CI-build waiver:** the golden game is a standalone gitignored project (`Templates/`), so CI cannot build it; the local pinned-editor (4.7-stable) headless export with zero errors is the accepted P0 evidence. CI-built becomes mandatory from P1, when project-writer output lives in-repo | Gate rule says freeze at pass; waiver keeps the repo lean without weakening the P1+ CI requirement | User + Claude Code | — |
| 2026-07-09 | Golden game = **"Castle Gate Trial"**, genre `arena_combat_3d`, camera `third_person`, base = "Godot 4 Souls-Like Template" by Cat Prisbrey (Unlicense, asset-library #2609) + team-added `WinZone` win trigger (lever → unlock door → reach zone) | Working, license-clean (public domain) souls-like base already runs on 4.7-stable + GL Compatibility; fastest honest path to the P0 gate. Resolves pending decision #6 | User + Claude Code | — |
| 2026-07-08 | Scope-freeze **signed** (team-confirmed); cloud VPS deferred to P3 (no spend now — local Docker through P2) | Lock v1 scope before the spine; avoid cloud cost while it isn't needed | All 4 members | — |
| 2026-07-08 | Pinned planner `Qwen/Qwen3.6-27B` (Apache-2.0) | Latest Apache-2.0 dense Qwen at project time; verified on HF model card; vLLM + guided-JSON/tool-call; one model covers planner + gated adapter (VRAM-friendly). Fine-tune student (P4) stays a smaller Qwen dense, TBD then | Team (user-approved) + Claude Code | — |
| 2026-07-07 | Pinned Godot `4.7-stable` + Emscripten `4.0.11` | Latest stable at project time; Emscripten taken from Godot's own CI at that tag (authoritative, avoids the #1 web-build failure); basis for the Serendib rebrand build | Team (user-approved) + Claude Code | pending ADR-0002 |
| 2026-07-07 | Repo root = `promptplay/`; `ReferenceDocuments/` kept outside git | Matches README clone instructions + keeps CLAUDE.md at repo root; PDFs are source material, can be added to `docs/reference/` if versioning is wanted | Claude Code (confirm) | — |
| 2026-07-07 | P0 completion pass: golden-game plan, service skeleton plans, CI skeleton, brain Dockerfile skeleton; git initialized + first commit | Close remaining P0 scope; version control from day 1 | Team + Claude Code | — |
| 2026-07-07 | Monorepo scaffold + docs created; P0 started | Foundation for AI-assisted implementation | Team + Claude Code | ADR-0001 |
| 2026-07-07 | Planning report v4.0 + Implementation Checklist adopted as source of truth | Consolidated, source-verified planning documents exist in `ReferenceDocuments/` | Team | — |
| (from report) | v1 = single-player, 4 genres, 3 cameras, ≤90 MB WebGL2 — FROZEN | Scope discipline; dissertation core | All 4 members | ADR-0001 |
| (from report) | Golden-game-first; deterministic spine before brain | De-risks web export + gives specs a working target | All | ADR-0001 |
| (from report) | LLM never writes gameplay-critical code; template-bound scripting | Reliability/safety core property | All | ADR-0001 |
| (from report) | pgvector on existing Postgres (no separate vector DB) | Cost + ops consolidation for a 4-person team | All | ADR-0001 |
| (from report) | GPU worker outbound-only (Tunnel/Tailscale) | Home-network security | All | ADR-0001 |
| (from report) | FLUX.1[dev] + Hunyuan3D-2.1 quarantined to research | Non-commercial / territorial licenses | All | — |
| (from report) | Bots read state via debug singleton, never vision | GlitchBench 43.4% vision ceiling | All | — |

## Pending decisions (need user/team input — not blocking P0 scaffold)

| # | Decision needed | By when | Notes |
|---|---|---|---|
| 1 | ~~Exact pinned Godot tag + Emscripten~~ | ✅ **RESOLVED 2026-07-07** | **Godot `4.7-stable`** (latest stable, 2026-06-18) + **Emscripten `4.0.11`** (from Godot CI `web_builds.yml` @ tag). Recorded in `.env.example`, `upstream-notes.md`, `GODOT_BUILD.md`, ledger |
| 2 | ~~Exact Apache-2.0 Qwen planner + coder SKUs~~ | ✅ **RESOLVED 2026-07-08** | **`Qwen/Qwen3.6-27B`** — Apache-2.0 verified on the HF model card; dense 27B, vLLM + tool-call/guided-JSON, 262K ctx. One model serves planner **and** the gated adapter-coder (replaces unconfirmed "Qwen3-Coder-14B"). Logged in ledger; `.env.example` `LLM_PLANNER_MODEL` set. Quantize (AWQ/GPTQ 4-bit) for the 32GB 5090 |
| 3 | ~~Budget tier + who pays~~ | ✅ **RESOLVED 2026-07-10** | **Low tier** through P2 (as recommended — $0 cloud spend, everything local), user-confirmed |
| 4 | ~~GitHub org name + repo visibility~~ | ✅ **RESOLVED 2026-07-09** | `pasindu-jayasena/AI-Driven-Natural-Language-Based-3D-Simulation-Generation-System` — live, CI green |
| 5 | ~~Serendib name clearance check~~ | ✅ **RESOLVED 2026-07-10** | Cleared by team (user-confirmed); revisit formally before any public/commercial launch (P3+) |
| 6 | ~~Golden game genre choice~~ | ✅ **RESOLVED 2026-07-09** | **`arena_combat_3d` — "Castle Gate Trial"** (souls-like castle courtyard escape; third_person). Base: Cat Prisbrey's Souls-Like Template (Unlicense). Spec: `contracts/examples/golden_game.spec.json` |
| 7 | ~~Team jurisdiction confirmation~~ | ✅ **RESOLVED 2026-07-10** | Confirmed as documented (user sign-off); DPIA/ethics track proceeds on that basis before any user study (P5) |
| 8 | ~~Beyond-games vision: domain-pack platform + user-data training~~ | ✅ **ACCEPTED 2026-07-13** (all-4, user-confirmed) — `docs/adr/ADR-0002` | Keep v1 frozen on games; education/visualization = post-v1 *domain packs* on the same engine; user-data training deferred + hard-gated behind DPIA/consent/pseudonymization (minors). SCOPE_FREEZE_MEMO stays in force for v1 |
| 9 | ~~"Thinking-based, unique" generation (not only templates)~~ | ✅ **ACCEPTED 2026-07-13** (all-4, user-confirmed) — `docs/adr/ADR-0003` | LLM creativity moves UP to *composition* (L3), not DOWN into free code (L5, permanently banned). **Phase A greenlit for v1**: richer LLM-authored spec via guided JSON over the frozen schema (safe) → Phase B: behavior-graph composition (v2) → Phase C: gated adapter. Preserves playability/editability + the thesis |
