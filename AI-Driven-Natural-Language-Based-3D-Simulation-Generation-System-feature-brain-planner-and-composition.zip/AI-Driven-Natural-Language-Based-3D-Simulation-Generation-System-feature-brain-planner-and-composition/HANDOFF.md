# HANDOFF — PromptPlay 3D & Serendib Engine

**Read this first when picking the project up on a new machine.** Last updated 2026-07-09 · **P0 GATE MET — Phase P1 (deterministic spine) underway** · branch `main`.

This is the session/state handoff. The full rules live in [`CLAUDE.md`](CLAUDE.md); the phase plan in [`docs/IMPLEMENTATION_PLAN.md`](docs/IMPLEMENTATION_PLAN.md); live task status in [`docs/IMPLEMENTATION_CHECKLIST.md`](docs/IMPLEMENTATION_CHECKLIST.md).

---

## 1. What this project is (10-second version)

Prompt → browser-playable stylized low-poly 3D game → downloadable **editable Serendib Engine** (rebranded Godot 4.x) project. AI writes only a canonical `game_spec` JSON; deterministic seeded code builds/validates the game; gameplay uses vetted GDScript templates (never AI-written). Single-player v1, 4 genres, 3 cameras, ≤90 MB WebGL2. See [`docs/PROJECT_OVERVIEW.md`](docs/PROJECT_OVERVIEW.md).

## 2. What has been DONE (P0)

| Area | Status | Where |
|---|---|---|
| Monorepo + all docs + CLAUDE.md | ✅ | repo root, `docs/` |
| Canonical schema v2 (**DRAFT** until golden game) + validator | ✅ | `contracts/`, `scripts/validate_contracts.py` |
| CI (contracts+licenses, brain w/ Postgres+Redis, web-lint) | ✅ green | `.github/workflows/ci.yml` |
| **Godot pinned:** `4.7-stable` + Emscripten `4.0.11` | ✅ | `docs/runbooks/GODOT_BUILD.md`, `.env.example` |
| **Planner pinned:** `Qwen/Qwen3.6-27B` (Apache-2.0) | ✅ | `docs/licensing_ledger.csv` |
| Next.js frontend: home/prompt + `/jobs/[id]` progress | ✅ builds | `apps/web/` |
| FastAPI hello-job: `POST /games`→Celery→`GET /jobs/{id}` | ✅ 8 tests | `services/brain/` |
| **Full Docker stack validated** (API→Redis→Celery→Postgres) | ✅ | `docker-compose.yml`, `scripts/verify_stack.sh` |
| VPS/tunnel infra (Hetzner Caddy, Cloudflare) | ✅ ready | `infra/` |
| Scope-freeze | ✅ signed | `docs/SCOPE_FREEZE_MEMO.md` |
| **Golden game (the P0 gate)** | ✅ **GATE MET 2026-07-09** — "Castle Gate Trial" (`arena_combat_3d`, souls-like base, Unlicense), 77 MB, 4 browsers + mobile pass | `docs/GOLDEN_GAME_TASKS.md` §13 |
| **Schema v2** | ✅ **FROZEN v2.0.0 (2026-07-09)** | `contracts/game_spec.schema.json` |
| **P1 PCG (brain-side S4)** | ✅ zone graph → layout → placement → `run_pcg(spec)`, 27 tests | `services/brain/pcg/` |

**P0 is done.** The golden game lives locally under `Templates/` (gitignored — standalone Godot project; see the CI waiver in `DECISION_LOG.md`). P1 focus: remaining PCG algorithms, Godot-side materialization (`services/worker/godot_client/`), controller templates, Serendib rebrand v0.1.

## 3. Locked decisions (do not silently change)

- Repo root **is this folder** (`promptplay/`). The planning PDFs (`ReferenceDocuments/`) live **outside** the repo and are **not cloned** — their content is already distilled into `docs/`. Copy them in only if you want them versioned.
- Godot **4.7-stable** + Emscripten **4.0.11** (exact pair — mismatch is the #1 web-build failure).
- Planner **`Qwen/Qwen3.6-27B`** (Apache-2.0); also serves the gated adapter-coder.
- Single sync backend stack: **FastAPI + SQLAlchemy 2.0 + psycopg v3 + Alembic + Celery/Redis**.
- v1 scope is **frozen** (`SCOPE_FREEZE_MEMO.md`). No 5th genre / first-person / multiplayer.
- **No cloud spend needed until P3** — everything runs locally on Docker for $0. See `docs/DEPLOYMENT_PLAN.md`.
- **Git rule (STRICT):** Claude Code must NOT `git commit`/`git push` without explicit per-action permission. Commits use the human identity, no Claude co-author. See `CLAUDE.md` §13.

## 4. New-machine setup

### Prerequisites
Git · Node 20+ · Python 3.11+ · (optional) Docker Desktop · (for the golden game) **Godot 4.7 stable** editor from godotengine.org.

### Clone
```bash
git clone https://github.com/pasindu-jayasena/AI-Driven-Natural-Language-Based-3D-Simulation-Generation-System.git promptplay
cd promptplay
cp .env.example .env      # .env is gitignored — it does NOT come with the clone. Windows PS: Copy-Item .env.example .env
```

### Sanity checks (no services needed)
```bash
pip install "jsonschema>=4.21"
python scripts/validate_contracts.py     # expect verdict PASS
python scripts/check_licenses.py         # expect verdict PASS
```

### Frontend
```bash
npm install                 # from repo root (workspaces)
npm run dev:web             # http://localhost:3000
npm run build:web           # production build (what CI runs)
```

### Backend — Option A: no Docker (fast; SQLite + inline Celery)
```bash
cd services/brain
pip install ".[dev]"
# bash / macOS / Linux:
DATABASE_URL="sqlite+pysqlite:///./dev.db" CELERY_TASK_ALWAYS_EAGER=true alembic upgrade head
DATABASE_URL="sqlite+pysqlite:///./dev.db" CELERY_TASK_ALWAYS_EAGER=true uvicorn main:app --reload
# Windows PowerShell equivalent:
#   $env:DATABASE_URL="sqlite+pysqlite:///./dev.db"; $env:CELERY_TASK_ALWAYS_EAGER="true"
#   alembic upgrade head ; uvicorn main:app --reload
python -m pytest            # 8 tests, no Docker needed
```

### Backend — Option B: full stack (production parity; needs Docker Desktop running)
```bash
# from repo root, with .env present:
docker compose up -d                 # postgres + redis + brain (migrates+serves) + celery
curl http://localhost:8000/healthz   # {"status":"ok"}  (first build can take ~1–2 min)
bash scripts/verify_stack.sh         # one-command end-to-end async check, then tears down
```
Then open http://localhost:3000, type a prompt → **Generate** → watch `/jobs/<id>` reach **Ready**.

### Golden game (the P0 gate — human task)
Download **Godot 4.7 stable**, then follow [`docs/GOLDEN_GAME_TASKS.md`](docs/GOLDEN_GAME_TASKS.md). You do NOT need to compile Godot from source for P0 (the official editor + its web templates satisfy the gate).

## 5. What's next

1. **Finish the golden game** → meet its gate (`GOLDEN_GAME_TASKS.md` §13).
2. Freeze `contracts/game_spec.schema.json` as v2; tick the golden-game row in the checklist.
3. Start **P1 (deterministic spine):** PCG zone-graph → GridMap materialization → navmesh+placement → controller/AI/door templates → project writer + headless export → Serendib rebrand v0.1. See `docs/IMPLEMENTATION_PLAN.md`.

## 6. Onboarding prompt for Claude Code on the new PC

Paste this to Claude Code after cloning:

> I've cloned the PromptPlay 3D & Serendib Engine repo onto a new machine. Read `CLAUDE.md` and `HANDOFF.md` first, then `docs/IMPLEMENTATION_CHECKLIST.md`. Follow the strict Git rule in CLAUDE.md §13 — do NOT commit or push without my explicit per-action permission; commits use my identity, no Claude co-author.
>
> Task: get my environment working here. (1) Confirm Git/Node 20+/Python 3.11+/Docker are present and tell me what's missing. (2) `cp .env.example .env`. (3) Run `python scripts/validate_contracts.py` and `python scripts/check_licenses.py` (pip install jsonschema first) — both must say PASS. (4) `npm install` then `npm run build:web` to confirm the frontend builds. (5) In `services/brain`, `pip install ".[dev]"` then `python -m pytest` (should be 8 passed). (6) If Docker is running, `docker compose up -d` and `bash scripts/verify_stack.sh` to prove the full stack, else use the SQLite no-Docker mode from HANDOFF.md §4. Report what passed/failed at each step and how to fix any failure. Do not start P1 — the golden game is my task; just get the platform side running and green here. Stop and summarize.
