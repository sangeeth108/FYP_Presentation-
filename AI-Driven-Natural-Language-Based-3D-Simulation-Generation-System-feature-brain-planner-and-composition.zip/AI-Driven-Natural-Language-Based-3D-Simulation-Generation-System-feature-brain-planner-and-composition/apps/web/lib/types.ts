// Shared frontend types. The genre/camera allowlists mirror
// contracts/game_spec.schema.json (meta.genre / meta.camera) — keep in sync.
// When the brain exposes generated types, replace these hand-written ones.

export const GENRES = [
  "topdown_survival_escape_3d",
  "arena_combat_3d",
  "collect_explore_3d",
  "dungeon_crawl_3d",
] as const;
export type Genre = (typeof GENRES)[number];

export const CAMERAS = ["third_person", "top_down_3d", "isometric_3d"] as const;
export type Camera = (typeof CAMERAS)[number];

// Human-friendly labels for the pickers.
export const GENRE_LABELS: Record<Genre, string> = {
  topdown_survival_escape_3d: "Survival / Escape",
  arena_combat_3d: "Arena Combat",
  collect_explore_3d: "Collect & Explore",
  dungeon_crawl_3d: "Dungeon Crawl",
};

export const CAMERA_LABELS: Record<Camera, string> = {
  third_person: "Third-person",
  top_down_3d: "Top-down",
  isometric_3d: "Isometric",
};

// Request/response shapes for POST /api/v1/games (see docs/API_DOCUMENTATION.md).
export interface CreateGameOptions {
  camera?: Camera;
  genre?: Genre;
}

export interface CreateGameRequest {
  prompt: string;
  seed?: number;
  options?: CreateGameOptions;
}

export interface CreateGameResponse {
  game_id: string;
  job_id: string;
}

export type SizeProfile = "auto" | "small" | "medium";
export type TargetPlatform = "web" | "desktop";

export interface CreateSimulationRequest {
  prompt: string;
  size_profile: SizeProfile;
  target_platforms: TargetPlatform[];
  seed?: number;
  domain_constraints?: Record<string, unknown>;
}

export interface CreateSimulationResponse {
  simulation_id: string;
  run_id: string;
}

export type SimulationRunState =
  | "queued"
  | "planning"
  | "compiling"
  | "building"
  | "completed"
  | "failed_requirements"
  | "failed_capability"
  | "failed_build"
  | "failed_validation"
  | "failed_export";

export interface SimulationRun {
  run_id: string;
  simulation_id: string;
  state: SimulationRunState;
  stage: string;
  detail: Record<string, unknown>;
  repair_attempts: number;
  max_repair_attempts: number;
}

export interface SimulationRecord {
  simulation_id: string;
  title: string;
  prompt: string;
  size_profile: string;
  target_platforms: string[];
  status: SimulationRunState;
  current_run_id?: string;
  spec?: Record<string, unknown>;
  world_plan?: Record<string, unknown>;
  artifacts: { kind: string; url?: string }[];
  approximations: Record<string, unknown>[];
}

export interface ValidationItem {
  layer: string;
  status: "PASS" | "FAIL" | "NOT_RUN" | "UNAVAILABLE";
  mandatory: boolean;
  validator: string;
  evidence: Record<string, unknown>;
  errors: string[];
}

/** One entry in the inspector's stage rail. No payload — that is fetched per stage
 *  so opening a run does not pull every scene spec and asset manifest it produced. */
export interface StageSummary {
  stage: string;
  ordinal: number;
  status: string;
  summary: Record<string, unknown>;
  errors: unknown[];
  model_id?: string | null;
  duration_ms?: number | null;
  edited: boolean;
}

export interface StageList {
  run_id: string;
  stages: StageSummary[];
}

/** A stage including the full output you inspect and can correct. */
export interface StagePayload extends StageSummary {
  payload: Record<string, unknown>;
}

export interface SimulationReport {
  simulation_id: string;
  run_id?: string;
  requirements: Record<string, unknown>[];
  world_plan_hash?: string;
  validation: ValidationItem[];
  approximations: Record<string, unknown>[];
  capability_gaps: {
    capability_id: string;
    status: string;
    detail: Record<string, unknown>;
  }[];
}

export type JobState =
  | "QUEUED"
  | "PLANNING"
  | "SPEC_FROZEN"
  | "BUILDING_LEVEL"
  | "RESOLVING_ASSETS"
  | "ASSEMBLING"
  | "EXPORTING"
  | "VALIDATING"
  | "DEPLOYED"
  | "REPAIRING"
  | "FAILED";

export interface JobStatus {
  game_id: string;
  state: JobState;
  detail?: Record<string, unknown>;
  phases: { stage: string; state: string }[];
  artifacts: { kind: string; url?: string }[];
}

// Ordered pipeline used to render progress. The hello-job jumps QUEUED -> DEPLOYED;
// once the real S0-S8 pipeline lands (P2) the intermediate states become live.
export const JOB_PIPELINE: { state: JobState; label: string }[] = [
  { state: "QUEUED", label: "Queued" },
  { state: "PLANNING", label: "Planning" },
  { state: "SPEC_FROZEN", label: "Spec frozen" },
  { state: "BUILDING_LEVEL", label: "Building level" },
  { state: "RESOLVING_ASSETS", label: "Resolving assets" },
  { state: "ASSEMBLING", label: "Assembling" },
  { state: "EXPORTING", label: "Exporting" },
  { state: "VALIDATING", label: "Validating" },
  { state: "DEPLOYED", label: "Ready" },
];

export const TERMINAL_STATES: JobState[] = ["DEPLOYED", "FAILED"];

// Serendib Engine downloads. A generated project is engine-native and
// editable, which is only useful to someone who has the engine, so the
// download page offers both. `available: false` carries a reason because
// "not built yet" and "build machine unreachable" need different words.
export interface EngineBuild {
  kind: string;
  label: string;
  platform: string;
  filename: string;
  bytes: number;
  sha256: string;
  url: string;
}

export interface EngineDownloads {
  available: boolean;
  reason?: string | null;
  detail?: string | null;
  upstream_tag?: string | null;
  built_at?: string | null;
  attribution?: string;
  environment?: string;
  builds: EngineBuild[];
}
