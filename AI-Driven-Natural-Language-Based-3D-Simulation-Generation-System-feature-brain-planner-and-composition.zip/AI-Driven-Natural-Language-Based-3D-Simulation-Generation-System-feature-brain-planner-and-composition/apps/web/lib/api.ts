// Typed client for the FastAPI brain. In P0 the backend (hello-job) isn't wired
// yet, so these calls will fail and the UI shows a friendly error state — by design.
// Base URL comes from NEXT_PUBLIC_API_BASE_URL (see .env.example on the brain side).

import type {
  CreateGameRequest,
  CreateGameResponse,
  CreateSimulationRequest,
  CreateSimulationResponse,
  EngineDownloads,
  JobState,
  JobStatus,
  SimulationRecord,
  SimulationReport,
  SimulationRun,
  StageList,
  StagePayload,
} from "./types";

export const API_BASE =
  process.env.NEXT_PUBLIC_API_BASE_URL?.replace(/\/$/, "") ?? "http://localhost:8000";

export class ApiError extends Error {
  constructor(
    message: string,
    readonly status?: number,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      ...init,
      headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    });
  } catch {
    // Network error — brain not running yet (expected in P0).
    throw new ApiError(
      "Serendib cannot reach the simulation service. Please retry shortly.",
    );
  }
  if (!res.ok) {
    throw new ApiError(`Request failed (${res.status}).`, res.status);
  }
  return (await res.json()) as T;
}

export function createGame(body: CreateGameRequest): Promise<CreateGameResponse> {
  return request<CreateGameResponse>("/api/v1/games", {
    method: "POST",
    body: JSON.stringify(body),
  });
}

export function createSimulation(
  body: CreateSimulationRequest,
): Promise<CreateSimulationResponse> {
  return request<CreateSimulationResponse>("/api/v1/simulations", {
    method: "POST",
    body: JSON.stringify(body),
  });
}

export function getSimulationRun(runId: string): Promise<SimulationRun> {
  return request<SimulationRun>(`/api/v1/runs/${encodeURIComponent(runId)}`);
}

export function getSimulation(
  simulationId: string,
): Promise<SimulationRecord> {
  return request<SimulationRecord>(
    `/api/v1/simulations/${encodeURIComponent(simulationId)}`,
  );
}

export function getSimulationReport(
  simulationId: string,
): Promise<SimulationReport> {
  return request<SimulationReport>(
    `/api/v1/simulations/${encodeURIComponent(simulationId)}/report`,
  );
}

export function getJob(jobId: string): Promise<JobStatus> {
  return request<JobStatus>(`/api/v1/jobs/${encodeURIComponent(jobId)}`);
}

/** The stage rail: what ran, what it concluded, how long it took. */
export function listRunStages(runId: string): Promise<StageList> {
  return request<StageList>(
    `/api/v1/runs/${encodeURIComponent(runId)}/stages`,
  );
}

/** One stage's full output — the JSON the inspector shows. */
export function getRunStage(
  runId: string,
  stage: string,
): Promise<StagePayload> {
  return request<StagePayload>(
    `/api/v1/runs/${encodeURIComponent(runId)}/stages/${encodeURIComponent(stage)}`,
  );
}

/** Replace a stage's payload with a corrected one, to re-run downstream from it.
 *  The edit is validated by the same gates as any other spec when the pipeline
 *  next consumes it, so this cannot smuggle an invalid spec past validation. */
export function putRunStage(
  runId: string,
  stage: string,
  payload: Record<string, unknown>,
): Promise<StagePayload> {
  return request<StagePayload>(
    `/api/v1/runs/${encodeURIComponent(runId)}/stages/${encodeURIComponent(stage)}`,
    { method: "PUT", body: JSON.stringify({ payload }) },
  );
}

export interface JobEvent {
  state?: JobState;
  detail?: Record<string, unknown>;
  terminal?: boolean;
  error?: string;
}

// Live progress via Server-Sent Events. Returns an unsubscribe function.
// Falls back to onError (the caller then polls) if EventSource can't connect.
export function subscribeJobEvents(
  jobId: string,
  onEvent: (e: JobEvent) => void,
  onError: () => void,
): () => void {
  if (typeof EventSource === "undefined") {
    onError();
    return () => {};
  }
  const url = `${API_BASE}/api/v1/jobs/${encodeURIComponent(jobId)}/events`;
  const es = new EventSource(url);
  let closed = false;

  es.onmessage = (msg) => {
    try {
      const data = JSON.parse(msg.data) as JobEvent;
      onEvent(data);
      if (data.terminal || data.error) {
        closed = true;
        es.close();
      }
    } catch {
      /* ignore malformed frame */
    }
  };
  es.onerror = () => {
    // A clean server close after the terminal frame also fires onerror —
    // only treat it as a real failure if we never reached a terminal state.
    if (!closed) {
      es.close();
      onError();
    }
  };
  return () => {
    closed = true;
    es.close();
  };
}

export function getEngineDownloads(): Promise<EngineDownloads> {
  return request<EngineDownloads>("/api/v1/engine/downloads");
}

/**
 * Resolve an artifact path against the API origin.
 *
 * The brain returns artifact URLs as absolute PATHS ("/artifacts/<sim>/<run>/
 * index.html") because it serves them itself. A browser resolves a path
 * against the page's origin, and in development the page is on :3000 while
 * /artifacts is mounted on :8000 -- so every play link and every download
 * 404'd against the Next.js router while the file sat there serving 200 from
 * the API. Same-origin deployment hid this; the dev split is where it shows.
 *
 * Absolute URLs are returned untouched, so signed R2 links keep working when
 * artifacts move off local disk.
 */
export function artifactUrl(url: string): string {
  if (/^https?:\/\//i.test(url)) return url;
  // Left relative on purpose: next.config.mjs rewrites /artifacts/* to the API,
  // so the link stays same-origin with the page that frames it. Pointing it at
  // the API origin would work too, but would make the generated build
  // cross-origin from its own play page for no benefit.
  return url.startsWith("/") ? url : `/${url}`;
}
