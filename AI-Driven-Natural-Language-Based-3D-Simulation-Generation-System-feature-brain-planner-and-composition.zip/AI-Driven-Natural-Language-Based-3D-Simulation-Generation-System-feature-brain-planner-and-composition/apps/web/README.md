# Serendib web

Next.js interface for natural-language simulation requests, truthful generation
status, mandatory validation evidence, and verified artifact delivery.

```bash
npm install
npm run dev:web
npm run build:web
```

Set `NEXT_PUBLIC_API_BASE_URL` to the Serendib API. The production deployment
must also provide the OIDC session integration and authenticated artifact
gateway. The UI never calls models or databases directly and never presents an
unfinished preview as a completed simulation.
