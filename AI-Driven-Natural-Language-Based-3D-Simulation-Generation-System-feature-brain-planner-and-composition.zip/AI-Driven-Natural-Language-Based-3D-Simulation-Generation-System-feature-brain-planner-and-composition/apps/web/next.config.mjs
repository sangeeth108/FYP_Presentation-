/** @type {import('next').NextConfig} */
// PromptPlay 3D frontend config.
//
// The API base URL is read from NEXT_PUBLIC_API_BASE_URL at runtime (see
// lib/api.ts); JSON calls go to the FastAPI brain directly (CORS allow-listed).
const apiBase = (
  process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000"
).replace(/\/$/, "");

const nextConfig = {
  reactStrictMode: true,

  // Artifacts are proxied rather than linked cross-origin.
  //
  // The brain returns artifact URLs as absolute PATHS ("/artifacts/<sim>/<run>/
  // index.html") because it serves them itself. With the frontend on :3000 and
  // /artifacts mounted on :8000, the browser resolved those paths against the
  // page origin and every play link 404'd into the Next router -- while the
  // file sat there serving 200 from the API.
  //
  // Rewriting rather than rewriting-the-links is deliberate. Fixing only the
  // anchors leaves the bare URL broken, so a bookmarked, shared or
  // copy-pasted play link still fails, and that is the link a user is most
  // likely to keep. It also keeps the generated build same-origin with the
  // page that frames it, which avoids a class of cross-origin problems in the
  // WebGL runtime that would be tedious to diagnose later.
  async rewrites() {
    return [
      { source: "/artifacts/:path*", destination: `${apiBase}/artifacts/:path*` },
    ];
  },
};

export default nextConfig;
