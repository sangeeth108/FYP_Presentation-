"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

import { artifactUrl, getEngineDownloads } from "@/lib/api";
import type { EngineDownloads } from "@/lib/types";

/**
 * Serendib Engine downloads.
 *
 * The product promise is that a generated world is a beginning rather than an end,
 * and that is only redeemable by somebody holding the engine. The download page
 * therefore carries three things a bare file list does not: what the engine IS
 * (a rebranded Godot build, so existing knowledge transfers), how to open a
 * generated project in it, and the upstream credit that using it requires.
 *
 * Three states, kept deliberately distinct:
 *
 *   resolving    nothing rendered, so there is no flash of an empty state
 *   not built    says so, AND says the project is still editable meanwhile,
 *                because the useful fact is not "unavailable" but "not blocked"
 *   unreachable  a different failure from the above and never dressed up as it
 *
 * Sizes and checksums are shown because a binary nobody can verify after transfer
 * is not something to hand someone unprompted.
 */
export default function EnginePage() {
  const [downloads, setDownloads] = useState<EngineDownloads | null>(null);
  const [unreachable, setUnreachable] = useState(false);

  useEffect(() => {
    let cancelled = false;
    getEngineDownloads()
      .then((result) => {
        if (!cancelled) setDownloads(result);
      })
      .catch(() => {
        if (!cancelled) setUnreachable(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <main>
      <section className="hero-wide">
        <p className="eyebrow">Serendib Engine</p>
        <h1>The editor your generated world opens in.</h1>
        <p className="sub">
          Serendib Engine is a rebranded build of Godot 4.7. It is the same
          editor, with our name, icon and credits — so every tutorial, plugin and
          habit you already have still works. Generated projects are ordinary
          engine projects: open one and change anything.
        </p>
        {downloads?.available && (
          <p className="hint">
            Upstream {downloads.upstream_tag}
            {downloads.built_at
              ? ` · built ${new Date(downloads.built_at).toLocaleDateString()}`
              : ""}
          </p>
        )}
      </section>

      <section className="band alt" aria-labelledby="builds-title">
        <div className="band-inner">
          <h2 id="builds-title">Downloads</h2>

          {unreachable && (
            <div className="status error" role="alert">
              Cannot reach the download service right now. This is a problem with
              this site, not with your projects — a downloaded project stays
              editable in any compatible engine build.
            </div>
          )}

          {!unreachable && downloads && !downloads.available && (
            <div className="status" role="status">
              <strong>Not built yet.</strong>{" "}
              {downloads.detail ??
                "The engine has not been built from the pinned upstream tag on this deployment."}{" "}
              Your generated projects are ordinary engine projects and remain
              fully editable in any compatible build meanwhile.
            </div>
          )}

          {!unreachable && downloads?.available && (
            <>
              <p className="lede">
                Verify a download against its checksum before running it. Sizes
                are exact.
              </p>
              <div className="build-grid">
                {downloads.builds.map((build) => (
                  <article className="build" key={build.filename}>
                    <span className="kind">{build.label}</span>
                    <span className="meta">
                      {build.platform} · {(build.bytes / 1e6).toFixed(1)} MB
                    </span>
                    <code>sha256 {build.sha256}</code>
                    <a className="dl" href={artifactUrl(build.url)} download>
                      Download
                    </a>
                  </article>
                ))}
              </div>
              <p className="hint">
                The export templates are only needed if you want to produce your
                own browser or desktop builds from the editor. The editor alone is
                enough to open, edit and play a project.
              </p>
            </>
          )}
        </div>
      </section>

      <section className="band" aria-labelledby="open-title">
        <div className="band-inner">
          <h2 id="open-title">Opening a generated project</h2>
          <ol className="steps">
            <li>
              <h3>Download the project</h3>
              <p>
                From any finished simulation, take the project archive — not the
                browser build, which is the already-exported game.
              </p>
            </li>
            <li>
              <h3>Unzip it</h3>
              <p>
                Anywhere you like. It is a normal folder with a{" "}
                <code>project.godot</code> in it.
              </p>
            </li>
            <li>
              <h3>Open it in the editor</h3>
              <p>
                Launch Serendib Engine and pick that folder. The world, its
                behaviour graphs and its assets are all there to inspect.
              </p>
            </li>
            <li>
              <h3>Press play</h3>
              <p>
                Then change whatever you want. Node names are meaningful, and
                every behaviour is a readable script rather than generated code.
              </p>
            </li>
          </ol>
        </div>
      </section>

      <section className="band strong" aria-labelledby="legal-title">
        <div className="band-inner">
          <h2 id="legal-title">Licence and credit</h2>
          <p className="legal">
            {downloads?.attribution ??
              "Serendib Engine is based on Godot Engine, used under the MIT licence. Not affiliated with or endorsed by the Godot project."}
          </p>
          <p className="legal">
            The engine source remains MIT-licensed with all upstream copyright
            notices intact, and the editor&rsquo;s About dialog carries the full
            licence text and third-party notices. The Godot name and logo are
            trademarks of their respective owners and are not used as this
            product&rsquo;s identity — which is why the rebrand exists.
          </p>
          <p className="hint">
            Prefer upstream? A generated project is a standard engine project and
            opens in an unmodified Godot 4.7 build just as well.
          </p>
          <p style={{ marginTop: 24 }}>
            <Link href="/">← Back to generating a world</Link>
          </p>
        </div>
      </section>
    </main>
  );
}
