"use client";

// Step-through inspector. A run used to expose only its final summary, so when a
// generation came out wrong there was no way to see WHERE it went wrong. This page
// shows every stage's real output, and lets a stage be corrected by hand so the
// brain can be tested apart from the 3D pipeline.

import Link from "next/link";
import { useParams } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { ApiError, getRunStage, listRunStages, putRunStage } from "@/lib/api";
import type { StagePayload, StageSummary } from "@/lib/types";

const REFRESH_MS = 2500;

const STATUS_CLASS: Record<string, string> = {
  PASS: "pass",
  FAIL: "fail",
  RUNNING: "running",
  PENDING: "pending",
  SKIPPED: "pending",
};

function statusClass(status: string): string {
  return STATUS_CLASS[status] ?? "pending";
}

function duration(ms?: number | null): string {
  if (ms == null) return "";
  return ms < 1000 ? `${ms}ms` : `${(ms / 1000).toFixed(1)}s`;
}

export default function InspectRunPage() {
  const params = useParams<{ runId: string }>();
  const runId = params.runId;

  const [stages, setStages] = useState<StageSummary[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [detail, setDetail] = useState<StagePayload | null>(null);
  const [draft, setDraft] = useState<string>("");
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // Poll the rail so a running pipeline fills in without a manual refresh.
  useEffect(() => {
    let active = true;
    let timer: ReturnType<typeof setTimeout>;

    async function load() {
      try {
        const list = await listRunStages(runId);
        if (!active) return;
        setStages(list.stages);
        setError(null);
        // Land on the newest stage first — that is where the interesting news is.
        setSelected((current) =>
          current ?? (list.stages.length ? list.stages[list.stages.length - 1].stage : null),
        );
      } catch (err) {
        if (!active) return;
        setError(
          err instanceof ApiError ? err.message : "Could not load this run's stages.",
        );
      }
      if (active) timer = setTimeout(load, REFRESH_MS);
    }

    load();
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [runId]);

  const loadStage = useCallback(
    async (stage: string) => {
      try {
        const payload = await getRunStage(runId, stage);
        setDetail(payload);
        setDraft(JSON.stringify(payload.payload, null, 2));
        setEditing(false);
        setError(null);
      } catch (err) {
        setError(
          err instanceof ApiError ? err.message : `Could not load stage '${stage}'.`,
        );
      }
    },
    [runId],
  );

  useEffect(() => {
    if (selected) void loadStage(selected);
  }, [selected, loadStage]);

  async function save() {
    if (!detail) return;
    let parsed: Record<string, unknown>;
    try {
      parsed = JSON.parse(draft);
    } catch {
      // Fail here rather than send invalid JSON the API would reject anyway.
      setError("That is not valid JSON, so it was not saved.");
      return;
    }
    try {
      const updated = await putRunStage(runId, detail.stage, parsed);
      setDetail(updated);
      setDraft(JSON.stringify(updated.payload, null, 2));
      setEditing(false);
      setNotice(
        `Saved. '${detail.stage}' is now marked edited — re-run the pipeline from here to use it.`,
      );
      setError(null);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Could not save this stage.");
    }
  }

  return (
    <main className="container wide">
      <p className="crumb">
        <Link href="/simulations">← All simulations</Link>
      </p>
      <p className="eyebrow">Step-through inspector</p>
      <h1 className="job-title">Run {runId}</h1>
      <p className="details">
        Every stage&apos;s real output. Select a stage to read it; edit a stage to
        re-run the pipeline downstream from your correction.
      </p>

      {error && (
        <div className="status error" role="alert">
          {error}
        </div>
      )}
      {notice && (
        <div className="status loading" role="status">
          {notice}
        </div>
      )}

      {!stages.length && !error && (
        <div className="status loading" role="status">
          No stages recorded yet. They appear here as the pipeline runs.
        </div>
      )}

      <div className="inspect-grid">
        <nav className="inspect-rail" aria-label="Pipeline stages">
          {stages.map((stage) => (
            <button
              key={stage.stage}
              type="button"
              className={`inspect-stage ${statusClass(stage.status)} ${
                selected === stage.stage ? "selected" : ""
              }`}
              onClick={() => setSelected(stage.stage)}
              aria-current={selected === stage.stage}
            >
              <span className="inspect-stage-name">
                {stage.ordinal + 1}. {stage.stage}
              </span>
              <span className="inspect-stage-meta">
                {stage.status}
                {stage.duration_ms != null ? ` · ${duration(stage.duration_ms)}` : ""}
                {stage.edited ? " · edited" : ""}
              </span>
              {Object.keys(stage.summary ?? {}).length > 0 && (
                <span className="inspect-stage-summary">
                  {Object.entries(stage.summary)
                    .slice(0, 3)
                    .map(([key, value]) => `${key}: ${String(value)}`)
                    .join(" · ")}
                </span>
              )}
            </button>
          ))}
        </nav>

        <section className="inspect-detail" aria-live="polite">
          {!detail && <p className="details">Select a stage to see its output.</p>}
          {detail && (
            <>
              <header className="inspect-detail-head">
                <h2>{detail.stage}</h2>
                <span className={`badge ${statusClass(detail.status)}`}>
                  {detail.status}
                </span>
                {detail.model_id && (
                  <span className="details">model {detail.model_id}</span>
                )}
                {detail.edited && <span className="details">human-edited</span>}
              </header>

              {Array.isArray(detail.errors) && detail.errors.length > 0 && (
                <div className="status error" role="alert">
                  <strong>{detail.errors.length} error(s)</strong>
                  <pre className="inspect-json">
                    {JSON.stringify(detail.errors, null, 2)}
                  </pre>
                </div>
              )}

              <div className="inspect-actions">
                {!editing && (
                  <button type="button" onClick={() => setEditing(true)}>
                    Edit this stage
                  </button>
                )}
                {editing && (
                  <>
                    <button type="button" onClick={save}>
                      Save correction
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setDraft(JSON.stringify(detail.payload, null, 2));
                        setEditing(false);
                        setError(null);
                      }}
                    >
                      Cancel
                    </button>
                  </>
                )}
                <a
                  href={`data:application/json;charset=utf-8,${encodeURIComponent(
                    JSON.stringify(detail.payload, null, 2),
                  )}`}
                  download={`${runId}_${detail.stage}.json`}
                >
                  Download JSON
                </a>
              </div>

              {editing ? (
                <textarea
                  className="inspect-editor"
                  value={draft}
                  onChange={(event) => setDraft(event.target.value)}
                  spellCheck={false}
                  aria-label={`${detail.stage} payload`}
                />
              ) : (
                <pre className="inspect-json">
                  {JSON.stringify(detail.payload, null, 2)}
                </pre>
              )}
            </>
          )}
        </section>
      </div>
    </main>
  );
}
