"use client";

import Link from "next/link";
import { useParams, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

import { EngineDownload } from "../../../components/EngineDownload";
import { GenerationProgress } from "@/components/GenerationProgress";
import {
  ApiError,
  artifactUrl,
  getSimulation,
  getSimulationReport,
  getSimulationRun,
} from "@/lib/api";
import type {
  SimulationRecord,
  SimulationReport,
  SimulationRun,
} from "@/lib/types";

const TERMINAL = new Set([
  "completed",
  "failed_requirements",
  "failed_capability",
  "failed_build",
  "failed_validation",
  "failed_export",
]);

export default function SimulationPage() {
  const params = useParams<{ id: string }>();
  const query = useSearchParams();
  const simulationId = params.id;
  const requestedRunId = query.get("run");
  const [run, setRun] = useState<SimulationRun | null>(null);
  const [simulation, setSimulation] = useState<SimulationRecord | null>(null);
  const [report, setReport] = useState<SimulationReport | null>(null);
  const [error, setError] = useState<string | null>(null);
  // Fixed on first render. The run API does not expose a start timestamp, so
  // this measures the wait as experienced rather than claiming to know when
  // the job was queued.
  const [startedAt] = useState(() => Date.now());

  const runId = requestedRunId ?? simulation?.current_run_id ?? null;
  const terminal = run ? TERMINAL.has(run.state) : false;

  useEffect(() => {
    let active = true;
    let timer: ReturnType<typeof setTimeout> | undefined;

    async function refresh() {
      try {
        const record = await getSimulation(simulationId);
        if (!active) return;
        setSimulation(record);
        const currentRunId = requestedRunId ?? record.current_run_id;
        if (currentRunId) {
          const currentRun = await getSimulationRun(currentRunId);
          if (!active) return;
          setRun(currentRun);
          if (!TERMINAL.has(currentRun.state)) {
            timer = setTimeout(refresh, 2000);
            return;
          }
        }
        const evidence = await getSimulationReport(simulationId);
        if (active) setReport(evidence);
      } catch (cause) {
        if (active) {
          setError(
            cause instanceof ApiError
              ? cause.message
              : "Serendib could not load this generation run.",
          );
        }
      }
    }

    void refresh();
    return () => {
      active = false;
      if (timer) clearTimeout(timer);
    };
  }, [requestedRunId, simulationId]);

  const mandatoryPassed = useMemo(
    () =>
      Boolean(
        report &&
          report.validation.length > 0 &&
          report.validation
            .filter((item) => item.mandatory)
            .every((item) => item.status === "PASS"),
      ),
    [report],
  );
  const releasable = run?.state === "completed" && mandatoryPassed;

  return (
    <main className="container">
      <p className="crumb">
        <Link href="/">← New simulation</Link>
      </p>
      <p className="eyebrow">Generation run</p>
      <h1 className="job-title">
        {simulation?.title ?? "Loading simulation…"}
      </h1>
      <p className="details">
        Run {runId ?? "pending"} · stage {run?.stage ?? "intake"}
      </p>

      {error && (
        <div className="status error" role="alert">
          {error}
        </div>
      )}

      {/* Progress replaces the single sentence that used to stand in for a
          fifteen-minute job. It stays on screen after the run finishes, because
          "what did it do and what passed" is worth as much afterwards. */}
      {!error && (
        <GenerationProgress run={run} report={report} startedAt={startedAt} />
      )}

      {!error && !terminal && (
        <p className="hint">
          You can leave this page open. Only a final validator-approved artifact
          is published — nothing partial is shown as finished.
        </p>
      )}

      {terminal && !releasable && (
        <div className="status error" role="alert">
          This run is not releasable. A required build or validator failed,
          was unavailable, or did not run. No unfinished preview is presented
          as a completed simulation.
        </div>
      )}

      {releasable && (
        <section className="card" aria-labelledby="artifacts-title">
          <h2 id="artifacts-title">Verified artifacts</h2>
          <ul className="artifact-list">
            {(simulation?.artifacts ?? []).map((artifact) => (
              <li key={`${artifact.kind}-${artifact.url}`}>
                {artifact.url ? (
                  <a href={artifactUrl(artifact.url)}>{artifact.kind}</a>
                ) : (
                  <span>{artifact.kind} (delivery unavailable)</span>
                )}
              </li>
            ))}
          </ul>
        </section>
      )}

      {releasable && <EngineDownload />}

      {report && (
        <section className="card" aria-labelledby="evidence-title">
          <h2 id="evidence-title">Run details</h2>
          {/* The per-gate list lives in the progress card above; repeating it
              here would make the page twice as long and say nothing new. */}
          <p className="details">
            Requirements: {report.requirements.length} · world plan:{" "}
            {report.world_plan_hash ?? "not compiled"} · repair attempts:{" "}
            {run?.repair_attempts ?? 0}/{run?.max_repair_attempts ?? 3}
          </p>
        </section>
      )}
    </main>
  );
}
