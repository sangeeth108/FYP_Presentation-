import Link from "next/link";

export default function SimulationsPage() {
  return (
    <main className="container">
      <p className="eyebrow">Simulations</p>
      <h1>Verified simulation workspace</h1>
      <div className="card">
        <p>
          Simulation history is tenant-scoped and requires an authenticated
          workspace session. The public shell does not expose user records.
        </p>
        <Link className="link-btn" href="/">
          Create a simulation
        </Link>
      </div>
    </main>
  );
}
