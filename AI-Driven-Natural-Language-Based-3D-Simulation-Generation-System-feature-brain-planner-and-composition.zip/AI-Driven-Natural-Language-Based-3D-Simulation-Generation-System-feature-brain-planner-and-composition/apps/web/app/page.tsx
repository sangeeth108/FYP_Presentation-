"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ApiError, createSimulation } from "@/lib/api";
import { ExamplePromptChips } from "@/components/ExamplePromptChips";
import { HowItWorks } from "@/components/HowItWorks";
import { CapabilityShowcase } from "@/components/CapabilityShowcase";
import { TrustPanel } from "@/components/TrustPanel";
import type { SizeProfile, TargetPlatform } from "@/lib/types";

type Status =
  | { kind: "idle" }
  | { kind: "loading" }
  | { kind: "error"; message: string };

/**
 * Home: the promotional surface, with the tool at the top of it.
 *
 * The prompt box stays above the fold. Everything below is what a visitor reads
 * while deciding whether to use it, and promotion that pushes the action off
 * screen has traded the product for a brochure.
 *
 * The form behaviour is unchanged from the version that was only a form: same
 * request, same validation, same four states, same route on success.
 */
export default function HomePage() {
  const router = useRouter();
  const [prompt, setPrompt] = useState("");
  const [size, setSize] = useState<SizeProfile>("auto");
  const [platforms, setPlatforms] = useState<TargetPlatform[]>([
    "web",
    "desktop",
  ]);
  const [status, setStatus] = useState<Status>({ kind: "idle" });
  const canSubmit = prompt.trim().length >= 8 && status.kind !== "loading";

  function togglePlatform(platform: TargetPlatform) {
    setPlatforms((current) =>
      current.includes(platform)
        ? current.length === 1
          ? current
          : current.filter((item) => item !== platform)
        : [...current, platform],
    );
  }

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (!canSubmit) return;
    setStatus({ kind: "loading" });
    try {
      const created = await createSimulation({
        prompt: prompt.trim(),
        size_profile: size,
        target_platforms: platforms,
      });
      router.push(
        `/simulations/${encodeURIComponent(created.simulation_id)}?run=${encodeURIComponent(created.run_id)}`,
      );
    } catch (error) {
      setStatus({
        kind: "error",
        message:
          error instanceof ApiError
            ? error.message
            : "Serendib could not accept this simulation request.",
      });
    }
  }

  return (
    <main>
      <section className="hero-wide">
        <div className="hero-split">
          <div>
            <p className="eyebrow">Verified simulation generation</p>
            <h1>Describe a world. Serendib builds the working simulation.</h1>
            <p className="sub">
              Type a place in plain English and get a 3D world you can walk through in
              your browser — and a real engine project you can open and keep building.
              Every published result has passed the checks below.
            </p>

            <form className="card" onSubmit={onSubmit}>
              <label htmlFor="prompt" className="field-label">
                Describe your world
              </label>
              <textarea
                id="prompt"
                className="prompt"
                placeholder="A small railway platform in the late afternoon: a station guard who warns visitors about the platform edge, a tea vendor by the ticket window, and a bench under the awning."
                value={prompt}
                onChange={(event) => setPrompt(event.target.value)}
              />

              <div className="controls">
                <div className="field">
                  <label htmlFor="size">World size</label>
                  <select
                    id="size"
                    value={size}
                    onChange={(event) => setSize(event.target.value as SizeProfile)}
                  >
                    <option value="auto">Auto</option>
                    <option value="small">Small · up to 0.25 km²</option>
                    <option value="medium">Medium · up to 1 km²</option>
                  </select>
                </div>
                <fieldset className="platforms">
                  <legend>Artifacts</legend>
                  {(["web", "desktop"] as const).map((platform) => (
                    <label key={platform}>
                      <input
                        type="checkbox"
                        checked={platforms.includes(platform)}
                        onChange={() => togglePlatform(platform)}
                      />
                      {platform === "web" ? "Browser" : "Desktop"}
                    </label>
                  ))}
                </fieldset>
                <button type="submit" className="generate" disabled={!canSubmit}>
                  {status.kind === "loading"
                    ? "Planning simulation…"
                    : "Generate verified simulation"}
                </button>
              </div>
            </form>

            {status.kind === "loading" && (
              <div className="status loading" role="status">
                Extracting requirements and reserving a generation slot…
              </div>
            )}
            {status.kind === "error" && (
              <div className="status error" role="alert">
                {status.message}
              </div>
            )}

            <ExamplePromptChips onPick={setPrompt} />
          </div>

          {/* Decorative, so it is hidden from assistive technology: everything it
              depicts is stated in words elsewhere on the page. It shows the real
              shape of a run rather than a stock illustration. */}
          <div className="hero-preview" aria-hidden>
            <div className="row">
              <b>Building the world</b>
              <span>· 4m 12s elapsed</span>
            </div>
            <div className="mini-bar">
              <i />
            </div>
            <div className="checks">
              <span>requirements</span>
              <span>capability declaration</span>
              <span>asset geometry</span>
              <span>semantic placement</span>
              <span>behaviour compilation</span>
              <span className="waiting">runtime interactions</span>
              <span className="waiting">navigation reachability</span>
              <span className="waiting">cross-platform parity</span>
            </div>
          </div>
        </div>

        {/* Spans the hero's full width, beneath the split. Three facts the
            system can produce. No invented percentages: the
            measured pass rates are being re-measured and a number that cannot be
            reproduced on request does not belong beside a call to action. */}
        <div className="stat-strip">
          <div>
            <span className="n">18</span>
            <span className="l">validation layers, 17 of them mandatory</span>
          </div>
          <div>
            <span className="n">0</span>
            <span className="l">manual steps between prompt and playable build</span>
          </div>
          <div>
            <span className="n">Same seed</span>
            <span className="l">rebuilds the identical world, every time</span>
          </div>
        </div>
      </section>

      <HowItWorks />
      <CapabilityShowcase />
      <TrustPanel />

      <section className="band alt" aria-labelledby="engine-cta">
        <div className="band-inner">
          <div className="cta-band">
            <div>
              <h2 id="engine-cta">The engine comes with it</h2>
              <p className="lede" style={{ marginBottom: 0 }}>
                What you get is a beginning, not an end. Every world downloads as
                an engine-native project — nothing locked, nothing
                generated-only — and Serendib Engine opens it. It is a rebranded
                Godot 4.7 build, so everything you already know still applies.
              </p>
            </div>
            <Link href="/engine" className="primary">
              Download the engine
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
