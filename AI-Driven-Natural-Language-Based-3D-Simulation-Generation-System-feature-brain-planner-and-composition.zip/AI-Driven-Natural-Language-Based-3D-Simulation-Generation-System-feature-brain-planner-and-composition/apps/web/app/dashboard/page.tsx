"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

import { AppShell } from "@/components/AppShell";
import { GenerationProgress } from "@/components/GenerationProgress";
import {
  ApiError,
  artifactUrl,
  createSimulation,
  getSimulation,
  getSimulationReport,
  getSimulationRun,
} from "@/lib/api";
import type {
  SimulationRecord,
  SimulationReport,
  SimulationRun,
  SizeProfile,
  TargetPlatform,
} from "@/lib/types";

/**
 * The workspace: describe, generate, watch, inspect.
 *
 * Every panel is fed by data the pipeline really produces. Where the mockup this
 * was modelled on shows something the pipeline cannot back -- editable physics
 * fields, live FPS, analytics charts -- the panel says so plainly instead of
 * displaying a plausible number. A fake damping field that silently does nothing
 * is worse than an absent one: it invites a user to tune a world and wonder why
 * nothing changed.
 *
 * The viewport embeds the real exported build once a run has published one. Until
 * then it holds a grid and a sentence about what is happening, rather than a
 * pretend 3D scene, because a rendered-looking placeholder would misrepresent
 * what has actually been produced.
 */

const TERMINAL = new Set([
  "completed",
  "failed_requirements",
  "failed_capability",
  "failed_build",
  "failed_validation",
  "failed_export",
]);

/** Read a nested value out of the spec or plan without trusting its shape. */
function pick(source: unknown, ...path: string[]): unknown {
  let cursor: unknown = source;
  for (const key of path) {
    if (typeof cursor !== "object" || cursor === null) return undefined;
    cursor = (cursor as Record<string, unknown>)[key];
  }
  return cursor;
}

function count(value: unknown): number | null {
  return Array.isArray(value) ? value.length : null;
}

export default function DashboardPage() {
  const router = useRouter();
  const [prompt, setPrompt] = useState("");
  const [size, setSize] = useState<SizeProfile>("auto");
  const [platforms] = useState<TargetPlatform[]>(["web", "desktop"]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [simulationId, setSimulationId] = useState<string | null>(null);
  const [record, setRecord] = useState<SimulationRecord | null>(null);
  const [run, setRun] = useState<SimulationRun | null>(null);
  const [report, setReport] = useState<SimulationReport | null>(null);
  const [startedAt, setStartedAt] = useState<number>(() => Date.now());

  // `user_visible` separates a compromise somebody asked about from a note the
  // pipeline left itself. An absent flag is treated as visible: an approximation
  // that forgot to say is safer shown than hidden.
  const visibleApproximations = (report?.approximations ?? [])
    .map((item) => item as { reason?: unknown; user_visible?: unknown })
    .filter((item) => item.user_visible !== false);

  // Poll the active run. Two seconds matches the run page and is frequent enough
  // that a stage change is noticed without hammering the API for a job measured
  // in minutes.
  useEffect(() => {
    if (!simulationId) return;
    let active = true;
    let timer: ReturnType<typeof setTimeout> | undefined;

    async function refresh() {
      try {
        const current = await getSimulation(simulationId!);
        if (!active) return;
        setRecord(current);
        if (current.current_run_id) {
          const currentRun = await getSimulationRun(current.current_run_id);
          if (!active) return;
          setRun(currentRun);
          if (!TERMINAL.has(currentRun.state)) {
            timer = setTimeout(refresh, 2000);
            return;
          }
        }
        const finished = await getSimulationReport(simulationId!);
        if (active) setReport(finished);
      } catch (caught) {
        if (active) {
          setError(
            caught instanceof ApiError
              ? caught.message
              : "Lost contact with the generation service.",
          );
        }
      }
    }
    refresh();
    return () => {
      active = false;
      if (timer) clearTimeout(timer);
    };
  }, [simulationId]);

  async function onGenerate(event: React.FormEvent) {
    event.preventDefault();
    if (prompt.trim().length < 8 || busy) return;
    setBusy(true);
    setError(null);
    setReport(null);
    setRun(null);
    setRecord(null);
    try {
      const created = await createSimulation({
        prompt: prompt.trim(),
        size_profile: size,
        target_platforms: platforms,
      });
      setStartedAt(Date.now());
      setSimulationId(created.simulation_id);
    } catch (caught) {
      setError(
        caught instanceof ApiError
          ? caught.message
          : "Serendib could not accept this request.",
      );
    } finally {
      setBusy(false);
    }
  }

  const webBuild = useMemo(
    () =>
      (record?.artifacts ?? []).find((artifact) => artifact.kind === "web_build"),
    [record],
  );

  // Scene facts, all read from the plan and spec the run actually produced.
  const scene = useMemo(() => {
    const spec = record?.spec;
    const plan = record?.world_plan;
    if (!spec && !plan) return null;
    return {
      gravity: pick(spec, "environment", "gravity_mps2"),
      kind: pick(spec, "environment", "world_kind"),
      surface: pick(spec, "environment", "terrain_surface"),
      objects: count(pick(plan, "entities")),
      zones: count(pick(plan, "zones")),
      scatter: count(pick(plan, "scatter", "instances")),
      relief: pick(plan, "terrain", "amplitude_m"),
      seed: pick(plan, "seed"),
      hash: report?.world_plan_hash,
    };
  }, [record, report]);

  const state = run?.state ?? (simulationId ? "queued" : null);

  return (
    <AppShell
      title="Welcome back"
      subtitle="Describe a world in natural language. Serendib plans it, builds it, and verifies it before publishing."
    >
      {/* 1 — DESCRIBE */}
      <form className="card" onSubmit={onGenerate} style={{ marginBottom: 18 }}>
        <label className="field-label" htmlFor="nl">
          Describe your simulation
        </label>
        <textarea
          id="nl"
          className="prompt"
          placeholder="Describe what you want to simulate in natural language…"
          value={prompt}
          onChange={(event) => setPrompt(event.target.value)}
        />
        <div className="controls">
          <div className="field">
            <label htmlFor="size">World size</label>
            <select
              id="size"
              value={size}
              onChange={(event) => setSize(event.target.value as SizeProfile)}
            >
              <option value="auto">Auto</option>
              <option value="small">Small · up to 0.25 km²</option>
              <option value="medium">Medium · up to 1 km²</option>
            </select>
          </div>
          <button
            className="generate"
            type="submit"
            disabled={prompt.trim().length < 8 || busy}
          >
            ✦ {busy ? "Submitting…" : "Generate Simulation"}
          </button>
        </div>
        <p className="hint" style={{ marginTop: 12 }}>
          Try: <em>a farm yard with a tractor you can drive and a gate</em> ·{" "}
          <em>a railway platform with a guard who warns you about the edge</em> ·{" "}
          <em>a hillside meadow with a stone cottage and pine trees</em>
        </p>
      </form>

      {error && (
        <div className="status error" role="alert" style={{ marginBottom: 18 }}>
          {error}
        </div>
      )}

      <div className="lab">
        <div style={{ display: "grid", gap: 18, minWidth: 0 }}>
          {/* 2 — SIMULATE. The real build, or an honest empty state. */}
          <section className="viewport" aria-label="Simulation viewport">
            <div className="vhead">
              <span className="name">
                {record?.title ?? "No simulation loaded"}
              </span>
              <span className={`live${state === "completed" ? "" : " idle"}`}>
                {state ? state.replace(/_/g, " ") : "idle"}
              </span>
            </div>
            {webBuild?.url ? (
              <iframe
                className="stage-frame"
                src={artifactUrl(webBuild.url)}
                title={`${record?.title ?? "Simulation"} — interactive build`}
                allow="fullscreen; autoplay; xr-spatial-tracking"
              />
            ) : (
              <div className="stage-empty">
                <div>
                  <strong>
                    {state
                      ? "The world is being built"
                      : "Describe a world to begin"}
                  </strong>
                  {state
                    ? "The interactive build appears here once every mandatory check has passed. Nothing partial is shown as finished."
                    : "Your generated world becomes playable in this panel, and downloadable as an editable project."}
                </div>
              </div>
            )}
          </section>

          {/* Progress, driven entirely by the backend's own stage and gates. */}
          {simulationId && (
            <GenerationProgress
              run={run}
              report={report}
              startedAt={startedAt}
            />
          )}

          {/* 3 — ANALYZE. Only facts the plan carries. */}
          {scene && (
            <div className="props">
              <div className="prop-panel">
                <h3>Scene properties</h3>
                {scene.gravity !== undefined && (
                  <div className="prop-row">
                    <span>Gravity</span>
                    <span className="num">{String(scene.gravity)} m/s²</span>
                  </div>
                )}
                {scene.objects !== null && (
                  <div className="prop-row">
                    <span>Objects placed</span>
                    <span className="num">{scene.objects}</span>
                  </div>
                )}
                {scene.scatter !== null && (
                  <div className="prop-row">
                    <span>Scattered instances</span>
                    <span className="num">
                      {scene.scatter.toLocaleString()}
                    </span>
                  </div>
                )}
                {scene.zones !== null && (
                  <div className="prop-row">
                    <span>Zones</span>
                    <span className="num">{scene.zones}</span>
                  </div>
                )}
                {scene.relief !== undefined && (
                  <div className="prop-row">
                    <span>Terrain relief</span>
                    <span className="num">{String(scene.relief)} m</span>
                  </div>
                )}
                {scene.kind !== undefined && (
                  <div className="prop-row">
                    <span>World</span>
                    <span>
                      {String(scene.kind)} · {String(scene.surface)}
                    </span>
                  </div>
                )}
                {scene.seed !== undefined && (
                  <div className="prop-row">
                    <span>Seed</span>
                    <span className="num">{String(scene.seed)}</span>
                  </div>
                )}
                {scene.hash && (
                  <div className="prop-row">
                    <span>Plan hash</span>
                    <span className="num">{scene.hash.slice(0, 12)}…</span>
                  </div>
                )}
              </div>

              {/* Named, not hidden. The mockup shows editable mass, restitution
                  and damping; the pipeline has no path to re-simulate from an
                  edited value, and a field that silently does nothing is worse
                  than an absent one. */}
              <div className="notyet">
                <b>Live object editing is not wired yet</b>
                Position, mass, restitution and damping are authored by the
                planner and written into the project. To change them today, open
                the downloaded project in the workbench — the values are ordinary
                editable properties there.
              </div>
            </div>
          )}
        </div>

        {/* 4 — the assistant column: the run narrating itself. */}
        <aside style={{ display: "grid", gap: 14, minWidth: 0 }}>
          <section className="assist" aria-labelledby="ai-title">
            <div className="ahead">
              <b id="ai-title">Assistant</b>
              <span className="tag">Serendib AI</span>
            </div>
            <div className="body">
              {record?.prompt && (
                <div className="msg me">
                  <span className="who">You asked</span>
                  {record.prompt}
                </div>
              )}
              <div className="msg">
                <span className="who">Serendib</span>
                {!simulationId &&
                  "Describe a place and I will plan it, build it, and check it before anything is published."}
                {simulationId && !report && (
                  <>
                    Planning and building your world. I will report every check as
                    it lands.
                    <ul className="tick-list">
                      <li className={run ? "" : "waiting"}>Request accepted</li>
                      <li
                        className={
                          run && run.stage !== "intake" ? "" : "waiting"
                        }
                      >
                        Requirements extracted
                      </li>
                      <li
                        className={
                          run?.stage === "native_world_plan" ||
                          run?.stage === "validation" ||
                          run?.state === "completed"
                            ? ""
                            : "waiting"
                        }
                      >
                        World assembled
                      </li>
                      <li
                        className={run?.state === "completed" ? "" : "waiting"}
                      >
                        Verified and published
                      </li>
                    </ul>
                  </>
                )}
                {report && run?.state === "completed" && (
                  <>
                    Done. Every mandatory check passed, so the build above is the
                    verified result and the project is yours to edit.
                  </>
                )}
                {report && run?.state !== "completed" && (
                  <>
                    This run did not pass. I have not published a partial world —
                    the failing checks are listed above with their evidence.
                  </>
                )}
              </div>

              {/* Approximations are the honest half of the assistant: what the
                  planner had to compromise on, in its own words.

                  Only the ones flagged `user_visible`. The list carries internal
                  notes too -- routing an asset through the full resolution ladder
                  emits one per object, which for a village is dozens -- and those
                  are lineage, not news. Unfiltered they would fill the four slots
                  and push out the compromises somebody actually asked about, like
                  getting fewer street lamps than they requested. */}
              {visibleApproximations.length > 0 && (
                <div className="msg">
                  <span className="who">What I had to approximate</span>
                  <ul className="tick-list">
                    {visibleApproximations.slice(0, 4).map((item, index) => (
                      <li className="bad" key={index}>
                        {String(item.reason ?? "unspecified")}
                      </li>
                    ))}
                  </ul>
                  {visibleApproximations.length > 4 && (
                    <span className="req">
                      and {visibleApproximations.length - 4} more
                    </span>
                  )}
                </div>
              )}

              <div className="notyet">
                <b>Conversational editing is not wired yet</b>
                Asking me to change a finished world is the next step on the
                roadmap. Today a new description starts a new run.
              </div>
            </div>
          </section>

          <section className="quick" aria-label="Quick actions">
            <Link href="/dashboard">＋ New simulation</Link>
            <Link href="/simulations">◍ Open recent</Link>
            <Link href="/engine">⇩ Get the workbench</Link>
            <Link href="/">◇ How it works</Link>
          </section>

          {record && (
            <section className="prop-panel" aria-label="Artifacts">
              <h3>Artifacts</h3>
              {(record.artifacts ?? []).length === 0 && (
                <div className="prop-row">
                  <span>None published yet</span>
                  <span>—</span>
                </div>
              )}
              {(record.artifacts ?? []).map((artifact) => (
                <div className="prop-row" key={artifact.kind}>
                  <span>{artifact.kind.replace(/_/g, " ")}</span>
                  <span>
                    {artifact.url ? (
                      <a href={artifactUrl(artifact.url)} download>
                        download
                      </a>
                    ) : (
                      "unavailable"
                    )}
                  </span>
                </div>
              ))}
            </section>
          )}
        </aside>
      </div>

      {/* Counters that are real: the run's own numbers. */}
      <div className="tiles">
        <div className="tile">
          <b>{report ? report.validation.length : 18}</b>
          <span>Validation layers, 17 mandatory</span>
        </div>
        <div className="tile">
          <b>
            {report
              ? report.validation.filter((gate) => gate.status === "PASS").length
              : "—"}
          </b>
          <span>Checks passed this run</span>
        </div>
        <div className="tile">
          <b>{scene?.objects ?? "—"}</b>
          <span>Objects placed</span>
        </div>
        <div className="tile">
          <b>
            {run ? `${run.repair_attempts}/${run.max_repair_attempts}` : "—"}
          </b>
          <span>Repair attempts used</span>
        </div>
      </div>
    </AppShell>
  );
}
