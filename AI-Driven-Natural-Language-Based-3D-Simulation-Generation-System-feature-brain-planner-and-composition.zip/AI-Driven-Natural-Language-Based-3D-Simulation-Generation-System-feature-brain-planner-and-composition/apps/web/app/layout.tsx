import type { Metadata, Viewport } from "next";
import Link from "next/link";
import { SiteChrome } from "@/components/SiteChrome";
import "./globals.css";

export const metadata: Metadata = {
  title: "Serendib · Verified 3D Simulations",
  description:
    "Describe a place in plain English and get a 3D world you can walk through in "
    + "your browser, plus a real engine project you can open and keep building.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <SiteChrome>{children}</SiteChrome>
      </body>
    </html>
  );
}
