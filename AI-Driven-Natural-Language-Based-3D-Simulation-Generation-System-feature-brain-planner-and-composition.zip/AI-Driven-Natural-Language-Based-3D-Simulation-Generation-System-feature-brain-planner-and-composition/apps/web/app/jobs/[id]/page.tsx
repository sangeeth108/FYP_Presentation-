"use client";

import { useEffect, useRef, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { getJob, subscribeJobEvents, ApiError, API_BASE } from "@/lib/api";
import { TERMINAL_STATES, type JobState, type JobStatus } from "@/lib/types";
import { PhaseTimeline } from "@/components/PhaseTimeline";

const POLL_MS = 1500;

type View =
  | { kind: "loading" }
  | { kind: "error"; message: string }
  | { kind: "ready"; job: JobStatus };

export default function JobPage() {
  const params = useParams<{ id: string }>();
  const jobId = params.id;
  const [view, setView] = useState<View>({ kind: "loading" });
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    let cancelled = false;

    // Merge a partial event/status into the current view (SSE frames carry
    // state+detail; the REST fallback carries the full JobStatus).
    function apply(next: { state?: JobState; detail?: Record<string, unknown> }) {
      if (cancelled || next.state === undefined) return;
      setView((prev) => {
        const base: JobStatus =
          prev.kind === "ready"
            ? prev.job
            : { game_id: "", state: next.state!, phases: [], artifacts: [] };
        return { kind: "ready", job: { ...base, state: next.state!, detail: next.detail } };
      });
    }

    function poll() {
      getJob(jobId)
        .then((job) => {
          if (cancelled) return;
          setView({ kind: "ready", job });
          if (!TERMINAL_STATES.includes(job.state)) {
            timer.current = setTimeout(poll, POLL_MS);
          }
        })
        .catch((err) => {
          if (cancelled) return;
          const message =
            err instanceof ApiError && err.status === 404
              ? "We couldn't find that job. It may have expired or the id is wrong."
              : err instanceof ApiError
                ? err.message
                : "Lost contact with the generator. Retrying…";
          setView({ kind: "error", message });
          if (!(err instanceof ApiError && err.status === 404)) {
            timer.current = setTimeout(poll, POLL_MS * 2);
          }
        });
    }

    // Prefer the live SSE stream; fall back to REST polling if it can't connect.
    const unsubscribe = subscribeJobEvents(
      jobId,
      (e) => {
        if (e.error) {
          setView({
            kind: "error",
            message: "We couldn't find that job. It may have expired or the id is wrong.",
          });
          return;
        }
        apply(e);
      },
      () => poll(),
    );

    return () => {
      cancelled = true;
      unsubscribe();
      if (timer.current) clearTimeout(timer.current);
    };
  }, [jobId]);

  return (
    <main className="container">
      <p className="crumb">
        <Link href="/">← New game</Link>
      </p>
      <h1 className="job-title">Building your game…</h1>
      <p className="sub">
        Job <code>{jobId}</code>
      </p>

      {view.kind === "loading" && (
        <div className="status loading" role="status">
          Connecting to the generator…
        </div>
      )}

      {view.kind === "error" && (
        <div className="status error" role="alert">
          {view.message}
        </div>
      )}

      {view.kind === "ready" && (
        <>
          <PhaseTimeline state={view.job.state} />

          {view.job.state === "DEPLOYED" && (
            <div className="status success" role="status">
              <strong>Your game is ready.</strong>{" "}
              {typeof view.job.detail?.play_path === "string" ? (
                <>Click Play to open it in a new tab (WASD + mouse, E to interact).</>
              ) : (
                <>
                  The level plan was built, but this server has no Godot binary
                  configured (GODOT_BIN), so no web build was exported.
                </>
              )}
              <div className="cta-row">
                {typeof view.job.detail?.play_path === "string" ? (
                  <a
                    className="generate"
                    href={`${API_BASE}${view.job.detail.play_path}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    ▶ Play
                  </a>
                ) : (
                  <button className="generate" disabled title="Set GODOT_BIN on the brain">
                    ▶ Play
                  </button>
                )}
                {typeof view.job.detail?.download_path === "string" && (
                  <a
                    className="link-btn"
                    href={`${API_BASE}${view.job.detail.download_path}`}
                    title="The editable Godot/Serendib project — open it in the editor and keep building"
                  >
                    ⬇ Download project
                  </a>
                )}
                <Link className="link-btn" href="/">
                  Make another
                </Link>
              </div>
            </div>
          )}

          {view.job.state === "FAILED" && (
            <div className="status error" role="alert">
              Generation failed. When the pipeline is online you&rsquo;ll see the
              failing stage and an automatic repair attempt here.
            </div>
          )}

          {!TERMINAL_STATES.includes(view.job.state) && (
            <p className="hint">
              Live phase logs and asset previews stream in here once the S0–S8
              pipeline is online (P2). Refreshing every {POLL_MS / 1000}s…
            </p>
          )}
        </>
      )}
    </main>
  );
}
