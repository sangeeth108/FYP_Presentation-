export default function PrivacyPage() {
  return (
    <main className="container">
      <p className="eyebrow">Privacy and learning</p>
      <h1>Your content does not train Serendib by default.</h1>
      <div className="card">
        <p>
          Product use and model-training consent are separate. Training
          choices are granular, versioned, and withdrawable. Teen content
          requires both the teen’s choice and verified guardian consent.
        </p>
        <p>
          Tenant-private content is never merged into the global dataset.
          Deletion and export requests are tracked as auditable workflows.
        </p>
        <p className="details">
          Account-specific controls are shown only after authentication. This
          page intentionally does not infer or change consent.
        </p>
      </div>
    </main>
  );
}
