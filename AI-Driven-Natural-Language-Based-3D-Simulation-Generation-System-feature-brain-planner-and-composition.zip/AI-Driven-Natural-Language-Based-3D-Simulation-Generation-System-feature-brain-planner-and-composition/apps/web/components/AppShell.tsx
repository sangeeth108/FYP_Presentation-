"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

/**
 * The laboratory shell: sidebar, header, workspace.
 *
 * No engine name appears here or anywhere else in the product surface. The
 * upstream credit lives in the site footer's small print and on the download
 * page, which is where the binary actually changes hands.
 *
 * Navigation is deliberately honest. A destination the pipeline cannot back yet
 * is rendered as a disabled item with a "soon" marker rather than a link, because
 * a sidebar that offers nine sections and 404s on six of them tells the user less
 * than one that shows what exists. When a section lands, it moves from `SOON` to
 * `NAV` and nothing else changes.
 */

const NAV: { href: string; label: string; icon: string }[] = [
  { href: "/dashboard", label: "Dashboard", icon: "◈" },
  { href: "/simulations", label: "Simulations", icon: "◍" },
  { href: "/engine", label: "Workbench", icon: "▤" },
];

const SOON: { label: string; icon: string }[] = [
  { label: "Templates", icon: "▦" },
  { label: "Models", icon: "◎" },
  { label: "Scene Editor", icon: "✥" },
  { label: "Physics", icon: "◐" },
  { label: "Datasets", icon: "▥" },
  { label: "Analytics", icon: "◔" },
];

const TOOLS: { label: string; icon: string }[] = [
  { label: "Script Editor", icon: "⌗" },
  { label: "Import Manager", icon: "⇪" },
];

export function AppShell({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  const path = usePathname();

  return (
    <div className="shell">
      <aside className="side" aria-label="Sections">
        <Link href="/" className="logo">
          <span className="glyph" aria-hidden>
            S
          </span>
          <span>
            <b>SERENDIB</b>
            <span>
              Natural Language to
              <br />
              3D Simulation
            </span>
          </span>
        </Link>

        <nav aria-label="Main">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              aria-current={
                path === item.href || path.startsWith(`${item.href}/`)
                  ? "page"
                  : undefined
              }
            >
              <span aria-hidden>{item.icon}</span>
              {item.label}
            </Link>
          ))}
          {SOON.map((item) => (
            <div className="item soon" key={item.label} aria-disabled="true">
              <span>
                <span aria-hidden style={{ marginRight: 10 }}>
                  {item.icon}
                </span>
                {item.label}
              </span>
              <em>soon</em>
            </div>
          ))}
        </nav>

        <div className="group">Tools</div>
        {TOOLS.map((item) => (
          <div className="item soon" key={item.label} aria-disabled="true">
            <span>
              <span aria-hidden style={{ marginRight: 10 }}>
                {item.icon}
              </span>
              {item.label}
            </span>
            <em>soon</em>
          </div>
        ))}

        <div className="group">System</div>
        <Link href="/privacy">
          <span aria-hidden>⚙</span>
          Settings &amp; Privacy
        </Link>

        <div className="who">
          <span className="av" aria-hidden>
            SB
          </span>
          <span>
            Local workspace
            <small>research prototype</small>
          </span>
        </div>
      </aside>

      <main className="work">
        <header className="top">
          <div>
            <h1>{title}</h1>
            {subtitle && <p>{subtitle}</p>}
          </div>
          <div className="tools">
            <Link className="chipbtn" href="/engine">
              <span aria-hidden>▤</span> Workbench
            </Link>
            <Link className="chipbtn" href="/">
              <span aria-hidden>◇</span> About
            </Link>
          </div>
        </header>
        {children}
      </main>
    </div>
  );
}
