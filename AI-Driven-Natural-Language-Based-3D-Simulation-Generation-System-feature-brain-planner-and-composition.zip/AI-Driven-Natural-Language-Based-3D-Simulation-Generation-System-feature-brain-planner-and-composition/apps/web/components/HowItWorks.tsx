/**
 * The pipeline, in the words a visitor would use.
 *
 * The stages are called S0-S8 internally and that naming is useless to someone
 * deciding whether to type a prompt. Four steps, each naming what happens and --
 * more usefully -- who decides it, because the division of labour is the thing
 * that makes this different from asking a chatbot for a scene file.
 */
const STEPS = [
  {
    title: "It reads your description",
    body: "A local language model turns your sentence into a structured brief: the place, what is in it, and what a visitor should be able to do there.",
  },
  {
    title: "It plans, you are not asked to",
    body: "The model chooses what belongs in the world. Where each thing physically goes is solved by seeded, repeatable code — so the same prompt and seed always build the same world.",
  },
  {
    title: "The engine assembles it",
    body: "Terrain, placement, navigation and behaviour are written into a real engine project, then exported for the browser and the desktop.",
  },
  {
    title: "Then it is checked, and can be refused",
    body: "Eighteen validation layers inspect the result — geometry, placement, behaviour, navigation, export and lineage. Seventeen are mandatory.",
  },
];

export function HowItWorks() {
  return (
    <section className="band alt" aria-labelledby="how-title">
      <div className="band-inner">
        <h2 id="how-title">How it works</h2>
        <p className="lede">
          The model decides <em>what</em> the world contains. Deterministic code
          decides <em>how</em> it is built. That split is why the same prompt
          twice gives you the same world twice.
        </p>
        <ol className="steps">
          {STEPS.map((step) => (
            <li key={step.title}>
              <h3>{step.title}</h3>
              <p>{step.body}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
