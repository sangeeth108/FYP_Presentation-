"use client";

import { JOB_PIPELINE, type JobState } from "@/lib/types";

// Renders the S0-S8-style pipeline as a strip of dots that fill as the job advances.
// `failed` flips the current (unreached) step to an error marker.
export function PhaseTimeline({ state }: { state: JobState }) {
  const failed = state === "FAILED";
  const repairing = state === "REPAIRING";
  // Index of the current state in the ordered pipeline; unknown/terminal-error -> 0.
  const currentIndex = Math.max(
    0,
    JOB_PIPELINE.findIndex((p) => p.state === state),
  );
  const done = state === "DEPLOYED";

  return (
    <ol className="timeline" aria-label="Generation progress">
      {JOB_PIPELINE.map((step, i) => {
        const complete = done || i < currentIndex;
        const active = !done && i === currentIndex && !failed;
        const cls = complete
          ? "step done"
          : active
            ? "step active"
            : failed && i === currentIndex
              ? "step failed"
              : "step";
        return (
          <li key={step.state} className={cls}>
            <span className="dot" aria-hidden>
              {complete ? "✓" : failed && i === currentIndex ? "✕" : `S${i}`}
            </span>
            <span className="step-label">{step.label}</span>
          </li>
        );
      })}
      {repairing && <li className="repair-note">Repairing…</li>}
    </ol>
  );
}
