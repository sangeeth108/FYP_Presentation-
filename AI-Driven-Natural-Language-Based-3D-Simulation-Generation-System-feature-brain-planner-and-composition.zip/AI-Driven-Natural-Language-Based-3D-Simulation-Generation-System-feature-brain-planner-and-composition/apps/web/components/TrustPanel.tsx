/**
 * The verification story, which is the actual differentiator.
 *
 * Anything can emit a scene file. What is unusual here is that the result is
 * inspected afterwards and can be REFUSED -- so the promise worth making on a
 * landing page is not "it always works" but "it tells you when it did not".
 *
 * Every number is one the system produces: eighteen layers, seventeen mandatory.
 * No percentages appear here. The measured pass rates are being re-run and would
 * be stale by the time anyone read them, and a figure that cannot be reproduced on
 * request should not be printed next to a download button.
 */
const CHECKS = [
  {
    title: "Every requirement traced",
    body: "Each thing your description asked for is carried through to a check that can pass or fail, so nothing is quietly dropped.",
  },
  {
    title: "Nothing floats, nothing is buried",
    body: "Placement is compared against the actual ground in the engine. A prop hanging above a hill fails the gate rather than shipping.",
  },
  {
    title: "Behaviour is probed, not assumed",
    body: "The engine runs each interaction and reports the state it reached — the door really opened, the sensor really fired.",
  },
  {
    title: "Reachable on foot",
    body: "Navigation is baked and pathed, so a place you were promised access to is somewhere you can actually walk.",
  },
  {
    title: "The same on both platforms",
    body: "Browser and desktop builds are compared against each other, so what you play is what you downloaded.",
  },
  {
    title: "Full lineage recorded",
    body: "Prompt, seed, model digests and hashes travel with every artifact, so any world can be rebuilt exactly.",
  },
];

export function TrustPanel() {
  return (
    <section className="band strong" aria-labelledby="trust-title">
      <div className="band-inner">
        <h2 id="trust-title">How it is verified</h2>
        <p className="lede">
          Eighteen validation layers inspect the finished world. Seventeen must
          pass before anything is published — and when one cannot, the run is
          reported as failed with the evidence attached.
        </p>
        <div className="grid-cards bento">
          {CHECKS.map((check) => (
            <article className="mini" key={check.title}>
              <h3>{check.title}</h3>
              <p>{check.body}</p>
            </article>
          ))}
        </div>
        <p className="hint">
          Serendib does not publish unfinished previews. If a mandatory validator
          cannot run, or a requirement cannot be satisfied, the report says so
          instead of presenting an incomplete world as finished.
        </p>
      </div>
    </section>
  );
}
