/**
 * What a visitor can actually do in a generated world.
 *
 * The honesty rule for this component: nothing is advertised beyond its status in
 * the capability registry. The registry currently reads six capabilities fully
 * supported, six partial and one unavailable, and this page says which is which
 * rather than listing thirteen features and letting a reader assume.
 *
 * That is not modesty, it is the same rule the capability manifests enforce
 * internally. A landing page promising "simulate any ecosystem" while
 * `ecosystem_process` has no runtime binding would be exactly the overstatement
 * those manifests exist to catch -- and a visitor who typed that prompt would find
 * out within a minute.
 *
 * Mirrored from the registry by hand because this is a static marketing page and
 * must not depend on the API being reachable to render. The wording is kept close
 * to the manifest limitations so a drift is obvious in review.
 */
type Capability = {
  title: string;
  body: string;
  status: "ready" | "partial";
};

const CAPABILITIES: Capability[] = [
  {
    title: "Walk and look around",
    body: "Third-person movement over real terrain, with a camera you control.",
    status: "ready",
  },
  {
    title: "Open doors and gates",
    body: "Hinged doors that swing, and gates that start locked against you.",
    status: "ready",
  },
  {
    title: "Sit down",
    body: "Benches, chairs and pews you can actually rest on, and get up from.",
    status: "ready",
  },
  {
    title: "Pick things up and carry them",
    body: "Crates and tools travel with you and are set down on the ground where you leave them — one at a time.",
    status: "ready",
  },
  {
    title: "Talk to people",
    body: "A guard or a vendor delivers their lines one at a time. Linear: no choices and no replies.",
    status: "partial",
  },
  {
    title: "Drive vehicles",
    body: "Board a cart or tractor and drive it with the movement keys. Kinematic — no suspension or braking distance.",
    status: "partial",
  },
  {
    title: "Start machines",
    body: "A press or pump visibly runs, stops, or seizes where it stood. It consumes no inputs and produces no outputs.",
    status: "partial",
  },
  {
    title: "Trip sensors",
    body: "Plates and beams notice you entering and leaving. Proximity only — nothing is counted or logged.",
    status: "partial",
  },
  {
    title: "…and things that cause each other",
    body: "Step on the plate and the door across the room opens. Talk to the guard and the gate unlocks. Objects are wired together, not left as separate toys.",
    status: "ready",
  },
];

export function CapabilityShowcase() {
  return (
    <section className="band" aria-labelledby="can-title">
      <div className="band-inner">
        <h2 id="can-title">What a visitor can do</h2>
        <p className="lede">
          Behaviour comes from vetted, hand-written engine templates — never from
          generated code. The model picks which ones a world needs; it cannot
          invent new ones. Anything only partly finished is labelled, because you
          will find out in the first minute either way.
        </p>
        <div className="grid-cards bento">
          {CAPABILITIES.map((capability) => (
            <article className="mini" key={capability.title}>
              <span
                className={`pill ${capability.status}`}
                aria-label={
                  capability.status === "ready"
                    ? "Fully supported"
                    : "Partly supported"
                }
              >
                {capability.status === "ready" ? "Supported" : "Partial"}
              </span>
              <h3>{capability.title}</h3>
              <p>{capability.body}</p>
            </article>
          ))}
        </div>
        <p className="hint">
          One capability in the vocabulary has no runtime yet — quantitative
          ecosystem processes — and a prompt needing it is told so rather than
          handed a world that looks alive and is not.
        </p>
      </div>
    </section>
  );
}
