"use client";

import { useEffect, useState } from "react";

import { artifactUrl, getEngineDownloads } from "../lib/api";
import type { EngineDownloads } from "../lib/types";

/**
 * Offers the Serendib Engine alongside the downloadable project.
 *
 * The product promise is that a generated world is a beginning rather than an
 * end: a real, editable, engine-native project. That promise is only redeemable
 * by someone who has the engine, so the engine belongs on the same page as the
 * project rather than in documentation the user has to go looking for.
 *
 * Three states, deliberately distinct. A build that exists is offered with its
 * size and checksum. A build that does not exist yet says so, and says the
 * project is still editable meanwhile, because the useful information is not
 * "unavailable" but "you are not blocked". A service that cannot be reached is
 * a different failure and must not be dressed up as the second.
 */
export function EngineDownload() {
  const [downloads, setDownloads] = useState<EngineDownloads | null>(null);
  const [unreachable, setUnreachable] = useState(false);

  useEffect(() => {
    let cancelled = false;
    getEngineDownloads()
      .then((result) => {
        if (!cancelled) setDownloads(result);
      })
      .catch(() => {
        if (!cancelled) setUnreachable(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (unreachable) {
    return (
      <section className="card" aria-labelledby="engine-title">
        <h2 id="engine-title">Serendib Engine</h2>
        <p className="muted">
          Cannot reach the download service right now. Your project download
          above is unaffected.
        </p>
      </section>
    );
  }

  if (!downloads) return null;

  return (
    <section className="card" aria-labelledby="engine-title">
      <h2 id="engine-title">Serendib Engine</h2>

      {downloads.available ? (
        <>
          <p className="muted">
            Open the downloaded project to edit the world, its behaviour and its
            assets. Nothing in it is locked or generated-only.
          </p>
          <ul className="artifact-list">
            {downloads.builds.map((build) => (
              <li key={build.filename}>
                <a href={artifactUrl(build.url)} download>
                  {build.label} · {build.platform}
                </a>{" "}
                <span className="muted">
                  {(build.bytes / 1_048_576).toFixed(0)} MB
                </span>
                {/* Shown, not hidden behind a details pane: a binary you are
                    asked to run is one you should be able to verify. */}
                <div className="checksum">SHA-256 {build.sha256}</div>
              </li>
            ))}
          </ul>
          {downloads.upstream_tag && (
            <p className="muted">Built from upstream {downloads.upstream_tag}.</p>
          )}
        </>
      ) : (
        <p className="muted">
          {downloads.detail ??
            "No engine build is published yet. Generated projects remain fully editable in any compatible engine build."}
        </p>
      )}

      {downloads.attribution && (
        <p className="attribution">{downloads.attribution}</p>
      )}
    </section>
  );
}
