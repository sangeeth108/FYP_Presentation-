"use client";

const EXAMPLES = [
  "As a dog, explore a living village with usable doors and navigable paths.",
  "Simulate a factory line where a sensor starts a machine and logs each processed item.",
  "Create a forest ecosystem lesson with animals reacting to weather and habitat changes.",
  "Build a warehouse safety simulation with a drivable forklift, marked routes, and collision checks.",
];

export function ExamplePromptChips({
  onPick,
}: {
  onPick: (prompt: string) => void;
}) {
  return (
    <div>
      <p className="hint" style={{ marginTop: 20, marginBottom: 4 }}>
        Example simulations
      </p>
      <div className="chips">
        {EXAMPLES.map((example) => (
          <button
            key={example}
            type="button"
            className="chip"
            onClick={() => onPick(example)}
          >
            {example.length > 72
              ? `${example.slice(0, 69)}…`
              : example}
          </button>
        ))}
      </div>
    </div>
  );
}
