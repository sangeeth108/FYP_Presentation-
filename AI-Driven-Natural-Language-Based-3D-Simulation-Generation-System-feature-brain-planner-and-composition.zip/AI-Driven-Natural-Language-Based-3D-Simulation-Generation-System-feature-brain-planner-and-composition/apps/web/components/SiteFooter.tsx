/**
 * Site footer, rendered on every page from the root layout.
 *
 * It exists for a legal reason before an aesthetic one. Serendib Engine is a
 * rebranded Godot build, and CLAUDE.md section 14 requires the "based on Godot
 * Engine" credit and a non-affiliation disclaimer wherever the product is
 * presented. Until now the frontend carried that text nowhere: it was only in the
 * engine download response, so every page that named Serendib without offering a
 * download named it without the credit.
 *
 * Static content, so it has no states to define -- it cannot fail to load and
 * cannot be empty.
 */
import Link from "next/link";

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="band-inner">
        <nav aria-label="Footer">
          <Link href="/">Home</Link>
          <Link href="/simulations">Simulations</Link>
          <Link href="/engine">Engine</Link>
          <Link href="/privacy">Privacy</Link>
        </nav>
        <p className="legal">
          Serendib Engine is based on Godot Engine, used under the MIT licence.
          Serendib is not affiliated with or endorsed by the Godot project. Godot
          Engine is a trademark of its respective owners. Generated projects are
          yours; the engine retains its upstream licence and third-party notices,
          which are viewable in the editor&rsquo;s About dialog.
        </p>
        <p className="legal">
          A research prototype built as a final-year project. Generated worlds are
          verified against automated checks, not curated by hand.
        </p>
      </div>
    </footer>
  );
}
