"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { SiteFooter } from "./SiteFooter";

/**
 * Marketing header and footer, rendered only where they belong.
 *
 * The workspace supplies its own sidebar and header, so this returns null there.
 * It is a conditional RENDER rather than a CSS rule, and that distinction is the
 * point: `display: none` still ships the markup, so the upstream attribution in
 * the footer was present in the workspace's HTML source even though nothing drew
 * it. The product surface is meant to carry no engine name at all, and text that
 * is merely invisible is still text that was sent.
 *
 * The attribution itself is not weakened -- it renders on every marketing and
 * legal route, and on the download page where the binary changes hands, which is
 * where the licence requires it.
 */
const BARE = ["/dashboard"];

export function SiteChrome({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const bare = BARE.some(
    (prefix) => path === prefix || path.startsWith(`${prefix}/`),
  );

  if (bare) return <>{children}</>;

  return (
    <>
      <header className="site-header">
        <Link href="/" className="brand">
          <span className="brand-mark" aria-hidden>
            S
          </span>
          Serendib
        </Link>
        <nav className="nav" aria-label="Primary">
          <Link href="/">Home</Link>
          <Link href="/dashboard">Workspace</Link>
          <Link href="/simulations">Simulations</Link>
          <Link href="/engine">Workbench</Link>
          <Link href="/privacy">Privacy</Link>
        </nav>
      </header>
      {children}
      <SiteFooter />
    </>
  );
}
