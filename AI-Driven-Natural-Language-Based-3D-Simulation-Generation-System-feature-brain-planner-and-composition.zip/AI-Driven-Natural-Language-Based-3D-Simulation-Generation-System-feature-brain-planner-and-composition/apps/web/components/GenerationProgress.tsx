"use client";

import { useEffect, useState } from "react";

import type { SimulationReport, SimulationRun } from "@/lib/types";

/**
 * What a generation run is actually doing, while it does it.
 *
 * The run page previously showed a single sentence for the whole of a fifteen to
 * twenty minute job. A long job that reports one line is indistinguishable from a
 * hung one, and the person waiting has no way to tell which they are looking at.
 *
 * Everything here is derived from real state the backend already publishes -- the
 * run's `stage`, its `state`, its repair counter, and the validation rows as they
 * land. Nothing is a timed animation pretending to be progress: if the backend
 * stops moving, this stops moving, which is the honest behaviour and also the
 * useful one.
 *
 * Five stages, which is inside the range a stepper stays readable at. Each step is
 * one of four visually distinct states -- done, running, upcoming, failed --
 * because "which of these is happening now" is the question being asked.
 */

/** The backend's own stage vocabulary, in the order a run passes through it. */
const STAGES: { id: string; label: string; blurb: string }[] = [
  {
    id: "intake",
    label: "Reading your description",
    blurb: "Safety and scope checks, then the prompt becomes a structured brief.",
  },
  {
    id: "requirements",
    label: "Planning the world",
    blurb: "Deciding what the place contains and what a visitor can do there.",
  },
  {
    id: "asset_resolution",
    label: "Finding and making assets",
    blurb: "Reusing owned models where they fit, generating the rest.",
  },
  {
    id: "native_world_plan",
    label: "Building the world",
    blurb: "Terrain, placement, navigation and behaviour written into a project.",
  },
  {
    id: "validation",
    label: "Checking it",
    blurb: "Eighteen validators inspect the result. Seventeen must pass.",
  },
];

const FAILED = new Set([
  "failed",
  "failed_requirements",
  "failed_capability",
  "failed_build",
  "failed_validation",
  "failed_export",
]);

function stageIndex(stage: string | null | undefined): number {
  if (!stage) return 0;
  if (stage === "completed") return STAGES.length;
  const found = STAGES.findIndex((item) => item.id === stage);
  // An unrecognised stage means the backend moved on without telling this page
  // about it. Reporting the last known position is better than resetting to zero
  // and making a working run look like it restarted.
  return found === -1 ? 0 : found;
}

function elapsedLabel(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const rest = seconds % 60;
  return minutes > 0 ? `${minutes}m ${rest}s` : `${rest}s`;
}

export function GenerationProgress({
  run,
  report,
  startedAt,
}: {
  run: SimulationRun | null;
  report: SimulationReport | null;
  startedAt: number;
}) {
  const [now, setNow] = useState(() => Date.now());

  const state = run?.state ?? "queued";
  const failed = FAILED.has(state);
  const complete = state === "completed";
  const current = complete ? STAGES.length : stageIndex(run?.stage);

  // The clock only ticks while something is happening. Leaving an interval
  // running on a finished page is a battery cost for a number that cannot change.
  useEffect(() => {
    if (complete || failed) return;
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [complete, failed]);

  const percent = complete
    ? 100
    : Math.round((current / STAGES.length) * 100);
  const elapsed = Math.max(0, Math.floor((now - startedAt) / 1000));

  const gates = report?.validation ?? [];
  const passed = gates.filter((gate) => gate.status === "PASS").length;

  // asset_geometry carries `asset_tiers` -- how many meshes came from the cache,
  // the owned library, generation, or fell through to procedural primitives.
  const assetLayer = gates.find((gate) => gate.layer === "asset_geometry");
  const rawTiers = (assetLayer?.evidence?.["asset_tiers"] ?? {}) as Record<
    string,
    unknown
  >;
  const tiers = Object.entries(rawTiers)
    .map(([tier, count]) => [tier, Number(count) || 0] as [string, number])
    .filter(([, count]) => count > 0)
    .sort((left, right) => right[1] - left[1]);
  const tierTotal = tiers.reduce((sum, [, count]) => sum + count, 0);

  return (
    <section className="progress-card" aria-labelledby="progress-title">
      <div className="progress-head">
        <h2 id="progress-title">
          {complete
            ? "Verified and published"
            : failed
              ? "This run did not pass"
              : STAGES[Math.min(current, STAGES.length - 1)].label}
        </h2>
        <span className="elapsed">
          {complete || failed
            ? `finished in ${elapsedLabel(elapsed)}`
            : `${elapsedLabel(elapsed)} elapsed`}
        </span>
      </div>

      {/* role=progressbar so a screen reader gets the number, not just the bar. */}
      <div
        className={`bar${failed ? " failed" : !complete ? " working" : ""}`}
        role="progressbar"
        aria-valuenow={percent}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label="Generation progress"
      >
        <i style={{ width: `${Math.max(percent, failed ? 100 : 4)}%` }} />
      </div>

      <ol className="stages">
        {STAGES.map((stage, index) => {
          const done = index < current;
          const active = index === current && !complete && !failed;
          const broke = failed && index === current;
          const className = broke
            ? "failed"
            : done || complete
              ? "done"
              : active
                ? "active"
                : "";
          return (
            <li key={stage.id} className={className}>
              <span className="tick" aria-hidden>
                {done || complete ? "✓" : broke ? "!" : ""}
              </span>
              <span>
                {stage.label}
                <br />
                <span className="req">{stage.blurb}</span>
              </span>
            </li>
          );
        })}
      </ol>

      {gates.length > 0 && (
        <>
          <div className="progress-head" style={{ margin: "22px 0 0" }}>
            <h2 style={{ fontSize: "1rem" }}>Validation</h2>
            <span className="elapsed">
              {passed} of {gates.length} passed
            </span>
          </div>
          <div className="gates">
            {gates.map((gate, index) => (
              <div className="gate" key={`${gate.layer}-${index}`}>
                <span
                  className={`dot-state ${
                    gate.status === "PASS"
                      ? "pass"
                      : gate.status === "FAIL"
                        ? "fail"
                        : "pending"
                  }`}
                  aria-hidden
                />
                <span className="name" title={gate.layer}>
                  {gate.layer.replace(/_/g, " ")}
                </span>
                <span className="req">
                  {gate.status === "PASS"
                    ? "pass"
                    : gate.status === "FAIL"
                      ? gate.mandatory
                        ? "failed"
                        : "advisory"
                      : "waiting"}
                </span>
              </div>
            ))}
          </div>
        </>
      )}

      {/* Where the meshes came from. Already recorded in the asset_geometry
          evidence and, until now, visible only by querying the database -- so the
          generation hit rate was something you inferred from worker logs rather
          than read. It matters more since the planner stopped being allowed to
          skip the resolution ladder: every object now depends on generation
          landing, and `procedural` here is the count that fell all the way
          through to primitives. */}
      {tiers.length > 0 && (
        <>
          <div className="progress-head" style={{ margin: "22px 0 0" }}>
            <h2 style={{ fontSize: "1rem" }}>Where the models came from</h2>
            <span className="elapsed">{tierTotal} resolved</span>
          </div>
          <div className="gates">
            {tiers.map(([tier, count]) => (
              <div className="gate" key={tier}>
                <span
                  className={`dot-state ${
                    tier === "generated" || tier === "cache" || tier === "curated"
                      ? "pass"
                      : tier === "unresolved"
                        ? "fail"
                        : ""
                  }`}
                  aria-hidden
                />
                <span className="name">{tier.replace(/_/g, " ")}</span>
                <span className="req">{count}</span>
              </div>
            ))}
          </div>
        </>
      )}

      {(run?.repair_attempts ?? 0) > 0 && (
        <p className="hint">
          Repair attempt {run?.repair_attempts} of {run?.max_repair_attempts ?? 3}
          . A failing check re-runs only the step responsible, never the whole
          world.
        </p>
      )}
    </section>
  );
}
