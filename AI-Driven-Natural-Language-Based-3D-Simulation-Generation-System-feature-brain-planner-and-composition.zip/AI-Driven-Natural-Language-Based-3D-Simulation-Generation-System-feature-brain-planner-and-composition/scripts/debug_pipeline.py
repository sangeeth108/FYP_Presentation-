#!/usr/bin/env python
"""Step-by-step pipeline debugger — run a prompt through the canonical brain
stages ONE AT A TIME and dump every intermediate output for inspection.

This is the "open the black box" tool: no API, no Celery, no DB, no Godot. It
calls the exact same pure functions the worker's native_pipeline uses, prints a
one-line summary per stage, and writes each stage's full JSON to a folder you can
open. You see precisely what the LLM decided, what the asset resolver chose, what
the PCG placed, and what every validator concluded — and you can edit a dumped
stage and (later) feed it back to control the result.

Usage:
    python scripts/debug_pipeline.py "a dog explores the moon"
    python scripts/debug_pipeline.py "a dog explores the moon" --seed 7 --generate
    LLM_ENABLED=true LLM_MODEL=qwen3.6:27b python scripts/debug_pipeline.py "..."

Flags:
    --seed N     deterministic seed (default 1)
    --generate   use the real SDXL/TripoSR backend for assets (GPU; slow).
                 Default is curated-only (fast, no GPU).
    --out DIR    output folder (default: artifacts/debug/<simulation_id>)

Stages dumped: 01 spec · 02 assets · 03 descriptors · 04 capabilities ·
05 behaviour · 06 world_plan · 07 validation · 08 traceability · 09 critic.
(Scene compile + Godot validation + export are the worker/engine stages; run the
full pipeline via /api/v1/simulations for those — this tool covers the brain.)
"""

from __future__ import annotations

import argparse
import json
import sys
import tempfile
import traceback
from pathlib import Path

_REPO = Path(__file__).resolve().parents[1]
# The asset resolver lives in the worker package; the rest in the brain.
for _p in (_REPO / "services" / "brain", _REPO / "services" / "worker"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))


def _dump(out_dir: Path, index: int, name: str, payload: object) -> Path:
    path = out_dir / f"{index:02d}_{name}.json"
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    return path


def _line(msg: str) -> None:
    print(msg, flush=True)


def _errors_of(report: object) -> int:
    if isinstance(report, dict):
        return len(report.get("errors", []) or [])
    if isinstance(report, (list, tuple)):
        return len(report)
    return 0


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("prompt")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--generate", action="store_true", help="use the real GPU asset backend")
    ap.add_argument("--out", type=Path, default=None)
    args = ap.parse_args(argv)

    from core.config import get_settings
    from core.ids import new_simulation_id

    settings = get_settings()
    simulation_id = new_simulation_id(args.prompt[:48])
    out_dir = args.out or (Path(settings.artifacts_dir).resolve() / "debug" / simulation_id)
    out_dir.mkdir(parents=True, exist_ok=True)

    _line("=" * 70)
    _line(f"DEBUG PIPELINE  prompt={args.prompt!r}  seed={args.seed}")
    _line(f"  simulation_id={simulation_id}")
    _line(f"  LLM_ENABLED={settings.llm_enabled}  model={settings.llm_model}")
    _line(f"  asset backend={'GENERATE (GPU)' if args.generate else 'curated-only'}")
    _line(f"  outputs -> {out_dir}")
    _line("=" * 70)

    # --- Stage 1: prompt -> SimulationSpec (LLM planner or deterministic draft) ---
    from agents.simulation_planner import plan_simulation, validate_simulation_spec

    # plan_simulation only calls the LLM when GIVEN a planner id + base_url (the
    # model router supplies them in production); pass them when the LLM is enabled,
    # else it uses the deterministic draft.
    planner_kwargs = {}
    if settings.llm_enabled:
        planner_kwargs = {
            "planner_model_id": settings.llm_model,
            "planner_base_url": settings.llm_base_url,
        }
    spec, source = plan_simulation(
        prompt=args.prompt,
        simulation_id=simulation_id,
        seed=args.seed,
        size_profile="small",
        target_platforms=["web"],
        domain_constraints=None,
        settings=settings,
        **planner_kwargs,
    )
    try:
        validate_simulation_spec(spec)
        schema_ok = "valid"
    except Exception as exc:  # noqa: BLE001
        schema_ok = f"SCHEMA INVALID: {exc}"
    p = _dump(out_dir, 1, "simulation_spec", spec)
    _line(f"[1] SPEC        source={source}  schema={schema_ok}")
    _line(f"    entities={len(spec.get('entities', []))} "
          f"capabilities={len(spec.get('capabilities', []))} "
          f"requirements={len(spec.get('requirements', []))}")
    _line(f"    -> {p.name}")

    # --- Stage 2: asset resolution (curated / generate) ---
    from asset_farm.pipeline import resolve_simulation_assets
    from asset_farm.registry import select_backend

    class _Cfg:
        asset_gen_enabled = args.generate
        asset_gen_backend = "local"
    backend = select_backend(_Cfg()) if args.generate else None
    tmp = Path(tempfile.mkdtemp(prefix="debugpipe_"))
    manifest = resolve_simulation_assets(
        spec,
        kit_dir=_REPO / "content" / "kits",
        cache_dir=tmp / "cache",
        work_dir=tmp / "work",
        backend=backend,
        embed_base_url=settings.llm_base_url if settings.rag_enabled else None,
    )
    tiers = {}
    for entry in manifest.values():
        tiers[entry.get("tier", "?")] = tiers.get(entry.get("tier", "?"), 0) + 1
    p = _dump(out_dir, 2, "asset_manifest", manifest)
    _line(f"[2] ASSETS      resolved={len(manifest)}  tiers={tiers}")
    _line(f"    -> {p.name}")

    # --- Stage 3: measured descriptors ---
    from assets.descriptors import descriptors_from_simulation_manifest

    descriptors, descriptor_errors = descriptors_from_simulation_manifest(spec, manifest)
    _dump(out_dir, 3, "descriptors", {"descriptors": descriptors, "errors": descriptor_errors})
    _line(f"[3] DESCRIPTORS count={len(descriptors)}  errors={len(descriptor_errors)}  "
          "-> 03_descriptors.json")

    # --- Stage 4: capability resolution ---
    from capabilities.registry import resolve_capabilities

    resolved_caps, capability_gaps = resolve_capabilities(
        spec.get("capabilities", []),
        spec["request"]["target_platforms"],
        spec=spec,
        asset_descriptors=descriptors,
    )
    _dump(out_dir, 4, "capabilities", {"resolved": resolved_caps, "gaps": capability_gaps})
    _line(f"[4] CAPABILITY  resolved={len(resolved_caps)}  gaps={len(capability_gaps)}  "
          "-> 04_capabilities.json")

    # --- Stage 5: behaviour compilation ---
    from behaviors.compiler import compile_behavior_plan, validate_compiled_behaviors

    behavior_plan, behavior_errors = compile_behavior_plan(spec, descriptors)
    behavior_validation = validate_compiled_behaviors(behavior_plan)
    _dump(out_dir, 5, "behavior_plan",
          {"plan": behavior_plan, "compile_errors": behavior_errors,
           "validation": behavior_validation})
    _line(f"[5] BEHAVIOUR   graphs={len(behavior_plan.get('graphs', []))}  "
          f"compile_errors={len(behavior_errors)}  "
          f"validation_errors={_errors_of(behavior_validation)}  -> 05_behavior_plan.json")

    # --- Stage 6: semantic world plan (seeded PCG placement) ---
    from pcg.semantic import generate_semantic_world_plan, validate_semantic_world_plan

    world_plan = generate_semantic_world_plan(
        spec, descriptors, behavior_plan.get("graphs", []),
    )
    p = _dump(out_dir, 6, "world_plan", world_plan)
    _line(f"[6] WORLD_PLAN  placed_entities={len(world_plan.get('entities', []))}  -> {p.name}")

    # --- Stage 7: deterministic validation (spatial + measured assets) ---
    measured = validate_semantic_world_plan(world_plan, require_measured_assets=True)
    _dump(out_dir, 7, "validation", measured)
    _line(f"[7] VALIDATION  errors={_errors_of(measured)}  "
          f"verdict={'PASS' if _errors_of(measured) == 0 else 'FAIL'}  -> 07_validation.json")

    # --- Stage 8: requirement traceability ---
    from verification.contracts import (
        deterministic_independent_critique,
        verify_requirement_traceability,
    )

    traceability = verify_requirement_traceability(spec, world_plan, behavior_plan)
    _dump(out_dir, 8, "traceability", traceability)
    _line(f"[8] TRACE       errors={_errors_of(traceability)}  "
          f"verdict={'PASS' if _errors_of(traceability) == 0 else 'FAIL'}  -> 08_traceability.json")

    # --- Stage 9: deterministic independent critique ---
    critic = deterministic_independent_critique(spec, world_plan, behavior_plan)
    _dump(out_dir, 9, "critic", critic)
    _line(f"[9] CRITIC      errors={_errors_of(critic)}  -> 09_critic.json")

    _line("=" * 70)
    _line(f"DONE. Open the folder to inspect every stage:\n  {out_dir}")
    _line("Edit a dumped stage (e.g. 01_simulation_spec.json) to see how the "
          "downstream stages\nchange — that is your control point.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except SystemExit:
        raise
    except Exception:  # noqa: BLE001 — a debugger should show the failing stage, not vanish
        traceback.print_exc()
        raise SystemExit(1) from None
