"""Generate prompts, run them, read the gates, keep what survives.

WHY. Fine-tuning needs pairs of (prompt -> correct spec). Prompts are free;
correct specs are not. Measured across eight varied prompts, zero passed every
gate, so there is currently nothing to point a model at -- train on that and it
learns to reproduce its own mistakes.

This closes the loop without a human in it. A local model writes prompts, the
pipeline runs them, and the GATES decide what is correct -- not an opinion, not
a heuristic, and not the model that wrote the spec. Runs whose gates are silent
become gold examples; the rest become labelled failures, which are just as
useful for a ranker or a preference pair.

Two things it deliberately does NOT do:

- It does not repair specs itself. The pipeline already runs bounded localized
  repair (<=3 attempts per failure class) and re-verifies. Adding a second
  repair loop outside it would hide which layer actually fixed something, and
  the lineage is the point.
- It does not keep fallback-authored specs. A run whose lineage says
  `deterministic_fallback_v1` contains a canned template, not model output.
  Before the planner was fixed, EVERY stored spec was that template; a corpus
  built then would have taught the model the bug.

Usage:
    python scripts/corpus_loop.py --count 20 --out corpus.jsonl
    python scripts/corpus_loop.py --count 5 --dry-run     # prompts only
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

_TERMINAL = {"completed", "succeeded", "published", "failed_validation", "failed", "error", "failed_build"}
_FALLBACK_MARKER = "deterministic_fallback"

# The scope v1 is frozen to (CLAUDE.md 1). A generator left unconstrained writes
# prompts the system was never meant to accept, and the resulting failures teach
# nothing except that the scope is real.
_PROMPT_SYSTEM = (
    "Write prompts for a system that turns a sentence into a small explorable "
    "3D scene. Each prompt is ONE sentence describing a single place.\n\n"
    "Rules for every prompt:\n"
    "- name the place, plainly: a village, a workshop, a forest clearing\n"
    "- name 3 to 8 specific objects a visitor would walk up to\n"
    "- say who the visitor is, e.g. \"As a dog,\" or \"As a surveyor,\"\n"
    "- say what they do: explore, inspect, visit\n"
    "- no combat, no puzzles, no story, no multiple locations\n"
    "- plain everyday objects; nothing a small asset library could not have\n\n"
    "Vary the setting widely: indoor and outdoor, rural and industrial, warm "
    "and cold. Do not repeat a setting. Return JSON only."
)

_PROMPT_SCHEMA = {
    "type": "object",
    "required": ["prompts"],
    "properties": {
        "prompts": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 1,
            "maxItems": 25,
        }
    },
}


def generate_prompts(
    count: int, base_url: str, model: str, timeout: float = 1200.0
) -> list[str]:
    """Ask the local model for `count` varied prompts inside the frozen scope."""
    payload = {
        "model": model,
        "stream": False,
        "think": False,
        "format": _PROMPT_SCHEMA,
        "keep_alive": "30m",
        # Higher than the planner's 0.2: the whole value here is spread. A
        # corpus of twenty near-identical villages teaches nothing.
        "options": {"temperature": 0.9, "seed": 0},
        "messages": [
            {"role": "system", "content": _PROMPT_SYSTEM},
            {"role": "user", "content": f"Write {count} prompts, each a different kind of place."},
        ],
    }
    request = urllib.request.Request(
        f"{base_url}/api/chat",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        body = json.loads(response.read())
    prompts = json.loads(body["message"]["content"]).get("prompts") or []
    # Deduplicate while preserving order: the model repeats itself given a big
    # count, and a duplicate prompt is a wasted ten-minute run.
    seen, unique = set(), []
    for prompt in prompts:
        key = " ".join(str(prompt).lower().split())
        if key and key not in seen:
            seen.add(key)
            unique.append(str(prompt).strip())
    return unique[:count]


def submit(api: str, prompt: str) -> str | None:
    request = urllib.request.Request(
        f"{api}/api/v1/simulations",
        data=json.dumps({"prompt": prompt}).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=180) as response:
            return json.loads(response.read()).get("run_id")
    except Exception as exc:  # noqa: BLE001
        print(f"  submit failed: {exc}", file=sys.stderr, flush=True)
        return None


def wait_for(api: str, run_id: str, timeout: float) -> dict | None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(f"{api}/api/v1/runs/{run_id}", timeout=30) as response:
                run = json.loads(response.read())
            if run.get("state") in _TERMINAL:
                return run
        except Exception:
            pass
        time.sleep(20)
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--count", type=int, default=20)
    parser.add_argument("--api", default="http://127.0.0.1:8000")
    parser.add_argument("--ollama", default="http://127.0.0.1:11434")
    parser.add_argument("--model", default="qwen3.6:27b")
    parser.add_argument("--out", default="corpus.jsonl")
    parser.add_argument("--run-timeout", type=float, default=2400.0)
    parser.add_argument(
        "--prompt-timeout",
        type=float,
        default=1200.0,
        help="seconds to allow for generating the prompt list",
    )
    parser.add_argument("--dry-run", action="store_true", help="print prompts, run nothing")
    args = parser.parse_args()

    print(f"asking {args.model} for {args.count} prompts...", flush=True)
    prompts = generate_prompts(
        args.count, args.ollama, args.model, args.prompt_timeout
    )
    for index, prompt in enumerate(prompts, 1):
        print(f"  {index:>2}. {prompt}", flush=True)
    if args.dry_run:
        return 0
    if not prompts:
        print("no prompts generated", file=sys.stderr, flush=True)
        return 1

    # Runs are serialised by the solo worker, so submit and wait one at a time
    # rather than flooding a queue whose depth tells us nothing.
    run_ids: list[str] = []
    for index, prompt in enumerate(prompts, 1):
        print(f"\n[{index}/{len(prompts)}] {prompt}", flush=True)
        run_id = submit(args.api, prompt)
        if run_id is None:
            continue
        run = wait_for(args.api, run_id, args.run_timeout)
        state = run.get("state") if run else "TIMEOUT"
        failures = (run.get("detail", {}) or {}).get("mandatory_failures") if run else None
        print(f"      {run_id}  {state}  mandatory={failures}", flush=True)
        run_ids.append(run_id)

    if not run_ids:
        print("no runs completed", file=sys.stderr, flush=True)
        return 1

    # Reuse the collector rather than reimplementing the fallback filter and the
    # gate summary, so both paths agree on what counts as usable.
    print("\nbuilding corpus...", flush=True)
    return subprocess.call(
        [
            sys.executable,
            str(Path(__file__).with_name("build_corpus.py")),
            "--api", args.api,
            "--runs", ",".join(run_ids),
            "--out", args.out,
        ]
    )


if __name__ == "__main__":
    raise SystemExit(main())
