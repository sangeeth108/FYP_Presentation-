"""Vendor a CC0 model pack into `content/kits/` as a self-describing kit.

WHY THIS EXISTS. The curated library was 29 models, hand-transcribed into a Python dict
in `asset_kit.py`. That is why it stayed 29: adding a pack meant editing source, so
nobody did, so a house had nothing to match and a gun did not exist at all. Measured
consequence -- a village's dwellings resolved to `banner_red`, a hanging cloth banner,
because the library owned no building.

A vendored pack ships its own `kit.json`, so the library grows by adding files rather
than by this repository's Python growing with it.

LICENSING (rule 12). Only CC0/MIT/Apache packs may enter the product path. This script
REFUSES to vendor a pack whose bundled licence text does not state one, rather than
trusting the caller -- the ledger is only worth keeping if nothing can get in behind it.
The pack's own licence file is copied in beside the models as the evidence, and a row is
appended to `docs/licensing_ledger.csv`.

Usage:
    python scripts/vendor_asset_pack.py --list
    python scripts/vendor_asset_pack.py --pack blaster-kit
    python scripts/vendor_asset_pack.py --all
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import re
import sys
import urllib.request
import zipfile
from datetime import date
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
KITS = REPO / "content" / "kits"
LEDGER = REPO / "docs" / "licensing_ledger.csv"

# Kenney packs, all CC0. The download URL is discovered from the asset page rather than
# hard-coded, because Kenney versions the path with a content hash that changes whenever
# a pack is updated -- a pinned URL would silently 404 later.
PACKS: dict[str, dict] = {
    "blaster-kit": {
        "slug": "blaster-kit",
        "kit": "kenney-blaster",
        "category": "prop",
        "note": "guns, ammunition, scopes and targets",
    },
    "survival-kit": {
        "slug": "survival-kit",
        "kit": "kenney-survival",
        "category": "prop",
        "note": "camp, tools and outdoor gear",
    },
    "furniture-kit": {
        "slug": "furniture-kit",
        "kit": "kenney-furniture",
        "category": "prop",
        "note": "domestic interiors",
    },
    "nature-kit": {
        "slug": "nature-kit",
        "kit": "kenney-nature",
        "category": "prop",
        "note": "trees, rocks and ground cover",
    },
    "city-kit-commercial": {
        "slug": "city-kit-commercial",
        "kit": "kenney-city",
        "category": "building_module",
        "note": "buildings and street furniture",
    },
    "castle-kit": {
        "slug": "castle-kit",
        "kit": "kenney-castle",
        "category": "building_module",
        "note": "walls, towers and gates",
    },
    "food-kit": {
        "slug": "food-kit",
        "kit": "kenney-food",
        "category": "prop",
        "note": "produce and prepared food",
    },
    # The pack the library was missing. Everything vendored before it was a modern city,
    # a castle or a campsite -- so "a village cottage" had nothing honest to match and
    # resolved to an office block. This one is cottages, gable roofs, fences, carts,
    # lanterns, fountains, hedges and roads: an actual village.
    "fantasy-town-kit": {
        "slug": "fantasy-town-kit",
        "kit": "kenney-town",
        "category": "prop",
        "note": "village houses, roofs, fences and street furniture",
    },
    "holiday-kit": {
        "slug": "holiday-kit",
        "kit": "kenney-holiday",
        "category": "prop",
        "note": "seasonal decoration",
    },
}

_PERMISSIVE = re.compile(
    r"creative commons zero|\bCC0\b|public domain|\bMIT\b|Apache License", re.IGNORECASE
)


def _fetch(url: str, timeout: int = 240) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "promptplay-vendor/1.0"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def _discover_zip(slug: str) -> str | None:
    """The current download URL for a pack, read off its own asset page."""
    page = _fetch(f"https://kenney.nl/assets/{slug}", timeout=60).decode("utf-8", "replace")
    urls = re.findall(r"https://kenney\.nl/media/pages/assets/[^\"'\s]+\.zip", page)
    return urls[0] if urls else None


# A few Kenney stems are systematic but not the word anybody searches for. The hint
# REPLACES the stem rather than being appended to it.
#
# Measured, and the opposite of the obvious: piling synonyms into a description makes
# matching WORSE. bge-m3 averages over the sentence, so a long entry drifts away from a
# short query. Against the query "a pistol":
#
#     "a gun"                                                 0.931
#     "a utensil knife"                                       0.768
#     "a blaster, a gun, a pistol, a firearm you hold..."      0.745
#
# The enumerated description lost to a kitchen knife. So descriptions here stay SHORT and
# canonical -- the plainest noun phrase for the thing, and nothing else.
_STEM_HINTS = {
    "blaster": "gun",
    "clip": "ammunition magazine",
    "silencer": "gun silencer",
    "scope": "gun scope",
    "bullet": "bullet",
    "grenade": "grenade",
    "target": "shooting target",
}


# What a pack's models ARE, in the plainest words. Without this every model in a pack
# got the same bare noun -- all 41 city models read "a building" -- so the embedder could
# not tell an office tower from anything else and a village cottage matched a skyscraper.
#
# Short and specific. This is the STYLE, which is what distinguishes two things that are
# both "a building": a medieval stone tower and a modern office block answer completely
# different briefs, and a library that cannot say which is which will always answer the
# wrong one.
_PACK_STYLE = {
    "kenney-town": "village",
    "kenney-city": "modern city",
    "kenney-castle": "medieval stone",
    "kenney-survival": "rustic camp",
    "kenney-furniture": "household",
    "kenney-food": "food",
    "kenney-holiday": "festive",
    "kenney-nature": "",
    "kenney-blaster": "",
}


def _describe(stem: str, pack_note: str, style: str = "") -> str:
    """A sentence the embedder can match a brief against.

    Describes the MODEL, not the pack. The first version appended the pack's subject to
    every entry, so all forty blaster models ended "..., guns, ammunition, scopes and
    targets" and the shared tail dominated the vector -- measured, "a pistol" matched
    `scope-large-a.glb` at 0.701 and "a shotgun" matched the same scope at 0.717.

    Kenney names are terse and systematic (`blaster-a`, `crate-small`), so the stem is
    expanded into words and its trailing variant letter dropped; a short hint is added
    only for stems whose name alone is genuinely ambiguous.
    """
    # Kenney's nature pack is camelCase (`tree_pineTallC`, `rock_largeA`), which embeds
    # as one unknown token. Splitting it into words is what lets "a pine tree" find it.
    words = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", stem)
    words = re.sub(r"[-_]+", " ", words).strip().lower()
    # Trailing variant marker: `tree pine tall C` -> `tree pine tall`.
    words = re.sub(r"\s+\b([a-z])\b$", "", words).strip() or words
    parts = words.split()
    hint = _STEM_HINTS.get(parts[0]) if parts else None
    if hint:
        # The hint stands in for the stem, keeping any qualifier that followed it:
        # `scope large` -> "a gun scope large". Short beats complete.
        return " ".join(["a", hint, *parts[1:]]).strip()
    if style:
        # Style FIRST, so it carries weight in a short phrase: "a modern city building"
        # is a different request from "a medieval stone tower", and both are different
        # from a village cottage -- which is the point. A brief the library cannot
        # honestly answer should fall below the floor and reach the procedural
        # `building_shell`, because a house-shaped house beats a real skyscraper.
        return f"a {style} {words}"
    return f"a {words}"


# Words that make a model ARCHITECTURE rather than a thing standing in a room. A pack
# category is one label for the whole download, which is too coarse for a town kit: the
# same zip holds gable roofs and lanterns, and calling all of it `prop` leaves a cottage
# brief with nothing in the building library to find.
_ARCHITECTURE_WORDS = (
    "wall", "roof", "door", "window", "stairs", "pillar", "chimney", "balcony",
    "overhang", "tower", "gate", "building", "structure", "arch", "column", "floor",
)


# Things that GROW or LIE ON the ground. Scenery, whatever pack they arrived in: a castle
# pack ships trees and boulders, and inheriting the pack's `building_module` default made
# every one of them unreachable.
_NATURE_WORDS = (
    "tree", "trunk", "log", "bush", "shrub", "hedge", "plant", "flower", "fern",
    "grass", "leaf", "leaves", "moss", "rock", "rocks", "stone", "boulder", "cliff",
    "mushroom", "cactus", "palm", "crop", "corn", "wheat", "hay",
)


def _model_category_for(stem: str, pack_default: str) -> str:
    """What this model IS, from its name, falling back to the pack's own default.

    Nature is checked before architecture and before the default, because the default is
    a statement about the pack rather than about the model. Measured on the vendored
    library: `kenney-castle` declares itself `building_module`, so `tree-large.glb`,
    `tree-small.glb` and `rocks-large.glb` were all filed as architecture --

        library by category: prop 876 | building_module 306 | character 19

    -- and a scatter species, which searches one category, could never see a tree. A
    forest therefore fell through to single-image mesh generation for its oaks, its
    rocks and its ferns, which is where the shattered dark crowns came from.

    A trunk is still a trunk in a castle pack. `_ARCHITECTURE_WORDS` keeps "column" and
    "pillar", so a stone column stays a building module; the nature check runs first only
    for words no building is made of.
    """
    words = re.sub(r"[-_]+", " ", stem).lower()
    # Architecture first. "stone" and "rock" name a MATERIAL as often as a thing, so
    # checking nature first filed `wall-window-stone` and `stairs-stone` as scenery -- a
    # wall built of stone is still a wall.
    if any(word in words for word in _ARCHITECTURE_WORDS):
        return "building_module"
    if set(words.split()) & set(_NATURE_WORDS):
        return "prop"
    return pack_default


def vendor(name: str, *, force: bool = False) -> bool:
    spec = PACKS[name]
    destination = KITS / spec["kit"]
    if destination.exists() and not force:
        print(f"  {name}: already vendored at {destination.relative_to(REPO)}")
        return False

    url = _discover_zip(spec["slug"])
    if url is None:
        print(f"  {name}: no download link found on the asset page", file=sys.stderr)
        return False
    print(f"  {name}: {url.rsplit('/', 1)[-1]}")
    archive = zipfile.ZipFile(io.BytesIO(_fetch(url)))

    licence_names = [n for n in archive.namelist() if "licen" in n.lower()]
    licence_text = (
        archive.read(licence_names[0]).decode("utf-8", "replace") if licence_names else ""
    )
    if not _PERMISSIVE.search(licence_text):
        print(
            f"  {name}: REFUSED -- bundled licence does not state CC0/MIT/Apache "
            "(rule 12: nothing enters the product path unverified)",
            file=sys.stderr,
        )
        return False

    models = [n for n in archive.namelist() if n.lower().endswith(".glb")]
    if not models:
        print(f"  {name}: no .glb models in the archive", file=sys.stderr)
        return False

    model_dir = destination / "models"
    model_dir.mkdir(parents=True, exist_ok=True)
    entries: dict[str, dict] = {}
    for member in sorted(models):
        stem = Path(member).stem
        out = model_dir / f"{stem}.glb"
        out.write_bytes(archive.read(member))
        entries[f"models/{stem}.glb"] = {
            "description": _describe(stem, spec["note"], _PACK_STYLE.get(spec["kit"], "")),
            "category": _model_category_for(stem, spec["category"]),
        }

    (destination / "LICENSE.txt").write_text(licence_text, encoding="utf-8")
    (destination / "kit.json").write_text(
        json.dumps(
            {
                "pack": spec["kit"],
                "licence": "CC0-1.0",
                "source": f"https://kenney.nl/assets/{spec['slug']}",
                "models": entries,
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    _ledger_row(spec, len(entries))
    print(f"    vendored {len(entries)} models -> {destination.relative_to(REPO)}")
    return True


def _ledger_row(spec: dict, count: int) -> None:
    """Append to the licensing ledger, matching whatever columns it already has."""
    if not LEDGER.is_file():
        print("    (no licensing_ledger.csv; skipping ledger row)", file=sys.stderr)
        return
    with LEDGER.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.reader(handle))
    if not rows:
        return
    header = rows[0]
    if any(spec["kit"] in row for row in rows[1:]):
        return
    values = {
        "component": spec["kit"],
        "name": spec["kit"],
        "kind": "asset_pack",
        "type": "asset_pack",
        "licence": "CC0-1.0",
        "license": "CC0-1.0",
        "version": "vendored",
        "source": f"https://kenney.nl/assets/{spec['slug']}",
        "url": f"https://kenney.nl/assets/{spec['slug']}",
        "license_url": "https://creativecommons.org/publicdomain/zero/1.0/",
        "commercial_ok": "yes",
        "territory_restrictions": "none",
        "territory_limits": "none",
        "product_path": "yes",
        "verified_date": date.today().isoformat(),
        "verified_on": date.today().isoformat(),
        "date": date.today().isoformat(),
        # What was actually checked: the licence text bundled INSIDE the downloaded
        # archive, not a claim on a web page that can change under us.
        "verified_by": "vendor_asset_pack.py (bundled LICENSE.txt)",
        "notes": f"{count} glTF models, {spec['note']}; CC0, attribution optional",
    }
    with LEDGER.open("a", encoding="utf-8", newline="") as handle:
        csv.writer(handle).writerow([values.get(column, "") for column in header])


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--pack", action="append", choices=sorted(PACKS))
    parser.add_argument("--all", action="store_true")
    parser.add_argument("--list", action="store_true")
    parser.add_argument("--force", action="store_true", help="re-vendor an existing kit")
    args = parser.parse_args(argv)

    if args.list:
        for name, spec in sorted(PACKS.items()):
            state = "vendored" if (KITS / spec["kit"]).exists() else "-"
            print(f"  {name:24} {spec['category']:16} {state:9} {spec['note']}")
        return 0

    names = sorted(PACKS) if args.all else (args.pack or [])
    if not names:
        parser.error("choose --pack NAME, --all, or --list")
    vendored = sum(int(vendor(name, force=args.force)) for name in names)
    print(f"\n{vendored} pack(s) vendored")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
