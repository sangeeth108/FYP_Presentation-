#!/usr/bin/env python3
"""Check docs/licensing_ledger.csv for completeness and product-path safety.

Rules enforced (see docs/LICENSING_LEDGER.md):
  - Every row has component, kind, license, product_path.
  - product_path is 'product' or 'research_only'.
  - product rows with commercial_ok='no' are violations (quarantine them).
  - product rows must not carry territory restrictions.
  - Warn (not fail) on product rows not yet verified (empty verified_date) —
    these MUST be verified before the component is actually used.

Exit 0 = OK (warnings allowed); exit 1 = violations found.
Usage: python scripts/check_licenses.py
"""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
LEDGER = REPO_ROOT / "docs" / "licensing_ledger.csv"

REQUIRED_COLUMNS = {"component", "kind", "license", "commercial_ok", "product_path"}
ALLOWED_PATHS = {"product", "research_only"}


def main() -> int:
    if not LEDGER.exists():
        print(json.dumps({"code": "LEDGER_MISSING", "path": str(LEDGER),
                          "message": "licensing_ledger.csv not found."}))
        return 1

    violations: list[dict] = []
    warnings: list[dict] = []

    with LEDGER.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        missing_cols = REQUIRED_COLUMNS - set(reader.fieldnames or [])
        if missing_cols:
            print(json.dumps({"code": "LEDGER_MISSING_COLUMNS", "path": str(LEDGER),
                              "message": f"Missing columns: {sorted(missing_cols)}"}))
            return 1

        for line_no, row in enumerate(reader, start=2):
            component = (row.get("component") or "").strip()
            path = (row.get("product_path") or "").strip()
            commercial = (row.get("commercial_ok") or "").strip().lower()
            territory = (row.get("territory_restrictions") or "").strip().lower()
            verified = (row.get("verified_date") or "").strip()

            if not component:
                violations.append({"code": "EMPTY_COMPONENT", "line": line_no,
                                   "message": "Row without a component name."})
                continue
            if path not in ALLOWED_PATHS:
                violations.append({
                    "code": "BAD_PRODUCT_PATH",
                    "line": line_no,
                    "component": component,
                    "message": (
                        f"product_path must be one of {sorted(ALLOWED_PATHS)}, got '{path}'."
                    ),
                })
                continue

            if path == "product":
                if commercial == "no":
                    violations.append({
                        "code": "NON_COMMERCIAL_IN_PRODUCT",
                        "line": line_no,
                        "component": component,
                        "message": "commercial_ok=no but product_path=product.",
                        "hint": (
                            "Quarantine to research_only or replace with a "
                            "product-safe alternative."
                        ),
                    })
                if territory and territory not in ("none", "n/a", ""):
                    violations.append({
                        "code": "TERRITORY_RESTRICTED_IN_PRODUCT",
                        "line": line_no,
                        "component": component,
                        "message": (
                            f"Territory restriction '{territory}' on a product-path component."
                        ),
                    })
                if not verified:
                    warnings.append({
                        "code": "UNVERIFIED_PRODUCT_COMPONENT",
                        "line": line_no,
                        "component": component,
                        "message": (
                            "No verified_date — verify the license against the primary source "
                            "BEFORE this component is used in the product path."
                        ),
                    })

    report = {"verdict": "FAIL" if violations else "PASS",
              "violations": violations, "warnings": warnings}
    print(json.dumps(report, indent=2))
    return 1 if violations else 0


if __name__ == "__main__":
    sys.exit(main())
