#!/usr/bin/env python
"""Print one ablation condition's summary, one metric per line.

The numbers a report table needs are buried in a report file that also carries
one row per run, so reading them by eye means scrolling past several hundred
kilobytes of rows. This prints just the summary block, in the order the
condition tables in Chapter 8 list their metrics.

    python scripts/read_condition.py E
    python scripts/read_condition.py D --report eval/reports/ablation_C-D_....json

Deliberately a file rather than a shell one-liner: the equivalent heredoc is
bash-only and this project is developed on PowerShell, where it fails.
"""

from __future__ import annotations

import argparse
import glob
import json
import sys
from pathlib import Path

# The order the condition tables in Chapter 8 list their rows.
METRICS = (
    "runs",
    "passed",
    "schema_valid",
    "genre_matched",
    "repaired",
    "llm_fallbacks",
    "latency_p50_ms",
    "latency_p95_ms",
)


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("condition", nargs="?", default="E", help="condition id, e.g. D or E")
    parser.add_argument(
        "--report",
        default=None,
        help="report file; defaults to the most recent in eval/reports/",
    )
    args = parser.parse_args(argv)

    path = args.report
    if path is None:
        # By modification time, not by name: the report names are not ordered,
        # so sorting them alphabetically returns an old file that happens to
        # sort last (ablation_v2_RC.json beat a run from today).
        candidates = sorted(
            glob.glob("eval/reports/ablation_*.json"),
            key=lambda p: Path(p).stat().st_mtime,
        )
        if not candidates:
            print("no ablation report in eval/reports/; run the ablation first")
            return 1
        path = candidates[-1]

    conditions = json.loads(Path(path).read_text(encoding="utf-8"))["conditions"]
    key = args.condition.upper()
    if key not in conditions:
        print(f"{path} holds {sorted(conditions)}, not {key}")
        return 1

    summary = conditions[key]["summary"]
    print(f"# {path}")
    print(f"# condition {key}: {summary.get('label', '')}")
    for metric in METRICS:
        if metric in summary:
            print(f"{metric:18s} {summary[metric]}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
