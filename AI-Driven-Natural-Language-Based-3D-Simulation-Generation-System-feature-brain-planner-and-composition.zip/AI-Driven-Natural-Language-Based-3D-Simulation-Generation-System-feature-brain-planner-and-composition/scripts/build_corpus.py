"""Collect finished runs into a training/RAG corpus.

WHY. Measured across eight varied prompts, `requirement_traceability` is the
dominant failure -- five of eight runs -- and every other failure is a one-off.
That is model behaviour, not a code defect: the planner quotes `source_text` it
cannot quote. Three rounds of prompt rules did not fix it, because rules do not
generalise the way examples do.

So the next lever is examples, and examples need collecting. This writes one
JSONL record per run: the prompt, the spec the model actually produced, and
what verification thought of it. Records where the planner FELL BACK are
excluded -- a run whose lineage says `deterministic_fallback_v1` contains a
canned template rather than model output, and training on it would teach the
model to reproduce the fallback. That is not hypothetical: before the planner
was fixed, every stored spec was that template.

Usage:
    python scripts/build_corpus.py --api http://127.0.0.1:8000 --out corpus.jsonl
    python scripts/build_corpus.py --runs run_abc,run_def --out corpus.jsonl

The output is deliberately plain JSONL so it can seed a pgvector store, a
few-shot prompt, or a fine-tune set without further transformation.
"""

from __future__ import annotations

import argparse
import json
import sys
import urllib.request
from typing import Any

# A run only earns a place if the planning model wrote the spec. See module
# docstring: fallback-authored specs are poison for a training corpus.
_FALLBACK_MARKER = "deterministic_fallback"

# Gates that judge THE SPEC THE MODEL WROTE. Everything else judges the asset
# library, the Godot toolchain, the browser, or a vision model whose
# reliability was measured and found wanting -- a perfect spec fails those too.
#
# Labelling on all 15 gates said 1 of 13 runs was usable. Labelling on these
# said 7. Six good examples were being discarded because something downstream
# of the model broke, which is the wrong signal entirely when the thing being
# trained IS the model.
SPEC_LEVEL_GATES = frozenset({
    "requirements_and_schema",
    "capability_declaration",
    "capability_resolution",
    "requirement_traceability",
    "deterministic_critic",
    "independent_model_critic",
    "behavior_compilation",
    "semantic_placement",
    "lineage",
})


def _get(api: str, path: str, timeout: float = 30.0) -> Any:
    with urllib.request.urlopen(f"{api}{path}", timeout=timeout) as response:
        return json.loads(response.read())


def _find_spec(node: Any) -> dict | None:
    """The SimulationSpec inside a stage payload, wherever it is nested."""
    if isinstance(node, dict):
        entities = node.get("entities")
        if (
            isinstance(entities, list)
            and entities
            and isinstance(entities[0], dict)
            and "physical" in entities[0]
            and "requirements" in node
        ):
            return node
        for value in node.values():
            found = _find_spec(value)
            if found is not None:
                return found
    elif isinstance(node, list):
        for value in node:
            found = _find_spec(value)
            if found is not None:
                return found
    return None


def collect(api: str, run_id: str) -> dict | None:
    """One corpus record, or None if this run should not be learned from."""
    try:
        run = _get(api, f"/api/v1/runs/{run_id}")
    except Exception as exc:  # noqa: BLE001 -- one bad run must not stop the sweep
        print(f"  {run_id}: unreachable ({exc})", file=sys.stderr)
        return None

    try:
        stage = _get(api, f"/api/v1/runs/{run_id}/stages/scene_spec")
    except Exception:
        print(f"  {run_id}: no scene_spec stage", file=sys.stderr)
        return None

    spec = _find_spec(stage)
    if spec is None:
        print(f"  {run_id}: no spec in scene_spec", file=sys.stderr)
        return None

    planner = str((spec.get("lineage") or {}).get("planner") or "")
    if planner.startswith(_FALLBACK_MARKER):
        print(f"  {run_id}: skipped, spec came from the fallback", file=sys.stderr)
        return None

    gates: dict[str, str] = {}
    try:
        verify = _get(api, f"/api/v1/runs/{run_id}/stages/verify")
        reports = (verify.get("payload") or {}).get("reports") or {}
        gates = {
            name: report.get("status")
            for name, report in reports.items()
            if isinstance(report, dict)
        }
    except Exception:
        pass

    prompt = str((spec.get("request") or {}).get("prompt") or "")
    failed = sorted(name for name, status in gates.items() if status not in ("PASS", None))

    return {
        "run_id": run_id,
        "prompt": prompt,
        # The description the planner was allowed to quote from, when the expand
        # stage produced one. A few-shot example is far more useful with it.
        "source_description": (spec.get("request") or {}).get("source_description"),
        "spec": spec,
        "planner": planner,
        "state": run.get("state"),
        "published": run.get("state") in ("completed", "succeeded", "published"),
        "gates": gates,
        "failed_gates": failed,
        # The label a ranker or preference pair needs: did this spec survive
        # verification, and if not, what objected.
        "clean": not failed,
        # `clean` -- did the whole artifact ship. `spec_clean` -- did the
        # MODEL do its job, regardless of whether the library had the right
        # mesh. Train the planner on `spec_clean`; report `clean` as the
        # system's end-to-end rate.
        "spec_clean": not (set(failed) & SPEC_LEVEL_GATES),
        "spec_failures": sorted(set(failed) & SPEC_LEVEL_GATES),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--api", default="http://127.0.0.1:8000")
    parser.add_argument("--runs", help="comma-separated run ids")
    parser.add_argument("--out", default="corpus.jsonl")
    args = parser.parse_args()

    if not args.runs:
        print(
            "no --runs given. There is no list-runs endpoint yet, so pass ids "
            "explicitly, e.g. --runs run_abc,run_def",
            file=sys.stderr,
        )
        return 2

    run_ids = [r.strip() for r in args.runs.split(",") if r.strip()]
    records = []
    for run_id in run_ids:
        record = collect(args.api, run_id)
        if record is not None:
            records.append(record)

    with open(args.out, "w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    clean = sum(1 for r in records if r["clean"])
    published = sum(1 for r in records if r["published"])
    print(f"\n{len(records)} usable of {len(run_ids)} runs -> {args.out}")
    spec_clean = sum(1 for r in records if r["spec_clean"])
    print(f"   spec_clean (train on these): {spec_clean}")
    print(f"   clean (every gate):          {clean}")
    print(f"   published:               {published}")
    if records:
        from collections import Counter

        counts = Counter(gate for r in records for gate in r["failed_gates"])
        print("   failures by gate:")
        for gate, count in counts.most_common():
            print(f"      {count:>2}  {gate}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
