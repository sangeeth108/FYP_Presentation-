#!/usr/bin/env python
"""Merge a QLoRA adapter into its base model and write servable weights.

Ollama 0.32 imports a safetensors directory directly for supported
architectures, so there is no need for a llama.cpp checkout or a GGUF
conversion step: merge here, then `ollama create` against the output directory.

The base is reloaded in bfloat16 rather than 4-bit. Merging into quantised
weights would bake the quantisation error into the result, and an 8B in bf16 is
about 16 GB, which fits the workstation this project targets.

    $env:PYTHONUTF8=1
    python scripts/merge_lora.py --adapter artifacts/planner-8b-lora

The tokenizer is written alongside the weights so that its chat template
travels with them; Ollama reads that template, and a merged model served with
the wrong one answers as if it had never been tuned.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

_REPO = Path(__file__).resolve().parents[1]
DEFAULT_ADAPTER = _REPO / "artifacts" / "planner-8b-lora"
DEFAULT_OUT = _REPO / "artifacts" / "planner-8b-merged"


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--adapter", type=Path, default=DEFAULT_ADAPTER)
    ap.add_argument("--out", type=Path, default=DEFAULT_OUT)
    ap.add_argument("--base-model", default=None,
                    help="defaults to the base recorded in the adapter config")
    args = ap.parse_args(argv)

    if not (args.adapter / "adapter_config.json").is_file():
        raise SystemExit(f"no adapter at {args.adapter}; run scripts/train_planner_lora.py first")

    import torch
    from peft import PeftConfig, PeftModel
    from transformers import AutoModelForCausalLM, AutoTokenizer

    peft_config = PeftConfig.from_pretrained(str(args.adapter))
    base_id = args.base_model or peft_config.base_model_name_or_path
    print(f"base    {base_id}")
    print(f"adapter {args.adapter}")

    base = AutoModelForCausalLM.from_pretrained(
        base_id, dtype=torch.bfloat16, device_map="cpu"
    )
    merged = PeftModel.from_pretrained(base, str(args.adapter)).merge_and_unload()

    args.out.mkdir(parents=True, exist_ok=True)
    merged.save_pretrained(str(args.out), safe_serialization=True)
    AutoTokenizer.from_pretrained(base_id).save_pretrained(str(args.out))

    print(f"\nmerged -> {args.out}")
    print("next:")
    print(f'  "FROM {args.out}" | Out-File -Encoding utf8 Modelfile')
    print("  ollama create promptplay-planner-8b -f Modelfile")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
