#!/usr/bin/env python3
"""Compile every Serendib contract and validate contract-backed fixtures.

Emits machine-readable error objects (CLAUDE.md rule: never bare strings).
Exit 0 = all valid; exit 1 = validation errors; exit 2 = environment problem.

Usage:
    python scripts/validate_contracts.py
Requires:
    pip install jsonschema>=4.21   (root pyproject [dev] extra)
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
SCHEMA_PATH = REPO_ROOT / "contracts" / "game_spec.schema.json"
SCHEMAS_DIR = REPO_ROOT / "contracts"
EXAMPLES_DIR = REPO_ROOT / "contracts" / "examples"
CAPABILITIES_DIR = REPO_ROOT / "capabilities" / "packs"


def error_object(code: str, path: str, message: str, hint: str = "") -> dict:
    return {"code": code, "path": path, "message": message, "hint": hint}


def main() -> int:
    try:
        from jsonschema import Draft202012Validator
    except ImportError:
        print(json.dumps(error_object(
            "MISSING_DEPENDENCY", "-", "jsonschema is not installed.",
            'Run: pip install "jsonschema>=4.21" (or install the root [dev] extra).',
        )))
        return 2

    errors: list[dict] = []

    # 1. Every schema must load and compile. A new agent contract is not
    # protected by CI unless it is discovered here.
    compiled: dict[str, dict] = {}
    for schema_path in sorted(SCHEMAS_DIR.glob("*.schema.json")):
        try:
            candidate = json.loads(schema_path.read_text(encoding="utf-8"))
            Draft202012Validator.check_schema(candidate)
            compiled[schema_path.name] = candidate
            print(f"OK  schema compiles: {schema_path.relative_to(REPO_ROOT)}")
        except (json.JSONDecodeError, Exception) as exc:
            errors.append(
                error_object(
                    "SCHEMA_NOT_2020_12_VALID",
                    str(schema_path),
                    str(exc),
                )
            )
    if SCHEMA_PATH.name not in compiled:
        errors.append(
            error_object(
                "SCHEMA_MISSING",
                str(SCHEMA_PATH),
                "Required legacy compatibility schema is missing.",
            )
        )
        schema = {}
    else:
        schema = compiled[SCHEMA_PATH.name]
    validator = Draft202012Validator(schema)

    # 2. Every example must validate (files named *.invalid.json are expected to FAIL).
    examples = sorted(EXAMPLES_DIR.glob("*.json"))
    if not examples:
        print("WARN no examples found in contracts/examples/")

    for example in examples:
        expect_invalid = example.name.endswith(".invalid.json")
        try:
            instance = json.loads(example.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            errors.append(error_object("EXAMPLE_INVALID_JSON", str(example), str(exc)))
            continue

        found = [
            error_object(
                code="SPEC_SCHEMA_VIOLATION",
                path="$." + ".".join(str(p) for p in err.absolute_path),
                message=err.message,
                hint=f"in {example.name}",
            )
            for err in validator.iter_errors(instance)
        ]

        if expect_invalid and not found:
            errors.append(error_object(
                "EXPECTED_FAILURE_PASSED", str(example),
                "File is named *.invalid.json but validates cleanly.",
                "Fixture files ending in .invalid.json must contain at least one violation.",
            ))
        elif not expect_invalid and found:
            errors.extend(found)
        else:
            label = "correctly rejected" if expect_invalid else "valid"
            print(f"OK  {example.relative_to(REPO_ROOT)} ({label})")

    # 3. Capability packs are executable plugins and must match their contract.
    capability_schema = compiled.get("capability_pack.schema.json")
    if capability_schema is None:
        errors.append(
            error_object(
                "CAPABILITY_SCHEMA_MISSING",
                str(SCHEMAS_DIR / "capability_pack.schema.json"),
                "Capability pack schema is required.",
            )
        )
    else:
        capability_validator = Draft202012Validator(capability_schema)
        manifests = sorted(CAPABILITIES_DIR.glob("*/manifest.json"))
        if not manifests:
            errors.append(
                error_object(
                    "CAPABILITY_MANIFESTS_MISSING",
                    str(CAPABILITIES_DIR),
                    "At least one capability pack is required.",
                )
            )
        for manifest in manifests:
            try:
                body = json.loads(manifest.read_text(encoding="utf-8"))
            except json.JSONDecodeError as exc:
                errors.append(
                    error_object("CAPABILITY_INVALID_JSON", str(manifest), str(exc))
                )
                continue
            found = list(capability_validator.iter_errors(body))
            if found:
                errors.extend(
                    error_object(
                        "CAPABILITY_SCHEMA_VIOLATION",
                        "$." + ".".join(str(p) for p in item.absolute_path),
                        item.message,
                        f"in {manifest.relative_to(REPO_ROOT)}",
                    )
                    for item in found
                )
            else:
                print(f"OK  {manifest.relative_to(REPO_ROOT)} (valid)")

    if errors:
        print(json.dumps({"verdict": "FAIL", "errors": errors}, indent=2))
        return 1

    print(json.dumps({"verdict": "PASS", "errors": []}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
