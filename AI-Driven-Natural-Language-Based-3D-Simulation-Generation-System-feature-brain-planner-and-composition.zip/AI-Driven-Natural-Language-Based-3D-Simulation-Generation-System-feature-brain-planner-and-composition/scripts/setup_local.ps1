# PromptPlay 3D - local setup helper (Windows PowerShell)
# Safe by design: checks tools, copies .env.example, runs validators.
# It NEVER installs software, never touches git config, never runs docker automatically.
# Usage:  powershell -ExecutionPolicy Bypass -File scripts\setup_local.ps1

$ErrorActionPreference = "Stop"
$repoRoot = Split-Path -Parent $PSScriptRoot

Write-Host "=== PromptPlay 3D local setup check ===" -ForegroundColor Cyan

# 1. Tool availability (report only - install instructions in docs/runbooks/LOCAL_SETUP.md)
$tools = @(
    @{ Name = "git";    Args = "--version" },
    @{ Name = "node";   Args = "--version" },
    @{ Name = "python"; Args = "--version" },
    @{ Name = "docker"; Args = "--version" }
)
foreach ($t in $tools) {
    $cmd = Get-Command $t.Name -ErrorAction SilentlyContinue
    if ($cmd) {
        $ver = & $t.Name $t.Args 2>$null | Select-Object -First 1
        Write-Host ("  OK      {0}  {1}" -f $t.Name.PadRight(8), $ver)
    } else {
        Write-Host ("  MISSING {0}  -> see docs/runbooks/LOCAL_SETUP.md" -f $t.Name.PadRight(8)) -ForegroundColor Yellow
    }
}

# 2. .env from template (never overwrites an existing .env)
$envFile = Join-Path $repoRoot ".env"
$envExample = Join-Path $repoRoot ".env.example"
if (-not (Test-Path $envFile)) {
    Copy-Item $envExample $envFile
    Write-Host "  Created .env from .env.example - fill values from the team vault (never commit it)." -ForegroundColor Green
} else {
    Write-Host "  .env already exists - left untouched."
}

# 3. Contract + license checks (needs: pip install jsonschema)
Write-Host "`n=== Validating contracts ===" -ForegroundColor Cyan
python (Join-Path $repoRoot "scripts\validate_contracts.py")
Write-Host "`n=== Checking licensing ledger ===" -ForegroundColor Cyan
python (Join-Path $repoRoot "scripts\check_licenses.py")

Write-Host "`nNext steps: docs/runbooks/LOCAL_SETUP.md" -ForegroundColor Cyan
