"""Re-derive `category` in every vendored `kit.json` from the current rule.

The categories were written once, at vendoring time, by whatever rule existed then. When
that rule is corrected the manifests do not correct themselves -- and a manifest is what
`model_category` trusts before anything else, so a stale one silently outranks the fix.

Descriptions, licences and provenance are left exactly as they are: this rewrites the one
field it recomputes, so re-running it can never lose what a pack said about itself.
"""

from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "scripts"))

from vendor_asset_pack import _model_category_for  # noqa: E402

KITS = REPO / "content" / "kits"


def main() -> int:
    apply = "--apply" in sys.argv
    moved: Counter = Counter()
    total = 0

    for manifest_path in sorted(KITS.glob("*/kit.json")):
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        models = manifest.get("models") or {}

        changed = 0
        for rel, entry in models.items():
            stem = Path(rel).stem
            was = str(entry.get("category") or "prop")
            # Each model's OWN category is the fallback, so a model whose name says
            # neither nature nor architecture keeps whatever it was filed as. Inferring a
            # pack-wide default from the majority instead swept 42 carts, lanterns,
            # fountains and market stalls in `kenney-town` into `building_module`.
            now = _model_category_for(stem, was)
            total += 1
            if now != was:
                moved[f"{was} -> {now}"] += 1
                changed += 1
                if apply:
                    entry["category"] = now

        if changed:
            print(f"  {manifest_path.parent.name:<26} {changed} model(s) recategorised")
            if apply:
                manifest_path.write_text(
                    json.dumps(manifest, indent=2, sort_keys=True) + "\n",
                    encoding="utf-8",
                )

    print(f"\n{total} models examined")
    for move, count in moved.most_common():
        print(f"  {move:<34} {count}")
    if not apply:
        print("\n(dry run -- pass --apply to write)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
