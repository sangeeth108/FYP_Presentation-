#!/usr/bin/env python
"""Test ONLY the brain: prompt -> SimulationSpec JSON. No assets, no engine, no gates.

Why this exists: running a prompt through the API exercises the whole pipeline, so
the browser shows an 18-layer verification wall when all you wanted to know is
"did the LLM understand my prompt?". This calls the planner directly and prints /
saves the spec, so a brain change can be judged in seconds instead of minutes.

Usage
    python scripts/brain_only.py "Explore a lush jungle with ruins"
    python scripts/brain_only.py "..." --seed 7 --size medium --json
    python scripts/brain_only.py "..." --rules      # force the deterministic draft
    python scripts/brain_only.py --compare "a jungle" "a martian colony"

Exit code is 1 when the spec fails schema validation, so it is CI-usable.
"""

from __future__ import annotations

import argparse
import json
import sys
import textwrap
import time
from pathlib import Path

_REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_REPO / "services" / "brain"))


def _plan(
    prompt: str,
    seed: int,
    size: str,
    use_llm: bool,
    expand: bool = False,
    extract: bool = False,
    deliberate: bool = False,
) -> tuple[dict, str, float, str | None]:
    from agents.brief_extractor import brief_as_planner_input, extract_brief
    from agents.deliberator import deliberate_brief
    from agents.prompt_expander import expand_prompt
    from agents.simulation_planner import plan_simulation
    from core.config import get_settings
    from core.ids import new_simulation_id

    settings = get_settings()
    kwargs: dict = {}
    if use_llm and settings.llm_enabled:
        # plan_simulation only calls the LLM when GIVEN a model id + base url (the
        # model router supplies them in production); without these it silently uses
        # the deterministic draft, which is the #1 source of "why is it generic?".
        kwargs = {
            "planner_model_id": settings.llm_model,
            "planner_base_url": settings.llm_base_url,
        }
    started = time.perf_counter()
    # Stage 1. Off by default so the two arms of the ablation are one flag apart.
    expansion = None
    if expand and kwargs:
        expansion = expand_prompt(
            prompt,
            settings=settings,
            model_id=kwargs["planner_model_id"],
            base_url=kwargs["planner_base_url"],
            seed=seed,
        )
    extraction = None
    if expansion and extract:
        extraction = extract_brief(
            expansion.description,
            settings=settings,
            model_id=kwargs["planner_model_id"],
            base_url=kwargs["planner_base_url"],
            seed=seed,
        )
    if extraction and deliberate:
        from dataclasses import replace as _replace

        outcome = deliberate_brief(
            extraction.brief,
            expansion.description,
            settings=settings,
            model_id=kwargs["planner_model_id"],
            base_url=kwargs["planner_base_url"],
            seed=seed,
        )
        extraction = _replace(extraction, brief=outcome.brief)
        print(
            f"  deliberate        rounds={len(outcome.rounds)} "
            f"changed={outcome.changed} stopped={outcome.stopped_because}"
        )
    spec, source = plan_simulation(
        brief=(
            brief_as_planner_input(extraction)
            if extraction
            else (expansion.description if expansion else None)
        ),
        prompt=prompt,
        simulation_id=new_simulation_id(prompt[:48]),
        seed=seed,
        size_profile=size,
        target_platforms=["web"],
        domain_constraints={},
        settings=settings,
        **kwargs,
    )
    return (
        spec,
        source,
        time.perf_counter() - started,
        expansion.description if expansion else None,
    )


def _summarise(spec: dict, source: str, elapsed: float) -> None:
    env = spec["environment"]
    print(f"  source            {source}   ({elapsed:.1f}s)")
    print(f"  planner           {spec['lineage']['planner']}")
    print(f"  schema_version    {spec['schema_version']}")
    print(f"  environment       {env['semantic_type']} · {env['terrain']} · {env['world_kind']}")
    print(f"  size              {env['dimensions_m']['width']}x{env['dimensions_m']['depth']} m")
    print(f"  time / weather    {env['time_of_day']} · {env['weather']}")
    print(f"  zones             {[z['zone_id'] for z in env.get('zones', [])]}")
    print(f"  capabilities      {spec.get('capabilities', [])}")
    print(f"  entities ({len(spec['entities'])})")
    for entity in spec["entities"][:12]:
        bbox = entity["physical"]["bbox_m"]
        print(
            f"      {entity['semantic_type'][:24]:24} {entity['role'][:16]:16}"
            f" {bbox[0]:.1f}x{bbox[1]:.1f}x{bbox[2]:.1f}m  caps={entity.get('capabilities', [])}"
        )
    scatter = spec.get("scatter") or []
    print(f"  scatter species ({len(scatter)})")
    for item in scatter:
        print(
            f"      {item['semantic_type'][:28]:28} {item['density_per_100m2']:>6}/100m²"
            f"  {item.get('clustering', '-')}"
        )
    print(f"  requirements      {[r['requirement_id'] for r in spec['requirements']]}")
    approximations = spec.get("approximations") or []
    if approximations:
        print(f"  approximations    {len(approximations)} disclosed")
        for item in approximations[:5]:
            print(f"      {item['reason'][:96]}")


def _validate(spec: dict) -> bool:
    """Schema + registry allowlist, i.e. the two gates the BRAIN must satisfy."""
    import jsonschema
    from agents.simulation_planner import validate_simulation_spec

    ok = True
    try:
        validate_simulation_spec(spec)
        print("  schema            VALID")
    except jsonschema.ValidationError as exc:
        ok = False
        print(f"  schema            INVALID at {list(exc.path)}: {exc.message[:120]}")

    from capabilities.registry import resolve_capabilities

    _, gaps = resolve_capabilities(
        spec.get("capabilities", []),
        spec["request"]["target_platforms"],
        spec=spec,
        asset_descriptors={},
        final=False,
    )
    if gaps:
        print(f"  capabilities      {len(gaps)} gap(s): {[g['capability_id'] for g in gaps]}")
    else:
        print("  capabilities      all resolvable")
    return ok


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("prompts", nargs="+", help="one or more prompts")
    parser.add_argument("--seed", type=int, default=4521)
    parser.add_argument("--size", choices=("small", "medium"), default="small")
    parser.add_argument("--rules", action="store_true", help="force the deterministic draft")
    parser.add_argument("--json", action="store_true", help="print the full spec JSON")
    parser.add_argument("--out", type=Path, default=None, help="write each spec to this dir")
    parser.add_argument("--compare", action="store_true", help="alias for multiple prompts")
    parser.add_argument(
        "--expand",
        action="store_true",
        help="run the expand stage first (prompt -> prose -> spec)",
    )
    parser.add_argument(
        "--show-brief", action="store_true", help="print the expanded description"
    )
    parser.add_argument(
        "--extract",
        action="store_true",
        help="run the extract stage after expand (prose -> SceneBrief -> spec)",
    )
    parser.add_argument(
        "--deliberate",
        action="store_true",
        help="critique and revise the SceneBrief after extract",
    )
    args = parser.parse_args(argv)

    ok = True
    for prompt in args.prompts:
        print("=" * 78)
        print(f"PROMPT: {prompt}")
        spec, source, elapsed, brief = _plan(
            prompt,
            args.seed,
            args.size,
            not args.rules,
            args.expand,
            args.extract,
            args.deliberate,
        )
        if brief and args.show_brief:
            print("  --- expanded description ---")
            for line in textwrap.wrap(brief, 92):
                print(f"  {line}")
            print("  ---")
        _summarise(spec, source, elapsed)
        if not _validate(spec):
            ok = False
        if args.json:
            print(json.dumps(spec, indent=2))
        if args.out:
            args.out.mkdir(parents=True, exist_ok=True)
            path = args.out / f"{spec['meta']['simulation_id']}.json"
            path.write_text(json.dumps(spec, indent=2), encoding="utf-8")
            print(f"  written           {path}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
