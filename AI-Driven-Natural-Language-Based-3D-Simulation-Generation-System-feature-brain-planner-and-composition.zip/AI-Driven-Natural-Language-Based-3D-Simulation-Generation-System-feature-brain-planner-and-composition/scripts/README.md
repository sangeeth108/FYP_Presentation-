# scripts/ — repo utilities

**What this is:** small, safe, cross-cutting utilities that don't belong to one service.

**Files:**
- `setup_local.ps1` / `setup_local.sh` — check tools, create `.env` from template, run validators. Never installs software or runs destructive commands.
- `validate_contracts.py` — compiles `contracts/game_spec.schema.json` (JSON Schema 2020-12) and validates all `contracts/examples/*.json` (files named `*.invalid.json` must fail). Machine-readable error output. CI job.
- `check_licenses.py` — enforces `docs/licensing_ledger.csv` rules (no non-commercial or territory-restricted components in the product path). CI job.
- `p3_gate.py` — runs the **P3 gate** (CLAUDE.md §11: *download project → open in Serendib → AI-dock edit → re-export*) live, end to end, against a **real Godot export**: prompt → `DEPLOYED` → `project.zip` carrying `game_spec.json` + the enabled Assist addon → a dock edit → re-export → `DEPLOYED`. Prints PASS/FAIL per check and exits non-zero on failure. **Not a CI job** — it needs a real Godot binary and takes minutes; run it locally when the pipeline changes. Set `GODOT_BIN` (it defaults to a local path). Writes to `p3_gate_artifacts/` + `p3_gate.db`, both disposable. It found the `/reexport` registry hole on its first run, which is the point of having it.

**Owner:** M1 (Platform), with M2 for contract tooling.

**When updated:** whenever a new repo-wide chore appears (e.g. model re-download script, DB backup script). Add a header comment: purpose, usage, safety notes.

**Common mistakes to avoid:**
- Putting service-specific logic here (belongs in the service).
- Scripts with side effects that aren't obvious from the name — destructive actions require an explicit `--force`-style flag and a prompt.
- Windows-only or Unix-only scripts without a counterpart — provide both (`.ps1` + `.sh`) for anything a teammate must run.
