"""Measure world quality across every stored spec, not across two prompts.

The end-to-end pipeline takes ~30 minutes a run, which is why this project's findings kept
coming from whichever two prompts were being watched. `generate_semantic_world_plan` needs
no GPU, no LLM and no build -- so the planning stage can be run over every spec on disk in
seconds, and any claim about "the system" can be checked against all of them.

Reports, per spec: how much of the world the content actually occupies, what failed to
place, and how many objects a player would see.
"""

from __future__ import annotations

import argparse
import json
import statistics
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services/brain"))

from pcg.semantic import generate_semantic_world_plan  # noqa: E402


def _span(positions: list[list[float]], axis: int) -> float:
    values = [p[axis] for p in positions if len(p) >= 3]
    return (max(values) - min(values)) if values else 0.0


def measure(spec: dict) -> dict | None:
    """Plan one spec and report what a player would find in it."""
    try:
        plan = generate_semantic_world_plan(spec)
    except Exception as exc:  # noqa: BLE001 - a broken spec is a result, not a crash
        return {"error": f"{type(exc).__name__}: {exc}"[:120]}

    bounds = plan.get("world_bounds") or {}
    low, high = bounds.get("min") or [0, 0, 0], bounds.get("max") or [0, 0, 0]
    world_x, world_z = float(high[0]) - float(low[0]), float(high[2]) - float(low[2])

    entities = plan.get("entities") or []
    positions = [
        (e.get("transform") or {}).get("position_m") or [] for e in entities
    ]
    instances = ((plan.get("scatter") or {}).get("instances")) or []
    positions += [i.get("position_m") or [] for i in instances]

    span_x, span_z = _span(positions, 0), _span(positions, 2)
    fill = max(
        span_x / world_x if world_x else 0.0,
        span_z / world_z if world_z else 0.0,
    )

    summary = plan.get("constraint_summary") or {}
    shortfalls = Counter(
        str(s.get("shortfall_reason"))
        for s in ((plan.get("scatter") or {}).get("species") or [])
        if s.get("shortfall_reason")
    )

    # Anything a player cannot see in a wide shot of this world. 0.4% of the longest side
    # is roughly one pixel in a 1024 px render.
    invisible = 0
    for entity in entities:
        box = entity.get("world_aabb") or {}
        mn, mx = box.get("min"), box.get("max")
        if not (mn and mx):
            continue
        widest = max(mx[0] - mn[0], mx[2] - mn[2])
        if widest < 0.004 * max(world_x, world_z):
            invisible += 1

    return {
        "world_m": [round(world_x, 1), round(world_z, 1)],
        "fill": round(fill, 3),
        "entities": len(entities),
        "scatter": len(instances),
        "objects": len(entities) + len(instances),
        "unplaced": len(summary.get("unplaced_entities") or []),
        "invisible_entities": invisible,
        "shortfalls": dict(shortfalls),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--limit", type=int, default=0, help="0 = every spec")
    parser.add_argument("--sparse-below", type=float, default=0.55,
                        help="fill below this reads as islands on a plain")
    args = parser.parse_args()

    # One representative per distinct world type: the corpus is dominated by the same few
    # prompts re-run, and 400 copies of one village is not 400 measurements.
    by_type: dict[str, Path] = {}
    for path in sorted(ROOT.glob("artifacts/.staging/*/project/simulation_spec.json")):
        try:
            spec = json.loads(path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            continue
        kind = str((spec.get("environment") or {}).get("semantic_type") or "?")
        by_type.setdefault(kind, path)

    items = sorted(by_type.items())
    if args.limit:
        items = items[: args.limit]

    rows, errors = [], []
    for kind, path in items:
        spec = json.loads(path.read_text(encoding="utf-8"))
        result = measure(spec)
        if result is None or "error" in result:
            errors.append((kind, (result or {}).get("error", "no result")))
            continue
        rows.append((kind, result))

    print(f"distinct world types measured: {len(rows)}   (errors: {len(errors)})\n")
    print(f"{'world type':<36}{'world':>13}{'fill':>7}{'objects':>9}{'unplaced':>9}{'unseen':>7}")
    for kind, r in sorted(rows, key=lambda kv: kv[1]["fill"]):
        flag = "  <- sparse" if r["fill"] < args.sparse_below else ""
        print(
            f"{kind[:36]:<36}{str(r['world_m']):>13}{r['fill']:>7.2f}"
            f"{r['objects']:>9}{r['unplaced']:>9}{r['invisible_entities']:>7}{flag}"
        )

    fills = [r["fill"] for _, r in rows]
    objects = [r["objects"] for _, r in rows]
    sparse = [k for k, r in rows if r["fill"] < args.sparse_below]
    unplaced = [k for k, r in rows if r["unplaced"]]
    unseen = [k for k, r in rows if r["invisible_entities"]]
    shortfalls: Counter = Counter()
    for _, r in rows:
        shortfalls.update(r["shortfalls"])

    print("\n--- across every world type ---")
    print(f"  median fill        {statistics.median(fills):.2f}"
          f"   (below {args.sparse_below} reads as islands on a plain)")
    print(f"  median objects     {statistics.median(objects):.0f}")
    print(f"  sparse worlds      {len(sparse)} of {len(rows)}"
          f"  ({100 * len(sparse) / max(len(rows), 1):.0f}%)")
    print(f"  with unplaced      {len(unplaced)} of {len(rows)}")
    print(f"  with unseeable     {len(unseen)} of {len(rows)}")
    print(f"  scatter shortfalls {dict(shortfalls)}")
    if errors:
        print("\n--- specs that could not be planned ---")
        for kind, message in errors[:10]:
            print(f"  {kind[:34]:<34} {message}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
