#!/usr/bin/env python
"""QLoRA fine-tune of a small planner on the validator-filtered distillation set.

This is the RESEARCH path, not the governed one. `docs/runbooks/FINE_TUNING.md`
describes the production route: a frozen dataset of at least five hundred
approved examples, an approved candidate, a signed GPU-training image and
promotion through CANDIDATE -> EVALUATED -> SHADOW -> CANARY -> PRODUCTION. A
model produced here is fit for an ablation arm served behind a flag and for
nothing else; it must not be promoted on this dataset.

    # Windows needs UTF-8 mode: TRL reads its bundled jinja chat templates with
    # read_text() and no encoding, so cp1252 raises UnicodeDecodeError on import.
    $env:PYTHONUTF8=1
    python scripts/train_planner_lora.py --stats
    python scripts/train_planner_lora.py --base-model Qwen/Qwen3-8B

The split is by `spec_hash`, never at random: near-identical specifications on
both sides of a random split produce an evaluation score that measures
memorisation, which Chapter 8 states as a requirement and a test asserts
elsewhere in the codebase.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

_REPO = Path(__file__).resolve().parents[1]
DEFAULT_DATA = _REPO / "eval" / "reports" / "distill_generated.jsonl"
DEFAULT_OUT = _REPO / "artifacts" / "planner-8b-lora"


def load_pairs(path: Path) -> list[dict]:
    """Read the exporter's JSONL. Every row is {"messages": [...], "meta": {...}}."""
    if not path.is_file():
        raise SystemExit(f"no dataset at {path}; run eval/export_distillation.py first")
    lines = path.read_text(encoding="utf-8").splitlines()
    rows = [json.loads(line) for line in lines if line.strip()]
    kept = [r for r in rows if r.get("meta", {}).get("verdict") == "PASS"]
    if not kept:
        raise SystemExit(f"{path} holds no rows with verdict PASS")
    return kept


def split_by_spec(rows: list[dict], holdout: float, seed: int) -> tuple[list[dict], list[dict]]:
    """Hold out whole specification families, so no family spans the split."""
    families = sorted({r["meta"].get("spec_hash", "") for r in rows})
    rng = random.Random(seed)
    rng.shuffle(families)
    cut = max(1, int(len(families) * holdout))
    held = set(families[:cut])
    train = [r for r in rows if r["meta"].get("spec_hash", "") not in held]
    evaluate = [r for r in rows if r["meta"].get("spec_hash", "") in held]
    return train, evaluate


def report(rows: list[dict], train: list[dict], evaluate: list[dict]) -> None:
    lengths = [sum(len(m["content"]) for m in r["messages"]) for r in rows]
    lengths.sort()
    print(f"pairs                {len(rows)}")
    print(f"distinct spec_hash   {len({r['meta'].get('spec_hash') for r in rows})}")
    print(f"train / held out     {len(train)} / {len(evaluate)}")
    print(f"chars per pair       median {lengths[len(lengths) // 2]:,}  max {lengths[-1]:,}")
    overlap = {r["meta"].get("spec_hash") for r in train} & {
        r["meta"].get("spec_hash") for r in evaluate
    }
    print(f"family overlap       {len(overlap)} (must be 0)")


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--data", type=Path, default=DEFAULT_DATA)
    ap.add_argument("--base-model", default="Qwen/Qwen3-8B",
                    help="must carry a product-safe licence row in docs/licensing_ledger.csv")
    ap.add_argument("--out", type=Path, default=DEFAULT_OUT)
    ap.add_argument("--epochs", type=float, default=3.0)
    ap.add_argument("--rank", type=int, default=16)
    ap.add_argument("--max-length", type=int, default=4096)
    ap.add_argument("--holdout", type=float, default=0.2)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--stats", action="store_true", help="describe the split and exit")
    args = ap.parse_args(argv)

    rows = load_pairs(args.data)
    train_rows, eval_rows = split_by_spec(rows, args.holdout, args.seed)
    report(rows, train_rows, eval_rows)
    if args.stats:
        return 0

    if len(rows) < 500:
        print(f"\nNOTE: {len(rows)} pairs is below the 500 the governed runbook requires.")
        print("      Fine for a flagged ablation arm; not for promotion.\n")

    import torch
    from datasets import Dataset
    from peft import LoraConfig
    from transformers import BitsAndBytesConfig
    from trl import SFTConfig, SFTTrainer

    quantisation = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
    )
    peft_config = LoraConfig(
        r=args.rank,
        lora_alpha=args.rank * 2,
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                        "gate_proj", "up_proj", "down_proj"],
    )
    config = SFTConfig(
        output_dir=str(args.out),
        num_train_epochs=args.epochs,
        per_device_train_batch_size=1,
        gradient_accumulation_steps=8,
        learning_rate=2e-4,
        lr_scheduler_type="cosine",
        warmup_ratio=0.03,
        logging_steps=5,
        save_strategy="epoch",
        bf16=True,
        max_length=args.max_length,       # TRL 1.4 renamed this from max_seq_length
        packing=False,                    # one specification per example, never merged
        gradient_checkpointing=True,
        report_to=[],
        model_init_kwargs={"quantization_config": quantisation,
                           "dtype": torch.bfloat16,
                           "device_map": "auto"},
    )
    trainer = SFTTrainer(
        model=args.base_model,
        args=config,
        train_dataset=Dataset.from_list([{"messages": r["messages"]} for r in train_rows]),
        eval_dataset=Dataset.from_list([{"messages": r["messages"]} for r in eval_rows]),
        peft_config=peft_config,
    )
    trainer.train()
    trainer.save_model(str(args.out))
    print(f"\nadapter -> {args.out}")
    print("next: merge the adapter, convert to GGUF, then")
    print("  ollama create promptplay-planner-8b -f Modelfile")
    print("  python -m eval.ablation_runners.run_ablation --conditions D,E")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
