#!/usr/bin/env bash
# Production-parity smoke test: brings up the full Docker stack (Postgres + Redis +
# brain + a REAL Celery worker) and exercises the async job path end-to-end.
# Unlike the unit tests (SQLite + eager Celery), this proves API -> Redis -> Celery
# worker -> Postgres for real.
#
# Prereq: Docker Desktop running, and a local .env (cp .env.example .env).
# Usage:  bash scripts/verify_stack.sh
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."

API="http://127.0.0.1:8000"

echo "=== docker compose up -d --build ==="
docker compose up -d --build

cleanup() { echo "=== docker compose down ==="; docker compose down; }
trap cleanup EXIT

echo "=== wait for /healthz (up to ~120s; first build + migrations can be slow) ==="
for i in $(seq 1 120); do
  if curl -sf "$API/healthz" >/dev/null 2>&1; then echo "brain healthy after ${i}s."; break; fi
  if [ "$i" = "120" ]; then echo "FAIL: brain not healthy in time"; docker compose logs brain --tail 40; exit 1; fi
  sleep 1
done

echo "=== POST /api/v1/games ==="
RESP=$(curl -s -X POST "$API/api/v1/games" -H 'Content-Type: application/json' \
  -d '{"prompt":"a foggy village where I scavenge supplies and escape by boat","options":{"genre":"topdown_survival_escape_3d","camera":"top_down_3d"}}')
echo "$RESP"
JOB=$(echo "$RESP" | python -c "import sys,json; print(json.load(sys.stdin)['job_id'])")

echo "=== poll GET /api/v1/jobs/$JOB until DEPLOYED (real Celery worker) ==="
for i in $(seq 1 30); do
  STATE=$(curl -s "$API/api/v1/jobs/$JOB" | python -c "import sys,json; print(json.load(sys.stdin)['state'])")
  echo "  attempt $i: $STATE"
  if [ "$STATE" = "DEPLOYED" ]; then echo "PASS: async job reached DEPLOYED via Redis+Celery+Postgres"; exit 0; fi
  sleep 1
done
echo "FAIL: job did not reach DEPLOYED in time"; exit 1
