"""P3 GATE, live and end to end:
    download project -> (open in Serendib) -> AI-dock edit -> re-export

Everything except the human opening the editor. Uses the REAL pipeline with a
real Godot export, not the CI stub.
"""

import json
import os
import sys
import zipfile
from pathlib import Path

REPO = Path(r"d:\AI Drive Natural Language Based 3D Simulation Generation System\promptplay")
ART = REPO / "p3_gate_artifacts"
os.environ["GODOT_BIN"] = r"C:\Users\3D simulation\Desktop\Godot_v4.7-stable_win64.exe"
os.environ["ARTIFACTS_DIR"] = str(ART)
os.environ["DATABASE_URL"] = "sqlite:///./p3_gate.db"
os.environ["CELERY_TASK_ALWAYS_EAGER"] = "true"
sys.path.insert(0, str(REPO / "services" / "brain"))
sys.path.insert(0, str(REPO / "services" / "worker"))

from core import db as db_module  # noqa: E402
from core.db import Base  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from main import app  # noqa: E402

Base.metadata.drop_all(bind=db_module.engine)
Base.metadata.create_all(bind=db_module.engine)

ok = True


def check(label, passed, detail=""):
    global ok
    ok &= bool(passed)
    print(f"  {'PASS' if passed else 'FAIL'}  {label}" + (f"  -> {detail}" if detail else ""))


with TestClient(app) as client:
    # --- 1. a prompt becomes a built, playable game ------------------------
    created = client.post(
        "/api/v1/games", json={"prompt": "escape the torchlit skeleton crypt", "seed": 7}
    ).json()
    game_id, job_id = created["game_id"], created["job_id"]
    job = client.get(f"/api/v1/jobs/{job_id}").json()
    print("\n[1] prompt -> game")
    check("job reached DEPLOYED", job["state"] == "DEPLOYED", job["state"])
    detail = job.get("detail", {})
    check("validation gates recorded", bool(detail.get("validation")),
          str(detail.get("validation", {}).get("verdict", "")))
    check("asset tiers recorded (lineage)", bool(detail.get("asset_tiers")),
          str(detail.get("asset_tiers")))

    # --- 2. the DOWNLOADABLE project ---------------------------------------
    print("\n[2] the downloadable project")
    zips = list(ART.rglob("project.zip"))
    check("project.zip was produced", bool(zips))
    if zips:
        with zipfile.ZipFile(zips[0]) as z:
            names = z.namelist()
        check("it is an openable Godot project", any(n.endswith("project.godot") for n in names))
        check("it ships the canonical spec (the dock reads it)",
              any(n.endswith("game_spec.json") for n in names))
        check("Serendib Assist addon is deployed",
              any("addons/serendib_assist/plugin.cfg" in n for n in names))
        check("the addon is ENABLED in project.godot",
              "serendib_assist/plugin.cfg" in
              zipfile.ZipFile(zips[0]).read(
                  next(n for n in names if n.endswith("project.godot"))).decode("utf-8"))
        spec_in_zip = json.loads(
            zipfile.ZipFile(zips[0]).read(next(n for n in names if n.endswith("game_spec.json")))
        )
        check("the shipped spec is the built spec", spec_in_zip["meta"]["game_id"] == game_id)

    # --- 3. the AI-dock edit round-trip ------------------------------------
    print("\n[3] the dock's edit (what the button in Serendib calls)")
    edited = client.post(
        "/api/v1/edits/preview",
        json={"spec": spec_in_zip, "instruction": "make the skeletons much faster and tougher"},
    ).json()
    check("edit is in contract", edited.get("valid"), str(edited.get("changed"))[:70])
    before = spec_in_zip["entities"]["enemies"][0]["stats"]
    after = edited["spec"]["entities"]["enemies"][0]["stats"]
    check("it actually changed the game", after != before, f"{before} -> {after}")
    check("bounds held (speed <= 12, health <= 1000)",
          after["speed"] <= 12 and after["health"] <= 1000)

    # --- 4. one-click re-export from the edited spec ------------------------
    print("\n[4] re-export the edited spec into a new playable build")
    r = client.post(f"/api/v1/games/{game_id}/reexport", json={"spec": edited["spec"]})
    check("re-export accepted", r.status_code == 202, str(r.status_code))
    rejob = client.get(f"/api/v1/jobs/{r.json()['job_id']}").json()
    check("re-export reached DEPLOYED", rejob["state"] == "DEPLOYED", rejob["state"])
    check("re-export re-validated the edited spec (not trusted)",
          bool(rejob.get("detail", {}).get("validation")))

    # --- 5. an out-of-contract edit is refused ------------------------------
    print("\n[5] an edited spec is not trusted more than a planned one")
    bad = json.loads(json.dumps(edited["spec"]))
    bad["entities"]["enemies"][0]["ai_template_id"] = "ai_teleporting_boss"  # invented
    rb = client.post(f"/api/v1/games/{game_id}/reexport", json={"spec": bad})
    check("invented template id refused", rb.status_code in (400, 422), str(rb.status_code))

print("\n" + ("P3 GATE: PASS" if ok else "P3 GATE: FAIL"))
sys.exit(0 if ok else 1)
