#!/usr/bin/env bash
# PromptPlay 3D - local setup helper (macOS / Linux)
# Safe by design: checks tools, copies .env.example, runs validators.
# It NEVER installs software, never touches git config, never runs docker automatically.
# Usage:  bash scripts/setup_local.sh

set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "=== PromptPlay 3D local setup check ==="

# 1. Tool availability (report only - install instructions in docs/runbooks/LOCAL_SETUP.md)
for tool in git node python3 docker; do
  if command -v "$tool" >/dev/null 2>&1; then
    printf '  OK      %-8s %s\n' "$tool" "$("$tool" --version 2>/dev/null | head -n1)"
  else
    printf '  MISSING %-8s -> see docs/runbooks/LOCAL_SETUP.md\n' "$tool"
  fi
done

# 2. .env from template (never overwrites an existing .env)
if [ ! -f "$REPO_ROOT/.env" ]; then
  cp "$REPO_ROOT/.env.example" "$REPO_ROOT/.env"
  echo "  Created .env from .env.example - fill values from the team vault (never commit it)."
else
  echo "  .env already exists - left untouched."
fi

# 3. Contract + license checks (needs: pip install jsonschema)
echo
echo "=== Validating contracts ==="
python3 "$REPO_ROOT/scripts/validate_contracts.py"
echo
echo "=== Checking licensing ledger ==="
python3 "$REPO_ROOT/scripts/check_licenses.py"

echo
echo "Next steps: docs/runbooks/LOCAL_SETUP.md"
