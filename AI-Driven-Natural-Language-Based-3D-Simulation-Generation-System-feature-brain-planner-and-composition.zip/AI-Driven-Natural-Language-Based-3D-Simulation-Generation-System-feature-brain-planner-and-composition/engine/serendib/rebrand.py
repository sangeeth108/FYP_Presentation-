#!/usr/bin/env python3
"""Serendib Engine rebrand tool (v0.1 — Tier 1 patch series).

Applies the Serendib identity onto a pristine Godot checkout at the pinned
stable tag. Never forks deeper: rebasing onto a newer tag = re-apply the
patches; if one no longer applies, FIX THE PATCH (CLAUDE.md engine rules).

Steps:
  1. Verify (or clone) upstream Godot at GODOT_PINNED_TAG into upstream/.
  2. Apply patches/*.patch in lexical order (dry-run first; idempotent —
     an already-patched tree is detected and reported, not double-patched).
  3. Copy branding assets over their upstream counterparts:
       branding/splash.png -> main/splash.png
       branding/icon.svg   -> icon.svg
  4. Run the legal checklist and refuse to bless a tree that fails it:
       - LICENSE.txt intact (MIT, "Godot Engine contributors" retained)
       - COPYRIGHT.txt present
       - About dialog carries the "based on Godot Engine" credit
       - version.py carries the Serendib identity

Usage:
  python rebrand.py --check              # dry run against upstream/
  python rebrand.py --apply              # patch + brand upstream/
  python rebrand.py --apply --upstream <path>   # a checkout elsewhere

Build afterwards (docs/runbooks/GODOT_BUILD.md):
  scons platform=<host> target=editor
  scons platform=web target=template_release   (emsdk 4.0.11 active)
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PINNED_TAG = "4.6.3-stable"
UPSTREAM_REPO = "https://github.com/godotengine/godot.git"

# Upstream 4.6 keeps brand assets under misc/logo/ + the runtime app icon
# at main/app_icon.png.
BRANDING_COPIES = [
    (HERE / "branding" / "splash.png", "main/splash.png"),
    (HERE / "branding" / "app_icon.png", "main/app_icon.png"),
    (HERE / "branding" / "icon.svg", "misc/logo/icon.svg"),
    (HERE / "branding" / "icon.svg", "misc/logo/logo.svg"),
    # The editor's OWN icons, which the first pass missed. `TitleBarLogo` sits in the
    # top-left corner of every editor window, so leaving it upstream meant the product
    # still read as somebody else's however much the splash said otherwise. Each is
    # drawn at the size of the slot it fills: the two wide ones are wordmarks, the
    # rest square glyphs, and an icon that does not match its slot's aspect gets
    # stretched by the editor's layout.
    (HERE / "branding" / "editor_logo.svg", "editor/icons/Logo.svg"),
    (HERE / "branding" / "editor_titlebar_logo.svg", "editor/icons/TitleBarLogo.svg"),
    (HERE / "branding" / "editor_glyph.svg", "editor/icons/Godot.svg"),
    (HERE / "branding" / "editor_glyph_monochrome.svg", "editor/icons/GodotMonochrome.svg"),
    (HERE / "branding" / "editor_file_icon.svg", "editor/icons/GodotFile.svg"),
]


def _run(cmd: list[str], cwd: Path) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)


def ensure_upstream(upstream: Path) -> bool:
    if (upstream / "version.py").is_file():
        head = _run(["git", "describe", "--tags", "--always"], upstream).stdout.strip()
        print(f"upstream: {upstream} ({head or 'not a git checkout'})")
        return True
    print(f"cloning godot @ {PINNED_TAG} into {upstream} (shallow)...")
    result = subprocess.run(
        ["git", "clone", "--depth", "1", "--branch", PINNED_TAG, UPSTREAM_REPO, str(upstream)]
    )
    return result.returncode == 0


def apply_patches(upstream: Path, check_only: bool) -> bool:
    ok = True
    for patch_file in sorted((HERE / "patches").glob("*.patch")):
        probe = _run(
            ["patch", "-p1", "--dry-run", "--fuzz=0", "-i", str(patch_file)], upstream
        )
        if probe.returncode != 0:
            reverse = _run(
                ["patch", "-p1", "--dry-run", "--reverse", "--fuzz=0", "-i", str(patch_file)],
                upstream,
            )
            if reverse.returncode == 0:
                print(f"  = {patch_file.name}: already applied")
                continue
            print(f"  ! {patch_file.name}: DOES NOT APPLY\n{probe.stdout}{probe.stderr}")
            ok = False
            continue
        if check_only:
            print(f"  + {patch_file.name}: applies cleanly")
            continue
        _run(["patch", "-p1", "--fuzz=0", "-i", str(patch_file)], upstream)
        print(f"  + {patch_file.name}: applied")
    return ok


def copy_branding(upstream: Path, check_only: bool) -> bool:
    ok = True
    for source, rel_dest in BRANDING_COPIES:
        dest = upstream / rel_dest
        if not source.is_file():
            print(f"  ! branding asset missing: {source}")
            ok = False
            continue
        if not dest.exists():
            print(f"  ! upstream target missing: {dest}")
            ok = False
            continue
        if check_only:
            print(f"  + would copy {source.name} -> {rel_dest}")
        else:
            shutil.copyfile(source, dest)
            print(f"  + branded {rel_dest}")
    return ok


def legal_checklist(upstream: Path) -> bool:
    checks = {
        "MIT license intact": "Godot Engine contributors"
        in (upstream / "LICENSE.txt").read_text(encoding="utf-8", errors="ignore"),
        "COPYRIGHT.txt present": (upstream / "COPYRIGHT.txt").is_file(),
        "About credit present": "based on Godot Engine"
        in (upstream / "editor/gui/editor_about.cpp").read_text(
            encoding="utf-8", errors="ignore"
        ),
        "Serendib identity set": 'name = "Serendib Engine"'
        in (upstream / "version.py").read_text(encoding="utf-8"),
    }
    for label, passed in checks.items():
        print(f"  {'+' if passed else '!'} {label}")
    return all(checks.values())


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="dry run")
    parser.add_argument("--apply", action="store_true", help="patch + brand the tree")
    parser.add_argument("--upstream", type=Path, default=HERE / "upstream")
    args = parser.parse_args()
    if not (args.check or args.apply):
        parser.error("pick --check or --apply")
    check_only = not args.apply

    if not ensure_upstream(args.upstream):
        print("FAILED: could not obtain upstream checkout")
        return 1
    print("patches:")
    patches_ok = apply_patches(args.upstream, check_only)
    print("branding:")
    branding_ok = copy_branding(args.upstream, check_only)
    if not check_only:
        print("legal checklist:")
        if not legal_checklist(args.upstream):
            print("FAILED: legal checklist — do not build/ship this tree")
            return 1
    if not (patches_ok and branding_ok):
        return 1
    print("OK" + (" (dry run)" if check_only else " — tree is Serendib-branded"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
