# Serendib upstream pin and rebase log

## Active production pin

| Item | Value | Verified | Basis |
|---|---|---|---|
| Upstream engine | `godotengine/godot` |
| Stable tag | **`4.7-stable`** | 2026-08-15 | Official upstream stable release; verified against a running `4.7.stable.official` binary |
| Emscripten | **`4.0.11`** | 2026-07-20 | Reproducible Serendib toolchain pin; upstream 4.6+ requires 4.0.0+ |
| SCons | 4.x | per build | Upstream build requirement |
| Python | 3.11/3.12 | per build | Upstream requires 3.8+ |

`4.7-stable` was briefly de-pinned on 2026-07-20 because the tag could not be
verified from the upstream release source that day. It has since been verified
directly: the toolchain runs a `4.7.stable.official` binary, and every artifact
the system has produced carries `config/features=PackedStringArray("4.7")`.
Holding at 4.6.3 would have invalidated those exports and contradicted the
evaluation environment recorded in the report, so the pin is restored to 4.7
rather than the rest of the system being moved back.

Web templates are built with `threads=no` for the broadly compatible browser
profile. The build workflow must produce an editor, web template, desktop
templates, hashes, branding-verification report, licence bundle, and SBOM before
an engine version is eligible for production.

## Rebase log

| Date | From | To | Result |
|---|---|---|---|
| 2026-07-20 | invalid/unverified `4.7-stable` pin | `4.6.3-stable` | Patch contexts and active build configuration corrected; full CI build still required |

For every future update:

1. Verify the stable tag from the official upstream release source.
2. Reapply all patches with `--fuzz=0`.
3. Rebuild native editor plus web and desktop export templates.
4. Run legal, visible-brand, launch, screenshot, project compatibility and
   browser/desktop parity tests.
5. Retain the previous three signed Serendib releases for rollback.
