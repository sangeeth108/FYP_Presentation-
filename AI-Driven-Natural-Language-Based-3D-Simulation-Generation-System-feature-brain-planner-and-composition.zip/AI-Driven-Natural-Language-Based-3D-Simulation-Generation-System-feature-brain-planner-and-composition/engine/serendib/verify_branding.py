#!/usr/bin/env python3
"""Fail release artifacts that leak inherited visible product branding."""

from __future__ import annotations

import argparse
import hashlib
import re
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_upstream(upstream: Path) -> list[str]:
    errors: list[str] = []
    version = (upstream / "version.py").read_text(
        encoding="utf-8", errors="replace"
    )
    for required in (
        'short_name = "serendib"',
        'name = "Serendib Engine"',
    ):
        if required not in version:
            errors.append(f"version.py lacks {required}")
    about = (upstream / "editor" / "gui" / "editor_about.cpp").read_text(
        encoding="utf-8", errors="replace"
    )
    if "Serendib Engine is based on Godot Engine" not in about:
        errors.append("About dialog lacks upstream credit/non-affiliation text")
    if "Godot Engine contributors" not in (
        upstream / "LICENSE.txt"
    ).read_text(encoding="utf-8", errors="replace"):
        errors.append("upstream MIT licence notice is missing")
    copies = (
        ("branding/splash.png", "main/splash.png"),
        ("branding/app_icon.png", "main/app_icon.png"),
        ("branding/icon.svg", "misc/logo/icon.svg"),
        ("branding/icon.svg", "misc/logo/logo.svg"),
        # The editor's own icons. `TitleBarLogo` is in the corner of every editor
        # window, so leaving it upstream meant the product read as somebody else's
        # however much the splash said otherwise -- and this verifier passed anyway,
        # because it was not looking.
        ("branding/editor_logo.svg", "editor/icons/Logo.svg"),
        ("branding/editor_titlebar_logo.svg", "editor/icons/TitleBarLogo.svg"),
        ("branding/editor_glyph.svg", "editor/icons/Godot.svg"),
        ("branding/editor_glyph_monochrome.svg", "editor/icons/GodotMonochrome.svg"),
        ("branding/editor_file_icon.svg", "editor/icons/GodotFile.svg"),
    )
    for source_rel, destination_rel in copies:
        source = HERE / source_rel
        destination = upstream / destination_rel
        if not destination.is_file() or _digest(source) != _digest(destination):
            errors.append(f"branding mismatch: {destination_rel}")

    # The default editor theme. Blue on neutral charcoal is the inherited look; the
    # product's own accent is #6366f1 on #0d1222.
    theme = (upstream / "editor/themes/editor_theme_manager.cpp").read_text(
        encoding="utf-8", errors="replace"
    )
    for required in (
        "preset_accent_color = Color(0.3882, 0.4, 0.9451)",
        "preset_base_color = Color(0.051, 0.0706, 0.1333)",
    ):
        if required not in theme:
            errors.append(f"default editor theme lacks {required}")

    # And no user-visible string may name the upstream engine, with four exceptions
    # that are legally required or factually correct:
    #
    #   - the About dialog's copyright line and third-party licence notice, and the
    #     credits dialog's thanks to the community whose work this is. MIT requires the
    #     first two; the third is attribution, and it sits beside the mandatory credit.
    #   - .NET/C# messages, which are not in this product's path (no C# web export) and
    #     one of which tells the reader to use a specific upstream RELEASE as a
    #     workaround -- a fact about that engine, not our branding.
    allowed_prefixes = ("editor/gui/editor_about.cpp", "modules/mono/", "platform/web/export/")
    result = subprocess.run(
        ["git", "grep", "-n", "-E", r'TTRC?\(\s*"[^"]*Godot'],
        cwd=upstream,
        capture_output=True,
        text=True,
    )
    for line in result.stdout.splitlines():
        if line.strip() and not line.startswith(allowed_prefixes):
            errors.append(f"user-visible string still names the upstream engine: {line[:110]}")
    return errors


def verify_project(project: Path) -> list[str]:
    errors: list[str] = []
    settings_path = project / "project.godot"
    if not settings_path.is_file():
        return ["project.godot is missing"]
    settings = settings_path.read_text(encoding="utf-8", errors="replace")
    required = (
        'config/icon="res://branding/serendib_icon.svg"',
        'boot_splash/image="res://branding/serendib_splash.png"',
        "boot_splash/bg_color=Color(0.027, 0.039, 0.078, 1)",
    )
    for value in required:
        if value not in settings:
            errors.append(f"project settings lack {value}")
    for relative in (
        "branding/serendib_icon.svg",
        "branding/serendib_splash.png",
    ):
        if not (project / relative).is_file():
            errors.append(f"runtime branding file missing: {relative}")
    return errors


def verify_web(build: Path) -> list[str]:
    index = build / "index.html"
    if not index.is_file():
        return ["web index.html is missing"]
    html = index.read_text(encoding="utf-8", errors="replace")
    errors: list[str] = []
    if "data-serendib-brand" not in html:
        errors.append("browser shell lacks Serendib brand marker")
    non_script = re.sub(
        r"<(?:script|style)\b[^>]*>.*?</(?:script|style)>",
        "",
        html,
        flags=re.IGNORECASE | re.DOTALL,
    )
    visible = re.sub(r"<[^>]+>", " ", non_script)
    if "Godot Engine" in visible:
        errors.append("browser shell contains visible inherited engine branding")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--upstream", type=Path)
    parser.add_argument("--project", type=Path)
    parser.add_argument("--web", type=Path)
    args = parser.parse_args()
    if not any((args.upstream, args.project, args.web)):
        parser.error("provide --upstream, --project, or --web")
    errors: list[str] = []
    if args.upstream:
        errors.extend(f"upstream: {item}" for item in verify_upstream(args.upstream))
    if args.project:
        errors.extend(f"project: {item}" for item in verify_project(args.project))
    if args.web:
        errors.extend(f"web: {item}" for item in verify_web(args.web))
    for error in errors:
        print(f"FAIL {error}")
    if errors:
        return 1
    print("PASS visible Serendib branding and upstream attribution checks")
    return 0


if __name__ == "__main__":
    sys.exit(main())

