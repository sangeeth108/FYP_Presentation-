@tool
extends Control

## Requests a bounded edit against the canonical simulation. The server
## recompiles and reruns every mandatory validator; this editor plugin never
## writes an unverified local spec or executes model-generated code.

const SPEC_PATH := "res://simulation_spec.json"
const DEFAULT_BRAIN_URL := "http://localhost:8000"

var _brain_url: LineEdit
var _access_token: LineEdit
var _instruction: TextEdit
var _request_btn: Button
var _status: RichTextLabel
var _http: HTTPRequest


func _init() -> void:
	custom_minimum_size = Vector2(300, 0)
	var root := VBoxContainer.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("separation", 8)
	add_child(root)
	root.add_child(_label("Serendib Assist", 18))
	root.add_child(_label("Request a verified simulation edit.", 11))
	root.add_child(_label("Serendib API URL", 11))
	_brain_url = LineEdit.new()
	_brain_url.text = DEFAULT_BRAIN_URL
	root.add_child(_brain_url)
	root.add_child(_label("Access token", 11))
	_access_token = LineEdit.new()
	_access_token.secret = true
	_access_token.placeholder_text = "OIDC bearer token (required in production)"
	root.add_child(_access_token)
	root.add_child(_label("Edit instruction", 11))
	_instruction = TextEdit.new()
	_instruction.placeholder_text = "e.g. make it rainy and add a water bowl"
	_instruction.custom_minimum_size = Vector2(0, 80)
	_instruction.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	root.add_child(_instruction)
	_request_btn = Button.new()
	_request_btn.text = "Generate verified revision"
	_request_btn.pressed.connect(_on_request)
	root.add_child(_request_btn)
	_status = RichTextLabel.new()
	_status.fit_content = true
	_status.custom_minimum_size = Vector2(0, 130)
	_status.bbcode_enabled = true
	root.add_child(_status)
	_http = HTTPRequest.new()
	_http.request_completed.connect(_on_response)
	add_child(_http)


func _label(text: String, size: int) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", size)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return label


func _on_request() -> void:
	var spec := _load_spec()
	var simulation_id := str(spec.get("meta", {}).get("simulation_id", ""))
	if simulation_id.is_empty():
		_set_status("[color=tomato]No canonical %s with a simulation id was found.[/color]" % SPEC_PATH)
		return
	if _instruction.text.strip_edges().is_empty():
		_set_status("[color=tomato]Type an edit instruction first.[/color]")
		return
	var headers := PackedStringArray(["Content-Type: application/json"])
	var token := _access_token.text.strip_edges()
	if not token.is_empty():
		headers.append("Authorization: Bearer %s" % token)
	var url := "%s/api/v1/simulations/%s/edits" % [
		_brain_url.text.strip_edges().trim_suffix("/"),
		simulation_id.uri_encode(),
	]
	_request_btn.disabled = true
	_set_status("Submitting the revision for full compilation and validation...")
	var error := _http.request(
		url,
		headers,
		HTTPClient.METHOD_POST,
		JSON.stringify({"instruction": _instruction.text.strip_edges()})
	)
	if error != OK:
		_request_btn.disabled = false
		_set_status("[color=tomato]Could not reach the Serendib API (error %d).[/color]" % error)


func _on_response(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	_request_btn.disabled = false
	var parsed = JSON.parse_string(body.get_string_from_utf8())
	if result != HTTPRequest.RESULT_SUCCESS or code != 202 or typeof(parsed) != TYPE_DICTIONARY:
		_set_status("[color=tomato]Revision request failed (HTTP %d). No local files were changed.[/color]" % code)
		return
	var run_id := str(parsed.get("run_id", ""))
	_set_status(
		("[color=lightgreen]Revision queued.[/color]\nRun: [code]%s[/code]\n" % run_id)
		+ "Download the replacement artifact only after every mandatory gate passes."
	)


func _load_spec() -> Dictionary:
	if not FileAccess.file_exists(SPEC_PATH):
		return {}
	var file := FileAccess.open(SPEC_PATH, FileAccess.READ)
	if file == null:
		return {}
	var parsed = JSON.parse_string(file.get_as_text())
	file.close()
	return parsed if typeof(parsed) == TYPE_DICTIONARY else {}


func _set_status(bbcode: String) -> void:
	_status.text = bbcode
