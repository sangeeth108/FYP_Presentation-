@tool
extends EditorPlugin

## Serendib Assist submits natural-language revisions to the canonical
## /simulations/{id}/edits API. The server recompiles and validates a replacement
## artifact. The plugin never writes an unverified spec or executes generated code.

const AssistDock := preload("res://addons/serendib_assist/assist_dock.gd")

var _dock: Control


func _enter_tree() -> void:
	_dock = AssistDock.new()
	_dock.name = "Serendib Assist"
	add_control_to_dock(EditorPlugin.DOCK_SLOT_RIGHT_UL, _dock)


func _exit_tree() -> void:
	if _dock != null:
		remove_control_from_docks(_dock)
		_dock.queue_free()
		_dock = null
