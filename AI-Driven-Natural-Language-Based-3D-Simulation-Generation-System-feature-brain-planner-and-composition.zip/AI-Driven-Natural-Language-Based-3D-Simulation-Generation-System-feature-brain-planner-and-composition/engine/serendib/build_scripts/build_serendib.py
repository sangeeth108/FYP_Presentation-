#!/usr/bin/env python
"""Build Serendib Engine from the pinned upstream tag.

Produces the three artifacts the production checklist requires: a host editor,
a web export template and a desktop export template, plus the hashes and the
branding-verification report that make a build auditable.

The build is deliberately a script rather than a documented sequence of manual
SCons invocations. A rebrand whose provenance depends on someone remembering
the right flags is a rebrand nobody can prove, and the legal position (the
Godot name and logo are trademarks; the code is MIT and its notices must
survive) rests on that proof.

Usage
-----
    python build_serendib.py --stage clone      # fetch the pinned tag
    python build_serendib.py --stage patch      # apply the rebrand series
    python build_serendib.py --stage editor     # host editor
    python build_serendib.py --stage web        # web export template
    python build_serendib.py --stage desktop    # desktop export template
    python build_serendib.py --stage all

The web stage needs an active emsdk matching the pinned Emscripten version in
`upstream-notes.md`; it refuses to run rather than silently producing a
template built by whatever emcc happens to be on PATH.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ENGINE = HERE.parent
REPO = ENGINE.parents[1]
UPSTREAM_URL = "https://github.com/godotengine/godot.git"
NOTES = ENGINE / "upstream-notes.md"


def pinned() -> dict[str, str]:
    """Read the pin from upstream-notes.md, which is the single source of it.

    Duplicating the tag into this script would let the two disagree, and the
    one that ends up in a build is whichever the script used.
    """
    text = NOTES.read_text(encoding="utf-8")
    tag = re.search(r"\|\s*Stable tag\s*\|\s*\*\*`([^`]+)`\*\*", text)
    ems = re.search(r"\|\s*Emscripten\s*\|\s*\*\*`([^`]+)`\*\*", text)
    if not tag or not ems:
        raise SystemExit("cannot read the pin from upstream-notes.md")
    return {"tag": tag.group(1), "emscripten": ems.group(1)}


def run(cmd: list[str], cwd: Path) -> None:
    run_env(cmd, cwd, None)


def run_env(cmd: list[str], cwd: Path, env: dict[str, str] | None) -> None:
    print(f"  $ {' '.join(cmd)}", flush=True)
    result = subprocess.run(cmd, cwd=cwd, env=env)
    if result.returncode != 0:
        raise SystemExit(f"failed ({result.returncode}): {' '.join(cmd)}")


def stage_clone(upstream: Path, pin: dict[str, str]) -> None:
    if (upstream / ".git").is_dir():
        print(f"upstream already present at {upstream}")
        return
    upstream.parent.mkdir(parents=True, exist_ok=True)
    # Shallow, single tag: the full history is ~2 GB of nothing this build
    # needs, and a rebase log lives in upstream-notes.md rather than in git.
    #
    # Retried, because a single-shot clone of a repository this size fails on
    # any connection that blinks: the first attempt here died with "unexpected
    # disconnect while reading sideband packet" after several hundred MB, and
    # a build that needs a human to notice and retype the command is a build
    # that does not run in CI. A partial transfer leaves an unusable directory
    # behind, so each attempt starts from a clean one.
    attempts = 3
    for attempt in range(1, attempts + 1):
        if upstream.exists():
            shutil.rmtree(upstream, ignore_errors=True)
        print(f"  clone attempt {attempt}/{attempts}", flush=True)
        result = subprocess.run(
            [
                "git",
                # Large buffer and no compression: the bottleneck is the remote
                # packing, and re-compressing locally makes a slow link slower.
                "-c", "http.postBuffer=524288000",
                "-c", "core.compression=0",
                "clone", "--depth", "1",
                "--branch", pin["tag"], UPSTREAM_URL, str(upstream),
            ],
            cwd=upstream.parent,
        )
        if result.returncode == 0:
            return
        print(f"  attempt {attempt} failed ({result.returncode})", flush=True)
    raise SystemExit(
        f"could not clone {pin['tag']} after {attempts} attempts. "
        "If the link is the problem, clone it once by hand into "
        f"{upstream} and re-run from --stage patch."
    )


def stage_patch(upstream: Path) -> None:
    run([sys.executable, str(ENGINE / "rebrand.py"), "--apply",
         "--upstream", str(upstream)], cwd=ENGINE)


def _scons(upstream: Path, args: list[str]) -> None:
    run([sys.executable, "-m", "SCons", *args], cwd=upstream)


# Direct3D 12 is not built. Generated projects declare
# `rendering_method="gl_compatibility"` for both desktop and mobile, because the
# delivery target is a WebGL2 browser build; a second Windows-only backend would
# be compiled, shipped and never selected. Vulkan and the Compatibility renderer
# remain enabled.
#
# AccessKit is NOT disabled, though the same flag would have made the build pass
# sooner. It is the editor's screen-reader support, the editor is a thing this
# project hands to users, and switching it off would make Serendib less
# accessible than the upstream it rebrands. `misc/scripts/install_accesskit.py`
# fetches it; the build refuses rather than silently dropping it.
_COMMON_FLAGS = ["d3d12=no"]


def _ensure_accesskit(upstream: Path) -> None:
    if (upstream / "bin" / "build_deps" / "accesskit").is_dir():
        return
    print("  fetching AccessKit (editor accessibility)", flush=True)
    run([sys.executable, "misc/scripts/install_accesskit.py"], cwd=upstream)


def stage_editor(upstream: Path) -> None:
    _ensure_accesskit(upstream)
    _scons(upstream, ["platform=windows", "target=editor", *_COMMON_FLAGS,
                      "-j", str(os.cpu_count() or 4)])


def _emsdk_root() -> Path:
    """Find the emsdk the pin refers to.

    `emsdk activate` writes a config but only exports the environment into the
    shell that sourced `emsdk_env`. A build that depends on the caller having
    done that is a build that works on one terminal and fails in CI, which is
    the failure this whole script exists to remove, so the environment is
    constructed here instead.
    """
    for candidate in (
        Path(os.environ["EMSDK"]) if os.environ.get("EMSDK") else None,
        Path("C:/emsdk"),
        Path.home() / "emsdk",
    ):
        if candidate is not None and (candidate / "upstream" / "emscripten").is_dir():
            return candidate
    raise SystemExit(
        "emsdk not found. Install and activate the pinned version:\n"
        "  git clone https://github.com/emscripten-core/emsdk C:/emsdk\n"
        "  cd C:/emsdk && python emsdk.py install <pin> && python emsdk.py activate <pin>"
    )


def _emsdk_env(root: Path) -> dict[str, str]:
    emscripten = root / "upstream" / "emscripten"
    env = dict(os.environ)
    env["EMSDK"] = str(root)
    env["EM_CONFIG"] = str(root / ".emscripten")
    env["EMSDK_PYTHON"] = sys.executable
    node = sorted((root / "node").glob("*/bin/node.exe")) or sorted(
        (root / "node").glob("*/node.exe")
    )
    if node:
        env["EMSDK_NODE"] = str(node[-1])
    env["PATH"] = os.pathsep.join(
        [str(root), str(emscripten), str(root / "upstream" / "bin"), env.get("PATH", "")]
    )
    return env


def stage_web(upstream: Path, pin: dict[str, str]) -> None:
    root = _emsdk_root()
    emcc = root / "upstream" / "emscripten" / "emcc.py"
    version = subprocess.run(
        [sys.executable, str(emcc), "--version"],
        capture_output=True, text=True, env=_emsdk_env(root),
    ).stdout
    if pin["emscripten"] not in version:
        head = version.splitlines()[1] if len(version.splitlines()) > 1 else version
        raise SystemExit(
            f"emcc is not the pinned {pin['emscripten']}:\n{head}\n"
            "A template built by a different Emscripten is not the pinned artifact, "
            "and the pin is what makes the web build reproducible."
        )
    print(f"  emcc {pin['emscripten']} at {root}", flush=True)
    # threads=no is the broadly compatible browser profile recorded in the
    # notes: single-threaded exports do not need cross-origin isolation, which
    # is what keeps Safari and iOS in reach. WebXR lives in the web platform
    # layer rather than behind a module flag, so it rides along with this.
    run_env(
        [sys.executable, "-m", "SCons", "platform=web", "target=template_release",
         "threads=no", "-j", str(os.cpu_count() or 4)],
        cwd=upstream,
        env=_emsdk_env(root),
    )


def stage_desktop(upstream: Path) -> None:
    _ensure_accesskit(upstream)
    _scons(upstream, ["platform=windows", "target=template_release", *_COMMON_FLAGS,
                      "-j", str(os.cpu_count() or 4)])


def stage_install_templates(upstream: Path) -> None:
    """Put the built templates where the editor looks for them.

    The directory is the version WITHOUT the build suffix. The editor reports
    itself as `4.7.stable.custom_build.<hash>` but searches
    `export_templates/4.7.stable/`, and an export against a missing template
    fails with a configuration error that names a path nobody created. The
    filenames are equally load-bearing: the editor asks for
    `web_nothreads_release.zip`, not the name SCons produced.
    """
    user_data = Path(os.environ["APPDATA"]) / "Serendib"
    version = "4.7.stable"
    target = user_data / "export_templates" / version
    target.mkdir(parents=True, exist_ok=True)
    mapping = {
        "godot.web.template_release.wasm32.nothreads.zip": "web_nothreads_release.zip",
        "godot.windows.template_release.x86_64.exe": "windows_release_x86_64.exe",
        "godot.windows.template_release.x86_64.console.exe":
            "windows_release_x86_64_console.exe",
    }
    installed = 0
    for built, expected in mapping.items():
        source = upstream / "bin" / built
        if not source.is_file():
            print(f"  skip {built} (not built)")
            continue
        shutil.copyfile(source, target / expected)
        print(f"  {expected} <- {built}")
        installed += 1
    if installed == 0:
        raise SystemExit("no templates were built; run --stage web and --stage desktop first")
    print(f"installed {installed} template(s) into {target}")


def _published_name(built_name: str) -> str:
    """Mirror of `published_name` in services/brain/api/engine.py.

    Duplicated because the build script is standalone tooling and the API is a
    service; there is no module both may import. A test asserts they agree, which is
    the safeguard that matters -- a silent drift here shows up as a download page
    whose every link 404s.
    """
    if built_name.startswith("godot."):
        return "serendib." + built_name[len("godot.") :]
    return built_name


def stage_publish(upstream: Path) -> None:
    """Copy the downloadable artifacts to where /artifacts/engine serves from.

    The manifest advertises `/artifacts/engine/<name>` and the API serves
    `artifacts_dir` statically, so without this the download page lists three
    builds and every link 404s -- worse than showing nothing, because it looks
    like a broken server rather than an unfinished feature.

    Only the three artifacts the API publishes are copied. The raw .wasm, the
    unwrapped .js and the console stubs are build intermediates; shipping them
    would put 40 MB of unreferenced files behind a public URL.

    Copied under the Serendib name. SCons hardcodes the `godot` prefix, so without
    this the editor is offered for download as `godot.windows.editor.x86_64.exe`
    however thoroughly the binary is branded. `published_name` in
    `services/brain/api/engine.py` derives the same name when serving, and a test
    asserts the two agree: if they drift, every link on the download page 404s.
    """
    published = (
        "godot.windows.editor.x86_64.exe",
        "godot.web.template_release.wasm32.nothreads.zip",
        "godot.windows.template_release.x86_64.exe",
    )
    target = REPO / "artifacts" / "engine"
    target.mkdir(parents=True, exist_ok=True)
    for name in published:
        source = upstream / "bin" / name
        if not source.is_file():
            print(f"  skip {name} (not built)")
            continue
        destination = target / _published_name(name)
        if destination.is_file() and destination.stat().st_size == source.stat().st_size:
            print(f"  {destination.name} already published")
            continue
        shutil.copyfile(source, destination)
        print(
            f"  published {destination.name} <- {name} "
            f"({source.stat().st_size / 1e6:.1f} MB)"
        )
    print(f"serving from {target}")


def digest(path: Path) -> str:
    sha = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            sha.update(block)
    return sha.hexdigest()


def write_manifest(upstream: Path, pin: dict[str, str]) -> Path:
    """Hash every produced binary, so a shipped engine can be traced to a build."""
    binaries = sorted(
        p for p in (upstream / "bin").glob("*")
        if p.is_file() and p.suffix.lower() in {".exe", ".zip", ".wasm", ".js", ""}
    )
    manifest = {
        "built_at": datetime.now(timezone.utc).isoformat(),
        "upstream_tag": pin["tag"],
        "emscripten": pin["emscripten"],
        "artifacts": [
            {"name": p.name, "bytes": p.stat().st_size, "sha256": digest(p)}
            for p in binaries
        ],
    }
    out = ENGINE / "build-manifest.json"
    out.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"wrote {out} ({len(binaries)} artifacts)")
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--stage",
        choices=["clone", "patch", "editor", "web", "desktop",
                 "install-templates", "publish", "manifest", "all"],
        required=True,
    )
    parser.add_argument("--upstream", type=Path, default=ENGINE / "upstream")
    args = parser.parse_args()

    pin = pinned()
    print(f"Serendib build — upstream {pin['tag']}, emscripten {pin['emscripten']}")
    stages = (
        ["clone", "patch", "editor", "web", "desktop",
         "install-templates", "publish", "manifest"]
        if args.stage == "all" else [args.stage]
    )
    for stage in stages:
        print(f"\n== {stage} ==", flush=True)
        if stage == "clone":
            stage_clone(args.upstream, pin)
        elif stage == "patch":
            stage_patch(args.upstream)
        elif stage == "editor":
            stage_editor(args.upstream)
        elif stage == "web":
            stage_web(args.upstream, pin)
        elif stage == "desktop":
            stage_desktop(args.upstream)
        elif stage == "install-templates":
            stage_install_templates(args.upstream)
        elif stage == "publish":
            stage_publish(args.upstream)
        elif stage == "manifest":
            write_manifest(args.upstream, pin)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
