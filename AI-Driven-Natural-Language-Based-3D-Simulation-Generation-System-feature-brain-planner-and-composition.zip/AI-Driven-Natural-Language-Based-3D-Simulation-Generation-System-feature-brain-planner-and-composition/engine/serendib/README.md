# engine/serendib — the Serendib Engine fork

**What this is:** tooling to produce Serendib Engine — a rebranded Godot 4.x fork maintained as a **patch series on a pinned upstream stable tag**. Upstream source is cloned into `upstream/` (gitignored — never vendored into this repo).

**What belongs here:**
- `patches/*.patch` — the Tier-1 rebrand patch series (version/name, splash, icons, About dialog, project-manager titles, **editor theme + visible strings**) and later Tier-2 additions (Serendib Assist EditorPlugin bundling).

**What the rebrand actually covers, as of 2026-08-21.** The first pass replaced the
name, splash and application icon, and the editor still read as somebody else's
product, because none of that is what you look at while using it. Now also replaced:

- **The default editor theme.** Accent `#6366f1` on ground `#0d1222`, taken from the
  product's own lab UI (`apps/web/app/globals.css`) rather than invented, so the engine
  and the site are recognisably one thing. The two inherited legacy presets are
  *renamed*, not deleted — they are another engine's historical looks and someone who
  likes them should keep them.
- **The five editor icons**, including `TitleBarLogo.svg`, which sits in the corner of
  every editor window and was the single most visible inherited mark. Each is drawn at
  the size of the slot it fills: two wordmarks, three square glyphs.
- **48 user-visible strings** in menus, dialogs and tooltips. Only strings inside a
  translation macro are touched, so source comments and MIT copyright headers cannot be
  altered by accident.

**What is deliberately NOT removed**, because §14 requires it or because removing it
would make the editor wrong:

| Kept | Why |
|---|---|
| `Copyright (c) 2014-present Godot Engine contributors` headers | MIT requires the copyright notice to be retained. Source, not UI. |
| `LICENSE.txt`, `COPYRIGHT.txt`, the About dialog's licence viewer and third-party notice | Removing them makes the binary non-redistributable. |
| "Serendib Engine is based on Godot Engine / Not affiliated with or endorsed by the Godot project" | The mandatory attribution and non-affiliation disclaimer. |
| "Thanks from the Godot community!" in the credits dialog | It thanks the people whose work this is, and it sits beside the mandatory credit. |
| .NET/C# messages (`modules/mono`, `platform/web/export`) | Not in this product's path (no C# web export). One names a specific upstream *release* as a workaround — a fact about that engine, not our branding. |
| The class-reference documentation URL | Never rendered; it is passed to `shell_open()`. The class reference genuinely *is* that documentation, and repointing it at a site that does not exist would break a working feature to hide a string nobody sees. |

`verify_branding.py` now checks all of the above — the icons, the theme colours, and
that no user-visible string outside those exceptions names the upstream engine. It
passed before this change while the editor plainly still looked inherited, because it
was only looking at the splash.

**This needs a full engine rebuild to be visible.** The theme and the strings are C++;
`artifacts/engine/*.exe` predates them.
- `build_scripts/` — SCons invocation wrappers, CI build matrix helpers, export-template packaging.
- `rebrand.py` — clones/checks out the pinned tag, applies patches, verifies legal checklist items.
- `upstream-notes.md` — pinned tag, matching Emscripten version, rebase log.

**Owner:** M3 (Engine & Build).

**When updated:** on tag pinning (P0), rebrand v0.1 (P1), Assist dock bundling (P3), and every upstream rebase (fix patches, never fork deeper).

**Rules (legally required — see docs/SECURITY_AND_PRIVACY.md):**
- Tier 3 (deep C++ changes) is **banned**; use GDExtension for native needs.
- Keep MIT LICENSE + copyright notices + license viewer in About.
- Never ship the Godot name/logo as product identity; credit "based on Godot Engine" + non-affiliation disclaimer.

**Common mistakes to avoid:**
- Wrong Emscripten version for the tag — the #1 web-template build failure (see `docs/runbooks/GODOT_BUILD.md`).
- Editing upstream files directly instead of maintaining patches — you lose the rebase discipline.
- Forgetting to tag engine releases — keep the last 3 downloadable.
