# engine/templates — vetted GDScript template library

**What this is:** the ~15–20 gameplay-critical GDScript templates that implement ALL game behavior. The LLM selects a **template id** and fills **parameters** — it never writes or edits these files. This is the project's core safety property.

**Layout:**

| Folder | Templates (planned, P1) |
|---|---|
| `controllers/` | CharacterBody3D controllers per camera: `controller_third_person`, `controller_topdown_3d`, `controller_isometric_3d` |
| `ai/` | NavigationAgent3D behaviors: `ai_patrol_chase`, `ai_wander`, `ai_guard_zone` |
| `combat/` | `combat_melee_basic`, `combat_ranged_basic`, damage/health components |
| `objectives/` | `collect_n`, `reach_zone`, `survive_timer`, `defeat_all`, fail states (`player_death`, `timer_expired`) |
| `interactables/` | `door_hinged` (state machine: open/close, lock/key, creak SFX, NavigationLink3D toggle), `pickup_supply`, `objective_trigger` |

**Template contract (every file):**
- One concern per script.
- `@export` tunables mirroring spec fields exactly (names match `game_spec` paths).
- Header comment linking the spec path it binds to.
- A scene-level behavior test that CI runs headless.
- Registered in `registry_templates` (DB allowlist) with a params schema.

**Owner:** M3 (with M4 for AI/placement-adjacent templates). **Every new/changed template requires two-person review** — these files run in every generated game.

**When updated:** P1 initial library; additions only through review + registry entry + test.

**Common mistakes to avoid:**
- "Letting the LLM near these later" (checklist wording) — never; it erodes the entire reliability story.
- Un-named or generic node names — editability in Serendib depends on PascalCase meaningful names.
- Template behavior depending on unseeded randomness — determinism down, always.
