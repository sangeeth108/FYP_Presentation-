extends Node3D
class_name SerendibCapabilityStateMachine

## Vetted interpreter for schema-bound BehaviorPlan graphs.
## It executes data only; generated simulations cannot provide scripts.

@export_multiline var graphs_json: String = "[]"

var _graphs: Dictionary = {}
# Continuous motion cannot come from _apply_observable, which fires once per
# transition. A machine that is running has to keep moving between transitions,
# so the flag is held and _process does the work.
var _spinning := false
var _spin_failed := false
# A sensor samples every frame rather than waiting for a key, so it needs the
# same frame callback the machine spin uses.
var _senses := false
var _sense_radius := 2.5
# A vehicle only needs frame work while somebody is aboard, so this is armed by
# the `occupied` property rather than at load.
var _vehicle_occupied := false
## Seconds between ticks of an `ecosystem_process`, and how long until the next one.
## Seeded from the node's own name so two processes in one world do not tick in
## lockstep -- the same reason scatter jitters per species.
var _process_period := 0.0
var _process_countdown := 0.0
var _drive_speed_mps := 6.0
var _turn_rate_rps := 1.4
# Headless probes cannot press keys, and driving is the part worth proving.
# Depth of the causal chain currently unwinding, shared across every machine in
# the scene because a chain runs from entity to entity rather than inside one.
static var _causal_depth := 0
var _probe_input := false
var _probe_throttle := 0.0
var _probe_steer := 0.0
var _states: Dictionary = {}
var _properties: Dictionary = {}


func _ready() -> void:
	var parsed: Variant = JSON.parse_string(graphs_json)
	if not parsed is Array:
		push_error("Serendib capability graph JSON is invalid")
		return
	for graph: Dictionary in parsed:
		var capability_id := String(graph.get("capability_id", ""))
		if capability_id.is_empty():
			continue
		_graphs[capability_id] = graph
		reset_capability(capability_id)
	# Only advertise as interactable if some capability here answers to a key.
	# A sensor fires on proximity and has no key-driven transition ever, so
	# listing it would put a floor plate -- always the nearest thing, being
	# underfoot -- at the head of the interact queue for no reason.
	for capability_id: String in _graphs:
		if capability_id != "sensor_trigger":
			add_to_group("serendib_interactable")
			break
	if _graphs.has("ecosystem_process"):
		# Between four and eight seconds, from the node name, so a world with several
		# processes does not step them all on the same frame.
		var salt := float(abs(hash(name)) % 1000) / 1000.0
		_process_period = 4.0 + salt * 4.0
		_process_countdown = _process_period * salt
	if _graphs.has("sensor_trigger"):
		_senses = true
		_sense_radius = _detection_radius()
	_refresh_process()


func reset_capability(capability_id: String) -> void:
	var graph: Dictionary = _graphs.get(capability_id, {})
	if graph.is_empty():
		return
	var initial := String(graph.get("initial_state", ""))
	_states[capability_id] = initial
	_properties[capability_id] = _properties_for(graph, initial)
	_apply_observable(capability_id)


func trigger(capability_id: String, event: String) -> bool:
	var graph: Dictionary = _graphs.get(capability_id, {})
	if graph.is_empty():
		return false
	var current := String(_states.get(capability_id, graph.get("initial_state", "")))
	for transition: Dictionary in graph.get("transitions", []):
		if (
			String(transition.get("from_state", "")) == current
			and String(transition.get("trigger", "")) == event
		):
			var next_state := String(transition.get("to_state", ""))
			var next_properties := _properties_for(graph, next_state)
			for effect: Dictionary in transition.get("effects", []):
				next_properties[String(effect.get("property", ""))] = effect.get("value")
			_states[capability_id] = next_state
			_properties[capability_id] = next_properties
			_apply_observable(capability_id)
			# Cause and effect last, after this capability has finished changing:
			# a door opened by a plate should find the plate already triggered.
			_emit(transition.get("emits", []))
			return true
	return false


func interact() -> bool:
	# One key, whichever trigger the CURRENT state actually accepts.
	#
	# This used to hold one fixed trigger per capability, which works only where
	# the same word drives both directions. `openable` sends "interact" to open
	# and again to close, so it was fine. `sittable` sends "sit" to sit and
	# "stand" to rise, so a seated player could never get up: the key kept
	# offering "sit" to a state that had no such transition. The same trap was
	# waiting for `vehicle` (enter/exit) and `dialogue` (talk/end).
	#
	# Asking the graph what it will accept removes the class of bug rather than
	# one instance of it, and a capability added later needs no entry here.
	var preference := {
		"openable": ["interact"],
		"lockable": ["interact"],
		"pickup_carry_drop": ["pickup", "drop"],
		"sittable": ["sit", "stand"],
		"dialogue": ["talk", "end"],
		# `drive` is deliberately absent: throttle belongs to the movement keys,
		# not to the interact key, which cannot mean both "drive off" and "get
		# out" from one state. `stop` is present because `moving` accepts nothing
		# else -- a driver who reached it had no way back out at all.
		"vehicle": ["enter", "stop", "exit"],
		"machine": ["start", "stop"],
	}
	for capability_id: String in preference:
		if not _graphs.has(capability_id):
			continue
		for event: String in preference[capability_id]:
			if _accepts(capability_id, event):
				return trigger(capability_id, event)
	return false


func _accepts(capability_id: String, event: String) -> bool:
	"""Whether the current state has a transition on this trigger."""
	var graph: Dictionary = _graphs.get(capability_id, {})
	if graph.is_empty():
		return false
	var current := String(_states.get(capability_id, graph.get("initial_state", "")))
	for transition: Dictionary in graph.get("transitions", []):
		if (
			String(transition.get("from_state", "")) == current
			and String(transition.get("trigger", "")) == event
		):
			return true
	return false


func state_of(capability_id: String) -> String:
	return String(_states.get(capability_id, ""))


func properties_of(capability_id: String) -> Dictionary:
	return Dictionary(_properties.get(capability_id, {})).duplicate(true)


func trace_state() -> Dictionary:
	var result := {}
	var capability_ids: Array = _graphs.keys()
	capability_ids.sort()
	for capability_id: String in capability_ids:
		result[capability_id] = {
			"state": state_of(capability_id),
			"properties": properties_of(capability_id),
		}
	return result


func _properties_for(graph: Dictionary, state_id: String) -> Dictionary:
	for state: Dictionary in graph.get("states", []):
		if String(state.get("state_id", "")) == state_id:
			return Dictionary(state.get("observable_properties", {})).duplicate(true)
	return {}


func _apply_observable(capability_id: String) -> void:
	var values: Dictionary = _properties.get(capability_id, {})
	var entity := get_parent() as Node3D
	if entity == null:
		return
	var collision := entity.get_node_or_null("CollisionShape3D") as CollisionShape3D
	if collision != null and values.has("collision_enabled"):
		collision.set_deferred("disabled", not bool(values["collision_enabled"]))
	var visual := entity.get_node_or_null("VisualPivot") as Node3D
	if visual == null:
		visual = entity.get_node_or_null("Visual") as Node3D
	if visual != null and values.has("open"):
		visual.rotation.y = deg_to_rad(-90.0 if bool(values["open"]) else 0.0)
	# `physics_enabled` is the same lever as `collision_enabled` read the other
	# way round: a carried object must not collide with the player carrying it.
	if collision != null and values.has("physics_enabled"):
		collision.set_deferred("disabled", not bool(values["physics_enabled"]))
	if values.has("occupied"):
		# `sittable` and `vehicle` both publish `occupied`, and they mean
		# different things. A bench holds the player still; a vehicle carries
		# them, so the player has to become a child of it rather than merely
		# stand on top of a thing that then drives away without them.
		if capability_id == "vehicle":
			_ride_vehicle(entity, bool(values["occupied"]))
		else:
			_seat_player(entity, bool(values["occupied"]))
	if values.has("carried"):
		_carry_object(entity, bool(values["carried"]))
	if values.has("line"):
		_speak(entity, String(values["line"]), bool(values.get("speaking", false)))
	if values.has("operating"):
		# A running machine has to look different from a stopped one. The
		# manifest claimed "binary operating state works" while nothing honoured
		# the property, so off, running and failed rendered identically and the
		# claim was only true of the data.
		_spinning = bool(values["operating"])
		_spin_failed = bool(values.get("failed", false))
		# `_senses` has to be in this decision. One node can hold several
		# capabilities, so a machine that is also a sensor would otherwise stop
		# sensing the moment it was switched off -- one capability silently
		# disabling another through a shared frame callback.
		_refresh_process()
		if not _spinning:
			_settle_spin(entity)
	entity.set_meta("serendib_state_%s" % capability_id, state_of(capability_id))
	entity.set_meta("serendib_properties_%s" % capability_id, values.duplicate(true))


func _seat_player(seat: Node3D, occupied: bool) -> void:
	"""Put the player on this seat, or release them from it.

	`sittable` compiled to a state machine that flipped `occupied` and did
	nothing else, so a bench reported itself occupied while the player stood
	beside it unchanged. A capability whose observable property moves nothing in
	the scene is not implemented, whatever its status field says.

	The player is parked ON the seat and their physics process is suspended, the
	same way the immersive runtime suspends it when the headset takes over: the
	controller would otherwise keep applying gravity and input against a body
	that is supposed to be resting.
	"""
	var player := _player_node()
	if player == null:
		return
	if occupied:
		if player.has_meta("serendib_seated_at"):
			return  # already sitting somewhere; one seat at a time
		player.set_meta("serendib_seated_return", player.global_position)
		player.set_meta("serendib_seated_at", seat.get_path())
		# Sit ON the surface rather than inside it. The collision shape is the
		# one measurement guaranteed to be on every placed entity, so the seat
		# top is read from that rather than from a metadata key nobody writes.
		player.global_position = Vector3(
			seat.global_position.x, _seat_top(seat), seat.global_position.z
		)
		player.set_physics_process(false)
		if player is CharacterBody3D:
			(player as CharacterBody3D).velocity = Vector3.ZERO
	else:
		if not player.has_meta("serendib_seated_at"):
			return
		if String(player.get_meta("serendib_seated_at")) != String(seat.get_path()):
			return  # seated on a different seat; not ours to release
		var back: Variant = player.get_meta("serendib_seated_return", player.global_position)
		if back is Vector3:
			player.global_position = back
		player.remove_meta("serendib_seated_at")
		player.remove_meta("serendib_seated_return")
		player.set_physics_process(true)


func _carry_object(item: Node3D, carried: bool) -> void:
	"""Attach this object to the player, or set it back down.

	`pickup_carry_drop` compiled a full grounded/carried/dropped graph and the
	runtime honoured none of it: the state advanced and the object never left the
	ground, which is what "collection is implemented; persistent carry and drop
	are not" meant in practice.

	Carrying is done by reparenting rather than by copying a transform every
	frame. The object then follows the player for free, through walking,
	teleporting and the immersive rig alike, because it is genuinely a child of
	the body that moves.
	"""
	var player := _player_node()
	if player == null:
		return
	if carried:
		if item.has_meta("serendib_carry_home"):
			return
		var home := item.get_parent()
		if home == null:
			return
		item.set_meta("serendib_carry_home", home.get_path())
		item.set_meta("serendib_carry_ground_y", item.global_position.y)
		home.remove_child(item)
		player.add_child(item)
		# Held in front and a little above the player's centre, so it is visible
		# to whoever is carrying it rather than clipping through them.
		item.position = Vector3(0.0, 0.35, -0.7)
		item.rotation = Vector3.ZERO
	else:
		if not item.has_meta("serendib_carry_home"):
			return
		var home_path := NodePath(String(item.get_meta("serendib_carry_home")))
		var home := get_node_or_null(home_path)
		if home == null:
			home = get_tree().current_scene
		var forward := -player.global_transform.basis.z
		forward.y = 0.0
		if forward.length() < 0.01:
			forward = Vector3.FORWARD
		var landing := player.global_position + forward.normalized() * 0.9
		# Where the ground actually is at the landing spot. This used to reuse the
		# height the object was picked up from, which is the same answer only on a
		# flat slab: carried up a hill and set down, a crate sank back to the
		# height of wherever it was found.
		landing.y = _ground_y(
			item,
			landing,
			float(item.get_meta("serendib_carry_ground_y", item.global_position.y)),
		)
		player.remove_child(item)
		home.add_child(item)
		item.global_position = landing
		item.remove_meta("serendib_carry_home")
		item.remove_meta("serendib_carry_ground_y")


func _seat_top(seat: Node3D) -> float:
	"""The Y a sitter rests at: the top of the seat's collision box."""
	var collision := seat.get_node_or_null("CollisionShape3D") as CollisionShape3D
	if collision != null:
		var box := collision.shape as BoxShape3D
		if box != null:
			return seat.global_position.y + box.size.y * 0.5
		var capsule := collision.shape as CapsuleShape3D
		if capsule != null:
			return seat.global_position.y + capsule.height * 0.5
	return seat.global_position.y


func _player_node() -> Node3D:
	for node: Node in get_tree().get_nodes_in_group("player"):
		if node is Node3D:
			return node as Node3D
	return null


func _process(delta: float) -> void:
	"""Per-frame work: a running machine turns, and a sensor senses."""
	if _spinning:
		var part := _spin_target()
		if part == null:
			_spinning = false
		else:
			part.rotate_y(delta * 1.6)
	if _senses:
		_sample_proximity()
	if _process_period > 0.0:
		_advance_ecosystem(delta)
	_refresh_process()


func _physics_process(delta: float) -> void:
	"""Vehicle motion, which belongs to the physics tick and not to the frame.

	Driving from _process drilled a rigid vehicle into the ground. Writing
	`linear_velocity` there replaces the vector the solver had just produced,
	including the downward component it was using to resolve the contact with the
	floor -- so the body was handed back its own falling velocity every frame and
	sank until friction jammed it. Measured: a cart told to travel at 6 m/s sat at
	0.21 m below its resting height with 0.01 m/s of forward motion.

	In the physics callback the write lands once per tick, immediately before
	integration, and the vertical component read back is the post-solver one.
	"""
	if _vehicle_occupied:
		_drive_vehicle(delta)


func _sample_proximity() -> void:
	"""Fire a sensor when the player comes within range, and reset when they leave.

	A sensor that waits to be pressed is not a sensor. `sense` was in no input
	map at all, so the capability compiled a correct idle/triggered graph that
	nothing in the running world could ever advance -- the state was reachable
	only from a test harness.

	The band is hysteretic: leaving takes 15% more distance than entering.
	Sampling a single radius makes a player standing on the boundary flip the
	state every frame, which reads as a fault and would flood any log built on
	this later.
	"""
	var player := _player_node()
	var entity := get_parent() as Node3D
	if player == null or entity == null:
		return
	var distance := player.global_position.distance_to(entity.global_position)
	var state := state_of("sensor_trigger")
	if state == "triggered":
		if distance > _sense_radius * 1.15:
			trigger("sensor_trigger", "reset")
	elif distance <= _sense_radius:
		trigger("sensor_trigger", "sense")


func _detection_radius() -> float:
	"""How far this sensor reaches, taken from its own measured body.

	A floor plate and a gantry scanner are both sensors and should not share a
	hardcoded range, and the collision shape is the only measurement guaranteed
	present on a placed entity. The floor keeps a small plate usable: a 0.4 m
	pad with no margin could only be triggered by standing exactly on its centre.
	"""
	var entity := get_parent() as Node3D
	if entity == null:
		return 2.5
	var collision := entity.get_node_or_null("CollisionShape3D") as CollisionShape3D
	if collision != null:
		var box := collision.shape as BoxShape3D
		if box != null:
			var reach: float = maxf(box.size.x, box.size.z) * 0.5 + 1.5
			return maxf(reach, 1.5)
	return 2.5


func _spin_target() -> Node3D:
	var entity := get_parent() as Node3D
	if entity == null:
		return null
	var pivot := entity.get_node_or_null("VisualPivot") as Node3D
	if pivot != null:
		return pivot
	return entity.get_node_or_null("Visual") as Node3D


func _settle_spin(entity: Node3D) -> void:
	"""Return a stopped machine to its rest pose.

	A machine left at whatever angle it happened to reach reads as broken rather
	than off, and a FAILED machine should be distinguishable from a switched-off
	one: it stops where it stopped, which is exactly what a seizure looks like.
	"""
	if _spin_failed:
		return
	var part := _spin_target()
	if part != null:
		part.rotation.y = 0.0


func _refresh_process() -> void:
	"""One place decides whether this node needs a frame callback.

	Each capability used to call set_process itself, which is only correct while
	a node holds one of them. A machine switching off called set_process(false)
	and would have stopped a sensor on the same entity from sensing -- one
	capability disabling another through a callback they share. Asking all of
	them at once removes that.
	"""
	set_process(_spinning or _spin_failed or _senses or _process_period > 0.0)
	set_physics_process(_vehicle_occupied)


func _advance_ecosystem(delta: float) -> void:
	"""Tick the process, one full cycle per period.

	Both transitions are sent in order rather than one per tick: the machine's own
	shape is stable -> updating -> stable, and leaving it parked in `updating` between
	ticks would publish a state the world is not in for most of its life.
	"""
	_process_countdown -= delta
	if _process_countdown > 0.0:
		return
	_process_countdown += _process_period
	trigger("ecosystem_process", "simulate_step")
	trigger("ecosystem_process", "commit")


func _ride_vehicle(vehicle: Node3D, aboard: bool) -> void:
	"""Put the player aboard so they travel with the vehicle, or set them down.

	Reparenting is what makes this a vehicle rather than a bench: the player's
	transform becomes the vehicle's, so they ride through every movement for
	free. Their physics process is suspended for the same reason it is on a
	seat -- the controller would otherwise apply gravity and input to a body
	whose position the vehicle owns.
	"""
	var player := _player_node()
	if player == null:
		return
	if aboard:
		if player.has_meta("serendib_seated_at"):
			return  # already aboard something; one at a time
		var home := player.get_parent()
		if home == null:
			return
		player.set_meta("serendib_seated_at", vehicle.get_path())
		player.set_meta("serendib_ride_home", home.get_path())
		player.set_meta("serendib_ride_ground_y", player.global_position.y)
		var seat_y := _seat_top(vehicle)
		home.remove_child(player)
		vehicle.add_child(player)
		player.global_position = Vector3(
			vehicle.global_position.x, seat_y, vehicle.global_position.z
		)
		player.set_physics_process(false)
		if player is CharacterBody3D:
			(player as CharacterBody3D).velocity = Vector3.ZERO
		_vehicle_occupied = true
		_refresh_process()
	else:
		if not player.has_meta("serendib_ride_home"):
			return
		if String(player.get_meta("serendib_seated_at")) != String(vehicle.get_path()):
			return  # aboard a different vehicle; not ours to release
		var home := get_node_or_null(
			NodePath(String(player.get_meta("serendib_ride_home")))
		)
		if home == null:
			home = get_tree().current_scene
		# Step out BESIDE the vehicle, not back where they got in. A seat can
		# restore the entry position because a bench does not move; a vehicle
		# that has driven across the level would teleport its driver back to the
		# far side of the map on exit.
		var beside := vehicle.global_position + vehicle.global_transform.basis.x * 1.4
		# Measured at the spot they are stepping out onto, not remembered from where
		# they got in. A vehicle exists to cover ground, so those two are the same
		# height only by accident.
		beside.y = _ground_y(
			vehicle,
			beside,
			float(player.get_meta("serendib_ride_ground_y", player.global_position.y)),
		)
		vehicle.remove_child(player)
		home.add_child(player)
		player.global_position = beside
		player.remove_meta("serendib_seated_at")
		player.remove_meta("serendib_ride_home")
		player.remove_meta("serendib_ride_ground_y")
		player.set_physics_process(true)
		_vehicle_occupied = false
		_refresh_process()


func _drive_vehicle(delta: float) -> void:
	"""Turn the driver's movement keys into vehicle motion.

	The throttle reads the same actions that walk the player, because a driver
	pressing forward expects to go forward whether they are on foot or not.

	The vehicle moves along its own facing, so steering and travel stay
	consistent after any number of turns, and the state follows the throttle:
	releasing the keys returns `moving` to `occupied` rather than coasting on.
	"""
	var vehicle := get_parent() as Node3D
	if vehicle == null:
		return
	var throttle := 0.0
	var steer := 0.0
	if _probe_input:
		throttle = _probe_throttle
		steer = _probe_steer
	else:
		throttle = Input.get_axis("move_back", "move_forward")
		steer = Input.get_axis("move_right", "move_left")
	var state := state_of("vehicle")
	if absf(throttle) > 0.1:
		if state == "occupied":
			trigger("vehicle", "drive")
			state = state_of("vehicle")
	elif state == "moving":
		trigger("vehicle", "stop")
		state = state_of("vehicle")
	if state != "moving":
		_halt(vehicle)
		return
	# Steering only bites while under power, the way a wheel does: a stationary
	# vehicle spinning on the spot reads as a fault.
	var body := vehicle as RigidBody3D
	if body != null:
		# `physical.dynamic` makes the writer emit a RigidBody3D, and a vehicle
		# in a real prompt is dynamic. Writing to a rigid body's transform makes
		# it teleport and skips its own collision response, so the throttle
		# becomes a velocity the physics server integrates -- which is also why
		# this path needs no forward probe. Gravity keeps the vertical component.
		var heading := -body.global_transform.basis.z * throttle * _drive_speed_mps
		body.linear_velocity = Vector3(heading.x, body.linear_velocity.y, heading.z)
		body.angular_velocity = Vector3(0.0, steer * _turn_rate_rps, 0.0)
		return
	var step := throttle * _drive_speed_mps * delta
	# A StaticBody3D goes wherever it is told, so nothing stops a cart from
	# driving through the house it was parked beside. The step is checked before
	# it is taken rather than corrected afterwards, which would put the vehicle
	# inside the wall for a frame.
	if _path_is_clear(vehicle, step):
		vehicle.translate_object_local(Vector3(0.0, 0.0, -step))
	vehicle.rotate_y(steer * _turn_rate_rps * delta)


func set_drive_input(throttle: float, steer: float) -> void:
	"""Test seam: drive without a keyboard.

	Headless probes cannot press keys, and the driving path is exactly the part
	worth proving. This exists so a probe exercises the same motion code the
	player does rather than a copy of it.
	"""
	_probe_throttle = throttle
	_probe_steer = steer
	_probe_input = true


func _path_is_clear(vehicle: Node3D, step: float) -> bool:
	"""Whether the vehicle can take this step without entering something solid.

	The probe starts at the vehicle's own nose rather than its centre, so its
	body is not what it collides with, and it is raised off the ground so the
	terrain slab underneath is not read as an obstacle. Its own collider and the
	driver riding inside it are excluded for the same reason.

	This is one ray along the centre line. It catches walls, buildings and other
	vehicles -- the cases a driver actually meets -- and can clip a thin post
	standing off to one side, which is why the capability stays partial.
	"""
	var world := vehicle.get_world_3d()
	if world == null or absf(step) < 0.0001:
		return true
	var half_length := 1.0
	var collision := vehicle.get_node_or_null("CollisionShape3D") as CollisionShape3D
	if collision != null:
		var box := collision.shape as BoxShape3D
		if box != null:
			# The widest horizontal half-extent, not the one along travel. A
			# tractor authored 2.8 m across and 1.5 m deep faces -Z all the same,
			# so measuring the travel axis would start the probe inside its own
			# body. Erring long stops the vehicle slightly early, which is the
			# safe direction to be wrong in.
			half_length = maxf(box.size.x, box.size.z) * 0.5
	var heading := -vehicle.global_transform.basis.z * signf(step)
	var nose := vehicle.global_position + heading * half_length + Vector3(0.0, 0.4, 0.0)
	var query := PhysicsRayQueryParameters3D.create(
		nose, nose + heading * (absf(step) + 0.2)
	)
	var skip: Array[RID] = []
	if vehicle is CollisionObject3D:
		skip.append((vehicle as CollisionObject3D).get_rid())
	var player := _player_node()
	if player is CollisionObject3D:
		skip.append((player as CollisionObject3D).get_rid())
	query.exclude = skip
	return world.direct_space_state.intersect_ray(query).is_empty()


func _halt(vehicle: Node3D) -> void:
	"""Take a rigid vehicle out of gear when the throttle is released.

	A kinematic vehicle stops the moment nothing moves it, but a rigid body keeps
	the velocity it was given and would coast away under its own momentum after
	the driver let go. The vertical component is left alone so the vehicle still
	settles on the ground rather than hanging where it stopped.
	"""
	var body := vehicle as RigidBody3D
	if body == null:
		return
	body.linear_velocity = Vector3(0.0, body.linear_velocity.y, 0.0)
	body.angular_velocity = Vector3.ZERO


func _speak(speaker: Node3D, line: String, speaking: bool) -> void:
	"""Show the line this state carries, or hide the label when the talk ends.

	The text arrives in the state's observable properties rather than being
	indexed out of an array here. That keeps the words a visitor reads inside the
	state machine, where `runtime_interactions` can assert them: a runtime that
	owned the line list could show anything and still report the right state.
	"""
	var label := speaker.get_node_or_null("DialogueLine") as Label3D
	if label == null:
		return
	label.text = line
	label.visible = speaking and not line.is_empty()


func _ground_y(reference: Node3D, at: Vector3, fallback: float) -> float:
	"""The height of the ground under a world position.

	A downward ray rather than a remembered value, because the ground is a
	heightfield now: the planner builds it, the writer ships it and terrain_field.gd
	turns it into the collider this ray hits, so one query answers for every world
	whatever its relief.

	The fallback matters. This runs from a capability that may be exercised by a
	headless probe in a scene with no ground at all, and returning the caller's own
	best guess keeps a validator measuring behaviour rather than tripping over the
	absence of scenery.
	"""
	var world := reference.get_world_3d()
	if world == null:
		return fallback
	var from := Vector3(at.x, at.y + 40.0, at.z)
	var to := Vector3(at.x, at.y - 40.0, at.z)
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.collide_with_areas = false
	var skip: Array[RID] = []
	if reference is CollisionObject3D:
		skip.append((reference as CollisionObject3D).get_rid())
	var player := _player_node()
	if player is CollisionObject3D:
		skip.append((player as CollisionObject3D).get_rid())
	query.exclude = skip
	var hit := world.direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return fallback
	return float(hit["position"].y)


func _emit(emits: Array) -> void:
	"""Fire this transition's triggers on the entities it names.

	The chain is depth-limited. A machine that trips a sensor that stops the machine
	is a legitimate world -- an oscillator -- and without a limit it would lock the
	frame on the first tick. Eight is deep enough for any plausible chain of causes
	and shallow enough that exceeding it means a loop rather than a design.

	A missing target is reported rather than ignored. The compiler refuses links it
	cannot resolve, so anything unresolved here means the scene and the plan have
	diverged, which is worth a loud error and not a shrug.
	"""
	if emits.is_empty():
		return
	if _causal_depth >= 8:
		push_error(
			"Serendib causal chain exceeded 8 steps; stopping to avoid a loop"
		)
		return
	_causal_depth += 1
	for emit: Dictionary in emits:
		var target := _entity_machine(String(emit.get("entity_id", "")))
		if target == null:
			push_error(
				"Serendib causal link %s found no entity %s"
				% [str(emit.get("link_id", "?")), str(emit.get("entity_id", "?"))]
			)
			continue
		target.trigger(
			String(emit.get("capability_id", "")), String(emit.get("trigger", ""))
		)
	_causal_depth -= 1


func _entity_machine(entity_id: String) -> Node:
	"""The capability machine belonging to a named entity.

	Found through the `serendib_entity` group and the `entity_id` metadata the writer
	stamps on every body, rather than by node path: the path is derived from the id
	and reading it back would couple this to the writer's naming rules.
	"""
	if entity_id.is_empty():
		return null
	for node: Node in get_tree().get_nodes_in_group("serendib_entity"):
		if String(node.get_meta("entity_id", "")) != entity_id:
			continue
		var machine := node.get_node_or_null("Capabilities")
		if machine != null and machine.has_method("trigger"):
			return machine
		return null
	return null
