extends CharacterBody3D
class_name SerendibSimulationController

@export var move_speed: float = 4.0
@export var sprint_multiplier: float = 1.6
@export var jump_velocity: float = 4.5
@export var interaction_distance_m: float = 3.0
@export var mouse_sensitivity: float = 0.003

var _spring_arm: SpringArm3D
var _animation_player: AnimationPlayer


func _ready() -> void:
	add_to_group("player")
	floor_snap_length = 0.6
	_spring_arm = get_node_or_null("SpringArm3D")
	_animation_player = _find_animation_player(self)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	elif event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		if _spring_arm != null:
			_spring_arm.rotation.x = clampf(
				_spring_arm.rotation.x - event.relative.y * mouse_sensitivity,
				deg_to_rad(-60.0),
				deg_to_rad(30.0),
			)


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta
	elif Input.is_action_just_pressed("jump"):
		velocity.y = jump_velocity
	elif velocity.y > 0.0:
		velocity.y = 0.0
	var input_dir := Input.get_vector(
		"move_left", "move_right", "move_forward", "move_back"
	)
	var direction := (transform.basis * Vector3(input_dir.x, 0.0, input_dir.y)).normalized()
	var speed := move_speed * (
		sprint_multiplier if Input.is_action_pressed("sprint") else 1.0
	)
	if direction != Vector3.ZERO:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0.0, speed)
		velocity.z = move_toward(velocity.z, 0.0, speed)
	move_and_slide()
	_update_animation(direction != Vector3.ZERO)
	if Input.is_action_just_pressed("interact"):
		_interact_with_nearest()


func _interact_with_nearest() -> void:
	"""Interact with the closest thing in reach that can actually respond.

	This used to pick the single nearest candidate and press it regardless of
	whether anything happened. Being in reach is not the same as having a
	transition available: a locked door, or a machine already seized, accepts
	nothing. Whichever of those stood closest silently ate the key press, and the
	openable door right beside it never moved -- the player reads that as the
	interact key being broken.

	Trying candidates in distance order costs nothing (a handful of nodes are
	ever in reach) and makes the key find the nearest thing that responds.
	"""
	var candidates: Array[Node3D] = []
	var distances: Dictionary = {}
	for candidate: Node in get_tree().get_nodes_in_group("serendib_interactable"):
		if not candidate is Node3D or not candidate.has_method("interact"):
			continue
		var component := candidate as Node3D
		var distance := global_position.distance_to(component.global_position)
		if distance > interaction_distance_m:
			continue
		candidates.append(component)
		distances[component] = distance
	candidates.sort_custom(
		func(a: Node3D, b: Node3D) -> bool:
			return float(distances[a]) < float(distances[b])
	)
	for component: Node3D in candidates:
		if bool(component.call("interact")):
			return


func _find_animation_player(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer:
		return node
	for child: Node in node.get_children():
		var found := _find_animation_player(child)
		if found != null:
			return found
	return null


func _update_animation(moving: bool) -> void:
	if _animation_player == null:
		return
	var desired := "walk" if moving else "idle"
	for animation: StringName in _animation_player.get_animation_list():
		if desired in String(animation).to_lower():
			if _animation_player.current_animation != String(animation):
				_animation_player.play(animation)
			return
