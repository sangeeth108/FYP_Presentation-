extends CharacterBody3D
class_name SerendibSimulationAgent

## Reviewed deterministic navigation controller for non-user simulation agents.
## The generated world supplies only bounded configuration and measured geometry.

@export var move_speed: float = 2.2
@export var wander_radius_m: float = 12.0
@export var arrival_distance_m: float = 0.6

var _navigation: NavigationAgent3D
var _animation_player: AnimationPlayer
var _origin := Vector3.ZERO
var _waypoint_index := 0
var _identity_seed := 0
var _ready_to_move := false
var _target_age_frames := 0


func _ready() -> void:
	add_to_group("serendib_autonomous_agent")
	floor_snap_length = 0.6
	_navigation = get_node_or_null("NavigationAgent3D") as NavigationAgent3D
	_animation_player = _find_animation_player(self)
	_origin = global_position
	_identity_seed = abs(String(get_meta("entity_id", name)).hash())
	call_deferred("_initialize_navigation")


func _initialize_navigation() -> void:
	await get_tree().physics_frame
	await get_tree().physics_frame
	_ready_to_move = true
	_choose_next_target()


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta
	elif velocity.y > 0.0:
		velocity.y = 0.0
	if not _ready_to_move or _navigation == null:
		_stop_horizontal()
		move_and_slide()
		_update_animation(false)
		return
	if NavigationServer3D.map_get_iteration_id(_navigation.get_navigation_map()) == 0:
		_stop_horizontal()
		move_and_slide()
		_update_animation(false)
		return
	_target_age_frames += 1
	if _navigation.is_navigation_finished() and _target_age_frames > 10:
		_choose_next_target()
	var next_position := _navigation.get_next_path_position()
	var direction := global_position.direction_to(next_position)
	direction.y = 0.0
	direction = direction.normalized()
	if direction == Vector3.ZERO:
		_stop_horizontal()
	else:
		velocity.x = direction.x * move_speed
		velocity.z = direction.z * move_speed
		rotation.y = atan2(-direction.x, -direction.z)
	move_and_slide()
	_update_animation(direction != Vector3.ZERO)
	set_meta("serendib_agent_waypoint", _waypoint_index)
	set_meta("serendib_agent_moving", direction != Vector3.ZERO)
	set_meta("serendib_agent_target", _navigation.target_position)
	set_meta("serendib_agent_next", next_position)
	set_meta("serendib_agent_finished", _navigation.is_navigation_finished())
	set_meta(
		"serendib_agent_map_iteration",
		NavigationServer3D.map_get_iteration_id(_navigation.get_navigation_map())
	)
	set_meta("serendib_agent_slide_collisions", get_slide_collision_count())


func _choose_next_target() -> void:
	if _navigation == null:
		return
	var angle_degrees := fmod(float(_identity_seed % 360) + float(_waypoint_index) * 137.508, 360.0)
	var angle := deg_to_rad(angle_degrees)
	var requested := _origin + Vector3(cos(angle), 0.0, sin(angle)) * wander_radius_m
	var map_rid := _navigation.get_navigation_map()
	if NavigationServer3D.map_get_iteration_id(map_rid) > 0:
		requested = NavigationServer3D.map_get_closest_point(map_rid, requested)
	_navigation.target_position = requested
	_target_age_frames = 0
	_waypoint_index += 1


func _stop_horizontal() -> void:
	velocity.x = move_toward(velocity.x, 0.0, move_speed)
	velocity.z = move_toward(velocity.z, 0.0, move_speed)


func _find_animation_player(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer:
		return node
	for child: Node in node.get_children():
		var found := _find_animation_player(child)
		if found != null:
			return found
	return null


func _update_animation(moving: bool) -> void:
	if _animation_player == null:
		return
	var desired := "walk" if moving else "idle"
	for animation: StringName in _animation_player.get_animation_list():
		if desired in String(animation).to_lower():
			if _animation_player.current_animation != String(animation):
				_animation_player.play(animation)
			return
