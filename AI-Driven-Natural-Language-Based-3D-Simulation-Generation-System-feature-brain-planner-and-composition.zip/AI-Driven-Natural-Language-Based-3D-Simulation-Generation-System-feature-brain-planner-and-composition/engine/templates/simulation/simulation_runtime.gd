extends Node3D
class_name SerendibSimulationRuntime

const PLAN_PATH := "res://world_plan.json"
const MAX_CAPTURE_VIEWS := 8


func _ready() -> void:
	var navigation := get_node_or_null("Navigation") as NavigationRegion3D
	if navigation != null:
		navigation.bake_navigation_mesh(false)
		NavigationServer3D.map_force_update(navigation.get_navigation_map())
	if "--serendib-capture" in OS.get_cmdline_user_args():
		await get_tree().process_frame
		await get_tree().process_frame
		_capture_views()
	elif "--serendib-fps" in OS.get_cmdline_user_args():
		await _measure_frame_rate()
	elif _probe_requested():
		await get_tree().process_frame
		await get_tree().process_frame
		_run_probe()


func _measure_frame_rate() -> void:
	# Reports the DISTRIBUTION of frame times, not an average. A mean hides the
	# case that matters: a scene that holds 60 FPS until a dense scatter field
	# enters the view and then hitches. The first-percentile low is where that
	# shows, so median and 1% low are what leave here.
	const WARMUP_FRAMES := 90    # shaders compile and caches fill on first sight
	const SAMPLE_FRAMES := 600
	# Vsync must be off or this measures the monitor. With it on, a first run
	# reported median, 1% low and worst all at exactly 60.0 FPS and 16.67 ms:
	# a perfectly flat distribution, which is the display's refresh rather than
	# anything about the scene. Headroom is invisible under a cap.
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	Engine.max_fps = 0
	# Frame the content, for the same reason the capture views do. Measured from
	# the spawn camera this reported 3{,}413 FPS over 22 objects and 12{,}820
	# primitives, in a world declaring 11{,}947 scatter instances: the scatter
	# was outside the frustum and the timing described an empty view. A frame
	# rate is only meaningful for a stated viewpoint, so the measurement states
	# one, and reports what it drew so the claim can be checked.
	var bounds := _content_bounds()
	var center := bounds.get_center()
	var span: float = maxf(bounds.size.x, bounds.size.z)
	var camera := Camera3D.new()
	camera.fov = 60.0
	camera.far = maxf(500.0, span * 3.0)
	add_child(camera)
	camera.current = true
	camera.global_position = center + Vector3(span * 0.55, span * 0.35 + 10.0, span * 0.55)
	camera.look_at(center, Vector3.UP)
	for _i in range(WARMUP_FRAMES):
		await get_tree().process_frame
	var deltas: Array[float] = []
	for _i in range(SAMPLE_FRAMES):
		await get_tree().process_frame
		var delta := get_process_delta_time()
		if delta > 0.0:
			deltas.append(delta)
	if deltas.is_empty():
		print("SERENDIB_FPS_JSON:" + JSON.stringify({"status": "FAIL"}))
		get_tree().quit(1)
		return
	deltas.sort()
	# Sorted ascending by frame TIME, so the slowest frames are at the end: the
	# 1% low frame rate comes from the 99th percentile frame time.
	var median_ms: float = deltas[deltas.size() / 2] * 1000.0
	var p99_ms: float = deltas[int(deltas.size() * 0.99)] * 1000.0
	var worst_ms: float = deltas[deltas.size() - 1] * 1000.0
	print("SERENDIB_FPS_JSON:" + JSON.stringify({
		"status": "PASS",
		"frames_sampled": deltas.size(),
		"median_fps": snappedf(1000.0 / median_ms, 0.1),
		"low_1pc_fps": snappedf(1000.0 / p99_ms, 0.1),
		"worst_fps": snappedf(1000.0 / worst_ms, 0.1),
		"median_frame_ms": snappedf(median_ms, 0.01),
		"p99_frame_ms": snappedf(p99_ms, 0.01),
		"renderer": str(ProjectSettings.get_setting("rendering/renderer/rendering_method")),
		"adapter": RenderingServer.get_video_adapter_name(),
		# What was actually on screen while those frames were timed. Without
		# this the number is unfalsifiable: an empty frame renders very fast,
		# and a camera pointed at the sky would report a flattering figure that
		# says nothing about the world. Compare objects against the instance
		# count the plan declares.
		"objects_drawn": RenderingServer.get_rendering_info(
			RenderingServer.RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME
		),
		"primitives_drawn": RenderingServer.get_rendering_info(
			RenderingServer.RENDERING_INFO_TOTAL_PRIMITIVES_IN_FRAME
		),
		"draw_calls": RenderingServer.get_rendering_info(
			RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME
		),
	}))
	get_tree().quit(0)


func _probe_requested() -> bool:
	if "--serendib-probe" in OS.get_cmdline_user_args():
		return true
	if OS.has_feature("web"):
		# Read the query string through the JS object bridge, NOT eval(). Builds are
		# served under a strict Content-Security-Policy without 'unsafe-eval', so
		# eval() is blocked and its blocked return value read as truthy — which made
		# the PLAYER build run the probe and immediately get_tree().quit(), killing
		# the page on load. Probing must stay strictly opt-in via ?serendib_probe=1.
		var window: JavaScriptObject = JavaScriptBridge.get_interface("window")
		if window == null:
			return false
		return str(window.location.search).contains("serendib_probe=1")
	return false


func _capture_views() -> void:
	var output_dir := DirAccess.open("res://")
	if output_dir == null:
		print("SERENDIB_CAPTURE_JSON:" + JSON.stringify({"status": "FAIL"}))
		get_tree().quit(1)
		return
	output_dir.make_dir_recursive("validation_views")
	var actor := get_tree().get_first_node_in_group("player") as Node3D
	var square := get_node_or_null("EntVillageSquare") as Node3D
	var structure := _first_entity_of_role("structure")
	var interactable_component := get_tree().get_first_node_in_group(
		"serendib_interactable"
	) as Node3D
	var interactable := (
		interactable_component.get_parent() as Node3D
		if interactable_component != null
		else null
	)
	if interactable != null:
		var door_capabilities := interactable.get_node_or_null("Capabilities") as Node
		if door_capabilities != null and door_capabilities.has_method("trigger"):
			door_capabilities.call("reset_capability", "openable")
			door_capabilities.call("trigger", "openable", "interact")
			door_capabilities.call("trigger", "openable", "tick")
	# Frame the CONTENT, not a fixed point.
	#
	# This was `square.global_position if square != null else Vector3.ZERO` with a
	# fixed camera offset of (38, 10, 38). `EntVillageSquare` is a node name from
	# the golden fixture, so any other world centred the overview on the world
	# ORIGIN and stood a fixed distance from it -- while the content sat wherever
	# placement had put it. A real run spread twelve entities over 51 m with the
	# player 25 m off-origin, and the overview came out as sky and empty ground
	# with the village a sliver near the horizon. The vision critic reported
	# `entity_not_visible` for four entities and was right.
	var bounds := _content_bounds()
	var center: Vector3 = bounds.get_center() if square == null else square.global_position
	var overview_fov := 60.0
	# Fit the frame to the content, separately in each axis.
	#
	# This used to pull back by half the AABB's 3D DIAGONAL, which for a flat
	# world is dominated by an axis that is mostly empty air: a 90 x 10 x 93 m
	# world has a 130 m diagonal against a 93 m widest side, so the camera
	# retreated ~40% further than the content needed and the subject occupied a
	# fraction of the frame with the rest sky. The vision critic then reported
	# "an empty space with no identifiable objects" about a world that was
	# plainly there, which is a framing failure being recorded as a content one.
	#
	# Godot's `fov` is the VERTICAL angle, so the horizontal half-angle has to be
	# derived through the viewport aspect or a wide world is cropped.
	var half_v := deg_to_rad(overview_fov * 0.5)
	var aspect := 16.0 / 9.0
	var viewport := get_viewport()
	if viewport != null and viewport.get_visible_rect().size.y > 0.0:
		aspect = viewport.get_visible_rect().size.x / viewport.get_visible_rect().size.y
	var half_h := atan(tan(half_v) * aspect)
	var horizontal := maxf(maxf(bounds.size.x, bounds.size.z) * 0.5, 4.0)
	var vertical := maxf(bounds.size.y * 0.5, 2.0)
	# 1.10 leaves a margin so nothing sits on the frame edge.
	var back := maxf(
		maxf(horizontal / tan(half_h), vertical / tan(half_v)) * 1.10,
		18.0,
	)
	# Normalised: the old offset was Vector3(0.707, 0.45, 0.707), whose length is
	# 1.097, so every view was a further 9.7% back than the fit had asked for.
	var overview_position := center + Vector3(0.707, 0.45, 0.707).normalized() * back
	var structure_visual := (
		structure.get_node_or_null("Visual") as Node3D if structure != null else null
	)
	var interactable_visual := (
		interactable.get_node_or_null("VisualPivot") as Node3D
		if interactable != null
		else null
	)
	var camera := Camera3D.new()
	camera.fov = 50.0
	add_child(camera)
	camera.current = true
	var poses: Array[Dictionary] = [
		{
			"position": overview_position,
			"target": center + Vector3(0.0, 2.0, 0.0),
			"fov": overview_fov,
			"subject_entity_id": "environment_overview",
			"purpose": "street_level_environment_overview",
		},
	]
	if structure != null:
		poses.append({
			"position": _closeup_pose(structure, 50.0)["position"],
			"target": _closeup_pose(structure, 50.0)["target"],
			"subject_entity_id": String(
				structure.get_meta("entity_id", structure.name)
			),
			"purpose": "representative_structure_asset_isolation",
			"hidden_visuals": [interactable_visual] if interactable_visual != null else [],
		})
	if actor != null:
		poses.append({
			"position": _closeup_pose(actor, 50.0)["position"],
			"target": _closeup_pose(actor, 50.0)["target"],
			"subject_entity_id": String(actor.get_meta("entity_id", actor.name)),
			"purpose": "controlled_agent_closeup",
		})
	if interactable != null:
		poses.append({
			"position": _closeup_pose(interactable, 50.0)["position"],
			"target": _closeup_pose(interactable, 50.0)["target"],
			"subject_entity_id": String(
				interactable.get_meta("entity_id", interactable.name)
			),
			"purpose": "interactable_asset_state_isolation",
			"hidden_visuals": [structure_visual] if structure_visual != null else [],
		})
	for autonomous: Node in get_tree().get_nodes_in_group("serendib_autonomous_agent"):
		if not autonomous is Node3D or poses.size() >= MAX_CAPTURE_VIEWS:
			continue
		var agent := autonomous as Node3D
		poses.append({
			"position": _closeup_pose(agent, 50.0)["position"],
			"target": _closeup_pose(agent, 50.0)["target"],
			"subject_entity_id": String(agent.get_meta("entity_id", agent.name)),
			"purpose": "autonomous_agent_closeup",
		})
	while poses.size() < 4:
		var angle := float(poses.size()) * PI / 2.0
		poses.append({
			"position": center + Vector3(cos(angle) * 24.0, 12.0, sin(angle) * 24.0),
			"target": center,
			"subject_entity_id": "environment_overview",
			"purpose": "overview",
		})
	var files: Array[String] = []
	var view_manifest: Array[Dictionary] = []
	for index: int in range(mini(poses.size(), MAX_CAPTURE_VIEWS)):
		var hidden_visuals: Array = poses[index].get("hidden_visuals", [])
		for hidden: Variant in hidden_visuals:
			if hidden is Node3D:
				(hidden as Node3D).visible = false
		camera.fov = float(poses[index].get("fov", 50.0))
		camera.global_position = poses[index]["position"]
		camera.look_at(poses[index]["target"], Vector3.UP)
		await get_tree().process_frame
		RenderingServer.force_draw(false)
		var texture := get_viewport().get_texture()
		var image: Image = texture.get_image() if texture != null else null
		var relative := "validation_views/view_%02d.png" % index
		for hidden: Variant in hidden_visuals:
			if hidden is Node3D:
				(hidden as Node3D).visible = true
		if image == null or image.is_empty() or image.save_png("res://" + relative) != OK:
			print("SERENDIB_CAPTURE_JSON:" + JSON.stringify({
				"status": "FAIL", "files": files,
			}))
			get_tree().quit(1)
			return
		files.append(relative)
		view_manifest.append({
			"file": relative,
			"subject_entity_id": String(poses[index].get("subject_entity_id", "")),
			"purpose": String(poses[index].get("purpose", "")),
		})
	print("SERENDIB_CAPTURE_JSON:" + JSON.stringify({
		"status": "PASS", "files": files, "views": view_manifest,
	}))
	get_tree().quit(0)


func _first_entity_of_semantic_type(semantic_type: String) -> Node3D:
	for candidate: Node in get_tree().get_nodes_in_group("serendib_entity"):
		if String(candidate.get_meta("semantic_type", "")) == semantic_type:
			return candidate as Node3D
	return null


func _subject_radius(node: Node3D) -> float:
	"""Half the diagonal of whatever this entity actually renders as."""
	var radius := 0.0
	for child: Node in node.find_children("*", "VisualInstance3D", true, false):
		var visual := child as VisualInstance3D
		if visual == null:
			continue
		var box := visual.get_aabb()
		var scaled := box.size * visual.global_basis.get_scale()
		radius = maxf(radius, scaled.length() * 0.5)
	return maxf(radius, 0.4)


func _closeup_pose(node: Node3D, fov_degrees: float) -> Dictionary:
	"""A camera pose that fills the frame with THIS entity, whatever its size.

	The close-ups used fixed offsets -- (8, 4, -11) for a structure, (2.2, 1.7,
	-3.2) for an interactable -- so the distance had nothing to do with how big
	the subject was. A 0.9 m door photographed from 8 m came out a few pixels
	across a field of grass, and the vision critic reported it did not exist. The
	door was correctly attached and flush against its house the whole time; only
	the view was wrong.
	"""
	var radius := _subject_radius(node)
	var back := radius / tan(deg_to_rad(fov_degrees * 0.5)) * 1.6
	var direction := (node.global_basis * Vector3(0.55, 0.0, -1.0)).normalized()
	return {
		"position": node.global_position + direction * back + Vector3(0.0, radius * 0.7, 0.0),
		"target": node.global_position + Vector3(0.0, radius * 0.45, 0.0),
	}


func _content_bounds() -> AABB:
	"""The AABB of everything a viewer can actually see.

	Entities AND scatter. Only entities are in the `serendib_entity` group, so
	framing on that group alone measured the wrong thing in exactly the worlds
	where it matters most: a forest is two entities and three hundred trees, and
	the trees are the content. The vision critic then judged a frame composed
	around a handful of objects while the mass of the world sat outside it.

	Scatter is one MultiMeshInstance3D per species and its transforms are only
	populated at load, so the visual AABB is read back from the node rather than
	recomputed from the plan.
	"""
	var bounds := AABB()
	var seeded := false

	for candidate: Node in get_tree().get_nodes_in_group("serendib_entity"):
		var node := candidate as Node3D
		if node == null:
			continue
		var point := node.global_position
		if not seeded:
			bounds = AABB(point, Vector3.ZERO)
			seeded = true
		else:
			bounds = bounds.expand(point)

	var scatter_root := get_node_or_null("Scatter")
	if scatter_root != null:
		for child: Node in scatter_root.get_children():
			var field := child as MultiMeshInstance3D
			if field == null or field.multimesh == null:
				continue
			if field.multimesh.instance_count <= 0:
				continue
			var world_aabb := field.global_transform * field.get_aabb()
			if not seeded:
				bounds = world_aabb
				seeded = true
			else:
				bounds = bounds.merge(world_aabb)

	if not seeded:
		return AABB(Vector3.ZERO, Vector3.ONE * 20.0)
	# Grow by a nominal body size so edge objects are not clipped at the frame edge.
	return bounds.grow(3.0)


func _first_entity_of_role(role: String) -> Node3D:
	for candidate: Node in get_tree().get_nodes_in_group("serendib_entity"):
		if String(candidate.get_meta("role", "")) == role:
			return candidate as Node3D
	return null


func _run_probe() -> void:
	var errors: Array[Dictionary] = []
	var autonomous_origins: Dictionary = {}
	for autonomous: Node in get_tree().get_nodes_in_group("serendib_autonomous_agent"):
		if autonomous is Node3D:
			autonomous_origins[autonomous.get_path()] = (autonomous as Node3D).global_position
	for _frame: int in range(180):
		await get_tree().physics_frame
	for autonomous: Node in get_tree().get_nodes_in_group("serendib_autonomous_agent"):
		if not autonomous is Node3D:
			continue
		var origin: Vector3 = autonomous_origins.get(autonomous.get_path(), (autonomous as Node3D).global_position)
		if (autonomous as Node3D).global_position.distance_to(origin) < 0.05:
			errors.append({
				"code": "AUTONOMOUS_AGENT_DID_NOT_MOVE",
				"entity_id": autonomous.get_meta("entity_id", ""),
				"distance_m": (autonomous as Node3D).global_position.distance_to(origin),
				"target": autonomous.get_meta("serendib_agent_target", Vector3.ZERO),
				"next_path_position": autonomous.get_meta(
					"serendib_agent_next", Vector3.ZERO
				),
				"navigation_finished": autonomous.get_meta(
					"serendib_agent_finished", true
				),
				"map_iteration": autonomous.get_meta("serendib_agent_map_iteration", 0),
				"slide_collisions": autonomous.get_meta(
					"serendib_agent_slide_collisions", 0
				),
			})
	var plan: Variant = JSON.parse_string(FileAccess.get_file_as_string(PLAN_PATH))
	if not plan is Dictionary:
		errors.append({"code": "WORLD_PLAN_NOT_LOADABLE"})
	else:
		var entities_by_id: Dictionary = {}
		for node: Node in get_tree().get_nodes_in_group("serendib_entity"):
			entities_by_id[String(node.get_meta("entity_id", ""))] = node
		for expected: Dictionary in plan.get("entities", []):
			var entity_id := String(expected.get("entity_id", ""))
			var node := entities_by_id.get(entity_id) as Node3D
			if node == null:
				errors.append({"code": "ENTITY_MISSING", "entity_id": entity_id})
				continue
			if bool(expected.get("dynamic", false)):
				continue
			var target: Array = expected.get("transform", {}).get("position_m", [])
			if target.size() == 3:
				var wanted := Vector3(float(target[0]), float(target[1]), float(target[2]))
				if node.global_position.distance_to(wanted) > 0.02:
					errors.append({
						"code": "ENTITY_TRANSFORM_MISMATCH",
						"entity_id": entity_id,
					})
		for graph: Dictionary in plan.get("behaviours", []):
			var raw_entity_id: Variant = graph.get("entity_id")
			if raw_entity_id == null:
				continue
			var entity_id := String(raw_entity_id)
			var node := entities_by_id.get(entity_id) as Node3D
			if node == null:
				continue
			var component := node.get_node_or_null("Capabilities") as Node
			if component == null or not component.has_method("trigger"):
				errors.append({
					"code": "CAPABILITY_COMPONENT_MISSING",
					"entity_id": entity_id,
				})
				continue
			var capability_id := String(graph.get("capability_id", ""))
			for probe: Dictionary in graph.get("probes", []):
				component.call("reset_capability", capability_id)
				for event: String in probe.get("triggers", []):
					if not bool(component.call("trigger", capability_id, event)):
						errors.append({
							"code": "BEHAVIOR_TRIGGER_FAILED",
							"capability_id": capability_id,
							"trigger": event,
						})
						break
				if String(component.call("state_of", capability_id)) != String(
					probe.get("expected_state", "")
				):
					errors.append({
						"code": "BEHAVIOR_STATE_MISMATCH",
						"capability_id": capability_id,
					})
				var actual: Dictionary = component.call("properties_of", capability_id)
				for key: String in probe.get("expected_properties", {}):
					if actual.get(key) != probe["expected_properties"][key]:
						errors.append({
							"code": "BEHAVIOR_PROPERTY_MISMATCH",
							"capability_id": capability_id,
							"property": key,
						})
			# Leave the world as the probes found it. Resetting only before each
			# probe was enough while a capability just flipped a flag, but they
			# now move things: the last probe of a vehicle left the player parked
			# aboard it, and the reachability check further down reads that same
			# player's position. A validator must not decide the outcome by
			# having disturbed the scene it is measuring.
			component.call("reset_capability", capability_id)
		var actor := entities_by_id.get("ent_controlled_actor") as Node3D
		var navigation_node := get_node_or_null("Navigation") as NavigationRegion3D
		if actor != null and navigation_node != null:
			var map_rid := navigation_node.get_navigation_map()
			NavigationServer3D.map_force_update(map_rid)
			for reachability: Dictionary in plan.get("navigation", {}).get(
				"required_reachability", []
			):
				var target_node: Node3D
				var target_label := ""
				if reachability.has("to_entity"):
					target_label = String(reachability.get("to_entity", ""))
					target_node = entities_by_id.get(target_label) as Node3D
				else:
					target_label = String(reachability.get("to_zone", ""))
					target_node = get_node_or_null("Zones/Zone" + _pascal_case(target_label)) as Node3D
				if target_node == null:
					errors.append({"code": "NAVIGATION_TARGET_MISSING", "target": target_label})
					continue
				var reachable_point := NavigationServer3D.map_get_closest_point(
					map_rid, target_node.global_position
				)
				var path := NavigationServer3D.map_get_path(
					map_rid, actor.global_position, reachable_point, true
				)
				if path.is_empty():
					errors.append({"code": "NAVIGATION_PATH_MISSING", "target": target_label})
		var trace: Array[Dictionary] = []
		var entity_ids: Array = entities_by_id.keys()
		entity_ids.sort()
		for entity_id: String in entity_ids:
			var traced := entities_by_id[entity_id] as Node3D
			var entry := {
				"entity_id": entity_id,
				"dynamic": traced is CharacterBody3D or traced is RigidBody3D,
				"position_m": [
					snappedf(traced.global_position.x, 0.0001),
					snappedf(traced.global_position.y, 0.0001),
					snappedf(traced.global_position.z, 0.0001),
				],
				"capabilities": {},
			}
			var component := traced.get_node_or_null("Capabilities") as Node
			if component != null and component.has_method("trace_state"):
				entry["capabilities"] = component.call("trace_state")
			trace.append(entry)
		result_trace = trace
	var result := {
		"status": "PASS" if errors.is_empty() else "FAIL",
		"errors": errors,
		"trace": result_trace,
	}
	var result_json := JSON.stringify(result)
	print("SERENDIB_PROBE_JSON:" + result_json)
	if OS.has_feature("web"):
		# Publish the verdict through the JS object bridge for the same reason the
		# probe flag is read that way: eval() is blocked by the artifact CSP.
		var encoded := Marshalls.raw_to_base64(result_json.to_utf8_buffer())
		var document: JavaScriptObject = JavaScriptBridge.get_interface("document")
		var window: JavaScriptObject = JavaScriptBridge.get_interface("window")
		if document != null:
			document.documentElement.setAttribute("data-serendib-probe", encoded)
		if window != null:
			window.__serendibProbeComplete = true
	get_tree().quit(0 if errors.is_empty() else 1)


var result_trace: Array[Dictionary] = []


func _pascal_case(value: String) -> String:
	var result := ""
	var parts := value.replace("-", "_").split("_", false)
	var suffix := ""
	if not parts.is_empty() and String(parts[-1]).is_valid_int():
		suffix = "_" + String(parts[-1])
		parts.remove_at(parts.size() - 1)
	for part: String in parts:
		result += part.capitalize().replace(" ", "")
	return result + suffix
