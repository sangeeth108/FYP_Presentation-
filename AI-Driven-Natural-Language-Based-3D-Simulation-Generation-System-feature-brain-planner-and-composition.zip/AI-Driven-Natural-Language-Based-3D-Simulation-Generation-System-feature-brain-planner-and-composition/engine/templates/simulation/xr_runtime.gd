extends Node
class_name SerendibXRRuntime

## Immersive delivery for a generated simulation.
##
## The immersive mode is not a second build. It is the SAME project, the same
## world plan, the same navigation mesh and the same behaviour state machines,
## with the camera rig substituted and nothing else. That is what makes the
## verification story hold: a door cannot open differently in stereo, because
## no second implementation of a door exists for it to differ from.
##
## The rig is therefore built HERE, at runtime, rather than written into
## main.tscn. A scene carrying XR nodes would either fail or waste them on the
## flat build, and the project must stay one artifact that runs in a browser
## with or without a headset. If no XR interface initialises, this script
## disables itself and the flat controller keeps the camera it already had.
##
## Locomotion offers teleport (default) and constant-velocity glide. Neither
## accelerates. Acceleration mismatched to the vestibular system is the
## component the locomotion literature most consistently associates with
## discomfort, and avoiding it costs nothing this project wanted.

## Metres per second for the glide mode. Constant: there is no ramp, by design.
@export var glide_speed_mps: float = 2.2
## Snap-turn increment. Continuous yaw is the other common comfort offender.
@export var snap_turn_degrees: float = 30.0
## How far a teleport arc is allowed to reach.
@export var teleport_range_m: float = 12.0
## How far off the navmesh a teleport target may land and still be accepted.
## The navmesh is baked with an agent radius, so its edge sits inboard of the
## visible floor; a hard zero would reject targets a player can plainly stand on.
@export var teleport_navmesh_tolerance_m: float = 0.6

const ARC_SEGMENTS := 24
const ARC_STEP_SECONDS := 0.06
const ARC_GRAVITY := 9.8

var _origin: XROrigin3D
var _camera: XRCamera3D
var _left: XRController3D
var _right: XRController3D
var _arc: MeshInstance3D
var _marker: MeshInstance3D
var _player: CharacterBody3D
var _flat_camera: Camera3D
var _interface: XRInterface
var _teleport_target := Vector3.ZERO
var _teleport_valid := false

## Set once an interface is live. Read by the validation probe, which needs to
## distinguish "immersive mode is off" from "immersive mode is broken".
var xr_active := false


func _ready() -> void:
	# One frame, so every entity has run its own _ready(). The flat controller
	# joins the "player" group there, and this node is emitted near the top of
	# the scene, so without the wait the group is reliably empty.
	await get_tree().process_frame
	_player = _find_player()
	if _player == null:
		# No user-controlled entity in this world: nothing to attach a rig to.
		# Not an error. A world can be a diorama.
		set_process(false)
		return
	_flat_camera = _player.get_node_or_null("SpringArm3D/Camera3D") as Camera3D
	_interface = _find_interface()
	if _interface == null:
		set_process(false)
		return
	if _interface is WebXRInterface:
		# WebXR cannot start without a user gesture, so the browser build waits
		# for one instead of failing at load. OpenXR has no such requirement.
		_arm_webxr(_interface as WebXRInterface)
		return
	if _interface.is_initialized() or _interface.initialize():
		_enter_xr()


func _find_player() -> CharacterBody3D:
	# The group is how the flat controller announces itself, and is authoritative
	# when it is populated. The tree walk is the fallback for a world whose
	# user-controlled entity has not joined it, so a missing group membership
	# degrades to a slower answer rather than to no immersive mode at all.
	for node: Node in get_tree().get_nodes_in_group("player"):
		if node is CharacterBody3D:
			return node as CharacterBody3D
	return _first_body(get_tree().current_scene)


func _first_body(node: Node) -> CharacterBody3D:
	if node == null:
		return null
	if node is CharacterBody3D:
		return node as CharacterBody3D
	for child: Node in node.get_children():
		var found := _first_body(child)
		if found != null:
			return found
	return null


func _find_interface() -> XRInterface:
	# OpenXR first: on desktop it is the real headset. WebXR is the browser
	# path and is only meaningful when the build is actually running in one.
	for name: String in ["OpenXR", "WebXR"]:
		var candidate := XRServer.find_interface(name)
		if candidate != null:
			return candidate
	return null


func _arm_webxr(web: WebXRInterface) -> void:
	web.session_mode = "immersive-vr"
	# local-floor gives a floor-relative origin, which is what lets the world's
	# ground plane and the player's real floor agree. Without it the player
	# stands at the world origin's height regardless of where the floor is.
	web.required_features = "local-floor"
	web.optional_features = "bounded-floor"
	web.requested_reference_space_types = "bounded-floor, local-floor, local"
	web.session_supported.connect(_on_session_supported)
	web.session_started.connect(_enter_xr)
	web.session_ended.connect(_exit_xr)
	web.session_failed.connect(_on_session_failed)
	web.is_session_supported("immersive-vr")


func _on_session_supported(mode: String, supported: bool) -> void:
	if mode == "immersive-vr" and supported:
		# Supported does not mean started. The session begins on the next input
		# event, because a browser will refuse it outside a user gesture.
		set_process_unhandled_input(true)


func _on_session_failed(message: String) -> void:
	push_warning("Serendib: immersive session refused: %s" % message)
	xr_active = false


func _unhandled_input(event: InputEvent) -> void:
	if xr_active or _interface == null:
		return
	var gesture: bool = (event is InputEventMouseButton and event.pressed) \
		or (event is InputEventScreenTouch and event.pressed)
	if gesture and _interface is WebXRInterface:
		_interface.initialize()


func _enter_xr() -> void:
	if xr_active:
		return
	_build_rig()
	get_viewport().use_xr = true
	if _flat_camera != null:
		_flat_camera.current = false
	# The flat controller owns mouse-look and WASD. Both are wrong in a headset:
	# the head is the camera, and its script would fight the tracker every frame.
	_player.set_physics_process(false)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	xr_active = true


func _exit_xr() -> void:
	get_viewport().use_xr = false
	if _origin != null:
		_origin.queue_free()
		_origin = null
	if _flat_camera != null:
		_flat_camera.current = true
	_player.set_physics_process(true)
	xr_active = false


func _build_rig() -> void:
	_origin = XROrigin3D.new()
	_origin.name = "XROrigin3D"
	# Parented to the player so every existing thing that reasons about where
	# the player IS -- interaction range, navigation, agent perception --
	# keeps working untouched. The rig moves the player, not a separate body.
	_player.add_child(_origin)

	_camera = XRCamera3D.new()
	_camera.name = "XRCamera3D"
	_origin.add_child(_camera)

	_left = _make_controller("left_hand", "LeftHand")
	_right = _make_controller("right_hand", "RightHand")

	_arc = MeshInstance3D.new()
	_arc.name = "TeleportArc"
	_arc.mesh = ImmediateMesh.new()
	_arc.material_override = _unshaded(Color(0.35, 0.75, 1.0))
	_arc.visible = false
	_origin.add_child(_arc)

	_marker = MeshInstance3D.new()
	_marker.name = "TeleportMarker"
	var disc := CylinderMesh.new()
	disc.top_radius = 0.35
	disc.bottom_radius = 0.35
	disc.height = 0.02
	_marker.mesh = disc
	_marker.material_override = _unshaded(Color(0.35, 0.95, 0.55))
	_marker.visible = false
	# Added to the world, not the origin: the marker marks a place on the
	# ground, and must not travel with the player's head.
	_player.get_parent().add_child(_marker)


func _make_controller(tracker: String, node_name: String) -> XRController3D:
	var controller := XRController3D.new()
	controller.name = node_name
	controller.tracker = tracker
	_origin.add_child(controller)
	controller.button_pressed.connect(_on_button.bind(controller))
	controller.button_released.connect(_on_button_released.bind(controller))
	return controller


func _unshaded(colour: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = colour
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return material


func _process(delta: float) -> void:
	if not xr_active:
		return
	_glide(delta)
	if _right != null and _right.get_float("trigger") > 0.5:
		_aim_teleport()
	_sync_body_to_head()


func _glide(delta: float) -> void:
	if _left == null:
		return
	var stick := _left.get_vector2("primary")
	if stick.length() < 0.15:
		return
	# Head-relative, flattened: pushing forward means "where I am looking",
	# and looking up must not launch the player off the ground.
	var forward := -_camera.global_transform.basis.z
	var right := _camera.global_transform.basis.x
	forward.y = 0.0
	right.y = 0.0
	var direction := (forward.normalized() * stick.y + right.normalized() * stick.x)
	if direction == Vector3.ZERO:
		return
	# Constant velocity. No easing, no ramp: see the class comment.
	_player.velocity = direction.normalized() * glide_speed_mps
	_player.velocity.y = 0.0
	_player.move_and_slide()


func _aim_teleport() -> void:
	if _right == null or _arc == null:
		return
	var mesh := _arc.mesh as ImmediateMesh
	mesh.clear_surfaces()
	var start := _right.global_position
	var velocity := -_right.global_transform.basis.z * (teleport_range_m * 0.55)
	var space := _player.get_world_3d().direct_space_state
	var previous := start
	var landed := false
	mesh.surface_begin(Mesh.PRIMITIVE_LINE_STRIP)
	mesh.surface_add_vertex(_arc.to_local(previous))
	for i in range(1, ARC_SEGMENTS + 1):
		var t := i * ARC_STEP_SECONDS
		var point := start + velocity * t + Vector3.DOWN * (0.5 * ARC_GRAVITY * t * t)
		mesh.surface_add_vertex(_arc.to_local(point))
		var query := PhysicsRayQueryParameters3D.create(previous, point)
		query.exclude = [_player.get_rid()]
		var hit := space.intersect_ray(query)
		if not hit.is_empty():
			_resolve_target(hit["position"])
			landed = true
			break
		previous = point
	mesh.surface_end()
	_arc.visible = true
	if not landed:
		_teleport_valid = false
		_marker.visible = false
	_arc.material_override.albedo_color = (
		Color(0.35, 0.95, 0.55) if _teleport_valid else Color(0.95, 0.4, 0.35)
	)


func _resolve_target(hit_point: Vector3) -> void:
	# The rule the report states: a teleport target must be ON the generated
	# navigation mesh. The arc can land anywhere the physics ray hits -- a roof,
	# a boulder, the far side of a wall -- and none of those are places the
	# world guarantees are reachable. Reusing the navmesh means immersive
	# locomotion inherits the reachability the flat build already verified,
	# rather than inventing a second definition of "somewhere you can stand".
	var map := _player.get_world_3d().navigation_map
	var nearest := NavigationServer3D.map_get_closest_point(map, hit_point)
	_teleport_valid = nearest.distance_to(hit_point) <= teleport_navmesh_tolerance_m
	_teleport_target = nearest
	_marker.global_position = nearest + Vector3.UP * 0.02
	_marker.visible = _teleport_valid


func _on_button(button: String, controller: XRController3D) -> void:
	if button == "ax_button" and controller == _left:
		_snap_turn(-1.0)
	elif button == "by_button" and controller == _left:
		_snap_turn(1.0)


func _on_button_released(button: String, controller: XRController3D) -> void:
	if button != "trigger" or controller != _right:
		return
	_arc.visible = false
	_marker.visible = false
	if _teleport_valid:
		# Move the BODY. The origin is its child, so the head follows and the
		# player's own offset within the play space is preserved.
		_player.global_position = _teleport_target
		_teleport_valid = false


func _snap_turn(sign: float) -> void:
	# Rotate about the head, not the body origin, or the world appears to swing
	# sideways when the player is not standing on their own centre.
	var head := _camera.global_position
	var offset := _player.global_position - head
	var angle := deg_to_rad(snap_turn_degrees) * sign
	_player.global_position = head + offset.rotated(Vector3.UP, angle)
	_player.rotate_y(angle)


func _sync_body_to_head() -> void:
	# Room-scale walking moves the CAMERA within the play space while the body
	# stays put, so interaction range and agent perception would be measured
	# from where the player was standing when they put the headset on. Bring the
	# body under the head and cancel the drift on the origin, which keeps the
	# view stationary while the collider follows.
	if _camera == null:
		return
	var drift := _camera.global_position - _player.global_position
	drift.y = 0.0
	if drift.length() < 0.05:
		return
	_player.global_position += drift
	_origin.global_position -= drift
