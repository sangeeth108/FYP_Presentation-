extends Node3D
class_name SerendibIdlePose

## Keeps a rigged entity standing rather than frozen in its imported bind pose.
##
## Only two things in a generated world animate: the player's controller and an
## autonomous agent's behaviour script. Everything else is a body with a rigged
## model attached and nothing playing on it, so it renders in whatever pose the
## GLB was exported in -- for the Quaternius humans, arms out.
##
## That went unnoticed while the only people in a world were walking agents. A
## `dialogue` speaker is neither controlled nor autonomous: a station guard is
## meant to stand at his post and talk, so he was the first entity whose whole
## purpose was to be stationary and lifelike at the same time.
##
## The clip is found by name at load rather than named by the writer, because the
## asset descriptor records synthetic clip names (`clip_1`, `clip_2`) and not the
## real ones inside the file. Substring matching on a lowercased name is the same
## rule the player controller uses to find its own walk and idle clips.

## Which clip to look for. Exposed so the owner of a downloaded project can point
## a market trader at a different one without touching this script.
@export var clip_hint: String = "idle"


func _ready() -> void:
	var parent := get_parent()
	if parent == null:
		return
	var player := _find_animation_player(parent)
	if player == null:
		return
	var clip := _matching_clip(player)
	if clip.is_empty():
		return
	player.play(clip)


func _matching_clip(player: AnimationPlayer) -> String:
	"""The first clip whose name contains the hint, or nothing.

	Returning nothing rather than falling back to the first available clip is
	deliberate: the alternative is a standing figure playing a death or a punch
	because those happened to be exported earlier in the file.
	"""
	var hint := clip_hint.to_lower()
	for animation: StringName in player.get_animation_list():
		if hint in String(animation).to_lower():
			return String(animation)
	return ""


func _find_animation_player(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer:
		return node as AnimationPlayer
	for child: Node in node.get_children():
		var found := _find_animation_player(child)
		if found != null:
			return found
	return null
