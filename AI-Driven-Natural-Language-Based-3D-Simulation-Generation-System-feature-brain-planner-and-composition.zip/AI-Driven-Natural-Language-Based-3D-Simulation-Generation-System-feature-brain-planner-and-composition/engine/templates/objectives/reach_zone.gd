extends Area3D
class_name ObjectiveReachZone

## Vetted template: reach_zone (objectives/)
## Binds to: game_spec objectives[] with objective_template_id "reach_zone"
##   params.zone_node          -> this node (placed by the project writer)
##   params.requires_objective -> requires_objective (gate; empty = none)
##   is_win_condition          -> is_win_condition
## Promoted from the golden game's win_zone.gd (Castle Gate Trial, P0).
## Detection is group-based ("player") — never a hard class dependency, so
## any controller template works. No randomness. One concern: fire once
## when the player enters, optionally show the win card.

signal objective_completed(objective_id: String)

@export var objective_id: String = "reach_zone"
@export var requires_objective: String = ""
@export var is_win_condition: bool = true
@export var player_group: String = "player"
@export var win_title: String = "YOU WIN!"
@export var win_subtitle: String = "Objective complete."
@export var restart_button_text: String = "Play Again"

var _triggered := false
var _gate_satisfied := false


func _ready() -> void:
	_gate_satisfied = requires_objective.is_empty()
	body_entered.connect(_on_body_entered)


## Wired by the objective manager when requires_objective is set.
func on_required_objective_completed(completed_id: String) -> void:
	if completed_id == requires_objective:
		_gate_satisfied = true


func _on_body_entered(body: Node3D) -> void:
	if _triggered or not _gate_satisfied:
		return
	if not body.is_in_group(player_group):
		return
	_triggered = true
	objective_completed.emit(objective_id)
	if is_win_condition:
		_show_win_card()


func _show_win_card() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 100

	var panel := ColorRect.new()
	panel.color = Color(0.0, 0.0, 0.0, 0.75)
	panel.set_anchors_preset(Control.PRESET_FULL_RECT)

	var box := VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var title := Label.new()
	title.text = win_title
	title.add_theme_font_size_override("font_size", 64)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	var subtitle := Label.new()
	subtitle.text = win_subtitle
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	var restart := Button.new()
	restart.text = restart_button_text
	restart.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	restart.pressed.connect(_on_restart_pressed)

	box.add_child(title)
	box.add_child(subtitle)
	box.add_child(restart)
	panel.add_child(box)
	layer.add_child(panel)
	add_child(layer)

	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _on_restart_pressed() -> void:
	get_tree().reload_current_scene()
