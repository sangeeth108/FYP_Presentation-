extends Node
class_name ObjectiveCollectN

## Vetted template: collect_n (objectives/)
## Binds to: game_spec objectives[] with objective_template_id "collect_n"
##   params.required_count -> required_count
##   objective_id          -> objective_id
##   is_win_condition      -> is_win_condition
##
## Counts PickupCollectible nodes as the player gathers them and completes when
## `required_count` are in hand. It emits the SAME `objective_completed(id)`
## signal as reach_zone, so the existing wiring accepts it untouched: the
## LockedDoor unlocks on it, the WinZone treats it as its `requires_objective`
## gate, and the HUD reports it. That is the whole point — the spatial
## lock-and-key spine is unchanged; only the GOAL differs ("find 5 relics"
## instead of "walk to the key room").
##
## `progress_changed` drives the HUD counter. No randomness. One concern: count
## collectibles and fire once.

signal objective_completed(objective_id: String)
signal progress_changed(collected: int, required: int)

@export var objective_id: String = "collect_relics"
@export var required_count: int = 3
@export var is_win_condition: bool = false

var collected_count := 0
var is_complete := false


func _ready() -> void:
	# Announce the starting state so the HUD shows "0 / N" before the first pickup.
	progress_changed.emit(collected_count, required_count)


## Connected by the project writer to every pickup's `collected` signal.
func on_pickup_collected(_prop_id: String) -> void:
	if is_complete:
		return
	collected_count += 1
	progress_changed.emit(collected_count, required_count)
	if collected_count >= required_count:
		is_complete = true
		objective_completed.emit(objective_id)
