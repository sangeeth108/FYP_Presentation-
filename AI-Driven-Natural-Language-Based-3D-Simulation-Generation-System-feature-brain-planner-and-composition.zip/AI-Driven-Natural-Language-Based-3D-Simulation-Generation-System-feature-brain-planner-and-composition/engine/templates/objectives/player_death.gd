extends Node
class_name FailStatePlayerDeath

## Vetted template: player_death (objectives/ fail states)
## Binds to: game_spec fail_states[] with fail_template_id "player_death".
## Shows the death card when the player's `died` signal fires (wired by
## the project writer as a scene [connection] — declarative, editable).
## One concern: the lose flow. No randomness.

signal failed

@export var death_title: String = "YOU DIED"
@export var death_subtitle: String = "The castle keeps its secrets."
@export var restart_button_text: String = "Try Again"

var _triggered := false


## Signal target for the player's died signal.
func _on_player_died() -> void:
	if _triggered:
		return
	_triggered = true
	failed.emit()
	_show_death_card()


func _show_death_card() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 100

	var panel := ColorRect.new()
	panel.color = Color(0.25, 0.0, 0.0, 0.8)
	panel.set_anchors_preset(Control.PRESET_FULL_RECT)

	var box := VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var title := Label.new()
	title.text = death_title
	title.add_theme_font_size_override("font_size", 64)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	var subtitle := Label.new()
	subtitle.text = death_subtitle
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

	var restart := Button.new()
	restart.text = restart_button_text
	restart.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	restart.pressed.connect(_on_restart_pressed)

	box.add_child(title)
	box.add_child(subtitle)
	box.add_child(restart)
	panel.add_child(box)
	layer.add_child(panel)
	add_child(layer)

	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _on_restart_pressed() -> void:
	get_tree().reload_current_scene()
