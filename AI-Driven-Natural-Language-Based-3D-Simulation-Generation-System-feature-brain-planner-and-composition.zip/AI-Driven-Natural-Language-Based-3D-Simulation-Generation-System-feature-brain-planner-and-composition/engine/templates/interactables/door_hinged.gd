extends StaticBody3D
class_name DoorHinged

## Vetted template: door_hinged (interactables/)
## Binds to: game_spec entities.props[] with interactable_template_id
## "door_hinged" / "door_hinged_lockable"; the lock side of objectives[]
## params.requires_objective chains.
##   locked                -> starts locked (placement_tags contains "locked")
##   unlocked_by_objective -> objective_id whose completion unlocks the door
##                            (wired by the project writer as a scene
##                            [connection] from the key objective's
##                            objective_completed signal — declarative and
##                            editable, never hardcoded).
## The node origin is the hinge (the writer places it at the doorway edge);
## interacting swings the door open around it. Detection is proximity
## (InteractZone Area3D child) + the "interact" action. No randomness.

signal door_opened
signal door_unlocked
signal locked_interaction  # player tried a locked door (UI hint hook)

@export var locked: bool = false
@export var unlocked_by_objective: String = ""
@export var open_angle_deg: float = -90.0
@export var open_seconds: float = 0.8
@export var player_group: String = "player"

var _open := false
var _player_in_range := false


func _ready() -> void:
	var zone := get_node_or_null("InteractZone") as Area3D
	if zone != null:
		zone.body_entered.connect(_on_zone_body_entered)
		zone.body_exited.connect(_on_zone_body_exited)


func _physics_process(_delta: float) -> void:
	if _player_in_range and Input.is_action_just_pressed("interact"):
		_try_open()


func _try_open() -> void:
	if _open:
		return
	if locked:
		locked_interaction.emit()
		return
	_open = true
	var tween := create_tween()
	tween.tween_property(self, "rotation:y", rotation.y + deg_to_rad(open_angle_deg), open_seconds)
	door_opened.emit()


func unlock() -> void:
	if locked:
		locked = false
		door_unlocked.emit()


## Signal target for the key objective's objective_completed(objective_id).
func _on_objective_completed(objective_id: String) -> void:
	if objective_id == unlocked_by_objective:
		unlock()


func _on_zone_body_entered(body: Node3D) -> void:
	if body.is_in_group(player_group):
		_player_in_range = true


func _on_zone_body_exited(body: Node3D) -> void:
	if body.is_in_group(player_group):
		_player_in_range = false
