extends Area3D
class_name PickupCollectible

## Vetted template: pickup_collectible (interactables/)
## Binds to: game_spec entities.props[] with interactable_template_id
##           "pickup_supply", when a collect_n objective is in play.
##   prop_id -> prop_id (the id the collect_n quest counts)
##
## Walk into it and it is collected: the visual hides, the area stops
## monitoring, and `collected` fires once. The node is deliberately KEPT in the
## tree (not queue_free'd) so the playtest bots and the debug view can still
## read its state — a freed node is invisible to state-reading validation.
##
## Detection is group-based ("player"), never a hard class dependency, so any
## controller template works. No randomness. One concern: be collectable once.

signal collected(prop_id: String)

@export var prop_id: String = "pickup"
@export var player_group: String = "player"
@export var bob_height: float = 0.15  # gentle idle motion so it reads as loot
@export var bob_speed: float = 2.0
@export var spin_degrees_per_second: float = 45.0

var is_collected := false

var _visual: Node3D
var _base_y: float = 0.0
var _time: float = 0.0


func _ready() -> void:
	_base_y = position.y
	_visual = get_node_or_null("Visual")
	body_entered.connect(_on_body_entered)


func _process(delta: float) -> void:
	if is_collected or _visual == null:
		return
	# Idle bob + spin. Purely cosmetic, and derived from position (not rng), so
	# two runs of the same build look identical.
	_time += delta
	position.y = _base_y + sin(_time * bob_speed) * bob_height
	_visual.rotate_y(deg_to_rad(spin_degrees_per_second) * delta)


func _on_body_entered(body: Node3D) -> void:
	if is_collected or not body.is_in_group(player_group):
		return
	is_collected = true
	if _visual != null:
		_visual.visible = false
	set_deferred("monitoring", false)  # deferred: never mutate during the physics callback
	collected.emit(prop_id)
