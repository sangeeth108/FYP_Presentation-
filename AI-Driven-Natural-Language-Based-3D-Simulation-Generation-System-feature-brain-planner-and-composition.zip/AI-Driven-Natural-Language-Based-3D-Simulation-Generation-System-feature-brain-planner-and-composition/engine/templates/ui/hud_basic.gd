extends CanvasLayer
class_name HudBasic

## Vetted template: hud_basic (ui/)
## Minimal HUD: health readout + one objective hint line. Wired by the
## project writer via scene [connection]s (player health_changed -> here,
## key objective completed -> here). Approachability rule: friendly text,
## no jargon. One concern: presentation; no game logic. No randomness.

@export var max_health: int = 100
@export var hint_locked: String = "Find the glowing key zone to unlock the exit door."
@export var hint_unlocked: String = "The exit door is unlocked - escape!"
@export var key_objective_id: String = "reach_key"
## Shown only when a collect_n objective is in play (writer sets the noun,
## e.g. "Relics"). Empty = no counter line, so reach_zone games look unchanged.
@export var collect_label: String = ""

var _health_label: Label
var _hint_label: Label
var _progress_label: Label


func _ready() -> void:
	layer = 50
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_TOP_LEFT)
	margin.add_theme_constant_override("margin_left", 16)
	margin.add_theme_constant_override("margin_top", 12)

	var box := VBoxContainer.new()
	_health_label = Label.new()
	_health_label.text = "Health: %d / %d" % [max_health, max_health]
	_health_label.add_theme_font_size_override("font_size", 22)
	_hint_label = Label.new()
	_hint_label.text = hint_locked
	_hint_label.add_theme_font_size_override("font_size", 16)

	box.add_child(_health_label)
	box.add_child(_hint_label)

	if not collect_label.is_empty():
		_progress_label = Label.new()
		_progress_label.add_theme_font_size_override("font_size", 20)
		_progress_label.text = "%s: 0" % collect_label
		box.add_child(_progress_label)

	margin.add_child(box)
	add_child(margin)


## Signal target for the controller's health_changed(current, max_value).
func _on_health_changed(current: int, max_value: int) -> void:
	_health_label.text = "Health: %d / %d" % [current, max_value]


## Signal target for the key objective's objective_completed(objective_id).
func on_objective_completed(objective_id: String) -> void:
	if objective_id == key_objective_id:
		_hint_label.text = hint_unlocked


## Signal target for collect_n's progress_changed(collected, required).
func on_objective_progress(collected: int, required: int) -> void:
	if _progress_label != null:
		_progress_label.text = "%s: %d / %d" % [collect_label, collected, required]
