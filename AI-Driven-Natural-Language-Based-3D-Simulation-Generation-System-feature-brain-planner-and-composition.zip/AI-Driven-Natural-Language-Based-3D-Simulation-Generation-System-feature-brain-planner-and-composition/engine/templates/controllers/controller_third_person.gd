extends CharacterBody3D
class_name ControllerThirdPerson

## Vetted template: controller_third_person (controllers/)
## Binds to: game_spec player.* with controller_template_id "controller_third_person"
##   player.move_speed -> move_speed
##   player.health     -> health
##   player.verbs      -> move/sprint/jump are native; interact via the
##                        "interact" action (interactables listen themselves)
## Camera: third_person (SpringArm3D + Camera3D children, built by the
## project writer). Adds itself to the "player" group so objective
## templates (reach_zone) detect it without class coupling.
## Input actions (defined by the project writer in project.godot):
##   move_forward/move_back/move_left/move_right, jump, sprint, interact.
## No randomness. One concern: movement + camera + health holder.

signal health_changed(current: int, max_value: int)
signal died

@export var move_speed: float = 5.0
@export var sprint_multiplier: float = 1.6
@export var jump_velocity: float = 4.5
@export var health: int = 100
@export var mouse_sensitivity: float = 0.003
@export var pitch_min_deg: float = -60.0
@export var pitch_max_deg: float = 30.0

var _current_health: int
var _spring_arm: SpringArm3D


func _ready() -> void:
	add_to_group("player")
	_current_health = health
	_spring_arm = get_node_or_null("SpringArm3D")
	# Keep the capsule glued to sloped floors. Levels connect tiers with ramps,
	# and the default snap is short enough that a walking capsule skips off the
	# slope and bounces up it. (Godot only applies this while grounded and not
	# jumping, so it costs the jump nothing.)
	floor_snap_length = 0.6
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	elif event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	elif event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		if _spring_arm != null:
			_spring_arm.rotation.x = clampf(
				_spring_arm.rotation.x - event.relative.y * mouse_sensitivity,
				deg_to_rad(pitch_min_deg),
				deg_to_rad(pitch_max_deg),
			)


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta
	elif Input.is_action_just_pressed("jump"):
		velocity.y = jump_velocity
	elif velocity.y > 0.0:
		# Walking UP a ramp, move_and_slide converts the horizontal push into
		# upward velocity. Carried into the next frame it launches the capsule
		# off the slope; it goes airborne, gravity drags it back, and it bounces
		# instead of climbing. Only ever clears an upward drift while grounded,
		# so jumping (set above) is untouched.
		velocity.y = 0.0

	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	var speed := move_speed * (sprint_multiplier if Input.is_action_pressed("sprint") else 1.0)
	if direction != Vector3.ZERO:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0.0, speed)
		velocity.z = move_toward(velocity.z, 0.0, speed)
	move_and_slide()


func apply_damage(amount: int) -> void:
	if _current_health <= 0:
		return
	_current_health = maxi(_current_health - amount, 0)
	health_changed.emit(_current_health, health)
	if _current_health == 0:
		died.emit()
