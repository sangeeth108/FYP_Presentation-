extends CharacterBody3D
class_name ControllerTopdown3d

## Vetted template: controller_topdown_3d (controllers/)
## Binds to: game_spec player.* with controller_template_id
## "controller_topdown_3d" (meta.camera "top_down_3d").
##   player.move_speed -> move_speed     player.health -> health
## Movement is WORLD-axis (screen-relative under the fixed overhead
## camera the project writer parents to this node); the body turns to
## face its motion. No mouse-look. Joins the "player" group; exposes the
## same apply_damage/died seam as the third-person controller.
## Input actions: move_forward/move_back/move_left/move_right, sprint,
## jump, interact. No randomness.

signal health_changed(current: int, max_value: int)
signal died

@export var move_speed: float = 5.0
@export var sprint_multiplier: float = 1.6
@export var jump_velocity: float = 4.5
@export var health: int = 100
@export var turn_speed: float = 10.0

var _current_health: int


func _ready() -> void:
	add_to_group("player")
	_current_health = health


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta
	elif Input.is_action_just_pressed("jump"):
		velocity.y = jump_velocity

	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction := Vector3(input_dir.x, 0, input_dir.y)  # world axes, camera-fixed
	var speed := move_speed * (sprint_multiplier if Input.is_action_pressed("sprint") else 1.0)
	if direction != Vector3.ZERO:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
		var target_yaw := atan2(-direction.x, -direction.z)
		rotation.y = lerp_angle(rotation.y, target_yaw, turn_speed * delta)
	else:
		velocity.x = move_toward(velocity.x, 0.0, speed)
		velocity.z = move_toward(velocity.z, 0.0, speed)
	move_and_slide()


func apply_damage(amount: int) -> void:
	if _current_health <= 0:
		return
	_current_health = maxi(_current_health - amount, 0)
	health_changed.emit(_current_health, health)
	if _current_health == 0:
		died.emit()
