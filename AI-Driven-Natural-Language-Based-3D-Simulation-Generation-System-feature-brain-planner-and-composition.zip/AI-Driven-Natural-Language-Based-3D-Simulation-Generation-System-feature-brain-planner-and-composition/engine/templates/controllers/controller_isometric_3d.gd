extends CharacterBody3D
class_name ControllerIsometric3d

## Vetted template: controller_isometric_3d (controllers/)
## Binds to: game_spec player.* with controller_template_id
## "controller_isometric_3d" (meta.camera "isometric_3d").
##   player.move_speed -> move_speed     player.health -> health
## Movement is CAMERA-relative: the writer parents a fixed 45-degree
## isometric camera to this node, and input up/right map to the camera's
## screen up/right projected onto the ground plane (the classic iso
## feel). Body turns to face motion. Same apply_damage/died seam. No
## randomness.

signal health_changed(current: int, max_value: int)
signal died

@export var move_speed: float = 5.0
@export var sprint_multiplier: float = 1.6
@export var jump_velocity: float = 4.5
@export var health: int = 100
@export var turn_speed: float = 10.0
## The fixed camera yaw the writer sets on the rig (degrees).
@export var camera_yaw_deg: float = 45.0

var _current_health: int


func _ready() -> void:
	add_to_group("player")
	_current_health = health


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta
	elif Input.is_action_just_pressed("jump"):
		velocity.y = jump_velocity

	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var yaw := deg_to_rad(camera_yaw_deg)
	var forward := Vector3(-sin(yaw), 0, -cos(yaw))
	var right := Vector3(cos(yaw), 0, -sin(yaw))
	# get_vector: pressing move_forward yields input_dir.y = -1.
	var direction := (right * input_dir.x - forward * input_dir.y).normalized() if input_dir != Vector2.ZERO else Vector3.ZERO
	var speed := move_speed * (sprint_multiplier if Input.is_action_pressed("sprint") else 1.0)
	if direction != Vector3.ZERO:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
		rotation.y = lerp_angle(rotation.y, atan2(-direction.x, -direction.z), turn_speed * delta)
	else:
		velocity.x = move_toward(velocity.x, 0.0, speed)
		velocity.z = move_toward(velocity.z, 0.0, speed)
	move_and_slide()


func apply_damage(amount: int) -> void:
	if _current_health <= 0:
		return
	_current_health = maxi(_current_health - amount, 0)
	health_changed.emit(_current_health, health)
	if _current_health == 0:
		died.emit()
