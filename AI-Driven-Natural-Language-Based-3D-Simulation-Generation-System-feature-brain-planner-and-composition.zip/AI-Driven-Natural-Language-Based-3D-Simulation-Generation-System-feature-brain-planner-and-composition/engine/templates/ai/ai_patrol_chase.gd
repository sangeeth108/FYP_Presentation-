extends CharacterBody3D
class_name AiPatrolChase

## Vetted template: ai_patrol_chase (ai/)
## Binds to: game_spec entities.enemies[] with ai_template_id "ai_patrol_chase"
##   stats.health -> health   stats.damage -> damage   stats.speed -> speed
## Patrol -> chase when the player enters detection_radius -> melee on
## contact range, repeating every attack_interval. Requires a
## NavigationAgent3D child (emitted by the project writer) and a baked-in
## NavigationMesh region in the scene.
## Patrol is DETERMINISTIC: a fixed square of waypoints around the spawn
## point (patrol_radius), no randomness (CLAUDE.md rule 14).
## Joins "enemies" group; damages anything in the player group via its
## apply_damage(amount) method (controller template seam).

signal died

@export var health: int = 5
@export var damage: int = 1
@export var speed: float = 3.0
@export var detection_radius: float = 8.0
@export var attack_range: float = 1.5
@export var attack_interval: float = 1.0
@export var patrol_radius: float = 3.0
@export var turn_speed: float = 8.0
@export var player_group: String = "player"

## Sound is driven by the same ACTIVITIES as animation, and the clips are chosen
## by the MODEL this enemy wears (the project writer fills these from the kit's
## sound set), so a skeleton dies as bones clattering. Empty arrays = silent:
## audio, like animation, is never a hard requirement.
@export var sfx_attack: Array[AudioStream] = []
@export var sfx_hit: Array[AudioStream] = []
@export var sfx_death: Array[AudioStream] = []
@export var sfx_step: Array[AudioStream] = []
## Seconds of walking per footstep, scaled by how fast this enemy moves.
@export var step_interval: float = 0.45

## Animation is driven by ACTIVITY, using whatever clips the model actually ships
## (the KayKit characters carry ~95: Idle, Walking, Running, attacks, Death...).
## Each entry lists candidates best-first; the first one the model HAS is used, so
## a model with fewer clips still animates and a GENERATED model with none simply
## stays static — animation is never a hard requirement.
##
## The names at the tail are the Quaternius CC0 animal kit's convention (ADR-0007
## rung 1), READ OFF THE REAL FILES rather than guessed — the guesses were 4/6:
## the animals' strike is `Attack_Headbutt`/`Attack_Kick`/`Attack` and their flinch
## is `Idle_HitReact_Left`, not the `Attack`/`Hit` that seemed obvious. They sit
## LAST so the skeletons keep their exact clips, and a name no model has simply
## never matches — that is what lets one list serve two unrelated character kits.
const ANIM_CANDIDATES := {
	"idle": ["Idle", "Idle_B", "2H_Melee_Idle"],
	"patrol": ["Walking_D_Skeletons", "Walking_A", "Walking_B", "Walk", "Idle"],
	"chase": ["Running_A", "Running_B", "Gallop", "Run", "Walking_A", "Walk"],
	"attack": [
		"1H_Melee_Attack_Chop", "2H_Melee_Attack_Chop", "1H_Melee_Attack_Stab",
		"Attack", "Attack_Headbutt", "Attack_Kick",
	],
	"hit": ["Hit_A", "Hit_B", "Idle_HitReact_Left", "Idle_HitReact_Right"],
	"death": ["Death_C_Skeletons", "Death_A", "Death_B", "Death"],
}

var _agent: NavigationAgent3D
var _spawn: Vector3
var _patrol_points: Array[Vector3] = []
var _patrol_index := 0
var _attack_cooldown := 0.0
var _current_health: int
var _anim: AnimationPlayer
var _anim_for: Dictionary = {}   # activity -> the clip this model really has
var _current_activity := ""
var _dying := false
var _sfx: AudioStreamPlayer3D       # reactions: strike, flinch, death
var _sfx_steps: AudioStreamPlayer3D # footsteps, so a step never cuts a strike
var _step_timer := 0.0
var _rng := RandomNumberGenerator.new()
# A strike or a flinch owns the model until its clip ends; locomotion must not
# overwrite it on the next physics tick or the clip is never seen.
var _lock := 0.0


func _ready() -> void:
	add_to_group("enemies")
	_current_health = health
	_agent = get_node("NavigationAgent3D")
	_spawn = global_position
	# Seeded from the node name: which clip variant an enemy picks is reproducible
	# from the spec alone (CLAUDE.md rule 14), and two enemies don't step in sync.
	_rng.seed = hash(name)
	_step_timer = _rng.randf() * step_interval
	_bind_animations()
	_bind_sounds()
	for offset in [
		Vector3(patrol_radius, 0, 0),
		Vector3(0, 0, patrol_radius),
		Vector3(-patrol_radius, 0, 0),
		Vector3(0, 0, -patrol_radius),
	]:
		_patrol_points.append(_spawn + offset)


## Find the model's AnimationPlayer (imported GLBs put one under the instanced
## scene) and resolve each activity to a clip this model actually has.
func _bind_animations() -> void:
	_anim = _find_animation_player(self)
	if _anim == null:
		return  # e.g. a generated mesh with no clips — stay static, never fail
	var have := _anim.get_animation_list()
	for activity in ANIM_CANDIDATES:
		for candidate in ANIM_CANDIDATES[activity]:
			if candidate in have:
				_anim_for[activity] = candidate
				break


## The writer emits these so they are visible and tunable in the editor; a
## hand-written scene without them still works — the script makes its own.
func _bind_sounds() -> void:
	_sfx = get_node_or_null("Sfx")
	if _sfx == null:
		_sfx = AudioStreamPlayer3D.new()
		_sfx.name = "Sfx"
		add_child(_sfx)
	_sfx_steps = get_node_or_null("SfxSteps")
	if _sfx_steps == null:
		_sfx_steps = AudioStreamPlayer3D.new()
		_sfx_steps.name = "SfxSteps"
		add_child(_sfx_steps)


## Play one clip from an activity's bank. Empty bank = silence, never an error.
func _play_sound(player: AudioStreamPlayer3D, bank: Array[AudioStream]) -> void:
	if player == null or bank.is_empty():
		return
	player.stream = bank[_rng.randi() % bank.size()]
	player.play()


func _find_animation_player(node: Node) -> AnimationPlayer:
	for child in node.get_children():
		if child is AnimationPlayer:
			return child
		var found := _find_animation_player(child)
		if found != null:
			return found
	return null


## Play the clip for an activity, if this model has one. Idempotent: re-requesting
## the current activity does not restart it (so walking doesn't stutter).
func _set_activity(activity: String, force := false) -> void:
	if _anim == null or not _anim_for.has(activity):
		return
	if activity == _current_activity and not force:
		return
	_current_activity = activity
	_anim.play(_anim_for[activity])


## A one-shot reaction (strike, flinch): replay it from the start and hold it for
## the clip's own length so the next physics tick cannot cut it off.
func _play_transient(activity: String) -> void:
	if _anim == null or not _anim_for.has(activity):
		return
	_set_activity(activity, true)
	var clip := _anim.get_animation(_anim_for[activity])
	_lock = clip.length if clip != null else 0.0


func _physics_process(delta: float) -> void:
	if _dying:
		return  # let the death animation finish; no AI, no movement
	if not is_on_floor():
		velocity += get_gravity() * delta
	_attack_cooldown = maxf(_attack_cooldown - delta, 0.0)
	_lock = maxf(_lock - delta, 0.0)

	var player := get_tree().get_first_node_in_group(player_group) as Node3D
	var target := _patrol_points[_patrol_index]
	var chasing := false
	if player != null:
		var distance := global_position.distance_to(player.global_position)
		if distance <= attack_range:
			_try_attack(player)
			velocity.x = 0.0
			velocity.z = 0.0
			move_and_slide()
			return
		if distance <= detection_radius:
			target = player.global_position
			chasing = true

	_agent.target_position = target
	if _agent.is_navigation_finished():
		_patrol_index = (_patrol_index + 1) % _patrol_points.size()
	else:
		var direction := (_agent.get_next_path_position() - global_position)
		direction.y = 0.0
		direction = direction.normalized()
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
	var moving := Vector2(velocity.x, velocity.z).length() > 0.1
	if moving:
		rotation.y = lerp_angle(rotation.y, atan2(-velocity.x, -velocity.z), turn_speed * delta)
	# The activity IS the animation: running when hunting you, walking a patrol,
	# idling when it has arrived. A flinch in progress keeps the model.
	if _lock <= 0.0:
		if not moving:
			_set_activity("idle")
		elif chasing:
			_set_activity("chase")
		else:
			_set_activity("patrol")
	_footsteps(delta, moving)
	move_and_slide()


## Footsteps come from the walking itself: only while actually moving, and paced
## by how fast this enemy really travels, so a fast chaser steps faster.
func _footsteps(delta: float, moving: bool) -> void:
	if not moving or sfx_step.is_empty():
		return
	var travelled := Vector2(velocity.x, velocity.z).length()
	_step_timer -= delta * (travelled / maxf(speed, 0.01))
	if _step_timer <= 0.0:
		_step_timer = step_interval
		_play_sound(_sfx_steps, sfx_step)


func _try_attack(player: Node3D) -> void:
	if _attack_cooldown > 0.0:
		return  # mid-swing or recovering: never restart the clip, it would freeze
	_play_transient("attack")  # one swing, one replay
	_play_sound(_sfx, sfx_attack)
	_attack_cooldown = attack_interval
	if player.has_method("apply_damage"):
		player.apply_damage(damage)


func take_damage(amount: int) -> void:
	if _current_health <= 0:
		return
	_current_health = maxi(_current_health - amount, 0)
	if _current_health == 0:
		_die()
	else:
		_play_transient("hit")  # a flinch that holds, then the AI resumes
		_play_sound(_sfx, sfx_hit)


## Death: emit immediately (listeners must not wait on a cosmetic animation),
## then play the death clip and free once it ends. Collision goes off at once so
## a corpse never blocks the player. With no clip, free right away as before.
func _die() -> void:
	_dying = true
	died.emit()
	velocity = Vector3.ZERO
	set_collision_layer_value(3, false)
	if _sfx_steps != null:
		_sfx_steps.stop()  # a corpse takes no more steps
	_play_sound(_sfx, sfx_death)
	if _anim != null and _anim_for.has("death"):
		_set_activity("death", true)
		await _anim.animation_finished
	elif _sfx != null and _sfx.playing:
		await _sfx.finished  # nothing to animate: at least let the sound land
	queue_free()
