"""Consent-qualified learning, data-subject requests, and model lifecycle.

Revision ID: 0005_learning_governance
Revises: 0004_identity_tenancy
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision: str = "0005_learning_governance"
down_revision: str | None = "0004_identity_tenancy"
branch_labels = None
depends_on = None


def _owned_columns() -> list[sa.Column]:
    return [
        sa.Column("tenant_id", sa.String(64), nullable=False),
        sa.Column("owner_id", sa.String(64), nullable=False),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["owner_id"], ["users.id"], ondelete="CASCADE"),
    ]


def upgrade() -> None:
    op.create_table(
        "consent_records",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("tenant_id", sa.String(64), nullable=False),
        sa.Column("subject_user_id", sa.String(64), nullable=False),
        sa.Column("actor_user_id", sa.String(64), nullable=False),
        sa.Column("consent_kind", sa.String(24), nullable=False),
        sa.Column("scope", sa.String(24), nullable=False),
        sa.Column("data_category", sa.String(32), nullable=False),
        sa.Column("granted", sa.Boolean(), nullable=False),
        sa.Column("disclosure_version", sa.String(32), nullable=False),
        sa.Column("locale", sa.String(16), nullable=False),
        sa.Column("guardian_relationship_id", sa.String(64), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("withdrawn_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["subject_user_id"], ["users.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["actor_user_id"], ["users.id"], ondelete="RESTRICT"),
        sa.ForeignKeyConstraint(
            ["guardian_relationship_id"],
            ["guardian_relationships.id"],
            ondelete="SET NULL",
        ),
    )
    op.create_index(
        "ix_consent_subject_scope",
        "consent_records",
        ["subject_user_id", "scope", "data_category", "created_at"],
    )
    op.create_table(
        "content_rights",
        sa.Column("id", sa.String(64), primary_key=True),
        *_owned_columns(),
        sa.Column("resource_type", sa.String(48), nullable=False),
        sa.Column("resource_id", sa.String(128), nullable=False),
        sa.Column("rights_basis", sa.String(48), nullable=False),
        sa.Column("training_allowed", sa.Boolean(), nullable=False),
        sa.Column("licence_id", sa.String(120), nullable=True),
        sa.Column("verified_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint(
            "tenant_id", "resource_type", "resource_id", name="uq_content_right_resource"
        ),
    )
    op.create_table(
        "training_eligibility",
        sa.Column("id", sa.String(64), primary_key=True),
        *_owned_columns(),
        sa.Column("resource_type", sa.String(48), nullable=False),
        sa.Column("resource_id", sa.String(128), nullable=False),
        sa.Column("training_scope", sa.String(24), nullable=False),
        sa.Column("data_source", sa.String(32), nullable=False),
        sa.Column("status", sa.String(24), nullable=False),
        sa.Column("consent_record_id", sa.String(64), nullable=True),
        sa.Column("guardian_consent_record_id", sa.String(64), nullable=True),
        sa.Column("content_right_id", sa.String(64), nullable=True),
        sa.Column("moderation_status", sa.String(24), nullable=False),
        sa.Column("quality_status", sa.String(24), nullable=False),
        sa.Column("pseudonym_key", sa.String(64), nullable=True),
        sa.Column("exclusion_reason", sa.String(160), nullable=True),
        sa.Column("legal_hold", sa.Boolean(), nullable=False),
        sa.Column("deleted", sa.Boolean(), nullable=False),
        sa.Column("evaluated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(
            ["consent_record_id"], ["consent_records.id"], ondelete="SET NULL"
        ),
        sa.ForeignKeyConstraint(
            ["guardian_consent_record_id"], ["consent_records.id"], ondelete="SET NULL"
        ),
        sa.ForeignKeyConstraint(
            ["content_right_id"], ["content_rights.id"], ondelete="SET NULL"
        ),
        sa.UniqueConstraint(
            "resource_type",
            "resource_id",
            "training_scope",
            name="uq_training_eligibility_resource_scope",
        ),
    )
    op.create_index(
        "ix_training_eligibility_export",
        "training_eligibility",
        ["status", "training_scope", "deleted", "legal_hold"],
    )
    op.create_table(
        "feedback_events",
        sa.Column("id", sa.String(64), primary_key=True),
        *_owned_columns(),
        sa.Column("simulation_id", sa.String(64), nullable=True),
        sa.Column("kind", sa.String(32), nullable=False),
        sa.Column("rating", sa.Integer(), nullable=True),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "usage_events",
        sa.Column("id", sa.String(64), primary_key=True),
        *_owned_columns(),
        sa.Column("simulation_id", sa.String(64), nullable=True),
        sa.Column("event_type", sa.String(64), nullable=False),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "data_subject_requests",
        sa.Column("id", sa.String(64), primary_key=True),
        *_owned_columns(),
        sa.Column("request_type", sa.String(24), nullable=False),
        sa.Column("state", sa.String(24), nullable=False),
        sa.Column("detail", sa.JSON(), nullable=False),
        sa.Column("result", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_table(
        "dataset_versions",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("tenant_id", sa.String(64), nullable=True),
        sa.Column("scope", sa.String(24), nullable=False),
        sa.Column("status", sa.String(24), nullable=False),
        sa.Column("manifest_hash", sa.String(64), nullable=True),
        sa.Column("item_count", sa.Integer(), nullable=False),
        sa.Column("metadata_json", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("frozen_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
    )
    op.create_table(
        "dataset_items",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("dataset_version_id", sa.String(64), nullable=False),
        sa.Column("eligibility_id", sa.String(64), nullable=False),
        sa.Column("content_hash", sa.String(64), nullable=False),
        sa.Column("split", sa.String(16), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(
            ["dataset_version_id"], ["dataset_versions.id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(
            ["eligibility_id"], ["training_eligibility.id"], ondelete="RESTRICT"
        ),
        sa.UniqueConstraint(
            "dataset_version_id", "eligibility_id", name="uq_dataset_item_eligibility"
        ),
    )
    op.create_table(
        "training_runs",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("dataset_version_id", sa.String(64), nullable=False),
        sa.Column("tenant_id", sa.String(64), nullable=True),
        sa.Column("target", sa.String(32), nullable=False),
        sa.Column("base_model", sa.String(160), nullable=False),
        sa.Column("state", sa.String(24), nullable=False),
        sa.Column("config", sa.JSON(), nullable=False),
        sa.Column("metrics", sa.JSON(), nullable=False),
        sa.Column("artifact_ref", sa.String(512), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(
            ["dataset_version_id"], ["dataset_versions.id"], ondelete="RESTRICT"
        ),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
    )
    op.create_table(
        "model_versions",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("training_run_id", sa.String(64), nullable=True),
        sa.Column("tenant_id", sa.String(64), nullable=True),
        sa.Column("name", sa.String(160), nullable=False),
        sa.Column("target", sa.String(32), nullable=False),
        sa.Column("state", sa.String(24), nullable=False),
        sa.Column("digest", sa.String(128), nullable=False),
        sa.Column("licence_id", sa.String(120), nullable=False),
        sa.Column("model_card", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(
            ["training_run_id"], ["training_runs.id"], ondelete="SET NULL"
        ),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
    )
    op.create_table(
        "model_deployments",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("model_version_id", sa.String(64), nullable=False),
        sa.Column("tenant_id", sa.String(64), nullable=True),
        sa.Column("stage", sa.String(24), nullable=False),
        sa.Column("traffic_percent", sa.Integer(), nullable=False),
        sa.Column("state", sa.String(24), nullable=False),
        sa.Column("metrics", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("ended_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(
            ["model_version_id"], ["model_versions.id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
    )
    op.create_table(
        "security_incidents",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("tenant_id", sa.String(64), nullable=True),
        sa.Column("severity", sa.String(16), nullable=False),
        sa.Column("state", sa.String(24), nullable=False),
        sa.Column("category", sa.String(64), nullable=False),
        sa.Column("detail", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="SET NULL"),
    )


def downgrade() -> None:
    for table in (
        "security_incidents",
        "model_deployments",
        "model_versions",
        "training_runs",
        "dataset_items",
        "dataset_versions",
        "data_subject_requests",
        "usage_events",
        "feedback_events",
        "training_eligibility",
        "content_rights",
        "consent_records",
    ):
        op.drop_table(table)
