"""Fail-closed training-data provenance on frozen specs.

Existing rows predate consent and source classification. They are deliberately
backfilled as ``legacy_unclassified`` and ineligible: absence of governance
metadata must never be interpreted as permission to train.

Revision ID: 0003_training_safety
Revises: 0002_specs
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision: str = "0003_training_safety"
down_revision: str | None = "0002_specs"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "specs",
        sa.Column(
            "data_source",
            sa.String(32),
            nullable=False,
            server_default="legacy_unclassified",
        ),
    )
    op.add_column(
        "specs",
        sa.Column(
            "training_eligible",
            sa.Boolean(),
            nullable=False,
            server_default=sa.false(),
        ),
    )
    op.create_index("ix_specs_data_source", "specs", ["data_source"])
    op.create_index("ix_specs_training_eligible", "specs", ["training_eligible"])


def downgrade() -> None:
    op.drop_index("ix_specs_training_eligible", table_name="specs")
    op.drop_index("ix_specs_data_source", table_name="specs")
    op.drop_column("specs", "training_eligible")
    op.drop_column("specs", "data_source")
