"""Tenant row-level security for stage_artifacts.

Revision ID: 0014_stage_artifact_rls
Revises: 0013_stage_artifacts

`stage_artifacts` was added in 0013 without a policy while every sibling
evidence table hanging off `generation_runs` -- validation_evidence,
simulation_artifacts, capability_gaps -- has had one since 0009. The API is
tenant-scoped and tested, so this is defence in depth rather than a live leak,
but the table holds whole stage payloads: the user's prompt, the planner's spec,
and any edits made in the inspector. That is the most sensitive per-tenant
content the system stores, and it should not be the one table relying on
application code alone.

Same shape as the other run-scoped tables: reachability through the run's
tenant, with the worker/admin bypass. SQLite (local and test) has no RLS and is
skipped, exactly as in 0009.
"""

from __future__ import annotations

from alembic import op

revision: str = "0014_stage_artifact_rls"
down_revision: str | None = "0013_stage_artifacts"
branch_labels = None
depends_on = None

_POLICY = "serendib_tenant_stage_artifacts"

_EXPRESSION = """
    EXISTS (
        SELECT 1 FROM generation_runs r
        WHERE r.id = stage_artifacts.run_id
          AND r.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')
    )
"""

_BYPASS = """
    COALESCE(current_setting('app.worker_bypass', true), '') = 'on'
    OR COALESCE(current_setting('app.platform_admin', true), '') = 'on'
"""


def _postgresql() -> bool:
    return op.get_bind().dialect.name == "postgresql"


def upgrade() -> None:
    if not _postgresql():
        return
    op.execute('ALTER TABLE "stage_artifacts" ENABLE ROW LEVEL SECURITY')
    op.execute(
        f'CREATE POLICY "{_POLICY}" ON "stage_artifacts" '
        f"USING ({_BYPASS} OR ({_EXPRESSION})) "
        f"WITH CHECK ({_BYPASS} OR ({_EXPRESSION}))"
    )


def downgrade() -> None:
    if not _postgresql():
        return
    op.execute(f'DROP POLICY IF EXISTS "{_POLICY}" ON "stage_artifacts"')
    op.execute('ALTER TABLE "stage_artifacts" DISABLE ROW LEVEL SECURITY')
