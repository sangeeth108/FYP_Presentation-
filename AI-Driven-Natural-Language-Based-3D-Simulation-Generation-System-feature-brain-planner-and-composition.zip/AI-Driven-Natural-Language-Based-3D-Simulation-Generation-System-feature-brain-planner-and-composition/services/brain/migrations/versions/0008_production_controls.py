"""Tenant quotas, job leases, and model route administration.

Revision ID: 0008_production_controls
Revises: 0007_world_plans
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision: str = "0008_production_controls"
down_revision: str | None = "0007_world_plans"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "tenant_quotas",
        sa.Column("tenant_id", sa.String(64), primary_key=True),
        sa.Column("max_concurrent_generations", sa.Integer(), nullable=False),
        sa.Column("monthly_generation_limit", sa.Integer(), nullable=False),
        sa.Column("active_generations", sa.Integer(), nullable=False),
        sa.Column("window_started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("window_generations", sa.Integer(), nullable=False),
        sa.Column("gpu_seconds_limit", sa.Integer(), nullable=False),
        sa.Column("gpu_seconds_used", sa.Integer(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
    )
    op.create_table(
        "generation_leases",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("run_id", sa.String(64), nullable=False, unique=True),
        sa.Column("tenant_id", sa.String(64), nullable=False),
        sa.Column("state", sa.String(16), nullable=False),
        sa.Column("reserved_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("released_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["run_id"], ["generation_runs.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
    )
    op.create_index(
        "ix_generation_leases_tenant_state",
        "generation_leases",
        ["tenant_id", "state"],
    )
    op.create_table(
        "model_route_overrides",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("tenant_id", sa.String(64), nullable=True),
        sa.Column("role", sa.String(24), nullable=False),
        sa.Column("model_id", sa.String(160), nullable=False),
        sa.Column("enabled", sa.Boolean(), nullable=False),
        sa.Column("created_by", sa.String(64), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["created_by"], ["users.id"], ondelete="RESTRICT"),
        sa.UniqueConstraint("tenant_id", "role", name="uq_model_route_tenant_role"),
    )


def downgrade() -> None:
    op.drop_table("model_route_overrides")
    op.drop_index(
        "ix_generation_leases_tenant_state", table_name="generation_leases"
    )
    op.drop_table("generation_leases")
    op.drop_table("tenant_quotas")

