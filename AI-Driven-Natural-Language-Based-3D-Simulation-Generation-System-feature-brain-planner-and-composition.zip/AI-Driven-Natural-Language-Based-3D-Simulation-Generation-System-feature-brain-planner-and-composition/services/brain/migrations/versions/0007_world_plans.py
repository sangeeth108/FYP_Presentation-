"""Persist canonical measured WorldPlans.

Revision ID: 0007_world_plans
Revises: 0006_simulation_core
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision: str = "0007_world_plans"
down_revision: str | None = "0006_simulation_core"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "world_plans",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("run_id", sa.String(64), nullable=False),
        sa.Column("spec_id", sa.String(64), nullable=False),
        sa.Column("simulation_id", sa.String(64), nullable=False),
        sa.Column("tenant_id", sa.String(64), nullable=False),
        sa.Column("plan_hash", sa.String(64), nullable=False),
        sa.Column("schema_version", sa.String(16), nullable=False),
        sa.Column("compiler_version", sa.String(32), nullable=False),
        sa.Column("body", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["run_id"], ["generation_runs.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["spec_id"], ["simulation_specs.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(
            ["simulation_id"], ["simulations.id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
        sa.UniqueConstraint("run_id", name="uq_world_plan_run"),
    )
    op.create_index("ix_world_plans_simulation", "world_plans", ["simulation_id"])
    op.create_index("ix_world_plans_hash", "world_plans", ["plan_hash"])
    op.create_table(
        "asset_descriptors",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("run_id", sa.String(64), nullable=False),
        sa.Column("simulation_id", sa.String(64), nullable=False),
        sa.Column("tenant_id", sa.String(64), nullable=False),
        sa.Column("entity_id", sa.String(80), nullable=False),
        sa.Column("asset_ref", sa.String(160), nullable=False),
        sa.Column("content_hash", sa.String(64), nullable=False),
        sa.Column("measurement_status", sa.String(24), nullable=False),
        sa.Column("body", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["run_id"], ["generation_runs.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(
            ["simulation_id"], ["simulations.id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
        sa.UniqueConstraint("run_id", "entity_id", name="uq_asset_descriptor_entity_run"),
    )
    op.create_index(
        "ix_asset_descriptors_simulation",
        "asset_descriptors",
        ["simulation_id"],
    )
    op.add_column(
        "generation_runs",
        sa.Column("world_plan_id", sa.String(64), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("generation_runs", "world_plan_id")
    op.drop_index(
        "ix_asset_descriptors_simulation", table_name="asset_descriptors"
    )
    op.drop_table("asset_descriptors")
    op.drop_index("ix_world_plans_hash", table_name="world_plans")
    op.drop_index("ix_world_plans_simulation", table_name="world_plans")
    op.drop_table("world_plans")
