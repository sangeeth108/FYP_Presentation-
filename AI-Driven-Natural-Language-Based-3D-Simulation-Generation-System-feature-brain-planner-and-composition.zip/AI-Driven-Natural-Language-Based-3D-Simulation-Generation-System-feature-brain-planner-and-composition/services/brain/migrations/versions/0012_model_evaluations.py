"""Signed model evaluation evidence.

Revision ID: 0012_model_evaluations
Revises: 0011_guardian_tenant_scope
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision: str = "0012_model_evaluations"
down_revision: str | None = "0011_guardian_tenant_scope"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "model_evaluations",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("model_version_id", sa.String(64), nullable=False),
        sa.Column("tenant_id", sa.String(64), nullable=True),
        sa.Column("evaluator", sa.String(80), nullable=False),
        sa.Column("evaluator_version", sa.String(64), nullable=False),
        sa.Column("benchmark_digest", sa.String(128), nullable=False),
        sa.Column("artifact_digest", sa.String(128), nullable=False),
        sa.Column("metrics", sa.JSON(), nullable=False),
        sa.Column("signature", sa.String(128), nullable=False),
        sa.Column("verified", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(
            ["model_version_id"], ["model_versions.id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
        sa.UniqueConstraint(
            "model_version_id",
            "artifact_digest",
            "benchmark_digest",
            name="uq_model_evaluation_artifact_benchmark",
        ),
    )
    op.create_index(
        "ix_model_evaluations_model_version_id",
        "model_evaluations",
        ["model_version_id"],
    )
    op.create_index(
        "ix_model_evaluations_tenant_id", "model_evaluations", ["tenant_id"]
    )
    if op.get_bind().dialect.name == "postgresql":
        expression = (
            "COALESCE(current_setting('app.worker_bypass', true), '') = 'on' "
            "OR COALESCE(current_setting('app.platform_admin', true), '') = 'on' "
            "OR tenant_id = NULLIF(current_setting('app.tenant_id', true), '')"
        )
        op.execute('ALTER TABLE "model_evaluations" ENABLE ROW LEVEL SECURITY')
        op.execute(
            'CREATE POLICY "serendib_tenant_model_evaluations" '
            'ON "model_evaluations" '
            f"USING ({expression}) WITH CHECK ({expression})"
        )


def downgrade() -> None:
    op.drop_index("ix_model_evaluations_tenant_id", table_name="model_evaluations")
    op.drop_index(
        "ix_model_evaluations_model_version_id", table_name="model_evaluations"
    )
    op.drop_table("model_evaluations")
