"""PostgreSQL tenant row-level security.

Revision ID: 0009_row_level_security
Revises: 0008_production_controls

SQLite remains the local/test database and does not support RLS. PostgreSQL
policies fail closed when no transaction-local API or worker identity is set.
"""

from __future__ import annotations

from alembic import op

revision: str = "0009_row_level_security"
down_revision: str | None = "0008_production_controls"
branch_labels = None
depends_on = None

_DIRECT_TENANT_TABLES = (
    "games",
    "jobs",
    "specs",
    "memberships",
    "tenant_quotas",
    "audit_events",
    "consent_records",
    "content_rights",
    "training_eligibility",
    "feedback_events",
    "usage_events",
    "data_subject_requests",
    "dataset_versions",
    "training_runs",
    "model_versions",
    "model_deployments",
    "security_incidents",
    "simulations",
    "simulation_specs",
    "generation_runs",
    "generation_leases",
    "world_plans",
    "asset_descriptors",
    "model_route_overrides",
)

_INDIRECT_POLICIES = {
    "age_assurance": """
        EXISTS (
            SELECT 1 FROM memberships m
            WHERE m.user_id = age_assurance.user_id
              AND m.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')
              AND m.status = 'active'
        )
    """,
    "guardian_relationships": """
        EXISTS (
            SELECT 1 FROM memberships m
            WHERE m.user_id IN (
                guardian_relationships.minor_user_id,
                guardian_relationships.guardian_user_id
            )
              AND m.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')
              AND m.status = 'active'
        )
    """,
    "dataset_items": """
        EXISTS (
            SELECT 1 FROM dataset_versions d
            WHERE d.id = dataset_items.dataset_version_id
              AND d.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')
        )
    """,
    "validation_evidence": """
        EXISTS (
            SELECT 1 FROM generation_runs r
            WHERE r.id = validation_evidence.run_id
              AND r.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')
        )
    """,
    "simulation_artifacts": """
        EXISTS (
            SELECT 1 FROM generation_runs r
            WHERE r.id = simulation_artifacts.run_id
              AND r.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')
        )
    """,
    "capability_gaps": """
        EXISTS (
            SELECT 1 FROM generation_runs r
            WHERE r.id = capability_gaps.run_id
              AND r.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')
        )
    """,
}

_BYPASS = """
    COALESCE(current_setting('app.worker_bypass', true), '') = 'on'
    OR COALESCE(current_setting('app.platform_admin', true), '') = 'on'
"""


def _postgresql() -> bool:
    return op.get_bind().dialect.name == "postgresql"


def _install_policy(table: str, expression: str) -> None:
    policy = f"serendib_tenant_{table}"
    op.execute(f'ALTER TABLE "{table}" ENABLE ROW LEVEL SECURITY')
    op.execute(
        f'CREATE POLICY "{policy}" ON "{table}" '
        f"USING ({_BYPASS} OR ({expression})) "
        f"WITH CHECK ({_BYPASS} OR ({expression}))"
    )


def upgrade() -> None:
    if not _postgresql():
        return

    _install_policy(
        "tenants",
        "id = NULLIF(current_setting('app.tenant_id', true), '')",
    )
    for table in _DIRECT_TENANT_TABLES:
        _install_policy(
            table,
            "tenant_id = NULLIF(current_setting('app.tenant_id', true), '')",
        )
    for table, expression in _INDIRECT_POLICIES.items():
        _install_policy(table, expression)


def downgrade() -> None:
    if not _postgresql():
        return
    for table in (
        "tenants",
        *_DIRECT_TENANT_TABLES,
        *_INDIRECT_POLICIES.keys(),
    ):
        policy = f"serendib_tenant_{table}"
        op.execute(f'DROP POLICY IF EXISTS "{policy}" ON "{table}"')
        op.execute(f'ALTER TABLE "{table}" DISABLE ROW LEVEL SECURITY')
