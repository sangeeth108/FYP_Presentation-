"""specs table — persist the frozen game_spec

Specified in docs/DATABASE_SCHEMA.md since P0 and never built. The pipeline
recorded only `spec_hash`, so the spec BODY lived solely inside each built
project's game_spec.json: recoverable, but not queryable, and gone with the
artifacts folder.

That is the P4 distillation set being discarded. Every job already emits exactly
the pair a fine-tune needs — `games.prompt` -> `specs.body` — and the validator
verdict on the job labels it, so the training data is a byproduct of ordinary use
rather than a labelling effort. It only accumulates if we keep it from now on:
a spec not stored today cannot be recovered later.

Revision ID: 0002_specs
Revises: 0001_initial
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision: str = "0002_specs"
down_revision: str | None = "0001_initial"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "specs",
        sa.Column("id", sa.String(64), primary_key=True),  # = job_id
        sa.Column(
            "game_id",
            sa.String(64),
            sa.ForeignKey("games.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "job_id",
            sa.String(64),
            sa.ForeignKey("jobs.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("schema_version", sa.String(16), nullable=False),
        # NOT unique: the same prompt+seed legitimately re-plans to an identical
        # spec on a rebuild, and a unique index would turn that into a crash.
        sa.Column("spec_hash", sa.String(64), nullable=False),
        sa.Column("brief_source", sa.String(16), nullable=False),  # llm | rules | edit
        sa.Column("planner_model", sa.String(120), nullable=True),
        sa.Column("body", sa.JSON(), nullable=False),
        sa.Column("frozen_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_specs_game_id", "specs", ["game_id"])
    op.create_index("ix_specs_job_id", "specs", ["job_id"])
    op.create_index("ix_specs_spec_hash", "specs", ["spec_hash"])
    # The distillation query is "every LLM-planned spec": index what it filters on.
    op.create_index("ix_specs_brief_source", "specs", ["brief_source"])


def downgrade() -> None:
    op.drop_index("ix_specs_brief_source", table_name="specs")
    op.drop_index("ix_specs_spec_hash", table_name="specs")
    op.drop_index("ix_specs_job_id", table_name="specs")
    op.drop_index("ix_specs_game_id", table_name="specs")
    op.drop_table("specs")
