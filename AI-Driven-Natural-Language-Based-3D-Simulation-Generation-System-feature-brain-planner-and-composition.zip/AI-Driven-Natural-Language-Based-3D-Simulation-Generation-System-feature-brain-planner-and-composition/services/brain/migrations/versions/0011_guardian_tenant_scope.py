"""Tenant-scope age assurance and guardian relationships.

Revision ID: 0011_guardian_tenant_scope
Revises: 0010_governed_datasets
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision: str = "0011_guardian_tenant_scope"
down_revision: str | None = "0010_governed_datasets"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("age_assurance") as batch:
        batch.add_column(
            sa.Column(
                "tenant_id",
                sa.String(64),
                nullable=False,
                server_default="tenant_dev",
            )
        )
        batch.create_foreign_key(
            "fk_age_assurance_tenant",
            "tenants",
            ["tenant_id"],
            ["id"],
            ondelete="CASCADE",
        )
        batch.create_index("ix_age_assurance_tenant_id", ["tenant_id"])
    with op.batch_alter_table("guardian_relationships") as batch:
        batch.drop_constraint("uq_guardian_relationship", type_="unique")
        batch.add_column(
            sa.Column(
                "tenant_id",
                sa.String(64),
                nullable=False,
                server_default="tenant_dev",
            )
        )
        batch.create_foreign_key(
            "fk_guardian_relationship_tenant",
            "tenants",
            ["tenant_id"],
            ["id"],
            ondelete="CASCADE",
        )
        batch.create_index("ix_guardian_relationships_tenant_id", ["tenant_id"])
        batch.create_unique_constraint(
            "uq_guardian_relationship",
            ["tenant_id", "minor_user_id", "guardian_user_id"],
        )
    if op.get_bind().dialect.name == "postgresql":
        for table in ("age_assurance", "guardian_relationships"):
            policy = f"serendib_tenant_{table}"
            op.execute(f'DROP POLICY IF EXISTS "{policy}" ON "{table}"')
            expression = (
                "COALESCE(current_setting('app.worker_bypass', true), '') = 'on' "
                "OR COALESCE(current_setting('app.platform_admin', true), '') = 'on' "
                "OR tenant_id = NULLIF(current_setting('app.tenant_id', true), '')"
            )
            op.execute(
                f'CREATE POLICY "{policy}" ON "{table}" '
                f"USING ({expression}) WITH CHECK ({expression})"
            )


def downgrade() -> None:
    with op.batch_alter_table("guardian_relationships") as batch:
        batch.drop_constraint("uq_guardian_relationship", type_="unique")
        batch.drop_index("ix_guardian_relationships_tenant_id")
        batch.drop_constraint(
            "fk_guardian_relationship_tenant", type_="foreignkey"
        )
        batch.drop_column("tenant_id")
        batch.create_unique_constraint(
            "uq_guardian_relationship",
            ["minor_user_id", "guardian_user_id"],
        )
    with op.batch_alter_table("age_assurance") as batch:
        batch.drop_index("ix_age_assurance_tenant_id")
        batch.drop_constraint("fk_age_assurance_tenant", type_="foreignkey")
        batch.drop_column("tenant_id")
