"""Production identity, tenancy, age assurance, guardianship, and audit.

Revision ID: 0004_identity_tenancy
Revises: 0003_training_safety
"""

from __future__ import annotations

from datetime import UTC, datetime

import sqlalchemy as sa
from alembic import op

revision: str = "0004_identity_tenancy"
down_revision: str | None = "0003_training_safety"
branch_labels = None
depends_on = None

DEV_TENANT = "tenant_dev"
DEV_USER = "user_dev"


def upgrade() -> None:
    op.create_table(
        "tenants",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("name", sa.String(160), nullable=False),
        sa.Column("slug", sa.String(80), nullable=False, unique=True),
        sa.Column("residency_region", sa.String(32), nullable=False),
        sa.Column("training_policy", sa.String(32), nullable=False),
        sa.Column("status", sa.String(24), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "users",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("subject", sa.String(255), nullable=False, unique=True),
        sa.Column("email_hash", sa.String(64), nullable=True),
        sa.Column("age_band", sa.String(16), nullable=False),
        sa.Column("status", sa.String(24), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_table(
        "memberships",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("tenant_id", sa.String(64), nullable=False),
        sa.Column("user_id", sa.String(64), nullable=False),
        sa.Column("role", sa.String(32), nullable=False),
        sa.Column("status", sa.String(24), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
        sa.UniqueConstraint("tenant_id", "user_id", "role", name="uq_membership_role"),
    )
    op.create_table(
        "age_assurance",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("user_id", sa.String(64), nullable=False),
        sa.Column("age_band", sa.String(16), nullable=False),
        sa.Column("provider", sa.String(80), nullable=False),
        sa.Column("evidence_ref", sa.String(255), nullable=False),
        sa.Column("verified_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
    )
    op.create_table(
        "guardian_relationships",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("minor_user_id", sa.String(64), nullable=False),
        sa.Column("guardian_user_id", sa.String(64), nullable=False),
        sa.Column("status", sa.String(24), nullable=False),
        sa.Column("verification_ref", sa.String(255), nullable=True),
        sa.Column("verified_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("revoked_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["minor_user_id"], ["users.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["guardian_user_id"], ["users.id"], ondelete="CASCADE"),
        sa.UniqueConstraint(
            "minor_user_id", "guardian_user_id", name="uq_guardian_relationship"
        ),
    )
    op.create_table(
        "audit_events",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("tenant_id", sa.String(64), nullable=True),
        sa.Column("actor_user_id", sa.String(64), nullable=True),
        sa.Column("action", sa.String(120), nullable=False),
        sa.Column("resource_type", sa.String(64), nullable=False),
        sa.Column("resource_id", sa.String(128), nullable=True),
        sa.Column("detail", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="SET NULL"),
        sa.ForeignKeyConstraint(["actor_user_id"], ["users.id"], ondelete="SET NULL"),
    )
    op.create_index("ix_audit_events_tenant_id", "audit_events", ["tenant_id"])
    op.create_index("ix_audit_events_action", "audit_events", ["action"])

    tenants = sa.table(
        "tenants",
        sa.column("id", sa.String),
        sa.column("name", sa.String),
        sa.column("slug", sa.String),
        sa.column("residency_region", sa.String),
        sa.column("training_policy", sa.String),
        sa.column("status", sa.String),
        sa.column("created_at", sa.DateTime(timezone=True)),
    )
    users = sa.table(
        "users",
        sa.column("id", sa.String),
        sa.column("subject", sa.String),
        sa.column("email_hash", sa.String),
        sa.column("age_band", sa.String),
        sa.column("status", sa.String),
        sa.column("created_at", sa.DateTime(timezone=True)),
        sa.column("updated_at", sa.DateTime(timezone=True)),
    )
    memberships = sa.table(
        "memberships",
        sa.column("id", sa.String),
        sa.column("tenant_id", sa.String),
        sa.column("user_id", sa.String),
        sa.column("role", sa.String),
        sa.column("status", sa.String),
        sa.column("created_at", sa.DateTime(timezone=True)),
    )
    now = datetime.now(UTC)
    op.bulk_insert(
        tenants,
        [
            {
                "id": DEV_TENANT,
                "name": "Development tenant",
                "slug": "development",
                "residency_region": "local",
                "training_policy": "disabled",
                "status": "active",
                "created_at": now,
            }
        ],
    )
    op.bulk_insert(
        users,
        [
            {
                "id": DEV_USER,
                "subject": "development",
                "email_hash": None,
                "age_band": "adult",
                "status": "active",
                "created_at": now,
                "updated_at": now,
            }
        ],
    )
    op.bulk_insert(
        memberships,
        [
            {
                "id": "membership_dev_owner",
                "tenant_id": DEV_TENANT,
                "user_id": DEV_USER,
                "role": "platform_admin",
                "status": "active",
                "created_at": now,
            }
        ],
    )

    for table in ("games", "jobs", "specs"):
        with op.batch_alter_table(table) as batch:
            batch.add_column(
                sa.Column(
                    "tenant_id",
                    sa.String(64),
                    nullable=False,
                    server_default=DEV_TENANT,
                )
            )
            batch.add_column(
                sa.Column(
                    "owner_id",
                    sa.String(64),
                    nullable=False,
                    server_default=DEV_USER,
                )
            )
            batch.add_column(
                sa.Column(
                    "residency_region",
                    sa.String(32),
                    nullable=False,
                    server_default="local",
                )
            )
            batch.add_column(
                sa.Column(
                    "retention_class",
                    sa.String(32),
                    nullable=False,
                    server_default="development",
                )
            )
            batch.create_index(f"ix_{table}_tenant_id", ["tenant_id"])
            batch.create_foreign_key(
                f"fk_{table}_tenant_id",
                "tenants",
                ["tenant_id"],
                ["id"],
                ondelete="RESTRICT",
            )
            batch.create_foreign_key(
                f"fk_{table}_owner_id",
                "users",
                ["owner_id"],
                ["id"],
                ondelete="RESTRICT",
            )


def downgrade() -> None:
    for table in ("specs", "jobs", "games"):
        with op.batch_alter_table(table) as batch:
            batch.drop_constraint(f"fk_{table}_owner_id", type_="foreignkey")
            batch.drop_constraint(f"fk_{table}_tenant_id", type_="foreignkey")
            batch.drop_index(f"ix_{table}_tenant_id")
            batch.drop_column("retention_class")
            batch.drop_column("residency_region")
            batch.drop_column("owner_id")
            batch.drop_column("tenant_id")
    op.drop_index("ix_audit_events_action", table_name="audit_events")
    op.drop_index("ix_audit_events_tenant_id", table_name="audit_events")
    op.drop_table("audit_events")
    op.drop_table("guardian_relationships")
    op.drop_table("age_assurance")
    op.drop_table("memberships")
    op.drop_table("users")
    op.drop_table("tenants")
