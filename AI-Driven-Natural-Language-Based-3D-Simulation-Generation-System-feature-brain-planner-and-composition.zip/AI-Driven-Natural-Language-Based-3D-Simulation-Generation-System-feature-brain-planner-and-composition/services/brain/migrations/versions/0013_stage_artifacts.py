"""Per-stage pipeline artifacts, so a run can be inspected step by step.

Revision ID: 0013_stage_artifacts
Revises: 0012_model_evaluations
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision: str = "0013_stage_artifacts"
down_revision: str | None = "0012_model_evaluations"
branch_labels: str | None = None
depends_on: str | None = None


def upgrade() -> None:
    op.create_table(
        "stage_artifacts",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column(
            "run_id",
            sa.String(length=64),
            sa.ForeignKey("generation_runs.id", ondelete="CASCADE"),
            nullable=False,
            index=True,
        ),
        sa.Column("stage", sa.String(length=48), nullable=False),
        sa.Column("ordinal", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("status", sa.String(length=16), nullable=False, server_default="PENDING"),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("summary", sa.JSON(), nullable=False),
        sa.Column("errors", sa.JSON(), nullable=False),
        sa.Column("model_id", sa.String(length=160), nullable=True),
        sa.Column("duration_ms", sa.Integer(), nullable=True),
        sa.Column("edited", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            nullable=False,
            server_default=sa.func.now(),
        ),
        # One row per stage per run: re-running a stage updates it in place, so the
        # inspector always shows the current truth for that step.
        sa.UniqueConstraint("run_id", "stage", name="uq_stage_artifact_run_stage"),
    )


def downgrade() -> None:
    op.drop_table("stage_artifacts")
