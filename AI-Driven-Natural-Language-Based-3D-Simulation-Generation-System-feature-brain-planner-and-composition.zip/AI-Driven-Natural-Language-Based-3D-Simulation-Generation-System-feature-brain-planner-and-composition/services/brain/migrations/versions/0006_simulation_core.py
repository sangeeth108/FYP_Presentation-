"""Neutral simulations, versioned specs, generation runs, and evidence.

Revision ID: 0006_simulation_core
Revises: 0005_learning_governance
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision: str = "0006_simulation_core"
down_revision: str | None = "0005_learning_governance"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "simulations",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("tenant_id", sa.String(64), nullable=False),
        sa.Column("owner_id", sa.String(64), nullable=False),
        sa.Column("title", sa.String(120), nullable=False),
        sa.Column("prompt", sa.String(4000), nullable=False),
        sa.Column("size_profile", sa.String(16), nullable=False),
        sa.Column("target_platforms", sa.JSON(), nullable=False),
        sa.Column("seed", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(32), nullable=False),
        sa.Column("current_spec_id", sa.String(64), nullable=True),
        sa.Column("current_run_id", sa.String(64), nullable=True),
        sa.Column("residency_region", sa.String(32), nullable=False),
        sa.Column("retention_class", sa.String(32), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["owner_id"], ["users.id"], ondelete="RESTRICT"),
    )
    op.create_index("ix_simulations_tenant_id", "simulations", ["tenant_id"])
    op.create_table(
        "simulation_specs",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("simulation_id", sa.String(64), nullable=False),
        sa.Column("tenant_id", sa.String(64), nullable=False),
        sa.Column("owner_id", sa.String(64), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("schema_version", sa.String(16), nullable=False),
        sa.Column("spec_hash", sa.String(64), nullable=False),
        sa.Column("source", sa.String(32), nullable=False),
        sa.Column("planner_model", sa.String(160), nullable=True),
        sa.Column("body", sa.JSON(), nullable=False),
        sa.Column("data_source", sa.String(32), nullable=False),
        sa.Column("training_eligible", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(
            ["simulation_id"], ["simulations.id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["owner_id"], ["users.id"], ondelete="RESTRICT"),
        sa.UniqueConstraint(
            "simulation_id", "version", name="uq_simulation_spec_version"
        ),
    )
    op.create_index("ix_simulation_specs_hash", "simulation_specs", ["spec_hash"])
    op.create_table(
        "generation_runs",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("simulation_id", sa.String(64), nullable=False),
        sa.Column("spec_id", sa.String(64), nullable=True),
        sa.Column("tenant_id", sa.String(64), nullable=False),
        sa.Column("owner_id", sa.String(64), nullable=False),
        sa.Column("state", sa.String(32), nullable=False),
        sa.Column("stage", sa.String(32), nullable=False),
        sa.Column("detail", sa.JSON(), nullable=False),
        sa.Column("model_routes", sa.JSON(), nullable=False),
        sa.Column("repair_attempts", sa.Integer(), nullable=False),
        sa.Column("max_repair_attempts", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(
            ["simulation_id"], ["simulations.id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(["spec_id"], ["simulation_specs.id"], ondelete="SET NULL"),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["owner_id"], ["users.id"], ondelete="RESTRICT"),
    )
    op.create_index(
        "ix_generation_runs_tenant_state",
        "generation_runs",
        ["tenant_id", "state"],
    )
    op.create_table(
        "validation_evidence",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("run_id", sa.String(64), nullable=False),
        sa.Column("layer", sa.String(48), nullable=False),
        sa.Column("status", sa.String(16), nullable=False),
        sa.Column("mandatory", sa.Boolean(), nullable=False),
        sa.Column("validator", sa.String(80), nullable=False),
        sa.Column("validator_version", sa.String(32), nullable=False),
        sa.Column("requirement_ids", sa.JSON(), nullable=False),
        sa.Column("evidence", sa.JSON(), nullable=False),
        sa.Column("errors", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["run_id"], ["generation_runs.id"], ondelete="CASCADE"),
    )
    op.create_index(
        "ix_validation_evidence_run_layer",
        "validation_evidence",
        ["run_id", "layer"],
    )
    op.create_table(
        "simulation_artifacts",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("run_id", sa.String(64), nullable=False),
        sa.Column("kind", sa.String(32), nullable=False),
        sa.Column("platform", sa.String(16), nullable=True),
        sa.Column("uri", sa.String(1024), nullable=False),
        sa.Column("content_hash", sa.String(128), nullable=True),
        sa.Column("bytes", sa.Integer(), nullable=True),
        sa.Column("ai_generated", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["run_id"], ["generation_runs.id"], ondelete="CASCADE"),
    )
    op.create_table(
        "capability_gaps",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("simulation_id", sa.String(64), nullable=False),
        sa.Column("run_id", sa.String(64), nullable=False),
        sa.Column("requirement_id", sa.String(80), nullable=True),
        sa.Column("capability_id", sa.String(80), nullable=False),
        sa.Column("status", sa.String(24), nullable=False),
        sa.Column("detail", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(
            ["simulation_id"], ["simulations.id"], ondelete="CASCADE"
        ),
        sa.ForeignKeyConstraint(["run_id"], ["generation_runs.id"], ondelete="CASCADE"),
    )


def downgrade() -> None:
    op.drop_table("capability_gaps")
    op.drop_table("simulation_artifacts")
    op.drop_index(
        "ix_validation_evidence_run_layer", table_name="validation_evidence"
    )
    op.drop_table("validation_evidence")
    op.drop_index(
        "ix_generation_runs_tenant_state", table_name="generation_runs"
    )
    op.drop_table("generation_runs")
    op.drop_index("ix_simulation_specs_hash", table_name="simulation_specs")
    op.drop_table("simulation_specs")
    op.drop_index("ix_simulations_tenant_id", table_name="simulations")
    op.drop_table("simulations")
