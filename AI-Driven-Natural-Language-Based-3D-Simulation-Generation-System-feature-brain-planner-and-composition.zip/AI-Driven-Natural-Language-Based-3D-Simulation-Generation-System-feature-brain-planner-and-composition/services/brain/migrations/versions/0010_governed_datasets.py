"""Governed dataset snapshots, tombstones, and research exclusions.

Revision ID: 0010_governed_datasets
Revises: 0009_row_level_security
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision: str = "0010_governed_datasets"
down_revision: str | None = "0009_row_level_security"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("training_eligibility") as batch:
        batch.add_column(
            sa.Column(
                "data_category",
                sa.String(32),
                nullable=False,
                server_default="prompt_spec",
            )
        )
    with op.batch_alter_table("dataset_versions") as batch:
        batch.add_column(
            sa.Column("target", sa.String(32), nullable=False, server_default="planner")
        )
        batch.add_column(
            sa.Column(
                "split_policy_version",
                sa.String(32),
                nullable=False,
                server_default="strict-v1",
            )
        )
    with op.batch_alter_table("dataset_items") as batch:
        batch.add_column(sa.Column("tenant_id", sa.String(64), nullable=True))
        batch.add_column(sa.Column("target", sa.String(32), nullable=False))
        batch.add_column(sa.Column("owner_pseudonym", sa.String(64), nullable=False))
        batch.add_column(sa.Column("prompt_family_hash", sa.String(64), nullable=False))
        batch.add_column(sa.Column("time_bucket", sa.String(16), nullable=False))
        batch.add_column(sa.Column("consent_snapshot", sa.JSON(), nullable=False))
        batch.add_column(sa.Column("rights_snapshot", sa.JSON(), nullable=False))
        batch.add_column(sa.Column("sanitized_payload", sa.JSON(), nullable=False))
        batch.add_column(
            sa.Column("source_created_at", sa.DateTime(timezone=True), nullable=False)
        )
        batch.create_foreign_key(
            "fk_dataset_items_tenant_id", "tenants", ["tenant_id"], ["id"], ondelete="CASCADE"
        )
        batch.create_index("ix_dataset_items_tenant_id", ["tenant_id"])
        batch.create_index("ix_dataset_items_owner_pseudonym", ["owner_pseudonym"])
        batch.create_index("ix_dataset_items_prompt_family_hash", ["prompt_family_hash"])
        batch.create_index("ix_dataset_items_time_bucket", ["time_bucket"])
    with op.batch_alter_table("training_runs") as batch:
        batch.add_column(sa.Column("approved_by", sa.String(64), nullable=True))
        batch.add_column(
            sa.Column("approved_at", sa.DateTime(timezone=True), nullable=True)
        )
        batch.create_foreign_key(
            "fk_training_runs_approved_by",
            "users",
            ["approved_by"],
            ["id"],
            ondelete="RESTRICT",
        )

    op.create_table(
        "deletion_tombstones",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("tenant_id", sa.String(64), nullable=False),
        sa.Column("owner_id", sa.String(64), nullable=False),
        sa.Column("resource_type", sa.String(48), nullable=False),
        sa.Column("resource_id", sa.String(128), nullable=False),
        sa.Column("content_hash", sa.String(64), nullable=True),
        sa.Column("reason", sa.String(64), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["tenant_id"], ["tenants.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["owner_id"], ["users.id"], ondelete="CASCADE"),
        sa.UniqueConstraint(
            "tenant_id",
            "resource_type",
            "resource_id",
            name="uq_deletion_tombstone_resource",
        ),
    )
    op.create_index(
        "ix_deletion_tombstones_tenant_id", "deletion_tombstones", ["tenant_id"]
    )
    op.create_index(
        "ix_deletion_tombstones_owner_id", "deletion_tombstones", ["owner_id"]
    )
    op.create_table(
        "research_exclusions",
        sa.Column("id", sa.String(64), primary_key=True),
        sa.Column("fingerprint", sa.String(64), nullable=False, unique=True),
        sa.Column("exclusion_type", sa.String(32), nullable=False),
        sa.Column("purpose", sa.String(120), nullable=False),
        sa.Column("study_id", sa.String(80), nullable=True),
        sa.Column("active", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index(
        "ix_research_exclusions_fingerprint",
        "research_exclusions",
        ["fingerprint"],
        unique=True,
    )

    if op.get_bind().dialect.name == "postgresql":
        # Replace the pre-column indirect policy from revision 0009. This lets a
        # tenant remove its own contribution from a global dataset without
        # granting access to the global dataset-version/model rows.
        op.execute(
            'DROP POLICY IF EXISTS "serendib_tenant_dataset_items" '
            'ON "dataset_items"'
        )
        dataset_item_expression = (
            "COALESCE(current_setting('app.worker_bypass', true), '') = 'on' "
            "OR COALESCE(current_setting('app.platform_admin', true), '') = 'on' "
            "OR tenant_id = NULLIF(current_setting('app.tenant_id', true), '')"
        )
        op.execute(
            'CREATE POLICY "serendib_tenant_dataset_items" ON "dataset_items" '
            f"USING ({dataset_item_expression}) "
            f"WITH CHECK ({dataset_item_expression})"
        )
        for table in ("deletion_tombstones",):
            policy = f"serendib_tenant_{table}"
            expression = (
                "COALESCE(current_setting('app.worker_bypass', true), '') = 'on' "
                "OR COALESCE(current_setting('app.platform_admin', true), '') = 'on' "
                "OR tenant_id = NULLIF(current_setting('app.tenant_id', true), '')"
            )
            op.execute(f'ALTER TABLE "{table}" ENABLE ROW LEVEL SECURITY')
            op.execute(
                f'CREATE POLICY "{policy}" ON "{table}" '
                f"USING ({expression}) WITH CHECK ({expression})"
            )
        op.execute('ALTER TABLE "research_exclusions" ENABLE ROW LEVEL SECURITY')
        op.execute(
            'CREATE POLICY "serendib_research_exclusions" ON "research_exclusions" '
            "USING ("
            "COALESCE(current_setting('app.worker_bypass', true), '') = 'on' OR "
            "COALESCE(current_setting('app.platform_admin', true), '') = 'on'"
            ") WITH CHECK ("
            "COALESCE(current_setting('app.worker_bypass', true), '') = 'on' OR "
            "COALESCE(current_setting('app.platform_admin', true), '') = 'on'"
            ")"
        )


def downgrade() -> None:
    if op.get_bind().dialect.name == "postgresql":
        op.execute(
            'DROP POLICY IF EXISTS "serendib_research_exclusions" '
            'ON "research_exclusions"'
        )
        op.execute(
            'DROP POLICY IF EXISTS "serendib_tenant_deletion_tombstones" '
            'ON "deletion_tombstones"'
        )
    op.drop_table("research_exclusions")
    op.drop_index(
        "ix_deletion_tombstones_owner_id", table_name="deletion_tombstones"
    )
    op.drop_index(
        "ix_deletion_tombstones_tenant_id", table_name="deletion_tombstones"
    )
    op.drop_table("deletion_tombstones")
    with op.batch_alter_table("training_runs") as batch:
        batch.drop_constraint("fk_training_runs_approved_by", type_="foreignkey")
        batch.drop_column("approved_at")
        batch.drop_column("approved_by")
    with op.batch_alter_table("dataset_items") as batch:
        batch.drop_index("ix_dataset_items_time_bucket")
        batch.drop_index("ix_dataset_items_prompt_family_hash")
        batch.drop_index("ix_dataset_items_owner_pseudonym")
        batch.drop_index("ix_dataset_items_tenant_id")
        batch.drop_constraint("fk_dataset_items_tenant_id", type_="foreignkey")
        for column in (
            "source_created_at",
            "sanitized_payload",
            "rights_snapshot",
            "consent_snapshot",
            "time_bucket",
            "prompt_family_hash",
            "owner_pseudonym",
            "target",
            "tenant_id",
        ):
            batch.drop_column(column)
    with op.batch_alter_table("dataset_versions") as batch:
        batch.drop_column("split_policy_version")
        batch.drop_column("target")
    with op.batch_alter_table("training_eligibility") as batch:
        batch.drop_column("data_category")
