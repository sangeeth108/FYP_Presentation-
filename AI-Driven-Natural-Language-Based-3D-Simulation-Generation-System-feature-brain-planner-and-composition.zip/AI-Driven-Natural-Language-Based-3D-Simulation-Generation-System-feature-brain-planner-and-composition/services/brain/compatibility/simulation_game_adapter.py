"""Compile a neutral SimulationSpec into the existing deterministic runtime.

This adapter is transitional. It never changes the canonical neutral spec and
records limitations for capabilities the legacy runtime cannot yet express.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path

import jsonschema

_REPO = Path(__file__).resolve().parents[3]
_BASE = json.loads(
    (_REPO / "contracts" / "examples" / "golden_game.spec.json").read_text(
        encoding="utf-8"
    )
)
_GAME_SCHEMA = json.loads(
    (_REPO / "contracts" / "game_spec.schema.json").read_text(encoding="utf-8")
)


def _asset_brief(entity: dict) -> dict:
    category = entity["asset"]["category"]
    legacy_category = "character" if category == "character" else "prop"
    return {
        "brief": entity["asset"]["brief"][:300],
        "category": legacy_category,
        "tri_budget": 8000 if legacy_category == "character" else 5000,
    }


def compile_to_legacy_game(
    simulation_spec: dict,
    game_id: str,
) -> tuple[dict, list[dict]]:
    spec = copy.deepcopy(_BASE)
    prompt = simulation_spec["request"]["prompt"]
    entities = simulation_spec["entities"]
    controlled = next(
        (entity for entity in entities if entity["role"] == "controlled_agent"),
        entities[0],
    )
    approximations: list[dict] = []

    spec["meta"]["game_id"] = game_id
    spec["meta"]["title"] = simulation_spec["meta"]["title"][:80]
    spec["meta"]["seed"] = simulation_spec["meta"]["seed"]
    spec["meta"]["genre"] = "collect_explore_3d"
    spec["meta"]["camera"] = "third_person"
    _env_type = simulation_spec["environment"]["semantic_type"]
    spec["meta"]["mood"] = f"Executable simulation of {_env_type}"
    spec["meta"]["style_anchor"] = "cohesive realistic low-poly simulation visualization"
    spec["world"]["kind"] = simulation_spec["environment"]["world_kind"]
    if spec["world"]["kind"] == "mixed":
        spec["world"]["kind"] = "outdoor"
    spec["world"]["zone_graph"]["algorithm"] = "room_corridor"
    spec["world"]["zone_graph"]["zone_count"] = (
        8 if simulation_spec["request"]["size_profile"] == "small" else 14
    )
    spec["world"]["zone_graph"]["verticality_tiers"] = 1
    spec["world"]["lighting_preset_id"] = (
        "moonlit_night"
        if simulation_spec["environment"]["time_of_day"] == "night"
        else "overcast_day"
    )
    spec["player"]["controller_template_id"] = "controller_third_person"
    spec["player"]["asset_brief"] = _asset_brief(controlled)
    spec["player"]["verbs"] = ["move", "sprint", "interact"]
    spec["entities"]["enemies"] = []

    props: list[dict] = []
    objects: list[dict] = []
    for entity in entities:
        if entity["entity_id"] == controlled["entity_id"]:
            continue
        semantic = entity["semantic_type"]
        caps = set(entity["capabilities"])
        bbox = [min(15.0, max(0.5, float(v))) for v in entity["physical"]["bbox_m"]]
        archetype = None
        if semantic in {"house", "industrial_building", "building"}:
            archetype = "building"
        elif "vehicle" in caps:
            archetype = "vehicle"
        elif semantic in {"chest", "cabinet", "gate"}:
            archetype = semantic
        if archetype and len(objects) < 8:
            objects.append(
                {
                    "object_id": entity["entity_id"][4:],
                    "archetype": archetype,
                    "bbox": bbox,
                    "brief": entity["asset"]["brief"][:200],
                    "placement_tags": [entity["placement"]["zone"]],
                }
            )
            continue

        prop = {
            "prop_id": entity["entity_id"][4:],
            "asset_brief": _asset_brief(entity),
            "placement_tags": [entity["placement"]["zone"]],
        }
        if "openable" in caps:
            prop["interactable_template_id"] = "door_hinged"
        elif "pickup_carry_drop" in caps:
            prop["interactable_template_id"] = "pickup_supply"
        elif "machine" in caps:
            prop["interactable_template_id"] = "lever_switch"
        props.append(prop)
        unsupported = caps - {
            "openable",
            "pickup_carry_drop",
            "machine",
            "locomotion",
        }
        if unsupported:
            approximations.append(
                {
                    "entity_id": entity["entity_id"],
                    "capabilities": sorted(unsupported),
                    "reason": "legacy runtime adapter cannot yet express these capabilities",
                }
            )

    spec["entities"]["props"] = props[:200]
    if objects:
        spec["entities"]["objects"] = objects
    else:
        spec["entities"].pop("objects", None)
    spec["budgets"]["max_props"] = max(50, len(props))
    spec["lineage"] = {
        "prompt": prompt,
        "seeds": {"simulation": simulation_spec["meta"]["seed"]},
        "model_digests": {
            "simulation_planner": simulation_spec["lineage"]["planner"]
        },
        "build_hash": "pending",
        "created_at": simulation_spec["lineage"]["created_at"],
    }
    jsonschema.validate(spec, _GAME_SCHEMA)
    return spec, approximations
