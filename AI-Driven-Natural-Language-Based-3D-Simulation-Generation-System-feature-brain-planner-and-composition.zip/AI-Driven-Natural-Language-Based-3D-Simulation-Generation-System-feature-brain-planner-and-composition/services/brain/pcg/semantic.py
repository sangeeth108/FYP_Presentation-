"""Seeded, bounds-aware semantic placement for neutral simulations.

Hard constraints are never relaxed. A failed placement is retained as an
explicit unplaced entity and makes validation fail. Soft preferences can be
relaxed, but every relaxation is recorded in the WorldPlan.
"""

from __future__ import annotations

import json
import math
import re
import random
from functools import lru_cache
from pathlib import Path
from typing import Any

import jsonschema

from pcg.regions import paint_regions
from verification.contracts import required_entity_ids
from pcg.routes import allocate_frontage, corridor_between
from pcg.scatter import instance_scatter
from pcg.terrain import build_terrain, terrain_from_payload

_REPO = Path(__file__).resolve().parents[3]
_SCHEMA = _REPO / "contracts" / "world_plan.schema.json"
_ATTEMPTS = 512
_WORLD_MARGIN_M = 5.0
# Room to walk around and between the content without it becoming a search task.
_CONTENT_SPREAD = 4.0
_MIN_WORLD_SIDE_M = 40.0
# Room placement keeps free around each object. Used when sizing a world so the
# extent reflects the space placement will actually demand, not just the sum of
# the footprints.
_PLACEMENT_CLEARANCE_M = 1.5
# How much wider than the bare content a world must be for seeded random
# placement to reliably find room for all of it. See `_content_scaled_dimensions`.
# Lowering this to 2.0 was tried on measurement and REVERTED, which is worth recording
# because the aggregate said it was free:
#
#   allowance   mean fill   mean world side   unplaced (30 specs)
#   2.4         0.399       36.3 m            12
#   2.0         0.417       35.6 m            11
#   1.8         0.399       35.2 m            13
#
# 2.0 looked like a local optimum -- better fill AND fewer unplaced than either
# neighbour. It still broke `test_an_explicit_hard_adjacency_survives_a_rotated_neighbour`:
# a stoop required to sit against its own door could no longer fit, because a hard
# adjacency needs slack that an average over thirty worlds does not see. A mean improving
# while a specific stated guarantee fails is exactly the trade this constant must not
# make, and a 4% aggregate gain does not buy a tested invariant.
#
# Note also that the DECLARED extent cannot be used to tighten a world:
# `_content_scaled_dimensions` recomputes it from content x this allowance, so shrinking
# `dimensions_m` is inert -- measured. This constant is the only lever on world size, and
# it is bounded below by adjacency, not by the fill ratio.
_PACKING_ALLOWANCE = 2.4
# The fraction of the zone the FIRST placement attempt may use. Later
# attempts widen to the whole zone, so this tightens composition without
# costing feasibility. See `_free_point`.
_MIN_SPREAD = 0.34


# The largest share of the ground scatter is allowed to claim when sizing the
# world. Beyond this the entities would have nowhere left to sit, and a world
# that is 95% vegetation by area cannot also hold a building.
_MAX_SCATTER_SHARE = 0.6
# Scatter shorter than this is stepped over rather than walked around, so it takes no
# share of the ground when the world is sized. Same number as the planner's
# `small_extent_m`, which already calls this "ground detail rather than an object".
#
# Measured on the rendered village of run_fc7e6f68fcd9448287dcb5bd94f7b057: 0.6 x 0.05 x
# 0.4 m paving slabs at 300 per 100 m2 demanded 0.72 of the ground on their own, pinning
# the clamp and making the world 2.5x larger than its entities needed -- 72.6 x 90.7 m
# holding 23.9 x 16.9 m of content, with 800 pebbles spread across the empty remainder.
# Across 48 stored specs, 25 were pinned at the clamp this way; gating on height leaves 5,
# which are the cases the rule is actually for -- the 8 m canopy trees of the tea
# plantation in `_scatter_headroom` genuinely do compete.
_STEPPABLE_HEIGHT_M = 0.25


# Enough of a species to read as that species rather than as one of them. Matches
# `_ENOUGH_TO_READ` in the planner, which sizes the declared world by the same question.
_ENOUGH_TO_READ = 8


# Half-width at which a scattered thing stops being detail and starts being structure.
# A tree crown, a boulder, a market stall. Below this a species can always be packed into
# whatever ground there is, so it never has an opinion about how big the world should be.
_STRUCTURAL_RADIUS_M = 1.5

# The most a scatter floor may give back, as a multiple of the trimmed AREA. The forest
# this exists for needs 1.02x; anything asking for many times its own world is describing
# something the spec got wrong rather than ground it needs.
_MOST_GROUND_A_TRIM_GIVES_BACK = 2.0

# What seeded rejection sampling actually achieves against ideal square packing. Measured
# on two forest runs at the same 11.3 m crown spacing:
#
#     999 m2 -> 4 trees   (4 x 127.7 / 999  = 51%)
#    1586 m2 -> 6 trees   (6 x 127.7 / 1586 = 48%)
#
# Dart-throwing stops when rejections pile up, long before the ground is full. Asking for
# ground as if packing were perfect asks for half what is needed, which is why the first
# two attempts at this floor both came back short.
_DART_THROWING_YIELD = 0.5


def _ground_the_scatter_needs(spec: dict, descriptors: dict | None = None) -> float:
    """Square metres the STRUCTURAL scatter needs to physically stand in.

    Only species too big to pack into any leftover ground get a say, and only by their
    measured footprint. Both halves of that sentence were paid for:

    Taking the largest need over ALL species asked a classroom corner to grow from
    64 m2 to 800 m2, because one species declared at 0.5 per 100 m2 -- deliberately
    sparse -- "needed" 1,600 m2 to show eight of itself. Measured across the 82 stored
    specs carrying scatter, that floor bound on 56 of them (68%), which would have undone
    the trim wholesale and put small worlds back on the empty slabs it exists to prevent.

    Sizing by `density_per_100m2` was wrong in the other direction: density claimed eight
    trees fit in 300 m2, while an 11.3 m crown needs about 1,021 m2 for eight. Density
    says nothing about whether the things can physically stand there, which is precisely
    what "packing_limit" means.

    So: measured footprint, structural species only. The radius comes from
    `_footprint_radius`, the same function the sampler uses to choose spacing, so this
    cannot disagree with the packing that actually happens.
    """
    from pcg.scatter import _footprint_radius

    needed = 0.0
    for species in spec.get("scatter") or ():
        if not isinstance(species, dict):
            continue
        try:
            if float(species.get("density_per_100m2") or 0.0) <= 0.0:
                continue
        except (TypeError, ValueError):
            continue

        wanted = _ENOUGH_TO_READ
        cap = species.get("max_instances")
        if isinstance(cap, int) and cap > 0:
            wanted = min(wanted, cap)  # a species capped to be rare asks for nothing

        try:
            radius, _ = _footprint_radius(species, descriptors or {})
            radius = float(radius)
        except Exception:  # noqa: BLE001 - a sizing hint must not cost a world
            continue
        if radius < _STRUCTURAL_RADIUS_M:
            continue  # detail packs into whatever ground there is
        needed = max(needed, wanted * (2.0 * radius) ** 2 / _DART_THROWING_YIELD)
    return needed


def _scatter_headroom(spec: dict) -> float:
    """The fraction of the ground left for entities once scatter has its share.

    Scatter and entities compete for the same ground, but the extent was derived
    from entity footprints alone. Measured on a live run: a tea plantation
    declared four entities totalling ~116 m2 and was sized to 34.7 x 25.5 m. The
    same specification asked for seven scatter species including two 8 m canopy
    trees; with the shed and machinery in the middle and the trees' `avoid_tags`
    keeping them clear of buildings, BOTH tree species placed zero instances.
    The planner had correctly asked for the visual landmarks of a plantation and
    the sizing threw them away.

    Density is per unit area, so scatter's demand is a FRACTION of the ground
    rather than an absolute area -- which is what makes this non-circular. If
    scatter wants 40% of the ground, entities must fit in the remaining 60%, so
    the world has to be 1/0.6 times larger than entities alone would need.

    The fraction is clamped rather than trusted. A planner can and does request
    coverage exceeding 100% (that same run asked for 518% in total), which no
    world size can satisfy because the excess scales with the world. Sizing
    absorbs what it can; the sampler thins the remainder and reports it.
    """
    demanded = 0.0
    for species in spec.get("scatter") or ():
        size = species.get("size_m")
        if not size or len(size) < 3:
            continue
        try:
            density = float(species.get("density_per_100m2") or 0.0)
            footprint = float(size[0]) * float(size[2])
            height = float(size[1])
        except (TypeError, ValueError):
            continue
        if density <= 0.0 or footprint <= 0.0:
            continue
        if height <= _STEPPABLE_HEIGHT_M:
            # Ground detail does not compete for the ground: a house sits on top of a
            # paving slab and a dog walks over a pebble. Only things tall enough to
            # actually stand in the way take a share.
            continue
        demanded += density * footprint / 100.0
    return 1.0 - min(demanded, _MAX_SCATTER_SHARE)


def content_scaled_dimensions(spec: dict) -> tuple[float, float, float]:
    """The extent this spec's contents actually need, as (width, depth, max_height).

    Public because the PLANNER needs the same number: it writes `dimensions_m` from this
    so the declaration is honest before anything reads it, which is what lets terrain go
    on reading the raw declaration. One authority for one fact -- the alternative was
    terrain deriving its own extent, and that made the heightfield move whenever content
    did (see docs/VILLAGE_GAP_ANALYSIS.md §5).

    Idempotent: the body caps at `preferred` and then grows to fit, so feeding a spec
    whose declaration is already this value returns it unchanged. That is what keeps the
    number stable across a localized repair.
    """
    return _content_scaled_dimensions(spec)


def _content_scaled_dimensions(spec: dict) -> tuple[float, float, float]:
    """Right-size the declared world extent to the content it actually holds.

    The planner may declare any extent the schema allows and routinely asks for a
    500x500 m world to hold three objects. Placement then scatters those objects
    across a quarter of a square kilometre: in a real run the player spawned 276 m
    from the only building and 353 m from the machine, so the opening view was empty
    ground and the visual-semantic critic correctly failed the world as showing "no
    identifiable objects". Deriving the extent from the declared entity footprints
    keeps placement fully deterministic while guaranteeing the content is findable
    from where the player starts.

    The declared horizontal extent is only ever REDUCED, never grown, so a
    deliberately small world stays small and an explicitly requested vista is
    never inflated.

    Height is the exception, and it is not symmetric. Width and depth are a
    stage the content sits on, so shrinking them brings the content together;
    height is a ceiling the content sits UNDER, so a world shorter than its
    tallest object cannot hold it at all. A real run declared a hillside 12 m
    high and a colonial factory 20 m tall in the same specification, and
    placement then failed with `unplaced_entities` -- correct, but reported as
    an unsolved constraint rather than as the contradiction it was. Nothing in
    the schema links the two fields, so the ceiling is raised here to whatever
    the content requires.
    """
    declared = spec["environment"]["dimensions_m"]
    width = float(declared["width"])
    depth = float(declared["depth"])
    max_height = float(declared["max_height"])

    heights = [
        float(bbox[1])
        for entity in (spec.get("entities") or [])
        if len(bbox := (entity.get("physical") or {}).get("bbox_m") or []) >= 3
    ]
    if heights:
        # Headroom above the tallest object, so it is contained rather than
        # exactly touching the ceiling.
        max_height = max(max_height, max(heights) + _WORLD_MARGIN_M)

    footprints = [
        (float(bbox[0]), float(bbox[2]))
        for entity in (spec.get("entities") or [])
        if len(bbox := (entity.get("physical") or {}).get("bbox_m") or []) >= 3
    ]
    if not footprints:
        return width, depth, max_height
    total_area = sum(x * z for x, z in footprints)
    largest_side = max(max(x, z) for x, z in footprints)
    preferred = max(
        _MIN_WORLD_SIDE_M,
        math.sqrt(total_area) * _CONTENT_SPREAD + 2 * _WORLD_MARGIN_M,
        # Always leave the biggest object room to be walked around and seen whole.
        largest_side * 3.0,
    )
    # The smallest world that can actually hold this content. Shrinking toward
    # the content is right; shrinking BELOW it is not, and the two were
    # conflated. A village of two 4 m houses was declared 8 m square -- legal
    # since the contract's floor was lowered to admit corridors and galleries --
    # and because the extent could only ever be reduced, nothing could grow it
    # back. Every one of the eight entities went unplaced and the world came out
    # empty. A floor derived from the content is the same argument already used
    # for height: a world smaller than the thing inside it cannot contain it.
    # Footprints alone understate the room required: placement also keeps
    # interaction clearance around each object and refuses overlaps, so the
    # area that must actually be free is the footprint GROWN by that clearance.
    # Sizing on the bare footprints left two 4 m houses in a 13 m world, which
    # is arithmetically enough and practically not: six of eight entities still
    # failed to place.
    # Clearance is SHARED between neighbours: if two objects each keep 1.5 m,
    # the gap between them is 1.5 m, not 3 m. Padding each footprint by the full
    # clearance on both sides double-counts it, which made the floor lurch
    # around with the object count instead of tracking the actual content.
    occupied = sum(
        (x + _PLACEMENT_CLEARANCE_M) * (z + _PLACEMENT_CLEARANCE_M)
        for x, z in footprints
    )
    # No margin term here. `needed` is the least extent that can CONTAIN the
    # content, not the pleasant size to view it at -- that is what `preferred`
    # above is for, and adding the 5 m margin to both meant a 20x8 m corridor
    # holding one bed was grown to 10.7 m wide for no reason. A world is allowed
    # to be exactly as small as its contents demand.
    #
    # The factor is a PACKING allowance, not geometry. Placement throws seeded
    # darts and keeps the first that fits, and random sequential placement stops
    # succeeding long before the area is full: at 1.3 (~60% occupancy) the
    # village lost five of eight entities to failed attempts even though the
    # arithmetic said they fit. Sizing to ~17% occupancy is what actually lets
    # 512 attempts find room for everything.
    #
    # The test is on AREA against the placeable zone, not on a square side.
    # Demanding a square of side sqrt(occupied)*allowance grew a 20 m-deep
    # corridor sideways to satisfy a number its own depth already answered. What
    # has to be true is that the zone has enough ground, and that its SHORT side
    # can still admit the largest object -- a shape this checks directly.
    #
    # It is checked against the zone rather than the world because placement
    # happens in the zone, and the inset between them is what actually decides
    # whether an object fits. Sizing the world while the zone silently kept only
    # the middle of it was why a 22.8 m world still could not seat two 4 m
    # houses: the darts were landing in a 12.8 m box.
    width = min(width, preferred)
    depth = min(depth, preferred)
    required_area = occupied * _PACKING_ALLOWANCE**2 / _scatter_headroom(spec)
    required_short_side = largest_side + _PLACEMENT_CLEARANCE_M
    for _ in range(64):
        # Iterated because the inset is itself a function of the side length.
        zone_width = width - 2 * _zone_inset(width)
        zone_depth = depth - 2 * _zone_inset(depth)
        zone_area = max(zone_width * zone_depth, 1e-6)
        short_side = max(min(zone_width, zone_depth), 1e-6)
        if zone_area >= required_area and short_side >= required_short_side:
            break
        growth = max(
            math.sqrt(required_area / zone_area),
            required_short_side / short_side,
            1.0 + 1e-4,
        )
        width *= growth
        depth *= growth
    return width, depth, max_height


@lru_cache(maxsize=1)
def world_plan_schema() -> dict:
    return json.loads(_SCHEMA.read_text(encoding="utf-8"))


def validate_world_plan_schema(plan: dict) -> None:
    jsonschema.validate(plan, world_plan_schema())


def _aabb(
    position: list[float],
    dimensions: list[float],
    yaw_degrees: float = 0.0,
) -> dict:
    yaw = math.radians(float(yaw_degrees))
    half_x = (
        abs(math.cos(yaw)) * dimensions[0] / 2.0
        + abs(math.sin(yaw)) * dimensions[2] / 2.0
    )
    half_z = (
        abs(math.sin(yaw)) * dimensions[0] / 2.0
        + abs(math.cos(yaw)) * dimensions[2] / 2.0
    )
    half = [half_x, dimensions[1] / 2.0, half_z]
    return {
        "min": [
            round(position[0] - half[0], 4),
            round(position[1] - half[1], 4),
            round(position[2] - half[2], 4),
        ],
        "max": [
            round(position[0] + half[0], 4),
            round(position[1] + half[1], 4),
            round(position[2] + half[2], 4),
        ],
    }


def _overlaps(a: dict, b: dict, clearance: float = 0.0, *, axes=(0, 1, 2)) -> bool:
    return all(
        a["min"][axis] < b["max"][axis] + clearance
        and a["max"][axis] > b["min"][axis] - clearance
        for axis in axes
    )


def _footprint_corners(
    position: list[float], dimensions: list[float], yaw_degrees: float
) -> list[tuple[float, float]]:
    yaw = math.radians(float(yaw_degrees))
    cos, sin = math.cos(yaw), math.sin(yaw)
    half_x, half_z = dimensions[0] / 2.0, dimensions[2] / 2.0
    return [
        (
            position[0] + cos * sx * half_x + sin * sz * half_z,
            position[2] - sin * sx * half_x + cos * sz * half_z,
        )
        for sx, sz in ((-1, -1), (1, -1), (1, 1), (-1, 1))
    ]


def _overlaps_oriented(
    position: list[float],
    dimensions: list[float],
    yaw_degrees: float,
    other: dict,
    *,
    ignore_vertical: bool = False,
) -> bool:
    """True footprint overlap, respecting rotation (separating-axis test).

    `_overlaps` compares AXIS-ALIGNED boxes, which is a safe over-estimate for
    general placement but silently ruins explicit adjacency: a 12x3 m house
    turned 15 degrees claims a 12.4x6.1 m box, so the ground in front of its own
    front door counts as inside the house, and a stoop required to sit 0.5 m
    from that door was refused at every one of 512 attempts. Both stoops in a
    two-house village failed this way. Used only where the spec has explicitly
    demanded two things be adjacent -- everywhere else the cheap conservative
    test still stands.
    """
    other_min, other_max = other["world_aabb"]["min"], other["world_aabb"]["max"]
    # Vertical extents are unrotated, so the cheap interval test is exact -- but it is
    # only MEANINGFUL between things whose heights are settled. Two bodies both seated on
    # terrain have not settled yet: `_reseat_on_terrain` rewrites their y afterwards, so a
    # gap here is an artifact of the unpadded field rather than clearance anybody can
    # walk through. Measured twice on the village prompt -- a garden hose was accepted
    # 0.15 m inside a dwelling because their y intervals happened to miss by 3 cm, and
    # reseating closed the gap and failed the world on ENTITY_OVERLAP_OR_CLEARANCE.
    if not ignore_vertical and (
        position[1] + dimensions[1] / 2.0 <= other_min[1]
        or position[1] - dimensions[1] / 2.0 >= other_max[1]
    ):
        return False

    ours = _footprint_corners(position, dimensions, yaw_degrees)
    theirs = _footprint_corners(
        other["transform"]["position_m"],
        other["dimensions_m"],
        other["transform"]["rotation_y_degrees"],
    )
    for polygon in (ours, theirs):
        for index in range(len(polygon)):
            x0, z0 = polygon[index]
            x1, z1 = polygon[(index + 1) % len(polygon)]
            axis_x, axis_z = -(z1 - z0), x1 - x0
            length = math.hypot(axis_x, axis_z)
            if length < 1e-9:
                continue
            axis_x, axis_z = axis_x / length, axis_z / length
            ours_projected = [x * axis_x + z * axis_z for x, z in ours]
            theirs_projected = [x * axis_x + z * axis_z for x, z in theirs]
            if max(ours_projected) <= min(theirs_projected) + 1e-9 or (
                max(theirs_projected) <= min(ours_projected) + 1e-9
            ):
                return False  # a separating axis exists, so they are apart
    return True


def _attachment_component(entity_id: str, relations: list[dict]) -> set[str]:
    """Everything joined to this entity through `attached_to`, in either direction.

    An assembly is not one level deep. A stoop is attached to a door which is
    attached to a house, and exempting only the stoop's immediate parent left it
    contending with the house for the very ground the door opens onto -- both
    stoops in a two-house village failed on that. Attachment is treated as an
    undirected graph so the whole doorway resolves as one object.
    """
    edges: dict[str, set[str]] = {}
    for relation in relations:
        if relation["relation"] != "attached_to":
            continue
        subject, target = relation["subject_id"], relation["target_id"]
        edges.setdefault(subject, set()).add(target)
        edges.setdefault(target, set()).add(subject)

    seen = {entity_id}
    queue = [entity_id]
    while queue:
        for neighbour in edges.get(queue.pop(), ()):
            if neighbour not in seen:
                seen.add(neighbour)
                queue.append(neighbour)
    return seen


def _part_of_group(entity_id: str, relations: list[dict]) -> set[str]:
    """Everything declared to be part of the same thing as this entity.

    Undirected and transitive, for the same reason `_attachment_component` is: a
    run's segments all point at the first one, but segment 5 and segment 9 are as
    much one object as either is with segment 0.
    """
    edges: dict[str, set[str]] = {}
    for relation in relations:
        if relation.get("relation") != "part_of":
            continue
        subject, target = relation["subject_id"], relation["target_id"]
        edges.setdefault(subject, set()).add(target)
        edges.setdefault(target, set()).add(subject)

    seen = {entity_id}
    queue = [entity_id]
    while queue:
        for neighbour in edges.get(queue.pop(), ()):
            if neighbour not in seen:
                seen.add(neighbour)
                queue.append(neighbour)
    return seen


# `<run>_s<N>`, the naming `expand_linear_structures` gives every segment it cuts. The
# placer and the validator both already read it as "part of that run".
_RUN_SEGMENT = re.compile(r"^(?P<run>.+)_s\d+$")


# A thing set INTO a boundary rather than standing beside one. An opening is opened, so it
# carries interaction clearance; the boundary it is set into is the one thing that
# clearance must not apply to.
_AN_OPENING = ("gate", "door", "doorway", "hatch", "window", "turnstile", "stile")


def _opening_in_a_run(left_id: str | None, right_id: str | None) -> bool:
    """Is one of these an opening and the other a segment of a run?

    The last cause of ENTITY_UNPLACED on the frozen benchmark, and the same mistake this
    codebase already fixed once for doors -- "asking the two halves of a doorway to stand
    1.5 m apart". Measured on `sim_village_lane`:

        ent_wall_right_s1  anchored at (-15.70, -1.50), unplaceable
        ent_gate           0.5 m away, interaction_clearance_m 1.5

    One segment of a fourteen-segment wall had no solution, and an anchored segment has no
    alternative position, so the wall shipped with a hole and the prompt failed.

    Derived from the ids here, beside `_joined_runs`, for the same reason: the existing
    waiver for this needs the SPEC to declare the two joined, and a gate's position is
    decided BY placement -- so no relation can be derived before it. A rule the placer and
    the validator both read from one definition cannot drift; a waiver added to one of them
    would be the eleventh time that happened.
    """
    if not left_id or not right_id:
        return False
    left, right = str(left_id).lower(), str(right_id).lower()
    left_is_segment = _RUN_SEGMENT.match(left) is not None
    right_is_segment = _RUN_SEGMENT.match(right) is not None
    if left_is_segment == right_is_segment:
        return False  # two segments, or two ordinary bodies: not this case
    segment, other = (left, right) if left_is_segment else (right, left)
    if any(word in segment for word in _AN_OPENING):
        return False  # a door segment of a door run is not set into itself
    return any(word in other for word in _AN_OPENING)


def _joined_runs(left_id: str | None, right_id: str | None) -> bool:
    """Are these segments of two DIFFERENT linear runs?

    Then they belong to structures the planner drew crossing, and where two runs cross
    they are joined -- a jetty into a quay, a path into a road, a fence into a wall. Two
    segments of the SAME run are not this case: they are neighbours in a line, already
    handled as hard adjacency, and letting them interpenetrate would hide a run that
    doubles back on itself.
    """
    if not left_id or not right_id:
        return False
    left, right = _RUN_SEGMENT.match(str(left_id)), _RUN_SEGMENT.match(str(right_id))
    if left is None or right is None:
        return False
    return left.group("run") != right.group("run")


def entities_conflict(
    position: list[float],
    dimensions: list[float],
    yaw_degrees: float,
    clearance: float,
    other: dict,
    *,
    adjacent: bool,
    own_support: dict | None = None,
    own_id: str | None = None,
) -> bool:
    """Can these two things both be where they are? One definition, two callers.

    Placement and validation each used to answer this separately, and drifted
    FIVE times -- every drift found only when a run failed:

      1. hard-adjacency pairs were known to the placer, not the validator
      2. transitive assemblies (stoop -> door -> house) likewise
      3. the validator compared axis-aligned boxes, so a 6x5 m house turned a
         few degrees swallowed the ground beside it and failed a placement the
         placer had deliberately allowed
      4. clearance semantics differed between the two
      5. the placer skipped the oriented confirmation on the ordinary path, so
         it was STRICTER than the validator for rotated objects and threw away
         positions that would have validated

    None of those were bugs in either implementation. They were bugs in there
    being two. This is the one place the rule lives now.

    `adjacent` means the spec explicitly required these two to be together --
    attached, or joined by a hard near/facing/reachable relation. Then only a
    real overlap disqualifies: interaction clearance is the room a player needs
    to walk up to a thing, and demanding it between a door and its own stoop
    asks the two halves of a doorway to stand 1.5 m apart.
    """
    # Both on the ground, so neither one's height is final and a vertical gap between
    # them means nothing. Derived HERE, from the support records both callers already
    # hold, rather than passed in by each -- this check drifted eight times when the two
    # sides were allowed to compute the same thing separately.
    # EITHER body being on the ground is enough, not both.
    #
    # `_reseat_on_terrain` rewrites the y of every terrain-seated body after placement
    # has already judged conflicts -- and this test consults y. So a vertical gap
    # involving a body that is going to be reseated is not a fact, it is a guess about
    # where the ground will end up. Measured twice on the village prompt: a garden hose
    # cleared a service door by 3 cm and then by nothing at all, once reseating lifted it
    # from y 0.56 to y 0.83, exactly the door's base -- 0.33 m from a door that needs
    # 1.5 m to be opened. The placer allowed it, the validator refused it, and the run
    # died on a mandatory gate both times.
    #
    # Genuine stacking is unaffected: a child resting on its parent is skipped by both
    # callers before reaching here (`other_id == parent_id`), and two bodies both
    # attached to something keep the vertical test, because neither of their heights is
    # going to move.
    ground_pair = (own_support or {}).get("type") != "entity" or (
        other.get("support") or {}
    ).get("type") != "entity"
    axes = (0, 2) if ground_pair else (0, 1, 2)

    # Two runs that were drawn to meet share material where they meet.
    #
    # Derived HERE from the two ids, for the reason this whole function exists: every
    # other version of this question drifted because two callers computed it separately.
    # Both callers already hold both ids, and no geometry is needed -- if segments of two
    # DIFFERENT runs overlap at all, the planner drew those runs crossing, and a crossing
    # is a junction.
    #
    # Measured on the frozen benchmark, which is what found this rather than any single
    # prompt. `ENTITY_UNPLACED` was 6 of 10 failures, and every unplaced entity was a run
    # segment. The harbour prompt drew
    #
    #     lin_timber_jetty  (-50,-7.5) -> (-10,-4.5)  thickness 2.0
    #     lin_quay_edge     (-50,-4.5) -> ( 50,-4.5)  thickness 1.5
    #
    # -- a jetty emerging from a quay at a shallow angle, so their footprints overlap for
    # 23 of the jetty's 40 m. Five of seven quay segments had no solution and the prompt
    # failed. Trimming the jetty clear of the quay would cost 60% of its length; the
    # honest reading is that the two structures are joined, as a real jetty and quay are.
    if _joined_runs(own_id, other.get("entity_id")):
        return False

    # An opening set into a boundary waives CLEARANCE against it, not overlap: a gate
    # stands in the gap in a wall, it does not stand inside the wall's masonry.
    if _opening_in_a_run(own_id, other.get("entity_id")):
        return _overlaps_oriented(
            position, dimensions, yaw_degrees, other, ignore_vertical=ground_pair
        )

    if adjacent:
        return _overlaps_oriented(
            position, dimensions, yaw_degrees, other, ignore_vertical=ground_pair
        )

    separation = max(float(clearance), float(other["interaction_clearance_m"]))
    # Cheap axis-aligned reject first; it is a safe over-estimate, so anything
    # it clears is genuinely clear.
    if not _overlaps(
        _aabb(position, dimensions, yaw_degrees),
        other["world_aabb"],
        separation,
        axes=axes,
    ):
        return False
    # It flagged them -- now confirm on the true footprints, grown by the
    # clearance so the meaning of the check is unchanged and only the rotation
    # is accounted for.
    #
    # Tested BOTH WAYS ROUND, and that is not belt-and-braces. Padding grows a
    # box along its OWN axes, which for a rotated box is not the same as growing
    # it evenly in all directions -- so the test is asymmetric, and asking
    # "does A clear B" can answer differently from "does B clear A". Placement
    # always asks with the candidate first; validation asks in list order. Two
    # specs placed cleanly and then failed validation on exactly that, which is
    # the same drift this function exists to end, hiding one level down.
    def _clear(
        pos: list[float], dims: list[float], yaw: float, target: dict
    ) -> bool:
        padded = [
            dims[0] + 2 * separation,
            dims[1],
            dims[2] + 2 * separation,
        ]
        # Same reasoning as above: between two ground-seated bodies the height gap is
        # not settled yet, so it must not excuse a footprint overlap.
        return _overlaps_oriented(
            pos, padded, yaw, target, ignore_vertical=ground_pair
        )

    if _clear(position, dimensions, yaw_degrees, other):
        return True
    # The mirror: grow the other one instead, and test against this one.
    mirrored = {
        "world_aabb": _aabb(position, dimensions, yaw_degrees),
        "transform": {"position_m": position, "rotation_y_degrees": yaw_degrees},
        "dimensions_m": dimensions,
    }
    return _clear(
        other["transform"]["position_m"],
        other["dimensions_m"],
        other["transform"]["rotation_y_degrees"],
        mirrored,
    )


def _contains(outer: dict, inner: dict) -> bool:
    return all(
        inner["min"][axis] >= outer["min"][axis]
        and inner["max"][axis] <= outer["max"][axis]
        for axis in range(3)
    )


def _segment_intersects_aabb_2d(
    start: list[float],
    end: list[float],
    bounds: dict,
    margin: float,
) -> bool:
    """Liang-Barsky segment/expanded-XZ-AABB intersection."""
    minimum = [bounds["min"][0] - margin, bounds["min"][2] - margin]
    maximum = [bounds["max"][0] + margin, bounds["max"][2] + margin]
    origin = [start[0], start[2]]
    delta = [end[0] - start[0], end[2] - start[2]]
    lower, upper = 0.0, 1.0
    for axis in range(2):
        if abs(delta[axis]) < 1e-9:
            if origin[axis] < minimum[axis] or origin[axis] > maximum[axis]:
                return False
            continue
        first = (minimum[axis] - origin[axis]) / delta[axis]
        second = (maximum[axis] - origin[axis]) / delta[axis]
        entry, exit_ = min(first, second), max(first, second)
        lower, upper = max(lower, entry), min(upper, exit_)
        if lower > upper:
            return False
    return True


def _path_is_clear(
    points: list[list[float]],
    placed: dict[str, dict],
    excluded: set[str],
    width_m: float,
) -> bool:
    obstacles = [
        item
        for entity_id, item in placed.items()
        if entity_id not in excluded and not item["dynamic"]
    ]
    return not any(
        _segment_intersects_aabb_2d(start, end, obstacle["world_aabb"], width_m / 2.0)
        for start, end in zip(points, points[1:], strict=False)
        for obstacle in obstacles
    )


def _navigation_paths(
    relations: list[dict],
    placed: dict[str, dict],
    routes: list[dict] | None = None,
) -> tuple[list[dict], list[dict]]:
    paths: list[dict] = []
    results: list[dict] = []
    connected = [relation for relation in relations if relation["relation"] == "connected_to"]
    for index, relation in enumerate(connected, start=1):
        source = placed.get(relation["subject_id"])
        target = placed.get(relation["target_id"])
        path_id = f"path_{index}_{relation['subject_id'][4:]}"
        if source is None or target is None:
            paths.append(
                {
                    "path_id": path_id,
                    "from_entity_id": relation["subject_id"],
                    "to_entity_id": relation["target_id"],
                    "width_m": 2.0,
                    "points_m": [[0.0, 0.04, 0.0], [0.0, 0.04, 0.0]],
                    "status": "UNRESOLVED",
                }
            )
            results.append(
                {
                    "constraint": "path_connectivity",
                    "path_id": path_id,
                    "status": "FAIL",
                    "code": "PATH_ENDPOINT_UNPLACED",
                }
            )
            continue
        start = [
            float(source["transform"]["position_m"][0]),
            0.04,
            float(source["transform"]["position_m"][2]),
        ]
        end = [
            float(target["transform"]["position_m"][0]),
            0.04,
            float(target["transform"]["position_m"][2]),
        ]
        excluded = {
            source["entity_id"],
            target["entity_id"],
            source.get("parent_id"),
            target.get("parent_id"),
        }
        candidates = [
            [start, end],
            [start, [start[0], 0.04, end[2]], end],
            [start, [end[0], 0.04, start[2]], end],
        ]
        # And then, if the world has streets, the way a person would actually go.
        #
        # With houses in two rows 1.2 m apart, the far row's doors could reach nothing:
        # straight and L-shaped candidates were blocked by the door's own neighbour
        # along the row, and by the opposite row going the other way. Every building
        # was correctly oriented onto a lane that no path could use, which is a
        # decorative street. Nobody walks between two terraced houses -- they step out
        # to the street, walk along it, and turn off at the far end.
        #
        # Offered last, so a clear straight line is still preferred: a path that hugs
        # the kerb to reach something ten metres away would be absurd.
        for route in routes or ():
            corridor = corridor_between(
                route, (start[0], start[2]), (end[0], end[2])
            )
            if corridor:
                candidates.append(
                    [start, *[[x, 0.04, z] for x, z in corridor], end]
                )
        points = next(
            (
                candidate
                for candidate in candidates
                if _path_is_clear(candidate, placed, excluded, 2.0)
            ),
            None,
        )
        status = "CONNECTED" if points is not None else "UNRESOLVED"
        paths.append(
            {
                "path_id": path_id,
                "from_entity_id": source["entity_id"],
                "to_entity_id": target["entity_id"],
                "width_m": 2.0,
                "points_m": points or [start, end],
                "status": status,
            }
        )
        results.append(
            {
                "constraint": "path_connectivity",
                "path_id": path_id,
                "status": "PASS" if points is not None else "FAIL",
                **({} if points is not None else {"code": "NO_CLEAR_PATH_SOLUTION"}),
            }
        )
    return paths, results


# How far outside the zones an anchored boundary may sit. Zones are inset from the
# world, so a wall declared along the world's edge is legitimately outside every zone
# box; this is the room that inset takes back for things whose position is a fact.
_BOUNDARY_MARGIN_M = 12.0


def _zone_inset(side: float) -> float:
    """Border between the world edge and the placeable zone, for one side.

    A flat 5 m was applied regardless of scale, which is a reasonable verge on a
    100 m world and takes 10 of 12 m from a small one -- an 8 m courtyard came
    out with a NEGATIVE placeable area, so nothing could be placed anywhere in
    it. A border must never be able to consume the thing it borders, so it is
    capped at a fraction of the side it trims.
    """
    return min(_WORLD_MARGIN_M, side * 0.15)


def _zone_geometry(spec: dict) -> list[dict]:
    width, depth, max_height = _content_scaled_dimensions(spec)
    margin_x = _zone_inset(width)
    margin_z = _zone_inset(depth)
    definitions = spec["environment"].get("zones") or [
        {"zone_id": "main", "semantic_type": "main", "connected_to": []}
    ]
    secondary = [zone for zone in definitions if zone["zone_id"] != "main"]
    columns = max(1, math.ceil(math.sqrt(len(secondary))))
    rows = max(1, math.ceil(len(secondary) / columns))
    inner_width = width - 2 * margin_x
    inner_depth = depth - 2 * margin_z
    cell_width = inner_width / columns
    cell_depth = inner_depth / rows
    zones: list[dict] = []
    for definition in definitions:
        if definition["zone_id"] == "main":
            bounds = {
                "min": [-width / 2 + margin_x, 0.0, -depth / 2 + margin_z],
                "max": [width / 2 - margin_x, max_height, depth / 2 - margin_z],
            }
        else:
            secondary_index = secondary.index(definition)
            row, column = divmod(secondary_index, columns)
            x0 = -width / 2 + margin_x + column * cell_width
            z0 = -depth / 2 + margin_z + row * cell_depth
            bounds = {
                "min": [x0, 0.0, z0],
                "max": [x0 + cell_width, max_height, z0 + cell_depth],
            }
        zones.append(
            {
                "zone_id": definition["zone_id"],
                "semantic_type": definition["semantic_type"],
                "bounds": {
                    "min": [round(value, 4) for value in bounds["min"]],
                    "max": [round(value, 4) for value in bounds["max"]],
                },
                "connected_to": list(definition.get("connected_to", [])),
            }
        )
    return zones


# Above this share of a `part_of` group failing, the THING is missing rather than
# incomplete. One segment of sixteen is a gap in a fence; nine of sixteen is not a fence.
_GROUP_COLLAPSE = 0.5


def _classify_unplaced(spec: dict, unplaced: list[str]) -> dict:
    """Split unplaced entities into the ones the prompt asked for and the rest.

    A `part_of` group is judged as a group: if more than half its members failed, the
    group's own head is promoted to required, because what is missing is the fence and
    not a corner of it. That rule is what stops this becoming a way to publish a world
    whose walls simply are not there.
    """
    if not unplaced:
        return {"unplaced_required": [], "unplaced_incidental": []}

    required = set(required_entity_ids(spec))
    groups: dict[str, list[str]] = {}
    for relation in spec.get("spatial_relations") or ():
        if relation.get("relation") != "part_of":
            continue
        groups.setdefault(str(relation.get("target_id")), []).append(
            str(relation.get("subject_id"))
        )

    missing = set(unplaced)
    for head, members in groups.items():
        family = [head, *members]
        failed = sum(1 for entity_id in family if entity_id in missing)
        if family and failed / len(family) > _GROUP_COLLAPSE:
            # The run itself did not get built, so its failures stop being incidental.
            #
            # The FAILED MEMBERS are promoted, not the head: the head usually placed
            # fine -- it is the rest of the fence that is missing -- and marking an
            # entity that placed cannot make a gate object, because the gate only reads
            # entities that did not.
            required.update(entity_id for entity_id in family if entity_id in missing)

    return {
        "unplaced_required": [item for item in unplaced if item in required],
        "unplaced_incidental": [item for item in unplaced if item not in required],
    }


def _placement_order(spec: dict) -> list[dict]:
    target_ids = {
        relation["target_id"] for relation in spec["spatial_relations"]
    }
    category_order = {
        "environment": 0,
        "structure": 1,
        "machine": 2,
        "vehicle": 3,
        "prop": 4,
        "character": 5,
    }
    indexed = list(enumerate(spec["entities"]))

    def _anchored(entity: dict) -> int:
        """0 for a thing that cannot move, 1 for a thing that can.

        A wall segment carries a declared `anchor_m`: segment 7 belongs between 6 and 8
        and there is no second-choice position for it. A building has no anchor and any
        clear ground will do. Ordering by category alone let the movable thing claim the
        ground first and the immovable one fail against it -- measured on settlement
        prompts, 112 entities went unplaced and almost all were run segments.

        Frontage anchors are excluded on purpose. They are a PREFERENCE (ADR-0017): a
        house yields its plot when the ground is taken, so it does not need to go first
        and putting it there would let it claim ground a wall genuinely cannot give up.
        """
        placement = entity.get("placement") or {}
        if not placement.get("anchor_m"):
            return 1
        return 1 if isinstance(placement.get("frontage"), dict) else 0

    indexed.sort(
        key=lambda pair: (
            _anchored(pair[1]),
            category_order.get(pair[1]["asset"]["category"], 6),
            0 if pair[1]["entity_id"] in target_ids else 1,
            pair[0],
        )
    )
    ordered = [entity for _, entity in indexed]

    # An attached child is placed immediately after its parent, ahead of
    # everything else.
    #
    # Category order alone put a door (`prop`) behind every structure, machine
    # and vehicle in the world, so unrelated free objects claimed the ground
    # against the door's own house before the door was ever considered -- and a
    # rigidly attached child has no freedom to move aside, so it simply failed.
    # Whether a village kept its doors came down to which way the seeded darts
    # happened to fall: the same eight entities placed five at 22.6 m and four
    # at 22.8 m. Keeping an assembly contiguous makes that deterministic in
    # substance rather than only in seed, because the child contends only with
    # what was already there when its parent landed.
    children: dict[str, list[str]] = {}
    for relation in spec["spatial_relations"]:
        if relation["relation"] == "attached_to":
            children.setdefault(relation["target_id"], []).append(
                relation["subject_id"]
            )
    if not children:
        return ordered

    by_id = {entity["entity_id"]: entity for entity in ordered}
    emitted: set[str] = set()
    assembled: list[dict] = []

    def emit(entity_id: str) -> None:
        # Guards a cycle in the attachment graph as well as re-emission.
        if entity_id in emitted or entity_id not in by_id:
            return
        emitted.add(entity_id)
        assembled.append(by_id[entity_id])
        for child_id in children.get(entity_id, []):
            emit(child_id)

    attached = {child for group in children.values() for child in group}
    for entity in ordered:
        # Children are reached through their parent; one whose parent is missing
        # from the spec still gets its turn at the end of its category.
        if entity["entity_id"] in attached and any(
            relation["subject_id"] == entity["entity_id"]
            and relation["relation"] == "attached_to"
            and relation["target_id"] in by_id
            for relation in spec["spatial_relations"]
        ):
            continue
        emit(entity["entity_id"])
    for entity in ordered:  # anything left by a broken attachment graph
        emit(entity["entity_id"])
    return assembled


def _free_point(
    rng: random.Random, zone: dict, spread: float
) -> tuple[float, float]:
    """A candidate point, drawn from the middle `spread` fraction of the zone.

    Uniform sampling over the whole zone is what turns "a small village" into
    scattered buildings: a real run put two houses 48 m apart in a 73 m world,
    with the player 52 m from half the content, and the overview showed empty
    ground. The zone has to STAY large -- placement throws seeded darts and
    needs the room, and every attempt to shrink it broke placement on real
    specs -- so the fix is where the darts land, not how big the board is.

    `spread` is widened as attempts fail, so the first tries compose the scene
    tightly and the last ones can still reach any corner. Feasibility is
    unchanged; only the typical result is tighter.
    """
    bounds = zone["bounds"]
    center_x = (bounds["min"][0] + bounds["max"][0]) / 2.0
    center_z = (bounds["min"][2] + bounds["max"][2]) / 2.0
    half_x = (bounds["max"][0] - bounds["min"][0]) / 2.0 * spread
    half_z = (bounds["max"][2] - bounds["min"][2]) / 2.0 * spread
    return (
        rng.uniform(center_x - half_x, center_x + half_x),
        rng.uniform(center_z - half_z, center_z + half_z),
    )


def _preferred_position(
    rng: random.Random,
    entity: dict,
    zone: dict,
    placed: dict[str, dict],
    relations: list[dict],
    relax: bool = False,
    spread: float = 1.0,
) -> tuple[float, float, str | None, str | None]:
    """Pick a candidate point. Returns (x, z, near_target, abandoned_target).

    With `relax`, a SOFT preference the geometry cannot satisfy is dropped in
    favour of free ground, and the target it gave up on is returned so the
    caller can record the relaxation.
    """
    # An anchored entity is mostly not being positioned, it is being reported.
    # Collision, clearance and terrain seating all still run afterwards, so a plot
    # driven through a house is still caught and still disclosed. Returned before the
    # relation search deliberately: an anchor is a stronger claim than a relation, so
    # the two cannot compete.
    #
    # But there are two kinds of anchor and they differ in authority:
    #
    #   - A wall segment's anchor is a FACT. Segment 7 of a run belongs between 6 and
    #     8; moving it somewhere with more room would not be a compromise, it would be
    #     a different wall. It is honoured on every attempt, and if the ground is
    #     genuinely taken the segment is reported unplaced.
    #   - A frontage anchor is a PREFERENCE. "This house addresses the main lane" is
    #     satisfied by a plot on that lane, and when the plot is occupied the honest
    #     answer is a house somewhere else, not a missing house. Measured: a lane run
    #     through a 25 m village square put two of four cottages inside it, and
    #     honouring the anchor on every attempt lost both -- an unplaced building is
    #     worse than a badly placed one.
    #
    # So frontage yields once relaxation begins, like every other soft preference,
    # and the relaxation is recorded.
    placement = entity.get("placement") or {}
    anchor = placement.get("anchor_m")
    fronting = isinstance(placement.get("frontage"), dict)
    if isinstance(anchor, (list, tuple)) and len(anchor) >= 2:
        if not (relax and fronting):
            try:
                return (float(anchor[0]), float(anchor[1]), None, None)
            except (TypeError, ValueError):
                pass  # fall through rather than fail the world over a bad number

    near = next(
        (
            relation
            for relation in relations
            if relation["subject_id"] == entity["entity_id"]
            and relation["relation"] in {"near", "facing", "reachable_from"}
            and relation["target_id"] in placed
        ),
        None,
    )
    # A soft preference is a preference. Every one of the 512 attempts sampled
    # the same ring, so when that ring was unsatisfiable the entity simply
    # failed -- the player character was left unplaced beside a door set into a
    # wall, with 62% of the zone standing empty and no attempt ever made on it.
    # A `hard` relation still fails loudly; a soft one yields and says so.
    if near is not None and relax and not near.get("hard", False):
        x, z = _free_point(rng, zone, spread)
        return (x, z, None, near["target_id"])

    if near:
        placed_target = placed[near["target_id"]]
        target = placed_target["transform"]["position_m"]
        maximum = float(near.get("distance_m") or 12.0)

        # `distance_m` is centre-to-centre, which is what the rest of the system
        # asserts, but the ring it samples has to start OUTSIDE the target or it
        # cannot be satisfied at all. "Fence post near the house, 1.5 m" put all
        # 512 candidate points 1.5 m from the centre of a 4x4 m house -- inside
        # the house -- so the post never placed, and the player, asked to start
        # within 3 m of a door set into that same wall, failed the same way. The
        # tighter the relation and the bigger the target, the more certainly it
        # failed, which is the opposite of the intent.
        #
        # So only the ring's INNER edge is corrected, out to where the two
        # footprints stop overlapping. A generous distance is untouched and
        # still means what the tests say it means; a distance too small to be
        # obeyable is honoured as closely as the geometry permits.
        bounds = placed_target["world_aabb"]
        dimensions = entity["physical"]["bbox_m"]
        touching = (
            max(
                bounds["max"][0] - bounds["min"][0],
                bounds["max"][2] - bounds["min"][2],
            )
            + max(float(dimensions[0]), float(dimensions[2]))
        ) / 2.0
        inner = max(maximum * 0.35, touching)
        outer = max(maximum, inner * 1.05)

        angle = rng.uniform(0, math.tau)
        radius = rng.uniform(inner, outer)
        return (
            target[0] + math.cos(angle) * radius,
            target[2] + math.sin(angle) * radius,
            near["target_id"],
            None,
        )
    x, z = _free_point(rng, zone, spread)
    return (x, z, None, None)


def _reseat_on_terrain(placed: dict[str, dict], terrain) -> None:
    """Put every placed body back on the ground, now that the ground is final.

    Only y moves. The x/z decision was solved against zone bounds and neighbour
    clearances and is left exactly as it was, so laying pads cannot make a world
    that packed successfully fail to pack.

    A child supported by another entity moves RIGIDLY with its parent -- shifted by
    however far the parent moved -- rather than being re-seated onto the parent's
    top. Recomputing it was a real regression: an `attached_to` child records its own
    underside as `contact_y_m`, not its parent's top, so treating the two the same
    put a door two metres above the roofline of the cottage it was set into. The
    planner had authored the offset correctly ([0, -0.5, 2.5]: centred, half a metre
    down, flush with the front face) and the re-seat threw it away.

    Shifting is also simply more correct. Whatever relationship the placement solver
    established -- resting on a table, set into a wall -- survives the ground moving
    underneath the assembly, and nothing has to know which kind it was.

    Walked in insertion order, which is placement order, so a parent's shift is known
    before its child asks for it.
    """
    shifted: dict[str, float] = {}
    for record in placed.values():
        position = record["transform"]["position_m"]
        dimensions = record["dimensions_m"]
        support = record["support"]
        was = position[1]
        if support["type"] == "entity" and support["target_id"] in placed:
            delta = shifted.get(support["target_id"], 0.0)
            position[1] = round(position[1] + delta, 4)
            support["contact_y_m"] = round(
                float(support["contact_y_m"]) + delta, 4
            )
            # Nothing may end up under the ground. Shifting rigidly preserves the
            # relationship the solver established, which is right, but it also
            # preserves any sag the solver left behind -- and the old
            # seat-on-the-parent's-top rule was accidentally hiding that by
            # launching the child upward. A door found 0.2 m below the surface is
            # a door underground however faithfully it followed its wall.
            floor = terrain.height_at(position[0], position[2])
            underside = position[1] - dimensions[1] / 2.0
            if underside < floor - 1e-6:
                position[1] = round(position[1] + (floor - underside), 4)
                support["contact_y_m"] = round(floor, 4)
        else:
            contact = terrain.height_at(position[0], position[2])
            support["contact_y_m"] = round(contact, 4)
            position[1] = round(contact + dimensions[1] / 2.0, 4)
        shifted[record["entity_id"]] = round(position[1] - was, 4)
        record["world_aabb"] = _aabb(
            position, dimensions, record["transform"]["rotation_y_degrees"]
        )


def generate_semantic_world_plan(
    spec: dict,
    asset_descriptors: dict[str, dict] | None = None,
    behaviour_graphs: list[dict] | None = None,
    preserved_plan: dict | None = None,
    affected_entity_ids: set[str] | None = None,
    placement_ranker: Any | None = None,
) -> dict:
    descriptors = asset_descriptors or {}

    # Streets first, then the buildings that address them.
    #
    # This runs before the placement loop and after measurement, which is the only
    # window it can: plot width comes from how wide the building actually is, and a
    # 12 m longhouse and a 2 m market stall cannot share a plot size. Frontage is
    # turned into `anchor_m`, so the ordinary solver still does the placing --
    # collision, clearance and terrain seating all still apply, and a plot that lands
    # on a pre-existing well is still caught and disclosed rather than silently won.
    #
    # Mutating the caller's spec is deliberate and matches how the rest of this
    # function reads it: the anchors have to be visible to `_preferred_position` and
    # to the yaw choice, both of which read `entity["placement"]`.
    frontage_notes = allocate_frontage(
        spec,
        {
            entity_id: descriptor["world_dimensions_m"]
            for entity_id, descriptor in descriptors.items()
            if descriptor.get("world_dimensions_m")
        },
    )

    # The ground, before anything is placed on it. Built from the environment the
    # planner declared and the run's seed, so it is reproducible and so indoor and
    # built-surface worlds come back flat.
    # The ground, before anything is placed on it. Built from the environment the
    # planner declared and the run's seed, so it is reproducible and so indoor and
    # built-surface worlds come back flat.
    #
    # NOTE: this reads the RAW declaration, which is knowingly too small when the
    # planner under-declares -- see docs/VILLAGE_GAP_ANALYSIS.md §5. Sizing it from
    # `_content_scaled_dimensions` fixes the visible defect and was reverted, because
    # making terrain depend on content makes the heightfield change whenever content
    # does: adding one entity re-seats every entity, which breaks locality of repair
    # (test_localized_addition_re_solves_only_the_added_entity). The fix belongs in the
    # PLANNER, growing `dimensions_m` once so the declaration is honest and stable,
    # not here.
    terrain = build_terrain(spec.get("environment") or {}, int(spec["meta"]["seed"]))
    zones = _zone_geometry(spec)
    if not terrain.flat:
        # A zone's box must contain the ground beneath it. The floor was 0.0, and
        # `_contains` checks all three axes, so the first body seated in a dip was
        # reported as having left its zone.
        floor = round(min(0.0, min(terrain.heights)), 4)
        for zone in zones:
            zone["bounds"]["min"][1] = floor
    zone_by_id = {zone["zone_id"]: zone for zone in zones}
    # The whole world, as a box. Anchored entities are checked against this rather than
    # against an inset zone, so a declared boundary can sit on the boundary.
    # Derived from the zones themselves rather than from the world dimensions, which
    # are computed further down: the union of every zone box IS the built world, and a
    # boundary declared beyond all of them is beyond the world.
    world_bounds = {
        "min": [
            min(zone["bounds"]["min"][0] for zone in zones) - _BOUNDARY_MARGIN_M,
            -1e6,
            min(zone["bounds"]["min"][2] for zone in zones) - _BOUNDARY_MARGIN_M,
        ],
        "max": [
            max(zone["bounds"]["max"][0] for zone in zones) + _BOUNDARY_MARGIN_M,
            1e6,
            max(zone["bounds"]["max"][2] for zone in zones) + _BOUNDARY_MARGIN_M,
        ],
    } if zones else {"min": [-1e6, -1e6, -1e6], "max": [1e6, 1e6, 1e6]}
    placed: dict[str, dict] = {}
    hard_results: list[dict] = []
    soft_relaxations: list[dict] = []
    unplaced: list[str] = []
    relations = spec["spatial_relations"]
    # Declared geometry, kept alongside the measured geometry placement uses.
    # An attachment offset is authored against the declared box and applied
    # against the measured mesh, so resolving one needs both.
    spec_by_entity_id = {
        entity["entity_id"]: entity for entity in (spec.get("entities") or ())
    }
    preserved_by_id = {
        item["entity_id"]: item
        for item in (preserved_plan or {}).get("entities", [])
    }

    for entity in _placement_order(spec):
        entity_id = entity["entity_id"]
        descriptor = descriptors.get(entity_id)
        measurement_status = (
            descriptor["measurement"]["status"]
            if descriptor
            else "DECLARED_UNVERIFIED"
        )
        dimensions = [
            float(value)
            for value in (
                descriptor["world_dimensions_m"]
                if descriptor
                else entity["physical"]["bbox_m"]
            )
        ]
        zone = zone_by_id.get(entity["placement"]["zone"]) or zone_by_id.get("main") or zones[0]
        clearance = (
            float(descriptor["interaction"]["clearance_m"])
            if descriptor
            else (1.5 if entity["capabilities"] else 0.25)
        )
        scale = descriptor["normalization_scale"] if descriptor else [1.0, 1.0, 1.0]
        asset_ref = descriptor["asset_ref"] if descriptor else None
        rng = random.Random(f"{spec['meta']['seed']}:semantic:{entity_id}")
        accepted: dict | None = None
        used_near_target: str | None = None
        parent_id: str | None = None
        support = {"type": "terrain", "target_id": None, "contact_y_m": 0.0}

        support_relation = next(
            (
                relation
                for relation in relations
                if relation["subject_id"] == entity_id
                and relation["relation"] in {"on", "supported_by"}
                and relation["target_id"] in placed
            ),
            None,
        )
        previous = preserved_by_id.get(entity_id)
        should_preserve = previous is not None and (
            affected_entity_ids is not None
            and entity_id not in affected_entity_ids
        )
        if should_preserve:
            old_position = previous["transform"]["position_m"]
            preserved_aabb = _aabb(
                old_position,
                dimensions,
                previous["transform"]["rotation_y_degrees"],
            )
            collision = any(
                _overlaps(
                    preserved_aabb,
                    other["world_aabb"],
                    max(clearance, float(other["interaction_clearance_m"])),
                )
                for other in placed.values()
                if other["entity_id"] != previous.get("parent_id")
            )
            if _contains(zone["bounds"], preserved_aabb) and not collision:
                accepted = {
                    "entity_id": entity_id,
                    "semantic_type": entity["semantic_type"],
                    "zone_id": zone["zone_id"],
                    "asset_ref": asset_ref,
                    "measurement_status": measurement_status,
                    "dimensions_m": [round(value, 4) for value in dimensions],
                    "transform": {
                        "position_m": list(old_position),
                        "rotation_y_degrees": previous["transform"][
                            "rotation_y_degrees"
                        ],
                        "scale": [round(float(value), 6) for value in scale],
                    },
                    "world_aabb": preserved_aabb,
                    "support": dict(previous["support"]),
                    "interaction_clearance_m": clearance,
                    "dynamic": bool(entity["physical"]["dynamic"]),
                    "parent_id": previous.get("parent_id"),
                }
                used_near_target = next(
                    (
                        relation["target_id"]
                        for relation in relations
                        if relation["subject_id"] == entity_id
                        and relation["relation"] == "near"
                    ),
                    None,
                )
            else:
                soft_relaxations.append(
                    {
                        "entity_id": entity_id,
                        "constraint": "preserve_transform",
                        "reason": (
                            "previous transform no longer satisfies current "
                            "bounds or clearance"
                        ),
                    }
                )
        attachment = next(
            (
                relation
                for relation in relations
                if relation["subject_id"] == entity_id
                and relation["relation"] == "attached_to"
            ),
            None,
        )
        attachment_failed = False
        if accepted is None and attachment is not None:
            parent = placed.get(attachment["target_id"])
            if parent is None:
                attachment_failed = True
            else:
                offset = [float(value) for value in attachment["local_offset_m"]]

                # The offset was authored in DECLARED space and is applied in
                # MEASURED space, so it has to be carried across.
                #
                # Normalisation scales an imported mesh uniformly by height,
                # which preserves the ASSET's proportions rather than the
                # declared box's. A machine declared 2.5 x 2.4 x 1.8 measured
                # 2.81 x 2.4 x 3.57: the planner put a sensor at z = 1.0,
                # correctly just proud of a 1.8 m-deep face, and placement read
                # that against a 3.57 m-deep body, burying the sensor inside the
                # machine. A display attached to the sensor then overlapped its
                # own grandparent and was refused on every variant, which failed
                # semantic_placement, requirement_traceability and the entity
                # count critic together, and stopped the run before it built.
                #
                # Scaling each axis by measured-over-declared keeps what the
                # planner actually meant -- which face, and how far along it as
                # a fraction of the parent -- under a mesh of different
                # proportions. The clamp below still pulls it flush.
                declared_parent = (
                    (spec_by_entity_id.get(attachment["target_id"]) or {}).get("physical")
                    or {}
                ).get("bbox_m")
                if isinstance(declared_parent, list) and len(declared_parent) >= 3:
                    for axis in range(3):
                        try:
                            declared_extent = float(declared_parent[axis])
                        except (TypeError, ValueError):
                            continue
                        measured_extent = float(parent["dimensions_m"][axis])
                        if declared_extent > 1e-6 and measured_extent > 1e-6:
                            offset[axis] *= measured_extent / declared_extent

                # An attached child has to touch what it is attached to.
                #
                # The offset is free-form, and the planner reads the parent's
                # dimensions off the wrong axis often enough to matter: a door
                # was attached to a 3 m deep house at an offset of 4.06 m, which
                # left it floating 2.6 m clear of the wall -- and, being at the
                # edge of the plot, just outside its own zone, so it failed to
                # place at all. Past the point where the two surfaces separate,
                # a larger offset does not describe a different attachment; it
                # describes a detached object. Each axis is therefore limited to
                # the flush position, which keeps the chosen FACE intact and only
                # removes the gap.
                limits = [
                    parent["dimensions_m"][axis] / 2.0 + dimensions[axis] / 2.0
                    for axis in range(3)
                ]
                # An offset that reaches no face at all is as broken as one that
                # overshoots, and was previously left alone. Measured across 176
                # specs: 6 of 168 attachments (4%) named an offset inside the
                # parent's own volume, which places the child INSIDE it -- a
                # gatehouse door at offset [0, -0.25, 0] came out at exactly the
                # gatehouse's x and z, invisible.
                #
                # The dominant axis is pushed out to flush, keeping whichever face
                # the planner leaned towards. A child fully inside its parent is
                # never the intent.
                reaches_a_face = any(
                    abs(offset[axis]) >= limits[axis] - 1e-6 for axis in range(3)
                )
                if not reaches_a_face:
                    # Horizontal axes only, unless the planner clearly meant UP.
                    #
                    # Taking the largest component outright pushed a gatehouse door
                    # straight down out of the building's underside, because its
                    # offset [0, -0.25, 0] is vertical-dominant -- and the
                    # below-ground guard then lifted it back to where it started.
                    # Attaching something beneath a building is essentially never
                    # meant; attaching to the TOP is (a chimney, a sign on a post),
                    # so a positive vertical offset is still allowed to win.
                    horizontal = 0 if abs(offset[0]) >= abs(offset[2]) else 2
                    if offset[1] > 1e-6 and abs(offset[1]) > abs(offset[horizontal]):
                        dominant = 1
                    else:
                        dominant = horizontal
                    # A zero vector names no face at all, so fall back to the
                    # thinnest horizontal axis -- the one a door or panel belongs on.
                    if abs(offset[dominant]) <= 1e-6:
                        dominant = 0 if dimensions[0] <= dimensions[2] else 2
                    sunken = [round(value, 2) for value in offset]
                    sign = -1.0 if offset[dominant] < 0 else 1.0
                    offset[dominant] = sign * limits[dominant]
                    soft_relaxations.append(
                        {
                            "entity_id": entity_id,
                            "constraint": "attachment_offset_sunken",
                            "reason": (
                                f"offset {sunken} lies inside {attachment['target_id']} "
                                f"and reaches no face; pushed out to its surface"
                            ),
                        }
                    )
                if any(abs(offset[axis]) > limits[axis] for axis in range(3)):
                    detached = [round(offset[axis], 2) for axis in range(3)]
                    offset = [
                        max(-limits[axis], min(limits[axis], offset[axis]))
                        for axis in range(3)
                    ]
                    soft_relaxations.append(
                        {
                            "entity_id": entity_id,
                            "constraint": "attachment_offset",
                            "reason": (
                                f"offset {detached} does not reach the surface of "
                                f"{attachment['target_id']}; pulled flush against it"
                            ),
                        }
                    )
                parent_yaw = float(parent["transform"]["rotation_y_degrees"])
                angle = math.radians(parent_yaw)
                assembly = _attachment_component(entity_id, relations)
                # An assembly absorbs whatever its members are PART OF.
                #
                # `_attachment_component` walks `attached_to` only, so a door reaches its
                # gatehouse and stops -- while the gatehouse is `part_of` a perimeter wall
                # run, and the door was then measured against the wall segments beside its
                # own parent with its full 1.5 m interaction clearance. Measured on
                # run_9bb52892adfc42b39dfcc477934e7a54: `ent_gatehouse_door` went unplaced
                # and took seven mandatory gates with it.
                #
                # This is the same gap that was just closed on `adjacency_exempt`, in a
                # second implementation of the same question -- attached children are
                # placed by this path, which never calls `entities_conflict` and so never
                # saw that fix. Nobody needs walking room between a door and the wall its
                # own gatehouse is built into.
                assembly |= {
                    member
                    for attached in set(assembly)
                    for member in _part_of_group(attached, relations)
                }

                # Which way is OUT is not something the planner gets right.
                #
                # A stoop was attached to a door with a +0.5 m offset along the
                # axis whose outward direction is negative, which put the step
                # INSIDE the house the door is set into. The face and the
                # distance were both right; only the sign was wrong, and there
                # is nothing in a bare 3-vector to check it against. So the
                # mirrored horizontal directions are tried as fallbacks, in a
                # fixed order, and the first that clears the assembly wins. The
                # planner's chosen axis and magnitude always survive.
                variants = [
                    tuple(offset),
                    (offset[0], offset[1], -offset[2]),
                    (-offset[0], offset[1], offset[2]),
                    (-offset[0], offset[1], -offset[2]),
                ]
                seen_variants: list[tuple[float, float, float]] = []
                for variant in variants:
                    if variant not in seen_variants:
                        seen_variants.append(variant)

                position = [
                    round(
                        parent["transform"]["position_m"][0]
                        + math.cos(angle) * offset[0]
                        + math.sin(angle) * offset[2],
                        4,
                    ),
                    round(parent["transform"]["position_m"][1] + offset[1], 4),
                    round(
                        parent["transform"]["position_m"][2]
                        - math.sin(angle) * offset[0]
                        + math.cos(angle) * offset[2],
                        4,
                    ),
                ]
                yaw = parent_yaw + float(attachment["local_rotation_y_degrees"])
                candidate = _aabb(position, dimensions, yaw)

                def _evaluate(
                    trial: tuple[float, float, float],
                ) -> tuple[list[float], dict, float] | None:
                    """Resolve one offset variant, or None if it will not do."""
                    trial_position = [
                        round(
                            parent["transform"]["position_m"][0]
                            + math.cos(angle) * trial[0]
                            + math.sin(angle) * trial[2],
                            4,
                        ),
                        round(parent["transform"]["position_m"][1] + trial[1], 4),
                        round(
                            parent["transform"]["position_m"][2]
                            - math.sin(angle) * trial[0]
                            + math.cos(angle) * trial[2],
                            4,
                        ),
                    ]
                    trial_box = _aabb(trial_position, dimensions, yaw)
                    dropped = zone["bounds"]["min"][1] - trial_box["min"][1]
                    if dropped > 1e-6:
                        trial_position[1] = round(trial_position[1] + dropped, 4)
                        trial_box = _aabb(trial_position, dimensions, yaw)
                    if not _contains(zone["bounds"], trial_box):
                        return None
                    for other_id, other in placed.items():
                        if other_id == parent["entity_id"]:
                            continue
                        if other_id in assembly:
                            # Parts of one assembly are MEANT to touch, so this
                            # test allows a little interpenetration and refuses
                            # only gross intersection.
                            #
                            # Strict zero-overlap was wrong in the case it is
                            # most needed. A sensor plate clamped exactly flush
                            # to a machine's face carried a display 3 cm deeper
                            # than itself, so the display protruded 1.5 cm back
                            # into the machine -- its own grandparent -- and was
                            # refused on all four variants. The entity went
                            # unplaced and took semantic_placement,
                            # requirement_traceability and the entity-count
                            # critic down with it, stopping a run that was
                            # otherwise correct over fifteen millimetres.
                            #
                            # The tolerance scales with the child so it stays
                            # meaningful at any size, and is capped so a large
                            # part cannot swallow a small sibling whole.
                            slack = min(0.05, min(dimensions) * 0.4)
                            shrunk = [
                                max(1e-4, value - slack * 2.0) for value in dimensions
                            ]
                            if _overlaps_oriented(
                                trial_position, shrunk, yaw, other
                            ):
                                return None
                            continue
                        # OVERLAP is refused; interaction clearance is not enforced.
                        #
                        # An attached child has no freedom to satisfy clearance: its
                        # position is its parent's plus a fixed offset, so a metre and a
                        # half of walking room is a demand it can only fail. The parent
                        # chose where the assembly stands and already answered for
                        # clearance when IT was placed; asking the door again just makes
                        # doors unplaceable near anything.
                        #
                        # Measured on run_9bb52892adfc42b39dfcc477934e7a54:
                        # `ent_gatehouse_door` was refused 22 times at clearance 1.50 --
                        # it is `openable`, so it carries 1.5 m -- and went unplaced,
                        # cascading to seven mandatory gates. The gatehouse itself is not
                        # `part_of` anything, so no assembly or adjacency exemption could
                        # ever have reached it; the demand was simply wrong for a body
                        # that cannot move.
                        #
                        # This mirrors the rule the module already states for hard
                        # adjacency: clearance is waived, "real geometric overlap is
                        # still refused".
                        if _overlaps(trial_box, other["world_aabb"], 0.0):
                            return None
                    return trial_position, trial_box, max(dropped, 0.0)

                resolved = None
                for index, variant in enumerate(seen_variants):
                    resolved = _evaluate(variant)
                    if resolved is None:
                        continue
                    if index:
                        soft_relaxations.append(
                            {
                                "entity_id": entity_id,
                                "constraint": "attachment_offset_direction",
                                "reason": (
                                    f"offset {[round(v, 2) for v in offset]} placed "
                                    f"this inside {attachment['target_id']}'s own "
                                    "assembly; mirrored to the outward face"
                                ),
                            }
                        )
                    break
                if resolved is not None:
                    position, candidate, lifted = resolved
                    if lifted > 1e-6:
                        soft_relaxations.append(
                            {
                                "entity_id": entity_id,
                                "constraint": "attachment_offset_y",
                                "reason": (
                                    f"attachment to {attachment['target_id']} placed "
                                    f"this {lifted:.2f} m below the ground plane; "
                                    "lifted to rest on it"
                                ),
                            }
                        )

                if resolved is None:
                    attachment_failed = True
                else:
                    parent_id = parent["entity_id"]
                    support = {
                        "type": "entity",
                        "target_id": parent_id,
                        "contact_y_m": candidate["min"][1],
                    }
                    accepted = {
                        "entity_id": entity_id,
                        "semantic_type": entity["semantic_type"],
                        "zone_id": zone["zone_id"],
                        "asset_ref": asset_ref,
                        "measurement_status": measurement_status,
                        "dimensions_m": [round(value, 4) for value in dimensions],
                        "transform": {
                            "position_m": position,
                            "rotation_y_degrees": round(yaw, 4),
                            "scale": [round(float(value), 6) for value in scale],
                        },
                        "world_aabb": candidate,
                        "support": support,
                        "interaction_clearance_m": clearance,
                        "dynamic": bool(entity["physical"]["dynamic"]),
                        "parent_id": parent_id,
                    }

        ranked_candidates: list[tuple[float, int, dict, str | None, str | None]] = []
        abandoned_near: str | None = None

        # Targets this entity has been explicitly required to sit against, plus
        # whatever those targets are themselves attached to. Clearance is waived
        # against these; overlap is not. See the collision check below.
        adjacency_exempt: set[str] = set()
        for relation in relations:
            if relation["subject_id"] != entity_id or not relation.get("hard"):
                continue
            if relation["relation"] not in {"near", "facing", "reachable_from"}:
                continue
            target_id = relation["target_id"]
            adjacency_exempt.add(target_id)
            adjacency_exempt.update(
                other["target_id"]
                for other in relations
                if other["subject_id"] == target_id
                and other["relation"] == "attached_to"
            )
        # `part_of` is adjacency by definition, and unlike the relations above it
        # does not need to be `hard` to mean it: it says these entities ARE one
        # thing. A wall's segments must abut -- that abutment is what makes it a
        # wall rather than a row of blocks -- and with interaction clearance
        # between them, half a 16-segment wall failed to place at all, every
        # other segment rejected against its own neighbour.
        adjacency_exempt.update(_part_of_group(entity_id, relations))
        # A child inherits its PARENT's assembly. `entities_conflict` names this case --
        # "transitive assemblies (stoop -> door -> house)" -- and the exemption never
        # reached the child.
        #
        # Measured twice: `ent_gatehouse_door` and `ent_ped_door` each failed to place
        # and took seven gates down by cascade. A door set into a gatehouse is openable,
        # so it carries 1.5 m of interaction clearance; the gatehouse is `part_of` a
        # perimeter wall run, so the door was measured against the wall segments beside
        # its own parent and refused. Nobody needs a metre and a half of walking room
        # between a door and the wall it is set into -- the door IS part of that wall,
        # by way of the thing it is attached to.
        for relation in relations:
            if (
                relation["subject_id"] == entity_id
                and relation["relation"] == "attached_to"
            ):
                parent = relation["target_id"]
                adjacency_exempt.add(parent)
                adjacency_exempt.update(_part_of_group(parent, relations))
        # Segments of DIFFERENT runs meet at corners and junctions, and a corner is not
        # somewhere a visitor walks up to a fence -- it is where two fences join.
        #
        # `part_of` waives interaction clearance within one run and cannot reach across
        # runs. Measured: with the ends inset so the boxes genuinely do not overlap
        # (0.015 m apart), the corner segment STILL failed, because the clearance rule
        # demanded 0.25 m between them. Overlap was never the whole story; clearance was
        # the rest of it.
        #
        # Every anchored, non-fronting entity is a run segment: its position is a fact
        # rather than a preference (ADR-0017). Overlap between them is still refused --
        # this waives only the room a visitor would need, which two joining walls do not.
        if (entity.get("placement") or {}).get("anchor_m") and not isinstance(
            (entity.get("placement") or {}).get("frontage"), dict
        ):
            adjacency_exempt.update(
                other["entity_id"]
                for other in spec.get("entities") or ()
                if (other.get("placement") or {}).get("anchor_m")
                and not isinstance((other.get("placement") or {}).get("frontage"), dict)
            )
        attempts = 0 if accepted is not None or attachment_failed else _ATTEMPTS
        for attempt in range(attempts):
            # The first 60% of attempts honour the preference; the rest fall
            # back to open ground rather than spending every attempt on a ring
            # that has already proved unsatisfiable.
            # Compose tightly first, widen only as attempts are spent: the
            # early darts land in the middle third of the zone, the last ones
            # anywhere in it.
            spread = _MIN_SPREAD + (1.0 - _MIN_SPREAD) * (
                attempt / max(attempts - 1, 1)
            )
            x, z, near_target, abandoned = _preferred_position(
                rng,
                entity,
                zone,
                placed,
                relations,
                relax=attempt * 5 >= attempts * 3,
                spread=spread,
            )
            # The ground under this candidate, not the plane it used to assume.
            # Still the unpadded field: pads cannot exist until every footprint is
            # known, and the second pass re-seats everything once they are.
            contact_y = terrain.height_at(x, z)
            if support_relation:
                parent = placed[support_relation["target_id"]]
                x = parent["transform"]["position_m"][0]
                z = parent["transform"]["position_m"][2]
                contact_y = parent["world_aabb"]["max"][1]
                parent_id = support_relation["target_id"]
                support = {
                    "type": "entity",
                    "target_id": parent_id,
                    "contact_y_m": contact_y,
                }
            position = [round(x, 4), round(contact_y + dimensions[1] / 2.0, 4), round(z, 4)]
            authored_placement = entity.get("placement") or {}
            authored_yaw = authored_placement.get("anchor_yaw_degrees")
            # A house that gave up its plot has nothing to face. Keeping the street's
            # angle would leave it squared to a lane it no longer stands on, which
            # reads as a mistake rather than as a fallback.
            if authored_yaw is not None and (
                position[0] == round(float(authored_placement["anchor_m"][0]), 4)
                and position[2] == round(float(authored_placement["anchor_m"][1]), 4)
                if authored_placement.get("anchor_m")
                else True
            ):
                # A run's direction is the whole point of the run. Left to the random
                # branch below, every segment of a diagonal wall would face a
                # different way and the wall would read as a heap.
                yaw = round(float(authored_yaw), 4)
            elif near_target is not None and entity["asset"]["category"] == "structure":
                target_position = placed[near_target]["transform"]["position_m"]
                yaw = round(
                    math.degrees(math.atan2(target_position[0] - x, -(target_position[2] - z))),
                    4,
                )
            else:
                yaw = round(rng.uniform(0.0, 360.0), 4)
            candidate = _aabb(position, dimensions, yaw)
            # A boundary wall belongs on the boundary.
            #
            # Zones are inset from the world, so a run declared along the world's edge
            # falls outside its zone and every segment is rejected -- for being exactly
            # where a boundary wall goes. Measured by replaying the corpus specs: nine
            # of a town square's unplaced entities were its eastern wall, and four of a
            # workshop's were its west, north and east walls.
            #
            # Only for an entity whose position is a FACT. A dart-thrown object still
            # has to land inside its zone: the inset exists so free content does not
            # pile against the edges, and that reasoning is untouched here.
            containing = (
                world_bounds
                if (entity.get("placement") or {}).get("anchor_m")
                else zone["bounds"]
            )
            if not _contains(containing, candidate):
                continue
            collision = False
            for other_id, other in placed.items():
                if other_id == parent_id:
                    continue
                # An explicit hard adjacency outranks a default clearance.
                #
                # `interaction_clearance_m` defaults to 1.5 m -- the room a
                # player needs to walk up to a thing -- and is enforced against
                # everything. But a spec that says "stoop within 0.5 m of the
                # door, HARD" has stated that these belong against each other,
                # and the door is set into a house that demands 1.5 m of space
                # around itself. The two rules are then contradictory and the
                # stated one lost: both stoops in a two-house village failed to
                # place, every time, because no point can be both 0.5 m from the
                # door and 1.5 m clear of the wall holding it.
                #
                # So a hard adjacency waives CLEARANCE against its target, and
                # against whatever that target is attached to -- a stoop admitted
                # next to the door is necessarily next to the house. Nothing is
                # relaxed: real geometric overlap is still refused below, and
                # soft relations get no exemption at all.
                if entities_conflict(
                    position,
                    dimensions,
                    yaw,
                    clearance,
                    other,
                    adjacent=other_id in adjacency_exempt,
                    own_id=entity_id,
                ):
                    collision = True
                    break
            if collision:
                continue
            candidate_body = {
                "entity_id": entity_id,
                "semantic_type": entity["semantic_type"],
                "zone_id": zone["zone_id"],
                "asset_ref": asset_ref,
                "measurement_status": measurement_status,
                "dimensions_m": [round(value, 4) for value in dimensions],
                "transform": {
                    "position_m": position,
                    "rotation_y_degrees": yaw,
                    "scale": [round(float(value), 6) for value in scale],
                },
                "world_aabb": candidate,
                "support": support,
                "interaction_clearance_m": clearance,
                "dynamic": bool(entity["physical"]["dynamic"]),
                "parent_id": parent_id,
            }
            if placement_ranker is None:
                accepted = candidate_body
                used_near_target = near_target
                abandoned_near = abandoned
                break
            zone_center_x = (zone["bounds"]["min"][0] + zone["bounds"]["max"][0]) / 2
            zone_center_z = (zone["bounds"]["min"][2] + zone["bounds"]["max"][2]) / 2
            near_distance = 0.0
            if near_target is not None:
                target_position = placed[near_target]["transform"]["position_m"]
                near_distance = math.hypot(x - target_position[0], z - target_position[2])
            edge_clearance = min(
                candidate["min"][0] - zone["bounds"]["min"][0],
                zone["bounds"]["max"][0] - candidate["max"][0],
                candidate["min"][2] - zone["bounds"]["min"][2],
                zone["bounds"]["max"][2] - candidate["max"][2],
            )
            features = {
                "distance_to_zone_center_m": math.hypot(
                    x - zone_center_x, z - zone_center_z
                ),
                "distance_to_near_target_m": near_distance,
                "edge_clearance_m": edge_clearance,
                "interaction_clearance_m": clearance,
                "dynamic": bool(entity["physical"]["dynamic"]),
                "has_near_target": near_target is not None,
                "candidate_index": attempt,
            }
            try:
                score = float(placement_ranker.score(features))
                if not math.isfinite(score):
                    score = 0.0
            except Exception:
                score = 0.0
            ranked_candidates.append(
                (score, -attempt, candidate_body, near_target, abandoned)
            )

        if accepted is None and ranked_candidates:
            _, _, accepted, used_near_target, abandoned_near = max(
                ranked_candidates, key=lambda item: (item[0], item[1])
            )
        if accepted is not None and abandoned_near is not None:
            soft_relaxations.append(
                {
                    "entity_id": entity_id,
                    "constraint": "near",
                    "reason": (
                        f"no position near {abandoned_near} satisfied the hard "
                        "constraints; placed on open ground in the same zone"
                    ),
                }
            )

        # A house that gave up its plot on the street. Detected by comparing where it
        # landed with where frontage put it, rather than by threading another flag out
        # of the candidate loop -- the position IS the evidence, and a flag could
        # disagree with it. Disclosed because somebody asked for a building on a lane
        # and has got one off it (rules 11/13).
        frontage_anchor = (entity.get("placement") or {}).get("anchor_m")
        if (
            accepted is not None
            and frontage_anchor
            and isinstance((entity.get("placement") or {}).get("frontage"), dict)
        ):
            landed = accepted["transform"]["position_m"]
            try:
                moved = math.dist(
                    (landed[0], landed[2]),
                    (float(frontage_anchor[0]), float(frontage_anchor[1])),
                )
            except (TypeError, ValueError):
                moved = 0.0
            if moved > 0.05:
                route_id = str(
                    (entity["placement"]["frontage"] or {}).get("route_id") or "its route"
                )
                soft_relaxations.append(
                    {
                        "entity_id": entity_id,
                        "constraint": "frontage",
                        "reason": (
                            f"its plot on {route_id} was already occupied, so it stands "
                            f"{moved:.0f} m away on open ground instead of on the street"
                        ),
                    }
                )

        if accepted is None:
            unplaced.append(entity_id)
            hard_results.append(
                {
                    "constraint": "place_entity",
                    "entity_id": entity_id,
                    "status": "FAIL",
                    "code": "NO_HARD_CONSTRAINT_SOLUTION",
                }
            )
            continue
        placed[entity_id] = accepted
        hard_results.extend(
            [
                {
                    "constraint": "inside_zone",
                    "entity_id": entity_id,
                    "status": "PASS",
                },
                {
                    "constraint": "non_overlapping_with_clearance",
                    "entity_id": entity_id,
                    "status": "PASS",
                },
                {
                    "constraint": "supported",
                    "entity_id": entity_id,
                    "status": "PASS",
                },
            ]
        )
        requested_near = any(
            relation["subject_id"] == entity_id and relation["relation"] == "near"
            for relation in relations
        )
        # `abandoned_near` means the target WAS available and no position beside
        # it worked -- already reported just above, with the real reason. Without
        # this guard the same placement is also blamed on the target being
        # missing, which is a different fault and was not what happened.
        if requested_near and used_near_target is None and abandoned_near is None:
            soft_relaxations.append(
                {
                    "entity_id": entity_id,
                    "constraint": "near",
                    "reason": "target was not placeable before the subject",
                }
            )

    # Same right-sizing as the zone geometry, so world_bounds and the zones that
    # sit inside it can never disagree about how big the world is.
    width, depth, max_height = _content_scaled_dimensions(spec)
    navigation_paths, path_results = _navigation_paths(relations, placed, spec.get("routes") or [])
    hard_results.extend(path_results)
    entity_reachability = [
        {
            "from": "ent_controlled_actor",
            "to_entity": path["from_entity_id"],
            "status": "PLANNED",
        }
        for path in navigation_paths
        if path["status"] == "CONNECTED"
    ]
    # Scatter is laid down LAST, against the already-solved entities, so mass
    # content can never displace or block the objects that matter. An empty
    # `scatter` section in the spec yields no instances and costs nothing.
    # Trim the world to what placement actually used, BEFORE scattering.
    #
    # The extent is chosen ahead of placement and has to be generous: seeded
    # dart-throwing needs far more room than the content occupies, and every
    # attempt to size it down broke placement on real specs. Placement then
    # composes the content into the middle, leaving the declared world ~2.5x the
    # ground anything stands on -- and the writer builds the ground mesh straight
    # from these bounds, so a village 23 m across shipped on a 73 m slab and the
    # overview read as an empty plain.
    #
    # Sizing generously and then trimming gets both. It must happen here rather
    # than after `instance_scatter`, because scatter fills the zones it is given:
    # trimming afterwards either leaves grass hanging past the edge or, if the
    # scatter is counted, cancels the trim entirely (measured -- the world did
    # not move a metre).
    if placed:
        reach_x = max(
            abs(value)
            for entity in placed.values()
            for value in (entity["world_aabb"]["min"][0], entity["world_aabb"]["max"][0])
        )
        reach_z = max(
            abs(value)
            for entity in placed.values()
            for value in (entity["world_aabb"]["min"][2], entity["world_aabb"]["max"][2])
        )
        # Symmetric about the origin, matching the untrimmed shape, and only ever
        # brought in -- never grown.
        trimmed_width = min(width, 2.0 * (reach_x + _WORLD_MARGIN_M))
        trimmed_depth = min(depth, 2.0 * (reach_z + _WORLD_MARGIN_M))

        # ...but not in past the ground the scatter needs. The trim measures the reach of
        # placed ENTITIES, which is right for a village and wrong for a wood: a forest
        # spec had six entities and 1,295 scattered things, so it trimmed to 37x27 m and
        # the canopy hit its packing limit at FOUR trees --
        #
        #     spc_canopy_tree: requested 26, placed 4,
        #                      shortfall_reason "packing_limit", spacing_m 11.2996
        #
        # An 11 m crown is a real mature tree, so 999 m2 of ground holds about eight of
        # them however they are sampled. The world was the constraint, not the sampler.
        #
        # Safe in a way that pre-placement sizing is not: this runs AFTER placement has
        # solved, so widening the floor cannot unplace anything -- which is what happened
        # when the world was shrunk BEFORE placement (18/18 gates to 8/18). It only ever
        # gives back ground the trim was about to take, never more than there was.
        needed = _ground_the_scatter_needs(spec, descriptors)
        if needed > trimmed_width * trimmed_depth:
            scale = min(
                (needed / (trimmed_width * trimmed_depth)) ** 0.5,
                # Never more ground than there was before the trim: this gives back what
                # trimming was about to take, and cannot invent a larger world.
                min(width / trimmed_width, depth / trimmed_depth),
                # And never a runaway. A `warehouse_interior` spec declares a scatter
                # species 60 m across inside a 2,400 m2 building and would ask for
                # 28,800 m2 -- twelve times its own world. That is a planner mistake and
                # this is not the place to amplify it; a bounded correction fixes the
                # forest (which needs 1.02x) without acting on nonsense.
                _MOST_GROUND_A_TRIM_GIVES_BACK**0.5,
            )
            trimmed_width *= scale
            trimmed_depth *= scale
        width, depth = trimmed_width, trimmed_depth
        half_x, half_z = width / 2.0, depth / 2.0
        for zone in zones:
            bounds = zone["bounds"]
            bounds["min"][0] = round(max(bounds["min"][0], -half_x), 4)
            bounds["max"][0] = round(min(bounds["max"][0], half_x), 4)
            bounds["min"][2] = round(max(bounds["min"][2], -half_z), 4)
            bounds["max"][2] = round(min(bounds["max"][2], half_z), 4)

    # Level the ground under what was placed, then seat everything on the result.
    # Only terrain-supported bodies pad: a lamp resting on a table does not flatten
    # the floor, and its height comes from the table.
    footprints = [
        (
            record["transform"]["position_m"][0],
            record["transform"]["position_m"][2],
            record["world_aabb"]["max"][0] - record["world_aabb"]["min"][0],
            record["world_aabb"]["max"][2] - record["world_aabb"]["min"][2],
        )
        for record in placed.values()
        if record["support"]["type"] == "terrain"
    ]
    terrain = terrain.with_pads(footprints)
    _reseat_on_terrain(placed, terrain)

    # Inside the walls, when the spec drew a closed ring of them: mass content belongs
    # in the building the prompt is about, not on the ground beside it.
    from pcg.enclosure import enclosure_extent

    scatter = instance_scatter(
        spec,
        zones,
        list(placed.values()),
        descriptors,
        terrain=terrain,
        enclosure=enclosure_extent(spec.get("linear_structures")),
    )

    # Declared ground surfaces, painted onto the terrain's OWN lattice.
    #
    # Sampling at a different resolution would put the seam between two surfaces
    # somewhere other than where the ground changes shape, so the region grid and the
    # height grid are deliberately the same grid. A world with no regions gets a grid
    # of zeros, which the writer and the runtime both treat as "unchanged".
    terrain_payload = terrain.as_payload()
    surface_grid, surface_families, region_notes = paint_regions(
        spec, terrain.width_m, terrain.depth_m, terrain.grid
    )
    if any(surface_grid):
        terrain_payload["surface_grid"] = surface_grid
        terrain_payload["surface_families"] = surface_families

    plan = {
        # 1.1.0 only when the plan actually carries scatter, so a consumer reading
        # 1.0.0 can trust the older shape (same rule as the spec contract).
        "schema_version": "1.1.0" if scatter["instances"] else "1.0.0",
        "simulation_id": spec["meta"]["simulation_id"],
        "seed": spec["meta"]["seed"],
        "world_bounds": {
            # The floor is the lowest ground, not zero: heights are centred on the
            # origin so roughly half the field is below it, and a bounds box that
            # excluded the ground it describes would be wrong about the world.
            "min": [-width / 2, round(min(0.0, min(terrain.heights)), 4), -depth / 2],
            "max": [width / 2, max_height, depth / 2],
        },
        # Shipped with the plan because it is generated here and nowhere else. The
        # extent is the terrain's own, which can exceed the trimmed world bounds --
        # the field is built before placement and the bounds are pulled in after --
        # so a consumer must size the ground from this block, not from world_bounds,
        # or the mesh and the sampled heights will not agree.
        "terrain": terrain_payload,
        "zones": zones,
        "entities": list(placed.values()),
        "behaviours": list(behaviour_graphs or []),
        "relationships": list(relations),
        "navigation": {
            "regions": [zone["zone_id"] for zone in zones],
            "required_reachability": [
                {
                    "from": "ent_controlled_actor",
                    "to_zone": zone["zone_id"],
                    "status": "PLANNED",
                }
                for zone in zones
            ] + entity_reachability,
            "paths": navigation_paths,
        },
        "constraint_summary": {
            "hard_constraints": hard_results,
            "soft_relaxations": soft_relaxations,
            "unplaced_entities": unplaced,
            # ADR-0020. The prompt decides which of these matters: a required thing
            # missing is an incomplete world, a fence segment missing is a gap in a
            # fence. Split here because the validator receives only the plan.
            **_classify_unplaced(spec, unplaced),
            # Entities whose position is a FACT rather than a preference: run segments.
            # The placer waives interaction clearance between them, and the validator
            # gets only the plan, so the set has to travel -- otherwise the two disagree
            # and a corner that placed cleanly is reported as a clearance violation.
            # That drift is exactly what `entities_conflict` exists to prevent, and it
            # is the seventh time these two have parted company.
            "anchored_entities": sorted(
                str(entity.get("entity_id"))
                for entity in (spec.get("entities") or ())
                if (entity.get("placement") or {}).get("anchor_m")
                and not isinstance((entity.get("placement") or {}).get("frontage"), dict)
            ),
            # Frontage the route could not honour. Recorded on the plan because that
            # is what the report reads; an approximation nobody can see is not one.
            "frontage_notes": frontage_notes,
            # Areas that could not be painted -- smaller than a grid cell, or off
            # the world. Same channel as frontage, for the same reason: a courtyard
            # that vanished is one somebody asked for.
            "region_notes": region_notes,
        },
    }
    if scatter["instances"]:
        plan["scatter"] = scatter
    validate_world_plan_schema(plan)
    return plan


def validate_semantic_world_plan(
    plan: dict,
    *,
    require_measured_assets: bool = True,
) -> dict:
    """Independently re-check the serialized plan rather than trust the solver."""
    errors: list[dict] = []
    # Read the shipped field rather than regenerate it: the validator has to check
    # the plan that will actually be built, not one it recomputes and agrees with.
    bounds = plan.get("world_bounds") or {}
    field = terrain_from_payload(
        plan.get("terrain"),
        abs(float((bounds.get("max") or [0, 0, 0])[0]) * 2.0),
        abs(float((bounds.get("max") or [0, 0, 0])[2]) * 2.0),
    )
    try:
        validate_world_plan_schema(plan)
    except jsonschema.ValidationError as exc:
        return {
            "status": "FAIL",
            "errors": [
                {
                    "code": "WORLD_PLAN_SCHEMA_INVALID",
                    "path": list(exc.absolute_path),
                    "message": exc.message,
                }
            ],
        }

    zone_by_id = {zone["zone_id"]: zone for zone in plan["zones"]}
    entities = plan["entities"]
    anchored_set = set(
        (plan.get("constraint_summary") or {}).get("anchored_entities") or ()
    )
    # The union of the zones plus the margin the inset takes back -- the same box the
    # placer uses for an anchored entity, so the two cannot disagree.
    world_extent = {
        "min": [
            min(zone["bounds"]["min"][0] for zone in plan["zones"]) - _BOUNDARY_MARGIN_M,
            -1e6,
            min(zone["bounds"]["min"][2] for zone in plan["zones"]) - _BOUNDARY_MARGIN_M,
        ],
        "max": [
            max(zone["bounds"]["max"][0] for zone in plan["zones"]) + _BOUNDARY_MARGIN_M,
            1e6,
            max(zone["bounds"]["max"][2] for zone in plan["zones"]) + _BOUNDARY_MARGIN_M,
        ],
    } if plan.get("zones") else {"min": [-1e6] * 3, "max": [1e6] * 3}

    seen: set[str] = set()
    for entity in entities:
        if entity["entity_id"] in seen:
            errors.append(
                {"code": "DUPLICATE_ENTITY", "entity_id": entity["entity_id"]}
            )
        seen.add(entity["entity_id"])
        zone = zone_by_id.get(entity["zone_id"])
        # A boundary wall belongs on the boundary, and zones are inset from the world.
        # The placer bounds an ANCHORED entity by the world rather than by its zone for
        # exactly that reason; checking it against the inset zone here reports a wall
        # for being where a wall goes. Eighth time the placer and validator have parted
        # company, always the same shape: one side learns a rule and the other does not.
        anchored_here = entity["entity_id"] in anchored_set
        containing = world_extent if anchored_here else (zone or {}).get("bounds")
        if containing is None or not _contains(containing, entity["world_aabb"]):
            errors.append(
                {"code": "ENTITY_OUTSIDE_ZONE", "entity_id": entity["entity_id"]}
            )
        # "Supported by the terrain" means the body's underside meets the ground
        # under it. This used to assert the underside was at y=0, which is the same
        # statement only while the ground is a plane -- and it is the check that
        # catches a prop left floating above a hill or buried inside it.
        if (
            entity["support"]["type"] == "terrain"
            and abs(
                entity["world_aabb"]["min"][1]
                - field.height_at(
                    entity["transform"]["position_m"][0],
                    entity["transform"]["position_m"][2],
                )
            )
            > 1e-3
        ):
            errors.append(
                {"code": "INVALID_TERRAIN_SUPPORT", "entity_id": entity["entity_id"]}
            )
        if require_measured_assets and entity["measurement_status"] != "MEASURED":
            errors.append(
                {
                    "code": "ASSET_NOT_MEASURED",
                    "entity_id": entity["entity_id"],
                    "status": entity["measurement_status"],
                }
            )
    # The validator has to judge an assembly by the same rule the placer built
    # it with, or the two disagree and a sound world is failed.
    #
    # Skipping only DIRECT parent/child pairs meant a stoop attached to a door
    # attached to a house was still measured against the house -- with the full
    # 1.5 m interaction clearance, and on axis-aligned boxes, so a building
    # turned a few degrees swallowed its own doorstep. Placement had already
    # accepted exactly this arrangement. `assembly_of` walks the parent chain so
    # the whole doorway is one object here too, and inside it only a real
    # oriented overlap counts.
    by_entity_id = {entity["entity_id"]: entity for entity in entities}

    # Pairs the SPEC required to be adjacent, by any route.
    #
    # Placement waives interaction clearance between two things a hard relation
    # says belong together, and judges them on their true footprints instead.
    # The validator only knew about `parent_id`, so a stoop held against its
    # house by a hard `near` -- no parent link -- was re-measured with the full
    # 1.5 m clearance and failed a placement the placer had deliberately
    # allowed. Second time the two have disagreed; the rule has to be stated
    # once and read by both.
    adjacent_pairs: set[frozenset[str]] = set()
    part_of_edges: list[tuple[str, str]] = []

    # Run segments, as recorded by the placer. Every pair among them is adjacent: two
    # fences meeting at a corner are joining, not standing near each other, so the room
    # a visitor needs to walk up to one does not apply between them. Overlap is still
    # judged normally.
    anchored = [
        entity_id
        for entity_id in (plan.get("constraint_summary") or {}).get("anchored_entities")
        or ()
        if entity_id in by_entity_id
    ]
    for index, left_id in enumerate(anchored):
        for right_id in anchored[index + 1 :]:
            adjacent_pairs.add(frozenset((left_id, right_id)))
    for relation in plan.get("relationships") or []:
        # `part_of` is exempt whether or not it is hard: it is not a preference
        # about where two things go, it is a statement that they are one thing.
        # Requiring `hard` here would have let the placer allow a wall the
        # validator then rejected -- the sixth time these two have disagreed, and
        # the reason entities_conflict exists.
        if relation.get("relation") == "part_of":
            part_of_edges.append(
                (relation["subject_id"], relation["target_id"])
            )
            adjacent_pairs.add(
                frozenset((relation["subject_id"], relation["target_id"]))
            )
            continue
        if not relation.get("hard"):
            continue
        if relation.get("relation") not in {
            "near", "facing", "reachable_from", "attached_to", "supported_by",
        }:
            continue
        adjacent_pairs.add(
            frozenset((relation["subject_id"], relation["target_id"]))
        )

    # Transitively: segment 5 and segment 9 of one wall are one object even
    # though both point only at segment 0.
    group_edges: dict[str, set[str]] = {}
    for subject, target in part_of_edges:
        group_edges.setdefault(subject, set()).add(target)
        group_edges.setdefault(target, set()).add(subject)
    for node in list(group_edges):
        seen = {node}
        queue = [node]
        while queue:
            for neighbour in group_edges.get(queue.pop(), ()):
                if neighbour not in seen:
                    seen.add(neighbour)
                    queue.append(neighbour)
        for member in seen:
            if member != node:
                adjacent_pairs.add(frozenset((node, member)))

    assembly_of: dict[str, str] = {}
    for entity in entities:
        root = entity["entity_id"]
        seen = {root}
        while True:
            parent = by_entity_id.get(root, {}).get("parent_id")
            if not parent or parent in seen:
                break
            root = parent
            seen.add(root)
        assembly_of[entity["entity_id"]] = root

    for index, left in enumerate(entities):
        for right in entities[index + 1 :]:
            if left["parent_id"] == right["entity_id"] or right["parent_id"] == left["entity_id"]:
                continue
            # Same question, same answer: one definition, in entities_conflict.
            adjacent = (
                assembly_of[left["entity_id"]] == assembly_of[right["entity_id"]]
                or frozenset((left["entity_id"], right["entity_id"])) in adjacent_pairs
                # A rigidly attached body waives clearance against everything, because it
                # has no freedom to satisfy it -- its position is its parent's plus a
                # fixed offset. The placer waives it (see the attached-child branch); if
                # this side did not, the two would disagree about every door in every
                # world, which is the tenth time this check has drifted. Overlap is still
                # refused: `adjacent` only relaxes CLEARANCE.
                or bool(left.get("parent_id"))
                or bool(right.get("parent_id"))
            )
            if entities_conflict(
                left["transform"]["position_m"],
                left["dimensions_m"],
                left["transform"]["rotation_y_degrees"],
                float(left["interaction_clearance_m"]),
                right,
                adjacent=adjacent,
                own_id=left["entity_id"],
                # The support record, which the placer also passes. Omitting it here
                # defaulted `own_support` to None, which reads as "on the ground", so a
                # door attached two metres up a wall was judged as if it stood on the
                # ground and everything beneath it conflicted. Measured on
                # run_b6234550ab5f44078eb2450d786ca77e: a garden hose 0.9 m from a
                # service door failed the mandatory placement gate, while the placer --
                # which does pass it -- had correctly seen the door pass overhead.
                #
                # Two callers, one question, and the answer differed by an argument.
                # That is the ninth time this check has drifted; the parameter is the
                # drift, so it is passed from both sides now.
                own_support=left.get("support"),
            ):
                errors.append(
                    {
                        "code": "ENTITY_OVERLAP_OR_CLEARANCE",
                        "entity_ids": [left["entity_id"], right["entity_id"]],
                    }
                )
    # ADR-0020: only entities the prompt asked for. An incidental one is reported as an
    # approximation by the pipeline instead, which is what every other stage already
    # does when it cannot fully deliver. `unplaced_entities` is untouched, so nothing is
    # hidden from anyone reading the plan.
    #
    # Falls back to the whole list when the split is absent: a plan written before this
    # change, or preserved through a repair, must not silently start passing.
    summary = plan["constraint_summary"]
    blocking = summary.get("unplaced_required")
    if blocking is None:
        blocking = summary["unplaced_entities"]
    for missing in blocking:
        errors.append({"code": "ENTITY_UNPLACED", "entity_id": missing})
    path_by_id = {
        path["path_id"]: path for path in plan.get("navigation", {}).get("paths", [])
    }
    for path in path_by_id.values():
        if path["status"] != "CONNECTED":
            errors.append({"code": "PATH_UNRESOLVED", "path_id": path["path_id"]})
            continue
        source = next(
            (item for item in entities if item["entity_id"] == path["from_entity_id"]),
            None,
        )
        target = next(
            (item for item in entities if item["entity_id"] == path["to_entity_id"]),
            None,
        )
        if source is None or target is None:
            errors.append({"code": "PATH_ENDPOINT_MISSING", "path_id": path["path_id"]})
            continue
        excluded = {
            source["entity_id"],
            target["entity_id"],
            source.get("parent_id"),
            target.get("parent_id"),
        }
        placed_by_id = {item["entity_id"]: item for item in entities}
        if not _path_is_clear(
            path["points_m"], placed_by_id, excluded, path["width_m"]
        ):
            errors.append({"code": "PATH_INTERSECTS_OBSTACLE", "path_id": path["path_id"]})

    if not errors:
        return {
            "status": "PASS",
            "errors": [],
            "evidence": {
                "entity_count": len(entities),
                "zone_count": len(plan["zones"]),
                "measured_entity_count": sum(
                    item["measurement_status"] == "MEASURED" for item in entities
                ),
                "soft_relaxations": plan["constraint_summary"]["soft_relaxations"],
            },
        }
    only_measurement = all(error["code"] == "ASSET_NOT_MEASURED" for error in errors)
    return {
        "status": "NOT_RUN" if only_measurement else "FAIL",
        "errors": errors,
        "evidence": {
            "entity_count": len(entities),
            "unplaced_entities": plan["constraint_summary"]["unplaced_entities"],
        },
    }
