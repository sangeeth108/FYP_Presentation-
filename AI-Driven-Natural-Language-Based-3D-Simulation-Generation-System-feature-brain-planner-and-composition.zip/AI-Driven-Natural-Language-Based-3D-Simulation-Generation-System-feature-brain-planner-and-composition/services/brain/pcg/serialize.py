"""Level-plan serialization: PCGOutput -> stable JSON for the Godot worker.

This dict/JSON shape is the contract between the brain's S4 output and the
worker's 3D materialization (`services/worker/godot_client/`, GridMap kits +
navmesh + node instancing). Keep it flat, snake_case, and version-tagged —
the worker validates `level_plan_version` before consuming.

Output is byte-stable for identical inputs (sorted keys, fixed separators,
no floats introduced beyond what PCG produced) so a level plan can be
hashed for lineage the same way specs are.
"""

from __future__ import annotations

import json

from pcg.pipeline import PCGOutput

LEVEL_PLAN_VERSION = "1.0.0"


def to_level_plan(out: PCGOutput) -> dict:
    """Convert a PCGOutput into a plain-JSON dict (the worker's input)."""
    return {
        "level_plan_version": LEVEL_PLAN_VERSION,
        "seed": out.graph.seed,
        "algorithm": out.graph.algorithm,
        "zones": [
            {"zone_id": z.zone_id, "kind": z.kind, "tier": z.tier}
            for z in out.graph.zones
        ],
        "rooms": [
            {
                "zone_id": room.zone_id,
                "x": room.rect.x,
                "z": room.rect.z,
                "width": room.rect.width,
                "depth": room.rect.depth,
                "elevation": room.elevation,
            }
            for room in sorted(out.layout.rooms.values(), key=lambda r: r.zone_id)
        ],
        "corridors": [
            {
                "a": c.a,
                "b": c.b,
                "kind": c.kind,
                "width": c.width,
                "points": [[x, z] for x, z in c.points],
            }
            for c in out.layout.corridors
        ],
        "entities": [
            {
                "entity_id": e.entity_id,
                "source_id": e.source_id,
                "kind": e.kind,
                "zone_id": e.zone_id,
                "x": e.x,
                "z": e.z,
                "elevation": e.elevation,
            }
            for e in out.placement.entities
        ],
        # Entities the level physically could not hold (a capped roster). Part of
        # the plan, so it lands in the artifact and the lineage record rather than
        # quietly vanishing between the spec and the game.
        "dropped": out.placement.dropped,
    }


def to_level_plan_json(out: PCGOutput) -> str:
    """Byte-stable JSON string (hashable for lineage records)."""
    return json.dumps(to_level_plan(out), sort_keys=True, separators=(",", ":"))
