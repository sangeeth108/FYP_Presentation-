"""Seeded procedural content generation (S4 — deterministic spine).

Everything here must be reproducible from the recorded seed alone
(CLAUDE.md rule 14): same seed + same spec fields => byte-identical output.
"""

from pcg.layout import Corridor, Layout, Rect, RoomPlacement, generate_layout
from pcg.pipeline import PCGOutput, run_pcg
from pcg.placement import (
    EnemySpec,
    PlacedEntity,
    PlacementResult,
    PropSpec,
    generate_placement,
)
from pcg.serialize import LEVEL_PLAN_VERSION, to_level_plan, to_level_plan_json
from pcg.zone_graph import Edge, PCGError, Zone, ZoneGraph, generate_zone_graph

__all__ = [
    "Corridor",
    "Edge",
    "EnemySpec",
    "LEVEL_PLAN_VERSION",
    "Layout",
    "PCGError",
    "PlacedEntity",
    "PlacementResult",
    "PropSpec",
    "PCGOutput",
    "Rect",
    "RoomPlacement",
    "Zone",
    "ZoneGraph",
    "generate_layout",
    "generate_placement",
    "generate_zone_graph",
    "run_pcg",
    "to_level_plan",
    "to_level_plan_json",
]
