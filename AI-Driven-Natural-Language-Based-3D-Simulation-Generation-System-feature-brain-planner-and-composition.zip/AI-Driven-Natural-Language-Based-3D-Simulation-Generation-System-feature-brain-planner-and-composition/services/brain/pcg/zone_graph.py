"""Seeded zone-graph generator (S4, step 1 of the deterministic spine).

Consumes the ``world.zone_graph`` fields of a validated game_spec
(``algorithm``, ``zone_count``, ``verticality_tiers``) plus ``meta.seed``
and produces an abstract zone graph that later stages materialize into
GridMap geometry. Guarantees:

- deterministic: identical inputs => identical graph (uses its own
  ``random.Random(seed)``, never the global RNG);
- connected: every zone reachable from the entry zone;
- exactly one ``entry`` and one ``exit`` zone, with a ``key`` zone on the
  critical path and a ``locked`` edge into the exit (the lock/key pattern
  proven by the golden game's lever -> locked door -> escape loop).

Spec mapping: world.zone_graph.* in contracts/game_spec.schema.json.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field

ALGORITHMS_IMPLEMENTED = ("room_corridor", "bsp", "cellular_caves", "wfc_dressing")
CAVE_LOOP_CHANCE = 0.35  # caves are warren-like: much loopier than corridors

# wfc_dressing: kind adjacency constraints (miniature Wave Function Collapse
# over the graph — the "dressing" pass the algorithm is named for).
WFC_INCOMPATIBLE: set[frozenset] = {
    frozenset(("loot", "loot")),      # loot rooms never adjacent (pacing)
    frozenset(("combat", "key")),     # a breather room guards the key
    frozenset(("empty", "empty")),    # no dead stretches
}
MIN_ZONES, MAX_ZONES = 3, 20  # mirrors schema bounds
MIDDLE_KINDS = ("combat", "loot", "empty")
EXTRA_EDGE_CHANCE = 0.15


class PCGError(ValueError):
    """Machine-readable PCG failure (CLAUDE.md rule 13)."""

    def __init__(self, code: str, path: str, message: str, hint: str) -> None:
        super().__init__(message)
        self.code = code
        self.path = path
        self.message = message
        self.hint = hint

    def to_dict(self) -> dict:
        return {
            "code": self.code,
            "path": self.path,
            "message": self.message,
            "hint": self.hint,
        }


@dataclass(frozen=True)
class Zone:
    zone_id: str
    kind: str  # entry | combat | loot | empty | key | exit
    tier: int  # 0-based verticality tier


@dataclass(frozen=True)
class Edge:
    a: str
    b: str
    kind: str  # open | locked


@dataclass
class ZoneGraph:
    seed: int
    algorithm: str
    zones: list[Zone] = field(default_factory=list)
    edges: list[Edge] = field(default_factory=list)

    def neighbors(self, zone_id: str) -> list[str]:
        out: list[str] = []
        for e in self.edges:
            if e.a == zone_id:
                out.append(e.b)
            elif e.b == zone_id:
                out.append(e.a)
        return out

    def is_connected(self) -> bool:
        if not self.zones:
            return False
        seen = {self.zones[0].zone_id}
        frontier = [self.zones[0].zone_id]
        while frontier:
            for nxt in self.neighbors(frontier.pop()):
                if nxt not in seen:
                    seen.add(nxt)
                    frontier.append(nxt)
        return len(seen) == len(self.zones)


def generate_zone_graph(
    seed: int,
    zone_count: int,
    algorithm: str = "room_corridor",
    verticality_tiers: int = 1,
) -> ZoneGraph:
    """Build a connected, seeded zone graph. Raises PCGError on bad input."""
    if not MIN_ZONES <= zone_count <= MAX_ZONES:
        raise PCGError(
            code="zone_count_out_of_range",
            path="world.zone_graph.zone_count",
            message=f"zone_count {zone_count} outside [{MIN_ZONES}, {MAX_ZONES}]",
            hint="Pick a zone_count within the schema bounds.",
        )
    if not 1 <= verticality_tiers <= 3:
        raise PCGError(
            code="verticality_out_of_range",
            path="world.zone_graph.verticality_tiers",
            message=f"verticality_tiers {verticality_tiers} outside [1, 3]",
            hint="Use 1-3 elevation tiers.",
        )
    if algorithm not in ALGORITHMS_IMPLEMENTED:
        raise PCGError(
            code="algorithm_not_implemented",
            path="world.zone_graph.algorithm",
            message=f"algorithm '{algorithm}' is not implemented yet",
            hint=f"Implemented: {', '.join(ALGORITHMS_IMPLEMENTED)}.",
        )

    rng = random.Random(seed)
    if algorithm == "bsp":
        zones, edges = _build_bsp(rng, zone_count, verticality_tiers)
    elif algorithm == "cellular_caves":
        zones, edges = _build_cellular_caves(rng, zone_count, verticality_tiers)
    elif algorithm == "wfc_dressing":
        zones, edges = _build_wfc_dressing(rng, zone_count, verticality_tiers)
    else:
        zones, edges = _build_room_corridor(rng, zone_count, verticality_tiers)

    zones = _bridgeable_tiers(zones, edges)
    graph = ZoneGraph(seed=seed, algorithm=algorithm, zones=zones, edges=edges)
    if not graph.is_connected():  # defensive: both constructions guarantee it
        raise PCGError(
            code="graph_disconnected",
            path="world.zone_graph",
            message="generated graph is not fully connected",
            hint="Report this seed - the construction invariant was violated.",
        )
    return graph


def _bridgeable_tiers(zones: list[Zone], edges: list[Edge]) -> list[Zone]:
    """Guarantee every edge spans at most one tier.

    Tiers are drawn per zone before the edges exist, so a corridor could join a
    tier-0 room to a tier-2 room: a 3.0-unit cliff, and a ramp only bridges one
    tier (rise 1.5 against the 1.6 walkable step). The level would look fine and
    be unsolvable — exactly the KEY_UNREACHABLE gate-5 failure.

    Relax to a fixed point: while some edge spans >1 tier, pull the higher zone
    down to one above the lower. Only ever lowers, so the tier sum strictly
    decreases and this terminates; no rng, so the graph stays reproducible from
    the seed. Verticality survives — the drops just become climbable.
    """
    tier = {zone.zone_id: zone.tier for zone in zones}
    for _ in range(len(zones) + 1):  # convergence is guaranteed well inside this
        violations = [e for e in edges if abs(tier[e.a] - tier[e.b]) > 1]
        if not violations:
            break
        for edge in violations:
            low, high = sorted((edge.a, edge.b), key=lambda z: tier[z])
            tier[high] = tier[low] + 1

    # Relaxing only lowers, so a level can settle entirely above the ground
    # tier and float. Drop it back down; only the relative tiers matter.
    floor = min(tier.values())
    return [
        Zone(zone_id=z.zone_id, kind=z.kind, tier=tier[z.zone_id] - floor) for z in zones
    ]


def _make_zones(rng: random.Random, kinds: list[str], verticality_tiers: int) -> list[Zone]:
    return [
        Zone(zone_id=f"z{i:02d}", kind=kind, tier=rng.randrange(verticality_tiers))
        for i, kind in enumerate(kinds)
    ]


def _build_room_corridor(
    rng: random.Random, zone_count: int, verticality_tiers: int
) -> tuple[list[Zone], list[Edge]]:
    """Chain entry -> middles -> key -> exit, plus random open loop edges."""
    kinds = ["entry"]
    kinds += [rng.choice(MIDDLE_KINDS) for _ in range(zone_count - 3)]
    kinds += ["key", "exit"]
    zones = _make_zones(rng, kinds, verticality_tiers)

    # Critical path entry -> ... -> key -> exit; final edge is locked.
    edges: list[Edge] = []
    for i in range(len(zones) - 1):
        kind = "locked" if zones[i + 1].kind == "exit" else "open"
        edges.append(Edge(a=zones[i].zone_id, b=zones[i + 1].zone_id, kind=kind))

    # Extra open edges for loops (never into the exit — keeps the lock honest).
    for i in range(len(zones)):
        for j in range(i + 2, len(zones)):
            if zones[j].kind == "exit" or zones[i].kind == "exit":
                continue
            if rng.random() < EXTRA_EDGE_CHANCE:
                edges.append(Edge(a=zones[i].zone_id, b=zones[j].zone_id, kind="open"))
    return zones, edges


def _build_bsp(
    rng: random.Random, zone_count: int, verticality_tiers: int
) -> tuple[list[Zone], list[Edge]]:
    """Branching tree via recursive bisection (a BSP over zone indices).

    Exactly zone_count - 1 edges, no loops. The exit is the deepest leaf
    from the entry (index 0) and is gated by its single, locked edge; the
    key zone is the exit's only neighbor. If the tree degenerates into a
    star around the entry, the exit leaf is re-attached under another
    middle zone so the key can never be the entry itself.
    """
    pairs: list[tuple[int, int]] = []

    def bisect(lo: int, hi: int) -> None:
        if lo >= hi:
            return
        mid = rng.randint(lo, hi - 1)
        pairs.append((rng.randint(lo, mid), rng.randint(mid + 1, hi)))
        bisect(lo, mid)
        bisect(mid + 1, hi)

    bisect(0, zone_count - 1)

    adjacency: dict[int, set[int]] = {i: set() for i in range(zone_count)}
    for a, b in pairs:
        adjacency[a].add(b)
        adjacency[b].add(a)

    # BFS depths from the entry (index 0); deepest node in a tree is a leaf.
    depth = {0: 0}
    frontier = [0]
    while frontier:
        current = frontier.pop(0)
        for neighbor in sorted(adjacency[current]):
            if neighbor not in depth:
                depth[neighbor] = depth[current] + 1
                frontier.append(neighbor)
    exit_idx = min(i for i in depth if depth[i] == max(depth.values()))
    key_idx = min(adjacency[exit_idx])

    if key_idx == 0:  # star around the entry: re-attach the exit under a middle
        key_idx = min(n for n in adjacency[0] if n != exit_idx)
        pairs = [p for p in pairs if set(p) != {0, exit_idx}]
        pairs.append((key_idx, exit_idx))

    kinds = [
        "entry" if i == 0
        else "exit" if i == exit_idx
        else "key" if i == key_idx
        else rng.choice(MIDDLE_KINDS)
        for i in range(zone_count)
    ]
    zones = _make_zones(rng, kinds, verticality_tiers)
    edges = [
        Edge(
            a=zones[a].zone_id,
            b=zones[b].zone_id,
            kind="locked" if exit_idx in (a, b) else "open",
        )
        for a, b in pairs
    ]
    return zones, edges


def _deepest_leaf_lock(
    rng: random.Random, pairs: list[tuple[int, int]], zone_count: int
) -> tuple[int, int, list[tuple[int, int]]]:
    """Shared lock/key finisher for tree topologies: exit = deepest leaf from
    the entry (index 0), key = its only neighbor; if that neighbor is the
    entry (star), the exit leaf is re-attached under another middle zone.
    Returns (exit_idx, key_idx, possibly-rewired pairs)."""
    adjacency: dict[int, set[int]] = {i: set() for i in range(zone_count)}
    for a, b in pairs:
        adjacency[a].add(b)
        adjacency[b].add(a)
    depth = {0: 0}
    frontier = [0]
    while frontier:
        current = frontier.pop(0)
        for neighbor in sorted(adjacency[current]):
            if neighbor not in depth:
                depth[neighbor] = depth[current] + 1
                frontier.append(neighbor)
    exit_idx = min(i for i in depth if depth[i] == max(depth.values()))
    key_idx = min(adjacency[exit_idx])
    if key_idx == 0:
        key_idx = min(n for n in adjacency[0] if n != exit_idx)
        pairs = [p for p in pairs if set(p) != {0, exit_idx}]
        pairs.append((key_idx, exit_idx))
    return exit_idx, key_idx, pairs


def _build_cellular_caves(
    rng: random.Random, zone_count: int, verticality_tiers: int
) -> tuple[list[Zone], list[Edge]]:
    """Organic warren: a random recursive tree (each cavern branches off a
    random earlier one — hubs and dead-ends emerge naturally) plus a high
    loop density. Distinct from room_corridor's chain and bsp's bisection."""
    pairs = [(rng.randrange(i), i) for i in range(1, zone_count)]
    exit_idx, key_idx, pairs = _deepest_leaf_lock(rng, pairs, zone_count)

    # Dense open loops between non-exit caverns (the warren feel).
    for i in range(zone_count):
        for j in range(i + 2, zone_count):
            if exit_idx in (i, j) or (i, j) in pairs or (j, i) in pairs:
                continue
            if rng.random() < CAVE_LOOP_CHANCE:
                pairs.append((i, j))

    kinds = [
        "entry" if i == 0
        else "exit" if i == exit_idx
        else "key" if i == key_idx
        else rng.choice(("combat", "empty", "combat"))  # caves skew hostile
        for i in range(zone_count)
    ]
    zones = _make_zones(rng, kinds, verticality_tiers)
    edges = [
        Edge(
            a=zones[a].zone_id,
            b=zones[b].zone_id,
            kind="locked" if exit_idx in (a, b) else "open",
        )
        for a, b in pairs
    ]
    return zones, edges


def _build_wfc_dressing(
    rng: random.Random, zone_count: int, verticality_tiers: int
) -> tuple[list[Zone], list[Edge]]:
    """Chain skeleton with kinds assigned by a miniature Wave Function
    Collapse over the graph: middle-zone domains collapse lowest-entropy
    first (seeded tie-break) and adjacency constraints propagate — no two
    loot rooms touch, combat never guards the key directly, no empty runs."""
    # Skeleton identical to room_corridor: entry .. middles .. key, exit.
    pairs = [(i, i + 1) for i in range(zone_count - 1)]
    for i in range(zone_count):
        for j in range(i + 2, zone_count):
            if zone_count - 1 in (i, j):  # never bypass the locked exit
                continue
            if rng.random() < EXTRA_EDGE_CHANCE:
                pairs.append((i, j))

    adjacency: dict[int, set[int]] = {i: set() for i in range(zone_count)}
    for a, b in pairs:
        adjacency[a].add(b)
        adjacency[b].add(a)

    fixed = {0: "entry", zone_count - 2: "key", zone_count - 1: "exit"}
    domains: dict[int, set[str]] = {
        i: set(MIDDLE_KINDS) for i in range(zone_count) if i not in fixed
    }
    assigned = dict(fixed)

    def compatible(kind: str, other: str) -> bool:
        return frozenset((kind, other)) not in WFC_INCOMPATIBLE

    def propagate(idx: int) -> None:
        for neighbor in adjacency[idx]:
            if neighbor in domains:
                domains[neighbor] = {
                    k for k in domains[neighbor] if compatible(k, assigned[idx])
                }

    for idx in fixed:
        propagate(idx)
    while domains:
        # Lowest entropy first; seeded tie-break keeps it deterministic.
        idx = min(domains, key=lambda i: (len(domains[i]), i))
        options = sorted(domains.pop(idx)) or ["combat"]  # contradiction fallback
        assigned[idx] = options[rng.randrange(len(options))]
        propagate(idx)

    zones = _make_zones(rng, [assigned[i] for i in range(zone_count)], verticality_tiers)
    edges = [
        Edge(
            a=zones[a].zone_id,
            b=zones[b].zone_id,
            kind="locked" if zone_count - 1 in (a, b) else "open",
        )
        for a, b in pairs
    ]
    return zones, edges
