"""Seeded 2D room/corridor layout (S4, step 2 of the deterministic spine).

Takes the abstract ZoneGraph from ``zone_graph.py`` and assigns each zone a
grid-aligned, non-overlapping rectangular footprint plus a straight/L-shaped
corridor for every edge. This is the direct input the Godot-side worker
needs for 3D materialization (GridMap kit placement, elevation, ramps) —
everything here stays engine-agnostic pure Python so it's unit-testable
without Godot.

Determinism (CLAUDE.md rule 14): uses only ``random.Random(graph.seed)``
seeded from the zone graph; never the global RNG.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from pcg.zone_graph import PCGError, ZoneGraph

ROOM_SIZE_RANGE = (6, 12)  # grid units, per room width/depth
CORRIDOR_WIDTH = 2.0
ROOM_GAP = 2.0  # minimum clearance kept between room footprints
# Per-tier rise. Must stay walkable across the ROOM_GAP: rise/gap must be
# well under Godot's 45-degree floor limit (1.5/2.0 = 36.9 degrees).
FLOOR_HEIGHT = 1.5
MAX_PLACEMENT_ATTEMPTS = 64
DIRECTIONS = ("north", "south", "east", "west")


@dataclass(frozen=True)
class Rect:
    x: float
    z: float
    width: float
    depth: float

    def overlaps(self, other: Rect, gap: float = 0.0) -> bool:
        return not (
            self.x + self.width + gap <= other.x
            or other.x + other.width + gap <= self.x
            or self.z + self.depth + gap <= other.z
            or other.z + other.depth + gap <= self.z
        )

    def center(self) -> tuple[float, float]:
        return (self.x + self.width / 2, self.z + self.depth / 2)


@dataclass(frozen=True)
class RoomPlacement:
    zone_id: str
    rect: Rect
    elevation: float


@dataclass(frozen=True)
class Corridor:
    a: str
    b: str
    kind: str  # open | locked (mirrors the source Edge)
    points: tuple[tuple[float, float], ...]  # polyline, 2 or 3 waypoints
    width: float = CORRIDOR_WIDTH


@dataclass
class Layout:
    seed: int
    rooms: dict[str, RoomPlacement] = field(default_factory=dict)
    corridors: list[Corridor] = field(default_factory=list)

    def has_no_overlaps(self) -> bool:
        placed = list(self.rooms.values())
        for i, a in enumerate(placed):
            for b in placed[i + 1 :]:
                if a.rect.overlaps(b.rect):
                    return False
        return True

    def bounds(self) -> Rect:
        xs = [r.rect.x for r in self.rooms.values()]
        zs = [r.rect.z for r in self.rooms.values()]
        x2s = [r.rect.x + r.rect.width for r in self.rooms.values()]
        z2s = [r.rect.z + r.rect.depth for r in self.rooms.values()]
        return Rect(x=min(xs), z=min(zs), width=max(x2s) - min(xs), depth=max(z2s) - min(zs))


def _bfs_order(graph: ZoneGraph) -> list[str]:
    entry = next(z.zone_id for z in graph.zones if z.kind == "entry")
    seen = {entry}
    order = [entry]
    frontier = [entry]
    while frontier:
        current = frontier.pop(0)
        for neighbor in graph.neighbors(current):
            if neighbor not in seen:
                seen.add(neighbor)
                order.append(neighbor)
                frontier.append(neighbor)
    return order


def _candidate_rect(parent: Rect, direction: str, width: float, depth: float, gap: float) -> Rect:
    if direction == "north":
        return Rect(x=parent.x, z=parent.z - depth - gap, width=width, depth=depth)
    if direction == "south":
        return Rect(x=parent.x, z=parent.z + parent.depth + gap, width=width, depth=depth)
    if direction == "east":
        return Rect(x=parent.x + parent.width + gap, z=parent.z, width=width, depth=depth)
    return Rect(x=parent.x - width - gap, z=parent.z, width=width, depth=depth)  # west


def _corridor_points(a: Rect, b: Rect) -> tuple[tuple[float, float], ...]:
    ax, az = a.center()
    bx, bz = b.center()
    if abs(ax - bx) < 1e-6 or abs(az - bz) < 1e-6:
        return ((ax, az), (bx, bz))
    return ((ax, az), (bx, az), (bx, bz))  # simple L-shaped elbow


def generate_layout(
    graph: ZoneGraph,
    room_size_range: tuple[int, int] = ROOM_SIZE_RANGE,
    gap: float = ROOM_GAP,
    floor_height: float = FLOOR_HEIGHT,
) -> Layout:
    """Place every zone as a non-overlapping rect; connect every edge with a corridor."""
    rng = random.Random(graph.seed)
    zones_by_id = {z.zone_id: z for z in graph.zones}
    order = _bfs_order(graph)

    layout = Layout(seed=graph.seed)
    lo, hi = room_size_range
    entry_id = order[0]
    entry_zone = zones_by_id[entry_id]
    entry_w = rng.randint(lo, hi)
    entry_d = rng.randint(lo, hi)
    layout.rooms[entry_id] = RoomPlacement(
        zone_id=entry_id,
        rect=Rect(x=0.0, z=0.0, width=entry_w, depth=entry_d),
        elevation=entry_zone.tier * floor_height,
    )

    for zone_id in order[1:]:
        zone = zones_by_id[zone_id]
        parent_id = next(n for n in graph.neighbors(zone_id) if n in layout.rooms)
        parent_rect = layout.rooms[parent_id].rect
        width = rng.randint(lo, hi)
        depth = rng.randint(lo, hi)

        placed_rect = None
        directions = list(DIRECTIONS)
        rng.shuffle(directions)
        for attempt in range(MAX_PLACEMENT_ATTEMPTS):
            direction = directions[attempt % len(directions)]
            jitter = attempt // len(directions)
            candidate = _candidate_rect(parent_rect, direction, width, depth, gap + jitter * 2)
            if not any(candidate.overlaps(r.rect, gap=gap) for r in layout.rooms.values()):
                placed_rect = candidate
                break
        if placed_rect is None:
            raise PCGError(
                code="layout_placement_failed",
                path=f"world.zone_graph (zone {zone_id})",
                message=(
                    f"could not place zone '{zone_id}' without overlap after "
                    f"{MAX_PLACEMENT_ATTEMPTS} attempts"
                ),
                hint="Reduce zone_count or widen room_size_range/gap.",
            )
        layout.rooms[zone_id] = RoomPlacement(
            zone_id=zone_id, rect=placed_rect, elevation=zone.tier * floor_height
        )

    for edge in graph.edges:
        a_rect = layout.rooms[edge.a].rect
        b_rect = layout.rooms[edge.b].rect
        layout.corridors.append(
            Corridor(a=edge.a, b=edge.b, kind=edge.kind, points=_corridor_points(a_rect, b_rect))
        )

    if not layout.has_no_overlaps():  # defensive: placement loop guarantees it
        raise PCGError(
            code="layout_overlap_detected",
            path="world.zone_graph",
            message="generated layout has overlapping room rects",
            hint="Report this seed - the placement invariant was violated.",
        )
    return layout
