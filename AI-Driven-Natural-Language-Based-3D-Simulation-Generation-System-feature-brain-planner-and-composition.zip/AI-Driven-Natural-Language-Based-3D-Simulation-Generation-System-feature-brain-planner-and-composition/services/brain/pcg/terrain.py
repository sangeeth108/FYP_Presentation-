"""Seeded terrain: one heightfield, generated here, consulted by everyone.

The ground was a single flat slab, and that assumption was written down in three
places -- placement pinned every entity's contact height to 0.0, the scatter
sampler declared `slope_max_degrees` an *ignored* constraint because a slope limit
on a plane is meaningless rather than satisfied, and the writer emitted a BoxMesh.

The load-bearing decision here is that the heightfield is generated ONCE, in
Python, and shipped as data. The alternative -- generating it in the engine with
FastNoiseLite and mirroring the same noise in Python so placement can agree --
requires two implementations to match bit for bit forever. The first divergence
puts every prop either floating above the hill or buried inside it, and nothing
would report it, because each side is internally consistent. One generator, one
grid, everybody samples it.

Pure Python on purpose. `numpy` is installed in this environment but is not a
declared dependency of the brain (see pyproject.toml), and `pcg/scatter.py` runs
on `random` alone. A 128x128 grid over four octaves is about 65k noise
evaluations, which costs milliseconds -- not enough to justify widening what the
API service must install.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

# Cells per side. A 1000 m world at 2 m spacing would be 501x501 = 251k samples,
# which is a quarter-million floats to ship and hash for relief a player reads
# over tens of metres. Capping the GRID and letting the cell size grow keeps the
# payload fixed: 128x128 is 16k samples whatever the world measures.
_MAX_GRID = 128
# Below this the interpolation has nothing to interpolate between.
_MIN_GRID = 9

# Relief in metres per surface family, as a fraction of the smaller world
# dimension. Amplitude is not a free parameter: it comes from what the planner
# already said the ground is MADE OF, so no new spec field is needed.
#
# Built ground is deliberately flat. A concrete yard or a metal deck with rolling
# hills in it is not stylisation, it is a fault -- and a wooden floor even more so.
_RELIEF_BY_SURFACE = {
    "grass": 0.035,
    "soil": 0.040,
    "sand": 0.055,  # dunes carry the most visible relief of the natural families
    "snow": 0.030,
    "stone": 0.070,  # rugged: the one family where sharp ground reads as correct
    "concrete": 0.0,
    "metal": 0.0,
    "wood": 0.0,
    "unspecified": 0.025,  # gentle, because nobody asked for hills
}
# Absolute ceiling regardless of world size. Past this the navmesh's
# agent_max_climb of 0.5 m and agent_max_slope of 45 degrees start carving the
# walkable surface into disconnected islands, and `navigation_reachability` is a
# mandatory gate -- relief must not be able to fail a run that would otherwise
# pass.
_MAX_AMPLITUDE_M = 2.5


def _lattice_value(seed: int, ix: int, iy: int) -> float:
    """A stable pseudorandom value in [0, 1) for one lattice point.

    Deliberately not Python's `hash()`, which is randomised per process for str
    and bytes: the same world would then generate different ground on every run.
    This is an integer mix (splitmix64's finaliser), which is reproducible across
    processes, machines and Python versions.
    """
    mixed = (seed & 0xFFFFFFFFFFFFFFFF) ^ (ix * 0x9E3779B97F4A7C15) ^ (
        iy * 0xC2B2AE3D27D4EB4F
    )
    mixed &= 0xFFFFFFFFFFFFFFFF
    mixed = (mixed ^ (mixed >> 30)) * 0xBF58476D1CE4E5B9 & 0xFFFFFFFFFFFFFFFF
    mixed = (mixed ^ (mixed >> 27)) * 0x94D049BB133111EB & 0xFFFFFFFFFFFFFFFF
    mixed ^= mixed >> 31
    return (mixed & 0xFFFFFFFF) / 0x100000000


def _smooth(t: float) -> float:
    """Smoothstep, so lattice cells meet without a visible crease."""
    return t * t * (3.0 - 2.0 * t)


def _value_noise(seed: int, x: float, y: float) -> float:
    """Interpolated lattice noise in [0, 1)."""
    ix, iy = math.floor(x), math.floor(y)
    fx, fy = x - ix, y - iy
    sx, sy = _smooth(fx), _smooth(fy)
    n00 = _lattice_value(seed, ix, iy)
    n10 = _lattice_value(seed, ix + 1, iy)
    n01 = _lattice_value(seed, ix, iy + 1)
    n11 = _lattice_value(seed, ix + 1, iy + 1)
    top = n00 + (n10 - n00) * sx
    bottom = n01 + (n11 - n01) * sx
    return top + (bottom - top) * sy


def _fbm(seed: int, x: float, y: float, octaves: int = 4) -> float:
    """Fractional Brownian motion in [0, 1): broad hills plus finer undulation."""
    total = 0.0
    amplitude = 1.0
    frequency = 1.0
    normaliser = 0.0
    for octave in range(octaves):
        total += _value_noise(seed + octave * 7919, x * frequency, y * frequency) * amplitude
        normaliser += amplitude
        amplitude *= 0.5
        frequency *= 2.0
    return total / normaliser if normaliser else 0.0


def relief_amplitude_m(environment: dict) -> float:
    """How much relief this world's ground should carry, in metres.

    Indoors is always flat: a hospital corridor or a museum gallery with hills in
    it is absurd, and an indoor world's ground IS its floor.

    `mixed` gets relief. It was excluded at first, on the grounds that a building's
    floor cannot follow a hillside without the walls parting company with the
    ground -- which was true when written and stopped being true once footprint pads
    landed, because the building now stands on ground levelled for it. The first real
    prompt found this: "a grassy hillside meadow with a stone cottage" is classified
    mixed, for the cottage, and came back perfectly flat. Across 159 stored specs 46
    are mixed against 67 outdoor, so the exclusion was withholding relief from nearly
    a third of worlds -- and from exactly the ones with buildings in them.
    """
    if str(environment.get("world_kind") or "outdoor") == "indoor":
        return 0.0
    surface = str(environment.get("terrain_surface") or "unspecified")
    fraction = _RELIEF_BY_SURFACE.get(surface, _RELIEF_BY_SURFACE["unspecified"])
    if fraction <= 0.0:
        return 0.0
    dimensions = environment.get("dimensions_m") or {}
    extent = min(
        float(dimensions.get("width") or 0.0), float(dimensions.get("depth") or 0.0)
    )
    if extent <= 0.0:
        return 0.0
    return min(extent * fraction, _MAX_AMPLITUDE_M)


@dataclass(frozen=True)
class Terrain:
    """A sampled heightfield, and the single source of ground height.

    Heights are centred on zero rather than starting there, so y=0 stays the
    world's reference plane and a world does not lift or sink as a whole when
    relief is switched on. `flat` worlds are a real Terrain with every height at
    zero, which keeps one code path instead of scattering `if terrain is None`
    through placement.
    """

    width_m: float
    depth_m: float
    grid: int
    amplitude_m: float
    heights: tuple[float, ...]  # row-major, grid*grid entries, metres

    @property
    def flat(self) -> bool:
        return self.amplitude_m <= 0.0

    def _cell(self, x: float, z: float) -> tuple[float, float]:
        """World metres to fractional grid coordinates, clamped to the field.

        Clamping rather than raising: scatter and placement both work in world
        space and an entity exactly on the boundary is a legitimate position, not
        a programming error.
        """
        half_w, half_d = self.width_m / 2.0, self.depth_m / 2.0
        u = (x + half_w) / self.width_m if self.width_m else 0.0
        v = (z + half_d) / self.depth_m if self.depth_m else 0.0
        u = min(max(u, 0.0), 1.0)
        v = min(max(v, 0.0), 1.0)
        return u * (self.grid - 1), v * (self.grid - 1)

    def height_at(self, x: float, z: float) -> float:
        """Ground height in metres at a world position, bilinearly interpolated.

        Bilinear and not nearest-neighbour: nearest would put every prop on a
        little plateau and leave visible steps between neighbouring props that
        share no cell.
        """
        if self.flat:
            return 0.0
        gx, gz = self._cell(x, z)
        x0, z0 = int(gx), int(gz)
        x1 = min(x0 + 1, self.grid - 1)
        z1 = min(z0 + 1, self.grid - 1)
        tx, tz = gx - x0, gz - z0
        h00 = self.heights[z0 * self.grid + x0]
        h10 = self.heights[z0 * self.grid + x1]
        h01 = self.heights[z1 * self.grid + x0]
        h11 = self.heights[z1 * self.grid + x1]
        top = h00 + (h10 - h00) * tx
        bottom = h01 + (h11 - h01) * tx
        return top + (bottom - top) * tz

    def slope_degrees_at(self, x: float, z: float) -> float:
        """Steepness of the ground at a world position, in degrees from level.

        Measured with central differences over one cell, which is the scale a
        footprint actually rests on. Sampling closer would report the
        interpolation's own gradient rather than the ground's.
        """
        if self.flat:
            return 0.0
        step_x = self.width_m / (self.grid - 1)
        step_z = self.depth_m / (self.grid - 1)
        dx = (
            self.height_at(x + step_x, z) - self.height_at(x - step_x, z)
        ) / (2.0 * step_x)
        dz = (
            self.height_at(x, z + step_z) - self.height_at(x, z - step_z)
        ) / (2.0 * step_z)
        return math.degrees(math.atan(math.hypot(dx, dz)))

    def with_pads(self, footprints: list[tuple[float, float, float, float]]) -> "Terrain":
        """A copy with the ground levelled under each footprint.

        `footprints` is (centre_x, centre_z, width, depth) in world metres. Every
        pad target is read from THIS field before any is applied, so a pad's level
        never depends on another pad having been laid first.

        Two rules settle overlaps, both arrived at by measurement:

        Largest footprint first, and a cell it fully owns is final. A bench standing
        against a barn wall otherwise won those cells outright -- its pad covers them
        completely while the barn's only reaches them at the edge -- and left the barn
        with 0.208 m of spread under a 14 m wall. Big structures define the ground and
        small props sit on whatever ground they find, which is also the right way
        round physically.

        Otherwise the pad that covers a cell MOST governs it. Averaging was tried
        first and is wrong: two entities standing close pull each other off level
        through their blend rings, and a house whose ring met a hall's came out less
        level than before either pad existed (0.670 m of spread became 0.846 m).

        Processing order is by descending footprint area with position breaking ties,
        so the result is reproducible whatever order the caller supplies.

        The blend ring stops a pad becoming a plateau with a cliff at its edge.
        One cell of blend is enough at this grid spacing and keeps the levelled
        area close to the footprint it exists for.
        """
        if self.flat or not footprints:
            return self
        step_x = self.width_m / (self.grid - 1)
        step_z = self.depth_m / (self.grid - 1)
        half_w, half_d = self.width_m / 2.0, self.depth_m / 2.0
        # The winning pad per cell: (weight, level). Deliberately not a running
        # average -- see the note above.
        claims: dict[int, tuple[float, float]] = {}
        ordered = sorted(
            footprints,
            key=lambda f: (-(f[2] * f[3]), f[0], f[1]),
        )
        locked: set[int] = set()
        for centre_x, centre_z, width, depth in ordered:
            level = self.height_at(centre_x, centre_z)
            reach_x = width / 2.0 + 2.0 * step_x
            reach_z = depth / 2.0 + 2.0 * step_z
            first_column = int(max(0, math.floor((centre_x - reach_x + half_w) / step_x)))
            last_column = int(min(self.grid - 1, math.ceil((centre_x + reach_x + half_w) / step_x)))
            first_row = int(max(0, math.floor((centre_z - reach_z + half_d) / step_z)))
            last_row = int(min(self.grid - 1, math.ceil((centre_z + reach_z + half_d) / step_z)))
            for row in range(first_row, last_row + 1):
                for column in range(first_column, last_column + 1):
                    cell_x = -half_w + column * step_x
                    cell_z = -half_d + row * step_z
                    # 1 inside the footprint, falling to 0 across the blend ring.
                    over_x = max(
                        0.0, abs(cell_x - centre_x) - (width / 2.0 + step_x)
                    ) / step_x
                    over_z = max(
                        0.0, abs(cell_z - centre_z) - (depth / 2.0 + step_z)
                    ) / step_z
                    slack = max(over_x, over_z)
                    if slack >= 1.0:
                        continue
                    weight = 1.0 - slack
                    index = row * self.grid + column
                    if index in locked:
                        continue  # a larger footprint already owns this ground
                    if weight >= 1.0:
                        locked.add(index)
                        claims[index] = (weight, level)
                        continue
                    winner = claims.get(index)
                    # Ties break on the lower level, so the result does not depend
                    # on iteration order when two pads cover a cell equally.
                    if winner is None or (weight, -level) > (winner[0], -winner[1]):
                        claims[index] = (weight, level)
        if not claims:
            return self
        heights = list(self.heights)
        for index, (weight, level) in claims.items():
            heights[index] = heights[index] * (1.0 - weight) + level * weight
        return Terrain(
            width_m=self.width_m,
            depth_m=self.depth_m,
            grid=self.grid,
            amplitude_m=self.amplitude_m,
            heights=tuple(heights),
        )

    def as_payload(self) -> dict:
        """The plan's terrain block: parameters plus the grid itself."""
        return {
            "width_m": round(self.width_m, 4),
            "depth_m": round(self.depth_m, 4),
            "grid": self.grid,
            "amplitude_m": round(self.amplitude_m, 4),
            "heights_m": [round(value, 4) for value in self.heights],
        }


def flat_terrain(width_m: float, depth_m: float) -> Terrain:
    """A Terrain with no relief, for indoor and built-surface worlds."""
    return Terrain(
        width_m=float(width_m),
        depth_m=float(depth_m),
        grid=_MIN_GRID,
        amplitude_m=0.0,
        heights=tuple([0.0] * (_MIN_GRID * _MIN_GRID)),
    )


def build_terrain(environment: dict, seed: int) -> Terrain:
    """The heightfield for this world, reproducible from the seed alone."""
    dimensions = environment.get("dimensions_m") or {}
    width = float(dimensions.get("width") or 0.0)
    depth = float(dimensions.get("depth") or 0.0)
    amplitude = relief_amplitude_m(environment)
    if width <= 0.0 or depth <= 0.0 or amplitude <= 0.0:
        return flat_terrain(width, depth)

    # Broad relief: roughly two hills across the world, so the ground rolls
    # rather than ripples. Measured at extent/12 (five hills across 60 m) an 8x6 m
    # house spanned 2.16 m of height, which no single contact height can seat.
    extent = max(width, depth)
    grid = int(min(_MAX_GRID, max(_MIN_GRID, round(extent / 1.5) + 1)))
    features = max(1.0, extent / 30.0)

    raw = []
    for row in range(grid):
        for column in range(grid):
            u = column / (grid - 1)
            v = row / (grid - 1)
            raw.append(_fbm(seed, u * features, v * features))

    # Centre on the mean so y=0 remains the reference plane, then scale to the
    # requested amplitude. Scaling by the observed spread rather than assuming
    # fBm spans [0,1] keeps the amplitude honest: four octaves of value noise
    # concentrate around the middle and never reach either end.
    mean = sum(raw) / len(raw)
    spread = max(max(raw) - mean, mean - min(raw)) or 1.0
    heights = tuple((value - mean) / spread * amplitude for value in raw)
    return Terrain(
        width_m=width,
        depth_m=depth,
        grid=grid,
        amplitude_m=amplitude,
        heights=heights,
    )


def terrain_from_payload(payload: dict | None, width_m: float = 0.0, depth_m: float = 0.0) -> Terrain:
    """Read a plan's terrain block back into a field.

    A plan written before terrain existed has no block and describes a flat world,
    so the fallback is flat rather than an error -- a preserved plan carried through
    a repair must still validate.
    """
    if not payload:
        return flat_terrain(width_m, depth_m)
    return Terrain(
        width_m=float(payload["width_m"]),
        depth_m=float(payload["depth_m"]),
        grid=int(payload["grid"]),
        amplitude_m=float(payload["amplitude_m"]),
        heights=tuple(float(value) for value in payload["heights_m"]),
    )
