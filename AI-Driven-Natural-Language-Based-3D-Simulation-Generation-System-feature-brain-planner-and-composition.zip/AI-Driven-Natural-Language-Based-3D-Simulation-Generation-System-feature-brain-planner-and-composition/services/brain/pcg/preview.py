"""See the world straight after placement, before anything expensive.

WHY. Nothing looked at pixels until after asset generation and a headless Godot
build -- roughly ten minutes. So a spec-level mistake cost a full run to find,
and the repair loop was too expensive to lean on. Worse, the planner authors a
VISUAL artifact with no way to see one, which is how doors came out lying on
their sides, an oak arrived felled, and a village spread over 51 m of a 73 m
world with the player 52 m from half of it. Every one of those is invisible in
JSON and obvious in a picture.

This renders the WorldPlan as plain boxes: no assets, no engine, no GPU, a
couple of hundred milliseconds. It cannot tell you whether a house looks like a
house -- that is what the real validation views are for. It tells you what the
LAYOUT is, which is what the cheap mistakes live in: an empty plain, everything
in one corner, a thing lying down, the player nowhere near the content.

Deterministic by construction: same plan in, identical PNG out. Nothing here
samples.
"""

from __future__ import annotations

import colorsys
import hashlib
import math
from pathlib import Path

_IMAGE_WIDTH = 960
_IMAGE_HEIGHT = 540
_FOV_DEGREES = 55.0

# A three-quarter view from above: high enough to read the layout, low enough
# that heights are still legible. Matches the overview the real validation
# capture uses, so a preview and a final render are comparable.
_VIEW_DIRECTION = (0.72, 0.46, 0.72)

_SKY = (94, 122, 138)
_GROUND = (176, 178, 172)
_PLAYER = (206, 78, 62)


def _colour_for(semantic_type: str, *, is_player: bool) -> tuple[int, int, int]:
    """A stable, distinguishable colour per kind of thing.

    Hashed rather than assigned so a new semantic_type needs no registration,
    and stable so the same world always renders the same way -- two previews of
    one plan must be diffable by eye.
    """
    if is_player:
        return _PLAYER
    digest = hashlib.sha256(semantic_type.encode("utf-8")).digest()
    hue = digest[0] / 255.0
    # Muted and mid-toned: full saturation makes a dozen boxes unreadable.
    red, green, blue = colorsys.hsv_to_rgb(hue, 0.34, 0.78)
    return (int(red * 255), int(green * 255), int(blue * 255))


def _corners(
    position: list[float], dimensions: list[float], yaw_degrees: float
) -> list[tuple[float, float, float]]:
    """The eight corners of a box, in world space."""
    yaw = math.radians(float(yaw_degrees))
    cos, sin = math.cos(yaw), math.sin(yaw)
    half_x, half_y, half_z = (float(v) / 2.0 for v in dimensions[:3])
    points = []
    for sign_x in (-1, 1):
        for sign_y in (-1, 1):
            for sign_z in (-1, 1):
                local_x, local_z = sign_x * half_x, sign_z * half_z
                points.append(
                    (
                        position[0] + cos * local_x + sin * local_z,
                        position[1] + sign_y * half_y,
                        position[2] - sin * local_x + cos * local_z,
                    )
                )
    return points


def _look_at(eye, target):
    """Camera basis: right, up, forward."""
    forward = [target[i] - eye[i] for i in range(3)]
    length = math.sqrt(sum(v * v for v in forward)) or 1.0
    forward = [v / length for v in forward]
    right = [forward[2], 0.0, -forward[0]]
    length = math.sqrt(sum(v * v for v in right)) or 1.0
    right = [v / length for v in right]
    up = [
        right[1] * forward[2] - right[2] * forward[1],
        right[2] * forward[0] - right[0] * forward[2],
        right[0] * forward[1] - right[1] * forward[0],
    ]
    return right, up, forward


def render_world_plan(plan: dict, output_path: Path) -> dict:
    """Draw the plan as boxes. Returns what was drawn, for the record.

    Never raises: a preview that fails must not take a run with it. The report
    says what happened so a missing image is diagnosable rather than mysterious.
    """
    output_path = Path(output_path)
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return {"rendered": False, "reason": "Pillow is not installed"}

    entities = list(plan.get("entities") or [])
    if not entities:
        return {"rendered": False, "reason": "the plan places no entities"}

    try:
        # Frame the CONTENT, not the declared world: the surplus ground is
        # exactly what a preview should show as surplus, and the camera has to
        # sit somewhere sensible regardless of how big the plan claims to be.
        xs = [e["transform"]["position_m"][0] for e in entities]
        zs = [e["transform"]["position_m"][2] for e in entities]
        ys = [
            e["transform"]["position_m"][1] + e["dimensions_m"][1] / 2.0
            for e in entities
        ]
        centre = (
            (min(xs) + max(xs)) / 2.0,
            max(0.0, max(ys)) / 2.0,
            (min(zs) + max(zs)) / 2.0,
        )
        span = max(max(xs) - min(xs), max(zs) - min(zs), max(ys), 6.0)
        distance = span / math.tan(math.radians(_FOV_DEGREES / 2.0)) * 0.9 + span

        eye = tuple(centre[i] + _VIEW_DIRECTION[i] * distance for i in range(3))
        right, up, forward = _look_at(eye, centre)
        focal = (_IMAGE_WIDTH / 2.0) / math.tan(math.radians(_FOV_DEGREES / 2.0))

        def project(point):
            offset = [point[i] - eye[i] for i in range(3)]
            depth = sum(offset[i] * forward[i] for i in range(3))
            if depth <= 0.05:
                return None, depth
            screen_x = sum(offset[i] * right[i] for i in range(3))
            screen_y = sum(offset[i] * up[i] for i in range(3))
            return (
                _IMAGE_WIDTH / 2.0 + focal * screen_x / depth,
                _IMAGE_HEIGHT / 2.0 - focal * screen_y / depth,
            ), depth

        image = Image.new("RGB", (_IMAGE_WIDTH, _IMAGE_HEIGHT), _SKY)
        draw = ImageDraw.Draw(image)

        # The ground, as the plan declares it. Seeing it dwarf the content is
        # the single most useful thing this picture can show.
        bounds = plan.get("world_bounds") or {}
        low, high = bounds.get("min"), bounds.get("max")
        if low and high:
            ground = [
                (low[0], 0.0, low[2]),
                (high[0], 0.0, low[2]),
                (high[0], 0.0, high[2]),
                (low[0], 0.0, high[2]),
            ]
            flat = [project(p)[0] for p in ground]
            if all(point is not None for point in flat):
                draw.polygon(flat, fill=_GROUND)

        # Painter's algorithm: far boxes first. Cheap, and correct enough for
        # boxes that rarely interpenetrate.
        drawn = 0
        faces: list[tuple[float, list, tuple[int, int, int]]] = []
        for entity in entities:
            transform = entity["transform"]
            corners = _corners(
                transform["position_m"],
                entity["dimensions_m"],
                transform.get("rotation_y_degrees", 0.0),
            )
            projected = [project(c) for c in corners]
            if any(point is None for point, _ in projected):
                continue
            colour = _colour_for(
                str(entity.get("semantic_type") or "thing"),
                is_player="controlled_actor" in str(entity.get("entity_id", "")),
            )
            points = [p for p, _ in projected]
            depths = [d for _, d in projected]
            # Each face carries ITS OWN depth, not the box's. Sorting by the
            # box average tied all six faces, so back faces drew over front
            # ones and every solid came out looking hollow.
            # Index order matches _corners: (sign_x, sign_y, sign_z) counting up.
            for a, b, c, d in (
                (0, 1, 3, 2), (4, 5, 7, 6),   # -x, +x
                (0, 1, 5, 4), (2, 3, 7, 6),   # -z, +z
                (1, 3, 7, 5), (0, 2, 6, 4),   # top, bottom
            ):
                face_depth = (depths[a] + depths[b] + depths[c] + depths[d]) / 4.0
                faces.append(
                    (face_depth, [points[a], points[b], points[c], points[d]], colour)
                )
            drawn += 1

        for _, polygon, colour in sorted(faces, key=lambda item: -item[0]):
            draw.polygon(polygon, fill=colour, outline=(60, 60, 60))

        output_path.parent.mkdir(parents=True, exist_ok=True)
        image.save(output_path)
        return {
            "rendered": True,
            "path": str(output_path),
            "entities_drawn": drawn,
            "entities_total": len(entities),
            "world_m": [
                round(high[0] - low[0], 2) if low and high else None,
                round(high[2] - low[2], 2) if low and high else None,
            ],
            "content_m": [round(max(xs) - min(xs), 2), round(max(zs) - min(zs), 2)],
        }
    except Exception as exc:  # noqa: BLE001 -- a preview must never fail a run
        return {"rendered": False, "reason": f"{type(exc).__name__}: {exc}"}
