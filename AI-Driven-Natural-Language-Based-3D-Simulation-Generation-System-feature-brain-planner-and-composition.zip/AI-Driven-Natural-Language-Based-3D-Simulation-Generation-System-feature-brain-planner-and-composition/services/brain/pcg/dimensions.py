"""Real-world sizes for the kinds of thing a planner names.

WHY THIS EXISTS. The planner is a language model asked to author geometry it
cannot see. Measured over one day of real runs, that produced: a door as
[0.1, 2.1, 1.8] -- 1.8 m deep, lying on its side; a fence post as
[0.1, 0.1, 1.8] -- 0.1 m tall, a plank on the ground; an oak as [0.4, 0.4, 8],
felled; two houses described in their own brief as "3 metres to the roof peak"
emitted as [12, 8, 3], eight metres tall. Every one of those is invisible in
text and obvious in a picture, which is exactly the check the model does not
have.

The project's own rule (CLAUDE.md 3.15) is "ambiguity up, determinism down":
the model decides WHAT, deterministic code decides HOW. A bounding box is HOW.
So the model keeps naming things -- the part it is good at -- and the size comes
from here.

This is a correction, not a straitjacket. A planner that says a cathedral door
is 3 m tall is telling us something true that a generic "door" entry would
destroy, so a declared size is kept when it is within a believable band of the
canonical one. Only implausible sizes are replaced, and every replacement is
reported so the planner's failure modes stay measurable rather than hidden.
"""

from __future__ import annotations

import re

# Canonical [width_x, height_y, depth_z] in metres. Height is ALWAYS the middle
# value -- that convention is the single most misread thing in the contract, and
# stating it here in data is worth more than stating it again in prose.
#
# Keys are matched as whole words against an entity's semantic_type and name, so
# "hinged_wooden_door" and "front door" both find "door". Order matters: the
# first match wins, so put specific kinds before the generic ones they contain.
_CANONICAL: tuple[tuple[str, tuple[float, float, float]], ...] = (
    # openings and fittings
    ("doorway", (1.0, 2.1, 0.15)),
    ("door", (0.9, 2.0, 0.05)),
    ("window", (1.2, 1.4, 0.1)),
    ("gate", (2.4, 1.8, 0.1)),
    ("stoop", (1.5, 0.45, 0.9)),
    ("steps", (1.5, 0.45, 0.9)),
    ("stair", (1.2, 2.6, 3.0)),
    # street furniture
    ("hydrant", (0.35, 0.75, 0.35)),
    ("fence_post", (0.12, 1.2, 0.12)),
    ("post", (0.12, 1.2, 0.12)),
    ("bollard", (0.2, 0.9, 0.2)),
    ("lamp", (0.3, 4.0, 0.3)),
    ("bench", (1.6, 0.85, 0.6)),
    ("bin", (0.5, 0.9, 0.5)),
    ("sign", (0.6, 2.2, 0.08)),
    ("mailbox", (0.4, 1.1, 0.3)),
    # buildings
    ("cottage", (7.0, 5.0, 8.0)),
    ("house", (9.0, 6.0, 10.0)),
    ("barn", (12.0, 7.0, 18.0)),
    ("shed", (3.0, 2.4, 3.0)),
    ("tower", (6.0, 18.0, 6.0)),
    ("hut", (4.0, 3.0, 4.0)),
    ("building", (10.0, 8.0, 12.0)),
    # furniture
    ("table", (1.4, 0.75, 0.8)),
    ("chair", (0.5, 0.9, 0.5)),
    ("bed", (1.4, 0.6, 2.0)),
    ("crate", (0.8, 0.8, 0.8)),
    ("barrel", (0.6, 0.9, 0.6)),
    ("shelf", (1.0, 1.8, 0.4)),
    # nature
    ("tree", (4.0, 8.0, 4.0)),
    ("bush", (1.2, 1.0, 1.2)),
    ("shrub", (1.0, 0.8, 1.0)),
    ("rock", (1.0, 0.7, 1.0)),
    ("boulder", (2.0, 1.6, 2.0)),
    ("log", (0.5, 0.5, 3.0)),
    # living things
    ("dog", (0.35, 0.55, 1.0)),
    ("cat", (0.2, 0.3, 0.5)),
    ("horse", (0.7, 1.7, 2.4)),
    ("cow", (0.7, 1.5, 2.2)),
    ("sheep", (0.5, 0.9, 1.2)),
    ("bird", (0.15, 0.2, 0.25)),
    ("person", (0.55, 1.75, 0.35)),
    ("villager", (0.55, 1.75, 0.35)),
    ("visitor", (0.55, 1.75, 0.35)),
    ("pedestrian", (0.55, 1.75, 0.35)),
    # vehicles
    ("car", (1.8, 1.5, 4.4)),
    ("cart", (1.3, 1.2, 2.2)),
    ("bicycle", (0.6, 1.1, 1.8)),
    ("boat", (2.0, 1.2, 5.0)),
)

# How far a declared size may stray from the canonical one before it is treated
# as a mistake rather than a variation. A cathedral door really is twice a
# domestic one; nothing is a tenth or ten times the size of what it is named.
_TOLERANCE = 3.0

_WORD = re.compile(r"[a-z0-9]+")


def canonical_bbox(*descriptors: str) -> tuple[float, float, float] | None:
    """The real-world size of the first known kind named in these strings."""
    words: set[str] = set()
    joined = " ".join(d for d in descriptors if d).lower()
    words.update(_WORD.findall(joined))
    collapsed = re.sub(r"[^a-z0-9]+", "_", joined)
    for kind, size in _CANONICAL:
        if kind in words or f"_{kind}_" in f"_{collapsed}_":
            return size
    return None


def _scale_of(declared: list[float], canonical: tuple[float, float, float]) -> float:
    """How many times bigger the declared thing is, by volume."""
    declared_volume = max(declared[0] * declared[1] * declared[2], 1e-9)
    canonical_volume = canonical[0] * canonical[1] * canonical[2]
    return (declared_volume / canonical_volume) ** (1.0 / 3.0)


def correct_bbox(
    declared: list[float] | None, *descriptors: str
) -> tuple[list[float], str | None]:
    """Return (bbox, reason_if_corrected) for a named thing.

    A declared size within `_TOLERANCE` of the canonical one is kept: the
    planner may know this door is a cathedral door. Anything further out, or
    shaped nothing like the real thing, is replaced -- keeping the planner's
    overall scale where that is itself believable, so a "small shed" stays
    small.
    """
    canonical = canonical_bbox(*descriptors)
    if canonical is None:
        return (list(declared) if declared else [1.0, 1.0, 1.0]), None
    if not declared or len(declared) < 3 or any(float(v) <= 0 for v in declared[:3]):
        return list(canonical), "no usable size declared"

    declared = [float(v) for v in declared[:3]]
    scale = _scale_of(declared, canonical)

    # Wrong SHAPE is the tell, not wrong volume: a fence post emitted as
    # [0.1, 0.1, 1.8] has almost exactly the right volume and is lying down.
    # Compare the proportions, which is what the axis-order mistake destroys.
    def proportions(box: list[float] | tuple[float, float, float]) -> tuple[float, ...]:
        longest = max(box) or 1.0
        return tuple(round(v / longest, 3) for v in box)

    declared_shape = proportions(declared)
    canonical_shape = proportions(canonical)
    shape_error = max(
        abs(a - b) for a, b in zip(declared_shape, canonical_shape, strict=True)
    )

    if shape_error <= 0.34 and 1 / _TOLERANCE <= scale <= _TOLERANCE:
        return declared, None

    # Replace, keeping the one number the model reliably got right: the LONGEST
    # dimension. When the axes are scrambled the volume misleads -- a door
    # emitted as [0.1, 2.1, 1.8] has 4x the volume of a real door and rescaling
    # by volume produced a 3.2 m door, while an oak given as [0.4, 0.4, 8]
    # collapsed to 2.7 m because a bare trunk has a fraction of a canopy's
    # volume. The longest side survives an axis swap untouched: the door's
    # 2.1 m and the oak's 8 m were both correct and both recoverable.
    longest_declared = max(declared)
    longest_canonical = max(canonical)
    kept_scale = longest_declared / longest_canonical if longest_canonical else 1.0
    kept_scale = min(max(kept_scale, 1 / _TOLERANCE), _TOLERANCE)
    corrected = [round(v * kept_scale, 4) for v in canonical]
    return corrected, (
        f"declared {[round(v, 2) for v in declared]} is not the shape of this "
        f"kind (canonical {list(canonical)}); corrected to {corrected}"
    )
