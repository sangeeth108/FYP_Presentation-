"""Turn the brief's `layout` list into composition, in code rather than by asking.

Four hypotheses were tested for why the planner used `routes` and `regions` zero times
across five settlement prompts while using `linear_structures` five times. Three were
refuted -- the guidance was made concrete, the nested arrays were flattened, and the
double-listed materials were addressed by instruction -- and none of them moved the
number. The one that worked was structural: `extract` had nowhere to put a street, so a
street stopped being a street before the planner read any schema.

That fix landed and the extractor now emits all three shapes correctly. The planner
still converts `run` and drops `route` and `area`.

So this stops asking. The brief's `layout` entries are structured data with a shape and,
now, geometry; turning them into `routes`, `regions` and `linear_structures` is a
transcription, and transcription is what deterministic code is for. It is the same move
the rest of the system already makes: the model decides WHAT the place contains, code
decides how that is written down (rule 3.15).

Only fills what the planner left empty. A planner that did author a route keeps its own,
because it saw the prose and this sees three fields.

Why the geometry is required on the brief rather than invented here: a route needs a
centreline and a region needs a polygon, and inventing either from a name would put a
street wherever a default said, which is the arrangement-by-accident the composition work
exists to end. Asking the extract stage for two corners and a width is asking for
something it can read off the description.
"""

from __future__ import annotations

import math
import re


def _slug(text: str) -> str:
    value = re.sub(r"[^a-z0-9]+", "_", str(text).lower()).strip("_")
    return value[:40] or "layout"


def _pair(value) -> tuple[float, float] | None:
    try:
        return float(value[0]), float(value[1])
    except (TypeError, ValueError, IndexError):
        return None


# How close two lines must be before they are the same line. Generous on purpose: the
# planner names a thing one way and the brief another, and the cost of treating two
# descriptions of one wall as two walls is that they occupy each other's ground.
_SAME_LINE_M = 6.0


def _covers_same_line(existing: list[dict], start, end, keys) -> bool:
    """Whether something already runs roughly where this would.

    Names cannot answer this. Measured on settlement prompts: the planner authored
    `lin_wall_right` while the brief described the same wall as `right boundary wall`,
    and an id comparison kept both -- 28 of one world's 44 entities failed to place,
    almost all of them segments of walls built twice. Endpoints are compared instead,
    in both directions, because a run described from either end is the same run.
    """
    for item in existing:
        for key_start, key_end in keys:
            other_start = item.get(key_start)
            other_end = item.get(key_end)
            if not other_start or not other_end:
                continue
            try:
                a = (float(other_start[0]), float(other_start[1]))
                b = (float(other_end[0]), float(other_end[1]))
            except (TypeError, ValueError, IndexError):
                continue
            forward = math.dist(a, start) + math.dist(b, end)
            reversed_ = math.dist(a, end) + math.dist(b, start)
            if min(forward, reversed_) <= _SAME_LINE_M * 2:
                return True
    return False


def _line_of_points(values) -> tuple | None:
    """First and last point of a flat [x1,z1,x2,z2,...] list."""
    try:
        numbers = [float(value) for value in values or ()]
    except (TypeError, ValueError):
        return None
    if len(numbers) < 4:
        return None
    return (numbers[0], numbers[1]), (numbers[-2], numbers[-1])


# A line shorter than this fraction of the world's smaller side is a feature of one
# object, not layout. Measured: giving `extract` a third bucket with no sense of when it
# does not apply made a baker's workspace produce one route and four "runs", a dusty
# attic a boundary wall, and a storage room a street -- and every corpus run that used
# composition failed to publish while all three that did not, did.
#
# Scale rather than a list of indoor place types, because any such list is the noun
# ceiling this codebase keeps refusing to build: "kitchen" would be caught and "galley"
# would not. A countertop edge is short relative to its world whatever the room is
# called; a boundary wall is not.
_MIN_LINE_FRACTION = 0.25
# And an absolute floor, because proportion alone is not enough: a 3 m countertop edge is
# exactly a quarter of a 12 m kitchen and still furniture. Two segments' worth is the
# shortest thing worth expanding as a run at all -- below that it is one object, which is
# what `entities` is for. Tied to the segmentation constant rather than picked, so the two
# cannot drift apart.
_MIN_LINE_M = 6.0
# And an area smaller than this share of the ground is a rug, not a plaza. A room's floor
# is already `environment.terrain_surface`.
_MIN_AREA_FRACTION = 0.04


def _world_extent(candidate: dict) -> tuple[float, float]:
    """The world's width and depth, or zeros when it does not say."""
    dimensions = ((candidate.get("environment") or {}).get("dimensions_m")) or {}
    try:
        return float(dimensions.get("width") or 0.0), float(dimensions.get("depth") or 0.0)
    except (TypeError, ValueError):
        return 0.0, 0.0


def materialise_layout(candidate: dict, brief: dict | None) -> list[dict]:
    """Fill `routes`, `regions` and `linear_structures` from the brief's `layout`.

    Returns approximation records for what was added, so a world whose streets came
    from transcription rather than from the planner's own hand says so.
    """
    entries = (brief or {}).get("layout")
    if not isinstance(entries, list) or not entries:
        return []

    notes: list[dict] = []
    width, depth = _world_extent(candidate)
    smaller_side = min(width, depth) if width > 0.0 and depth > 0.0 else 0.0
    world_area = width * depth

    for entry in entries:
        if not isinstance(entry, dict):
            continue
        shape = str(entry.get("shape") or "")
        start = _pair(entry.get("from_m"))
        end = _pair(entry.get("to_m"))
        if start is None or end is None or start == end:
            continue

        # Too small to be layout: this is a feature of one object.
        span = math.dist(start, end)
        if shape in {"route", "run"}:
            too_short = span < _MIN_LINE_M or (
                smaller_side > 0.0 and span < smaller_side * _MIN_LINE_FRACTION
            )
            if too_short:
                notes.append(
                    {
                        "requirement_id": _slug(entry.get("name") or shape),
                        "reason": (
                            f"{entry.get('name') or shape!r} is {span:.1f} m across a "
                            f"{smaller_side:.0f} m place, which is a feature of one "
                            "object rather than the shape of the place; left to the "
                            "objects"
                        )[:300],
                        "user_visible": False,
                    }
                )
                continue
        if shape == "area" and world_area > 0.0:
            patch = abs(end[0] - start[0]) * abs(end[1] - start[1])
            if patch < world_area * _MIN_AREA_FRACTION:
                notes.append(
                    {
                        "requirement_id": _slug(entry.get("name") or shape),
                        "reason": (
                            f"{entry.get('name') or shape!r} covers {patch:.0f} m2 of a "
                            f"{world_area:.0f} m2 place, which is a rug rather than a "
                            "paved area; the ground surface already describes it"
                        )[:300],
                        "user_visible": False,
                    }
                )
                continue
        name = str(entry.get("name") or shape)
        stem = _slug(name)
        source = str(entry.get("reason") or name)[:200]
        try:
            width = float(entry.get("width_m") or 0.0)
        except (TypeError, ValueError):
            width = 0.0

        if shape == "route":
            routes = candidate.setdefault("routes", [])
            existing = [
                {"a": line[0], "b": line[1]}
                for line in (_line_of_points(item.get("points_m")) for item in routes)
                if line
            ]
            if _covers_same_line(existing, start, end, (("a", "b"),)):
                continue
            routes.append(
                {
                    "route_id": f"rte_{stem}"[:64],
                    "semantic_type": name[:80],
                    "source_text": source,
                    "points_m": [start[0], start[1], end[0], end[1]],
                    "width_m": min(30.0, max(0.5, width or 4.0)),
                }
            )
        elif shape == "area":
            regions = candidate.setdefault("regions", [])
            if any(str(item.get("region_id", "")).endswith(stem) for item in regions):
                continue
            # Two opposite corners become a rectangle. A brief describes a yard, not a
            # surveyed outline, and four corners is the shape a yard actually is.
            low_x, high_x = sorted((start[0], end[0]))
            low_z, high_z = sorted((start[1], end[1]))
            regions.append(
                {
                    "region_id": f"rgn_{stem}"[:64],
                    "semantic_type": name[:80],
                    "source_text": source,
                    "polygon_m": [low_x, low_z, high_x, low_z, high_x, high_z, low_x, high_z],
                    # The one field with no honest default: an unpainted region is
                    # indistinguishable from the ground, so `stone` stands in and is
                    # disclosed rather than guessed silently.
                    "surface": "stone",
                }
            )
        elif shape == "run":
            runs = candidate.setdefault("linear_structures", [])
            if _covers_same_line(runs, start, end, (("from_m", "to_m"),)):
                continue
            runs.append(
                {
                    "structure_id": f"lin_{stem}"[:64],
                    "semantic_type": name[:80],
                    "source_text": source,
                    "from_m": [start[0], start[1]],
                    "to_m": [end[0], end[1]],
                    "height_m": 1.2,
                    "thickness_m": min(2.0, max(0.05, width or 0.2)),
                    "asset": {
                        "brief": f"a segment of {name}"[:500],
                        "category": "structure",
                        "requires_animation": False,
                        "preferred_source": "either",
                        "procedural_type": "semantic_box",
                    },
                }
            )
        else:
            continue

        notes.append(
            {
                "requirement_id": stem,
                "reason": (
                    f"the description called for a {shape} ({name}); it was built from "
                    "the brief's own outline because the plan did not include one"
                )[:300],
                "user_visible": False,
            }
        )
    return notes
