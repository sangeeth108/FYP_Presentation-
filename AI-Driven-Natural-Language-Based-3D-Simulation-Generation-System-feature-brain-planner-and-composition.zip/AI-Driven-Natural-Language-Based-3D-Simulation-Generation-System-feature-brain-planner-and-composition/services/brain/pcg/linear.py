"""Turn a declared run into a line of segments.

A wall is one thing to a person and many things to a renderer. The contract lets the
planner say the first ("a dry-stone wall from here to there, 1.8 m high, with a gate
in the middle") and this module says the second, deterministically.

Why segments at all, rather than one long box? Because a run has to sit on ground that
is not flat. `pcg/terrain.py` gives the world real relief, and a single 60 m box either
floats at one end or buries itself at the other. Dividing the run lets each piece be
seated on the ground beneath it, which is what a real wall does as it crosses a slope.
Segments also give the run its openings for free: a gateway is simply the segments that
were not emitted.

Why this is not a planner decision. How finely to divide a run is rendering economics --
segment count against draw calls against how badly a long box reads on a slope -- and
the planner has no way to know any of it. So the contract carries the two endpoints and
the cross-section, and everything else is worked out here (rule 3.15).

The output is ordinary spec entities. That is deliberate and it is what makes the
feature small: entities already get colliders, terrain seating, navmesh carving, the
scene writer, and every validation gate. A run materialised into some parallel
`segments` array would have needed all of that reimplemented, and the scene writer
indexes the spec by entity id, so a world-plan-only segment could not be written at all.

Traceability rides on `part_of` (ADR from the requirement_traceability work): the first
segment carries the run's `exists` requirement with the run's own verbatim
`source_text`, and every later segment is `part_of` the first. This is the case that
relation was added for -- one described thing built as several.
"""

from __future__ import annotations

import math

# How long a segment wants to be. Chosen so a segment reads as a piece of wall rather
# than a fence post, and so a garden wall is a handful of nodes rather than dozens.
_PREFERRED_SEGMENT_M = 3.0
# The ceiling matters more than the preference. A 240 m run at 3 m would be 80 static
# bodies for one wall, and the scope budget is 50-200 props for the WHOLE world.
_MAX_SEGMENTS = 16
# Across every run in the world, not per run. Sixteen was sized for a world with one
# boundary wall; a settlement now declares four or five runs, and sixteen each is 60-80
# bodies contending for ground. Measured when composition began landing: 216 entities
# failed to place. Same rule as the scatter instance ceiling, same reason -- the cost is
# a property of the scene.
_TOTAL_SEGMENT_BUDGET = 36
_MIN_SEGMENTS = 1
# A hairline joint between neighbouring segments. Two segments that abut EXACTLY are
# overlapping as far as a separating-axis test is concerned -- zero separation is not
# positive separation -- so a 16-segment wall lost six segments to collisions with its
# own neighbours even after `part_of` waived their clearance. Ten millimetres is below
# what a low-poly stylised mesh resolves at any distance a visitor sees it from, and
# comfortably above the four-decimal rounding the plan stores positions at.
_JOINT_M = 0.01
# Forms a segment of a run can legitimately be. A run is a length of something with a
# cross-section: a box reads as wall, stone, hedge or fence; a panel reads as boarding;
# an open container reads as railing. Everything else in the vocabulary describes a
# free-standing OBJECT, and tiling an object along a line does not make a wall.
#
# Measured: a village's `low_boundary_wall` was given `slender_post` -- the form for a
# lamp post -- and its seven segments rendered as thin plates floating in a row. The
# planner picks the form and nothing checked that the form suited being a run.
_RUN_FORMS = frozenset(
    {
        "semantic_box",
        "flat_panel",
        "open_container",
        "building_shell",
        # Forms built to be tiled along a line. `fence_section` is the reason the
        # override exists at all -- a fence has to be seen THROUGH, and forcing it
        # to `semantic_box` turned every fence into a solid wall.
        "fence_section",
        "arch_gateway",
    }
)
_RUN_FALLBACK = "semantic_box"


def _direction(start: list[float], end: list[float]) -> tuple[float, float, float]:
    """Unit direction and length in the XZ plane."""
    dx = float(end[0]) - float(start[0])
    dz = float(end[1]) - float(start[1])
    length = math.hypot(dx, dz)
    if length <= 0.0:
        return 0.0, 0.0, 0.0
    return dx / length, dz / length, length


def _segment_count(length: float) -> int:
    wanted = int(math.ceil(length / _PREFERRED_SEGMENT_M))
    return max(_MIN_SEGMENTS, min(_MAX_SEGMENTS, wanted))


def _solid_spans(length: float, openings: list[dict]) -> list[tuple[float, float]]:
    """The run with its openings taken out: a list of (start, end) along the run.

    Subtracting the gaps BEFORE segmenting is what makes a gate the width it was asked
    for. The first version segmented the whole run and dropped any segment an opening
    touched, so a 3 m gate ate two 3.75 m segments and opened the wall by 7.5 m. A gap
    slightly too wide is a fair rounding; two and a half times too wide is a hole.

    Openings are clamped to the run and merged, because two that overlap describe one
    gate and would otherwise produce an empty span between them.
    """
    gaps: list[tuple[float, float]] = []
    for opening in openings:
        try:
            centre = float(opening["at_fraction"]) * length
            half = float(opening["width_m"]) / 2.0
        except (KeyError, TypeError, ValueError):
            continue
        if half <= 0.0:
            continue
        gaps.append((max(0.0, centre - half), min(length, centre + half)))
    gaps.sort()

    merged: list[tuple[float, float]] = []
    for start, end in gaps:
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))

    spans: list[tuple[float, float]] = []
    cursor = 0.0
    for start, end in merged:
        if start - cursor > 1e-6:
            spans.append((cursor, start))
        cursor = max(cursor, end)
    if length - cursor > 1e-6:
        spans.append((cursor, length))
    return spans


def expand_linear_structures(spec: dict) -> list[dict]:
    """Materialise every `linear_structures` entry into entities and relations.

    Mutates `spec` in place: appends to `entities`, `spatial_relations` and
    `requirements`. Returns the approximation records for anything that could not be
    materialised as asked, so the caller can disclose them.

    Idempotent: a run whose segments are already present is skipped. Today the only
    caller runs this once, inside the planner's normalisation chain, so the guard is
    never needed -- which is exactly why it is here rather than left to caller
    discipline. Segment ids are derived from the run id and index, so a second pass
    without it would append a duplicate of every entity in the world and fail much
    further downstream than the mistake.

    It does not delete `linear_structures`: the run is what the planner said and the
    segments are what was built from it, and throwing away the former would lose the
    only record of intent.
    """
    runs = spec.get("linear_structures")
    if not isinstance(runs, list) or not runs:
        return []

    entities: list[dict] = spec.setdefault("entities", [])
    relations: list[dict] = spec.setdefault("spatial_relations", [])
    requirements: list[dict] = spec.setdefault("requirements", [])
    approximations: list[dict] = []
    # (from, to, height) -> the run that claimed that line first.
    seen_lines: dict[tuple, str] = {}

    # What every run would want on its own, so the budget can be shared in proportion
    # to length rather than by clipping each to the same ceiling. A 60 m boundary and a
    # 6 m garden fence should not get the same number of pieces.
    wanted_total = 0.0
    length_total = 0.0
    for candidate_run in runs:
        if not isinstance(candidate_run, dict):
            continue
        start_pair = candidate_run.get("from_m") or ()
        end_pair = candidate_run.get("to_m") or ()
        try:
            span = math.dist(
                (float(start_pair[0]), float(start_pair[1])),
                (float(end_pair[0]), float(end_pair[1])),
            )
        except (TypeError, ValueError, IndexError):
            continue
        wanted_total += min(_MAX_SEGMENTS, max(1.0, span / _PREFERRED_SEGMENT_M))
        length_total += span
    budget_scale = (
        _TOTAL_SEGMENT_BUDGET / wanted_total if wanted_total > _TOTAL_SEGMENT_BUDGET else 1.0
    )

    for run in runs:
        if not isinstance(run, dict):
            continue
        structure_id = str(run.get("structure_id") or "")
        if not structure_id.startswith("lin_"):
            continue
        stem = structure_id[len("lin_") :]

        # Two runs on the same line are one run, built twice.
        #
        # Measured on a settlement prompt: a farmyard "bounded by a split rail fence"
        # came back as four runs -- north, south, east, west -- where north and south
        # were the SAME two endpoints and east and west were another same pair. Sixty
        # four segments were emitted for what is geometrically two lines, and 22 of
        # them failed to place because they collided with their own duplicate. The
        # `part_of` exemption cannot help: it makes segments of ONE run able to abut,
        # and these are different runs occupying identical ground.
        #
        # Merged rather than refused, and not user-visible: the planner asked for a
        # boundary and gets a boundary. What it does not get is the same fence twice.
        signature = (
            tuple(round(float(value), 2) for value in run.get("from_m") or ()),
            tuple(round(float(value), 2) for value in run.get("to_m") or ()),
            round(float(run.get("height_m") or 0.0), 2),
        )
        if signature in seen_lines:
            approximations.append(
                {
                    "requirement_id": structure_id,
                    "reason": (
                        f"this runs along exactly the same line as "
                        f"{seen_lines[signature]}, so it was built once rather than "
                        "twice on top of itself"
                    )[:300],
                    "user_visible": False,
                }
            )
            continue
        seen_lines[signature] = structure_id

        if any(
            str(entity.get("entity_id", "")).startswith(f"ent_{stem}_s")
            for entity in spec.get("entities") or ()
        ):
            continue
        try:
            start = [float(value) for value in run["from_m"][:2]]
            end = [float(value) for value in run["to_m"][:2]]
            height = float(run["height_m"])
            thickness = float(run["thickness_m"])
        except (KeyError, TypeError, ValueError, IndexError):
            approximations.append(
                {
                    "requirement_id": structure_id,
                    "reason": (
                        "this run was missing the numbers needed to build it, so "
                        "it was not created"
                    )[:300],
                    "user_visible": True,
                }
            )
            continue

        unit_x, unit_z, length = _direction(start, end)

        # Pull each end in, so runs that meet at a corner do not fight over it.
        #
        # Two runs bounding a yard share the corner coordinate exactly. Measured on a
        # 0.4 m fence: south's first segment occupies x 0.005..2.995, z -0.2..0.2 and
        # west's wants x -0.2..0.2, z 0.005..2.855 -- a 0.2 m square of genuine overlap,
        # and west's corner segment is the one that fails. `part_of` exempts segments of
        # ONE run from each other and cannot reach across runs.
        #
        # HALF the thickness is not enough, which is why the first attempt at this
        # failed: it leaves the two boxes touching along a line, and touching is overlap
        # to a separating-axis test. Half plus the joint separates them, and it is the
        # same hairline the segments of one run already use on each other.
        inset = thickness / 2.0 + _JOINT_M
        if length > inset * 4.0:
            start = [start[0] + unit_x * inset, start[1] + unit_z * inset]
            end = [end[0] - unit_x * inset, end[1] - unit_z * inset]
            unit_x, unit_z, length = _direction(start, end)

        if length <= thickness:
            # Not a run at all. Building it would produce one segment shorter than it
            # is deep -- a post, and a misleading one, since the planner asked for
            # something that goes somewhere.
            approximations.append(
                {
                    "requirement_id": structure_id,
                    "reason": (
                        f"declared as a run but its two ends are {length:.2f} m apart, "
                        f"less than its own {thickness:.2f} m thickness; not built, "
                        "because a single block is not what was described"
                    )[:300],
                    "user_visible": True,
                }
            )
            continue

        # Degrees, and measured the way the solver measures yaw: the segment's local X
        # is its length, so the rotation is what takes +X onto the run's direction.
        yaw = round(math.degrees(math.atan2(unit_x, unit_z)) - 90.0, 4)
        openings = [
            opening for opening in (run.get("openings") or ()) if isinstance(opening, dict)
        ]
        asset = dict(run.get("asset") or {})
        # Override rather than reject: the run itself is wanted, only the shape of its
        # pieces is wrong, and a wall built as boxes is right where a wall built as
        # lamp posts is not.
        declared_form = asset.get("procedural_type")
        if declared_form not in _RUN_FORMS:
            asset["procedural_type"] = _RUN_FALLBACK
            approximations.append(
                {
                    "requirement_id": structure_id,
                    "reason": (
                        f"declared as {declared_form!r}, which describes a free-standing "
                        f"object; a run is built from {_RUN_FALLBACK} pieces so it reads "
                        "as one continuous thing rather than a row of objects"
                    )[:300],
                    "user_visible": False,
                }
            )
        semantic_type = str(run.get("semantic_type") or "linear_structure")
        zone = run.get("zone")

        spans = _solid_spans(length, openings)
        # Named `span_from`/`span_to` throughout: `start` and `end` are the run's own
        # endpoints, and reusing them here silently replaced the run's origin with a
        # scalar distance along it, so every anchor was computed from the wrong place.
        solid = sum(span_to - span_from for span_from, span_to in spans)
        if solid <= 0.0:
            approximations.append(
                {
                    "requirement_id": structure_id,
                    "reason": (
                        "every part of this run fell inside a declared opening, so "
                        "nothing was left to build"
                    )[:300],
                    "user_visible": True,
                }
            )
            continue

        # The budget is per RUN, shared across its spans in proportion to their
        # length, so a wall broken by three gates does not get three walls' worth of
        # nodes. Each span keeps at least one segment: a 0.4 m stub between two gates
        # is still wall, and dropping it would leave a gap nobody asked for.
        run_cap = _MAX_SEGMENTS
        if budget_scale < 1.0 and length_total > 0.0:
            run_cap = max(
                1,
                min(
                    _MAX_SEGMENTS,
                    int(round(_TOTAL_SEGMENT_BUDGET * length / length_total)),
                ),
            )

        pieces: list[tuple[float, float]] = []
        for span_from, span_to in spans:
            share = (span_to - span_from) / solid
            allowance = max(1, int(round(run_cap * share)))
            count = max(1, min(allowance, _segment_count(span_to - span_from)))
            step = (span_to - span_from) / count
            for index in range(count):
                pieces.append((span_from + (index + 0.5) * step, step))

        built: list[str] = []
        for index, (centre_along, span) in enumerate(pieces):
            entity_id = f"ent_{stem}_s{index}"
            entities.append(
                {
                    "entity_id": entity_id,
                    "name": f"{semantic_type} segment {index + 1}",
                    "semantic_type": semantic_type,
                    "role": "scenery",
                    "asset": dict(asset),
                    "physical": {
                        # Length on X, height on Y, thickness on Z, and the yaw below
                        # turns that into the run's direction. Declaring it the other
                        # way round and relying on rotation to fix it is how a log
                        # ends up standing on its end.
                        # The joint comes off the LENGTH only, and the centre does
                        # not move, so the run still starts and ends where it was
                        # declared to -- each end pulls in by 5 mm.
                        "bbox_m": [
                            round(max(_JOINT_M, span - _JOINT_M), 4),
                            round(height, 4),
                            round(thickness, 4),
                        ],
                        "dynamic": False,
                        "mass_kg": 0.0,
                    },
                    "capabilities": [],
                    "placement": {
                        "zone": zone or "",
                        "anchor_m": [
                            round(start[0] + unit_x * centre_along, 4),
                            round(start[1] + unit_z * centre_along, 4),
                        ],
                        "anchor_yaw_degrees": yaw,
                        "hard_constraints": [],
                        "soft_constraints": [],
                    },
                }
            )
            built.append(entity_id)

        # One requirement for the whole run, carrying the run's own verbatim source.
        # The later segments trace through `part_of` rather than inventing sources of
        # their own, which is exactly the case that relation was added for.
        requirements.append(
            {
                "requirement_id": f"req_{stem}"[:64],
                "source_text": str(run.get("source_text") or semantic_type)[:200],
                "subject": built[0],
                "predicate": "exists",
                "target": semantic_type[:160],
                "priority": "required",
                # Phrased about the finished world rather than about this document,
                # which is the distinction the planner's own guidance insists on.
                "observable": (
                    f"A {semantic_type.replace('_', ' ')} runs across the world, built "
                    f"from {len(built)} connected segments."
                )[:300],
                "validator": "asset_and_runtime",
            }
        )
        for entity_id in built[1:]:
            relations.append(
                {
                    "subject_id": entity_id,
                    "target_id": built[0],
                    "relation": "part_of",
                    # Not hard, because there is nothing to enforce. `part_of` is a
                    # pure grouping claim that moves nothing -- every placement
                    # consumer matches a specific relation name and ignores this one --
                    # so declaring it hard would invite a solver to fail a world over
                    # a constraint it never applies.
                    "hard": False,
                }
            )

        if budget_scale < 1.0:
            approximations.append(
                {
                    "requirement_id": structure_id,
                    "reason": (
                        f"built from {len(built)} segments rather than the "
                        f"{_PREFERRED_SEGMENT_M:.0f} m spacing it would have had, "
                        "because this world declares several runs and they share one "
                        "budget"
                    )[:300],
                    "user_visible": False,
                }
            )
        elif len(built) >= _MAX_SEGMENTS and solid / len(built) > _PREFERRED_SEGMENT_M * 1.2:
            approximations.append(
                {
                    "requirement_id": structure_id,
                    "reason": (
                        f"a {length:.0f} m run built as {len(built)} segments of about "
                        f"{solid / len(built):.1f} m rather than "
                        f"{_PREFERRED_SEGMENT_M:.0f} m, so one wall does not use the "
                        "whole world's object budget"
                    )[:300],
                    "user_visible": False,
                }
            )

    return approximations
