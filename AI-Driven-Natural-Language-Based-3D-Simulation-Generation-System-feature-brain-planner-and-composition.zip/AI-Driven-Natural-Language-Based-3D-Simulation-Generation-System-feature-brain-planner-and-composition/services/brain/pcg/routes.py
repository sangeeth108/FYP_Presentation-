"""Allocate plots along a route, so buildings address a street instead of a dart.

Measured across 176 specs: `facing` used 0 times in 531 relations, 55% of entities
carrying no relation at all, and buildings landing wherever a seeded dart did not
collide -- 21 m gaps in something called a village. §3.3 of the gap analysis is blunt
about why: for the majority of entities, dart-throwing IS the layout.

A settlement is not a set of buildings with distances between them. It is a circulation
spine with buildings addressing it. `routes[]` declares the spine and
`placement.frontage` says which entity addresses which route; this module turns that
into coordinates.

The split is the same one as everywhere else in this system. The planner decides *where
the street goes* and *what fronts onto it*, because both are design. This module decides
*where along it each building stands*, because that is arithmetic over measured
geometry -- plot widths, kerb offsets, which side, and how to keep two houses from
occupying the same frontage.

Why it emits `anchor_m` rather than solving positions itself: ADR-0016 already built the
route from a declared position to a placed entity, including collision, clearance and
terrain seating. Frontage that computed final transforms would be a second placement
path, and the two would drift -- which is the failure `entities_conflict` exists to
document. So frontage produces an anchor and the ordinary solver does the rest, meaning
a house whose plot lands on top of a pre-existing well is still caught and disclosed.

Determinism (rule 14): allocation walks the route in a fixed order derived from the
spec's own entity order, and consumes no randomness at all. The same spec always
produces the same street.
"""

from __future__ import annotations

import math

# Space between neighbouring plots, on top of each entity's own footprint. Small on
# purpose: the point of a street is that its buildings read as a row, and a village lane
# with 8 m between cottages is a set of cottages rather than a lane.
_PLOT_GAP_M = 1.2


def _coordinate_pairs(values) -> list[tuple[float, float]]:
    """Read [x1, z1, x2, z2, ...] or the older [[x, z], ...], whichever is present.

    The contract now asks for a flat list, because the planner demonstrably produces
    those and avoids nested arrays -- five uses of `linear_structures` against zero of
    `routes` with otherwise identical definitions. Both shapes are accepted so a spec
    written before the change, or preserved through a repair, still reads.
    """
    points: list[tuple[float, float]] = []
    items = list(values or ())
    if items and isinstance(items[0], (list, tuple)):
        for item in items:
            try:
                points.append((float(item[0]), float(item[1])))
            except (TypeError, ValueError, IndexError):
                continue
        return points
    for index in range(0, len(items) - 1, 2):
        try:
            points.append((float(items[index]), float(items[index + 1])))
        except (TypeError, ValueError):
            continue
    return points


def _points(route: dict) -> list[tuple[float, float]]:
    """The centreline, with kinks shorter than the street is wide merged out.

    A bend a visitor cannot see is not a bend; it is a place where two nearly parallel
    segments disagree about which way "beside the route" points, which puts two
    neighbouring buildings at noticeably different angles for no visible reason.
    """
    raw = _coordinate_pairs(route.get("points_m"))
    if len(raw) < 2:
        return []

    try:
        width = float(route["width_m"])
    except (KeyError, TypeError, ValueError):
        width = 3.0

    kept = [raw[0]]
    for point in raw[1:-1]:
        if math.dist(point, kept[-1]) >= width:
            kept.append(point)
    # The last point is always kept: it is where the planner said the street ends, and
    # dropping it would shorten the street rather than smooth it.
    if math.dist(raw[-1], kept[-1]) > 1e-6:
        kept.append(raw[-1])
    return kept if len(kept) >= 2 else raw[:1] + raw[-1:]


def _length(points: list[tuple[float, float]]) -> float:
    return sum(math.dist(points[i], points[i + 1]) for i in range(len(points) - 1))


def _at_distance(
    points: list[tuple[float, float]], distance: float
) -> tuple[float, float, float, float]:
    """Point and unit direction at `distance` along the polyline.

    Clamped at both ends rather than extrapolated: a street that runs out of room has
    run out of room, and continuing its last segment into open country would put a
    building somewhere the planner never drew.
    """
    remaining = max(0.0, distance)
    for index in range(len(points) - 1):
        start, end = points[index], points[index + 1]
        segment = math.dist(start, end)
        if segment <= 1e-9:
            continue
        if remaining <= segment or index == len(points) - 2:
            fraction = min(1.0, remaining / segment)
            return (
                start[0] + (end[0] - start[0]) * fraction,
                start[1] + (end[1] - start[1]) * fraction,
                (end[0] - start[0]) / segment,
                (end[1] - start[1]) / segment,
            )
        remaining -= segment
    first, second = points[0], points[1]
    span = max(1e-9, math.dist(first, second))
    return first[0], first[1], (second[0] - first[0]) / span, (second[1] - first[1]) / span


def _measured(entity: dict, measured: dict[str, list[float]]) -> list[float]:
    """Measured geometry where the asset farm produced it, declared otherwise.

    The same fallback placement itself uses. Plot width has to come from how wide the
    building actually IS -- a 12 m longhouse and a 2 m market stall cannot share a plot
    size, which is the whole reason frontage cannot be solved at spec time.
    """
    dimensions = measured.get(str(entity.get("entity_id") or "")) or (
        entity.get("physical") or {}
    ).get("bbox_m")
    return list(dimensions or [1.0, 1.0, 1.0])


def _across_of(entity: dict, measured: dict[str, list[float]]) -> float:
    try:
        return float(_measured(entity, measured)[0])
    except (TypeError, ValueError, IndexError):
        return 1.0


def _deep_of(entity: dict, measured: dict[str, list[float]]) -> float:
    try:
        return float(_measured(entity, measured)[2])
    except (TypeError, ValueError, IndexError):
        return 1.0


def _frontage_of(entity: dict) -> dict | None:
    frontage = (entity.get("placement") or {}).get("frontage")
    return frontage if isinstance(frontage, dict) else None


def allocate_frontage(
    spec: dict, dimensions_by_entity_id: dict[str, list[float]]
) -> list[dict]:
    """Give every entity with `frontage` an anchor beside its route.

    `dimensions_by_entity_id` is MEASURED geometry where the asset farm produced it and
    declared geometry otherwise -- the same fallback placement itself uses. Plot width
    comes from it, so a 12 m longhouse takes a 12 m plot and a market stall takes 2 m,
    which is the whole reason this cannot be done at spec time.

    Mutates each entity's `placement`, adding `anchor_m` and `anchor_yaw_degrees`.
    Returns approximation records for anything it could not honour.
    """
    routes = {
        str(route.get("route_id")): route
        for route in (spec.get("routes") or ())
        if isinstance(route, dict) and str(route.get("route_id", "")).startswith("rte_")
    }
    approximations: list[dict] = []
    if not routes:
        # Frontage naming a route that does not exist is worth saying out loud: the
        # entity still gets placed, by the ordinary solver, so the world is fine and
        # the arrangement the planner described is not what was built.
        for entity in spec.get("entities") or ():
            if _frontage_of(entity):
                approximations.append(
                    {
                        "requirement_id": str(entity.get("entity_id") or "unknown"),
                        "reason": (
                            "asked to front onto a route, but this world declares no "
                            "routes; placed on open ground instead"
                        )[:300],
                        "user_visible": False,
                    }
                )
        return approximations

    # Grouped by route, in the spec's own entity order, so allocation is deterministic
    # without consulting the seed. An entity that is already anchored -- a wall segment
    # from a linear structure -- is left alone: its position is not a preference.
    by_route: dict[str, list[dict]] = {}
    for entity in spec.get("entities") or ():
        frontage = _frontage_of(entity)
        if not frontage:
            continue
        if (entity.get("placement") or {}).get("anchor_m") is not None:
            continue
        route_id = str(frontage.get("route_id") or "")
        if route_id not in routes:
            approximations.append(
                {
                    "requirement_id": str(entity.get("entity_id") or "unknown"),
                    "reason": (
                        f"asked to front onto {route_id or 'an unnamed route'}, which "
                        "this world does not contain; placed on open ground instead"
                    )[:300],
                    "user_visible": False,
                }
            )
            continue
        by_route.setdefault(route_id, []).append(entity)

    for route_id, members in by_route.items():
        route = routes[route_id]
        points = _points(route)
        if len(points) < 2:
            continue
        length = _length(points)
        try:
            half_width = float(route["width_m"]) / 2.0
        except (KeyError, TypeError, ValueError):
            half_width = 1.5

        # Sides are assigned in a first pass so the second can CENTRE each side's row
        # on the route. Filling from the start instead put four cottages in the first
        # 20 m of a 70 m lane with fifty metres of empty street beyond them -- every
        # building correctly oriented, and the settlement still bunched at one end.
        # Centring costs one extra pass and no randomness.
        sides: list[str] = []
        plots: list[float] = []
        alternate = 0
        for entity in members:
            frontage = _frontage_of(entity) or {}
            side = str(frontage.get("side") or "either")
            if side not in {"left", "right"}:
                side = "left" if alternate % 2 == 0 else "right"
                alternate += 1
            sides.append(side)
            plots.append(max(0.5, _across_of(entity, dimensions_by_entity_id)) + _PLOT_GAP_M)

        row_length = {
            "left": sum(plot for plot, side in zip(plots, sides, strict=True) if side == "left"),
            "right": sum(plot for plot, side in zip(plots, sides, strict=True) if side == "right"),
        }
        # A row longer than the street starts at 0 and overflows at the far end, which
        # is where the disclosure below picks it up. Centring a row that does not fit
        # would push its first building off the near end as well.
        cursor = {
            side: max(0.0, (length - row_length[side]) / 2.0) for side in ("left", "right")
        }
        overflowed: list[str] = []

        for entity, side, plot in zip(members, sides, plots, strict=True):
            entity_id = str(entity.get("entity_id") or "")
            frontage = _frontage_of(entity) or {}
            deep = _deep_of(entity, dimensions_by_entity_id)
            along = cursor[side] + plot / 2.0
            if along > length:
                # The street is full. Left to the ordinary solver rather than stacked
                # past the end of the route, because a building beyond where the
                # planner drew the street is not fronting onto anything.
                overflowed.append(entity_id)
                continue
            cursor[side] += plot

            x, z, dir_x, dir_z = _at_distance(points, along)
            try:
                setback = float(frontage.get("setback_m") or 0.0)
            except (TypeError, ValueError):
                setback = 0.0
            # Setback is to the NEAR FACE, so the centre sits half the depth further
            # out. Measuring to the centre instead would bury half of every building
            # in its own street, and worse for a deep one than a shallow one.
            offset = half_width + setback + max(0.0, deep) / 2.0
            # Left of travel is the direction 90 degrees anticlockwise in XZ.
            normal = (-dir_z, dir_x) if side == "left" else (dir_z, -dir_x)

            placement = entity.setdefault("placement", {})
            placement["anchor_m"] = [
                round(x + normal[0] * offset, 4),
                round(z + normal[1] * offset, 4),
            ]
            # Turned to face the street: the entity's local -Z looks back along the
            # normal it was pushed out on. This is what `facing` was never able to
            # express, and why it went unused in all 531 measured relations -- a
            # building does not face another building.
            #
            # The convention is the one `semantic.py` already uses to face a near
            # target: yaw = atan2(dx, -dz) points local -Z at (dx, dz), so yaw 0 faces
            # -Z. Here the direction to face is -normal, giving atan2(-nx, +nz).
            #
            # Getting the second sign wrong turned every building's BACK to the street.
            # It was invisible in the transforms -- two tidy rows at 0 and 180 degrees,
            # exactly as intended -- and showed up only because the doors attached to
            # those houses landed on the far side and the navigation probe could not
            # reach one of them. A row of houses is symmetric enough that facing and
            # backing look identical until something has to walk up to a door.
            placement["anchor_yaw_degrees"] = round(
                math.degrees(math.atan2(-normal[0], normal[1])), 4
            )

        if overflowed:
            approximations.append(
                {
                    "requirement_id": route_id,
                    "reason": (
                        f"{len(overflowed)} of {len(members)} buildings did not fit "
                        f"along a {length:.0f} m route and were placed on open ground "
                        "instead; a longer route would have kept them on the street"
                    )[:300],
                    "user_visible": True,
                }
            )

    return approximations


def _project(
    points: list[tuple[float, float]], target: tuple[float, float]
) -> tuple[float, tuple[float, float]]:
    """Distance along the polyline of the closest point on it, and that point."""
    best = (0.0, points[0])
    best_gap = math.dist(points[0], target)
    travelled = 0.0
    for index in range(len(points) - 1):
        start, end = points[index], points[index + 1]
        segment = math.dist(start, end)
        if segment <= 1e-9:
            continue
        # Parameter of the perpendicular foot, clamped to the segment.
        along = (
            (target[0] - start[0]) * (end[0] - start[0])
            + (target[1] - start[1]) * (end[1] - start[1])
        ) / (segment * segment)
        along = min(1.0, max(0.0, along))
        foot = (
            start[0] + (end[0] - start[0]) * along,
            start[1] + (end[1] - start[1]) * along,
        )
        gap = math.dist(foot, target)
        if gap < best_gap:
            best_gap = gap
            best = (travelled + along * segment, foot)
        travelled += segment
    return best


def corridor_between(
    route: dict, start: tuple[float, float], end: tuple[float, float]
) -> list[tuple[float, float]]:
    """The stretch of a route that gets you from near `start` to near `end`.

    This is what makes a declared street actually load-bearing rather than
    decorative. Measured: with houses in two rows 1.2 m apart, the far row's doors
    could reach nothing -- straight and L-shaped paths were blocked by the door's own
    neighbour along the row, and by the opposite row going the other way. Every
    building was correctly oriented onto a lane that no route could use.

    A person does not walk between two terraced houses. They step out to the street,
    walk along it, and turn off at the far end. So the candidates offered to the path
    solver include the route's centreline between the two projections, with the
    vertices in between kept so a bending street is followed rather than cut across.

    Returns an empty list when the route cannot help, so the caller falls back to its
    ordinary straight and L-shaped candidates.
    """
    points = _points(route)
    if len(points) < 2:
        return []
    from_distance, from_foot = _project(points, start)
    to_distance, to_foot = _project(points, end)
    if abs(to_distance - from_distance) < 1e-6:
        return []

    forward = from_distance < to_distance
    travelled = 0.0
    middle: list[tuple[float, float]] = []
    for index in range(len(points) - 1):
        travelled += math.dist(points[index], points[index + 1])
        vertex = points[index + 1]
        low, high = sorted((from_distance, to_distance))
        if low < travelled < high:
            middle.append(vertex)
    if not forward:
        middle.reverse()
    return [from_foot, *middle, to_foot]
