"""CLI: game_spec JSON in, level-plan JSON out.

Usage (from services/brain):
    python -m pcg.cli ../../contracts/examples/golden_game.spec.json

Prints the level plan to stdout; on PCG failure prints the machine-readable
error object to stderr and exits 1. This is the same path the worker's
godot_client will call in-process — the CLI exists for manual inspection
and shell pipelines.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan
from pcg.zone_graph import PCGError


def main(argv: list[str]) -> int:
    if len(argv) != 1:
        print("usage: python -m pcg.cli <game_spec.json>", file=sys.stderr)
        return 2
    spec = json.loads(Path(argv[0]).read_text(encoding="utf-8"))
    try:
        out = run_pcg(spec)
    except PCGError as err:
        print(json.dumps(err.to_dict()), file=sys.stderr)
        return 1
    print(json.dumps(to_level_plan(out), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
