"""Seeded scatter instancing: species + density -> concrete instances.

A `scatter` species in the spec is a KIND, not a thing: "buttress root tree at 6
per 100 m², grouped, away from water". This module expands each species into the
hundreds of individual placements that make a place feel inhabited, which is what
`entities` cannot do — an entity is one listed object, and a believable jungle
needs far more instances than anyone would ever enumerate.

Why sampling and not the constraint solver: the solver exists for the handful of
objects whose exact relationships matter (a temple *inside* a clearing). Nobody
cares which fern is where, only that the distribution reads correctly, and
solving thousands of ferns would be pointless as well as O(n²). So the few are
solved and the many are sampled.

Method: Poisson-disk (blue-noise) dart throwing on a spatial hash. Blue noise is
what makes scatter look natural — uniform random clumps and overlaps, a grid
looks planted. `min_distance` comes from the asset's MEASURED footprint, so
placement can never be tighter than the geometry allows.

Honesty (rule 11/13): requested density is frequently impossible. 6 trees per
100 m² with a 4 m canopy cannot pack — Poisson-disk at 8 m spacing fits roughly
180 in 10,000 m², not 600. Rather than overlap geometry or silently drop the
request, every species reports requested vs ACHIEVED density and why it fell
short.

Determinism (rule 14): each species draws from
``random.Random(f"{seed}:scatter:{species_id}")`` so editing one species'
density cannot reshuffle any other species.
"""

from __future__ import annotations

import random
from typing import Any

# Dart-throwing budget per wanted instance. Poisson-disk rejects a lot near
# saturation; this bounds the work instead of looping until the plane is full.
_ATTEMPTS_PER_INSTANCE = 12
_DEFAULT_FOOTPRINT_M = 0.5  # used only when an asset has no measured bounds yet
# Instancing makes many copies of one mesh cheap, but the world plan still carries
# a transform per instance and the renderer still culls them, so the total is
# capped. A real run produced 120,000 instances (6 species x a 20,000 default),
# which no <=90 MB web build can carry.
_TOTAL_INSTANCE_BUDGET = 12_000
_CLUSTER_MEMBERS = 7  # instances per cluster centre when clustering="grouped"
_TAG_RADIUS_M = 12.0  # how near "near_tags" must be / how far "avoid_tags" pushes


def _footprint_radius(species: dict, descriptors: dict[str, dict]) -> tuple[float, bool]:
    """Half the largest horizontal dimension, from MEASURED bounds when available.

    Returns (radius, measured). Preference order: the measured asset, then the
    planner's declared `size_m`, then a conservative default. A species has no
    entity to measure, so without `size_m` a canopy tree and a fern would be
    spaced identically — which is why the contract carries it. An unmeasured
    species is still placed (`measured=False` is recorded), because refusing to
    scatter is worse than scattering at a declared size.
    """
    descriptor = descriptors.get(species["species_id"]) or {}
    dims = descriptor.get("world_dimensions_m") or descriptor.get("dimensions_m")
    if dims and len(dims) >= 3:
        return max(float(dims[0]), float(dims[2])) / 2.0, True
    declared = species.get("size_m")
    if declared and len(declared) >= 3:
        return max(float(declared[0]), float(declared[2])) / 2.0, False
    return _DEFAULT_FOOTPRINT_M, False


def _zone_rects(
    species: dict, zones: list[dict], enclosure: tuple | None = None
) -> list[dict]:
    """The bounds this species may occupy; empty `zones` means the whole world.

    When the spec draws a closed ring of walls, "the whole world" means the whole world
    INSIDE them. Measured on a warehouse that passed all eighteen gates: the walls
    enclosed 40x60 m of a 77x93 m world, and because scatter samples the world, 219 of
    275 instances -- 80%, including all ten racking units -- were laid down on the ground
    outside the building, leaving the warehouse itself nearly bare. Pallets in a field.

    Clipped here rather than by shrinking the world, which was tried and measured: taking
    the ground away left four wall segments unplaced and dropped the run from 18/18 gates
    to 8/18. The world has to stay generous for placement to solve; only the scatter
    needed to come inside.
    """
    wanted = set(species.get("zones") or ())
    rects = [
        zone["bounds"]
        for zone in zones
        if not wanted or zone["zone_id"] in wanted
    ]
    if enclosure is None:
        return rects

    west, north, east, south = enclosure
    clipped = []
    for rect in rects:
        low_x, high_x = max(rect["min"][0], west), min(rect["max"][0], east)
        low_z, high_z = max(rect["min"][2], north), min(rect["max"][2], south)
        if high_x <= low_x or high_z <= low_z:
            continue  # this zone lies wholly outside the building
        clipped.append(
            {
                "min": [low_x, rect["min"][1], low_z],
                "max": [high_x, rect["max"][1], high_z],
            }
        )
    # A ring of walls that shares no ground with any zone is not a room anything can be
    # scattered into; better the world as it was than nowhere at all.
    return clipped or rects


def _area_of(rects: list[dict]) -> float:
    return sum(
        (r["max"][0] - r["min"][0]) * (r["max"][2] - r["min"][2]) for r in rects
    )


def _tagged_positions(
    placed: list[dict], tags: set[str]
) -> list[tuple[float, float]]:
    """(x, z) of already-placed entities whose semantic type matches a tag."""
    if not tags:
        return []
    found: list[tuple[float, float]] = []
    for entity in placed:
        semantic = str(entity.get("semantic_type") or "").lower()
        if any(tag.lower() in semantic for tag in tags):
            position = entity.get("transform", {}).get("position_m")
            if position:
                found.append((float(position[0]), float(position[2])))
    return found


def _too_close(
    grid: dict[tuple[int, int], list[tuple[float, float]]],
    cell: float,
    spacing: float,
    x: float,
    z: float,
) -> bool:
    """Poisson-disk rejection against the spatial hash.

    Only the 9 neighbouring cells are compared, so cost stays flat as the count
    grows instead of O(n²) against every accepted instance.
    """
    cx, cz = int(x // cell), int(z // cell)
    for dx in (-1, 0, 1):
        for dz in (-1, 0, 1):
            for ox, oz in grid.get((cx + dx, cz + dz), ()):
                if (ox - x) ** 2 + (oz - z) ** 2 < spacing * spacing:
                    return True
    return False


def _blocked_by_entity(x: float, z: float, radius: float, placed: list[dict]) -> bool:
    """True when this instance would sit inside a placed entity's footprint."""
    for entity in placed:
        box = entity.get("world_aabb")
        if not box:
            continue
        if (
            box["min"][0] - radius <= x <= box["max"][0] + radius
            and box["min"][2] - radius <= z <= box["max"][2] + radius
        ):
            return True
    return False


# Ground a plant will not grow through. Deliberately not every named surface: soil,
# sand, grass and snow all support growth, and excluding them would empty a meadow.
_HARD_SURFACES = frozenset({"stone", "concrete", "wood", "metal"})
# Categories that read as growing things. A crate on a courtyard is ordinary; a fern
# sprouting from cobbles is not.
_GROWING = frozenset({"foliage"})


def _on_hard_surface(x: float, z: float, species: dict, regions: list[dict]) -> bool:
    """Whether a growing species would land on paving.

    Only foliage is refused, and only over a hard region. The test is the same
    ray-crossing one `pcg/regions.py` uses to paint, so what is refused is exactly
    what is painted -- a species rejected on ground the renderer did not actually
    pave would be a silent inconsistency between two ideas of the same square metre.
    """
    if not regions:
        return False
    category = ((species.get("asset") or {}).get("category") or "").lower()
    if category not in _GROWING:
        return False
    from pcg.regions import _point_in_polygon

    return any(_point_in_polygon(x, z, polygon) for polygon in regions)


def instance_scatter(
    spec: dict,
    zones: list[dict],
    placed: list[dict],
    asset_descriptors: dict[str, dict] | None = None,
    ground_y: float = 0.0,
    terrain: Any | None = None,
    enclosure: tuple | None = None,
) -> dict:
    """Expand every `scatter` species into seeded instances.

    `placed` is the already-solved entity list (landmarks, agents, interactables):
    scatter is deliberately laid down LAST so it can never displace or block the
    content that matters. Returns instances plus a per-species report of what was
    actually achieved.
    """
    descriptors = asset_descriptors or {}
    seed = spec["meta"]["seed"]
    # Painted hard ground, resolved once rather than per candidate point.
    from pcg.regions import _polygon_of

    hard_regions = [
        polygon
        for polygon in (
            _polygon_of(region)
            for region in (spec.get("regions") or ())
            if isinstance(region, dict)
            and str(region.get("surface") or "") in _HARD_SURFACES
        )
        if len(polygon) >= 3
    ]
    # Sorted so the output is stable regardless of the order the planner emitted.
    species_list = sorted(spec.get("scatter") or (), key=lambda item: item["species_id"])

    instances: list[dict] = []
    reports: list[dict] = []

    # --- Budget pass -------------------------------------------------------
    # Density x area is unbounded: a real run asked for 50/100m2 across a
    # 500x500 m world and wanted 126,000 instances, which no web build can carry.
    # Work out what every species wants FIRST, then scale the whole set to the
    # budget proportionally, so one greedy species cannot starve the others and
    # the mix the planner intended is preserved.
    wanted_by_id: dict[str, int] = {}
    # species_id -> (what density asked for, what max_instances allowed)
    capped_by_id: dict[str, tuple[int, int]] = {}
    for species in species_list:
        rects = _zone_rects(species, zones, enclosure)
        area = _area_of(rects)
        raw = max(0, int(float(species["density_per_100m2"]) * area / 100.0))
        # Only an EXPLICIT cap applies before scaling. Applying the default cap
        # here flattened the mix — six species with densities from 4.5 to 15 all
        # clipped to the same number, so the planner's proportions were lost
        # before scaling could preserve them.
        explicit_cap = species.get("max_instances")
        if explicit_cap and int(explicit_cap) < raw:
            # Remember that density was not what limited this species, so the report
            # does not claim it got what it asked for. A lamp capped from 168 to 6
            # otherwise came out as requested=6, achieved=6, shortfall=None -- which
            # is the one thing this report exists not to do (rules 11/13).
            capped_by_id[species["species_id"]] = (raw, int(explicit_cap))
            raw = int(explicit_cap)
        wanted_by_id[species["species_id"]] = raw

    total_wanted = sum(wanted_by_id.values())
    budget_scale = (
        _TOTAL_INSTANCE_BUDGET / total_wanted
        if total_wanted > _TOTAL_INSTANCE_BUDGET
        else 1.0
    )
    if budget_scale < 1.0:
        # Proportional, so a dense understorey stays denser than sparse canopy.
        # No per-species ceiling is applied afterwards: the global budget already
        # bounds the total, and clipping the densest species on top of scaling just
        # discarded the mix the planner asked for (a 15/100m2 species came out only
        # 2.2x a 4.5/100m2 one instead of 3.3x). If the planner wants a world that
        # is mostly ferns, that is a legitimate design choice.
        wanted_by_id = {
            species_id: max(1, int(count * budget_scale))
            for species_id, count in wanted_by_id.items()
        }

    for species in species_list:
        species_id = species["species_id"]
        rng = random.Random(f"{seed}:scatter:{species_id}")
        rects = _zone_rects(species, zones, enclosure)
        area = _area_of(rects)
        radius, measured = _footprint_radius(species, descriptors)

        requested_density = float(species["density_per_100m2"])
        wanted = wanted_by_id[species_id]

        clustering = species.get("clustering") or "random"
        # "even" spreads further apart than the geometry demands; "random" only
        # respects the footprint; "grouped" packs members inside loose clusters.
        spacing = {
            "even": 2.5 * radius * 2.0,
            "random": 2.0 * radius,
            "grouped": 2.0 * radius,
        }[clustering]
        spacing = max(spacing, 0.05)

        near = _tagged_positions(placed, set(species.get("near_tags") or ()))
        avoid = _tagged_positions(placed, set(species.get("avoid_tags") or ()))

        # Cluster centres first for "grouped", so members form thickets rather
        # than an even sprinkle.
        centres: list[tuple[float, float]] = []
        if clustering == "grouped" and wanted:
            for _ in range(max(1, wanted // _CLUSTER_MEMBERS)):
                rect = rng.choice(rects) if rects else None
                if rect is None:
                    break
                centres.append(
                    (
                        rng.uniform(rect["min"][0], rect["max"][0]),
                        rng.uniform(rect["min"][2], rect["max"][2]),
                    )
                )

        # Spatial hash keyed by cell = spacing, so a candidate only compares
        # against neighbours instead of every accepted instance.
        cell = max(spacing, 0.05)
        grid: dict[tuple[int, int], list[tuple[float, float]]] = {}

        placed_count = 0
        attempts = 0
        # A limit is only enforceable against a field. Without one the sampler
        # cannot judge slope at all, which is a different statement from the ground
        # being level, and the report says which of the two happened.
        raw_limit = species.get("slope_max_degrees")
        slope_limit = float(raw_limit) if raw_limit is not None else None
        too_steep = 0
        budget = max(1, wanted) * _ATTEMPTS_PER_INSTANCE
        while placed_count < wanted and attempts < budget and rects:
            attempts += 1
            if centres:
                # Members orbit a cluster centre; the radius keeps thickets tight.
                ox, oz = rng.choice(centres)
                spread = spacing * 3.0
                x = ox + rng.uniform(-spread, spread)
                z = oz + rng.uniform(-spread, spread)
                rect = rects[0]
                inside = any(
                    r["min"][0] <= x <= r["max"][0] and r["min"][2] <= z <= r["max"][2]
                    for r in rects
                )
                if not inside:
                    continue
            else:
                rect = rng.choice(rects)
                x = rng.uniform(rect["min"][0], rect["max"][0])
                z = rng.uniform(rect["min"][2], rect["max"][2])

            if slope_limit is not None and terrain is not None:
                if terrain.slope_degrees_at(x, z) > slope_limit:
                    too_steep += 1
                    continue
            if _too_close(grid, cell, spacing, x, z):
                continue
            # A paved yard is paved. Foliage strewn across a cobbled square is the
            # same category of wrong as the 2,239 loose slabs that `regions` replaced,
            # only from the other direction -- the surface says stone and the world
            # puts ferns on it. Hard surfaces repel growing things; a boulder or a
            # crate on a courtyard is perfectly ordinary and is left alone.
            if _on_hard_surface(x, z, species, hard_regions):
                continue
            if _blocked_by_entity(x, z, radius, placed):
                continue
            if avoid and any(
                (ax - x) ** 2 + (az - z) ** 2 < _TAG_RADIUS_M**2 for ax, az in avoid
            ):
                continue
            if near and not any(
                (nx - x) ** 2 + (nz - z) ** 2 < _TAG_RADIUS_M**2 for nx, nz in near
            ):
                continue

            jitter = float(species.get("scale_jitter") or 0.0)
            scale = 1.0 + rng.uniform(-jitter, jitter) if jitter else 1.0
            instances.append(
                {
                    "species_id": species_id,
                    # Each instance meets the ground under it. A single scalar
                    # was right while the ground was a plane; over relief it
                    # leaves half a wood hanging in the air and buries the rest.
                    "position_m": [
                        round(x, 4),
                        round(
                            terrain.height_at(x, z) if terrain is not None else ground_y,
                            4,
                        ),
                        round(z, 4),
                    ],
                    "yaw_degrees": round(rng.uniform(0.0, 360.0), 2),
                    "scale": round(scale, 4),
                }
            )
            grid.setdefault((int(x // cell), int(z // cell)), []).append((x, z))
            placed_count += 1

        achieved = (placed_count / area * 100.0) if area else 0.0
        shortfall = None
        if species_id in capped_by_id:
            # Reported first so a later geometric reason can still override it: if the
            # capped count ALSO failed to pack, packing is the more specific truth.
            shortfall = "instance_cap"
        if budget_scale < 1.0:
            # The ask was affordable per-species but not in total; say so, rather
            # than let it look like the geometry could not pack.
            shortfall = "instance_budget"
        if placed_count < wanted:
            # Say WHY, so an impossible ask is visible rather than silently lost.
            shortfall = (
                "no_placeable_area"
                if not rects
                else "near_tags_unsatisfiable"
                if near and not placed_count
                else "slope_limit"
                if too_steep > attempts / 2
                else "packing_limit"
            )
        # Only ignored when there is no field to judge it against. That used to be
        # always: the ground was a single flat slab, so a slope limit was not
        # "satisfied" but meaningless, and disclosing it kept a spec from claiming a
        # guarantee nothing enforced (rules 11/13). With a heightfield the limit is
        # enforced above, so continuing to call it ignored would be the dishonest
        # direction of the same rule.
        ignored = (
            ["slope_max_degrees"]
            if slope_limit is not None and terrain is None
            else []
        )

        reports.append(
            {
                "species_id": species_id,
                "requested_density_per_100m2": requested_density,
                "ignored_constraints": ignored,
                "achieved_density_per_100m2": round(achieved, 4),
                "requested_instances": capped_by_id.get(species_id, (wanted,))[0],
                "capped_to_instances": capped_by_id.get(species_id, (None, None))[1],
                "placed_instances": placed_count,
                "spacing_m": round(spacing, 4),
                "footprint_measured": measured,
                "clustering": clustering,
                "shortfall_reason": shortfall,
            }
        )

    return {"instances": instances, "species": reports}
