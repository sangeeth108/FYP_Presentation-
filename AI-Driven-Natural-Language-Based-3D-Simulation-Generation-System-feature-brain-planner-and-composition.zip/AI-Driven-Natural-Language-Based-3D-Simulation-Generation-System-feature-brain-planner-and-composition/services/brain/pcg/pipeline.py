"""S4 pipeline entry point: validated game_spec dict -> zone graph + layout + placement.

This is the seam the project writer (S6) will consume. It reads exactly the
spec fields the schema guarantees (``meta.seed``, ``world.zone_graph.*``,
``entities.enemies[]``, ``entities.props[]``) and runs the three seeded
stages in order. No LLM anywhere below this line (ambiguity up,
determinism down).
"""

from __future__ import annotations

from dataclasses import dataclass

from pcg.layout import Layout, generate_layout
from pcg.placement import (
    EnemySpec,
    PlacementResult,
    PropSpec,
    generate_placement,
)
from pcg.zone_graph import ZoneGraph, generate_zone_graph


@dataclass
class PCGOutput:
    graph: ZoneGraph
    layout: Layout
    placement: PlacementResult


def run_pcg(spec: dict) -> PCGOutput:
    """Run S4 for a schema-valid game_spec. Raises PCGError on any stage failure."""
    zone_graph_spec = spec["world"]["zone_graph"]
    graph = generate_zone_graph(
        seed=spec["meta"]["seed"],
        zone_count=zone_graph_spec["zone_count"],
        algorithm=zone_graph_spec["algorithm"],
        verticality_tiers=zone_graph_spec.get("verticality_tiers", 1),
    )
    layout = generate_layout(graph)

    enemies = [
        EnemySpec(enemy_id=e["enemy_id"], count=e["count"])
        for e in spec["entities"]["enemies"]
    ]
    props = [
        PropSpec(prop_id=p["prop_id"], placement_tags=tuple(p.get("placement_tags", [])))
        for p in spec["entities"]["props"]
    ]
    placement = generate_placement(graph, layout, enemies, props)
    return PCGOutput(graph=graph, layout=layout, placement=placement)
