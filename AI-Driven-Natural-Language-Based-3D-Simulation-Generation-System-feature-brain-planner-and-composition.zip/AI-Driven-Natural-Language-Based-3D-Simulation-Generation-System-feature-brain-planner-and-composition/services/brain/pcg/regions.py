"""Paint declared regions onto the world's existing heightfield.

Measured: the village's paths came back as **2,239 loose paving slabs**, instanced as
scatter with no collision, because the contract could only express objects and the only
way to say "this ground is paved" was to strew slab-shaped things over it.

That is the 59-wall-panels mistake (ADR-0016) one dimension up. A yard is not a
collection of slabs; it is a region of ground with a different surface. The ground already
carries a synthesised material and real relief, so the honest representation is a second
surface painted onto the same grid -- free per square metre, exactly following the slope,
and adding no objects at all.

The output is a per-vertex family index over the terrain grid, shipped in the plan's
terrain block. `terrain_field.gd` already builds the ground mesh from that grid at load,
so it can read one more array and give each vertex a colour; no textures, no shader
authoring, and nothing that GL Compatibility cannot draw.

Rule 15, as everywhere: the planner NAMES a vetted family and this code alone decides
what a name looks like. Index 0 always means "the world's own surface", so a plan with no
regions produces a grid of zeros that changes nothing.
"""

from __future__ import annotations

# Index 0 is reserved for the base ground, so an absent or unpaintable region simply
# leaves the world as it was.
BASE_INDEX = 0


def _point_in_polygon(x: float, z: float, polygon: list[tuple[float, float]]) -> bool:
    """Ray-crossing test, counting crossings of the horizontal line through (x, z).

    Chosen over a winding-number test because the contract explicitly does not
    constrain winding: a planner drawing a courtyard clockwise and one drawing it
    anticlockwise must get the same yard. Crossing parity does not care.

    The `(z < zj) != (z < zi)` form is the half-open convention, so a vertex lying
    exactly on the scan line is counted once rather than twice or never -- which is
    what stops a grid-aligned rectangle, the most common case by far, from developing
    a one-cell seam along its own edge.
    """
    inside = False
    count = len(polygon)
    for index in range(count):
        xi, zi = polygon[index]
        xj, zj = polygon[(index - 1) % count]
        if (z < zi) != (z < zj):
            crossing = xi + (z - zi) / (zj - zi) * (xj - xi)
            if x < crossing:
                inside = not inside
    return inside


def _coordinate_pairs(values) -> list[tuple[float, float]]:
    """Read [x1, z1, x2, z2, ...] or the older [[x, z], ...], whichever is present.

    The contract now asks for a flat list, because the planner demonstrably produces
    those and avoids nested arrays -- five uses of `linear_structures` against zero of
    `routes` with otherwise identical definitions. Both shapes are accepted so a spec
    written before the change, or preserved through a repair, still reads.
    """
    points: list[tuple[float, float]] = []
    items = list(values or ())
    if items and isinstance(items[0], (list, tuple)):
        for item in items:
            try:
                points.append((float(item[0]), float(item[1])))
            except (TypeError, ValueError, IndexError):
                continue
        return points
    for index in range(0, len(items) - 1, 2):
        try:
            points.append((float(items[index]), float(items[index + 1])))
        except (TypeError, ValueError):
            continue
    return points


def _polygon_of(region: dict) -> list[tuple[float, float]]:
    return _coordinate_pairs(region.get("polygon_m"))


def paint_regions(
    spec: dict, width_m: float, depth_m: float, grid: int
) -> tuple[list[int], list[str], list[dict]]:
    """Rasterise `regions` onto a `grid` x `grid` lattice over the world.

    Returns (per-vertex family indices, the family table those index into,
    approximation records). The table's first entry is always the empty string,
    meaning "whatever the world's own surface is" -- resolving that name here would
    duplicate a decision `environment.terrain_surface` already owns.

    Later regions win where two overlap. Declaration order is the only tie-break that
    does not require inventing a rule the planner cannot see: area would mean a small
    inset yard could never sit inside a large paved square, which is a normal thing to
    describe.

    The lattice matches the terrain's own, so a painted vertex and its height are the
    same vertex. Sampling at a different resolution would put the seam between two
    surfaces somewhere other than where the ground changes shape.
    """
    regions = [
        region
        for region in (spec.get("regions") or ())
        if isinstance(region, dict) and str(region.get("region_id", "")).startswith("rgn_")
    ]
    families: list[str] = [""]
    approximations: list[dict] = []
    if not regions or grid < 2 or width_m <= 0.0 or depth_m <= 0.0:
        return [BASE_INDEX] * (max(0, grid) * max(0, grid)), families, approximations

    painted = [BASE_INDEX] * (grid * grid)
    step_x = width_m / (grid - 1)
    step_z = depth_m / (grid - 1)
    origin_x = -width_m / 2.0
    origin_z = -depth_m / 2.0

    for region in regions:
        polygon = _polygon_of(region)
        surface = str(region.get("surface") or "")
        region_id = str(region.get("region_id") or "unknown")
        if len(polygon) < 3 or not surface:
            approximations.append(
                {
                    "requirement_id": region_id,
                    "reason": (
                        "this area was missing the outline or the surface needed to "
                        "paint it, so the ground there is unchanged"
                    )[:300],
                    "user_visible": True,
                }
            )
            continue

        if surface in families:
            index = families.index(surface)
        else:
            families.append(surface)
            index = len(families) - 1

        # Bounded to the polygon's own box, so a 4 m yard costs sixteen tests rather
        # than one per vertex of a 128x128 world.
        xs = [point[0] for point in polygon]
        zs = [point[1] for point in polygon]
        low_col = max(0, int((min(xs) - origin_x) / step_x) - 1)
        high_col = min(grid - 1, int((max(xs) - origin_x) / step_x) + 1)
        low_row = max(0, int((min(zs) - origin_z) / step_z) - 1)
        high_row = min(grid - 1, int((max(zs) - origin_z) / step_z) + 1)

        touched = 0
        for row in range(low_row, high_row + 1):
            z = origin_z + row * step_z
            for column in range(low_col, high_col + 1):
                x = origin_x + column * step_x
                if _point_in_polygon(x, z, polygon):
                    painted[row * grid + column] = index
                    touched += 1

        if not touched:
            # Smaller than one cell of the grid, or entirely off the world. Saying so
            # matters: a courtyard that vanished is a courtyard somebody asked for, and
            # silence would make the ground look simply wrong rather than explained.
            approximations.append(
                {
                    "requirement_id": region_id,
                    "reason": (
                        f"this {surface} area is smaller than one cell of the ground's "
                        f"{step_x:.1f} m grid, or lies outside the world, so it could "
                        "not be painted"
                    )[:300],
                    "user_visible": True,
                }
            )

    return painted, families, approximations
