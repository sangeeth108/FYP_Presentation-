"""Where a spec's walls enclose a place.

One definition, two readers. The planner asks so it can tell a boundary drawn corner to
corner from a wall (`_enclosures_are_perimeters`); the scatter sampler asks so mass
content lands inside the building rather than in the field beside it. `entities_conflict`
drifted ten times by being defined once and copied twice, so this is imported by both
rather than mirrored in either.
"""

from __future__ import annotations

# Words that make a run a BOUNDARY rather than a road, a hedge row or a pipe.
ENCLOSURE_WORDS = (
    "wall",
    "fence",
    "perimeter",
    "boundary",
    "barrier",
    "hedge",
    "railing",
    "enclosure",
)

# How much of a side a run must cover before that side counts as walled. Half: a wall
# with a loading bay cut out of it is still that side of the building.
_EDGE_COVERAGE = 0.5


def names_an_enclosure(run: dict) -> bool:
    """Does this run describe a boundary, by its id, its type or its own description?"""
    haystack = " ".join(
        str(run.get(field) or "")
        for field in ("structure_id", "semantic_type", "source_text")
    ).lower()
    return any(word in haystack for word in ENCLOSURE_WORDS)


def _endpoints(run: dict) -> tuple[tuple[float, float], tuple[float, float]] | None:
    start, end = run.get("from_m"), run.get("to_m")
    if not (isinstance(start, list) and isinstance(end, list)):
        return None
    if len(start) < 2 or len(end) < 2:
        return None
    try:
        return (float(start[0]), float(start[1])), (float(end[0]), float(end[1]))
    except (TypeError, ValueError):
        return None


def enclosure_extent(runs) -> tuple[float, float, float, float] | None:
    """The rectangle a CLOSED ring of boundary runs encloses, as (west, north, east, south).

    All four sides must be walled. Three walls and an open side is a courtyard, a bay or
    a half-built thing, and nothing should be inferred from its extent.
    """
    if not isinstance(runs, list):
        return None
    edges = [
        endpoints
        for run in runs
        if isinstance(run, dict) and names_an_enclosure(run)
        for endpoints in (_endpoints(run),)
        if endpoints is not None
    ]
    if len(edges) < 4:
        return None

    xs = [x for edge in edges for x, _ in edge]
    zs = [z for edge in edges for _, z in edge]
    west, east, north, south = min(xs), max(xs), min(zs), max(zs)
    width, depth = east - west, south - north
    if width <= 0.0 or depth <= 0.0:
        return None
    margin = 0.05 * max(width, depth)

    def walled(vertical: bool, at: float, length: float) -> bool:
        for (x0, z0), (x1, z1) in edges:
            along = (x0, x1) if vertical else (z0, z1)
            across = (z0, z1) if vertical else (x0, x1)
            if abs(along[0] - at) > margin or abs(along[1] - at) > margin:
                continue
            if abs(across[1] - across[0]) >= _EDGE_COVERAGE * length:
                return True
        return False

    if not (
        walled(True, west, depth)
        and walled(True, east, depth)
        and walled(False, north, width)
        and walled(False, south, width)
    ):
        return None
    return west, north, east, south
