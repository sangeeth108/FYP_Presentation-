"""Seeded entity placement (S4, step 3 of the deterministic spine).

Takes the ZoneGraph + Layout and the spec's entity lists and assigns every
enemy and prop a concrete (x, z, elevation) inside a room, by rejection
sampling within the room rect (CLAUDE.md rule: measure, don't assume).

Placement rules (mirrors GOLDEN_GAME_TASKS / the spec's placement_tags):
- enemies prefer ``combat`` zones (fallback: any zone that is not the entry
  or the exit) and keep a safe-spawn distance from the entry room center;
- props tagged ``spawn`` go to the entry room, ``loot`` to loot zones when
  any exist; everything else lands in any non-exit room;
- every placement keeps a minimum separation from entities already placed
  in the same room.

Determinism (rule 14): uses ``random.Random(f"{seed}:placement")`` — a
string seed hashes via sha512 inside CPython's Random, so it is stable
across processes and platforms (unlike built-in ``hash``).
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

from pcg.layout import Layout, Rect
from pcg.zone_graph import PCGError, ZoneGraph

WALL_MARGIN = 1.0  # keep entities off the walls
MIN_SEPARATION = 1.5  # between entities in the same room
SAFE_SPAWN_DISTANCE = 8.0  # enemies keep this from the entry room center
MAX_SAMPLE_ATTEMPTS = 96


@dataclass(frozen=True)
class EnemySpec:
    enemy_id: str
    count: int


@dataclass(frozen=True)
class PropSpec:
    prop_id: str
    placement_tags: tuple[str, ...] = ()


@dataclass(frozen=True)
class PlacedEntity:
    entity_id: str  # unique instance id, e.g. "castle_guard_shambler_02"
    source_id: str  # the spec's enemy_id / prop_id
    kind: str  # enemy | prop
    zone_id: str
    x: float
    z: float
    elevation: float


@dataclass
class PlacementResult:
    seed: int
    entities: list[PlacedEntity] = field(default_factory=list)
    # Entities the level physically could not hold, e.g. 25 enemies asked for a
    # single 6x6 room. Recorded, never silent: {source_id, kind, requested, placed}.
    dropped: list[dict] = field(default_factory=list)

    def in_zone(self, zone_id: str) -> list[PlacedEntity]:
        return [e for e in self.entities if e.zone_id == zone_id]


def _zones_of_kind(graph: ZoneGraph, kind: str) -> list[str]:
    return [z.zone_id for z in graph.zones if z.kind == kind]


def _sample_point(
    rng: random.Random,
    rect: Rect,
    taken: list[tuple[float, float]],
    keep_away: tuple[float, float, float] | None,
    separation: float = MIN_SEPARATION,
) -> tuple[float, float] | None:
    """Rejection-sample a point in the rect honoring margin/separation. None if budget runs out."""
    if rect.width <= 2 * WALL_MARGIN or rect.depth <= 2 * WALL_MARGIN:
        return None
    for _ in range(MAX_SAMPLE_ATTEMPTS):
        x = rng.uniform(rect.x + WALL_MARGIN, rect.x + rect.width - WALL_MARGIN)
        z = rng.uniform(rect.z + WALL_MARGIN, rect.z + rect.depth - WALL_MARGIN)
        if any(math.hypot(x - tx, z - tz) < separation for tx, tz in taken):
            continue
        if keep_away is not None:
            ax, az, dist = keep_away
            if math.hypot(x - ax, z - az) < dist:
                continue
        return (x, z)
    return None


# Last-resort spacing before we declare a level physically unable to hold an
# entity. Still honors the wall margin and the safe-spawn radius — the world
# just gets more crowded, which is far better than losing the whole game.
CROWDED_SEPARATION = MIN_SEPARATION / 2


def _first_fit(
    rng: random.Random,
    zone_ids: list[str],
    layout: Layout,
    taken_by_zone: dict[str, list[tuple[float, float]]],
    keep_away: tuple[float, float, float] | None,
    separation: float,
) -> tuple[str, object, tuple[float, float]] | None:
    """First zone in the given order that can host a point. None if none can."""
    for zone_id in zone_ids:
        room = layout.rooms[zone_id]
        point = _sample_point(rng, room.rect, taken_by_zone[zone_id], keep_away, separation)
        if point is not None:
            return (zone_id, room, point)
    return None


def _prop_target_zones(tags: tuple[str, ...], graph: ZoneGraph) -> list[str]:
    if "spawn" in tags:
        return _zones_of_kind(graph, "entry")
    if "loot" in tags:
        loot = _zones_of_kind(graph, "loot")
        if loot:
            return loot
    return [z.zone_id for z in graph.zones if z.kind != "exit"]


def generate_placement(
    graph: ZoneGraph,
    layout: Layout,
    enemies: list[EnemySpec],
    props: list[PropSpec],
) -> PlacementResult:
    """Place every enemy instance and prop; raises PCGError when a room cannot host one."""
    rng = random.Random(f"{graph.seed}:placement")
    result = PlacementResult(seed=graph.seed)
    taken_by_zone: dict[str, list[tuple[float, float]]] = {z.zone_id: [] for z in graph.zones}

    entry_id = _zones_of_kind(graph, "entry")[0]
    entry_center = layout.rooms[entry_id].rect.center()

    # Combat zones are the PREFERENCE, every other non-entry/non-exit zone is
    # spillover — a lone small combat room must never cap the enemy count
    # (a horde brief with one 7x7 combat zone failed exactly this way).
    combat_zones = _zones_of_kind(graph, "combat")
    other_zones = [
        z.zone_id
        for z in graph.zones
        if z.kind not in ("entry", "exit") and z.zone_id not in combat_zones
    ]
    enemy_zones = combat_zones + other_zones
    preferred_count = max(len(combat_zones), 1) if combat_zones else len(enemy_zones)

    # Safe spawn is a world-space rule: even a room adjacent to the entry
    # must not host an enemy inside the safe radius.
    keep_away = (entry_center[0], entry_center[1], SAFE_SPAWN_DISTANCE)

    for spec in enemies:
        for i in range(spec.count):
            # Round-robin across the preferred zones, then deterministic
            # spillover through every remaining candidate: a crowded or
            # safe-radius-shadowed zone must not fail the whole placement
            # while other candidate zones still have room.
            start = (i + len(result.entities)) % preferred_count
            placed = None
            for offset in range(len(enemy_zones)):
                zone_id = enemy_zones[(start + offset) % len(enemy_zones)]
                room = layout.rooms[zone_id]
                point = _sample_point(rng, room.rect, taken_by_zone[zone_id], keep_away)
                if point is not None:
                    placed = (zone_id, room, point)
                    break
            if placed is None:
                # Every candidate zone is full at normal spacing. Crowd them
                # rather than lose the game: the LLM authors far richer worlds
                # than the rule parser (28 entities vs 15), and two of the 20
                # frozen prompts died here with a hard PCGError.
                placed = _first_fit(
                    rng, enemy_zones, layout, taken_by_zone, keep_away, CROWDED_SEPARATION
                )
            if placed is None:
                # Still nothing. In a small level the 8m safe-spawn bubble can
                # shadow an ENTIRE neighbouring room, rejecting every sample —
                # so the last rung halves it. 4m is still well clear of the
                # player's feet, and a tight spawn beats no game at all.
                close_but_safe = (entry_center[0], entry_center[1], SAFE_SPAWN_DISTANCE / 2)
                placed = _first_fit(
                    rng, enemy_zones, layout, taken_by_zone, close_but_safe, CROWDED_SEPARATION
                )
            if placed is None:
                # The level is physically full — e.g. a 3-zone brief whose only
                # combat room is 6x6 cannot hold 25 enemies at any legal spacing.
                # Playability outranks designer intent (the constraint stack), so
                # cap the roster at what fits and RECORD it. Crashing the whole
                # job over the 25th skeleton would be the worse answer.
                result.dropped.append(
                    {
                        "source_id": spec.enemy_id,
                        "kind": "enemy",
                        "requested": spec.count,
                        "placed": i,
                    }
                )
                break
            zone_id, room, point = placed
            taken_by_zone[zone_id].append(point)
            result.entities.append(
                PlacedEntity(
                    entity_id=f"{spec.enemy_id}_{i + 1:02d}",
                    source_id=spec.enemy_id,
                    kind="enemy",
                    zone_id=zone_id,
                    x=point[0],
                    z=point[1],
                    elevation=room.elevation,
                )
            )

    for spec in props:
        candidates = list(_prop_target_zones(spec.placement_tags, graph))
        rng.shuffle(candidates)  # seeded => deterministic order
        placed = None
        for zone_id in candidates:
            room = layout.rooms[zone_id]
            point = _sample_point(rng, room.rect, taken_by_zone[zone_id], None)
            if point is not None:
                placed = (zone_id, room, point)
                break
        if placed is None:
            # The tagged zones are full. Props have no safe-radius rule, so spill
            # into ANY room but the exit (which must stay a clean win space), then
            # crowd if even that is full. A themed placement is a nice-to-have; a
            # game that fails to generate is not.
            spillover = [z.zone_id for z in graph.zones if z.kind != "exit"]
            placed = _first_fit(rng, spillover, layout, taken_by_zone, None, MIN_SEPARATION)
        if placed is None:
            placed = _first_fit(rng, spillover, layout, taken_by_zone, None, CROWDED_SEPARATION)
        if placed is None:
            result.dropped.append(
                {"source_id": spec.prop_id, "kind": "prop", "requested": 1, "placed": 0}
            )
            continue
        zone_id, room, point = placed
        taken_by_zone[zone_id].append(point)
        result.entities.append(
            PlacedEntity(
                entity_id=spec.prop_id,
                source_id=spec.prop_id,
                kind="prop",
                zone_id=zone_id,
                x=point[0],
                z=point[1],
                elevation=room.elevation,
            )
        )

    # Crowding out the last few entities is a design compromise; placing NOTHING
    # is a broken level, and shipping an empty world silently would be the worst
    # outcome of all. That still raises, loudly and machine-readably.
    requested = sum(e.count for e in enemies) + len(props)
    if requested and not result.entities:
        raise PCGError(
            code="placement_impossible",
            path="entities",
            message=f"not one of {requested} entities could be placed in any zone",
            hint="Rooms are too small or the sampler is misconfigured — this is not crowding.",
        )
    return result
