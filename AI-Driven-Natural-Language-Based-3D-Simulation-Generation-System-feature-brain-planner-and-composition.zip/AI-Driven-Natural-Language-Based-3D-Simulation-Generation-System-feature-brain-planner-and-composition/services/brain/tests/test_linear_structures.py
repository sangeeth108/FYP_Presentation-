"""A wall is one declared run, not fifty-nine scattered panels.

Measured on the village diagnostic: the boundary wall arrived as 59 loose scatter
panels, because the contract had no way to say "a wall runs from here to there". The
planner was not being careless -- it was describing a settlement with a language that
had no word for a line.

These tests pin the two halves of the fix. The planner gives two endpoints and a
cross-section; deterministic code decides segment count, length, orientation, openings
and terrain seating, because all of that is rendering economics rather than design.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path

import jsonschema
import pytest
from pcg.linear import _MAX_SEGMENTS, _solid_spans, expand_linear_structures
from pcg.semantic import generate_semantic_world_plan, validate_semantic_world_plan

from tests.test_simulation_core import _dog_village

_CONTRACT = (
    Path(__file__).resolve().parents[3] / "contracts" / "simulation_spec.schema.json"
)


def _run(**overrides) -> dict:
    run = {
        "structure_id": "lin_boundary_wall",
        "semantic_type": "dry_stone_boundary_wall",
        "source_text": "a village",
        "from_m": [-30.0, -20.0],
        "to_m": [30.0, -20.0],
        "height_m": 1.8,
        "thickness_m": 0.5,
        "asset": {
            "brief": "a dry stone wall segment",
            "category": "structure",
            "requires_animation": False,
            "preferred_source": "either",
            "procedural_type": "semantic_box",
            "palette_hex": ["#8d8579"],
        },
    }
    run.update(overrides)
    return run


def _segments(spec: dict, stem: str = "boundary_wall") -> list[dict]:
    return [
        entity
        for entity in spec["entities"]
        if entity["entity_id"].startswith(f"ent_{stem}_s")
    ]


def _spec_with(*runs: dict) -> dict:
    spec = copy.deepcopy(_dog_village())
    spec["linear_structures"] = list(runs)
    return spec


def test_a_declared_run_becomes_a_line_of_segments_that_reaches_both_ends():
    """The run's ends are what the planner said; everything between is ours.

    A wall that stops short of where it was declared to end is a different wall, so
    the segmentation has to divide the run exactly rather than approximately.
    """
    spec = _spec_with(_run())
    expand_linear_structures(spec)
    segments = _segments(spec)
    assert len(segments) == _MAX_SEGMENTS  # a 60 m run, at the per-run ceiling

    xs = sorted(
        (
            entity["placement"]["anchor_m"][0],
            entity["physical"]["bbox_m"][0],
        )
        for entity in segments
    )
    left = xs[0][0] - xs[0][1] / 2.0
    right = xs[-1][0] + xs[-1][1] / 2.0
    # Each end is pulled in by half the run's thickness plus the joint, so two runs
    # meeting at a corner do not fight over it. On this 0.5 m wall that is 0.26 m --
    # deliberate, and the alternative is a corner segment that never places at all.
    inset = 0.5 / 2.0 + 0.01
    assert left == pytest.approx(-30.0 + inset, abs=0.02)
    assert right == pytest.approx(30.0 - inset, abs=0.02)

    # One run, one direction. A diagonal wall whose segments each chose their own
    # yaw would read as a heap of blocks rather than a wall.
    assert len({entity["placement"]["anchor_yaw_degrees"] for entity in segments}) == 1
    assert len({entity["placement"]["anchor_m"][1] for entity in segments}) == 1


def test_a_gate_is_exactly_as_wide_as_it_was_asked_to_be():
    """This is the defect the span construction exists to prevent.

    The first version segmented the whole run and dropped any segment an opening
    touched, so a 3 m gate consumed two 3.75 m segments and opened the wall by
    7.5 m. Subtracting the openings BEFORE segmenting makes the gate a hole in the
    input rather than a casualty of the output.
    """
    spec = _spec_with(_run(openings=[{"at_fraction": 0.5, "width_m": 3.0}]))
    expand_linear_structures(spec)
    segments = _segments(spec)

    anchors = sorted(entity["placement"]["anchor_m"][0] for entity in segments)
    width_at = {
        entity["placement"]["anchor_m"][0]: entity["physical"]["bbox_m"][0]
        for entity in segments
    }
    left = max(x for x in anchors if x < 0)
    right = min(x for x in anchors if x > 0)
    gate = (right - width_at[right] / 2.0) - (left + width_at[left] / 2.0)
    assert gate == pytest.approx(3.0, abs=0.02)


def test_a_run_with_no_opening_is_still_built_but_the_contract_warns_about_it():
    """Deliberately not enforced here.

    A run that closes around something seals it off, and reachability validation is
    what catches that -- with the whole world's geometry in front of it, which this
    function does not have. A straight wall across open ground encloses nothing, so
    refusing every opening-less run would reject correct worlds.
    """
    spec = _spec_with(_run())
    approximations = expand_linear_structures(spec)
    assert _segments(spec)
    assert not [note for note in approximations if note["user_visible"]]

    schema = json.loads(_CONTRACT.read_text(encoding="utf-8"))
    described = schema["$defs"]["linear_structure"]["properties"]["openings"][
        "description"
    ]
    assert "reachability" in described


def test_two_ends_in_the_same_place_are_refused_and_disclosed():
    """A run that goes nowhere is not a run.

    Building it anyway would emit one segment shorter than the wall is thick -- a
    post, and a misleading one, since the planner asked for something that goes
    somewhere. So it is refused, and the refusal is user-visible: somebody asked for
    a wall and has not got one.
    """
    spec = _spec_with(_run(from_m=[4.0, 4.0], to_m=[4.2, 4.0]))
    approximations = expand_linear_structures(spec)
    assert not _segments(spec)
    visible = [note for note in approximations if note["user_visible"]]
    assert len(visible) == 1
    assert "thickness" in visible[0]["reason"]


def test_the_segment_budget_is_per_run_not_per_span():
    """A wall broken by three gates must not get three walls' worth of nodes.

    The scope budget is 50-200 props for the WHOLE world, so one 200 m wall cannot
    be allowed to spend it. Each span still keeps at least one segment: a short stub
    between two gates is still wall, and dropping it would leave a gap nobody asked
    for.
    """
    spec = _spec_with(
        _run(
            from_m=[-100.0, 0.0],
            to_m=[100.0, 0.0],
            openings=[
                {"at_fraction": 0.25, "width_m": 3.0},
                {"at_fraction": 0.5, "width_m": 3.0},
                {"at_fraction": 0.75, "width_m": 3.0},
            ],
        )
    )
    expand_linear_structures(spec)
    segments = _segments(spec)
    assert 0 < len(segments) <= _MAX_SEGMENTS + 3  # at most one extra per span floor


def test_overlapping_openings_describe_one_gate():
    """Two gaps that overlap are one gap, not two with a phantom wall between them."""
    spans = _solid_spans(20.0, [
        {"at_fraction": 0.5, "width_m": 6.0},
        {"at_fraction": 0.55, "width_m": 6.0},
    ])
    assert len(spans) == 2
    assert spans[0][1] == pytest.approx(7.0)
    assert spans[1][0] == pytest.approx(14.0)


def test_the_whole_run_traces_to_one_requirement_through_part_of():
    """One described thing, several built things.

    Requiring a separate requirement per segment collides with the rule that a
    requirement's source_text must appear VERBATIM in the prompt -- fifteen of
    sixteen segments could not be sourced. So the first segment carries the run's
    own verbatim source and the rest are `part_of` it, which is precisely the case
    that relation was added for.
    """
    spec = _spec_with(_run())
    expand_linear_structures(spec)
    segments = _segments(spec)

    requirements = [
        item for item in spec["requirements"] if item["subject"].startswith("ent_boundary_wall_s")
    ]
    assert len(requirements) == 1
    assert requirements[0]["subject"] == "ent_boundary_wall_s0"
    assert requirements[0]["source_text"] == "a village"

    grouped = {
        relation["subject_id"]
        for relation in spec["spatial_relations"]
        if relation.get("relation") == "part_of"
        and relation["target_id"] == "ent_boundary_wall_s0"
    }
    assert grouped == {entity["entity_id"] for entity in segments} - {
        "ent_boundary_wall_s0"
    }


def test_the_expanded_spec_still_validates_against_the_contract():
    """The expansion writes entities, relations and a requirement, and all three are
    closed objects with required fields. The first version was missing four of the
    requirement's, which only validating caught."""
    spec = _spec_with(_run(openings=[{"at_fraction": 0.5, "width_m": 3.0}]))
    expand_linear_structures(spec)
    schema = json.loads(_CONTRACT.read_text(encoding="utf-8"))
    jsonschema.Draft202012Validator(schema).validate(spec)


def test_every_segment_places_and_the_wall_validates():
    """The end that matters: abutting segments are legal, and 16 of 16 land.

    Two things had to be true for this. `part_of` waives interaction clearance
    between parts of one object -- with it enforced, half a 16-segment wall was
    rejected against its own neighbours. And segments carry a hairline joint,
    because two boxes that abut EXACTLY are overlapping as far as a separating-axis
    test is concerned.
    """
    spec = _spec_with(_run(openings=[{"at_fraction": 0.5, "width_m": 3.0}]))
    expand_linear_structures(spec)
    plan = generate_semantic_world_plan(spec)

    placed = [
        entity
        for entity in plan["entities"]
        if entity["entity_id"].startswith("ent_boundary_wall_s")
    ]
    assert len(placed) == len(_segments(spec))
    assert not [
        entity_id
        for entity_id in plan["constraint_summary"]["unplaced_entities"]
        if entity_id.startswith("ent_boundary_wall_s")
    ]

    report = validate_semantic_world_plan(plan, require_measured_assets=False)
    assert report["status"] == "PASS", report.get("errors")


def test_a_diagonal_run_keeps_one_yaw_through_placement():
    """The solver picks a random yaw for anything without a reason to face somewhere.

    A run has a reason: its own direction. Left to the random branch, every segment
    of a diagonal wall would face a different way.
    """
    spec = _spec_with(
        _run(
            structure_id="lin_paddock_fence",
            semantic_type="split_rail_fence",
            from_m=[-40.0, 30.0],
            to_m=[-28.0, 42.0],
            height_m=1.1,
            thickness_m=0.12,
        )
    )
    expand_linear_structures(spec)
    plan = generate_semantic_world_plan(spec)
    yaws = {
        entity["transform"]["rotation_y_degrees"]
        for entity in plan["entities"]
        if entity["entity_id"].startswith("ent_paddock_fence_s")
    }
    assert yaws == {-45.0}


def test_the_planner_cannot_write_an_anchor_itself():
    """`anchor_m` is absolute world coordinates, and machine-authored on purpose.

    A model handed raw coordinates starts hand-authoring layouts in them, which is
    the arrangement work this system does deterministically downstream and the whole
    reason `linear_structures` exists. The canonical contract keeps the field, so the
    post-expansion spec validates; the grammar the model decodes against does not.
    """
    from agents.simulation_planner import ollama_simulation_schema, simulation_schema

    guided = ollama_simulation_schema()["$defs"]["entity"]["properties"]["placement"]
    canonical = simulation_schema()["$defs"]["entity"]["properties"]["placement"]
    assert "anchor_m" not in guided["properties"]
    assert "anchor_yaw_degrees" not in guided["properties"]
    assert "anchor_m" in canonical["properties"]
    assert "anchor_yaw_degrees" in canonical["properties"]

    # And the model can still describe the run itself, which is the field it should
    # be reaching for instead.
    assert "linear_structures" in ollama_simulation_schema()["properties"]


def test_no_runs_declared_changes_nothing():
    """The overwhelmingly common case, and it must be free.

    Every spec written before this feature existed has no `linear_structures`, and
    expansion must leave those byte-identical rather than, say, appending an empty
    requirement.
    """
    spec = copy.deepcopy(_dog_village())
    before = copy.deepcopy(spec)
    assert expand_linear_structures(spec) == []
    assert spec == before


def test_expanding_twice_does_not_duplicate_the_wall():
    """Idempotence is a guard, not a feature the caller relies on.

    Segment ids are derived from the run id and index, so a second pass without the
    guard appends a duplicate of every segment -- and duplicate entity ids fail far
    downstream of the mistake that caused them. Today the only caller runs this once,
    which is precisely why the guard belongs here rather than in the caller.
    """
    spec = _spec_with(_run())
    expand_linear_structures(spec)
    first = copy.deepcopy(spec)

    assert expand_linear_structures(spec) == []
    assert spec == first


def test_two_runs_on_the_same_line_are_built_once():
    """Found by the settlement benchmark, in eight minutes, on its first run.

    A farmyard "bounded by a split rail fence" came back as four runs -- north, south,
    east, west -- where north and south were the SAME two endpoints and east and west
    were another identical pair. Sixty-four segments were emitted for two lines and 22
    failed to place, colliding with their own duplicates.

    `part_of` cannot help here: it lets segments of ONE run abut, and these are separate
    runs on identical ground, which is a real overlap. Merged rather than refused,
    because the planner asked for a boundary and should get one.
    """
    spec = _spec_with(
        _run(structure_id="lin_fence_north"),
        _run(structure_id="lin_fence_south"),  # same endpoints as north
        _run(structure_id="lin_fence_east", from_m=[-30.0, -20.0], to_m=[-30.0, 20.0]),
    )
    notes = expand_linear_structures(spec)

    assert _segments(spec, "fence_north"), "the first run is built"
    assert not _segments(spec, "fence_south"), "its duplicate is not built again"
    assert _segments(spec, "fence_east"), "a genuinely different line still builds"

    merged = [note for note in notes if "same line" in note["reason"]]
    assert len(merged) == 1
    assert merged[0]["user_visible"] is False


def test_two_runs_meeting_at_a_corner_both_place():
    """A yard bounded by four fences shares every corner between two runs.

    Measured on settlement prompts: a farmyard declared fence_south (0,0)->(30,0) and
    fence_west (0,0)->(0,40), which share the corner exactly, and fence_north and
    fence_east sharing (30,40). The corner segments of two DIFFERENT runs then occupy
    identical ground, which is a real overlap -- `part_of` exempts segments of ONE run
    from each other and cannot reach across runs. Four of that world's segments and five
    of a harbour's failed there, most of the 20 that held the pass rate at 1/5.

    Written before the fix and confirmed to fail, so it is testing the defect rather
    than describing the implementation.
    """
    spec = _spec_with(
        _run(
            structure_id="lin_fence_south",
            from_m=[0.0, 0.0],
            to_m=[30.0, 0.0],
            thickness_m=0.4,
        ),
        _run(
            structure_id="lin_fence_west",
            from_m=[0.0, 0.0],
            to_m=[0.0, 40.0],
            thickness_m=0.4,
        ),
    )
    expand_linear_structures(spec)
    plan = generate_semantic_world_plan(spec)

    declared = {
        entity["entity_id"]
        for entity in spec["entities"]
        if entity["entity_id"].startswith(("ent_fence_south_s", "ent_fence_west_s"))
    }
    unplaced = {
        entity_id
        for entity_id in plan["constraint_summary"]["unplaced_entities"]
        if entity_id in declared
    }
    assert declared, "both runs should have produced segments"
    assert not unplaced, f"corner segments failed to place: {sorted(unplaced)}"
