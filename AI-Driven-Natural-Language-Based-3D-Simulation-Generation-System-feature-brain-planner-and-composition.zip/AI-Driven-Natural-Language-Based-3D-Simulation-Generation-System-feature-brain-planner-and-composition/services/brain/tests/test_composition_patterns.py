"""Decomposition patterns (ADR-0008, brain side).

The LLM names an archetype; this vetted library turns it into parts+sockets. So
these pin: the archetype menu is fixed, common words classify to it, and "a car"
expands to a body with two side doors (a house to one front door) — deterministic
geometry the LLM never authored (rule 10).
"""

from agents.composition_patterns import (
    classify_archetype,
    expand,
    expand_all,
    known_archetypes,
    place_objects,
)

_ROOMS = [
    {"zone_id": "z0", "x": 0.0, "z": 0.0, "width": 10.0, "depth": 10.0, "elevation": 0.0},
    {"zone_id": "z1", "x": 20.0, "z": 0.0, "width": 8.0, "depth": 8.0, "elevation": 1.5},
]


def test_common_object_words_classify_to_an_archetype():
    assert classify_archetype("a beat-up red car") == "vehicle"
    assert classify_archetype("a cozy thatched cottage") == "building"
    assert classify_archetype("an old oak wardrobe") == "cabinet"
    assert classify_archetype("a rusty treasure chest") == "chest"
    assert classify_archetype("an iron gate") == "gate"


def test_unknown_objects_have_no_archetype():
    # A rock or a lamppost is a plain prop, not a composite — no invented doors.
    assert classify_archetype("a mossy boulder") is None
    assert classify_archetype("") is None


def test_a_vehicle_expands_to_two_side_doors():
    obj = {"object_id": "car01", "archetype": "vehicle", "bbox": [2.0, 1.2, 4.0],
           "origin": [5, 0, 5], "yaw_deg": 0.0}
    comp = expand(obj)
    assert comp is not None
    part_ids = [p["part_id"] for p in comp["parts"]]
    assert part_ids == ["door_l", "door_r"]
    # opposite sides of the body, hinged, car-door swing
    assert comp["parts"][0]["socket"]["offset"][0] == -0.5
    assert comp["parts"][1]["socket"]["offset"][0] == 0.5
    assert all(p["template_id"] == "door_hinged" for p in comp["parts"])
    assert comp["parts"][0]["params"]["open_angle_deg"] == -70.0


def test_archetype_is_inferred_from_the_name_when_omitted():
    comp = expand({"object_id": "h1", "name": "a little hut", "bbox": [4, 3, 4]})
    assert comp["archetype"] == "building"
    assert [p["part_id"] for p in comp["parts"]] == ["front_door"]
    # front-centre door
    assert comp["parts"][0]["socket"]["offset"] == [0.0, 0.0, 0.5]


def test_a_chest_has_a_lid_and_loot():
    comp = expand({"object_id": "c1", "archetype": "chest", "bbox": [1, 0.8, 0.6]})
    templates = {p["part_id"]: p["template_id"] for p in comp["parts"]}
    assert templates == {"lid": "door_hinged", "loot": "pickup_collectible"}


def test_unknown_archetype_expands_to_nothing():
    assert expand({"object_id": "x", "name": "a puddle", "bbox": [1, 1, 1]}) is None


def test_expand_all_keeps_composites_and_drops_plain_props():
    objs = [
        {"object_id": "car", "archetype": "vehicle", "bbox": [2, 1, 4]},
        {"object_id": "rock", "name": "a boulder", "bbox": [1, 1, 1]},  # plain prop
        {"object_id": "house", "archetype": "building", "bbox": [6, 3, 6]},
    ]
    out = expand_all(objs)
    assert [c["object_id"] for c in out] == ["car", "house"]


def test_the_archetype_menu_is_fixed_and_nonempty():
    menu = known_archetypes()
    assert {"vehicle", "building", "chest"} <= menu  # the core kinds are present


# --- placement (ADR-0008 phase 3b-3) --------------------------------------


def test_placement_is_seeded_and_reproducible():
    objs = [{"object_id": "car", "archetype": "vehicle", "bbox": [2, 1.5, 4]}]
    a = place_objects(objs, _ROOMS, seed=123)
    b = place_objects(objs, _ROOMS, seed=123)
    assert a == b  # rule 14: same seed -> same placement
    assert a[0]["origin"] is not None and "yaw_deg" in a[0]


def test_placed_object_sits_at_a_room_centre_on_its_floor():
    objs = [{"object_id": "car", "archetype": "vehicle", "bbox": [2, 1.5, 4]}]
    placed = place_objects(objs, _ROOMS, seed=1)
    ox, oy, oz = placed[0]["origin"]
    # centre of whichever room it landed in, at that room's elevation
    room = next(r for r in _ROOMS if abs(oy - r["elevation"]) < 1e-6)
    assert ox == room["x"] + room["width"] / 2
    assert oz == room["z"] + room["depth"] / 2


def test_an_object_too_big_for_any_room_is_dropped_not_clipped():
    huge = [{"object_id": "airship", "archetype": "vehicle", "bbox": [14, 5, 14]}]
    assert place_objects(huge, _ROOMS, seed=1) == []  # no room fits it with margin


def test_placement_needs_rooms_and_objects():
    one = [{"object_id": "c", "archetype": "vehicle", "bbox": [1, 1, 1]}]
    assert place_objects([], _ROOMS, seed=1) == []
    assert place_objects(one, [], seed=1) == []  # no rooms -> nothing placed


def test_placed_objects_expand_into_composites_end_to_end():
    objs = [{"object_id": "car", "archetype": "vehicle", "bbox": [2, 1.5, 4],
             "brief": "a rusty car"}]
    composites = expand_all(place_objects(objs, _ROOMS, seed=7))
    assert len(composites) == 1
    assert composites[0]["origin"] is not None  # carried the placement
    assert [p["part_id"] for p in composites[0]["parts"]] == ["door_l", "door_r"]
