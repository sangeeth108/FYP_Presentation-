"""Stage 2: prose becomes an explicit few-vs-many split.

The stage exists for one measured failure: handed rich prose, the planner
enumerated what it should have abstracted and four of ten worlds ended up with
no mass content (DEFECTS_AND_DECISIONS #18). These tests pin that the brief is
small, validated, fail-soft, and that it cannot quietly become another place
where the world gets invented.
"""

from __future__ import annotations

import json

import httpx
from agents.brief_extractor import (
    brief_as_planner_input,
    extract_brief,
    ollama_brief_schema,
    scene_brief_schema,
)


class _Settings:
    llm_timeout_seconds = 5


def _client(handler):
    class _Stub:
        def __init__(self, *a, **k):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def post(self, url, json=None):
            return handler(url, json)

    return _Stub


def _reply(payload) -> httpx.Response:
    body = payload if isinstance(payload, str) else json.dumps(payload)
    return httpx.Response(
        200,
        json={"message": {"content": body}},
        request=httpx.Request("POST", "http://test/api/chat"),
    )


_BRIEF = {
    "place": "sinharaja_lowland_rainforest",
    "world_size_m": {"width": 120.0, "depth": 120.0, "max_height": 40.0},
    "individual": [
        {
            "name": "Ruined stupa",
            "semantic_type": "brick_dagaba_ruin",
            "size_m": [8.0, 4.0, 8.0],
            "why_individual": "the landmark the visitor walks to",
        }
    ],
    "mass": [
        {
            "name": "Ironwood",
            "semantic_type": "mesua_ferrea",
            "size_m": [6.0, 28.0, 6.0],
            "per_100m2": 4.0,
            "form": "foliage_column",
        },
        {
            "name": "Ferns",
            "semantic_type": "nephrolepis_fern",
            "size_m": [0.9, 0.6, 0.9],
            "per_100m2": 380.0,
            "form": "ground_cover",
        },
    ],
    "conditions": {"ground": "wet_clay_loam", "light": "dawn_filtered", "weather": "misty"},
}


def test_a_brief_is_returned_and_counted(monkeypatch):
    monkeypatch.setattr(httpx, "Client", _client(lambda u, j: _reply(_BRIEF)))
    result = extract_brief(
        "a long description", settings=_Settings(), model_id="qwen", base_url="http://x"
    )
    assert result is not None
    payload = result.as_stage_payload()
    assert payload["individual_count"] == 1
    assert payload["mass_count"] == 2


def test_extraction_is_schema_constrained_unlike_expansion(monkeypatch):
    """expand must NOT be guided; extract must be. Different jobs.

    The reasoning already happened upstream; all this stage owes is a faithful
    reading, so the grammar should hold it to the shape.
    """
    sent: dict = {}

    def handler(url, payload):
        sent.update(payload)
        return _reply(_BRIEF)

    monkeypatch.setattr(httpx, "Client", _client(handler))
    extract_brief("desc", settings=_Settings(), model_id="q", base_url="http://x", seed=5)
    assert "format" in sent
    assert sent["options"]["seed"] == 5
    assert sent["options"]["temperature"] <= 0.2


def test_a_brief_that_breaks_the_contract_is_refused(monkeypatch):
    """Never hand the planner something the contract rejects."""
    broken = {**_BRIEF, "mass": [{"name": "x"}]}
    monkeypatch.setattr(httpx, "Client", _client(lambda u, j: _reply(broken)))
    assert (
        extract_brief("desc", settings=_Settings(), model_id="q", base_url="http://x")
        is None
    )


def test_an_unavailable_model_is_not_fatal(monkeypatch):
    def handler(url, payload):
        raise httpx.ConnectError("down")

    monkeypatch.setattr(httpx, "Client", _client(handler))
    assert (
        extract_brief("desc", settings=_Settings(), model_id="q", base_url="http://x")
        is None
    )


def test_nothing_to_read_is_skipped():
    assert extract_brief("", settings=_Settings(), model_id="q", base_url="http://x") is None
    assert extract_brief("d", settings=_Settings(), model_id=None, base_url="http://x") is None


def test_the_brief_is_small_on_purpose():
    """If this grows into a second SimulationSpec it has lost its reason to exist."""
    schema = scene_brief_schema()
    assert set(schema["required"]) == {
        "place",
        "world_size_m",
        "individual",
        "mass",
        "conditions",
    }
    # The one judgement it owns must be forced, not optional.
    individual = schema["$defs"]["individual_thing"]
    assert "why_individual" in individual["required"]


def test_mass_forms_match_the_builders():
    """A form the brief can name but nobody builds would fail at generation."""
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "services" / "worker"))
    from asset_farm.procedural import _SUPPORTED

    forms = set(scene_brief_schema()["$defs"]["mass_kind"]["properties"]["form"]["enum"])
    assert forms <= set(_SUPPORTED)


def test_the_guided_view_keeps_the_shape_but_drops_length_bounds():
    guided = ollama_brief_schema()
    assert guided["required"] == scene_brief_schema()["required"]
    assert "minLength" not in guided["properties"]["place"]
    assert guided["$defs"]["mass_kind"]["properties"]["per_100m2"]["maximum"] == 5000


def test_the_planner_receives_compact_deterministic_json(monkeypatch):
    monkeypatch.setattr(httpx, "Client", _client(lambda u, j: _reply(_BRIEF)))
    result = extract_brief(
        "desc", settings=_Settings(), model_id="q", base_url="http://x"
    )
    text = brief_as_planner_input(result)
    assert ", " not in text  # compact separators
    assert json.loads(text) == _BRIEF
    assert text == brief_as_planner_input(result)  # stable


def test_extract_is_the_second_declared_stage():
    from core.stages import STAGE_ORDER, stage_ordinal

    assert STAGE_ORDER[1] == "extract"
    assert stage_ordinal("expand") < stage_ordinal("extract") < stage_ordinal("scene_spec")


def test_an_out_of_range_brief_is_repaired_not_discarded(monkeypatch):
    """The SimulationSpec's repair, applied to the brief, for the same reason.

    Measured before this existed: three of ten briefs were thrown away for
    `per_100m2: 10000` against a 5000 cap and `width: 4` against an 8 m floor —
    both accurate readings of dense ground cover and a narrow corridor. Building
    a second guided stage reproduced the exact bug already fixed one file over,
    which is what a schema-specific "general" fix earns you.
    """
    over = json.loads(json.dumps(_BRIEF))
    over["mass"][1]["per_100m2"] = 10000
    over["world_size_m"]["width"] = 4
    monkeypatch.setattr(httpx, "Client", _client(lambda u, j: _reply(over)))

    result = extract_brief(
        "desc", settings=_Settings(), model_id="q", base_url="http://x"
    )
    assert result is not None, "an out-of-range value must not cost the whole brief"
    assert result.brief["mass"][1]["per_100m2"] == 5000
    assert result.brief["world_size_m"]["width"] == 8


def test_the_repair_is_shared_not_copied():
    """Both guided stages must use one implementation, or they will drift apart."""
    import inspect

    from agents import brief_extractor, simulation_planner
    from agents.schema_bounds import clamp_to_schema as shared

    assert brief_extractor.clamp_to_schema is shared
    assert "clamp_to_schema" in inspect.getsource(simulation_planner._clamp_out_of_range_numbers)


def test_an_overlong_justification_is_trimmed_not_thrown_away(monkeypatch):
    """The third instance of one class: a bound the grammar never showed the model.

    `ollama_brief_schema()` strips maxLength to build the grammar, so the model
    cannot respect it — and three of ten briefs were discarded because a
    thoughtful `why_individual` ran past the cap. Losing the tail of a
    justification costs nothing; losing the brief costs the stage.
    """
    wordy = json.loads(json.dumps(_BRIEF))
    wordy["individual"][0]["why_individual"] = "because " * 60  # ~480 chars
    monkeypatch.setattr(httpx, "Client", _client(lambda u, j: _reply(wordy)))

    result = extract_brief(
        "desc", settings=_Settings(), model_id="q", base_url="http://x"
    )
    assert result is not None
    reason = result.brief["individual"][0]["why_individual"]
    assert len(reason) <= 240
    assert reason.startswith("because")


def test_mass_kinds_are_told_to_be_distinct():
    """One run emitted six kinds all named `debris` — six copies of one mesh.

    `individual_thing.semantic_type` carried the "specific and distinct" rule and
    `mass_kind.semantic_type` did not, so the model was never told. The guidance
    has to live on both or the omission is invisible until a world is generated.
    """
    schema = scene_brief_schema()
    mass_desc = schema["$defs"]["mass_kind"]["properties"]["semantic_type"]["description"]
    individual_desc = schema["$defs"]["individual_thing"]["properties"]["semantic_type"][
        "description"
    ]
    for text in (mass_desc, individual_desc):
        assert "Specific and distinct" in text
