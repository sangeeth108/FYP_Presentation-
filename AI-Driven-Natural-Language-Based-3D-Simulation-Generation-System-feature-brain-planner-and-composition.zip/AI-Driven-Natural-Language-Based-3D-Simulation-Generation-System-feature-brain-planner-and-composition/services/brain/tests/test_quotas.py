"""Tenant generation admission is atomic, bounded, and released idempotently."""

from __future__ import annotations

from datetime import datetime

from core import db
from core.ids import new_resource_id
from core.models import GenerationRun, Simulation, Tenant, TenantQuota, User
from core.quotas import QuotaExceeded, release_generation_slot, reserve_generation_slot


def _run(db, suffix: str) -> str:
    simulation_id = f"sim_quota_{suffix}"
    run_id = f"run_quota_{suffix}"
    simulation = Simulation(
        id=simulation_id,
        tenant_id="tenant_dev",
        owner_id="user_dev",
        title="Quota test",
        prompt="a valid quota test simulation",
        size_profile="small",
        target_platforms=["web"],
        seed=1,
    )
    db.add(simulation)
    db.flush()
    db.add(
        GenerationRun(
            id=run_id,
            simulation_id=simulation_id,
            tenant_id="tenant_dev",
            owner_id="user_dev",
        )
    )
    db.flush()
    return run_id


def _identity(session):
    session.add(
        Tenant(id="tenant_dev", name="Development", slug="development")
    )
    session.add(
        User(id="user_dev", subject="development", age_band="adult")
    )
    session.flush()


def test_concurrent_limit_fails_closed():
    with db.session_scope() as session:
        _identity(session)
        quota = TenantQuota(
            tenant_id="tenant_dev",
            max_concurrent_generations=1,
            monthly_generation_limit=10,
            active_generations=0,
            window_generations=0,
            gpu_seconds_limit=100,
            gpu_seconds_used=0,
        )
        session.add(quota)
        first = _run(session, "first")
        reserve_generation_slot(session, "tenant_dev", first)
        second = _run(session, "second")
        try:
            reserve_generation_slot(session, "tenant_dev", second)
            raise AssertionError("quota must reject the second active generation")
        except QuotaExceeded as exc:
            assert exc.code == "CONCURRENT_GENERATION_LIMIT"


def test_release_is_idempotent():
    with db.session_scope() as session:
        _identity(session)
        run_id = _run(session, new_resource_id("quota"))
        quota = reserve_generation_slot(session, "tenant_dev", run_id)
        assert quota.active_generations == 1
        assert release_generation_slot(session, run_id) is True
        assert release_generation_slot(session, run_id) is False
        assert quota.active_generations == 0


def test_sqlite_naive_month_window_is_normalized():
    with db.session_scope() as session:
        _identity(session)
        quota = TenantQuota(
            tenant_id="tenant_dev",
            max_concurrent_generations=3,
            monthly_generation_limit=10,
            active_generations=0,
            window_started_at=datetime(2026, 1, 1),
            window_generations=2,
            gpu_seconds_limit=100,
            gpu_seconds_used=3,
        )
        session.add(quota)
        run_id = _run(session, "naive_time")
        reserve_generation_slot(session, "tenant_dev", run_id)
        assert quota.window_generations >= 1


def _quota(session, *, limit: int = 3) -> None:
    session.add(
        TenantQuota(
            tenant_id="tenant_dev",
            max_concurrent_generations=limit,
            monthly_generation_limit=100,
            active_generations=0,
            window_generations=0,
            gpu_seconds_limit=100,
            gpu_seconds_used=0,
        )
    )
    session.flush()


def _leak(session, run_id: str) -> None:
    """Backdate a lease past the stale window — simulates a crash-leaked slot."""
    from datetime import UTC, datetime, timedelta

    from core.models import GenerationLease
    from core.quotas import STALE_LEASE_SECONDS

    lease = session.query(GenerationLease).filter_by(run_id=run_id).one()
    lease.reserved_at = datetime.now(UTC) - timedelta(seconds=STALE_LEASE_SECONDS + 60)
    session.flush()


def test_reconcile_releases_a_stale_lease_and_resyncs_the_counter():
    from core.quotas import reconcile_generation_quotas

    with db.session_scope() as session:
        _identity(session)
        _quota(session)
        run_id = _run(session, "stale")
        reserve_generation_slot(session, "tenant_dev", run_id)
        _leak(session, run_id)
        assert reconcile_generation_quotas(session) == 1
        q = session.query(TenantQuota).filter_by(tenant_id="tenant_dev").one()
        assert q.active_generations == 0  # counter re-synced from live leases


def test_reconcile_keeps_a_fresh_running_lease():
    from core.quotas import reconcile_generation_quotas

    with db.session_scope() as session:
        _identity(session)
        _quota(session)
        run_id = _run(session, "fresh")  # recent, run state=queued (not terminal)
        reserve_generation_slot(session, "tenant_dev", run_id)
        assert reconcile_generation_quotas(session) == 0  # a real job is NOT killed
        q = session.query(TenantQuota).filter_by(tenant_id="tenant_dev").one()
        assert q.active_generations == 1


def test_a_leaked_slot_self_heals_on_the_next_submit():
    # The user-facing bug: a crash-leaked slot must not 429 the tenant forever.
    with db.session_scope() as session:
        _identity(session)
        _quota(session, limit=1)  # only one slot
        old = _run(session, "old")
        reserve_generation_slot(session, "tenant_dev", old)  # fills the single slot
        _leak(session, old)  # ...then it leaks
        new = _run(session, "new")
        quota = reserve_generation_slot(session, "tenant_dev", new)  # must NOT 429
        assert quota.active_generations == 1  # only the new job holds the slot now


def test_reconcile_releases_a_terminal_run_slot():
    from core.models import GenerationRun
    from core.quotas import reconcile_generation_quotas

    with db.session_scope() as session:
        _identity(session)
        _quota(session)
        run_id = _run(session, "done")
        reserve_generation_slot(session, "tenant_dev", run_id)
        session.query(GenerationRun).filter_by(id=run_id).one().state = "completed"
        session.flush()
        assert reconcile_generation_quotas(session) == 1  # finished run's slot freed
