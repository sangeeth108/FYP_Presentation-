"""A world needs enough ground for the scatter that defines it.

Measured on the forest prompt, which failed the visual critic three runs running with
"the scene lacks trees, foliage" and "a single stump does not suffice". The spec declared
oak and maple at 1 per 100 m2 -- a real forest density -- in a 22x16 m world, which is
3.7 hundred-m2 of ground and therefore about seven trees.
"""

import pytest
from agents.simulation_planner import _a_world_holds_enough_of_what_defines_it as size_it

_FOREST = [
    {"species_id": "spc_oak_tree", "density_per_100m2": 1},
    {"species_id": "spc_maple_tree", "density_per_100m2": 1},
    {"species_id": "spc_moss_patch", "density_per_100m2": 200},
]


def _spec(width: float, depth: float, scatter: list, runs: list | None = None) -> dict:
    return {
        "environment": {"dimensions_m": {"width": width, "depth": depth}},
        "scatter": scatter,
        "linear_structures": runs or [],
    }


def _instances(candidate: dict, species_id: str) -> float:
    dimensions = candidate["environment"]["dimensions_m"]
    area = dimensions["width"] * dimensions["depth"]
    density = next(
        s["density_per_100m2"] for s in candidate["scatter"] if s["species_id"] == species_id
    )
    return density * area / 100.0


def test_a_forest_gets_ground_enough_for_trees() -> None:
    candidate = _spec(22.259, 16.694, list(_FOREST))
    assert _instances(candidate, "spc_oak_tree") < 4  # the measured failure

    size_it(candidate)

    assert _instances(candidate, "spc_oak_tree") >= 8
    assert any(
        a["requirement_id"] == "environment.dimensions_m"
        for a in candidate["approximations"]
    )


def test_the_world_keeps_its_shape() -> None:
    """A long thin ravine grows into a longer thinner ravine, not a square."""
    candidate = _spec(40.0, 10.0, list(_FOREST))
    size_it(candidate)
    dimensions = candidate["environment"]["dimensions_m"]
    # Both axes are rounded to millimetres, so the ratio survives to about that.
    assert dimensions["width"] / dimensions["depth"] == pytest.approx(4.0, abs=1e-3)


def test_it_only_ever_grows() -> None:
    candidate = _spec(120.0, 120.0, list(_FOREST))
    size_it(candidate)
    assert candidate["environment"]["dimensions_m"] == {"width": 120.0, "depth": 120.0}


def test_a_walled_world_is_left_to_its_walls() -> None:
    """Two sizing rules must not fight: inside a building, scatter goes inside it."""
    walls = [
        {"structure_id": "lin_wall_north", "semantic_type": "wall",
         "from_m": [-20.0, -30.0], "to_m": [20.0, -30.0]},
        {"structure_id": "lin_wall_south", "semantic_type": "wall",
         "from_m": [-20.0, 30.0], "to_m": [20.0, 30.0]},
        {"structure_id": "lin_wall_west", "semantic_type": "wall",
         "from_m": [-20.0, -30.0], "to_m": [-20.0, 30.0]},
        {"structure_id": "lin_wall_east", "semantic_type": "wall",
         "from_m": [20.0, -30.0], "to_m": [20.0, 30.0]},
    ]
    candidate = _spec(50.0, 70.0, list(_FOREST), walls)
    size_it(candidate)
    assert candidate["environment"]["dimensions_m"] == {"width": 50.0, "depth": 70.0}


def test_a_species_meant_to_be_rare_does_not_inflate_the_world() -> None:
    """One fox capped at 3 instances is not a reason to build a bigger forest."""
    candidate = _spec(60.0, 60.0, [{"species_id": "spc_fox", "density_per_100m2": 0.5,
                                    "max_instances": 3}])
    size_it(candidate)
    assert candidate["environment"]["dimensions_m"]["width"] == 60.0


def test_the_world_cannot_grow_without_end() -> None:
    """The build budget is finite; a world stops at the widest v1 promises."""
    candidate = _spec(20.0, 20.0, [{"species_id": "spc_rare", "density_per_100m2": 0.01}])
    size_it(candidate)
    dimensions = candidate["environment"]["dimensions_m"]
    assert dimensions["width"] <= 220.0
    assert dimensions["depth"] <= 220.0
