
import pytest
from cryptography.exceptions import InvalidTag
from learning.encryption import KmsEnvelopeCipher, seal_directory, unseal_directory
from worker.learning_tasks import _delete_dataset_copy_refs


class _FakeKms:
    def __init__(self):
        self.key = bytes(range(32))

    def generate_data_key(self, **_kwargs):
        return {"Plaintext": self.key, "CiphertextBlob": b"wrapped-test-key"}

    def decrypt(self, **kwargs):
        assert kwargs["CiphertextBlob"] == b"wrapped-test-key"
        return {"Plaintext": self.key}


def _cipher() -> KmsEnvelopeCipher:
    cipher = object.__new__(KmsEnvelopeCipher)
    cipher.client = _FakeKms()
    return cipher


def test_governed_directory_envelope_round_trip_and_tamper_detection(tmp_path):
    source = tmp_path / "plain"
    source.mkdir()
    (source / "train.jsonl").write_text('{"safe":"row"}\n', encoding="utf-8")
    sealed = tmp_path / "sealed"
    manifest = seal_directory(
        source, sealed, cipher=_cipher(), key_id="kms-test-training"
    )
    assert manifest["format"] == "serendib_kms_directory_v1"
    assert not (sealed / "train.jsonl").exists()

    restored = tmp_path / "restored"
    unseal_directory(sealed, restored, cipher=_cipher())
    assert (restored / "train.jsonl").read_text(encoding="utf-8") == '{"safe":"row"}\n'

    encrypted = next(sealed.glob("*.kms"))
    body = bytearray(encrypted.read_bytes())
    body[-17] ^= 1
    encrypted.write_bytes(body)
    with pytest.raises(InvalidTag):
        unseal_directory(sealed, tmp_path / "tampered", cipher=_cipher())


def test_training_copy_deletion_is_root_bounded(tmp_path, monkeypatch):
    monkeypatch.setattr(
        "worker.learning_tasks.get_settings",
        lambda: type("Settings", (), {"training_work_dir": str(tmp_path)})(),
    )
    copy = tmp_path / "sealed_datasets" / "dataset_one"
    copy.mkdir(parents=True)
    (copy / "train.jsonl.kms").write_bytes(b"encrypted")
    assert _delete_dataset_copy_refs([str(copy)]) == 1
    assert not copy.exists()

    outside = tmp_path.parent / "must-not-delete"
    outside.mkdir(exist_ok=True)
    with pytest.raises(RuntimeError, match="escaped"):
        _delete_dataset_copy_refs([str(outside)])
    assert outside.exists()
    outside.rmdir()
