"""S1 intent rules + S2 spec builder: prompts genuinely shape the spec."""

import json
from pathlib import Path

import jsonschema
from agents.intent import parse_intent
from agents.spec_builder import build_spec

REPO = Path(__file__).resolve().parents[3]
GOLDEN_SPEC = json.loads(
    (REPO / "contracts" / "examples" / "golden_game.spec.json").read_text(encoding="utf-8")
)
SCHEMA = json.loads(
    (REPO / "contracts" / "game_spec.schema.json").read_text(encoding="utf-8")
)


def test_genre_keywords():
    assert parse_intent("a deep dungeon crawl through crypts").genre == "dungeon_crawl_3d"
    assert parse_intent("descend the forgotten mines, floor by floor").genre == "dungeon_crawl_3d"
    assert parse_intent("escape the zombie village").genre == "topdown_survival_escape_3d"
    assert parse_intent("collect ancient relics on an island").genre == "collect_explore_3d"
    assert parse_intent("an arena where I duel a boss").genre == "arena_combat_3d"
    assert parse_intent("something nice").genre == "collect_explore_3d"  # default


def test_explicit_options_beat_keywords():
    brief = parse_intent("a deep dungeon crawl", genre="arena_combat_3d", camera="top_down_3d")
    assert brief.genre == "arena_combat_3d"
    assert brief.camera == "top_down_3d"


def test_camera_defaults_follow_genre():
    assert parse_intent("escape the village").camera == "top_down_3d"
    assert parse_intent("dungeon crawl").camera == "isometric_3d"
    assert parse_intent("arena battle").camera == "third_person"


def test_lighting_preset_keywords():
    assert parse_intent("a moonlit monastery at night").lighting_preset == "moonlit_night"
    assert parse_intent("escape the foggy village").lighting_preset == "dusk_fog"
    assert parse_intent("torchlit crypts under the keep").lighting_preset == "cave_torchlit"
    assert parse_intent("a cheerful sunny meadow").lighting_preset == "sunny_bright"
    assert parse_intent("an average adventure").lighting_preset == "overcast_day"


def test_scale_verticality_and_enemy_density():
    small = parse_intent("a tiny peaceful garden to explore")
    assert (small.zone_count, small.enemy_count) == (4, 0)
    big = parse_intent("a huge tower arena with a horde of enemies")
    assert (big.zone_count, big.verticality_tiers, big.enemy_count) == (12, 2, 12)
    default = parse_intent("an average adventure")
    assert (default.zone_count, default.enemy_count) == (7, 5)


def test_built_specs_are_schema_valid():
    expected_algorithms = {
        "a tiny peaceful garden to explore": "cellular_caves",
        "a huge tower arena with a horde of enemies": "bsp",
        "escape the foggy zombie village": "room_corridor",
        "a deep dungeon crawl through crypts with few enemies": "wfc_dressing",
    }
    for prompt, algorithm in expected_algorithms.items():
        brief = parse_intent(prompt)
        spec = build_spec(GOLDEN_SPEC, brief, "g3d_test_game_deadbeef", prompt, seed=42)
        jsonschema.validate(spec, SCHEMA)  # raises on violation
        assert spec["meta"]["genre"] == brief.genre
        assert spec["world"]["zone_graph"]["zone_count"] == brief.zone_count
        assert spec["world"]["zone_graph"]["algorithm"] == algorithm  # genre drives topology


def test_peaceful_spec_has_no_enemies():
    brief = parse_intent("a peaceful cozy meadow, no enemies")
    spec = build_spec(GOLDEN_SPEC, brief, "g3d_test_game_deadbeef", "t", seed=1)
    assert spec["entities"]["enemies"] == []
    jsonschema.validate(spec, SCHEMA)


def test_dense_worlds_place_across_hundreds_of_seeds():
    # Regression: 12 enemies + safe-spawn radius used to exhaust a single
    # zone and fail ~12% of seeds before placement spillover existed.
    from pcg.pipeline import run_pcg

    brief = parse_intent("a huge haunted dungeon crawl with a horde of skeletons on many floors")
    for seed in range(300):
        spec = build_spec(GOLDEN_SPEC, brief, "g3d_test_game_deadbeef", "t", seed)
        out = run_pcg(spec)  # raises PCGError on any placement failure
        assert len(out.placement.entities) == 12 + len(GOLDEN_SPEC["entities"]["props"])
