"""Showcase selection (P4/P6 gate: 5 cached games + 1 live).

The pipeline runs (LLM + Godot export) are exercised elsewhere; these pin the
SELECTION rule, which is where a showcase quietly goes wrong: padding it with
games that don't actually pass, or showing five of the same genre.
"""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "eval" / "showcase"))

from build_showcase import demo_script, select  # noqa: E402


def _row(id, genre, verdict="PASS", won=True):
    return {
        "id": id, "genre": genre, "verdict": verdict, "won": won,
        "prompt": f"a {genre} game", "build_mb": 45.0,
        "play_path": f"/artifacts/{id}/index.html", "seed": 1,
    }


def test_only_passing_and_bot_won_games_are_eligible():
    rows = [
        _row("a", "arena_combat_3d"),
        _row("b", "dungeon_crawl_3d", verdict="FAIL"),  # failed gates
        _row("c", "collect_explore_3d", won=False),     # bot didn't win
    ]
    chosen = select(rows)
    assert {r["id"] for r in chosen} == {"a"}  # only the clean one


def test_selection_prefers_genre_spread():
    # 5 arenas + 1 dungeon: the demo must show range, not five arenas.
    rows = [_row(f"ar{i}", "arena_combat_3d") for i in range(5)]
    rows.append(_row("dg", "dungeon_crawl_3d"))
    chosen = select(rows, want=2)
    genres = {r["genre"] for r in chosen}
    assert genres == {"arena_combat_3d", "dungeon_crawl_3d"}  # one of each first


def test_all_four_genres_appear_when_available():
    rows = [
        _row("s", "topdown_survival_escape_3d"),
        _row("a", "arena_combat_3d"),
        _row("c", "collect_explore_3d"),
        _row("d", "dungeon_crawl_3d"),
        _row("a2", "arena_combat_3d"),
    ]
    chosen = select(rows, want=5)
    assert len({r["genre"] for r in chosen}) == 4  # all genres represented


def test_never_pads_beyond_what_qualifies():
    # Only 2 clean games -> the set is 2, honestly, not 5 with duds.
    rows = [_row("a", "arena_combat_3d"), _row("b", "dungeon_crawl_3d"),
            _row("c", "collect_explore_3d", verdict="FAIL")]
    assert len(select(rows, want=5)) == 2


def test_demo_script_names_the_backup_plan_and_every_game():
    chosen = [_row("a", "arena_combat_3d"), _row("d", "dungeon_crawl_3d")]
    live = {"id": "live", "prompt": "a sunny meadow", "seed": 21, "build_seconds": 90}
    script = demo_script(chosen, live)
    assert "Backup plan" in script  # a defense demo must have a fallback
    assert "a sunny meadow" in script  # the live prompt
    for r in chosen:
        assert r["id"] in script and r["play_path"] in script  # every game listed
    # it is valid markdown-ish: has the table header
    assert "| # | game |" in script


def test_the_curated_prompt_set_is_well_formed():
    p = Path(__file__).resolve().parents[3] / "eval" / "showcase" / "showcase_prompts.json"
    data = json.loads(p.read_text(encoding="utf-8"))
    assert len(data["candidates"]) >= 5  # enough to select 5 from
    assert "live_demo" in data  # the P6 gate needs a live one
    ids = [c["id"] for c in data["candidates"]]
    assert len(ids) == len(set(ids))  # unique ids
    for c in data["candidates"]:
        assert c["prompt"] and isinstance(c["seed"], int)
