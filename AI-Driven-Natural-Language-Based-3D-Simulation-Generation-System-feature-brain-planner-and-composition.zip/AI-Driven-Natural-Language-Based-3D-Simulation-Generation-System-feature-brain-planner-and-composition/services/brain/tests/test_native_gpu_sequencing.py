from types import SimpleNamespace

from worker import native_pipeline


def test_unload_planner_uses_routed_ollama_model(monkeypatch):
    calls = []

    class Response:
        def raise_for_status(self):
            return None

    class Client:
        def __init__(self, **kwargs):
            calls.append(("client", kwargs))

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return None

        def post(self, path, json):
            calls.append(("post", path, json))
            return Response()

    import httpx

    monkeypatch.setattr(httpx, "Client", Client)
    route = SimpleNamespace(
        provider="ollama",
        endpoint="http://planner.internal:11434",
        model_id="serendib-planner",
    )

    native_pipeline._unload_planner_for_asset_generation(route)

    assert calls == [
        ("client", {"base_url": route.endpoint, "timeout": 30.0}),
        ("post", "/api/generate", {"model": route.model_id, "keep_alive": 0}),
    ]


def test_unload_planner_ignores_non_ollama_route(monkeypatch):
    import httpx

    monkeypatch.setattr(
        httpx,
        "Client",
        lambda **_kwargs: (_ for _ in ()).throw(AssertionError("must not connect")),
    )
    route = SimpleNamespace(
        provider="hosted", endpoint="https://provider.example", model_id="planner"
    )

    native_pipeline._unload_planner_for_asset_generation(route)
