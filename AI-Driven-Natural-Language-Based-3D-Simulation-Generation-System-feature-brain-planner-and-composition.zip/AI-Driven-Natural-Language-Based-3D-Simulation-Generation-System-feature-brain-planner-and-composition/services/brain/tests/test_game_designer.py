"""Game Designer: the brain's first real choice of GOAL.

The engine implements two win conditions; the registry's ids ARE the guided-JSON
enum, so a goal the engine cannot run is unrepresentable in the model's output.
The dangerous outcome is not a bad goal — it is a goal the world cannot satisfy:
a hunt with nothing to hunt builds perfectly and can never be won.
"""

import json

import httpx
from agents.chain import AgentContext, run_chain
from agents.content_designer import ensure_pickups
from agents.game_designer import collect_objectives, llm_objective, objective_schema, sanitize
from agents.intent import parse_intent
from knowledge.registries import registry

BASE_OBJECTIVES = [
    {
        "objective_id": "escape",
        "objective_template_id": "reach_zone",
        "params": {"zone_node": "WinZone"},
        "is_win_condition": True,
    }
]


class _Settings:
    llm_base_url = "http://mock"
    llm_model = "qwen3.6:27b"
    llm_timeout_seconds = 5.0


def _transport(payload) -> httpx.MockTransport:
    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        enum = body["format"]["properties"]["objective_template_id"]["enum"]
        assert set(enum) == set(registry()["objective_template_id"])
        return httpx.Response(200, json={"message": {"content": json.dumps(payload)}})

    return httpx.MockTransport(handler)


def test_only_implemented_goals_are_offered_to_the_model():
    enum = objective_schema()["properties"]["objective_template_id"]["enum"]
    assert set(enum) == set(registry()["objective_template_id"])
    assert "collect_n" in enum  # the second win condition exists...
    assert "survive_timer" not in enum  # ...and the ones we never built do not


def test_a_hunt_prompt_yields_a_collect_quest():
    brief = parse_intent("steal the relics from the crypt")
    quest = llm_objective(
        "steal the relics from the crypt",
        brief,
        _Settings(),
        transport=_transport(
            {
                "objective_template_id": "collect_n",
                "required_count": 5,
                "label": "Relics",
                "reason": "the player is asked to steal several treasures",
            }
        ),
    )
    assert quest["objective_template_id"] == "collect_n"
    assert quest["required_count"] == 5
    assert quest["label"] == "Relics"


def test_reach_zone_means_keep_the_default_spine():
    brief = parse_intent("escape the burning village")
    quest = llm_objective(
        "escape the burning village",
        brief,
        _Settings(),
        transport=_transport({"objective_template_id": "reach_zone", "reason": "an escape"}),
    )
    assert quest is None  # None = "nothing to change", the classic key chain stands


def test_counts_are_clamped_and_junk_falls_back():
    assert sanitize({"objective_template_id": "collect_n", "required_count": 99})[
        "required_count"
    ] <= 8
    assert sanitize({"objective_template_id": "collect_n", "required_count": 1})[
        "required_count"
    ] >= 3
    assert sanitize({"objective_template_id": "teleport_to_moon"}) is None


def test_the_exit_is_unlocked_by_the_quest_not_the_key():
    quest = {"objective_template_id": "collect_n", "required_count": 4, "label": "Relics"}
    objectives = collect_objectives(quest, BASE_OBJECTIVES[-1])
    assert objectives[0]["objective_template_id"] == "collect_n"
    assert objectives[0]["params"]["required_count"] == 4
    # The exit keeps its own template and win flag; only what unlocks it changes.
    assert objectives[-1]["is_win_condition"] is True
    assert objectives[-1]["params"]["requires_objective"] == "collect_relics"


def test_a_hunt_always_has_something_to_hunt():
    """The killer failure: a collect quest whose world holds no collectibles.

    It builds and runs perfectly, and the exit door never opens.
    """
    quest = {"required_count": 5, "label": "Relics"}
    props = [
        {
            "prop_id": "stone_altar",
            "interactable_template_id": "chest_lidded",
            "placement_tags": [],
            "asset_brief": {"brief": "an altar", "category": "prop", "tri_budget": 500},
        }
    ]
    topped = ensure_pickups(props, quest)
    pickups = [p for p in topped if p["interactable_template_id"] == "pickup_supply"]
    assert len(pickups) >= 5
    assert len({p["prop_id"] for p in topped}) == len(topped)  # ids stay unique (node names)
    # Content the author already provided is preserved, not replaced.
    assert any(p["prop_id"] == "stone_altar" for p in topped)


def test_rules_mode_keeps_the_classic_goal():
    result = run_chain(
        json.loads(
            (
                __import__("pathlib").Path(__file__).resolve().parents[3]
                / "contracts"
                / "examples"
                / "golden_game.spec.json"
            ).read_text(encoding="utf-8")
        ),
        AgentContext(prompt="steal the relics from the crypt", seed=7),  # no LLM
    )
    templates = [o["objective_template_id"] for o in result.spec["objectives"]]
    assert "collect_n" not in templates  # deterministic path is unchanged
