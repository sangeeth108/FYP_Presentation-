"""The reproducibility package (docs/dissertation/results/ + eval/reproduce.py).

The dissertation's cited numbers must be (a) version-controlled and (b) provably
regenerable from the raw rows. These tests pin that the verifier actually
verifies — a check that passes no matter what is worse than no check.
"""

import json
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[3]
EVIDENCE = REPO / "docs" / "dissertation" / "results"
sys.path.insert(0, str(REPO / "eval"))

pytestmark = pytest.mark.skipif(
    not EVIDENCE.is_dir(), reason="run `python eval/reproduce.py --freeze` first"
)


def test_frozen_evidence_is_present_and_small():
    # Small = the level-plan bulk was stripped; present = the thesis can cite it.
    assert (EVIDENCE / "PROVENANCE.json").is_file()
    total = sum(f.stat().st_size for f in EVIDENCE.glob("*.json"))
    assert total < 300_000, "evidence should be slim metric rows, not raw level-plans"


def test_provenance_records_what_makes_a_run_reproducible():
    prov = json.loads((EVIDENCE / "PROVENANCE.json").read_text(encoding="utf-8"))
    assert prov["git_sha"] and prov["git_sha"] != "unknown"
    assert "qwen" in prov["planner_model"].lower()
    assert prov["files"]


def test_cited_stats_regenerate_exactly_from_the_frozen_rows():
    from reproduce import CITED, _recompute_and_check

    checked = 0
    for raw_name, cmp_name, base in CITED:
        if not cmp_name:
            continue
        slim, cmp = EVIDENCE / raw_name, EVIDENCE / cmp_name
        if not (slim.is_file() and cmp.is_file()):
            continue
        assert _recompute_and_check(slim, cmp, base) == [], f"{cmp_name} does not reproduce"
        checked += 1
    assert checked >= 1  # at least one cited comparison was actually verified


def test_the_verifier_catches_a_tampered_number(tmp_path):
    """The sharpest test: if someone edits a reported p-value, verify must FAIL.

    A reproducibility check that rubber-stamps a fudged number is theatre.
    """
    from reproduce import _recompute_and_check

    slim = EVIDENCE / "comparison_v2_RC.json"  # the file we tamper is the comparison
    raw_slim = EVIDENCE / "ablation_v2_RC.json"
    assert slim.is_file() and raw_slim.is_file()

    cmp = json.loads(slim.read_text(encoding="utf-8"))
    # flip the genre_match significance / p-value to a lie
    m = cmp["comparisons"]["C"]["metrics"]["genre_match"]
    m["p_value"] = 0.999
    m["holm"]["significant"] = False
    tampered = tmp_path / "tampered.json"
    tampered.write_text(json.dumps(cmp), encoding="utf-8")

    problems = _recompute_and_check(raw_slim, tampered, "R")
    assert problems, "the verifier must catch a tampered p-value"
    assert any("genre_match" in p for p in problems)
