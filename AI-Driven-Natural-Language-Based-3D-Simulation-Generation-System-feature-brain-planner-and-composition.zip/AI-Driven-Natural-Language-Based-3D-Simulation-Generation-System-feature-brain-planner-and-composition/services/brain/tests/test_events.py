"""SSE live-progress stream: real event frames, terminal close, 404."""

import json


def _events_from(raw: str) -> list[dict]:
    return [
        json.loads(line[len("data: ") :])
        for line in raw.splitlines()
        if line.startswith("data: ")
    ]


def test_stream_emits_terminal_state_and_closes(client, monkeypatch):
    import api.simulations as simulations_api
    from core import db
    from core.models import GenerationRun

    monkeypatch.setattr(
        simulations_api.run_simulation_generation,
        "delay",
        lambda run_id: run_id,
    )
    body = client.post(
        "/api/v1/games", json={"prompt": "a calm meadow to wander through"}
    ).json()
    with db.session_scope() as session:
        run = session.get(GenerationRun, body["job_id"])
        run.state = "failed_validation"
        run.stage = "validation"
        run.detail = {"mandatory_failures": ["visual_semantic"]}
    with client.stream("GET", f"/api/v1/jobs/{body['job_id']}/events") as r:
        assert r.status_code == 200
        assert r.headers["content-type"].startswith("text/event-stream")
        events = _events_from(r.read().decode())

    assert events, "stream produced no events"
    assert events[-1]["terminal"] is True
    assert events[-1]["state"] == "FAILED"
    assert events[-1]["detail"]["canonical_state"] == "failed_validation"
    assert events[-1]["detail"]["deprecated_adapter"] is True


def test_stream_for_unknown_job_reports_not_found(client):
    with client.stream("GET", "/api/v1/jobs/nope/events") as r:
        events = _events_from(r.read().decode())
    assert events == [{"error": "not_found", "job_id": "nope"}]
