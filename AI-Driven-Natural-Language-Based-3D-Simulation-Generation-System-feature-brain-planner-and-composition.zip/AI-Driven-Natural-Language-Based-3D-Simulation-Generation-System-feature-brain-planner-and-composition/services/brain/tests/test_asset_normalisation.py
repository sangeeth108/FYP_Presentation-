"""Bringing an imported mesh to its declared size without distorting it.

A uniform scale can only honour one axis. Which one it honours decides whether
a character stands up or lies down, and the wrong choice is invisible
downstream because every derived number stays internally consistent.
"""

from __future__ import annotations

import pytest
from assets.descriptors import _uniform_scale


def test_a_t_posed_character_is_scaled_by_height_not_wingspan():
    """The measured failure: arms wider than the figure is tall.

    A visitor declared [0.7, 1.8, 0.7] imported as [1.09, 1.02, 0.20]. Matching
    longest to longest mapped the 1.09 m arm span onto the 1.8 m declared
    height, yielding a person 1.8 m wide and 1.68 m tall.
    """
    declared = [0.7, 1.8, 0.7]
    imported = [1.09, 1.02, 0.20]
    scale = _uniform_scale(declared, imported)
    world = [value * scale for value in imported]

    assert world[1] == pytest.approx(1.8, rel=0.01), "a 1.8 m person must be 1.8 m tall"
    # Depth is the axis a T-pose does not distort, so it is the honest check
    # that the whole figure is at human scale rather than merely tall.
    assert 0.25 <= world[2] <= 0.55, f"torso depth implausible: {world[2]:.2f} m"
    # The old behaviour, pinned so it cannot return: matching longest to longest
    # gave 1.8 m of ARM SPAN and a figure only 1.68 m tall.
    legacy = max(declared) / max(imported)
    assert imported[1] * legacy < 1.7, "sanity: the old rule really did under-scale height"

    # Width stays wide, and that is the mesh telling the truth: arms out really
    # are broader than the figure is tall. The character animates out of T-pose
    # at runtime, and its collision proxy is a capsule rather than this box.
    assert world[0] > world[1]


def test_height_is_honoured_for_an_ordinary_upright_object():
    """The common case must be unchanged in spirit: declared height is met."""
    declared = [8.0, 6.0, 12.0]
    imported = [2.0, 1.5, 3.0]
    scale = _uniform_scale(declared, imported)
    assert imported[1] * scale == pytest.approx(6.0)


def test_a_flat_asset_falls_back_to_longest_dimension():
    """A rug has no useful height; dividing by it would explode the scale."""
    declared = [3.0, 0.005, 2.0]
    imported = [1.5, 0.002, 1.0]
    scale = _uniform_scale(declared, imported)
    # max(declared)/max(imported) = 3.0/1.5 = 2.0
    assert scale == pytest.approx(2.0)


def test_scale_is_positive_and_finite_for_degenerate_input():
    """A zero-height import must not produce inf or a divide-by-zero."""
    scale = _uniform_scale([1.0, 1.0, 1.0], [0.5, 0.0, 0.5])
    assert scale > 0.0 and scale != float("inf")


def test_a_mesh_that_is_not_the_declared_shape_is_rebuilt_not_refused():
    """Found by running the corpus, and the first fix for it made things worse.

    An attic window was declared [1.0, 1.0, 0.1] -- an upright panel ten centimetres
    thin -- and the generator produced one LYING ON ITS FACE, measured [1.5, 0.14, 1.43].
    Normalisation scales by height, so 1.0 / 0.14 = 7.1 applied uniformly gave
    [10.84, 1.0, 10.32]: a ten-metre window that no room could hold. It went unplaced and
    took the world plan and five cascading gates with it.

    The first attempt refused the descriptor and expected the ladder to fall through to
    procedural. It does not -- descriptors are built AFTER resolution and their errors are
    terminal, so refusing there fails `asset_geometry` instead. Measured on a full corpus
    run that took published from 4 to 1. The detection was right; the consequence was
    wrong, and it was wrong in exactly the half that was reasoned about rather than run.

    So this pins the CONSEQUENCE, not just the arithmetic: a bad mesh is replaced at
    resolution time and the descriptors that follow are clean.
    """
    from assets.descriptors import (
        implausible_proportions,
        normalised_dimensions,
    )

    declared = [1.0, 1.0, 0.1]
    lying_down = [1.5, 0.14, 1.43]
    would_be = normalised_dimensions(declared, lying_down)
    # 1.0 / 0.14 = 7.14, applied to all three axes. (The live run measured 10.84 from
    # unrounded import dimensions; these are the rounded ones quoted above, so the
    # arithmetic here is checked against its own inputs rather than against a figure
    # copied out of a log.)
    assert would_be[0] == pytest.approx(10.71, abs=0.05)

    implausible, ratio, axis = implausible_proportions(declared, would_be)
    assert implausible is True
    assert ratio == pytest.approx(102.1, abs=0.5)
    assert axis == 2

    # The character that must survive: outstretched arms legitimately span far wider
    # than a declared shoulder width, which is the same counter-example that stopped
    # `_uniform_scale` matching longest-to-longest.
    ok, ratio, _ = implausible_proportions([0.7, 1.8, 0.7], [1.92, 1.8, 0.35])
    assert ok is False
    assert ratio == pytest.approx(2.74, abs=0.02)


def test_both_directions_are_judged_by_the_same_factor():
    """Undershoot used to be permitted, on the reasoning that a small mesh "leaves a gap,
    which reads as a modelling choice". A rendered village disproved it: two dwellings
    declared [8, 4, 6] m normalised to [1.9, 4.0, 0.4] m and shipped as 0.4 m-thin white
    slabs standing in a field. A house 6 m deep arriving 0.4 m deep is a billboard.

    Judging it is safe because normalisation matches HEIGHT, so the vertical axis always
    agrees and an undershoot on x or z means the footprint aspect is wrong rather than
    that the mesh is merely small."""
    from assets.descriptors import implausible_proportions

    implausible, ratio, axis = implausible_proportions([2.0, 2.0, 2.0], [0.1, 0.1, 0.1])
    assert implausible is True
    assert ratio == pytest.approx(0.05)

    # The measured case, from run_fc7e6f68fcd9448287dcb5bd94f7b057.
    slab, ratio, axis = implausible_proportions([8.0, 4.0, 6.0], [1.9, 4.0, 0.4])
    assert slab is True
    assert axis == 2, "depth is the worst offender: 0.4 m where 6 m was declared"
    assert ratio == pytest.approx(0.0667, abs=1e-3)

    # A mesh that collapses to nothing is caught by the same rule.
    gone, _, _ = implausible_proportions([1.0, 0.05, 1.0], [0.001, 0.1, 0.1])
    assert gone is True


def test_a_declared_thin_object_is_not_punished_for_being_thin():
    """A rug really is 2 cm thick. The rule compares against the DECLARATION, so a thin
    thing matched by a thin mesh is in proportion -- otherwise this would forbid every
    flat object in the vocabulary."""
    from assets.descriptors import implausible_proportions

    implausible, _, _ = implausible_proportions([2.0, 0.02, 3.0], [2.05, 0.02, 2.9])
    assert implausible is False
