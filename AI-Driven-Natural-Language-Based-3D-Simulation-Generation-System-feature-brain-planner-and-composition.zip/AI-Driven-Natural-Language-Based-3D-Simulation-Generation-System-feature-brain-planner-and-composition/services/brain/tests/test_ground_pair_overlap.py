"""Two things on the ground cannot overlap, whatever their heights say.

Regression for run_fc7e6f68fcd9448287dcb5bd94f7b057 and
run_93c70fae32134e5a85c3c3c410bd0c3f, which both failed the mandatory
`semantic_placement` gate on the same pair -- a garden hose accepted 0.15 m inside a
dwelling because their y intervals happened to miss by about 3 cm.

`_overlaps_oriented` short-circuits on disjoint vertical extents, which is right for
things genuinely stacked (a lamp above a bench) and wrong for two bodies both seated on
terrain: `_reseat_on_terrain` rewrites their y afterwards, so the gap the placer saw was
an artifact of the unpadded field and closed the moment the ground was final.

The distinction is derived inside `entities_conflict` from the support records both
callers already hold -- never passed in separately. That check drifted eight times when
placement and validation were each allowed to compute it.
"""

from pcg.semantic import entities_conflict


def _body(entity_id, position, dimensions, *, support_type="terrain", clearance=0.0):
    half_x, half_y, half_z = (value / 2.0 for value in dimensions)
    return {
        "entity_id": entity_id,
        "dimensions_m": list(dimensions),
        "transform": {"position_m": list(position), "rotation_y_degrees": 0.0},
        "world_aabb": {
            "min": [position[0] - half_x, position[1] - half_y, position[2] - half_z],
            "max": [position[0] + half_x, position[1] + half_y, position[2] + half_z],
        },
        "support": {"type": support_type},
        "interaction_clearance_m": clearance,
    }


GROUND = {"type": "terrain"}
STACKED = {"type": "entity", "target_id": "ent_table"}


def test_a_vertical_gap_does_not_excuse_a_footprint_overlap_on_the_ground():
    # The measured case: footprints overlap, y intervals miss by a hair.
    house = _body("ent_dwelling_b", [0.0, 2.5, 0.0], [4.0, 4.0, 4.0])
    house["world_aabb"]["min"][1] = 0.83
    house["world_aabb"]["max"][1] = 4.83
    assert entities_conflict(
        [1.9, 0.8, 0.0], [1.0, 0.05, 1.0], 0.0, 0.0, house,
        adjacent=False, own_support=GROUND,
    )


def test_two_bodies_whose_heights_are_settled_keep_the_vertical_test():
    """Both attached, so neither will be reseated -- their vertical gap is a fact.

    Two signs at different heights on the same wall must not conflict. This is the case
    the vertical test still exists for, and the reason the rule is "either body is on the
    ground" rather than "always ignore height".
    """
    upper = _body("ent_sign_upper", [0.0, 3.0, 0.0], [1.0, 0.4, 0.1], support_type="entity")
    assert not entities_conflict(
        [0.0, 1.2, 0.0], [1.0, 0.4, 0.1], 0.0, 0.0, upper,
        adjacent=False, own_support=STACKED,
    )


def test_a_thing_on_the_ground_cannot_hide_under_an_attached_one():
    """The measured failure, from both village runs.

    A garden hose cleared a service door by 3 cm, then by nothing at all once
    `_reseat_on_terrain` lifted it from y 0.56 to y 0.83 -- exactly the door's base, and
    0.33 m from a door needing 1.5 m to open. A vertical gap involving a body that is
    about to be reseated is a guess, not a fact.

    A child resting on its PARENT is unaffected: both callers skip that pair before it
    reaches here.
    """
    door = _body(
        "ent_svc_door", [0.19, 1.83, -4.33], [0.96, 2.0, 0.18],
        support_type="entity", clearance=1.5,
    )
    assert entities_conflict(
        [-0.48, 0.58, -5.97], [1.0, 0.05, 1.0], 0.0, 0.25, door,
        adjacent=False, own_support=GROUND,
    )


def test_two_ground_bodies_that_do_not_share_ground_are_still_clear():
    far = _body("ent_far", [20.0, 0.5, 20.0], [1.0, 1.0, 1.0])
    assert not entities_conflict(
        [0.0, 0.5, 0.0], [1.0, 1.0, 1.0], 0.0, 0.0, far,
        adjacent=False, own_support=GROUND,
    )


def test_the_default_keeps_the_stricter_ground_reading():
    # `own_support` omitted must not silently restore the old permissive behaviour:
    # an absent support record is a ground body, not a stacked one.
    house = _body("ent_dwelling_b", [0.0, 2.5, 0.0], [4.0, 4.0, 4.0])
    house["world_aabb"]["min"][1] = 0.83
    house["world_aabb"]["max"][1] = 4.83
    assert entities_conflict(
        [1.9, 0.8, 0.0], [1.0, 0.05, 1.0], 0.0, 0.0, house, adjacent=False
    )


def test_the_validator_asks_the_same_question_as_the_placer():
    """The ninth drift, and the parameter that caused it.

    `own_support` was added for the placer and not passed by the validator, where it
    defaulted to None -- which `entities_conflict` reads as "on the ground". A service
    door attached two metres up a wall was then judged as a ground object, and a garden
    hose 0.9 m away failed the mandatory placement gate, while the placer had correctly
    seen the door pass overhead (run_b6234550ab5f44078eb2450d786ca77e).

    Asserted through `validate_semantic_world_plan` rather than `entities_conflict`,
    because the defect was never in the rule -- it was in one caller asking it
    differently.
    """
    from pcg.semantic import validate_semantic_world_plan

    door = _body(
        "ent_svc_door",
        [0.19, 1.83, -4.33],
        [0.96, 2.0, 0.18],
        support_type="entity",
        clearance=1.5,
    )
    door["support"]["target_id"] = "ent_dwelling"
    door["parent_id"] = "ent_dwelling"
    hose = _body("ent_garden_hose", [-0.48, 0.58, -5.97], [1.0, 0.05, 1.0], clearance=0.25)
    hose["parent_id"] = None

    plan = {
        "schema_version": "1.0.0",
        "simulation_id": "sim_drift",
        "seed": 1,
        "world_bounds": {"min": [-40.0, -1.0, -40.0], "max": [40.0, 20.0, 40.0]},
        "zones": [
            {
                "zone_id": "main",
                "semantic_type": "main",
                "bounds": {"min": [-40.0, -1.0, -40.0], "max": [40.0, 20.0, 40.0]},
                "connected_to": [],
            }
        ],
        "terrain": {"width_m": 80.0, "depth_m": 80.0, "grid": 2, "amplitude_m": 0.0,
                    "heights_m": [0.0, 0.0, 0.0, 0.0]},
        "entities": [door, hose],
        "behaviours": [],
        "relationships": [],
        "navigation": {},
        "constraint_summary": {"unplaced_entities": []},
        "scatter": {"instances": []},
    }
    for entity in plan["entities"]:
        entity.setdefault("semantic_type", "thing")
        entity.setdefault("zone_id", "main")
        entity.setdefault("asset_ref", "entity:" + entity["entity_id"])
        entity.setdefault("measurement_status", "MEASURED")
        entity.setdefault("dynamic", False)

    result = validate_semantic_world_plan(plan)
    errors = result.get("errors") if isinstance(result, dict) else result
    overlaps = [e for e in errors if e.get("code") == "ENTITY_OVERLAP_OR_CLEARANCE"]
    assert overlaps == [], "a door overhead is not an obstruction on the ground"
