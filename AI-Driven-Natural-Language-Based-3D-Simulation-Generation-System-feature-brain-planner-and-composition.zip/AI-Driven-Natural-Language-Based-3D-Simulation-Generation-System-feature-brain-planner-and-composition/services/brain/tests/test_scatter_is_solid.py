"""Scatter is solid objects, and the contract has to say so structurally.

A live run asked for "volumetric fog particles simulating misty conditions" as a
scatter species, declared it a `vehicle` requiring animation, named
`irregular_mass` as its form and gave it `size_m=[5,5,5]` at density 10 per
100 m². The system did exactly as told and drew ninety five-metre boulders
across the map. Nothing was broken; the vocabulary simply let the planner ask
for something scatter cannot be.

Following ADR-0009: make the contradiction unrepresentable rather than argue
with the model about it in a prompt.
"""

from __future__ import annotations

import json
from pathlib import Path

import jsonschema
import pytest

_SCHEMA = json.loads(
    (Path(__file__).resolve().parents[3] / "contracts" / "simulation_spec.schema.json")
    .read_text(encoding="utf-8")
)
_SPECIES = {"$ref": "#/$defs/scatter_species", "$defs": _SCHEMA["$defs"]}


def _species(**asset_overrides) -> dict:
    asset = {
        "brief": "low dense green tea bushes covering the terraces",
        "category": "foliage",
        "requires_animation": False,
        "preferred_source": "procedural",
        "procedural_type": "ground_cover",
    }
    asset.update(asset_overrides)
    return {
        "species_id": "spc_tea_bush",
        "semantic_type": "tea_bush",
        "asset": asset,
        "size_m": [1.5, 0.8, 1.5],
        "density_per_100m2": 40,
        "clustering": "even",
        "near_tags": [],
        "avoid_tags": [],
    }


def test_an_ordinary_species_still_validates():
    jsonschema.validate(_species(), _SPECIES)


def test_scatter_cannot_require_animation():
    """A MultiMesh has no rig and no animation player, so this asks for
    something the instancer cannot provide. The mist species declared it."""
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(_species(requires_animation=True), _SPECIES)


@pytest.mark.parametrize("category", ["character", "vehicle"])
def test_scatter_cannot_be_a_character_or_a_vehicle(category):
    """Both need a rig, behaviour or a collision body; scatter has none of
    those. The mist that became boulders had declared itself a vehicle."""
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(_species(category=category), _SPECIES)


@pytest.mark.parametrize("category", ["prop", "structure", "environment", "foliage"])
def test_the_categories_scatter_can_legitimately_be_are_kept(category):
    jsonschema.validate(_species(category=category), _SPECIES)


def test_the_exact_mist_species_from_the_live_run_is_now_rejected():
    """The regression, in the form it actually shipped in."""
    mist = {
        "species_id": "spc_mist_particle",
        "semantic_type": "mist_volumetric",
        "asset": {
            "brief": "volumetric fog particles simulating misty conditions",
            "category": "vehicle",
            "requires_animation": True,
            "preferred_source": "procedural",
            "procedural_type": "irregular_mass",
        },
        "size_m": [5.0, 5.0, 5.0],
        "density_per_100m2": 10,
        "clustering": "random",
        "near_tags": [],
        "avoid_tags": [],
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(mist, _SPECIES)
