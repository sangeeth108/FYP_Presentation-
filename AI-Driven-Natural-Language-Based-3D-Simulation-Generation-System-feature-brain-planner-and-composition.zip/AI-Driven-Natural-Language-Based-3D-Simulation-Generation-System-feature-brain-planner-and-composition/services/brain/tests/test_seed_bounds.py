"""The auto-derived seed must fit the column that stores it.

Regression: the seed came from the first 8 hex digits of sha256(prompt), which is
a 32-bit UNSIGNED value, while `simulations.seed` is a signed 32-bit INTEGER. Any
prompt hashing to >= 0x80000000 — roughly half of them — failed creation with
`DataError: integer out of range`, and the browser reported it as a CORS error
because the 500 carried no CORS headers. "Explore a lush jungle..." hashed to
3943104326 and could never be generated.
"""

from __future__ import annotations

import hashlib
import json

import pytest
from core.schemas import CreateSimulationRequest
from pydantic import ValidationError

PG_INT_MAX = 2_147_483_647

# Prompts whose raw sha256[:8] exceeds the signed range, so they exercise the bug.
OVERFLOWING_PROMPTS = [
    "Explore a lush jungle with ancient ruins and a winding river.",
    "A foggy abandoned village where I scavenge supplies and hide from zombies.",
    "Simulate a factory line where a sensor starts a machine.",
    "Explore a quiet stone courtyard with a wooden door you can open.",
]


def _derived_seed(prompt: str) -> int:
    """Mirror of the API's derivation, so the bound is asserted on the real value."""
    return int(hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:8], 16) & 0x7FFFFFFF


def test_raw_hash_would_overflow_for_real_prompts():
    """Guard the guard: if none of these overflow, the test has stopped testing."""
    raw = [
        int(hashlib.sha256(p.encode("utf-8")).hexdigest()[:8], 16)
        for p in OVERFLOWING_PROMPTS
    ]
    assert any(value > PG_INT_MAX for value in raw), (
        "no sample prompt exceeds the signed range any more — pick new samples"
    )


@pytest.mark.parametrize("prompt", OVERFLOWING_PROMPTS)
def test_derived_seed_fits_a_signed_integer(prompt):
    seed = _derived_seed(prompt)
    assert 0 <= seed <= PG_INT_MAX


def test_derived_seed_is_stable_per_prompt():
    """Masking must not cost determinism: same prompt, same seed."""
    prompt = OVERFLOWING_PROMPTS[0]
    assert _derived_seed(prompt) == _derived_seed(prompt)
    assert _derived_seed(prompt) != _derived_seed("a completely different prompt")


def test_api_rejects_an_out_of_range_client_seed():
    """An impossible seed must 422 at the boundary, not crash the insert."""
    with pytest.raises(ValidationError):
        CreateSimulationRequest(prompt="a valid prompt for testing", seed=PG_INT_MAX + 1)


def test_api_accepts_the_largest_valid_seed():
    request = CreateSimulationRequest(prompt="a valid prompt for testing", seed=PG_INT_MAX)
    assert request.seed == PG_INT_MAX


def test_live_creation_succeeds_for_a_previously_failing_prompt(client):
    """End to end: the exact prompt that used to 500 must now be accepted."""
    response = client.post(
        "/api/v1/simulations",
        json={"prompt": OVERFLOWING_PROMPTS[0], "target_platforms": ["web"]},
    )
    assert response.status_code == 202, response.text
    assert response.json()["simulation_id"].startswith("sim_")


# --- Schema ranges the guided grammar cannot enforce -------------------------
#
# Both cases below are real 27B output from a ten-prompt spread, not invented:
# guided decoding can express "a number goes here" but not "<= 200", so every
# bounded field in the contract is exposed and one bad value used to throw the
# entire world away.


def test_an_absurd_scatter_density_is_clamped_not_fatal():
    """Mars base: the model asked for 10,000 instances per 100 m2.

    The ceiling later moved from 200 to 5000, because 200 could not express
    ground cover and was clamping accurate planners. What this test pins is
    unchanged: an out-of-range number costs one value, never the whole world.
    """
    from agents.simulation_planner import _clamp_out_of_range_numbers

    candidate = {
        "scatter": [
            {
                "species_id": "spc_regolith_rock",
                "semantic_type": "regolith_boulder",
                "density_per_100m2": 10000,
                "size_m": [0.6, 0.4, 0.6],
                "asset": {
                    "brief": "a weathered regolith boulder",
                    "category": "environment",
                    "requires_animation": False,
                    "preferred_source": "procedural",
                    "procedural_type": "semantic_box",
                },
            }
        ]
    }
    clamped = _clamp_out_of_range_numbers(candidate)
    assert candidate["scatter"][0]["density_per_100m2"] == 5000
    assert clamped[0]["path"] == "scatter[0].density_per_100m2"
    assert clamped[0]["requested"] == 10000


def test_a_small_but_honest_world_is_accepted_rather_than_inflated():
    """Rooftop garden: the model said 15 m deep, which is right for a roof.

    Originally the 20 m floor clamped it upward -- better than losing the whole
    world to a validation error, but still the contract overruling an accurate
    answer. The floor is now 8 m, so a roof stays a roof, and only genuinely
    unusable extents are raised.
    """
    from agents.simulation_planner import _clamp_out_of_range_numbers

    candidate = {
        "environment": {"dimensions_m": {"width": 24.0, "depth": 15.0, "max_height": 8.0}}
    }
    assert _clamp_out_of_range_numbers(candidate) == []
    assert candidate["environment"]["dimensions_m"]["depth"] == 15.0

    # Below the floor it is still raised rather than discarded.
    tiny = {"environment": {"dimensions_m": {"width": 3.0, "depth": 15.0, "max_height": 8.0}}}
    _clamp_out_of_range_numbers(tiny)
    assert tiny["environment"]["dimensions_m"]["width"] == 8


def test_clamping_covers_fields_nobody_special_cased():
    """The point of doing it against the schema: no field needs its own fix."""
    from agents.simulation_planner import _clamp_out_of_range_numbers

    candidate = {
        "meta": {"seed": 99_999_999_999},
        "performance": {"web_target_fps": 500, "web_memory_mb": 1},
        "scatter": [
            {
                "species_id": "spc_tree",
                "semantic_type": "tree",
                "density_per_100m2": 4.0,
                "size_m": [400.0, 0.0, 2.0],
                "asset": {
                    "brief": "a tree",
                    "category": "environment",
                    "requires_animation": False,
                    "preferred_source": "procedural",
                    "procedural_type": "semantic_box",
                },
            }
        ],
    }
    _clamp_out_of_range_numbers(candidate)
    assert candidate["meta"]["seed"] == 2147483647
    assert candidate["performance"]["web_target_fps"] == 120
    assert candidate["performance"]["web_memory_mb"] == 256
    assert candidate["scatter"][0]["size_m"][0] == 60  # maximum
    assert candidate["scatter"][0]["size_m"][1] > 0  # exclusiveMinimum, not zero


def test_in_range_values_are_left_exactly_alone():
    """A normalisation that rewrites healthy specs would be worse than the bug."""
    from agents.simulation_planner import _clamp_out_of_range_numbers

    candidate = {
        "meta": {"seed": 4521},
        "environment": {"dimensions_m": {"width": 120.0, "depth": 120.0, "max_height": 40.0}},
        "performance": {
            "desktop_target_fps": 60,
            "web_target_fps": 60,
            "desktop_memory_mb": 2048,
            "web_memory_mb": 1024,
        },
    }
    before = json.loads(json.dumps(candidate))
    assert _clamp_out_of_range_numbers(candidate) == []
    assert candidate == before


def test_a_repeated_capability_is_deduped_not_fatal():
    """Coral reef: guided decoding emitted camera_control twice and lost the world.

    A grammar can emit an array of enum values but has no memory of which it
    already used, so `uniqueItems` is unenforceable at decode time — the same
    class of gap as an out-of-range number, and the same total cost.
    """
    from agents.simulation_planner import _dedupe_unique_arrays

    candidate = {
        "capabilities": ["camera_control", "locomotion", "camera_control"],
        "request": {"target_platforms": ["web", "web", "desktop"]},
    }
    _dedupe_unique_arrays(candidate)
    assert candidate["capabilities"] == ["camera_control", "locomotion"]
    assert candidate["request"]["target_platforms"] == ["web", "desktop"]


def test_dedupe_preserves_order_and_leaves_clean_arrays_alone():
    from agents.simulation_planner import _dedupe_unique_arrays

    candidate = {"capabilities": ["locomotion", "camera_control", "openable"]}
    before = list(candidate["capabilities"])
    _dedupe_unique_arrays(candidate)
    assert candidate["capabilities"] == before


def test_arrays_without_uniqueitems_keep_their_repeats():
    """Two identical requirements are legal; dedupe must not invent a rule."""
    from agents.simulation_planner import _dedupe_unique_arrays

    entity = {
        "entity_id": "ent_a",
        "physical": {"bbox_m": [1.0, 1.0, 1.0]},
    }
    candidate = {"entities": [entity, dict(entity)]}
    _dedupe_unique_arrays(candidate)
    assert len(candidate["entities"]) == 2


def test_an_interior_scale_world_is_accepted_without_clamping():
    """A museum gallery is 8 m across; the old 20 m floor called that an error."""
    from agents.simulation_planner import _clamp_out_of_range_numbers

    candidate = {
        "environment": {"dimensions_m": {"width": 8.0, "depth": 12.0, "max_height": 6.0}}
    }
    assert _clamp_out_of_range_numbers(candidate) == []
    assert candidate["environment"]["dimensions_m"]["width"] == 8.0
