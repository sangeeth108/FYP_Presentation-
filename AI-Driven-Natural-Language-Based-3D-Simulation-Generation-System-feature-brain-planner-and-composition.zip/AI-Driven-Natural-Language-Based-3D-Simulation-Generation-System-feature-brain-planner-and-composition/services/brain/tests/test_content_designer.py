"""Content Designer: the LLM authors the world's contents, safely.

Invention is impossible by construction (registry ids ARE the guided-JSON
enum), and everything is re-validated + clamped afterwards anyway.
"""

import json

import httpx
from agents.composition_patterns import known_archetypes
from agents.content_designer import entities_schema, llm_entities, sanitize
from agents.intent import parse_intent
from knowledge.registries import registry


class _Settings:
    llm_base_url = "http://mock"
    llm_model = "qwen3.6:27b"
    llm_timeout_seconds = 5.0


def _transport(payload) -> httpx.MockTransport:
    content = payload if isinstance(payload, str) else json.dumps(payload)

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        # The registry allowlist must be baked into the schema the model sees.
        enum = body["format"]["properties"]["props"]["items"]["properties"][
            "interactable_template_id"
        ]["enum"]
        assert set(enum) == set(registry()["interactable_template_id"])
        return httpx.Response(200, json={"message": {"content": content}})

    return httpx.MockTransport(handler)


def _prop(prop_id: str, template: str = "chest_lidded") -> dict:
    return {
        "prop_id": prop_id,
        "interactable_template_id": template,
        "placement_tags": ["loot"],
        "asset_brief": {"brief": "a cracked funerary urn", "category": "prop", "tri_budget": 800},
    }


def _enemy(enemy_id: str, count: int = 4) -> dict:
    return {
        "enemy_id": enemy_id,
        "ai_template_id": "ai_patrol_chase",
        "count": count,
        "stats": {"health": 6, "damage": 2, "speed": 3},
        "asset_brief": {
            "brief": "an ash-caked revenant",
            "category": "character",
            "tri_budget": 8000,
        },
    }


GOOD = {
    "props": [_prop("bone_urn"), _prop("iron_chest"), _prop("wall_torch", "lever_switch"),
              _prop("rope_ladder", "ladder_climbable"), _prop("rusted_gate", "gate_sliding")],
    "enemies": [_enemy("ash_revenant", 4)],
}


def test_registry_ids_are_the_schema_enum():
    schema = entities_schema()
    prop_enum = schema["properties"]["props"]["items"]["properties"][
        "interactable_template_id"
    ]["enum"]
    assert set(prop_enum) == set(registry()["interactable_template_id"])
    # An invented id is literally unrepresentable in the model's output.
    assert "controller_hover_bike" not in prop_enum


def test_authored_content_is_accepted():
    brief = parse_intent("a torchlit crypt with a few skeletons")
    result = llm_entities("a torchlit crypt", brief, _Settings(), transport=_transport(GOOD))
    assert result is not None
    assert [p["prop_id"] for p in result["props"]] == [
        "bone_urn", "iron_chest", "wall_torch", "rope_ladder", "rusted_gate"
    ]
    assert result["enemies"][0]["enemy_id"] == "ash_revenant"
    assert result["props"][0]["asset_brief"]["brief"] == "a cracked funerary urn"


def test_duplicate_ids_are_deduped_not_left_to_collide():
    # Godot node names derive from these ids — duplicates would break the scene.
    raw = {"props": [_prop("chest"), _prop("chest"), _prop("chest"), _prop("chest")],
           "enemies": [_enemy("ghoul")]}
    result = sanitize(raw, parse_intent("a crypt with skeletons"))
    ids = [p["prop_id"] for p in result["props"]]
    assert ids == ["chest", "chest_2", "chest_3", "chest_4"]
    assert len(set(ids)) == len(ids)


def test_enemy_counts_are_clamped_to_the_brief_budget():
    brief = parse_intent("a crypt with few enemies")  # -> enemy_count 3
    raw = {"props": GOOD["props"], "enemies": [_enemy("a", 20), _enemy("b", 20)]}
    result = sanitize(raw, brief)
    assert sum(e["count"] for e in result["enemies"]) <= brief.enemy_count


def test_peaceful_brief_gets_no_enemies_even_if_the_model_offers_some():
    brief = parse_intent("a peaceful cozy meadow, no enemies")  # -> enemy_count 0
    result = sanitize({"props": GOOD["props"], "enemies": [_enemy("wolf")]}, brief)
    assert result["enemies"] == []


def test_bad_output_falls_back_rather_than_shipping_junk():
    brief = parse_intent("a crypt with skeletons")
    # Too few props to be a world.
    assert sanitize({"props": [_prop("a")], "enemies": [_enemy("x")]}, brief) is None
    # Garbage / unreachable server.
    assert llm_entities("x", brief, _Settings(), transport=_transport("not json")) is None

    def down(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("refused")

    assert llm_entities("x", brief, _Settings(), transport=httpx.MockTransport(down)) is None


# --- composite interactive objects (ADR-0008 phase 3b) --------------------


def _obj(object_id: str, archetype: str = "vehicle", bbox=(2.0, 1.5, 4.0)) -> dict:
    return {"object_id": object_id, "archetype": archetype, "bbox": list(bbox),
            "brief": "a rusty pickup truck, low-poly", "placement_tags": ["street"]}


def test_objects_archetype_enum_is_the_pattern_menu():
    schema = entities_schema()
    enum = schema["properties"]["objects"]["items"]["properties"]["archetype"]["enum"]
    assert set(enum) == set(known_archetypes())  # invented archetypes are impossible


def test_authored_objects_are_accepted_and_carry_through():
    brief = parse_intent("drive through a ruined city")
    result = sanitize({**GOOD, "objects": [_obj("rusty_truck"), _obj("old_house", "building",
                       (6, 4, 6))]}, brief)
    assert [o["object_id"] for o in result["objects"]] == ["rusty_truck", "old_house"]
    assert result["objects"][0]["archetype"] == "vehicle"


def test_object_bbox_is_clamped_and_bad_ones_dropped():
    brief = parse_intent("a city")
    raw = {**GOOD, "objects": [
        {"object_id": "huge", "archetype": "vehicle", "bbox": [99, 99, 99], "brief": "a big rig"},
        {"object_id": "noshape", "archetype": "vehicle", "bbox": [1, 2], "brief": "broken"},
    ]}
    objs = sanitize(raw, brief)["objects"]
    assert [o["object_id"] for o in objs] == ["huge"]  # the malformed-bbox one is dropped
    assert max(objs[0]["bbox"]) <= 15.0  # clamped to the metric ceiling


def test_object_ids_are_deduped_against_props_and_each_other():
    brief = parse_intent("a city")
    raw = {**GOOD, "objects": [_obj("bone_urn"), _obj("bone_urn")]}  # collides with a prop id
    ids = [o["object_id"] for o in sanitize(raw, brief)["objects"]]
    assert len(set(ids)) == 2 and "bone_urn" not in ids  # all unique, no scene-node clash


def test_no_objects_key_when_none_authored():
    result = sanitize(GOOD, parse_intent("a bare crypt"))
    assert "objects" not in result  # most games have none; the field stays absent
