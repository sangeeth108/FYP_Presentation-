"""An invisible thing is not asked to be visible.

Measured on the forest prompt, which blocked publication run after run on one entity whose
own spec reads:

    role "logic_driver", semantic_type "system_entity",
    brief "Invisible logic entity driving ecosystem behaviors"

`ENTITY_PRESENCE_REQUIREMENT_MISSING` asks it to trace to a noun in the prompt. It is not
content somebody described; it is the mechanism by which described content behaves.
"""

from verification.contracts import _is_disembodied, _performs_a_capability


def test_a_declared_logic_driver_is_disembodied() -> None:
    assert _is_disembodied({"role": "logic_driver", "semantic_type": "system_entity"})
    assert _is_disembodied({"role": "", "semantic_type": "sensor_trigger"})


def test_a_real_thing_is_not_disembodied_however_small() -> None:
    """Judged on what the spec SAYS, not on size: a 10 cm entity may be a real pebble."""
    assert not _is_disembodied({"role": "prop", "semantic_type": "pebble"})
    assert not _is_disembodied({"role": "controlled_agent", "semantic_type": "dog"})


def test_the_exemption_requires_a_capability_to_name_it() -> None:
    """Not a free pass. An invented ornament calling itself a controller still fails,
    because no capability would name it as the performer (ADR-0021)."""
    spec = {
        "capabilities": [
            {"capability": "ecosystem_process", "entity_id": "ent_ecosystem_controller"}
        ]
    }
    assert _performs_a_capability(spec, "ent_ecosystem_controller")
    assert not _performs_a_capability(spec, "ent_ornament")


def test_capabilities_written_as_plain_strings_do_not_crash() -> None:
    """Some specs list capability ids rather than objects; neither names an entity."""
    assert not _performs_a_capability({"capabilities": ["locomotion"]}, "ent_x")
    assert not _performs_a_capability({}, "ent_x")
