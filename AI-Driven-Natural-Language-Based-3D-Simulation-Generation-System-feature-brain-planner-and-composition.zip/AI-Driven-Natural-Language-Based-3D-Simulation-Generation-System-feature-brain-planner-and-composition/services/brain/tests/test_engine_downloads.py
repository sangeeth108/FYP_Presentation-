"""What the engine is offered to a user AS.

The binary is a full editor and thoroughly branded -- "Serendib Engine" appears
twelve times inside it, the splash and app icon are ours, and the About dialog
carries the mandatory Godot credit. None of that is visible in a filename, and the
filename is the first thing a user sees.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path

from api.engine import _PUBLISHED, published_name

REPO = Path(__file__).resolve().parents[3]


def test_a_download_is_offered_under_the_serendib_name():
    """SCons hardcodes the `godot` prefix; a download must not inherit it.

    Someone who downloads `godot.windows.editor.x86_64.exe` reasonably concludes the
    rebrand never happened, whatever the About box says. The bytes are unchanged --
    this is the label on the box.
    """
    assert (
        published_name("godot.windows.editor.x86_64.exe")
        == "serendib.windows.editor.x86_64.exe"
    )
    assert (
        published_name("godot.web.template_release.wasm32.nothreads.zip")
        == "serendib.web.template_release.wasm32.nothreads.zip"
    )
    # Every artifact the API publishes has to be covered by the rule, or the
    # download page offers a name that is not on disk.
    for filename, _kind, _label, _platform in _PUBLISHED:
        assert published_name(filename).startswith("serendib."), filename


def test_a_name_without_the_upstream_prefix_is_left_alone():
    """Derived by rule, not tabulated, so an unfamiliar artifact passes through.

    A rule that mangled anything it did not recognise would be worse than no rule:
    a build product added later would be offered under a name nobody wrote.
    """
    assert published_name("serendib.windows.editor.x86_64.exe") == (
        "serendib.windows.editor.x86_64.exe"
    )
    assert published_name("web_nothreads_release.zip") == "web_nothreads_release.zip"


def test_the_build_script_and_the_api_agree_on_the_name():
    """Two copies of one rule, and this is what stops them drifting.

    The build script is standalone tooling and the API is a service, so there is no
    module both can import. If they disagree the build publishes one filename and the
    download page links another, and every link on that page 404s -- which looks like
    a broken server rather than a naming mistake.
    """
    script = REPO / "engine" / "serendib" / "build_scripts" / "build_serendib.py"
    spec = importlib.util.spec_from_file_location("build_serendib", script)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    for name in (
        "godot.windows.editor.x86_64.exe",
        "godot.web.template_release.wasm32.nothreads.zip",
        "godot.windows.template_release.x86_64.exe",
        "already.renamed.exe",
    ):
        assert module._published_name(name) == published_name(name), name


def test_the_editor_export_template_names_are_not_renamed():
    """The engine dictates these, so they must stay exactly as it expects them.

    The editor asks its export_templates directory for `web_nothreads_release.zip`.
    Renaming those to match the product would break every export with a
    configuration error naming a path nobody created -- the rebrand must stop at the
    boundary where the engine is the one reading the filename.
    """
    script = REPO / "engine" / "serendib" / "build_scripts" / "build_serendib.py"
    source = script.read_text(encoding="utf-8")
    assert '"web_nothreads_release.zip"' in source
    assert '"windows_release_x86_64.exe"' in source


def test_engine_source_detection_survives_the_rebrand():
    """The identity patch broke a check that looks for the upstream short_name.

    `methods.py` decides whether a directory is the engine source by finding
    `short_name = "godot"` in version.py. The rebrand changed it to "serendib", so
    is_engine() returned False for our own tree and detect_modules() would recurse
    into it under `custom_modules`. Nothing has failed because no build here passes
    that option, which is precisely why it was worth repairing before someone hit it.

    Both names are accepted: a build machine legitimately holds a pristine checkout
    beside a rebranded one.
    """
    methods = REPO / "engine" / "serendib" / "upstream" / "methods.py"
    if not methods.is_file():
        return  # no upstream checkout on this machine
    source = methods.read_text(encoding="utf-8")
    assert 'short_name = "serendib"' in source, "the rebranded name must be accepted"
    assert 'short_name = "godot"' in source, "upstream must still be recognised"


def test_the_patch_series_records_the_detection_repair():
    """A change to upstream code that is not in the patch series is lost on rebase.

    The rule in CLAUDE.md is that rebasing onto a newer tag means re-applying the
    patches; anything hand-edited into the checkout and not written down disappears
    the first time that happens.
    """
    patches = sorted(
        (REPO / "engine" / "serendib" / "patches").glob("*.patch")
    )
    names = [path.name for path in patches]
    assert any("engine-source-detection" in name for name in names), names
    text = next(
        path.read_text(encoding="utf-8")
        for path in patches
        if "engine-source-detection" in path.name
    )
    assert "methods.py" in text
    assert "short_name" in text
