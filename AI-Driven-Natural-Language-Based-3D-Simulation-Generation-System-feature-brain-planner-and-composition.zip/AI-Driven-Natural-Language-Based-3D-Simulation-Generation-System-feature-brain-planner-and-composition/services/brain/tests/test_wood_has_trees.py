"""A world that calls itself wooded needs more than one tree.

Measured on the forest run where world sizing and ground cover both worked: 740 instances
scattered into a 48x37 m world, and it still failed the visual critic, because of WHAT
was scattered --

    leaf_litter 500 | ferns 120 | rocks 50 | branches 40 | salmonberry 30
    entities: a student, a stump, a nest, a squirrel, a bird, and `ent_cedar`,
              a single 10x20 m tree

The floor of a forest in full detail, and no forest. This is why "the scene lacks trees"
survived every other fix.
"""

from agents.simulation_planner import _a_wood_has_trees

_FOREST_FLOOR = [
    {"species_id": "spc_leaf_litter", "size_m": [0.05, 0.15, 0.05],
     "density_per_100m2": 500},
    {"species_id": "spc_ferns", "size_m": [0.2, 0.2, 0.2], "density_per_100m2": 120},
]


def _world(semantic_type: str, width=69.582, depth=52.186, entities=(), scatter=()) -> dict:
    return {
        "environment": {
            "world_kind": "outdoor",
            "semantic_type": semantic_type,
            "terrain": "natural_ground",
            "dimensions_m": {"width": width, "depth": depth},
        },
        "entities": list(entities),
        "scatter": list(scatter),
    }


def _canopy(candidate: dict) -> dict | None:
    return next(
        (s for s in candidate.get("scatter", []) if s["species_id"] == "spc_canopy_tree"),
        None,
    )


def _instances(candidate: dict, species: dict) -> float:
    dimensions = candidate["environment"]["dimensions_m"]
    return species["density_per_100m2"] * dimensions["width"] * dimensions["depth"] / 100.0


def test_a_forest_with_one_tree_gets_a_canopy() -> None:
    candidate = _world(
        "forest_ecosystem_lesson",
        entities=[{"entity_id": "ent_cedar", "physical": {"bbox_m": [10.0, 20.0, 10.0]}}],
        scatter=list(_FOREST_FLOOR),
    )
    _a_wood_has_trees(candidate)

    canopy = _canopy(candidate)
    assert canopy is not None
    assert _instances(candidate, canopy) >= 8
    # The floor it already had is untouched.
    assert {s["species_id"] for s in candidate["scatter"]} >= {"spc_leaf_litter", "spc_ferns"}
    assert any(
        "wooded" in a["reason"] for a in candidate.get("approximations", [])
    )


def test_a_wood_that_already_has_a_canopy_is_left_alone() -> None:
    candidate = _world(
        "forest_clearing",
        scatter=[{"species_id": "spc_oak", "size_m": [6.0, 14.0, 6.0],
                  "density_per_100m2": 1}],
    )
    _a_wood_has_trees(candidate)
    assert _canopy(candidate) is None


def test_trees_the_planner_listed_as_entities_are_counted() -> None:
    """Eight cedars is a wood however they were authored."""
    candidate = _world(
        "temperate_deciduous_woodland_edge",
        entities=[
            {"entity_id": f"ent_cedar_{i}", "physical": {"bbox_m": [10.0, 20.0, 10.0]}}
            for i in range(8)
        ],
    )
    _a_wood_has_trees(candidate)
    assert _canopy(candidate) is None


def test_a_courtyard_with_one_tree_is_not_a_wood() -> None:
    """The rule reads how the world describes ITSELF, not what it happens to contain."""
    candidate = _world(
        "village_courtyard",
        entities=[{"entity_id": "ent_tree", "physical": {"bbox_m": [4.0, 8.0, 4.0]}}],
        scatter=list(_FOREST_FLOOR),
    )
    _a_wood_has_trees(candidate)
    assert _canopy(candidate) is None


def test_indoor_worlds_grow_nothing() -> None:
    candidate = _world("forest_diorama_room")
    candidate["environment"]["world_kind"] = "indoor"
    _a_wood_has_trees(candidate)
    assert _canopy(candidate) is None


def test_the_canopy_spreads_rather_than_clustering() -> None:
    """Thickets of 11 m crowns fit almost nothing.

    Measured with `clustering: "grouped"`, the sampler reported:

        spc_canopy_tree: requested 48, placed 3,
                         shortfall_reason "packing_limit", spacing_m 11.2996

    The spacing is right -- a mature crown really is ~11 m across, measured from the
    resolved asset -- so grouping them into a few centres leaves room for three. A canopy
    is trees standing apart across the whole wood.
    """
    candidate = _world(
        "forest_ecosystem_lesson",
        entities=[{"entity_id": "ent_cedar", "physical": {"bbox_m": [10.0, 20.0, 10.0]}}],
        scatter=list(_FOREST_FLOOR),
    )
    _a_wood_has_trees(candidate)
    assert _canopy(candidate)["clustering"] == "random"
