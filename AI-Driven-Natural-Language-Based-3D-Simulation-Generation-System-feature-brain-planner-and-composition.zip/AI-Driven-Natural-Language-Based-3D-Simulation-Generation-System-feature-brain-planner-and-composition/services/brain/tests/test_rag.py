"""RAG over design notes: retrieval is relevant, grounded, and never a hard
dependency (falls back to keyword scoring when the embedder is unavailable).

The corpus is PLACE ARCHETYPES, not system rules. That distinction is the
substance of these tests. The previous corpus held design guidance for the four
legacy game genres, and against the simulation prompts this system actually
serves it retrieved NOTHING: every real prompt scored around 0.40 against a 0.50
floor, so ablation D measured "retrieval has no effect" on a corpus that could
not fire. Universal rules belong in the planner's system prompt, where they
apply to every prompt; retrieval is for knowledge whose relevance varies with
the query, which is what a place archetype is.
"""

from knowledge.rag import as_context, load_notes, search

# One representative prompt per archetype, phrased the way a user would rather
# than echoing the note, so a passing test means the archetype generalises
# instead of matching its own wording back.
PROMPT_TO_ARCHETYPE = [
    ("a hospital ward with rows of beds", "place_institutional_interior"),
    ("a car factory assembly line", "place_industrial"),
    ("a flooded subway station", "place_transit"),
    ("a medieval market square", "place_market_commercial"),
    ("a snowy forest clearing", "place_forest_woodland"),
    ("a desert canyon", "place_arid_canyon"),
    ("a Sri Lankan tea estate on a misty hillside", "place_agricultural"),
    ("a coral reef", "place_underwater"),
    ("a Mars research base", "place_enclosed_habitat"),
    ("a rooftop garden", "place_domestic_garden"),
    ("an ancient overgrown temple", "place_ruin_historic"),
]


def test_the_corpus_loads_and_covers_the_archetypes():
    notes = load_notes()
    ids = {n.id for n in notes}
    assert len(notes) >= 12
    for _, archetype in PROMPT_TO_ARCHETYPE:
        assert archetype in ids, f"missing archetype {archetype}"


def test_every_note_carries_the_numbers_a_planner_needs():
    """A note that reads well and says nothing measurable cannot change a spec.

    The planner's failures are numeric -- densities that cannot be satisfied,
    extents that dwarf their content -- so each archetype has to commit to a
    scale and a density rather than describing atmosphere.
    """
    for note in load_notes():
        assert "per 100 m2" in note.text, f"{note.id} states no density"
        assert " m " in note.text or " m," in note.text, f"{note.id} states no scale"


def test_retrieval_finds_the_right_archetype():
    for prompt, archetype in PROMPT_TO_ARCHETYPE:
        ids = [n.id for n in search(prompt, k=3)]
        assert archetype in ids, f"{prompt!r} -> {ids}, expected {archetype}"


def test_search_is_bounded_and_deterministic():
    a = [n.id for n in search("a busy indoor market", k=3)]
    b = [n.id for n in search("a busy indoor market", k=3)]
    assert a == b  # same query -> same notes (reproducible generation)
    assert len(a) <= 3


def test_context_rendering_is_injectable_or_empty():
    notes = search("a coral reef", k=2)
    context = as_context(notes)
    assert context.startswith("Relevant design knowledge")
    assert all(n.text in context for n in notes)
    assert as_context([]) == ""  # nothing retrieved -> no prompt pollution


def test_unmatched_query_returns_nothing_rather_than_noise():
    # Off-domain input must not force irrelevant notes into the planner's
    # context. Holds on BOTH paths: the embedding path via the similarity
    # floor, the keyword path via zero tag hits. "The concept of justice" is
    # here because it is fluent English that is not a place -- the case a
    # gibberish-only test would miss.
    assert search("zzzz qqqq", k=3) == []
    assert search("the concept of justice", k=3) == []


def test_keyword_fallback_works_without_an_embedder():
    # Point at a dead embedder: retrieval must still return relevant notes
    # (the GPU going down must never degrade generation into nothing).
    dead = "http://127.0.0.1:9"  # nothing listens here
    ids = [n.id for n in search("a flooded subway station platform", base_url=dead)]
    assert "place_transit" in ids
    assert search("zzzz qqqq", base_url=dead) == []
