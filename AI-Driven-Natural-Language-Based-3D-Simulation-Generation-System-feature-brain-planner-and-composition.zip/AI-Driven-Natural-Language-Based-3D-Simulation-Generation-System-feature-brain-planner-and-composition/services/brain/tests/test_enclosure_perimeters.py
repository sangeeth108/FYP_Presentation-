"""A boundary drawn corner to corner means the rectangle, not the diagonal.

Guards the warehouse regression: a run whose own `source_text` read "Defines the
perimeter boundary of the simulation volume" was drawn (-20,-30) to (20,30) and expanded
into sixteen 2 m-thick segments slicing diagonally across the middle of the warehouse.
"""

from agents.simulation_planner import _enclosures_are_perimeters


def _run(**overrides) -> dict:
    run = {
        "structure_id": "lin_drywall_walls",
        "semantic_type": "Drywall Walls",
        "thickness_m": 2.0,
        "source_text": "Defines the perimeter boundary of the simulation volume.",
        "from_m": [-20.0, -30.0],
        "to_m": [20.0, 30.0],
    }
    run.update(overrides)
    return {"linear_structures": [run]}


def test_a_perimeter_drawn_as_a_diagonal_becomes_four_edges() -> None:
    candidate = _run()
    _enclosures_are_perimeters(candidate)

    runs = candidate["linear_structures"]
    assert len(runs) == 4
    edges = {r["structure_id"]: (tuple(r["from_m"]), tuple(r["to_m"])) for r in runs}
    assert edges["lin_drywall_walls_north"] == ((-20.0, -30.0), (20.0, -30.0))
    assert edges["lin_drywall_walls_south"] == ((-20.0, 30.0), (20.0, 30.0))
    assert edges["lin_drywall_walls_west"] == ((-20.0, -30.0), (-20.0, 30.0))
    assert edges["lin_drywall_walls_east"] == ((20.0, -30.0), (20.0, 30.0))

    # Every edge keeps the wall it was: thickness, material and kind are not a detail the
    # rewrite is allowed to lose.
    assert all(r["thickness_m"] == 2.0 for r in runs)
    assert all(r["semantic_type"] == "Drywall Walls" for r in runs)

    # And the rewrite is recorded, not silent.
    assert any(
        a["requirement_id"] == "lin_drywall_walls"
        for a in candidate.get("approximations", [])
    )


def test_a_straight_wall_stays_one_wall() -> None:
    candidate = _run(from_m=[-20.0, -30.0], to_m=[20.0, -30.0])
    _enclosures_are_perimeters(candidate)
    assert [r["structure_id"] for r in candidate["linear_structures"]] == [
        "lin_drywall_walls"
    ]


def test_a_leaning_wall_is_not_a_perimeter() -> None:
    """40 m across and 4 m of lean is a wall on a slight angle, not an enclosure."""
    candidate = _run(from_m=[0.0, 0.0], to_m=[40.0, 4.0])
    _enclosures_are_perimeters(candidate)
    assert len(candidate["linear_structures"]) == 1


def test_a_diagonal_road_is_left_alone() -> None:
    """The rule keys on enclosure WORDS; a road crossing a field is a road."""
    candidate = _run(
        structure_id="lin_main_road",
        semantic_type="gravel road",
        source_text="A track running across the field.",
    )
    _enclosures_are_perimeters(candidate)
    assert len(candidate["linear_structures"]) == 1


def _edges() -> list[dict]:
    """The four walls a planner draws itself, on the edges of the same rectangle."""
    return [
        {"structure_id": "lin_wall_north", "semantic_type": "wall",
         "from_m": [-20.0, -30.0], "to_m": [20.0, -30.0]},
        {"structure_id": "lin_wall_south", "semantic_type": "wall",
         "from_m": [-20.0, 30.0], "to_m": [20.0, 30.0]},
        {"structure_id": "lin_wall_west", "semantic_type": "wall",
         "from_m": [-20.0, -30.0], "to_m": [-20.0, 30.0]},
        {"structure_id": "lin_wall_east", "semantic_type": "wall",
         "from_m": [20.0, -30.0], "to_m": [20.0, 30.0]},
    ]


def test_a_diagonal_over_walls_that_already_exist_is_dropped() -> None:
    """Two perimeters in one place is worse than the diagonal was.

    Measured: rebuilding the diagonal when the planner had ALSO authored
    `lin_wall_north/south/east/west` gave the warehouse 34 wall segments where 18
    belonged, and eight of them could not be placed at all. `_drop_umbrella_runs` cannot
    catch this pair -- `lin_wall_north` is not named after `lin_drywall_walls` -- so only
    the geometry can.
    """
    candidate = _run()
    candidate["linear_structures"].extend(_edges())
    _enclosures_are_perimeters(candidate)

    kept = [r["structure_id"] for r in candidate["linear_structures"]]
    assert kept == ["lin_wall_north", "lin_wall_south", "lin_wall_west", "lin_wall_east"]
    assert not any(k.startswith("lin_drywall_walls") for k in kept)


def test_one_wall_does_not_bound_an_area() -> None:
    """A single wall crossing a yard encloses nothing, so the perimeter is still built."""
    candidate = _run()
    candidate["linear_structures"].append(_edges()[0])
    _enclosures_are_perimeters(candidate)

    kept = [r["structure_id"] for r in candidate["linear_structures"]]
    assert sum(k.startswith("lin_drywall_walls_") for k in kept) == 4
