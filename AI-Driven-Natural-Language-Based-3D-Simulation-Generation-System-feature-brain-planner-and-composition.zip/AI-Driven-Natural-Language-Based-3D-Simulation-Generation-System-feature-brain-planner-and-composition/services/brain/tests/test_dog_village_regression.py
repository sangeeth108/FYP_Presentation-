from types import SimpleNamespace

from agents.composition_patterns import expand
from agents.simulation_planner import plan_simulation
from compatibility.simulation_game_adapter import compile_to_legacy_game


def test_dog_village_is_neutral_rigged_and_compositionally_interactive():
    settings = SimpleNamespace(
        llm_enabled=False,
        llm_base_url="",
        llm_timeout_seconds=1,
    )
    spec, source = plan_simulation(
        prompt="As a dog, explore a village with usable doors and navigable paths.",
        simulation_id="sim_dog_village_12345678",
        seed=42,
        size_profile="small",
        target_platforms=["web", "desktop"],
        domain_constraints={},
        settings=settings,
    )
    assert source == "deterministic_fallback"
    dog = next(item for item in spec["entities"] if item["role"] == "controlled_agent")
    assert dog["semantic_type"] == "dog"
    assert dog["asset"]["category"] == "character"
    assert dog["asset"]["requires_animation"] is True
    assert {"locomotion", "animal"}.issubset(dog["capabilities"])
    assert any(
        requirement["validator"] == "navigation_probe"
        for requirement in spec["requirements"]
    )

    legacy, approximations = compile_to_legacy_game(
        spec, "g3d_dog_village_12345678"
    )
    assert "rigged dog" in legacy["player"]["asset_brief"]["brief"]
    houses = [
        item
        for item in legacy["entities"]["objects"]
        if item["archetype"] == "building"
    ]
    assert houses
    for house in houses:
        composite = expand(house)
        assert composite is not None
        assert any(
            part["template_id"] == "door_hinged"
            for part in composite["parts"]
        )
    # The adapter may report missing runtime capability packs, but it must not
    # downgrade a building's usable door to visual-only geometry.
    assert all("openable" not in item["capabilities"] for item in approximations)
