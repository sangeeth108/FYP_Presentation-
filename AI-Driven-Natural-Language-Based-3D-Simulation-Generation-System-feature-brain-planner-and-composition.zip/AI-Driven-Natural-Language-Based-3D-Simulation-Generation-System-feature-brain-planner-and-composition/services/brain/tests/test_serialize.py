import json
from pathlib import Path

from pcg.pipeline import run_pcg
from pcg.serialize import LEVEL_PLAN_VERSION, to_level_plan, to_level_plan_json

GOLDEN_SPEC = (
    Path(__file__).resolve().parents[3] / "contracts" / "examples" / "golden_game.spec.json"
)


def _golden_plan():
    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    return spec, run_pcg(spec)


def test_level_plan_is_json_round_trippable_and_versioned():
    _, out = _golden_plan()
    plan = json.loads(to_level_plan_json(out))
    assert plan["level_plan_version"] == LEVEL_PLAN_VERSION
    assert plan["seed"] == out.graph.seed
    assert plan["algorithm"] == out.graph.algorithm


def test_level_plan_json_is_byte_stable():
    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    assert to_level_plan_json(run_pcg(spec)) == to_level_plan_json(run_pcg(spec))


def test_level_plan_internal_references_are_consistent():
    _, out = _golden_plan()
    plan = to_level_plan(out)
    zone_ids = {z["zone_id"] for z in plan["zones"]}
    assert {r["zone_id"] for r in plan["rooms"]} == zone_ids
    for corridor in plan["corridors"]:
        assert corridor["a"] in zone_ids
        assert corridor["b"] in zone_ids
        assert len(corridor["points"]) in (2, 3)
    for entity in plan["entities"]:
        assert entity["zone_id"] in zone_ids
    locked = [c for c in plan["corridors"] if c["kind"] == "locked"]
    assert len(locked) == 1  # the key-gated exit survives serialization
