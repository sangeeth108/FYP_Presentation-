"""A capability declared for the world must name the thing that performs it.

Regression for run_03bcc12ea42448818b0220c12ffd29d1, where `animal` was declared at the
top level and no entity claimed it. `capability_resolution` and `behavior_compilation`
both failed with `entity_id: null` -- there was no entity to name -- which failed two
mandatory gates and left six more unrun. The dog's mesh was rigged with 24 clips
throughout; only the spec was inconsistent.
"""

from agents.simulation_planner import _reconcile_capabilities


def _spec(top: list[str], entities: list[dict]) -> dict:
    return {"capabilities": list(top), "entities": entities}


def _actor(semantic_type: str, capabilities: list[str]) -> dict:
    return {
        "entity_id": "ent_controlled_actor",
        "role": "controlled_agent",
        "semantic_type": semantic_type,
        "capabilities": list(capabilities),
    }


def test_animal_attaches_to_the_creature_that_was_forgotten():
    spec = _spec(["animal", "locomotion"], [_actor("dog", ["locomotion"])])
    _reconcile_capabilities(spec)
    assert spec["capabilities"] == ["animal", "locomotion"]
    assert "animal" in spec["entities"][0]["capabilities"]


def test_the_head_noun_decides_so_a_compound_type_still_counts():
    # `village_dog` is the type the planner actually wrote in the failing run.
    spec = _spec(["animal"], [_actor("village_dog", [])])
    _reconcile_capabilities(spec)
    assert "animal" in spec["entities"][0]["capabilities"]


def test_a_modifier_does_not_make_a_prop_into_an_animal():
    # A kennel is not a dog, so `animal` has nobody to bind to and is withdrawn.
    spec = _spec(
        ["animal"],
        [{"entity_id": "ent_kennel", "role": "prop", "semantic_type": "dog_kennel"}],
    )
    _reconcile_capabilities(spec)
    assert spec["capabilities"] == []


def test_a_capability_nothing_can_perform_is_withdrawn_and_disclosed():
    spec = _spec(["animal"], [_actor("villager", ["locomotion"])])
    _reconcile_capabilities(spec)
    assert spec["capabilities"] == []
    reasons = [item["requirement_id"] for item in spec["approximations"]]
    assert "capability:animal" in reasons
    # Internal inconsistency, not a compromise the user needs told about.
    assert all(not item["user_visible"] for item in spec["approximations"])


def test_every_eligible_creature_gets_it_not_merely_the_first():
    spec = _spec(
        ["animal"],
        [
            _actor("dog", []),
            {"entity_id": "ent_cow", "role": "npc", "semantic_type": "dairy_cow"},
        ],
    )
    _reconcile_capabilities(spec)
    assert all("animal" in e["capabilities"] for e in spec["entities"])


def test_an_ambient_capability_is_left_alone():
    # `time_weather` and `camera_control` carry no qualification, so the registry never
    # asks who consumes them. Rebuilding the list from entities would wrongly drop them.
    spec = _spec(["time_weather", "camera_control"], [_actor("dog", [])])
    _reconcile_capabilities(spec)
    assert spec["capabilities"] == ["time_weather", "camera_control"]


def test_an_already_consistent_spec_is_untouched():
    spec = _spec(["animal"], [_actor("dog", ["animal"])])
    before = _spec(["animal"], [_actor("dog", ["animal"])])
    _reconcile_capabilities(spec)
    assert spec == before


def test_locomotion_binds_to_the_controlled_agent():
    spec = _spec(["locomotion"], [_actor("dog", [])])
    _reconcile_capabilities(spec)
    assert "locomotion" in spec["entities"][0]["capabilities"]
