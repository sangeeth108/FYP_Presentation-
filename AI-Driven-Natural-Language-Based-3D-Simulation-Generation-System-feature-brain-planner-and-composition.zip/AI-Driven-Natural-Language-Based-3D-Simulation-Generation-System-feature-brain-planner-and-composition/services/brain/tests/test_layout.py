import pcg.layout as layout_module
import pytest
from pcg.layout import generate_layout
from pcg.zone_graph import PCGError, generate_zone_graph


def test_same_seed_same_layout():
    g = generate_zone_graph(seed=4521, zone_count=7)
    a = generate_layout(g)
    b = generate_layout(g)
    assert a.rooms == b.rooms
    assert a.corridors == b.corridors


def test_no_overlaps_across_many_seeds_and_sizes():
    for seed in range(30):
        for zone_count in (3, 5, 12, 20):
            g = generate_zone_graph(seed=seed, zone_count=zone_count)
            layout = generate_layout(g)
            assert len(layout.rooms) == zone_count
            assert layout.has_no_overlaps()


def test_every_zone_has_a_room_and_every_edge_has_a_corridor():
    g = generate_zone_graph(seed=4521, zone_count=8, verticality_tiers=2)
    layout = generate_layout(g)
    assert set(layout.rooms.keys()) == {z.zone_id for z in g.zones}
    assert len(layout.corridors) == len(g.edges)
    corridor_pairs = {frozenset((c.a, c.b)) for c in layout.corridors}
    edge_pairs = {frozenset((e.a, e.b)) for e in g.edges}
    assert corridor_pairs == edge_pairs


def test_elevation_matches_tier():
    g = generate_zone_graph(seed=7, zone_count=10, verticality_tiers=3)
    layout = generate_layout(g)
    zones_by_id = {z.zone_id: z for z in g.zones}
    for zone_id, room in layout.rooms.items():
        assert room.elevation == zones_by_id[zone_id].tier * 1.5


def test_locked_corridor_matches_locked_edge():
    g = generate_zone_graph(seed=4521, zone_count=8)
    layout = generate_layout(g)
    locked_edges = {frozenset((e.a, e.b)) for e in g.edges if e.kind == "locked"}
    locked_corridors = {frozenset((c.a, c.b)) for c in layout.corridors if c.kind == "locked"}
    assert locked_edges == locked_corridors
    assert len(locked_edges) == 1  # exactly the entry->exit lock


def test_layout_fails_gracefully_when_placement_budget_is_exhausted(monkeypatch):
    monkeypatch.setattr(layout_module, "MAX_PLACEMENT_ATTEMPTS", 0)
    g = generate_zone_graph(seed=1, zone_count=5)
    with pytest.raises(PCGError) as exc:
        generate_layout(g)
    assert exc.value.code == "layout_placement_failed"
    assert exc.value.hint
