"""Entities and requirements are made to agree, with the PROMPT as the arbiter.

Measured across a 12-prompt corpus, once the oversized-mesh defect is accounted for, the
remaining failures are the planner contradicting its own document: four entities nothing
required, three requirements about nothing.

Both are paperwork rather than content, and both are repairable without inventing
anything -- provided the prompt decides what is real. That condition is what stops this
becoming the tautology the `part_of` work warned about: a rule deriving requirements from
entities can never fail to cover entities, which would turn a live gate into a rubber
stamp.
"""

from __future__ import annotations

from agents.simulation_planner import _reconcile_entities_and_requirements

PROMPT = (
    "As a baker, I inspect my morning workspace containing a large flour sack, "
    "a wooden kneading table, a ceramic mixing bowl, and a cast-iron oven door."
)


def _requirement(requirement_id: str, subject: str, source: str) -> dict:
    return {
        "requirement_id": requirement_id,
        "source_text": source,
        "subject": subject,
        "predicate": "exists",
        "target": "x",
        "priority": "required",
        "observable": "o",
        "validator": "asset_and_runtime",
    }


def _spec() -> dict:
    return {
        "request": {"prompt": PROMPT},
        "entities": [
            {"entity_id": "ent_flour_sack", "semantic_type": "flour_sack", "name": "Flour sack"},
            {"entity_id": "ent_barbecue", "semantic_type": "barbecue", "name": "Barbecue"},
            {"entity_id": "ent_mixing_bowl", "semantic_type": "mixing_bowl", "name": "Bowl"},
        ],
        "requirements": [
            _requirement("req_bowl", "ent_mixing_bowl", "a ceramic mixing bowl"),
            _requirement("req_oven_door", "ent_oven_door", "a cast-iron oven door"),
            _requirement("req_ghost", "ent_chandelier", "a chandelier"),
        ],
        "spatial_relations": [],
    }


def _subjects(spec: dict) -> set[str]:
    return {item["subject"] for item in spec["requirements"]}


def test_a_built_thing_the_prompt_names_gets_the_record_it_was_missing():
    """The world is right and only the paperwork is absent, so the paperwork is written
    -- from the prompt's own words, so it survives the verbatim source check."""
    spec = _spec()
    _reconcile_entities_and_requirements(spec)

    assert "ent_flour_sack" in _subjects(spec)
    written = next(r for r in spec["requirements"] if r["subject"] == "ent_flour_sack")
    assert written["source_text"] in PROMPT, "source_text must be quotable from the prompt"
    assert written["predicate"] == "exists"


def test_an_invented_thing_is_left_for_the_gate_to_catch():
    """This is the whole reason the prompt is the arbiter.

    A barbecue nobody asked for has no verbatim source, so no requirement can be written
    for it and `ENTITY_PRESENCE_REQUIREMENT_MISSING` still fires. Covering it would make
    the gate unable to fail.
    """
    spec = _spec()
    _reconcile_entities_and_requirements(spec)
    assert "ent_barbecue" not in _subjects(spec)


def test_a_promise_the_prompt_made_is_left_failing_rather_than_deleted():
    """The prompt asked for an oven door, the planner promised one and built none.

    The world is genuinely incomplete. Dropping the requirement would delete a thing
    somebody asked for and turn a real omission into a green run, so it is kept and the
    gate is allowed to object.
    """
    spec = _spec()
    _reconcile_entities_and_requirements(spec)
    assert "ent_oven_door" in _subjects(spec)


def test_a_requirement_about_nothing_at_all_is_dropped_and_disclosed():
    """Not in the spec and not in the prompt: there was never anything there, so nothing
    is lost by removing it -- and the removal is recorded rather than silent."""
    spec = _spec()
    _reconcile_entities_and_requirements(spec)
    assert "ent_chandelier" not in _subjects(spec)
    assert any(
        "never mentions" in note["reason"] for note in spec.get("approximations", [])
    )


def test_a_part_of_a_covered_thing_needs_no_record_of_its_own():
    """One described thing built as several. A wall's segments trace through `part_of`,
    so writing a requirement per segment would undo that work and re-create the
    verbatim-source collision it was added to solve."""
    spec = _spec()
    spec["entities"].append(
        {"entity_id": "ent_mixing_bowl_lid", "semantic_type": "bowl_lid", "name": "Lid"}
    )
    spec["spatial_relations"].append(
        {
            "subject_id": "ent_mixing_bowl_lid",
            "target_id": "ent_mixing_bowl",
            "relation": "part_of",
            "hard": False,
        }
    )
    _reconcile_entities_and_requirements(spec)
    assert "ent_mixing_bowl_lid" not in _subjects(spec)


def test_no_prompt_means_no_reconciliation():
    """Without the arbiter there is no safe judgement to make, so nothing is changed."""
    spec = _spec()
    spec["request"] = {}
    before = len(spec["requirements"])
    _reconcile_entities_and_requirements(spec)
    assert len(spec["requirements"]) == before
