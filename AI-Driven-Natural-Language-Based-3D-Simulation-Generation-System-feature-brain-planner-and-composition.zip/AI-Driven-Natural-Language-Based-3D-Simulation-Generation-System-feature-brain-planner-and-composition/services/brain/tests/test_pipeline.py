import json
from pathlib import Path

from pcg.pipeline import run_pcg

GOLDEN_SPEC = (
    Path(__file__).resolve().parents[3] / "contracts" / "examples" / "golden_game.spec.json"
)


def _load_golden_spec():
    return json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))


def test_golden_game_spec_drives_full_s4_pipeline():
    spec = _load_golden_spec()
    out = run_pcg(spec)

    assert len(out.graph.zones) == spec["world"]["zone_graph"]["zone_count"]
    assert out.graph.is_connected()
    assert out.layout.has_no_overlaps()

    enemies = [e for e in out.placement.entities if e.kind == "enemy"]
    props = [e for e in out.placement.entities if e.kind == "prop"]
    assert len(enemies) == sum(e["count"] for e in spec["entities"]["enemies"])
    assert len(props) == len(spec["entities"]["props"])


def test_pipeline_is_deterministic_end_to_end():
    spec = _load_golden_spec()
    a = run_pcg(spec)
    b = run_pcg(spec)
    assert a.graph.zones == b.graph.zones
    assert a.graph.edges == b.graph.edges
    assert a.layout.rooms == b.layout.rooms
    assert a.placement.entities == b.placement.entities
