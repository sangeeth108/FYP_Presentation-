"""The lineage gate must refuse a spec the planning model did not author.

A real run asked for "a small village with two houses ... and a dog wandering
between them". The planner call timed out, the pipeline substituted its built-in
draft, and the result -- a stock four-house village with a public square, no dog
and a generic "visitor" as the player -- passed 13 of the 15 gates. The fallback
is internally consistent, so every structural check is satisfied by it; the only
gate that objected was the vision critic, which is also the one gate allowed to
report UNAVAILABLE. Nothing read the `deterministic_fallback_v1` marker the
planner had written into lineage.
"""

from __future__ import annotations

from core.validation_contract import MANDATORY_PREPUBLICATION_LAYERS


def _lineage_report(planner_marker: str) -> dict:
    """The gate's decision, isolated from the rest of the native pipeline."""
    errors: list[dict] = []
    if planner_marker.startswith("deterministic_fallback"):
        errors.append(
            {
                "code": "SPEC_NOT_MODEL_AUTHORED",
                "path": "lineage.planner",
                "message": "built-in fallback, not this prompt",
                "hint": "check the planner model and llm_timeout_seconds",
            }
        )
    return {"status": "FAIL" if errors else "PASS", "errors": errors}


def test_a_fallback_authored_spec_fails_lineage():
    report = _lineage_report("deterministic_fallback_v1")
    assert report["status"] == "FAIL"
    assert [error["code"] for error in report["errors"]] == ["SPEC_NOT_MODEL_AUTHORED"]


def test_a_model_authored_spec_passes_lineage():
    assert _lineage_report("qwen3.6:27b")["status"] == "PASS"


def test_lineage_blocks_publication():
    """A failing lineage has to actually stop the artifact shipping."""
    assert "lineage" in MANDATORY_PREPUBLICATION_LAYERS


def test_the_pipeline_wires_the_marker_into_the_gate():
    """Guards the wiring, not just the logic: the gate must read the real field."""
    import inspect

    from worker import native_pipeline

    source = inspect.getsource(native_pipeline)
    assert "SPEC_NOT_MODEL_AUTHORED" in source
    assert 'lineage") or {}).get("planner"' in source


def test_the_planner_still_marks_its_fallback():
    """If the marker is ever renamed, the gate above silently stops working."""
    import inspect

    from agents import simulation_planner

    assert '"deterministic_fallback_v1"' in inspect.getsource(simulation_planner)
