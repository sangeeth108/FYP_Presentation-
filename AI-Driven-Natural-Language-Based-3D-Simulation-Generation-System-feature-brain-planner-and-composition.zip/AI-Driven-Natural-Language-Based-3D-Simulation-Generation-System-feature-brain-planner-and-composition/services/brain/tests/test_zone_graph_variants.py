"""cellular_caves + wfc_dressing: invariants, distinctness, integration."""

from pcg.layout import generate_layout
from pcg.placement import EnemySpec, PropSpec, generate_placement
from pcg.zone_graph import WFC_INCOMPATIBLE, generate_zone_graph


def _lock_and_key_ok(g):
    kinds = {z.zone_id: z.kind for z in g.zones}
    assert list(kinds.values()).count("entry") == 1
    assert list(kinds.values()).count("exit") == 1
    assert list(kinds.values()).count("key") == 1
    exit_id = next(zid for zid, k in kinds.items() if k == "exit")
    exit_edges = [e for e in g.edges if exit_id in (e.a, e.b)]
    assert len(exit_edges) == 1
    assert exit_edges[0].kind == "locked"
    neighbor = exit_edges[0].a if exit_edges[0].b == exit_id else exit_edges[0].b
    assert kinds[neighbor] == "key"


def test_caves_determinism_connectivity_and_lock():
    a = generate_zone_graph(seed=4521, zone_count=10, algorithm="cellular_caves")
    b = generate_zone_graph(seed=4521, zone_count=10, algorithm="cellular_caves")
    assert (a.zones, a.edges) == (b.zones, b.edges)
    for seed in range(25):
        for zone_count in (3, 6, 12, 20):
            g = generate_zone_graph(seed=seed, zone_count=zone_count, algorithm="cellular_caves")
            assert g.is_connected()
            _lock_and_key_ok(g)


def test_caves_are_loopier_than_corridors():
    total_cave = total_chain = 0
    for seed in range(20):
        total_cave += len(
            generate_zone_graph(seed=seed, zone_count=12, algorithm="cellular_caves").edges
        )
        total_chain += len(
            generate_zone_graph(seed=seed, zone_count=12, algorithm="room_corridor").edges
        )
    assert total_cave > total_chain  # the warren feel is structural, not cosmetic


def test_wfc_determinism_connectivity_and_lock():
    a = generate_zone_graph(seed=4521, zone_count=10, algorithm="wfc_dressing")
    b = generate_zone_graph(seed=4521, zone_count=10, algorithm="wfc_dressing")
    assert (a.zones, a.edges) == (b.zones, b.edges)
    for seed in range(25):
        for zone_count in (3, 6, 12, 20):
            g = generate_zone_graph(seed=seed, zone_count=zone_count, algorithm="wfc_dressing")
            assert g.is_connected()
            _lock_and_key_ok(g)


def test_wfc_adjacency_constraints_hold():
    violations = 0
    for seed in range(25):
        g = generate_zone_graph(seed=seed, zone_count=14, algorithm="wfc_dressing")
        kinds = {z.zone_id: z.kind for z in g.zones}
        for e in g.edges:
            if frozenset((kinds[e.a], kinds[e.b])) in WFC_INCOMPATIBLE:
                violations += 1
    # WFC without backtracking can rarely hit contradictions (fallback kind);
    # the constraint must hold in the overwhelming majority of adjacencies.
    assert violations <= 2


def test_both_variants_drive_layout_and_placement():
    enemies = [EnemySpec(enemy_id="guard", count=6)]
    props = [PropSpec(prop_id="chest", placement_tags=("loot",))]
    for algorithm in ("cellular_caves", "wfc_dressing"):
        for seed in range(10):
            g = generate_zone_graph(seed=seed, zone_count=10, algorithm=algorithm)
            layout = generate_layout(g)
            assert layout.has_no_overlaps()
            result = generate_placement(g, layout, enemies, props)
            assert len(result.entities) == 7
