"""Registries = the allowlist. Invented ids are impossible; and the registry
may never drift from what the engine actually implements."""

import json
import sys
from pathlib import Path

from knowledge.registries import registry, script_templates, unknown_ids

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO / "services" / "worker"))
GOLDEN = json.loads(
    (REPO / "contracts" / "examples" / "golden_game.spec.json").read_text(encoding="utf-8")
)


def test_registry_is_scanned_from_the_real_templates():
    scripts = script_templates()
    assert scripts["controllers"] == {
        "controller_third_person",
        "controller_topdown_3d",
        "controller_isometric_3d",
    }
    assert "ai_patrol_chase" in scripts["ai"]
    assert "reach_zone" in scripts["objectives"]
    assert "door_hinged" in scripts["interactables"]


def test_the_golden_spec_only_uses_vetted_ids():
    # The canonical example must never promise mechanics the engine lacks.
    assert unknown_ids(GOLDEN) == []


def test_invented_ids_are_caught_with_machine_readable_errors():
    spec = json.loads(json.dumps(GOLDEN))
    spec["player"]["controller_template_id"] = "controller_hover_bike"
    errors = unknown_ids(spec)
    assert len(errors) == 1
    error = errors[0]
    assert error["code"] == "TEMPLATE_ID_NOT_IN_REGISTRY"
    assert error["path"] == "$.player.controller_template_id"
    assert error["failure_class"] == "schema"
    assert "controller_third_person" in error["hint"]  # tells you what IS allowed


def test_unimplemented_categories_reject_everything():
    # No combat template exists yet — declaring one is a lie, so it fails.
    spec = json.loads(json.dumps(GOLDEN))
    spec["entities"]["enemies"][0]["combat_template_id"] = "combat_melee_basic"
    errors = unknown_ids(spec)
    assert any(e["path"].endswith("combat_template_id") for e in errors)


# --- drift guards: the registry must match the worker's real implementations ---


def test_lighting_presets_match_the_worker_implementations():
    from godot_client.lighting import LIGHTING_PRESETS as implemented

    assert set(registry()["lighting_preset_id"]) == set(implemented)


def test_controllers_match_what_the_project_writer_can_emit():
    from godot_client.project_writer import CONTROLLER_EXT_IDS

    assert set(registry()["controller_template_id"]) == set(CONTROLLER_EXT_IDS)


def test_interactables_match_what_the_asset_kit_honors():
    from godot_client.asset_kit import FUNCTIONAL_PROPS, PROP_MODELS

    honored = set(PROP_MODELS) | set(FUNCTIONAL_PROPS)
    assert set(registry()["interactable_template_id"]) == honored
