"""Canonical bounds-aware placement and independent validation."""

from __future__ import annotations

import math

import pytest
from agents.simulation_planner import apply_localized_edit
from pcg.semantic import (
    _aabb,
    generate_semantic_world_plan,
    validate_semantic_world_plan,
)

from tests.test_simulation_core import _dog_village


def _measured_descriptors(spec: dict) -> dict[str, dict]:
    return {
        entity["entity_id"]: {
            "asset_ref": f"test:{entity['entity_id']}",
            "measurement": {"status": "MEASURED"},
            "world_dimensions_m": entity["physical"]["bbox_m"],
            "normalization_scale": [1.0, 1.0, 1.0],
            "interaction": {
                "clearance_m": 1.5 if entity["capabilities"] else 0.25
            },
        }
        for entity in spec["entities"]
    }


def test_semantic_plan_is_seed_deterministic_and_schema_valid():
    spec = _dog_village()
    descriptors = _measured_descriptors(spec)
    first = generate_semantic_world_plan(spec, descriptors)
    second = generate_semantic_world_plan(spec, descriptors)
    assert first == second
    assert validate_semantic_world_plan(first)["status"] == "PASS"


def test_world_plan_uses_measured_bounds_not_planner_declarations():
    spec = _dog_village()
    descriptors = _measured_descriptors(spec)
    actor_id = "ent_controlled_actor"
    descriptors[actor_id]["world_dimensions_m"] = [1.6, 1.0, 2.4]
    plan = generate_semantic_world_plan(spec, descriptors)
    actor = next(item for item in plan["entities"] if item["entity_id"] == actor_id)
    assert actor["dimensions_m"] == [1.6, 1.0, 2.4]
    yaw = math.radians(actor["transform"]["rotation_y_degrees"])
    expected_x = abs(math.cos(yaw)) * 1.6 + abs(math.sin(yaw)) * 2.4
    assert actor["world_aabb"]["max"][0] - actor["world_aabb"]["min"][0] == pytest.approx(
        expected_x, abs=2e-4
    )


def test_attached_doors_keep_parent_local_transform_and_do_not_replace_houses():
    spec = _dog_village()
    plan = generate_semantic_world_plan(spec, _measured_descriptors(spec))
    placed = {item["entity_id"]: item for item in plan["entities"]}
    for index in range(1, 5):
        house = placed[f"ent_house_{index}"]
        door = placed[f"ent_house_{index}_door"]
        assert door["parent_id"] == house["entity_id"]
        assert door["semantic_type"] == "hinged_wooden_door"
        assert door["transform"]["rotation_y_degrees"] == pytest.approx(
            house["transform"]["rotation_y_degrees"]
        )
        assert door["support"]["target_id"] == house["entity_id"]


def test_declared_dimensions_cannot_satisfy_the_production_measurement_gate():
    plan = generate_semantic_world_plan(_dog_village())
    report = validate_semantic_world_plan(plan, require_measured_assets=True)
    assert report["status"] == "NOT_RUN"
    assert {error["code"] for error in report["errors"]} == {"ASSET_NOT_MEASURED"}


def test_soft_near_relations_are_real_distances():
    spec = _dog_village()
    plan = generate_semantic_world_plan(spec, _measured_descriptors(spec))
    positions = {
        item["entity_id"]: item["transform"]["position_m"] for item in plan["entities"]
    }
    square = positions["ent_village_square"]
    for index in range(1, 5):
        house = positions[f"ent_house_{index}"]
        assert math.hypot(house[0] - square[0], house[2] - square[2]) <= 35.0


def test_village_doors_have_explicit_clear_paths_to_square():
    spec = _dog_village()
    plan = generate_semantic_world_plan(spec, _measured_descriptors(spec))
    paths = plan["navigation"]["paths"]
    assert len(paths) == 4
    assert all(path["status"] == "CONNECTED" for path in paths)
    assert {path["from_entity_id"] for path in paths} == {
        f"ent_house_{index}_door" for index in range(1, 5)
    }
    assert {path["to_entity_id"] for path in paths} == {"ent_village_square"}
    assert validate_semantic_world_plan(plan)["status"] == "PASS"


def test_environment_only_edit_preserves_every_transform():
    original = _dog_village()
    edited, _, _ = apply_localized_edit(original, "make it rainy at night")
    descriptors = _measured_descriptors(original)
    before = generate_semantic_world_plan(original, descriptors)
    after = generate_semantic_world_plan(edited, descriptors)
    assert {
        item["entity_id"]: item["transform"] for item in before["entities"]
    } == {
        item["entity_id"]: item["transform"] for item in after["entities"]
    }


def test_localized_addition_re_solves_only_the_added_entity():
    original = _dog_village()
    descriptors = _measured_descriptors(original)
    before = generate_semantic_world_plan(original, descriptors)
    edited, changes, _ = apply_localized_edit(original, "add a water bowl")
    edited_descriptors = _measured_descriptors(edited)
    affected = {
        path.split(".", 1)[1]
        for path in changes
        if path.startswith("entities.")
    }
    after = generate_semantic_world_plan(
        edited,
        edited_descriptors,
        preserved_plan=before,
        affected_entity_ids=affected,
    )
    before_transforms = {
        item["entity_id"]: item["transform"] for item in before["entities"]
    }
    after_transforms = {
        item["entity_id"]: item["transform"] for item in after["entities"]
    }
    assert set(after_transforms) - set(before_transforms) == affected
    assert all(
        after_transforms[entity_id] == transform
        for entity_id, transform in before_transforms.items()
    )


def test_impossible_hard_constraints_fail_without_silent_dropping():
    spec = _dog_village()
    descriptors = _measured_descriptors(spec)
    descriptors["ent_controlled_actor"]["world_dimensions_m"] = [600.0, 2.0, 600.0]
    plan = generate_semantic_world_plan(spec, descriptors)
    report = validate_semantic_world_plan(plan, require_measured_assets=False)
    assert report["status"] == "FAIL"
    assert "ent_controlled_actor" in plan["constraint_summary"]["unplaced_entities"]
    assert any(error["code"] == "ENTITY_UNPLACED" for error in report["errors"])


def test_placement_ranker_only_reorders_hard_valid_candidates_deterministically():
    class PreferLaterCandidate:
        def score(self, features):
            return features["candidate_index"]

    spec = _dog_village()
    descriptors = _measured_descriptors(spec)
    unranked = generate_semantic_world_plan(spec, descriptors)
    ranked_a = generate_semantic_world_plan(
        spec, descriptors, placement_ranker=PreferLaterCandidate()
    )
    ranked_b = generate_semantic_world_plan(
        spec, descriptors, placement_ranker=PreferLaterCandidate()
    )
    assert ranked_a == ranked_b
    assert ranked_a != unranked
    assert validate_semantic_world_plan(ranked_a)["status"] == "PASS"


def test_a_world_is_raised_to_contain_its_tallest_object():
    """A ceiling lower than the content cannot hold it, so height grows.

    Measured: a tea plantation declared a 12 m hillside and a 20 m colonial
    factory in the same specification. Nothing in the schema links the two
    fields, and placement failed with `unplaced_entities` -- correct, but
    reported as an unsolved constraint rather than the contradiction it was.

    Width and depth are a stage the content sits on and are only ever reduced;
    height is a ceiling it sits under, so the asymmetry is deliberate.
    """
    from pcg.semantic import generate_semantic_world_plan

    spec = {
        "schema_version": "1.0.0",
        "meta": {"simulation_id": "sim_tall_thing_0a1b2c3d", "title": "Tall", "seed": 7},
        "environment": {
            "semantic_type": "hillside",
            "dimensions_m": {"width": 200.0, "depth": 200.0, "max_height": 12.0},
            "zones": [
                {
                    "zone_id": "main",
                    "semantic_type": "slope",
                    "purpose": "explore",
                    "connected_to": [],
                }
            ],
        },
        "entities": [
            {
                "entity_id": "ent_factory",
                "name": "Factory",
                "semantic_type": "colonial_factory",
                "role": "structure",
                "asset": {
                    "brief": "a rusted factory",
                    "category": "structure",
                    "requires_animation": False,
                    "preferred_source": "procedural",
                    "procedural_type": "building_shell",
                },
                "physical": {"bbox_m": [40.0, 20.0, 12.0], "dynamic": False, "mass_kg": 0.0},
                "capabilities": [],
                "placement": {
                    "zone": "main",
                    "hard_constraints": ["inside_zone", "non_overlapping", "supported"],
                    "soft_constraints": [],
                },
            }
        ],
        "agents": [],
        "spatial_relations": [],
        "requirements": [],
    }
    plan = generate_semantic_world_plan(spec)

    ceiling = plan["world_bounds"]["max"][1]
    assert ceiling >= 20.0, "the world must be at least as tall as its tallest object"
    assert plan["constraint_summary"]["unplaced_entities"] == []


def test_a_world_taller_than_its_content_is_left_alone():
    """Only raised when the content demands it; a declared vista stays a vista."""
    from pcg.semantic import _content_scaled_dimensions

    spec = {
        "environment": {"dimensions_m": {"width": 100.0, "depth": 100.0, "max_height": 80.0}},
        "entities": [
            {"physical": {"bbox_m": [2.0, 3.0, 2.0]}},
        ],
    }
    _, _, height = _content_scaled_dimensions(spec)
    assert height == 80.0


def test_a_world_too_small_for_its_content_is_grown_to_fit():
    """Shrinking toward the content is right; shrinking below it is not.

    Measured on a live run: a village of two 4 m houses was declared 8 m square
    -- legal once the contract floor was lowered to admit corridors and
    galleries -- and because the extent could only ever be reduced, nothing
    could grow it back. All eight entities went unplaced and the world came out
    empty.
    """
    from pcg.semantic import _content_scaled_dimensions

    spec = {
        "environment": {"dimensions_m": {"width": 8.0, "depth": 8.0, "max_height": 3.0}},
        "entities": [
            {"physical": {"bbox_m": [4.0, 3.0, 4.0]}},
            {"physical": {"bbox_m": [4.0, 3.0, 4.0]}},
            {"physical": {"bbox_m": [0.8, 1.2, 1.4]}},
        ],
    }
    width, depth, _ = _content_scaled_dimensions(spec)
    assert width > 8.0 and depth > 8.0, "a world must be able to hold its content"
    # Two 4 m houses need appreciably more than one house-width of room.
    assert width >= 6.4


def test_an_oversized_world_is_still_brought_in_to_its_content():
    """The anti-inflation behaviour that motivated right-sizing must survive."""
    from pcg.semantic import _content_scaled_dimensions

    spec = {
        "environment": {"dimensions_m": {"width": 500.0, "depth": 500.0, "max_height": 80.0}},
        "entities": [{"physical": {"bbox_m": [2.0, 2.0, 2.0]}} for _ in range(3)],
    }
    width, depth, _ = _content_scaled_dimensions(spec)
    assert width < 500.0 and depth < 500.0
    assert width <= 60.0, "a handful of small objects must not keep a 500 m world"


def test_a_genuinely_small_world_stays_small():
    """A corridor is allowed to be a corridor; growth is only to fit content."""
    from pcg.semantic import _content_scaled_dimensions

    spec = {
        "environment": {"dimensions_m": {"width": 8.0, "depth": 20.0, "max_height": 2.7}},
        "entities": [{"physical": {"bbox_m": [0.9, 0.7, 2.0]}}],
    }
    width, _, _ = _content_scaled_dimensions(spec)
    assert width <= 8.0, "one small bed must not inflate a narrow corridor"


def _two_house_village() -> dict:
    """A courtyard declared far too small for what the planner put in it."""
    def entity(entity_id, category, bbox, semantic="thing"):
        return {
            "entity_id": entity_id,
            "semantic_type": semantic,
            "asset": {"category": category, "asset_ref": f"ref_{entity_id}"},
            "physical": {"bbox_m": bbox, "dynamic": False, "mass_kg": 10.0},
            "capabilities": [],
            "placement": {
                "zone": "main",
                "hard_constraints": ["inside_zone", "non_overlapping_with_clearance"],
                "soft_preferences": [],
            },
        }

    return {
        "meta": {"simulation_id": "sim_two_house_village", "seed": 4242},
        "environment": {
            "dimensions_m": {"width": 8.0, "depth": 8.0, "max_height": 3.0},
            "zones": [{"zone_id": "main", "semantic_type": "main", "connected_to": []}],
        },
        "entities": [
            entity("ent_house_a", "structure", [4.0, 3.0, 4.0], "house"),
            entity("ent_house_b", "structure", [4.0, 3.0, 4.0], "house"),
            entity("ent_door_a", "prop", [0.9, 2.1, 0.1], "door"),
            entity("ent_post", "prop", [0.1, 1.2, 0.1], "fence_post"),
            entity("ent_actor", "character", [0.8, 1.2, 1.4], "dog"),
        ],
        "spatial_relations": [
            {
                "subject_id": "ent_door_a",
                "relation": "attached_to",
                "target_id": "ent_house_a",
                "hard": True,
                # Measured from the house's TOP rather than its centre, which is
                # what a planner writes when the contract does not say.
                "local_offset_m": [0.0, -1.9, -2.0],
                "local_rotation_y_degrees": 0.0,
            },
            {
                "subject_id": "ent_post",
                "relation": "near",
                "target_id": "ent_house_a",
                "hard": False,
                "distance_m": 1.5,
            },
            {
                "subject_id": "ent_actor",
                "relation": "near",
                "target_id": "ent_door_a",
                "hard": False,
                "distance_m": 3.0,
            },
        ],
    }


def test_a_world_too_small_for_its_content_is_grown_until_everything_places():
    """The whole point: an under-declared world must not silently lose its content."""
    spec = _two_house_village()
    plan = generate_semantic_world_plan(spec)
    assert plan["constraint_summary"]["unplaced_entities"] == []
    assert len(plan["entities"]) == len(spec["entities"])


def test_the_placeable_zone_never_vanishes_inside_a_small_world():
    """A 5 m border on each side used to leave a small world with none."""
    from pcg.semantic import _zone_geometry

    spec = _two_house_village()
    spec["environment"]["dimensions_m"] = {"width": 8.0, "depth": 8.0, "max_height": 3.0}
    bounds = _zone_geometry(spec)[0]["bounds"]
    width = bounds["max"][0] - bounds["min"][0]
    depth = bounds["max"][2] - bounds["min"][2]
    assert width > 0 and depth > 0, "the border consumed the world it borders"


def test_an_attachment_offset_below_ground_is_lifted_not_dropped():
    """`local_offset_m` had no stated origin; a door read from the wrong one sank."""
    spec = _two_house_village()
    plan = generate_semantic_world_plan(spec)
    door = next(e for e in plan["entities"] if e["entity_id"] == "ent_door_a")
    assert door["world_aabb"]["min"][1] >= -1e-6, "the door is underground"
    assert any(
        item["entity_id"] == "ent_door_a"
        and item["constraint"] == "attachment_offset_y"
        for item in plan["constraint_summary"]["soft_relaxations"]
    ), "a correction this large must be recorded, not silent"


def test_an_attached_child_is_placed_directly_after_its_parent():
    """Category order alone let free props take the ground a rigid child needed."""
    from pcg.semantic import _placement_order

    order = [e["entity_id"] for e in _placement_order(_two_house_village())]
    assert order.index("ent_door_a") == order.index("ent_house_a") + 1


def test_an_unsatisfiable_soft_near_yields_instead_of_failing_the_entity():
    """A soft preference is a preference: the player must still get placed."""
    spec = _two_house_village()
    plan = generate_semantic_world_plan(spec)
    assert "ent_actor" not in plan["constraint_summary"]["unplaced_entities"]
    assert "ent_post" not in plan["constraint_summary"]["unplaced_entities"]


def test_a_hard_near_relation_is_never_quietly_relaxed():
    """Only SOFT preferences yield; a hard one must still fail loudly."""
    spec = _two_house_village()
    for relation in spec["spatial_relations"]:
        if relation["subject_id"] == "ent_actor":
            relation["hard"] = True
            relation["distance_m"] = 0.05
    plan = generate_semantic_world_plan(spec)
    relaxed = {
        item["entity_id"]
        for item in plan["constraint_summary"]["soft_relaxations"]
        if item["constraint"] == "near"
    }
    assert "ent_actor" not in relaxed


def test_a_rotated_building_does_not_claim_the_ground_beside_its_own_wall():
    """AABBs over-claim when rotated; adjacency must use the true footprint."""
    from pcg.semantic import _overlaps, _overlaps_oriented

    # A 12 x 3 m house turned 15 degrees: its axis-aligned box is 12.4 x 6.1 m,
    # so a doorstep against the long wall falls inside the box but not the house.
    house_position = [0.0, 4.0, 0.0]
    house = {
        "transform": {"position_m": house_position, "rotation_y_degrees": 15.0},
        "dimensions_m": [12.0, 8.0, 3.0],
        "world_aabb": _aabb(house_position, [12.0, 8.0, 3.0], 15.0),
    }
    stoop_position = [0.0, 0.45, -2.4]
    stoop_dimensions = [1.5, 0.9, 0.3]

    assert _overlaps(
        _aabb(stoop_position, stoop_dimensions, 15.0), house["world_aabb"]
    ), "the axis-aligned test is expected to over-claim here"
    assert not _overlaps_oriented(
        stoop_position, stoop_dimensions, 15.0, house
    ), "the doorstep is beside the wall, not inside the house"


def test_an_explicit_hard_adjacency_survives_a_rotated_neighbour():
    """Both stoops of a two-house village failed this way in a real run."""
    spec = _two_house_village()
    spec["entities"].append(
        {
            "entity_id": "ent_stoop",
            "semantic_type": "stoop",
            "asset": {"category": "prop", "asset_ref": "ref_stoop"},
            "physical": {"bbox_m": [1.5, 0.9, 0.3], "dynamic": False, "mass_kg": 40.0},
            "capabilities": [],
            "placement": {
                "zone": "main",
                "hard_constraints": ["inside_zone", "non_overlapping_with_clearance"],
                "soft_preferences": [],
            },
        }
    )
    spec["spatial_relations"].append(
        {
            "subject_id": "ent_stoop",
            "relation": "near",
            "target_id": "ent_door_a",
            "hard": True,
            "distance_m": 0.5,
        }
    )
    plan = generate_semantic_world_plan(spec)
    assert "ent_stoop" not in plan["constraint_summary"]["unplaced_entities"]


def test_an_attachment_that_does_not_reach_its_parent_is_pulled_flush():
    """A door attached 4.06 m from a 3 m deep house floated clear of the wall."""
    spec = _two_house_village()
    relation = next(
        item for item in spec["spatial_relations"] if item["subject_id"] == "ent_door_a"
    )
    relation["local_offset_m"] = [0.0, -1.9, -4.06]  # house is only 4 m deep
    plan = generate_semantic_world_plan(spec)

    assert "ent_door_a" not in plan["constraint_summary"]["unplaced_entities"]
    door = next(e for e in plan["entities"] if e["entity_id"] == "ent_door_a")
    house = next(e for e in plan["entities"] if e["entity_id"] == "ent_house_a")
    gap = math.dist(
        (door["transform"]["position_m"][0], door["transform"]["position_m"][2]),
        (house["transform"]["position_m"][0], house["transform"]["position_m"][2]),
    )
    # Flush against the 4 m deep house is ~2.05 m from its centre, not 4.06.
    assert gap < 3.0, "the door is still floating clear of the house"
    assert any(
        item["entity_id"] == "ent_door_a"
        and item["constraint"] == "attachment_offset"
        for item in plan["constraint_summary"]["soft_relaxations"]
    ), "moving an attachment must be recorded"


def test_an_attachment_pointing_into_its_own_assembly_is_mirrored_outward():
    """A stoop offset +0.5 along an axis whose outward direction is negative."""
    spec = _two_house_village()
    spec["entities"].append(
        {
            "entity_id": "ent_stoop",
            "semantic_type": "stoop",
            "asset": {"category": "prop", "asset_ref": "ref_stoop"},
            "physical": {"bbox_m": [1.5, 0.9, 0.3], "dynamic": False, "mass_kg": 40.0},
            "capabilities": [],
            "placement": {
                "zone": "main",
                "hard_constraints": ["inside_zone", "non_overlapping_with_clearance"],
                "soft_preferences": [],
            },
        }
    )
    spec["spatial_relations"].append(
        {
            "subject_id": "ent_stoop",
            "relation": "attached_to",
            "target_id": "ent_door_a",
            "hard": True,
            "local_offset_m": [0.0, -1.0, 0.5],  # +z points back into the house
            "local_rotation_y_degrees": 0.0,
        }
    )
    plan = generate_semantic_world_plan(spec)
    assert "ent_stoop" not in plan["constraint_summary"]["unplaced_entities"]


def test_content_is_composed_tightly_rather_than_scattered():
    """A small village must read as one place, not as buildings on a plain."""
    spec = _two_house_village()
    # A world with far more room than the content needs: the zone stays large
    # for placement's sake, so only WHERE the darts land can keep this together.
    spec["environment"]["dimensions_m"] = {
        "width": 200.0, "depth": 200.0, "max_height": 20.0,
    }
    plan = generate_semantic_world_plan(spec)
    assert plan["constraint_summary"]["unplaced_entities"] == []

    xs = [e["transform"]["position_m"][0] for e in plan["entities"]]
    zs = [e["transform"]["position_m"][2] for e in plan["entities"]]
    zone = plan["zones"][0]["bounds"]
    zone_width = zone["max"][0] - zone["min"][0]
    spread = max(max(xs) - min(xs), max(zs) - min(zs))
    # Real run before this: twelve entities over 51 m of a 73 m world, the
    # player 52 m from half of them, and the overview showed empty ground.
    assert spread < zone_width * 0.6, (
        f"content spans {spread:.1f} m of a {zone_width:.1f} m zone — scattered"
    )


def test_widening_still_lets_a_crowded_world_place_everything():
    """Composing tightly must never cost feasibility: late attempts spread out."""
    spec = _two_house_village()
    for index in range(6):
        spec["entities"].append(
            {
                "entity_id": f"ent_crate_{index}",
                "semantic_type": "crate",
                "asset": {"category": "prop", "asset_ref": f"ref_crate_{index}"},
                "physical": {"bbox_m": [1.2, 1.2, 1.2], "dynamic": False, "mass_kg": 30.0},
                "capabilities": [],
                "placement": {
                    "zone": "main",
                    "hard_constraints": ["inside_zone", "non_overlapping_with_clearance"],
                    "soft_preferences": [],
                },
            }
        )
    plan = generate_semantic_world_plan(spec)
    assert plan["constraint_summary"]["unplaced_entities"] == []


def test_world_extent_accounts_for_scatter_not_only_entities():
    """Scatter competes with entities for ground, so sizing must count it.

    Measured on a live run. A tea plantation declared four entities totalling
    about 116 m2 of footprint, and the extent was derived from those alone:
    34.7 x 25.5 m. The same specification also asked for seven scatter species
    including two 8 m canopy trees. Once the shed and machinery occupied the
    middle, and the trees' `avoid_tags` kept them off the buildings, both tree
    species placed ZERO instances -- the visual landmarks of a plantation, asked
    for by the planner and silently discarded, leaving bare boxes on a plain.

    Sizing on entities alone is the bug: it treats a world that is mostly
    vegetation as though it were only its buildings.
    """
    from pcg.semantic import _content_scaled_dimensions

    entities = [
        {"physical": {"bbox_m": [8.0, 6.0, 12.0]}},
        {"physical": {"bbox_m": [3.0, 4.0, 3.0]}},
        {"physical": {"bbox_m": [3.0, 4.0, 3.0]}},
        {"physical": {"bbox_m": [2.0, 1.1, 1.1]}},
    ]
    base = {
        "environment": {"dimensions_m": {"width": 50.0, "depth": 30.0, "max_height": 12.0}},
        "entities": entities,
    }
    bare_width, bare_depth, _ = _content_scaled_dimensions(base)

    planted = dict(base)
    planted["scatter"] = [
        {"species_id": "spc_canopy_a", "density_per_100m2": 2.5, "size_m": [8.0, 11.0, 8.0]},
        {"species_id": "spc_canopy_b", "density_per_100m2": 2.5, "size_m": [8.0, 11.0, 8.0]},
        {"species_id": "spc_bushes", "density_per_100m2": 83.0, "size_m": [1.0, 0.6, 0.5]},
    ]
    planted_width, planted_depth, _ = _content_scaled_dimensions(planted)

    assert planted_width * planted_depth > bare_width * bare_depth, (
        "a world carrying canopy trees needs more ground than the same "
        f"buildings alone ({planted_width:.1f}x{planted_depth:.1f} vs "
        f"{bare_width:.1f}x{bare_depth:.1f})"
    )


def test_scatter_sizing_does_not_inflate_a_sparse_world():
    """The allowance tracks demanded coverage, so light scatter changes little."""
    from pcg.semantic import _content_scaled_dimensions

    base = {
        "environment": {"dimensions_m": {"width": 60.0, "depth": 60.0, "max_height": 10.0}},
        "entities": [{"physical": {"bbox_m": [4.0, 3.0, 4.0]}}],
    }
    bare_width, _, _ = _content_scaled_dimensions(base)

    sparse = dict(base)
    # 1 pebble per 100 m2 at 0.25 m2 each: a quarter of one percent of the ground.
    sparse["scatter"] = [
        {"species_id": "spc_pebble", "density_per_100m2": 1.0, "size_m": [0.5, 0.5, 0.5]}
    ]
    sparse_width, _, _ = _content_scaled_dimensions(sparse)

    assert sparse_width == pytest.approx(bare_width, rel=0.02), (
        "negligible scatter must not grow the world"
    )
