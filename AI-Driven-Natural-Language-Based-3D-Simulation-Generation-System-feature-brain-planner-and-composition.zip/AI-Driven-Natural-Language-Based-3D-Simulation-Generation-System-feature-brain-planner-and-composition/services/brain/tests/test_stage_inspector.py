"""Per-stage artifacts and the inspector API.

A run used to expose only its final summary, so when a generation came out wrong
there was no way to see WHERE it went wrong. These tests pin the contract the
step-through inspector depends on: every stage is recorded, one row per stage,
the rail stays cheap (summaries only), a stage can be corrected by hand, and one
tenant can never read or edit another tenant's run.
"""

from __future__ import annotations

import jwt
from core import db as db_module
from core.config import get_settings
from core.models import GenerationRun, Simulation, StageArtifact, Tenant, User
from core.stages import (
    STAGE_ORDER,
    record_stage,
    replace_stage_payload,
    stage_payload,
    stages_for,
)

RUN_ID = "run_stage_inspector_0001"
SIM_ID = "sim_stage_inspector_0001"


def _headers(user_id: str, tenant_id: str) -> dict:
    token = jwt.encode(
        {
            "sub": f"subject:{user_id}",
            "serendib_user_id": user_id,
            "tenant_id": tenant_id,
            "age_band": "adult",
            "roles": ["user"],
        },
        get_settings().api_secret_key,
        algorithm="HS256",
    )
    return {"Authorization": f"Bearer {token}"}


def _seed_run(tenant_id: str = "tenant_dev", user_id: str = "user_dev") -> None:
    with db_module.session_scope() as session:
        session.add(Tenant(id=tenant_id, name=tenant_id, slug=tenant_id))
        session.add(User(id=user_id, subject=user_id, age_band="adult"))
        session.flush()
        session.add(
            Simulation(
                id=SIM_ID,
                tenant_id=tenant_id,
                owner_id=user_id,
                title="Inspector",
                prompt="Explore a jungle with ruins.",
                size_profile="small",
                target_platforms=["web"],
                seed=7,
            )
        )
        session.flush()
        session.add(
            GenerationRun(
                id=RUN_ID,
                simulation_id=SIM_ID,
                tenant_id=tenant_id,
                owner_id=user_id,
            )
        )


def test_stages_are_recorded_in_pipeline_order():
    _seed_run()
    # Recorded out of order on purpose: the rail must present pipeline order.
    record_stage(RUN_ID, "verify", status="PASS", summary={"layers": 18})
    record_stage(RUN_ID, "expand", status="PASS", summary={"words": 120})
    record_stage(RUN_ID, "scene_spec", status="PASS", summary={"entities": 13})

    stages = stages_for(RUN_ID)
    assert [item["stage"] for item in stages] == ["expand", "scene_spec", "verify"]
    assert all(item["ordinal"] == STAGE_ORDER.index(item["stage"]) for item in stages)


def test_rerunning_a_stage_updates_it_in_place():
    """One row per run+stage, so the inspector shows current truth, not a history."""
    _seed_run()
    record_stage(RUN_ID, "assets", status="FAIL", summary={"unresolved": 3})
    record_stage(RUN_ID, "assets", status="PASS", summary={"unresolved": 0})

    with db_module.session_scope() as session:
        rows = session.query(StageArtifact).filter_by(run_id=RUN_ID, stage="assets").all()
    assert len(rows) == 1
    assert rows[0].status == "PASS"
    assert rows[0].summary == {"unresolved": 0}


def test_payload_round_trips_and_unrun_stage_is_none():
    _seed_run()
    spec = {"terrain": {"kind": "jungle"}, "scatter": [{"species_id": "fern"}]}
    record_stage(RUN_ID, "scene_spec", status="PASS", payload=spec)

    stored = stage_payload(RUN_ID, "scene_spec")
    assert stored is not None
    assert stored["payload"] == spec
    assert stored["edited"] is False
    assert stage_payload(RUN_ID, "layout") is None


def test_a_human_edit_is_flagged_and_survives_a_rerun():
    """An edit is the strongest training signal there is, so it must stay marked."""
    _seed_run()
    record_stage(RUN_ID, "scene_spec", status="PASS", payload={"terrain": {"kind": "jungle"}})
    assert replace_stage_payload(RUN_ID, "scene_spec", {"terrain": {"kind": "desert"}}) is True

    stored = stage_payload(RUN_ID, "scene_spec")
    assert stored["payload"] == {"terrain": {"kind": "desert"}}
    assert stored["edited"] is True

    # Recomputing the stage must not quietly erase the fact a human corrected it.
    record_stage(RUN_ID, "scene_spec", status="PASS", summary={"entities": 4})
    assert stage_payload(RUN_ID, "scene_spec")["edited"] is True


def test_editing_a_stage_that_never_ran_is_refused():
    _seed_run()
    assert replace_stage_payload(RUN_ID, "layout", {"anything": True}) is False


def test_recording_never_raises_for_an_unknown_run():
    """Inspection is telemetry: it must never cost a build that otherwise worked."""
    record_stage("run_does_not_exist", "expand", status="PASS")  # must not raise


def test_api_lists_stages_and_returns_one_payload(client):
    _seed_run()
    record_stage(
        RUN_ID,
        "scene_spec",
        status="PASS",
        payload={"terrain": {"kind": "jungle"}},
        summary={"entities": 13},
        model_id="qwen3.6:27b",
        duration_ms=1234,
    )
    headers = _headers("user_dev", "tenant_dev")

    listed = client.get(f"/api/v1/runs/{RUN_ID}/stages", headers=headers)
    assert listed.status_code == 200, listed.text
    body = listed.json()
    assert body["run_id"] == RUN_ID
    entry = next(item for item in body["stages"] if item["stage"] == "scene_spec")
    assert entry["status"] == "PASS"
    assert entry["model_id"] == "qwen3.6:27b"
    assert entry["duration_ms"] == 1234
    # The rail must stay cheap: no payload in the list response.
    assert "payload" not in entry

    one = client.get(f"/api/v1/runs/{RUN_ID}/stages/scene_spec", headers=headers)
    assert one.status_code == 200, one.text
    assert one.json()["payload"] == {"terrain": {"kind": "jungle"}}


def test_api_edit_marks_the_stage_edited(client):
    _seed_run()
    record_stage(RUN_ID, "scene_spec", status="PASS", payload={"terrain": {"kind": "jungle"}})
    headers = _headers("user_dev", "tenant_dev")

    edited = client.put(
        f"/api/v1/runs/{RUN_ID}/stages/scene_spec",
        headers=headers,
        json={"payload": {"terrain": {"kind": "flooded_city"}}},
    )
    assert edited.status_code == 200, edited.text
    assert edited.json()["payload"] == {"terrain": {"kind": "flooded_city"}}
    assert edited.json()["edited"] is True


def test_api_404s_for_a_stage_that_never_ran(client):
    _seed_run()
    response = client.get(
        f"/api/v1/runs/{RUN_ID}/stages/layout", headers=_headers("user_dev", "tenant_dev")
    )
    assert response.status_code == 404


def test_another_tenant_can_neither_read_nor_edit_the_run(client):
    _seed_run()
    record_stage(RUN_ID, "scene_spec", status="PASS", payload={"secret": "prompt content"})
    with db_module.session_scope() as session:
        session.add(Tenant(id="tenant_other", name="Other", slug="other"))
        session.add(User(id="user_other", subject="user_other", age_band="adult"))
    intruder = _headers("user_other", "tenant_other")

    assert client.get(f"/api/v1/runs/{RUN_ID}/stages", headers=intruder).status_code == 404
    assert (
        client.get(f"/api/v1/runs/{RUN_ID}/stages/scene_spec", headers=intruder).status_code
        == 404
    )
    assert (
        client.put(
            f"/api/v1/runs/{RUN_ID}/stages/scene_spec",
            headers=intruder,
            json={"payload": {"tampered": True}},
        ).status_code
        == 404
    )
