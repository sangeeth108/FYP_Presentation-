"""The preview must be cheap, deterministic, and unable to fail a run.

Nothing looked at pixels until after asset generation and a Godot build --
about ten minutes -- so a spec-level mistake cost a full run to find, and the
planner authored a visual artifact with no way to see one. Doors came out lying
on their sides, an oak arrived felled, a village spread over 51 m of a 73 m
world. All invisible in JSON, all obvious in a picture.
"""

from __future__ import annotations

import time

import pytest
from pcg.preview import render_world_plan


def _plan(**overrides) -> dict:
    plan = {
        "world_bounds": {"min": [-20.0, 0.0, -20.0], "max": [20.0, 8.0, 20.0]},
        "entities": [
            {
                "entity_id": "ent_house",
                "semantic_type": "house",
                "dimensions_m": [6.0, 4.0, 5.0],
                "transform": {"position_m": [0.0, 2.0, 0.0], "rotation_y_degrees": 15.0},
            },
            {
                "entity_id": "ent_controlled_actor",
                "semantic_type": "dog",
                "dimensions_m": [0.35, 0.55, 1.0],
                "transform": {"position_m": [4.0, 0.3, 2.0], "rotation_y_degrees": 0.0},
            },
        ],
    }
    plan.update(overrides)
    return plan


def test_it_renders_a_plan(tmp_path):
    report = render_world_plan(_plan(), tmp_path / "preview.png")
    assert report["rendered"], report.get("reason")
    assert (tmp_path / "preview.png").is_file()
    assert report["entities_drawn"] == 2


def test_it_is_fast_enough_to_sit_in_the_loop(tmp_path):
    """The whole point is catching mistakes in seconds, not minutes."""
    started = time.monotonic()
    render_world_plan(_plan(), tmp_path / "preview.png")
    elapsed = time.monotonic() - started
    assert elapsed < 2.0, f"took {elapsed:.2f}s; a preview this slow buys nothing"


def test_the_same_plan_always_renders_the_same_image(tmp_path):
    """Two previews of one plan must be comparable by eye and by hash."""
    render_world_plan(_plan(), tmp_path / "a.png")
    render_world_plan(_plan(), tmp_path / "b.png")
    assert (tmp_path / "a.png").read_bytes() == (tmp_path / "b.png").read_bytes()


def test_it_reports_content_against_world(tmp_path):
    """The number that catches a village lost on a plain."""
    report = render_world_plan(_plan(), tmp_path / "preview.png")
    assert report["world_m"] == [40.0, 40.0]
    assert report["content_m"][0] < report["world_m"][0]


@pytest.mark.parametrize(
    "broken",
    [
        {"entities": []},
        {"entities": [{"entity_id": "x"}]},                      # no transform
        {"world_bounds": None},
        {"entities": [{"entity_id": "x", "semantic_type": "y",
                       "dimensions_m": [0, 0, 0],
                       "transform": {"position_m": [0, 0, 0]}}]},
    ],
)
def test_a_broken_plan_never_raises(tmp_path, broken):
    """A preview that fails must not take the run with it."""
    report = render_world_plan(_plan(**broken), tmp_path / "preview.png")
    assert isinstance(report, dict)
    assert "rendered" in report
    if not report["rendered"]:
        assert report.get("reason"), "a failure must say why"
