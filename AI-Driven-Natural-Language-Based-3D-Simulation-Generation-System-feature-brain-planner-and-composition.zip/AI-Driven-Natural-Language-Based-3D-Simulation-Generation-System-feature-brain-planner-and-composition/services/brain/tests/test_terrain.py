"""The heightfield, and the reason the ground can stop being a slab.

Every number quoted in these tests was measured off the generator, not chosen to
make it pass.
"""

from __future__ import annotations

import statistics

from pcg.terrain import (
    _MAX_AMPLITUDE_M,
    Terrain,
    build_terrain,
    flat_terrain,
    relief_amplitude_m,
)


def _environment(
    *, kind: str = "outdoor", surface: str = "grass", width: float = 60.0, depth: float = 60.0
) -> dict:
    return {
        "world_kind": kind,
        "terrain_surface": surface,
        "dimensions_m": {"width": width, "depth": depth, "max_height": 10.0},
    }


def test_the_same_seed_always_grows_the_same_ground():
    """A world must be reproducible from its seed alone (house rule 14).

    The lattice hash is a splitmix mix rather than Python's `hash()`, which is
    randomised per process for strings and bytes -- the same prompt would
    otherwise produce different hills on every run, and no lineage record could
    explain the difference.
    """
    first = build_terrain(_environment(), seed=42)
    again = build_terrain(_environment(), seed=42)
    other = build_terrain(_environment(), seed=43)
    assert first.heights == again.heights
    assert first.heights != other.heights


def test_built_ground_and_interiors_stay_flat():
    """A concrete yard with rolling hills in it is a fault, not a style.

    `world_kind` and `terrain_surface` already carry this, so relief needs no new
    spec field. Only a fully interior world is flat on kind alone -- its ground IS
    the floor. `mixed` used to be flat too, for a reason footprint pads have since
    answered; see test_a_world_with_buildings_in_it_still_gets_hills.
    """
    for surface in ("concrete", "metal", "wood"):
        assert relief_amplitude_m(_environment(surface=surface)) == 0.0
    assert relief_amplitude_m(_environment(kind="indoor")) == 0.0

    indoors = build_terrain(_environment(kind="indoor"), seed=42)
    assert indoors.flat
    # A flat world is a real Terrain rather than None, so placement keeps one code
    # path instead of testing for it everywhere.
    assert isinstance(indoors, Terrain)
    assert indoors.height_at(3.0, -4.0) == 0.0
    assert indoors.slope_degrees_at(3.0, -4.0) == 0.0


def test_natural_ground_gets_relief_within_its_amplitude():
    for surface in ("grass", "soil", "sand", "snow", "stone"):
        assert relief_amplitude_m(_environment(surface=surface)) > 0.0
    # Sand carries the most of the gentle families and stone the most overall,
    # which is the one family where sharp ground reads as correct.
    assert relief_amplitude_m(_environment(surface="stone")) >= relief_amplitude_m(
        _environment(surface="snow")
    )

    terrain = build_terrain(_environment(), seed=42)
    assert not terrain.flat
    assert max(abs(height) for height in terrain.heights) <= terrain.amplitude_m + 1e-9


def test_a_large_world_is_capped_rather_than_scaled_up():
    """Relief must not be able to fail a run that would otherwise pass.

    The navmesh bakes `agent_max_climb = 0.5` and `agent_max_slope = 45`, and
    `navigation_reachability` is mandatory, so unbounded amplitude on a 600 m world
    could carve the walkable surface into islands.
    """
    assert relief_amplitude_m(
        _environment(surface="stone", width=600.0, depth=600.0)
    ) == _MAX_AMPLITUDE_M


def test_the_payload_stays_small_however_large_the_world():
    """Cap the GRID, not the cell size.

    A 1000 m world at 2 m spacing would be 501x501 = 251k floats to ship, hash and
    diff, for relief a player reads over tens of metres.
    """
    big = build_terrain(_environment(surface="stone", width=1000.0, depth=1000.0), seed=7)
    assert len(big.heights) == big.grid * big.grid
    assert big.grid <= 128
    assert len(big.as_payload()["heights_m"]) == len(big.heights)


def test_heights_are_centred_so_the_world_does_not_lift():
    """y=0 has to stay the reference plane.

    Raw fBm is all-positive; using it directly would raise the whole world off its
    own origin, and every existing y in the plan is measured from there.
    """
    terrain = build_terrain(_environment(), seed=42)
    mean = statistics.fmean(terrain.heights)
    assert abs(mean) < 0.05


def test_the_sampler_agrees_with_the_grid_and_clamps_outside_it():
    terrain = build_terrain(_environment(), seed=42)
    half = terrain.width_m / 2.0
    step = terrain.width_m / (terrain.grid - 1)
    for column in (0, 5, terrain.grid - 1):
        expected = terrain.heights[column]
        assert abs(terrain.height_at(-half + column * step, -half) - expected) < 1e-9
    # Clamping, not raising: an entity exactly on the boundary is a legitimate
    # position, and both scatter and placement work in world space.
    assert terrain.height_at(9_999.0, 9_999.0) == terrain.heights[-1]


def test_slope_is_zero_on_the_flat_and_positive_on_a_hill():
    assert flat_terrain(60.0, 60.0).slope_degrees_at(1.0, 2.0) == 0.0
    terrain = build_terrain(_environment(), seed=42)
    slopes = [
        terrain.slope_degrees_at(x, z)
        for x in range(-28, 29, 3)
        for z in range(-28, 29, 3)
    ]
    assert max(slopes) > 1.0
    # Measured median 5.4 and max 28.2 degrees. Well inside the navmesh's 45, which
    # is what keeps relief from making targets unreachable.
    assert statistics.median(slopes) < 15.0
    assert max(slopes) < 45.0


def test_a_pad_levels_the_ground_under_a_footprint():
    """Placement gives an entity ONE contact height, so its footprint must be level.

    Without pads, measured on this field: an 8x6 m house spanned 0.670 m of height
    and a 16x12 m hall 2.101 m. A single contact height cannot seat either -- one
    corner floats or is buried by that much.
    """
    terrain = build_terrain(_environment(), seed=42)
    footprints = [(0.0, -15.0, 8.0, 6.0), (-18.0, -12.0, 16.0, 12.0)]
    padded = terrain.with_pads(footprints)

    for centre_x, centre_z, width, depth in footprints:
        before = [
            terrain.height_at(centre_x + sx * width / 2, centre_z + sz * depth / 2)
            for sx in (-1, 0, 1)
            for sz in (-1, 0, 1)
        ]
        after = [
            padded.height_at(centre_x + sx * width / 2, centre_z + sz * depth / 2)
            for sx in (-1, 0, 1)
            for sz in (-1, 0, 1)
        ]
        assert max(before) - min(before) > 0.2, "the test field must be uneven here"
        assert max(after) - min(after) < 0.01

    # Relief between the pads survives; the point is level footprints, not a plane.
    assert max(padded.heights) - min(padded.heights) > 1.0


def test_pads_do_not_depend_on_the_order_they_arrive_in():
    """Two entities must not seat differently depending on placement order."""
    terrain = build_terrain(_environment(), seed=42)
    footprints = [
        (0.0, -15.0, 8.0, 6.0),
        (15.0, 10.0, 14.0, 10.0),
        (6.0, 5.0, 1.8, 0.6),
        (-18.0, -12.0, 16.0, 12.0),
    ]
    assert (
        terrain.with_pads(footprints).heights
        == terrain.with_pads(list(reversed(footprints))).heights
    )


def test_a_big_structure_owns_the_ground_a_small_prop_stands_on():
    """A bench at a barn wall must not win the cells the barn needs.

    Measured with the nearest-pad rule alone, a bench standing against a 14 m barn
    took those cells outright -- its pad covers them fully while the barn's only
    reaches them at the edge -- and left the barn with 0.208 m of spread under its
    wall. Largest footprint first, with an owned cell final, puts the residual on
    the bench instead, which is both the smaller error and the right way round:
    big structures define the ground and props sit on what they find.
    """
    terrain = build_terrain(_environment(), seed=42)
    barn = (15.0, 10.0, 14.0, 10.0)
    bench = (8.0, 5.0, 1.8, 0.6)
    padded = terrain.with_pads([barn, bench])

    def spread(footprint) -> float:
        centre_x, centre_z, width, depth = footprint
        samples = [
            padded.height_at(centre_x + sx * width / 2, centre_z + sz * depth / 2)
            for sx in (-1, -0.5, 0, 0.5, 1)
            for sz in (-1, -0.5, 0, 0.5, 1)
        ]
        return max(samples) - min(samples)

    assert spread(barn) < 0.01
    # The bench absorbs what is left, and a bench is 0.45 m tall so this is a
    # centimetres-scale tilt rather than a floating wall.
    assert spread(bench) < 0.2


def test_pads_on_a_flat_world_change_nothing():
    flat = build_terrain(_environment(kind="indoor"), seed=42)
    assert flat.with_pads([(0.0, 0.0, 8.0, 6.0)]) is flat


def test_a_world_with_buildings_in_it_still_gets_hills():
    """`mixed` was excluded from relief, and that withheld it from most worlds.

    The exclusion was justified on a building's floor not being able to follow a
    hillside -- true when written, and answered by footprint pads, which level the
    ground a building stands on. The first real prompt exposed it: "a grassy hillside
    meadow with a stone cottage" classifies as mixed, for the cottage, and came back
    perfectly flat.

    Measured across 159 stored specs: 46 mixed against 67 outdoor. Only a world that
    is entirely interior stays flat, because there its ground IS the floor.
    """
    assert relief_amplitude_m(_environment(kind="mixed")) > 0.0
    assert relief_amplitude_m(_environment(kind="outdoor")) > 0.0
    assert relief_amplitude_m(_environment(kind="indoor")) == 0.0
    # A built surface stays flat whatever the world kind: a concrete yard with
    # rolling hills is a fault rather than a style.
    assert relief_amplitude_m(_environment(kind="mixed", surface="concrete")) == 0.0
