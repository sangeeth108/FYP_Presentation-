import re

from core.ids import new_game_id, new_job_id, slugify

GAME_ID_RE = re.compile(r"^g3d_[a-z0-9_]+_[a-f0-9]{8}$")


def test_game_id_matches_schema_pattern():
    for text in ["Foggy Village Escape", "  weird!!! chars @@ ", "12345", ""]:
        gid = new_game_id(text)
        assert GAME_ID_RE.match(gid), gid


def test_slugify_never_empty():
    assert slugify("") == "game"
    assert slugify("!!!") == "game"
    assert slugify("Hello World") == "hello_world"


def test_job_id_is_uuid_like():
    jid = new_job_id()
    assert len(jid) == 36 and jid.count("-") == 4
