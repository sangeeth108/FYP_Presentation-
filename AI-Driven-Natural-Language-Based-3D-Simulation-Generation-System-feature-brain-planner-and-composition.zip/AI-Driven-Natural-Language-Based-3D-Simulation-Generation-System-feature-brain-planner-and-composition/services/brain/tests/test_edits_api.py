"""POST /api/v1/edits/preview — the Serendib Assist dock's edit endpoint."""

import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from main import app

REPO = Path(__file__).resolve().parents[3]
SPEC = json.loads((REPO / "contracts" / "examples" / "golden_game.spec.json").read_text("utf-8"))


@pytest.fixture(autouse=True)
def _do_not_run_canonical_generation(monkeypatch):
    import api.simulations as simulations_api

    monkeypatch.setattr(
        simulations_api.run_simulation_generation,
        "delay",
        lambda run_id: run_id,
    )


def test_edit_preview_returns_a_valid_edited_spec():
    with TestClient(app) as client:
        r = client.post(
            "/api/v1/edits/preview",
            json={"spec": SPEC, "instruction": "make the skeletons faster and the crypt darker"},
        )
    assert r.status_code == 200
    body = r.json()
    assert body["valid"] is True
    assert body["changed"]  # something changed
    # The returned spec really is edited (enemy speed up).
    assert body["spec"]["entities"]["enemies"][0]["stats"]["speed"] > (
        SPEC["entities"]["enemies"][0]["stats"]["speed"]
    )


def test_edit_preview_reports_unsupported_requests():
    with TestClient(app) as client:
        r = client.post(
            "/api/v1/edits/preview",
            json={"spec": SPEC, "instruction": "add a boss and ranged archers"},
        )
    body = r.json()
    assert "a unique boss enemy" in body["rejected"]
    assert "ranged combat" in body["rejected"]


def test_edit_preview_rejects_a_too_long_instruction():
    with TestClient(app) as client:
        r = client.post(
            "/api/v1/edits/preview", json={"spec": SPEC, "instruction": "x" * 600}
        )
    assert r.status_code == 422  # schema-level guard


def test_legacy_reexport_redirects_canonical_users_to_neutral_edits():
    from core import db as db_module
    from core.db import Base
    Base.metadata.drop_all(bind=db_module.engine)
    Base.metadata.create_all(bind=db_module.engine)
    with TestClient(app) as client:
        # 1. create a game
        created = client.post(
            "/api/v1/games", json={"prompt": "a torchlit dungeon crawl", "seed": 7}
        ).json()
        game_id = created["game_id"]
        # 2. edit its spec (preview)
        edited = client.post("/api/v1/edits/preview",
                             json={"spec": SPEC, "instruction": "make the skeletons faster"}).json()
        assert edited["valid"]
        # 3. legacy game-spec mutation cannot bypass canonical simulation edits
        r = client.post(f"/api/v1/games/{game_id}/reexport", json={"spec": edited["spec"]})
        assert r.status_code == 410
        detail = r.json()["detail"]
        assert detail["code"] == "LEGACY_REEXPORT_RETIRED"
        assert detail["successor"].endswith(f"/simulations/{game_id}/edits")


def test_reexport_rejects_an_out_of_contract_spec():
    from core import db as db_module
    from core.db import Base
    Base.metadata.drop_all(bind=db_module.engine)
    Base.metadata.create_all(bind=db_module.engine)
    with TestClient(app) as client:
        created = client.post("/api/v1/games", json={"prompt": "a dungeon", "seed": 1}).json()
        bad = {"not": "a valid spec"}
        r = client.post(f"/api/v1/games/{created['game_id']}/reexport", json={"spec": bad})
        assert r.status_code == 422


def test_reexport_refuses_an_invented_template_id_immediately():
    """In-contract means the schema AND the registry.

    "ai_teleporting_boss" is a perfectly valid string, so jsonschema passes it.
    The pipeline's allowlist gate does stop it — but only after this endpoint has
    already answered 202, so the caller learns via a FAILED job minutes later.
    Answer now, with the same machine-readable error object.
    """
    from core import db as db_module
    from core.db import Base

    Base.metadata.drop_all(bind=db_module.engine)
    Base.metadata.create_all(bind=db_module.engine)
    with TestClient(app) as client:
        created = client.post("/api/v1/games", json={"prompt": "a dungeon", "seed": 1}).json()
        bad = json.loads(json.dumps(SPEC))
        bad["entities"]["enemies"][0]["ai_template_id"] = "ai_teleporting_boss"
        r = client.post(f"/api/v1/games/{created['game_id']}/reexport", json={"spec": bad})

    assert r.status_code == 422
    detail = r.json()["detail"]
    assert detail["code"] == "TEMPLATE_ID_NOT_IN_REGISTRY"  # an object, not a string (§13)
    assert detail["path"] == "$.entities.enemies[0].ai_template_id"
    assert "ai_patrol_chase" in detail["hint"]  # says what IS allowed


def test_registry_clean_legacy_edit_still_requires_canonical_edit_contract():
    from core import db as db_module
    from core.db import Base

    Base.metadata.drop_all(bind=db_module.engine)
    Base.metadata.create_all(bind=db_module.engine)
    with TestClient(app) as client:
        created = client.post("/api/v1/games", json={"prompt": "a dungeon", "seed": 2}).json()
        edited = client.post(
            "/api/v1/edits/preview", json={"spec": SPEC, "instruction": "make the enemies faster"}
        ).json()
        r = client.post(
            f"/api/v1/games/{created['game_id']}/reexport", json={"spec": edited["spec"]}
        )
    assert r.status_code == 410
