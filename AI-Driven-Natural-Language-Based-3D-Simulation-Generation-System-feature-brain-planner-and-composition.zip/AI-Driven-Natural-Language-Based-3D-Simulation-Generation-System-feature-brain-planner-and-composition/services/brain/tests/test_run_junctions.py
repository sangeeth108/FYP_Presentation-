"""Two runs the planner drew crossing are joined, not colliding.

Found by the FROZEN BENCHMARK rather than by any single prompt, which is the point:
`ENTITY_UNPLACED` was 6 of 10 failures at 70% pass, and every unplaced entity was a
linear-run segment. The harbour prompt drew

    lin_timber_jetty  (-50,-7.5) -> (-10,-4.5)  thickness 2.0
    lin_quay_edge     (-50,-4.5) -> ( 50,-4.5)  thickness 1.5

a jetty emerging from a quay at a shallow angle, so their footprints overlap for 23 of the
jetty's 40 m. Five of seven quay segments had no solution and the prompt failed. Trimming
the jetty clear of the quay would cost 60% of its length; the honest reading is that the
two structures are joined, as a real jetty and quay are.
"""

from pcg.semantic import _joined_runs, entities_conflict


def _body(position: list[float], entity_id: str) -> dict:
    return {
        "entity_id": entity_id,
        "world_aabb": {
            "min": [position[0] - 3.0, 0.0, position[2] - 0.75],
            "max": [position[0] + 3.0, 1.2, position[2] + 0.75],
        },
        "dimensions_m": [6.0, 1.2, 1.5],
        "transform": {"position_m": position, "rotation_y_degrees": 0.0},
        "interaction_clearance_m": 0.5,
        "support": {"type": "terrain"},
    }


def _small(position: list[float], entity_id: str, clearance: float = 0.25) -> dict:
    """A 1 x 1 m body, so a test can place it NEAR a wall without overlapping it."""
    return {
        "entity_id": entity_id,
        "world_aabb": {
            "min": [position[0] - 0.5, 0.0, position[2] - 0.5],
            "max": [position[0] + 0.5, 1.0, position[2] + 0.5],
        },
        "dimensions_m": [1.0, 1.0, 1.0],
        "transform": {"position_m": position, "rotation_y_degrees": 0.0},
        "interaction_clearance_m": clearance,
        "support": {"type": "terrain"},
    }


def test_segments_of_two_runs_may_share_their_junction() -> None:
    """The exact overlap that lost five quay segments."""
    quay = [-20.0, 0.6, -4.5]
    jetty = _body([-20.0, 0.6, -5.0], "ent_timber_jetty_s3")  # 0.5 m apart: overlapping
    assert not entities_conflict(
        quay, [6.0, 1.2, 1.5], 0.0, 0.5, jetty,
        adjacent=False, own_id="ent_quay_edge_s2",
    )


def test_neighbours_in_one_run_are_still_judged() -> None:
    """Two segments of the SAME run are a line, not a junction. Letting them
    interpenetrate would hide a run that doubles back on itself."""
    here = [0.0, 0.6, 0.0]
    overlapping_sibling = _body([0.5, 0.6, 0.0], "ent_quay_edge_s3")
    assert entities_conflict(
        here, [6.0, 1.2, 1.5], 0.0, 0.5, overlapping_sibling,
        adjacent=False, own_id="ent_quay_edge_s2",
    )


def test_a_run_still_conflicts_with_ordinary_content() -> None:
    """A warehouse standing in the quay is a collision, not a junction."""
    here = [0.0, 0.6, 0.0]
    warehouse = _body([0.5, 0.6, 0.0], "ent_warehouse")
    assert entities_conflict(
        here, [6.0, 1.2, 1.5], 0.0, 0.5, warehouse,
        adjacent=False, own_id="ent_quay_edge_s2",
    )


def test_the_waiver_needs_both_ids() -> None:
    """A caller that does not say who it is gets the strict answer, so a missed call
    site fails closed rather than silently letting everything overlap."""
    here = [0.0, 0.6, 0.0]
    other_run = _body([0.5, 0.6, 0.0], "ent_timber_jetty_s3")
    assert entities_conflict(
        here, [6.0, 1.2, 1.5], 0.0, 0.5, other_run, adjacent=False, own_id=None
    )


def test_the_rule_reads_run_names_not_geometry() -> None:
    assert _joined_runs("ent_quay_edge_s2", "ent_timber_jetty_s3")
    assert not _joined_runs("ent_quay_edge_s2", "ent_quay_edge_s3")
    assert not _joined_runs("ent_quay_edge_s2", "ent_warehouse")
    assert not _joined_runs(None, "ent_timber_jetty_s3")


def test_both_callers_pass_their_own_id() -> None:
    """This function has drifted ten times by two callers computing one answer. The
    junction test is derived inside it, but only if both callers say who they are."""
    import inspect

    from pcg import semantic

    source = inspect.getsource(semantic)
    assert source.count("own_id=") >= 2


def test_an_opening_needs_no_walking_room_from_its_own_wall() -> None:
    """The last cause of ENTITY_UNPLACED on the frozen benchmark.

    Measured on `sim_village_lane`:

        ent_wall_right_s1  anchored at (-15.70, -1.50), unplaceable
        ent_gate           0.5 m away, interaction_clearance_m 1.5

    A gate is opened, so it carries interaction clearance; the wall it is set into is the
    one thing that clearance must not apply to. One segment of a fourteen-segment wall had
    no solution, and an anchored segment has no alternative, so the wall shipped with a
    hole in it and the prompt failed. Exactly the mistake already fixed once for doors --
    "asking the two halves of a doorway to stand 1.5 m apart".
    """
    # The wall segment spans x -1.375..1.375; the gate sits just clear of its end and
    # well inside the 1.5 m it would otherwise demand.
    wall = [0.0, 0.5, -1.5]
    gate = _small([2.2, 0.5, -1.5], "ent_gate", clearance=1.5)
    assert not entities_conflict(
        wall, [2.75, 1.0, 0.3], 0.0, 0.25, gate,
        adjacent=False, own_id="ent_wall_right_s1",
    )


def test_an_opening_may_not_stand_inside_the_masonry() -> None:
    """Clearance is waived; overlap is not. A gate stands in the GAP in a wall."""
    wall = [0.0, 0.5, -1.5]
    gate = _body([0.0, 0.5, -1.5], "ent_gate")  # dead centre:a real overlap
    gate["interaction_clearance_m"] = 1.5
    assert entities_conflict(
        wall, [2.75, 1.0, 0.3], 0.0, 0.25, gate,
        adjacent=False, own_id="ent_wall_right_s1",
    )


def test_ordinary_content_still_needs_its_room() -> None:
    """A cottage is not an opening; it does not get to crowd a wall."""
    wall = [0.0, 0.5, -1.5]
    cottage = _small([2.2, 0.5, -1.5], "ent_cottage_r2", clearance=1.5)
    assert entities_conflict(
        wall, [2.75, 1.0, 0.3], 0.0, 0.25, cottage,
        adjacent=False, own_id="ent_wall_right_s1",
    )
