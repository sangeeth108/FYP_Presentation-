"""Production identity, tenancy, consent, and training-boundary invariants."""

from __future__ import annotations

import jwt
from core import db as db_module
from core.config import get_settings
from core.models import (
    ContentRight,
    Game,
    GuardianRelationship,
    Job,
    Simulation,
    Tenant,
    TrainingEligibility,
    UsageEvent,
    User,
)
from learning.eligibility import evaluate_eligibility


def _headers(user_id: str, tenant_id: str, age_band: str, roles=None) -> dict:
    token = jwt.encode(
        {
            "sub": f"subject:{user_id}",
            "serendib_user_id": user_id,
            "tenant_id": tenant_id,
            "age_band": age_band,
            "roles": roles or ["user"],
        },
        get_settings().api_secret_key,
        algorithm="HS256",
    )
    return {"Authorization": f"Bearer {token}"}


def _consent_body(granted=True):
    return {
        "disclosure_version": "privacy-v1",
        "locale": "en",
        "choices": [
            {"scope": "global", "data_category": "prompt_spec", "granted": granted}
        ],
    }


def test_job_lookup_is_tenant_scoped(client):
    with db_module.session_scope() as db:
        db.add(Tenant(id="tenant_a", name="A", slug="a"))
        db.add(Tenant(id="tenant_b", name="B", slug="b"))
        db.add(User(id="user_a", subject="a", age_band="adult"))
        db.add(User(id="user_b", subject="b", age_band="adult"))
        db.flush()  # identity rows must land before the FK-bearing game/job
        db.add(
            Game(
                id="g3d_tenant_test_00000000",
                title="tenant test",
                prompt="a tenant-isolated simulation",
                tenant_id="tenant_a",
                owner_id="user_a",
            )
        )
        db.flush()  # game must land before the job that references it
        db.add(
            Job(
                id="job_tenant_test",
                game_id="g3d_tenant_test_00000000",
                tenant_id="tenant_a",
                owner_id="user_a",
            )
        )

    own = client.get(
        "/api/v1/jobs/job_tenant_test",
        headers=_headers("user_a", "tenant_a", "adult"),
    )
    other = client.get(
        "/api/v1/jobs/job_tenant_test",
        headers=_headers("user_b", "tenant_b", "adult"),
    )
    assert own.status_code == 200
    assert other.status_code == 404


def test_consent_defaults_off_and_adult_can_opt_in(client):
    headers = _headers("adult_a", "tenant_a", "adult")
    initial = client.get("/api/v1/privacy/training-consent", headers=headers)
    assert initial.status_code == 200
    assert not any(item["effective"] for item in initial.json()["choices"])

    updated = client.put(
        "/api/v1/privacy/training-consent",
        headers=headers,
        json=_consent_body(),
    )
    assert updated.status_code == 200
    selected = next(
        item
        for item in updated.json()["choices"]
        if item["scope"] == "global" and item["data_category"] == "prompt_spec"
    )
    assert selected["subject_granted"] is True
    assert selected["effective"] is True


def test_teen_consent_is_ineffective_until_verified_guardian_consents(client):
    teen_headers = _headers("teen_a", "family", "13_15")
    guardian_headers = _headers("guardian_a", "family", "adult", ["guardian"])

    own = client.put(
        "/api/v1/privacy/training-consent",
        headers=teen_headers,
        json=_consent_body(),
    )
    selected = next(
        item
        for item in own.json()["choices"]
        if item["scope"] == "global" and item["data_category"] == "prompt_spec"
    )
    assert selected["subject_granted"] is True
    assert selected["guardian_granted"] is False
    assert selected["effective"] is False

    relationship = client.post(
        "/api/v1/privacy/guardian-relationships",
        headers=guardian_headers,
        json={
            "minor_user_id": "teen_a",
            "verification_reference": "opaque-provider-reference",
        },
    ).json()
    verified = client.post(
        f"/api/v1/admin/guardian-relationships/{relationship['relationship_id']}/verify"
    )
    assert verified.status_code == 200

    guardian = client.put(
        "/api/v1/privacy/guardians/teen_a/training-consent",
        headers=guardian_headers,
        json=_consent_body(),
    )
    selected = next(
        item
        for item in guardian.json()["choices"]
        if item["scope"] == "global" and item["data_category"] == "prompt_spec"
    )
    assert selected["guardian_granted"] is True
    assert selected["effective"] is True


def test_feedback_is_quarantined_and_requires_every_eligibility_gate(client):
    headers = _headers("adult_b", "tenant_b", "adult")
    client.put(
        "/api/v1/privacy/training-consent",
        headers=headers,
        json=_consent_body(),
    )
    response = client.post(
        "/api/v1/feedback",
        headers=headers,
        json={
            "kind": "rating",
            "rating": 5,
            "payload": {"comment": "the village placement is correct"},
            "rights_attested": True,
        },
    )
    assert response.status_code == 202
    assert response.json()["training_status"] == "quarantined"

    with db_module.session_scope() as db:
        tenant = db.get(Tenant, "tenant_b")
        tenant.training_policy = "hybrid"
        eligibility = (
            db.query(TrainingEligibility)
            .filter_by(
                resource_id=response.json()["feedback_id"],
                training_scope="global",
            )
            .one()
        )
        assert eligibility.status == "quarantined"
        eligibility.moderation_status = "approved"
        eligibility.quality_status = "approved"
        evaluate_eligibility(db, eligibility, data_category="prompt_spec")
        assert eligibility.status == "ineligible"
        assert eligibility.exclusion_reason == "training_rights_not_verified"
        right_id = eligibility.content_right_id

    reviewed = client.put(
        f"/api/v1/admin/content-rights/{right_id}/review",
        headers=_headers(
            "rights_reviewer",
            "tenant_b",
            "adult",
            ["reviewer"],
        ),
        json={
            "approved": True,
            "rights_basis": "user_attestation_verified",
        },
    )
    assert reviewed.status_code == 200, reviewed.text
    with db_module.session_scope() as db:
        eligibility = (
            db.query(TrainingEligibility)
            .filter_by(
                resource_id=response.json()["feedback_id"],
                training_scope="global",
            )
            .one()
        )
        assert eligibility.status == "eligible"
        assert eligibility.pseudonym_key


def test_usage_telemetry_is_tenant_scoped_and_quarantined_by_default(client):
    with db_module.session_scope() as db:
        db.add(Tenant(id="tenant_usage", name="Usage", slug="usage"))
        db.add(
            User(
                id="user_usage",
                subject="subject:user_usage",
                age_band="adult",
            )
        )
        db.flush()  # identity rows must exist before the FK-bearing simulation
        db.add(
            Simulation(
                id="sim_usage",
                tenant_id="tenant_usage",
                owner_id="user_usage",
                title="Placement study",
                prompt="Explore a measured placement study environment.",
                size_profile="small",
                target_platforms=["web"],
                seed=1,
            )
        )
    response = client.post(
        "/api/v1/usage-events",
        headers=_headers("user_usage", "tenant_usage", "adult"),
        json={
            "simulation_id": "sim_usage",
            "event_type": "placement_adjusted",
            "payload": {
                "chosen": {"clearance_m": 2.0, "reachable": True},
                "rejected": {"clearance_m": 0.1, "reachable": False},
            },
        },
    )
    assert response.status_code == 202, response.text
    with db_module.session_scope() as db:
        event = db.get(UsageEvent, response.json()["usage_event_id"])
        assert event.tenant_id == "tenant_usage"
        right = (
            db.query(ContentRight)
            .filter_by(resource_type="usage_event", resource_id=event.id)
            .one()
        )
        assert right.verified_at is not None
        rows = (
            db.query(TrainingEligibility)
            .filter_by(resource_type="usage_event", resource_id=event.id)
            .all()
        )
        assert len(rows) == 2
        assert {row.data_category for row in rows} == {"telemetry"}
        assert {row.status for row in rows} == {"quarantined"}


def test_delete_request_immediately_blocks_training(client):
    headers = _headers("adult_c", "tenant_c", "adult")
    response = client.post("/api/v1/privacy/delete", headers=headers)
    assert response.status_code == 202
    assert response.json()["state"] == "queued"
    status = client.get(
        f"/api/v1/privacy/requests/{response.json()['request_id']}",
        headers=headers,
    )
    assert status.status_code == 200
    assert status.json()["state"] == "completed"
    assert status.json()["result"]["content_deleted"] is True


def test_export_request_completes_with_user_owned_data(client):
    headers = _headers("adult_export", "tenant_export", "adult")
    feedback = client.post(
        "/api/v1/feedback",
        headers=headers,
        json={
            "kind": "rating",
            "rating": 4,
            "payload": {"comment": "useful simulation"},
            "rights_attested": False,
        },
    )
    assert feedback.status_code == 202
    requested = client.post("/api/v1/privacy/export", headers=headers)
    assert requested.status_code == 202
    status = client.get(
        f"/api/v1/privacy/requests/{requested.json()['request_id']}",
        headers=headers,
    )
    assert status.status_code == 200
    body = status.json()
    assert body["state"] == "completed"
    assert body["result"]["summary"]["feedback_count"] == 1
    assert body["result"]["scope"] == "all_serendib_tenants"


def test_guardian_relationship_stays_pending_until_review(client):
    teen_headers = _headers("teen_b", "family_b", "16_17")
    guardian_headers = _headers("guardian_b", "family_b", "adult", ["guardian"])
    client.get("/api/v1/privacy/training-consent", headers=teen_headers)
    response = client.post(
        "/api/v1/privacy/guardian-relationships",
        headers=guardian_headers,
        json={
            "minor_user_id": "teen_b",
            "verification_reference": "provider-check-1234",
        },
    )
    assert response.status_code == 202
    with db_module.session_scope() as db:
        relationship = db.get(
            GuardianRelationship, response.json()["relationship_id"]
        )
        assert relationship.status == "pending"
