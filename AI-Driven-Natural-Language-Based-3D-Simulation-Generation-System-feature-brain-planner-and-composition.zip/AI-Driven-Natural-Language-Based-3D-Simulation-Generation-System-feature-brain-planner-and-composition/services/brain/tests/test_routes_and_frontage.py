"""A settlement is a street with buildings addressing it.

Measured across 176 specs: `facing` used 0 times in 531 relations, 55% of entities
carrying no relation at all, and buildings landing wherever a seeded dart did not
collide -- 21 m gaps in something called a village. The gap analysis calls this the
actual reason the output is not a village.

On the diagnostic spec, before and after, the four cottages went from
45.3 / 27.8 / 12.6 m apart with yaws of -92.8, 62.7, -6.3 and -35.4 degrees, to two
facing rows 10.2 m apart along a lane at exactly 180 and 0 degrees.
"""

from __future__ import annotations

import copy
import json
import math
from pathlib import Path

import jsonschema
import pytest
from pcg.routes import _at_distance, _points, allocate_frontage
from pcg.semantic import generate_semantic_world_plan, validate_semantic_world_plan

from tests.test_simulation_core import _dog_village

_CONTRACT = (
    Path(__file__).resolve().parents[3] / "contracts" / "simulation_spec.schema.json"
)


def _route(**overrides) -> dict:
    route = {
        "route_id": "rte_main_lane",
        "semantic_type": "main_village_lane",
        "source_text": "a village",
        "points_m": [-35.0, -35.0, 35.0, -35.0],
        "width_m": 4.0,
    }
    route.update(overrides)
    return route


def _fronting(setback_m: float = 2.0, side: str | None = None, **route_overrides):
    """The diagnostic village with every structure addressing one lane."""
    spec = copy.deepcopy(_dog_village())
    spec["routes"] = [_route(**route_overrides)]
    for entity in spec["entities"]:
        if entity["asset"]["category"] == "structure":
            frontage = {"route_id": "rte_main_lane", "setback_m": setback_m}
            if side:
                frontage["side"] = side
            entity["placement"]["frontage"] = frontage
    return spec


def _structures(plan: dict, spec: dict) -> list[dict]:
    wanted = {
        entity["entity_id"]
        for entity in spec["entities"]
        if entity["asset"]["category"] == "structure"
    }
    return [entity for entity in plan["entities"] if entity["entity_id"] in wanted]


def test_buildings_that_front_a_lane_form_two_facing_rows():
    """The result the whole feature exists for.

    Without a route the same four cottages land 45, 28 and 13 m apart at four
    unrelated angles. With one they stand in two rows either side of it, every one of
    them square to the street.
    """
    spec = _fronting()
    plan = generate_semantic_world_plan(spec)
    placed = _structures(plan, spec)
    assert len(placed) == 4

    # Two rows: the lane runs along z = -35, so the near faces sit at
    # half-width (2) + setback (2) + half-depth (4) = 8 m either side.
    depths = sorted({round(entity["transform"]["position_m"][2], 2) for entity in placed})
    assert depths == [-43.0, -27.0]

    # And every one of them faces the street rather than a random direction. This is
    # what `facing` could never express, and why it went unused in all 531 relations.
    yaws = {round(entity["transform"]["rotation_y_degrees"]) % 360 for entity in placed}
    assert yaws == {0, 180}

    assert not plan["constraint_summary"]["unplaced_entities"]
    report = validate_semantic_world_plan(plan, require_measured_assets=False)
    assert report["status"] == "PASS", report.get("errors")


def test_setback_is_measured_to_the_near_face_not_the_centre():
    """Otherwise a deep building buries half of itself in its own street.

    Measuring to the centre would put a 12 m-deep longhouse 6 m into the road and a
    2 m stall barely at all, so the same declared setback would mean something
    different for every building -- and worse for the buildings that matter most.
    """
    spec = _fronting(setback_m=0.0)
    plan = generate_semantic_world_plan(spec)
    for entity in _structures(plan, spec):
        depth = entity["dimensions_m"][2]
        distance = abs(entity["transform"]["position_m"][2] + 35.0)
        # Flush against a 4 m lane: 2 m of half-width plus half the building's depth.
        assert distance == pytest.approx(2.0 + depth / 2.0, abs=0.01)


def test_a_row_is_centred_on_its_route_rather_than_stacked_at_the_start():
    """Four cottages in the first 20 m of a 70 m lane is not a street.

    Filling from the start oriented every building correctly and still left the
    settlement bunched at one end with fifty metres of empty road beyond it.
    """
    spec = _fronting()
    plan = generate_semantic_world_plan(spec)
    xs = [entity["transform"]["position_m"][0] for entity in _structures(plan, spec)]
    # Symmetric about the lane's midpoint at x = 0.
    assert sum(xs) == pytest.approx(0.0, abs=0.01)


def test_a_named_side_is_honoured_and_either_alternates():
    """`side` is for the prompt that actually says one side.

    The default alternates, because that is what fills a street evenly -- and a
    street with one empty side reads as half-built rather than as a design choice.
    """
    left_only = _fronting(side="left")
    plan = generate_semantic_world_plan(left_only)
    sides = {
        round(entity["transform"]["position_m"][2], 2)
        for entity in _structures(plan, left_only)
        # Only those that kept their plot; a relaxed one is not evidence about sides.
        if abs(entity["transform"]["position_m"][2] + 27.0) < 0.01
        or abs(entity["transform"]["position_m"][2] + 43.0) < 0.01
    }
    assert sides == {-27.0}

    both = generate_semantic_world_plan(_fronting())
    assert len(
        {round(entity["transform"]["position_m"][2], 2) for entity in both["entities"]}
        & {-27.0, -43.0}
    ) == 2


def test_a_taken_plot_yields_and_says_so():
    """A frontage anchor is a preference; a wall segment's anchor is a fact.

    Measured: a lane run through the village's own 25 m square put two of four
    cottages inside it. Honouring the anchor on every attempt lost both, and an
    unplaced building is worse than a badly placed one. So frontage yields once
    relaxation begins, like every other soft preference -- and the yield is recorded,
    because somebody asked for a building on a lane and has got one off it.
    """
    spec = _fronting(points_m=[-35.0, 0.0, 35.0, 0.0])
    plan = generate_semantic_world_plan(spec)

    given_up = [
        item
        for item in plan["constraint_summary"]["soft_relaxations"]
        if item["constraint"] == "frontage"
    ]
    assert given_up
    assert "already occupied" in given_up[0]["reason"]

    # A house that gave up its plot has nothing to face, so it must not keep the
    # street's angle -- squared to a lane it no longer stands on reads as a fault.
    moved = {item["entity_id"] for item in given_up}
    off_street = [
        entity
        for entity in _structures(plan, spec)
        if entity["entity_id"] in moved
    ]
    assert all(
        round(entity["transform"]["rotation_y_degrees"]) % 180 != 0
        for entity in off_street
    )

    # THE KNOWN LIMITATION THIS ONCE PINNED IS FIXED.
    #
    # It used to assert `lost == ["ent_house_3_door"]`: under this deliberately
    # pathological route -- a lane driven straight through the village's own 25 m square
    # -- one house kept a plot whose front face landed inside the square, and its door
    # was lost because "the door has no freedom to move aside and the parent is not
    # reconsidered once a child fails".
    #
    # The prediction was that fixing it meant letting a failed child push its parent to
    # another candidate. It did not. The door never needed to move: it was being refused
    # for INTERACTION CLEARANCE -- 1.5 m, because it is openable -- against unrelated
    # geometry, which a body positioned at parent-plus-offset can never satisfy and never
    # needed to. An attached child now waives clearance and still refuses overlap, on both
    # the placer and the validator.
    #
    # Kept as a regression: a rigidly attached child must survive its parent yielding a
    # plot. Measured on five stored production specs, all of which now place every entity
    # with zero overlaps; `ent_gatehouse_door` and `ent_ped_door` had each been failing a
    # mandatory gate and cascading to seven.
    lost = plan["constraint_summary"]["unplaced_entities"]
    assert lost == [], lost
    doors = [
        entity["entity_id"]
        for entity in plan["entities"]
        if entity["entity_id"].endswith("_door")
    ]
    assert "ent_house_3_door" in doors, doors


def test_a_bending_street_turns_its_buildings_with_it():
    """Two points make a lane; three or more make it bend.

    A settlement on a single straight line reads as a film set. The buildings on the
    diagonal leg have to turn with it, or the bend is invisible.
    """
    spec = _fronting(
        setback_m=0.0,
        side="left",
        points_m=[-30.0, -25.0, 0.0, -25.0, 20.0, -5.0],
        width_m=6.0,
    )
    plan = generate_semantic_world_plan(spec)
    yaws = {
        round(entity["transform"]["rotation_y_degrees"]) % 360
        for entity in _structures(plan, spec)
    }
    # The straight leg (running +x) faces its left-side buildings back at -z, which
    # is yaw 0; the 45-degree leg turns them to 45. Both present means the street's
    # shape actually reached the buildings rather than being averaged away.
    assert {0, 45} <= yaws


def test_a_kink_shorter_than_the_street_is_wide_is_merged_out():
    """A bend a visitor cannot see is not a bend.

    It is a place where two nearly parallel segments disagree about which way "beside
    the route" points, which sets two neighbouring buildings at visibly different
    angles for no visible reason.
    """
    merged = _points(
        {
            "points_m": [0.0, 0.0, 0.3, 0.05, 20.0, 0.0],
            "width_m": 6.0,
        }
    )
    assert len(merged) == 2
    assert merged[0] == (0.0, 0.0)
    assert merged[-1] == (20.0, 0.0)

    # A real bend survives.
    kept = _points({"points_m": [0.0, 0.0, 10.0, 0.0, 10.0, 10.0], "width_m": 4.0})
    assert len(kept) == 3


def test_walking_past_the_end_of_a_route_clamps_rather_than_extrapolates():
    """A street that has run out of room has run out of room.

    Continuing its last segment into open country would put a building somewhere the
    planner never drew a street, which is worse than the honest answer of not fitting.
    """
    points = [(0.0, 0.0), (10.0, 0.0)]
    x, z, dir_x, dir_z = _at_distance(points, 999.0)
    assert (round(x, 4), round(z, 4)) == (10.0, 0.0)
    assert (round(dir_x, 4), round(dir_z, 4)) == (1.0, 0.0)


def test_a_street_too_short_for_its_buildings_says_so():
    """Overflow is disclosed and user-visible: fewer buildings on the street than
    asked for is a change to what somebody described."""
    spec = _fronting(points_m=[-6.0, -35.0, 6.0, -35.0], side="left")
    notes = allocate_frontage(
        spec,
        {
            entity["entity_id"]: entity["physical"]["bbox_m"]
            for entity in spec["entities"]
        },
    )
    overflow = [note for note in notes if "did not fit" in note["reason"]]
    assert overflow
    assert overflow[0]["user_visible"] is True


def test_frontage_naming_a_route_that_does_not_exist_is_disclosed_not_fatal():
    """The entity still gets placed by the ordinary solver, so the world is fine.

    What is not fine is silence: the arrangement the planner described is not the one
    that was built.
    """
    spec = copy.deepcopy(_dog_village())
    for entity in spec["entities"]:
        if entity["asset"]["category"] == "structure":
            entity["placement"]["frontage"] = {
                "route_id": "rte_nowhere",
                "setback_m": 2.0,
            }
    notes = allocate_frontage(spec, {})
    assert notes and all("does not contain" in note["reason"] or "no routes" in note["reason"] for note in notes)

    plan = generate_semantic_world_plan(spec)
    assert not plan["constraint_summary"]["unplaced_entities"]


def test_plot_width_comes_from_measured_geometry_not_declared():
    """Which is the whole reason this runs at layout time rather than spec time.

    A building measured wider than it was declared needs a wider plot, or its
    neighbour is inside it.
    """
    spec = _fronting(side="left")
    narrow = allocate_frontage(copy.deepcopy(spec), {})

    wide_spec = copy.deepcopy(spec)
    ids = [
        entity["entity_id"]
        for entity in wide_spec["entities"]
        if entity["asset"]["category"] == "structure"
    ]
    allocate_frontage(wide_spec, {entity_id: [30.0, 6.0, 8.0] for entity_id in ids})
    anchors = [
        entity["placement"]["anchor_m"][0]
        for entity in wide_spec["entities"]
        if entity["entity_id"] in ids and entity["placement"].get("anchor_m")
    ]
    if len(anchors) > 1:
        # 30 m buildings cannot be 10.2 m apart.
        assert min(abs(b - a) for a, b in zip(sorted(anchors), sorted(anchors)[1:])) > 20.0
    assert narrow is not None


def test_allocation_consumes_no_randomness():
    """Determinism (rule 14), and stronger than seed-stability: allocation does not
    consult the seed at all, so two runs of the same spec under different seeds put
    the buildings in the same plots."""
    first = _fronting()
    second = copy.deepcopy(first)
    second["meta"]["seed"] = int(first["meta"]["seed"]) + 9999

    def anchors(spec: dict) -> dict:
        allocate_frontage(
            spec,
            {
                entity["entity_id"]: entity["physical"]["bbox_m"]
                for entity in spec["entities"]
            },
        )
        return {
            entity["entity_id"]: entity["placement"].get("anchor_m")
            for entity in spec["entities"]
        }

    assert anchors(first) == anchors(second)


def test_the_expanded_spec_and_routes_validate_against_the_contract():
    spec = _fronting()
    jsonschema.Draft202012Validator(
        json.loads(_CONTRACT.read_text(encoding="utf-8"))
    ).validate(spec)


def test_no_routes_declared_changes_nothing():
    """Every spec written before this feature has no `routes`, and must be untouched."""
    spec = copy.deepcopy(_dog_village())
    before = copy.deepcopy(spec)
    assert allocate_frontage(spec, {}) == []
    assert spec == before


def test_a_wall_segment_anchor_does_not_yield_the_way_frontage_does():
    """The two kinds of anchor differ in authority, and the difference is load-bearing.

    Segment 7 of a run belongs between 6 and 8; moving it somewhere roomier would not
    be a compromise, it would be a different wall. So a segment with no frontage is
    honoured on every attempt and reported unplaced if the ground is genuinely taken.
    """
    from pcg.linear import expand_linear_structures

    spec = copy.deepcopy(_dog_village())
    spec["linear_structures"] = [
        {
            "structure_id": "lin_wall",
            "semantic_type": "dry_stone_wall",
            "source_text": "a village",
            "from_m": [-20.0, -40.0],
            "to_m": [20.0, -40.0],
            "height_m": 1.8,
            "thickness_m": 0.5,
            "asset": {
                "brief": "a dry stone wall segment",
                "category": "structure",
                "requires_animation": False,
                "preferred_source": "either",
                "procedural_type": "semantic_box",
            },
        }
    ]
    expand_linear_structures(spec)
    plan = generate_semantic_world_plan(spec)

    segments = [
        entity
        for entity in plan["entities"]
        if entity["entity_id"].startswith("ent_wall_s")
    ]
    # Every segment sits exactly where the run put it -- on the declared line, at
    # z = -40, not nudged onto easier ground.
    assert segments
    assert {round(entity["transform"]["position_m"][2], 2) for entity in segments} == {
        -40.0
    }
    assert all(
        math.isclose(entity["transform"]["rotation_y_degrees"], 0.0, abs_tol=0.01)
        for entity in segments
    )


def test_a_frontage_compromise_reaches_the_report_not_just_the_plan():
    """An honest record that nothing displays is honest to nobody (rules 11/13).

    `soft_relaxations` and `frontage_notes` have always been written onto the world
    plan and never surfaced anywhere a person looks -- the same gap `asset_tiers` had
    before the run page started reading it. A house that gave up its plot on the
    street is exactly the compromise somebody asked about, so the pipeline copies it
    into `spec["approximations"]`, which is what the report renders.

    Only frontage relaxations are copied. A `near` relaxation is a distance nobody
    stated in words, and reporting every one would bury the compromises that answer
    something the person actually described.
    """
    from worker.native_pipeline import frontage_approximations

    # Real plan data, from the pathological route that actually produces a yield.
    spec = _fronting(points_m=[-35.0, 0.0, 35.0, 0.0])
    plan = generate_semantic_world_plan(spec)
    records = frontage_approximations(plan)

    assert records, plan["constraint_summary"]
    assert all(record["user_visible"] for record in records)
    assert any("already occupied" in record["reason"] for record in records)

    # A `near` relaxation is a distance nobody stated in words, and lifting every one
    # would bury the compromises that answer something the person described. The claim
    # is that none leaks through, whether or not this particular plan produced any.
    assert not [
        record for record in records if "no position near" in record["reason"]
    ]
    assert len(records) <= len(plan["constraint_summary"]["soft_relaxations"]) + len(
        plan["constraint_summary"].get("frontage_notes") or []
    )
