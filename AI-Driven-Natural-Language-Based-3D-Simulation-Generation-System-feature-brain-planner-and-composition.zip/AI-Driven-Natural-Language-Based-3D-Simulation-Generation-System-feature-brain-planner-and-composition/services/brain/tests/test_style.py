"""Per-game style anchor: one coherent visual descriptor for all a game's assets."""

from agents.intent import parse_intent
from agents.style import BASE_STYLE, derive_style_anchor


def test_anchor_reflects_genre_and_lighting_and_is_deterministic():
    crypt = parse_intent("descend the torchlit crypts, skeletons everywhere")
    a1 = derive_style_anchor(crypt)
    a2 = derive_style_anchor(crypt)
    assert a1 == a2  # same brief -> same look (reproducible)
    assert "stone" in a1 and "torch" in a1 and BASE_STYLE in a1


def test_different_games_get_different_anchors():
    crypt = derive_style_anchor(parse_intent("a dark torchlit dungeon crawl"))
    meadow = derive_style_anchor(parse_intent("a bright sunny cheerful meadow to explore"))
    assert crypt != meadow
    assert "sunlight" in meadow or "cheerful" in meadow


def test_anchor_respects_the_schema_length_cap():
    for prompt in ("a huge arena battle", "a foggy survival escape", "collect relics in caves"):
        assert len(derive_style_anchor(parse_intent(prompt))) <= 200


def test_the_analyzer_sets_meta_style_anchor():
    import json
    from pathlib import Path

    from agents.chain import AgentContext, run_chain

    base = json.loads(
        (Path(__file__).resolve().parents[3] / "contracts" / "examples" / "golden_game.spec.json")
        .read_text("utf-8")
    )
    result = run_chain(base, AgentContext(prompt="a torchlit dungeon crawl", seed=7))
    anchor = result.spec["meta"]["style_anchor"]
    assert anchor and len(anchor) <= 200
    assert "stone" in anchor  # a dungeon look
