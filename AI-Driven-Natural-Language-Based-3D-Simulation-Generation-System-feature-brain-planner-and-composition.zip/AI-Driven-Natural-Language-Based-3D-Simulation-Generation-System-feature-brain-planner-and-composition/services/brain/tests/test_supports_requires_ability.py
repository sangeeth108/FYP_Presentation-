"""A requirement may only ask an entity to support what it could possibly do.

Measured on the frozen benchmark, `sim_farmyard`:

    requirement: ent_farmhouse  supports  'locomotion'

A farmhouse that walks. `behaviors.compiler` builds no graph for it -- correctly, a
building has no locomotion template -- so `requirement_traceability` raised
REQUIRED_BEHAVIOR_GRAPH_MISSING and the prompt failed. The gate was right; the requirement
was nonsense.

`_QUALIFIED_CONSUMERS` already held who may perform each qualified capability, and
`_reconcile_capabilities` already used it to withdraw a capability nothing can perform.
The knowledge simply was not applied to REQUIREMENTS.
"""

from agents.simulation_planner import (
    _a_supports_requirement_names_something_that_can as check,
)

FARMHOUSE = {"entity_id": "ent_farmhouse", "semantic_type": "farmhouse", "role": "prop"}
DOG = {"entity_id": "ent_dog", "semantic_type": "dog", "role": "controlled_agent"}
WALKS = {
    "requirement_id": "req_move",
    "predicate": "supports",
    "subject": "ent_farmhouse",
    "target": "locomotion",
}


def _subjects(candidate: dict) -> dict[str, str]:
    return {r["requirement_id"]: r["subject"] for r in candidate["requirements"]}


def test_it_moves_to_something_that_can() -> None:
    """A world with a dog almost certainly meant the dog. Intent is kept."""
    candidate = {"entities": [FARMHOUSE, DOG], "requirements": [dict(WALKS)]}
    check(candidate)
    assert _subjects(candidate)["req_move"] == "ent_dog"
    assert any("moved to" in a["reason"] for a in candidate["approximations"])


def test_it_is_withdrawn_when_nothing_can() -> None:
    candidate = {"entities": [FARMHOUSE], "requirements": [dict(WALKS)]}
    check(candidate)
    assert candidate["requirements"] == []
    assert any("withdrawn" in a["reason"] for a in candidate["approximations"])


def test_a_requirement_that_makes_sense_is_untouched() -> None:
    ok = {
        "requirement_id": "req_move",
        "predicate": "supports",
        "subject": "ent_dog",
        "target": "locomotion",
    }
    candidate = {"entities": [FARMHOUSE, DOG], "requirements": [dict(ok)]}
    check(candidate)
    assert _subjects(candidate) == {"req_move": "ent_dog"}
    assert not candidate.get("approximations")


def test_other_predicates_are_not_this_rule_s_business() -> None:
    exists = {
        "requirement_id": "req_exists",
        "predicate": "exists",
        "subject": "ent_farmhouse",
        "target": "",
    }
    candidate = {"entities": [FARMHOUSE], "requirements": [dict(exists)]}
    check(candidate)
    assert _subjects(candidate) == {"req_exists": "ent_farmhouse"}


def test_an_unqualified_capability_belongs_to_the_world() -> None:
    """`time_weather` has no per-entity qualification, so anything may support it."""
    ambient = {
        "requirement_id": "req_weather",
        "predicate": "supports",
        "subject": "ent_farmhouse",
        "target": "time_weather",
    }
    candidate = {"entities": [FARMHOUSE], "requirements": [dict(ambient)]}
    check(candidate)
    assert _subjects(candidate) == {"req_weather": "ent_farmhouse"}


def test_an_unknown_subject_is_left_to_its_own_gate() -> None:
    orphan = dict(WALKS, subject="ent_nothing")
    candidate = {"entities": [FARMHOUSE], "requirements": [orphan]}
    check(candidate)
    assert _subjects(candidate) == {"req_move": "ent_nothing"}
