import math

import pcg.placement as placement_module
import pytest
from pcg.layout import generate_layout
from pcg.placement import (
    SAFE_SPAWN_DISTANCE,
    WALL_MARGIN,
    EnemySpec,
    PropSpec,
    generate_placement,
)
from pcg.zone_graph import PCGError, generate_zone_graph

ENEMIES = [EnemySpec(enemy_id="castle_guard_shambler", count=5)]
PROPS = [
    PropSpec(prop_id="spawn_brazier", placement_tags=("spawn",)),
    PropSpec(prop_id="chest_01", placement_tags=("loot",)),
    PropSpec(prop_id="chest_02", placement_tags=("loot",)),
    PropSpec(prop_id="lever_gatehouse", placement_tags=("critical_path",)),
]


def _build(seed=4521, zone_count=8):
    graph = generate_zone_graph(seed=seed, zone_count=zone_count)
    layout = generate_layout(graph)
    return graph, layout


def test_a_maximal_cast_still_fits_in_a_minimal_level():
    """The schema's worst case: every budget maxed, the smallest possible level.

    Regression: the LLM authors far richer worlds than the rule parser (28
    entities vs 15), and two of the 20 frozen prompts died with a hard
    PCGError — 'no valid position for prop ... in any candidate zone'. Placement
    now spills props across zones and crowds spacing as a last resort, so a
    dense brief degrades into a busy room instead of losing the whole game.
    """
    crowd = [EnemySpec(enemy_id="horde", count=25)]  # budgets.max_enemies ceiling
    clutter = [
        PropSpec(prop_id=f"prop_{i:02d}", placement_tags=tag)
        for i, tag in enumerate(
            [("loot",)] * 6 + [("spawn",)] * 4 + [("critical_path",)] * 4
        )
    ]
    for algorithm in ("room_corridor", "bsp", "cellular_caves", "wfc_dressing"):
        for seed in range(15):
            graph = generate_zone_graph(
                seed=seed, zone_count=3, algorithm=algorithm, verticality_tiers=3
            )
            layout = generate_layout(graph)
            result = generate_placement(graph, layout, crowd, clutter)  # must not raise

            # Every prop lands (they spill across zones and may crowd).
            props = [e for e in result.entities if e.kind == "prop"]
            assert len(props) == len(clutter)

            # A 3-zone level has ONE room that is neither entry nor exit, and it
            # can be as small as 6x6 — which cannot hold 25 enemies at any legal
            # spacing. Playability outranks designer intent: cap the roster at
            # what physically fits, and say so. Never crash, never lie.
            enemies = [e for e in result.entities if e.kind == "enemy"]
            assert len(enemies) >= 20, f"{algorithm}/{seed}: only {len(enemies)} enemies fit"
            assert len(enemies) + sum(d["requested"] - d["placed"] for d in result.dropped) == 25
            for drop in result.dropped:
                assert drop["placed"] < drop["requested"]


def test_a_roomy_level_drops_nothing():
    graph, layout = _build(zone_count=12)
    result = generate_placement(
        graph, layout, [EnemySpec(enemy_id="horde", count=25)], list(PROPS)
    )
    assert result.dropped == []
    assert len([e for e in result.entities if e.kind == "enemy"]) == 25


def test_same_seed_same_placement():
    graph, layout = _build()
    a = generate_placement(graph, layout, ENEMIES, PROPS)
    b = generate_placement(graph, layout, ENEMIES, PROPS)
    assert a.entities == b.entities


def test_counts_and_ids():
    graph, layout = _build()
    result = generate_placement(graph, layout, ENEMIES, PROPS)
    enemies = [e for e in result.entities if e.kind == "enemy"]
    props = [e for e in result.entities if e.kind == "prop"]
    assert len(enemies) == 5
    assert len(props) == len(PROPS)
    assert {e.entity_id for e in enemies} == {
        f"castle_guard_shambler_{i:02d}" for i in range(1, 6)
    }
    assert len({e.entity_id for e in result.entities}) == len(result.entities)


def test_positions_inside_rooms_across_seeds():
    for seed in range(20):
        graph, layout = _build(seed=seed, zone_count=10)
        result = generate_placement(graph, layout, ENEMIES, PROPS)
        for entity in result.entities:
            rect = layout.rooms[entity.zone_id].rect
            assert rect.x + WALL_MARGIN <= entity.x <= rect.x + rect.width - WALL_MARGIN
            assert rect.z + WALL_MARGIN <= entity.z <= rect.z + rect.depth - WALL_MARGIN
            assert entity.elevation == layout.rooms[entity.zone_id].elevation


def test_enemies_respect_safe_spawn_distance_and_zone_rules():
    for seed in range(20):
        graph, layout = _build(seed=seed, zone_count=10)
        result = generate_placement(graph, layout, ENEMIES, PROPS)
        entry_id = next(z.zone_id for z in graph.zones if z.kind == "entry")
        exit_id = next(z.zone_id for z in graph.zones if z.kind == "exit")
        ex, ez = layout.rooms[entry_id].rect.center()
        for enemy in (e for e in result.entities if e.kind == "enemy"):
            assert enemy.zone_id not in (entry_id, exit_id)
            assert math.hypot(enemy.x - ex, enemy.z - ez) >= SAFE_SPAWN_DISTANCE


def test_prop_tags_route_to_matching_zones():
    graph, layout = _build()
    result = generate_placement(graph, layout, ENEMIES, PROPS)
    kinds = {z.zone_id: z.kind for z in graph.zones}
    by_id = {e.entity_id: e for e in result.entities}
    assert kinds[by_id["spawn_brazier"].zone_id] == "entry"
    loot_zones = [zid for zid, kind in kinds.items() if kind == "loot"]
    if loot_zones:
        assert by_id["chest_01"].zone_id in loot_zones
        assert by_id["chest_02"].zone_id in loot_zones
    assert kinds[by_id["lever_gatehouse"].zone_id] != "exit"


def test_placement_impossible_is_machine_readable(monkeypatch):
    monkeypatch.setattr(placement_module, "MAX_SAMPLE_ATTEMPTS", 0)
    graph, layout = _build()
    with pytest.raises(PCGError) as exc:
        generate_placement(graph, layout, ENEMIES, PROPS)
    err = exc.value.to_dict()
    assert err["code"] == "placement_impossible"
    assert err["hint"]
