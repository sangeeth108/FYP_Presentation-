import os
import subprocess
import sys
from pathlib import Path


def test_alembic_upgrade_and_downgrade_chain(tmp_path):
    brain = Path(__file__).parents[1]
    database = tmp_path / "migration-chain.db"
    env = {
        **os.environ,
        "DATABASE_URL": f"sqlite+pysqlite:///{database.as_posix()}",
    }
    upgrade = subprocess.run(
        [sys.executable, "-m", "alembic", "upgrade", "head"],
        cwd=brain,
        env=env,
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert upgrade.returncode == 0, upgrade.stderr
    downgrade = subprocess.run(
        [sys.executable, "-m", "alembic", "downgrade", "base"],
        cwd=brain,
        env=env,
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert downgrade.returncode == 0, downgrade.stderr
