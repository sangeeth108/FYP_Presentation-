"""The expand stage: think about the place in prose before formalising it.

The stage exists because one guided-JSON call did intake, design, sizing and
density in a single pass with nowhere to reason -- see DEFECTS_AND_DECISIONS #6.
These tests pin the properties that make it safe to add: it is an input and
never a dependency, it degrades rather than failing, and it never becomes a
second place where the world gets invented.
"""

from __future__ import annotations

import httpx
from agents.prompt_expander import expand_prompt


class _Settings:
    llm_timeout_seconds = 5


def _client(handler):
    """Patch httpx.Client so no network is touched."""
    class _Stub:
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def post(self, url, json=None):
            return handler(url, json)

    return _Stub


def _reply(content: str) -> httpx.Response:
    return httpx.Response(
        200,
        json={"message": {"content": content}},
        request=httpx.Request("POST", "http://test/api/chat"),
    )


_GOOD = (
    "A lowland tropical rainforest in south-west Sri Lanka shortly after dawn. "
    "The canopy is dominated by mature dipterocarps standing roughly 30 m tall "
    "with buttress roots two metres across, spaced about eight to ten metres "
    "apart so their crowns just touch. Beneath them tree ferns around 2 m high "
    "carpet most of the ground. " * 2
)


def test_an_expansion_is_returned_with_its_lineage(monkeypatch):
    monkeypatch.setattr(httpx, "Client", _client(lambda url, json: _reply(_GOOD)))
    result = expand_prompt(
        "a jungle", settings=_Settings(), model_id="qwen", base_url="http://x", seed=7
    )
    assert result is not None
    assert "dipterocarp" in result.description
    assert result.model_id == "qwen"
    payload = result.as_stage_payload()
    assert payload["characters"] == len(result.description)
    assert payload["duration_ms"] >= 0


def test_the_call_is_seeded_and_unconstrained(monkeypatch):
    """Seeded for reproducibility; NOT guided JSON, which is the whole point.

    Constraining this output to a schema would reintroduce the problem the
    stage exists to solve — the value is in reasoning before structure.
    """
    sent: dict = {}

    def handler(url, json):
        sent.update(json)
        return _reply(_GOOD)

    monkeypatch.setattr(httpx, "Client", _client(handler))
    expand_prompt(
        "a jungle", settings=_Settings(), model_id="qwen", base_url="http://x", seed=99
    )
    assert sent["options"]["seed"] == 99
    assert "format" not in sent, "expansion must not be schema-constrained"


def test_an_unavailable_model_is_not_fatal(monkeypatch):
    """Planning must still run from the raw prompt: an expansion is a bonus."""

    def handler(url, json):
        raise httpx.ConnectError("no model")

    monkeypatch.setattr(httpx, "Client", _client(handler))
    assert (
        expand_prompt(
            "a jungle", settings=_Settings(), model_id="qwen", base_url="http://x"
        )
        is None
    )


def test_a_useless_expansion_is_discarded(monkeypatch):
    """A refusal or an echo is worse than the prompt it replaced."""
    monkeypatch.setattr(httpx, "Client", _client(lambda url, json: _reply("a jungle.")))
    assert (
        expand_prompt(
            "a jungle", settings=_Settings(), model_id="qwen", base_url="http://x"
        )
        is None
    )


def test_no_model_configured_skips_silently():
    assert expand_prompt("a jungle", settings=_Settings(), model_id=None, base_url=None) is None
    assert expand_prompt("a jungle", settings=_Settings(), model_id="q", base_url=None) is None


def test_an_empty_prompt_is_not_expanded():
    assert (
        expand_prompt("   ", settings=_Settings(), model_id="q", base_url="http://x")
        is None
    )


def test_a_runaway_description_is_bounded(monkeypatch):
    """The planner's context must stay mostly schema."""
    monkeypatch.setattr(httpx, "Client", _client(lambda url, json: _reply("x" * 99_999)))
    result = expand_prompt(
        "a jungle", settings=_Settings(), model_id="qwen", base_url="http://x"
    )
    assert result is not None and len(result.description) == 4000


def test_planning_without_a_brief_is_unchanged():
    """The stage is additive: the old path must still be exactly the old path."""
    from agents.simulation_planner import plan_simulation

    spec, source = plan_simulation(
        prompt="explore a quiet village",
        simulation_id="sim_expand_test_0a1b2c3d",
        seed=11,
        size_profile="small",
        target_platforms=["web"],
        domain_constraints=None,
        settings=_Settings(),
    )
    assert source == "deterministic_fallback"
    assert spec["environment"]["semantic_type"] == "village"


def test_the_brief_reaches_the_planner_and_is_labelled(monkeypatch):
    """A planned spec must say it was planned from an expansion, for the ablation."""
    import agents.simulation_planner as planner

    captured: dict = {}

    def fake_llm_plan(prompt, draft, settings, *, planner_model_id, planner_base_url, brief=None):
        captured["brief"] = brief
        return draft

    monkeypatch.setattr(planner, "_llm_plan", fake_llm_plan)
    _, source = planner.plan_simulation(
        prompt="explore a quiet village",
        simulation_id="sim_expand_test_0a1b2c3d",
        seed=11,
        size_profile="small",
        target_platforms=["web"],
        domain_constraints=None,
        settings=_Settings(),
        planner_model_id="qwen",
        planner_base_url="http://x",
        brief="a described village",
    )
    assert captured["brief"] == "a described village"
    assert source == "llm_expanded"


def test_expand_is_the_first_declared_stage():
    """Ordering is the contract the inspector and the artifacts table rely on."""
    from core.stages import STAGE_ORDER, stage_ordinal

    assert STAGE_ORDER[0] == "expand"
    assert stage_ordinal("expand") < stage_ordinal("scene_spec")


def test_a_species_nobody_wants_any_of_is_dropped():
    """Zero density means "not this kind" — keeping it costs a real asset build.

    Expanded runs emitted density 0 for several species. The range clamp would
    otherwise lift 0 to the exclusive minimum and preserve a species that can
    never place an instance, while still paying to generate its mesh.
    """
    from agents.simulation_planner import _drop_empty_species

    candidate = {
        "scatter": [
            {"species_id": "spc_real", "density_per_100m2": 4.0},
            {"species_id": "spc_none", "density_per_100m2": 0},
            {"species_id": "spc_alsonone", "density_per_100m2": 0.0},
        ]
    }
    dropped = _drop_empty_species(candidate)
    assert dropped == ["spc_none", "spc_alsonone"]
    assert [s["species_id"] for s in candidate["scatter"]] == ["spc_real"]


def test_a_healthy_scatter_list_is_untouched():
    from agents.simulation_planner import _drop_empty_species

    candidate = {"scatter": [{"species_id": "spc_a", "density_per_100m2": 1.0}]}
    assert _drop_empty_species(candidate) == []
    assert len(candidate["scatter"]) == 1


def test_expansion_is_a_runtime_toggle_for_the_ablation():
    """Both arms must be reproducible on one build, not one branch."""
    from core.config import Settings

    assert hasattr(Settings(), "expand_enabled")
