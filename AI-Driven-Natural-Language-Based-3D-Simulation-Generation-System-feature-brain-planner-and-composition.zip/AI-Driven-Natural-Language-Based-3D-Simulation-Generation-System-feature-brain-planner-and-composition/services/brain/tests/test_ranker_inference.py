import json

import pytest
from learning.rankers import _tree_digest, load_ranker_artifact


def test_json_ranker_is_digest_bound_and_never_executes_code(tmp_path):
    body = {
        "format": "serendib_pairwise_linear_v1",
        "target": "asset_ranker",
        "feature_names": ["semantic_keyword_score", "curated"],
        "weights": [2.0, 0.5],
        "hard_constraints_must_be_pre_filtered": True,
    }
    (tmp_path / "ranker.json").write_text(json.dumps(body), encoding="utf-8")
    digest = _tree_digest(tmp_path)
    ranker = load_ranker_artifact(
        tmp_path,
        expected_target="asset_ranker",
        expected_digest=digest,
        model_version_id="model_test",
    )
    assert ranker.score({"semantic_keyword_score": 0.75, "curated": True}) == 2.0

    body["weights"] = [200.0, 0.5]
    (tmp_path / "ranker.json").write_text(json.dumps(body), encoding="utf-8")
    with pytest.raises(ValueError, match="digest verification"):
        load_ranker_artifact(
            tmp_path,
            expected_target="asset_ranker",
            expected_digest=digest,
            model_version_id="model_test",
        )
