"""Ablation conditions A–F (eval/README.md).

The dissertation's claim is that reliability comes from the ARCHITECTURE, not
the model. An ablation tests that instead of asserting it — same frozen prompts,
same pipeline, one thing removed.

These tests guard the two ways an ablation study silently becomes worthless:
a condition that runs different code from the product, and a result whose seeds
or prompt-set version were not recorded.
"""

import inspect
import json
import sys
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO / "eval"))
sys.path.insert(0, str(REPO / "services" / "worker"))

from ablation_runners.conditions import CONDITIONS, runnable  # noqa: E402
from ablation_runners.run_ablation import SEEDS, _seed_for, run_condition  # noqa: E402
from run_benchmark import _run_one  # noqa: E402


def test_every_condition_from_the_plan_exists():
    # eval/README.md names A-F. R is the control the plan implies but doesn't letter.
    assert set("ABCDEF") <= set(CONDITIONS)
    for cond in CONDITIONS.values():
        # An arm exists to ask something. (Not `endswith("?")` — several questions
        # carry a trailing research-question tag, e.g. "...controllability? (RQ3)".)
        assert "?" in cond.question, cond.id
        assert cond.label


def test_a_toggle_must_be_something_the_real_pipeline_accepts():
    """The whole point: an ablation is the PRODUCT with one thing changed.

    A typo'd toggle would fork the study from the product at runtime, hours into
    a GPU run. Check it against `_run_one`'s actual signature instead.
    """
    allowed = set(inspect.signature(_run_one).parameters) - {"entry"}
    for cond in CONDITIONS.values():
        unknown = set(cond.toggles) - allowed
        assert not unknown, f"{cond.id} has toggles the pipeline cannot take: {unknown}"


def test_the_banned_arms_are_declared_unrunnable_not_quietly_missing():
    # A and F need free LLM generation, which rule 10 permanently bans. They must
    # be visible as EXTERNAL baselines, not silently absent — a reader has to see
    # that we know they belong in the study.
    for cond_id in ("A", "F"):
        cond = CONDITIONS[cond_id]
        assert cond.external and not cond.is_runnable()
        assert cond.requires  # says WHY, and what would unblock it


def test_the_tuned_arm_tracks_whether_the_model_is_actually_served(monkeypatch):
    """E is gated on the model existing, in BOTH directions.

    This used to assert `not is_runnable()` outright, which was true only while
    the weights did not exist. Once the QLoRA arm was trained and served, the
    test failed for the one reason a test should never fail: the world improved.
    The property worth pinning is not the answer but the coupling, so the server
    is stubbed and both answers are checked.
    """
    import ablation_runners.conditions as conditions

    monkeypatch.setattr(conditions, "_ollama_serves", lambda model: False)
    assert not CONDITIONS["E"].is_runnable()

    monkeypatch.setattr(conditions, "_ollama_serves", lambda model: True)
    assert CONDITIONS["E"].is_runnable()

    # The arm must still say what it needs, so a reader who sees it skipped
    # learns how to unblock it rather than that it is broken.
    assert "FINE_TUNING" in CONDITIONS["E"].requires


def test_the_runnable_set_is_what_we_can_actually_run_today(monkeypatch):
    """The arms that need no model are always runnable; the banned ones never.

    Pinning the exact set made this depend on what the local Ollama happened to
    hold, so it broke on the machine that had the tuned model and passed on the
    one that did not. Membership is asserted against the reason for membership.
    """
    import ablation_runners.conditions as conditions

    monkeypatch.setattr(conditions, "_ollama_serves", lambda model: False)
    without_tuned = {c.id for c in runnable()}
    assert without_tuned == {"B", "C", "D", "R"}

    monkeypatch.setattr(conditions, "_ollama_serves", lambda model: True)
    assert {c.id for c in runnable()} == {"B", "C", "D", "E", "R"}

    # A and F are external baselines and are never runnable in-product, whatever
    # any model server holds.
    assert not ({"A", "F"} & {c.id for c in runnable()})


def test_the_product_path_is_one_of_the_arms():
    # C must be the shipped defaults, or the study compares against a stranger.
    c = CONDITIONS["C"].toggles
    assert c["repair"] is True and c["use_llm"] is True


def test_seeds_are_fixed_and_distinct_per_replicate():
    # "3 seeds" must mean the SAME three every time, or nothing reproduces.
    assert SEEDS == (0, 1, 2)
    entry = {"seed": 1001}
    got = [_seed_for(entry, r) for r in SEEDS]
    assert got == [1001, 11001, 21001]
    assert len(set(got)) == 3
    assert [_seed_for(entry, r) for r in SEEDS] == got  # deterministic


def test_a_blocked_condition_refuses_loudly(monkeypatch):
    """A condition that cannot run must exit saying so, not return empty results.

    Stubbed unrunnable rather than relying on E genuinely being blocked: E is
    served on the development machine now, so the real arm runs and the refusal
    path went untested exactly when it started to matter.
    """
    import ablation_runners.conditions as conditions

    monkeypatch.setattr(conditions, "_ollama_serves", lambda model: False)
    with pytest.raises(SystemExit, match="cannot run yet"):
        run_condition("E", seeds=1, full=False)


def test_the_control_arm_runs_and_records_what_makes_it_reproducible():
    result = run_condition("R", seeds=1, full=False)
    s = result["summary"]
    assert s["runs"] == 20 and s["condition"] == "R"
    # Without these a result is unusable in a dissertation (eval/README.md).
    assert s["prompt_set_version"] and s["seeds"] == [0]
    assert s["ran_at"] and "toggles" in s
    assert 0.0 <= s["pass_rate"] <= 1.0
    assert len(result["rows"]) == 20
    assert all("replicate" in r for r in result["rows"])
    assert json.loads(json.dumps(result)) == result  # serialisable as-is


def test_the_control_arm_never_reports_llm_results():
    # R has no planner: if this ever shows llm_planned > 0 the arms are crossed.
    s = run_condition("R", seeds=1, full=False)["summary"]
    assert s["llm_planned"] == 0
    assert s["llm_fallbacks"] == 0  # not an LLM arm, so a fallback is not a thing


def test_an_llm_arm_counts_silent_fallbacks_as_a_warning_not_a_result(monkeypatch):
    """A dead planner must never be reported as an LLM finding.

    Every LLM entry point is stubbed to None here — a dead planner, exactly what
    an unplugged GPU looks like. Condition C's runs then fall back to rules, and
    the summary has to SAY so rather than quietly publishing rules numbers under
    an LLM label. This is the exact failure that once made a benchmark claim
    20/20 while 0/20 had actually been planned by the LLM.

    (Stubbed, not merely "unreachable": Ollama really is running on this box, so
    an un-stubbed C arm would make 60 live calls and take minutes.)
    """
    import agents.chain as chain

    for entry_point in ("llm_brief", "llm_objective", "llm_entities"):
        monkeypatch.setattr(chain, entry_point, lambda *a, **k: None)
    # Skip the VRAM warmup: it calls the planner directly (not via chain), so a
    # dead-planner test would otherwise make one real ~95s call. The warmup is
    # best-effort by design; this test is about the fallback COUNT, not warmup.
    import ablation_runners.run_ablation as ra

    monkeypatch.setattr(ra, "_warm_up_planner", lambda: None)

    s = run_condition("C", seeds=1, full=False)["summary"]
    assert s["runs"] == 20
    assert s["llm_planned"] == 0  # the planner was dead...
    assert s["llm_fallbacks"] == 20  # ...and every single run says so
    assert s["llm_planned"] + s["llm_fallbacks"] == s["runs"]


# --- compare.py: runs -> a defensible results table ------------------------


def _arm(cond_id, verdicts, latencies, replicate=0):
    """A minimal arm payload shaped like a real run."""
    return {
        "summary": {"condition": cond_id, "label": f"arm {cond_id}", "question": "does it?"},
        "rows": [
            {
                "prompt_id": f"p{i:02d}",
                "replicate": replicate,
                "verdict": v,
                "schema_valid": True,
                "genre_match": True,
                "latency_ms": lat,
            }
            for i, (v, lat) in enumerate(zip(verdicts, latencies, strict=True))
        ],
    }


def test_two_identical_arms_produce_no_significant_difference():
    """The null case, and the sharpest test of the harness.

    A study that finds a difference between two identical things is broken, and
    would have found "results" in this project's own smoke run.
    """
    from ablation_runners.compare import compare

    verdicts = ["PASS"] * 18 + ["FAIL"] * 2
    lat = [10.0 + i for i in range(20)]
    arms = {"R": _arm("R", verdicts, lat), "B": _arm("B", verdicts, lat)}
    report = compare(arms, "R")
    for metric in report["comparisons"]["B"]["metrics"].values():
        assert metric["p_value"] == 1.0
        assert not metric["holm"]["significant"]
        assert metric["magnitude"] == "negligible"


def test_a_real_difference_is_found():
    from ablation_runners.compare import compare

    good = ["PASS"] * 20
    bad = ["FAIL"] * 20
    lat = [10.0] * 20
    arms = {"R": _arm("R", bad, lat), "B": _arm("B", good, lat)}
    report = compare(arms, "R")
    passed = report["comparisons"]["B"]["metrics"]["passed"]
    assert passed["p_value"] < 0.001  # 20 discordant pairs, all one way
    assert passed["mean_arm"] == 1.0 and passed["mean_baseline"] == 0.0


def test_binary_metrics_use_mcnemar_and_continuous_use_wilcoxon():
    # The choice of test per metric is the thing most likely to be got wrong
    # silently, and the thing that most changes the conclusion.
    from ablation_runners.compare import compare

    arms = {
        "R": _arm("R", ["PASS"] * 15 + ["FAIL"] * 5, [10.0] * 20),
        "B": _arm("B", ["PASS"] * 19 + ["FAIL"] * 1, [12.0] * 20),
    }
    m = compare(arms, "R")["comparisons"]["B"]["metrics"]
    assert m["passed"]["test"] == "mcnemar_exact"
    assert m["schema_valid"]["test"] == "mcnemar_exact"
    assert m["genre_match"]["test"] == "mcnemar_exact"  # binary: paired yes/no per prompt
    assert m["latency_ms"]["test"] == "wilcoxon"


def test_arms_that_share_no_prompts_are_refused_not_silently_compared():
    # Comparing different prompt sets measures the prompt sets.
    from ablation_runners.compare import compare

    a = _arm("R", ["PASS"] * 3, [1.0, 2.0, 3.0], replicate=0)
    b = _arm("B", ["PASS"] * 3, [1.0, 2.0, 3.0], replicate=9)  # different seeds
    with pytest.raises(SystemExit, match="share no"):
        compare({"R": a, "B": b}, "R")


def test_pairing_is_by_prompt_and_seed_even_when_rows_are_shuffled():
    from ablation_runners.compare import compare

    verdicts = ["PASS"] * 10 + ["FAIL"] * 10
    lat = [float(i) for i in range(20)]
    a = _arm("R", verdicts, lat)
    b = _arm("B", verdicts, lat)
    b["rows"] = list(reversed(b["rows"]))  # same data, different order
    m = compare({"R": a, "B": b}, "R")["comparisons"]["B"]["metrics"]
    assert m["latency_ms"]["p_value"] == 1.0  # correctly paired -> zero differences


def test_every_comparison_in_a_report_is_one_holm_family():
    from ablation_runners.compare import compare

    lat = [10.0] * 20
    arms = {
        "R": _arm("R", ["PASS"] * 20, lat),
        "B": _arm("B", ["PASS"] * 20, lat),
        "C": _arm("C", ["PASS"] * 20, lat),
    }
    report = compare(arms, "R")
    # 2 arms x 4 metrics (passed, schema_valid, genre_match, latency): correcting
    # each arm separately would inflate the family-wise error rate as the plan warns.
    assert report["family_size"] == 8


def test_an_unknown_baseline_fails_loudly():
    from ablation_runners.compare import compare

    with pytest.raises(SystemExit, match="baseline"):
        compare({"R": _arm("R", ["PASS"], [1.0])}, "Z")


# --- alternate prompt sets (v2 adversarial) --------------------------------


def test_runner_accepts_an_alternate_prompt_set():
    # The runner must load a given set, not just v1 — or v2 can't be studied.
    from pathlib import Path

    v2 = Path(__file__).resolve().parents[3] / "eval" / "benchmark_prompts" / "v2_ambiguous.json"
    result = run_condition("R", seeds=1, full=False, prompts_path=v2)
    assert result["summary"]["prompt_set_version"] == "2.0.0-ambiguous"
    assert result["summary"]["runs"] == 12


def test_v2_is_genuinely_adversarial_to_the_rules_parser():
    """The set only means something if rules mode mislabels it.

    v2 exists to break the genre ceiling: if the deterministic parser scored well
    on it, it wouldn't separate the arms. Rules mode should get most WRONG (they
    fall to the collect_explore default or trip a misleading keyword).
    """
    from pathlib import Path

    v2 = Path(__file__).resolve().parents[3] / "eval" / "benchmark_prompts" / "v2_ambiguous.json"
    s = run_condition("R", seeds=1, full=False, prompts_path=v2)["summary"]
    # verified by construction: 11/12 wrong -> at most ~2 genre matches
    assert s["genre_matched"] <= 3, "v2 is supposed to defeat the keyword parser"
