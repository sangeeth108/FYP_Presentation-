"""The player has a body (spec v2.1.0 `player.asset_brief`).

Before this, "as a dog, explore the village" was unrepresentable: the spec had
no field for WHO the player is, so every player was an untextured capsule no
matter what the prompt said. Deciding that from free text is exactly the
ambiguity the planner exists for, so only the LLM path sets it — rules mode
stays byte-identical to the legacy builder.
"""

import json
from pathlib import Path

import httpx
import pytest
from agents.content_designer import entities_schema, llm_entities, sanitize
from agents.intent import parse_intent
from jsonschema import Draft202012Validator

SCHEMA = json.loads(
    (Path(__file__).resolve().parents[3] / "contracts" / "game_spec.schema.json").read_text(
        encoding="utf-8"
    )
)


class _Settings:
    llm_base_url = "http://mock"
    llm_model = "qwen3.6:27b"
    llm_timeout_seconds = 5.0


def _transport(payload) -> httpx.MockTransport:
    content = payload if isinstance(payload, str) else json.dumps(payload)

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"message": {"content": content}})

    return httpx.MockTransport(handler)


def _prop(prop_id: str) -> dict:
    return {
        "prop_id": prop_id,
        "interactable_template_id": "chest_lidded",
        "placement_tags": ["loot"],
        "asset_brief": {"brief": "a mossy crate", "category": "prop", "tri_budget": 800},
    }


def _authored(player_brief=None, enemies=None) -> dict:
    out = {
        "props": [_prop(f"crate_{i:02d}") for i in range(5)],
        "enemies": enemies
        if enemies is not None
        else [
            {
                "enemy_id": "angry_goose",
                "ai_template_id": "ai_patrol_chase",
                "count": 3,
                "stats": {"health": 5, "damage": 1, "speed": 3},
                "asset_brief": {
                    "brief": "a furious goose",
                    "category": "character",
                    "tri_budget": 8000,
                },
            }
        ],
    }
    if player_brief is not None:
        out["player_brief"] = player_brief
    return out


# --- the contract ---------------------------------------------------------


def test_the_guided_schema_forces_the_model_to_answer_who_the_player_is():
    schema = entities_schema()
    assert "player_brief" in schema["required"]
    assert schema["properties"]["player_brief"]["properties"]["brief"]["maxLength"] == 200


def test_a_player_body_is_valid_under_v2_1_and_absent_is_still_valid():
    v = Draft202012Validator(SCHEMA)
    base = json.loads(
        (
            Path(__file__).resolve().parents[3] / "contracts" / "examples" / "golden_game.spec.json"
        ).read_text(encoding="utf-8")
    )
    assert not list(v.iter_errors(base))  # N-1: untouched 2.0.0 spec still valid

    dog = json.loads(json.dumps(base))
    dog["schema_version"] = "2.1.0"
    dog["player"]["asset_brief"] = {
        "brief": "a scruffy low-poly village dog",
        "category": "character",
        "tri_budget": 8000,
    }
    assert not list(v.iter_errors(dog))


# --- the planner ----------------------------------------------------------


def test_the_prompts_character_becomes_the_players_body():
    brief = parse_intent("as a dog, explore the sleepy village")
    out = llm_entities(
        "as a dog, explore the sleepy village",
        brief,
        _Settings(),
        transport=_transport(
            _authored({"brief": "a scruffy village dog, floppy ears", "category": "character",
                       "tri_budget": 7000})
        ),
    )
    assert out is not None
    assert out["player_brief"]["brief"] == "a scruffy village dog, floppy ears"
    assert out["player_brief"]["category"] == "character"


def test_a_player_is_always_a_character_whatever_the_model_claims():
    brief = parse_intent("explore the village")
    out = llm_entities(
        "explore the village", brief, _Settings(),
        transport=_transport(
            _authored({"brief": "a dog", "category": "prop", "tri_budget": 900})
        ),
    )
    assert out["player_brief"]["category"] == "character"


def test_an_absurd_tri_budget_is_clamped_not_trusted():
    brief = parse_intent("explore the village")
    out = llm_entities(
        "explore the village", brief, _Settings(),
        transport=_transport(
            _authored({"brief": "a dog", "category": "character", "tri_budget": 999999})
        ),
    )
    assert out["player_brief"]["tri_budget"] == 20000


@pytest.mark.parametrize(
    "bad",
    [
        None,                                          # omitted entirely
        {"brief": "x", "category": "character"},       # too short
        {"brief": " " * 10, "category": "character"},  # whitespace only
        {"category": "character"},                     # no text at all
        "a dog",                                       # not even an object
    ],
)
def test_a_missing_or_junk_body_costs_the_player_a_body_but_never_the_game(bad):
    # Hard-failing here would throw away the props and enemies too. The capsule
    # is a working fallback; the rest of the world is not worth losing over it.
    brief = parse_intent("explore the village")
    authored = _authored()
    if bad is not None:
        authored["player_brief"] = bad
    out = llm_entities("explore the village", brief, _Settings(), transport=_transport(authored))
    assert out is not None
    assert out["props"]  # the world survived
    assert "player_brief" not in out


def test_sanitize_keeps_the_body_out_when_the_world_itself_is_rejected():
    # Too sparse to be a world -> None overall, body included.
    brief = parse_intent("explore the village")
    sparse = {"props": [_prop("only_one")], "enemies": [],
              "player_brief": {"brief": "a dog", "category": "character"}}
    assert sanitize(sparse, brief) is None


# --- the chain ------------------------------------------------------------

REPO = Path(__file__).resolve().parents[3]
BASE = json.loads(
    (REPO / "contracts" / "examples" / "golden_game.spec.json").read_text(encoding="utf-8")
)


@pytest.fixture
def offline_chain(monkeypatch):
    """llm_enabled with every LLM entry point stubbed. Without this the other
    agents dial a real planner and the test hangs on their timeouts."""
    import agents.chain as chain

    monkeypatch.setattr(chain, "llm_brief", lambda *a, **k: None)  # keep the rules brief
    monkeypatch.setattr(chain, "llm_objective", lambda *a, **k: None)  # keep reach_zone
    monkeypatch.setattr(chain, "search", lambda *a, **k: [])  # no RAG lookup
    return chain


def test_the_chain_puts_the_body_in_the_spec_and_bumps_the_version(offline_chain, monkeypatch):
    chain = offline_chain
    monkeypatch.setattr(
        chain,
        "llm_entities",
        lambda *a, **k: _authored(
            {"brief": "a scruffy village dog", "category": "character", "tri_budget": 7000}
        ),
    )
    result = chain.run_chain(
        BASE, chain.AgentContext(prompt="as a dog, explore the village", seed=7, llm_enabled=True)
    )
    assert result.spec["player"]["asset_brief"]["brief"] == "a scruffy village dog"
    # A spec that uses a v2.1 field must SAY it is v2.1, or the record lies.
    assert result.spec["schema_version"] == "2.1.0"
    Draft202012Validator(SCHEMA).validate(result.spec)


def test_a_body_the_planner_declined_leaves_the_version_alone(offline_chain, monkeypatch):
    chain = offline_chain
    monkeypatch.setattr(chain, "llm_entities", lambda *a, **k: _authored())  # no player_brief
    result = chain.run_chain(
        BASE, chain.AgentContext(prompt="explore the village", seed=7, llm_enabled=True)
    )
    assert "asset_brief" not in result.spec["player"]
    assert result.spec["schema_version"] == "2.0.0"
    Draft202012Validator(SCHEMA).validate(result.spec)


def test_rules_mode_never_invents_a_body():
    # "as a dog" is free text: reading it is the planner's job, not a regex's.
    # Rules mode must stay byte-identical to the legacy builder.
    import agents.chain as chain

    result = chain.run_chain(
        BASE, chain.AgentContext(prompt="as a dog, explore the village", seed=7)
    )
    assert "asset_brief" not in result.spec["player"]
    assert result.spec["schema_version"] == "2.0.0"
