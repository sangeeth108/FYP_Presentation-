"""The trim measures placed entities, and a wood is not its entities.

The world is trimmed to the reach of what placement solved -- right for a village, which
once shipped 23 m of content on a 73 m slab and read as an empty plain. A forest spec had
six entities and 1,295 scattered things, so it trimmed to 37x27 m and the canopy hit its
packing limit at four trees:

    spc_canopy_tree: requested 26, placed 4,
                     shortfall_reason "packing_limit", spacing_m 11.2996

An 11 m crown is a real mature tree, so 999 m2 holds about eight however they are
sampled. The world was the constraint, not the sampler.
"""

from pcg.semantic import _ground_the_scatter_needs

_CANOPY = {
    "species_id": "spc_canopy_tree",
    "density_per_100m2": 2.667,
    "size_m": [5.0, 12.0, 5.0],
}
_LITTER = {
    "species_id": "spc_leaf_litter",
    "density_per_100m2": 500,
    "size_m": [0.05, 0.15, 0.05],
}
# The crown as the sampler actually measured it from the resolved asset.
_MEASURED = {"spc_canopy_tree": {"world_dimensions_m": [11.2996, 20.0, 11.2996]}}


def test_the_measured_crown_beats_the_declared_one() -> None:
    """The spec declares a 5 m crown; the resolved asset measures 11.3 m across.

    Sizing the world from the declaration would ask for a quarter of the ground the
    sampler then needs, and the shortfall shows up as `packing_limit` rather than as
    anything the spec could be blamed for.
    """
    from_declared = _ground_the_scatter_needs({"scatter": [_CANOPY, _LITTER]}, {})
    by_footprint = _ground_the_scatter_needs({"scatter": [_CANOPY, _LITTER]}, _MEASURED)

    assert from_declared < by_footprint / 4
    assert by_footprint > 1000
    # Enough ground for the eight the rule asks for, at the spacing the sampler uses AND
    # the yield it actually achieves. Measured on two runs at this exact spacing:
    # 999 m2 gave 4 trees and 1,586 m2 gave 6 -- about half of ideal packing both times.
    assert by_footprint * 0.5 / (11.2996**2) >= 7.5


def test_ground_cover_asks_for_almost_nothing() -> None:
    """Litter packs at 5 cm; it is never what makes a world too small."""
    assert _ground_the_scatter_needs({"scatter": [_LITTER]}, {}) < 50


def test_a_species_capped_to_be_rare_asks_for_nothing_extra() -> None:
    rare = {"species_id": "spc_fox", "density_per_100m2": 0.5, "max_instances": 2,
            "size_m": [0.9, 0.4, 0.3]}
    assert _ground_the_scatter_needs({"scatter": [rare]}, {}) <= 400


def test_a_world_without_scatter_asks_for_nothing() -> None:
    assert _ground_the_scatter_needs({}, {}) == 0.0
    assert _ground_the_scatter_needs({"scatter": []}, {}) == 0.0


def test_only_structural_species_have_an_opinion() -> None:
    """Detail packs into whatever ground there is; it never sizes a world.

    Taking the largest need over ALL species asked a classroom corner to grow from 64 m2
    to 800 m2, because one species at 0.5 per 100 m2 -- deliberately sparse -- "needed"
    1,600 m2 to show eight of itself. Across the 82 stored specs carrying scatter that
    floor bound on 56 (68%); restricted to structural species it binds on 12 (15%).
    """
    sparse_detail = {
        "species_id": "spc_pencil",
        "density_per_100m2": 0.5,
        "size_m": [0.02, 0.01, 0.18],
    }
    assert _ground_the_scatter_needs({"scatter": [sparse_detail]}, {}) == 0.0

    # ...while something too big to pack still speaks up.
    boulder = {"species_id": "spc_boulder", "density_per_100m2": 1.0,
               "size_m": [4.0, 3.0, 4.0]}
    assert _ground_the_scatter_needs({"scatter": [boulder]}, {}) > 0.0
