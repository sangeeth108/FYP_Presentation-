"""Repair loop v1: classification -> localized action, deterministic fixes,
seed re-roll, monotonic-progress + cap discipline."""

import json
from pathlib import Path

from repair.loop import (
    MAX_ATTEMPTS_PER_CLASS,
    deterministic_spec_fixes,
    level_reroll_seed,
    responsible_action,
)

REPO = Path(__file__).resolve().parents[3]
GOLDEN_SPEC = json.loads(
    (REPO / "contracts" / "examples" / "golden_game.spec.json").read_text(encoding="utf-8")
)


def test_class_routes_to_the_responsible_node():
    assert responsible_action("schema", 1) == "fix_spec_deterministically"
    assert responsible_action("logic", 1) == "reroll_level_seed"
    assert responsible_action("build", 1) == "reexport"
    assert responsible_action("build", 2) == "drop_kit_models"  # escalates
    assert responsible_action("asset", 1) == "curated_substitute"
    assert responsible_action("quality", 1) == "none"  # advisory, never repaired


def test_level_reroll_is_deterministic_and_disjoint():
    assert level_reroll_seed(4521, 1) == level_reroll_seed(4521, 1)  # reproducible
    seeds = {level_reroll_seed(4521, a) for a in range(1, MAX_ATTEMPTS_PER_CLASS + 1)}
    assert len(seeds) == MAX_ATTEMPTS_PER_CLASS  # each attempt a distinct level
    assert 4521 not in seeds  # never the original (which already failed)


def test_deterministic_fix_camera_controller_mismatch():
    spec = json.loads(json.dumps(GOLDEN_SPEC))
    spec["meta"]["camera"] = "isometric_3d"
    spec["player"]["controller_template_id"] = "controller_third_person"  # wrong
    fixes = deterministic_spec_fixes(
        spec, [{"code": "CAMERA_CONTROLLER_MISMATCH"}]
    )
    assert "controller_locked_to_camera" in fixes
    assert spec["player"]["controller_template_id"] == "controller_isometric_3d"


def test_deterministic_fix_enemy_budget():
    spec = json.loads(json.dumps(GOLDEN_SPEC))
    spec["budgets"]["max_enemies"] = 4
    spec["entities"]["enemies"][0]["count"] = 20
    fixes = deterministic_spec_fixes(spec, [{"code": "ENEMY_BUDGET_EXCEEDED"}])
    assert "enemy_counts_clamped_to_budget" in fixes
    assert sum(e["count"] for e in spec["entities"]["enemies"]) <= 4


def test_an_over_ambitious_hunt_is_clamped_to_what_the_level_can_hold():
    """A collect goal asking for 8 relics in a level that can only fit 5.

    Re-rolling the whole world three times and then failing the job over the
    eighth relic is the wrong answer — ask for what is actually there. The gate
    hands the repairer the numbers (`data`), so it never has to parse a message.
    """
    spec = json.loads(json.dumps(GOLDEN_SPEC))
    spec["objectives"] = [
        {
            "objective_id": "collect_relics",
            "objective_template_id": "collect_n",
            "params": {"required_count": 8, "label": "Relics"},
            "is_win_condition": False,
        },
        GOLDEN_SPEC["objectives"][-1],
    ]
    fixes = deterministic_spec_fixes(
        spec, [{"code": "COLLECT_QUEST_IMPOSSIBLE", "data": {"required": 8, "placed": 5}}]
    )
    assert "collect_count_clamped_to_placed_pickups" in fixes
    assert spec["objectives"][0]["params"]["required_count"] == 5


def test_a_hunt_with_nothing_placed_is_not_silently_reduced_to_zero():
    """placed=0 has no honest repair — a 0-relic hunt would 'win' instantly."""
    spec = json.loads(json.dumps(GOLDEN_SPEC))
    spec["objectives"] = [
        {
            "objective_id": "collect_relics",
            "objective_template_id": "collect_n",
            "params": {"required_count": 4, "label": "Relics"},
            "is_win_condition": False,
        },
        GOLDEN_SPEC["objectives"][-1],
    ]
    fixes = deterministic_spec_fixes(
        spec, [{"code": "COLLECT_QUEST_IMPOSSIBLE", "data": {"required": 4, "placed": 0}}]
    )
    assert fixes == []
    assert spec["objectives"][0]["params"]["required_count"] == 4  # untouched


def test_unfixable_error_returns_no_fixes():
    spec = json.loads(json.dumps(GOLDEN_SPEC))
    assert deterministic_spec_fixes(spec, [{"code": "SPEC_SCHEMA_VIOLATION"}]) == []
