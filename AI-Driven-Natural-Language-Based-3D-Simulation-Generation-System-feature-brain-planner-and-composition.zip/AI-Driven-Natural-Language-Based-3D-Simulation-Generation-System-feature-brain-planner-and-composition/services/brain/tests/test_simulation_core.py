"""Neutral simulation contract, compatibility compiler, and canonical API."""

from __future__ import annotations

import json

from agents.simulation_planner import (
    apply_localized_edit,
    ollama_simulation_schema,
    plan_simulation,
    validate_simulation_spec,
)
from assets.descriptors import descriptors_from_simulation_manifest
from compatibility.simulation_game_adapter import compile_to_legacy_game
from core import db as db_module
from core.config import get_settings
from core.models import GenerationRun, SimulationArtifact
from core.validation_contract import MANDATORY_VALIDATION_LAYERS


def _dog_village(size="small"):
    return plan_simulation(
        prompt="as a dog explore the village",
        simulation_id="sim_dog_village_deadbeef",
        seed=42,
        size_profile=size,
        target_platforms=["web", "desktop"],
        domain_constraints={},
        settings=get_settings(),
    )[0]


def test_neutral_spec_models_a_simulation_not_a_game():
    spec = _dog_village()
    validate_simulation_spec(spec)
    assert "objectives" not in spec
    assert "enemies" not in spec
    assert spec["entities"][0]["semantic_type"] == "dog"
    assert spec["entities"][0]["asset"]["requires_animation"] is True
    assert "animal" in spec["capabilities"]
    houses = [entity for entity in spec["entities"] if entity["semantic_type"] == "house"]
    doors = [
        entity
        for entity in spec["entities"]
        if entity["semantic_type"] == "hinged_wooden_door"
    ]
    assert houses and len(doors) == len(houses)
    assert all("openable" not in house["capabilities"] for house in houses)
    assert all(door["capabilities"] == ["openable"] for door in doors)
    attachments = [
        relation
        for relation in spec["spatial_relations"]
        if relation["relation"] == "attached_to"
    ]
    assert {item["subject_id"] for item in attachments} == {
        door["entity_id"] for door in doors
    }
    assert all(requirement["observable"] for requirement in spec["requirements"])


def test_living_village_has_autonomous_measured_asset_candidates():
    spec = plan_simulation(
        prompt="as a dog explore a living village",
        simulation_id="sim_living_village_deadbeef",
        seed=42,
        size_profile="small",
        target_platforms=["web", "desktop"],
        domain_constraints={},
        settings=get_settings(),
    )[0]
    residents = [
        entity for entity in spec["entities"] if entity["role"] == "village_resident"
    ]
    assert {resident["semantic_type"] for resident in residents} == {"cow", "horse"}
    scheduled_ids = {
        agent["entity_id"] for agent in spec["agents"] if agent["controller"] == "schedule"
    }
    assert scheduled_ids == {resident["entity_id"] for resident in residents}


def test_size_profiles_have_explicit_area_limits():
    small = _dog_village("small")
    medium = _dog_village("medium")
    assert small["environment"]["dimensions_m"]["width"] == 500
    assert small["environment"]["dimensions_m"]["depth"] == 500
    assert medium["environment"]["dimensions_m"]["width"] == 1000
    assert medium["environment"]["dimensions_m"]["depth"] == 1000


def test_ollama_schema_keeps_tuple_bound_without_unsupported_boolean_schema():
    schema = ollama_simulation_schema()
    offset = schema["$defs"]["spatial_relation"]["properties"]["local_offset_m"]
    assert offset["items"] == {"type": "number"}
    assert offset["maxItems"] == 3
    assert offset["minItems"] == 3
    serialized = json.dumps(schema)
    assert '"allOf"' not in serialized
    assert '"minLength"' not in serialized
    assert '"maxLength"' not in serialized


def test_measured_asset_center_becomes_visual_alignment_offset(tmp_path):
    spec = _dog_village()
    entity = spec["entities"][0]
    asset = tmp_path / "measured.glb"
    asset.write_bytes(b"measured-fixture")
    manifest = {
        entity["entity_id"]: {
            "path": str(asset),
            "tier": "procedural",
            "component": "serendib-procedural-geometry",
            "qa": {
                "passed": True,
                "bbox_dimensions": [2.0, 4.0, 2.0],
                "bbox_center": [1.0, 2.0, -1.0],
                "measurement_method": "test",
                "tri_count": 12,
                "capabilities": {},
            },
        }
    }
    reduced_spec = {**spec, "entities": [entity]}
    descriptors, errors = descriptors_from_simulation_manifest(reduced_spec, manifest)
    assert errors == []
    descriptor = descriptors[entity["entity_id"]]
    # Derived through the same helper the code uses, so this test pins how the
    # pivot follows from the scale rather than restating what the scale rule is.
    # It previously hardcoded longest-to-longest and so failed when that rule
    # was corrected to match on height (see test_asset_normalisation.py).
    from assets.descriptors import _uniform_scale

    scale = _uniform_scale(entity["physical"]["bbox_m"], [2.0, 4.0, 2.0])
    assert descriptor["pivot"] == {
        "mode": "center",
        "offset_m": [-scale, -2.0 * scale, scale],
    }


def test_localized_edit_preserves_unrelated_entities():
    original = _dog_village()
    edited, changed, rejected = apply_localized_edit(original, "make it rainy at night")
    assert rejected == []
    assert edited["environment"]["weather"] == "rain"
    assert edited["environment"]["time_of_day"] == "night"
    assert edited["entities"] == original["entities"]
    assert "environment.weather" in changed
    validate_simulation_spec(edited)


def test_compatibility_compiler_is_explicit_and_schema_valid():
    legacy, approximations = compile_to_legacy_game(
        _dog_village(), "g3d_dog_village_deadbeef"
    )
    assert legacy["meta"]["genre"] == "collect_explore_3d"
    assert legacy["player"]["asset_brief"]["brief"].lower().find("dog") >= 0
    assert len(legacy["entities"]["objects"]) == 4
    assert approximations == []


def test_simulation_api_persists_spec_and_truthfully_fails_missing_runtime_gates(client):
    response = client.post(
        "/api/v1/simulations",
        json={
            "prompt": "as a dog explore the village",
            "size_profile": "small",
            "target_platforms": ["web", "desktop"],
            "seed": 42,
        },
    )
    assert response.status_code == 202, response.text
    identifiers = response.json()
    run = client.get(f"/api/v1/runs/{identifiers['run_id']}")
    assert run.status_code == 200
    assert run.json()["state"] == "failed_validation", run.json()
    # The point of this test -- a run truthfully reports the runtime gates it
    # could not satisfy -- is carried by cross_platform_parity, which is still
    # mandatory. visual_semantic is now advisory: it runs and is reported, but a
    # verdict from a model looking at pictures does not block publication.
    assert "visual_semantic" not in run.json()["detail"]["mandatory_failures"]
    assert "cross_platform_parity" in run.json()["detail"]["mandatory_failures"]

    simulation = client.get(
        f"/api/v1/simulations/{identifiers['simulation_id']}"
    ).json()
    assert simulation["spec"]["schema_version"] == "1.0.0"
    assert simulation["spec"]["entities"][0]["semantic_type"] == "dog"
    assert simulation["world_plan"]["schema_version"] == "1.0.0"
    assert simulation["world_plan"]["behaviours"]
    assert simulation["status"] == "failed_validation"

    report = client.get(
        f"/api/v1/simulations/{identifiers['simulation_id']}/report"
    ).json()
    statuses = {item["layer"]: item["status"] for item in report["validation"]}
    # Capability-critical village shells/doors are deterministic measured geometry,
    # so asset qualification passes even when optional AI generation is disabled.
    # Native compilation now runs. Engine/model-dependent checks are accurately
    # UNAVAILABLE in this unit-test deployment, which has no configured binary.
    assert statuses["visual_semantic"] == "UNAVAILABLE"
    assert statuses["cross_platform_parity"] == "UNAVAILABLE"
    assert statuses["native_world_plan_compilation"] == "PASS"
    assert statuses["asset_geometry"] == "PASS"
    assert statuses["capability_declaration"] == "PASS"
    assert statuses["capability_resolution"] == "PASS"
    assert statuses["behavior_compilation"] == "PASS"
    assert report["world_plan_hash"]
    assert report["requirements"]

    # A failed native staging run must never disclose an unfinished artifact.
    with db_module.session_scope() as db:
        db.add(
            SimulationArtifact(
                id="artifact_internal_failed_run",
                run_id=identifiers["run_id"],
                kind="web_build",
                platform="web",
                uri="/internal/unverified/index.html",
            )
        )
    simulation = client.get(
        f"/api/v1/simulations/{identifiers['simulation_id']}"
    ).json()
    assert simulation["artifacts"] == []


def test_revalidation_reuses_immutable_spec_in_a_new_gated_run(client):
    created = client.post(
        "/api/v1/simulations",
        json={
            "prompt": "as a dog explore the village",
            "size_profile": "small",
            "target_platforms": ["web"],
            "seed": 43,
        },
    ).json()
    response = client.post(
        f"/api/v1/simulations/{created['simulation_id']}/revalidate"
    )
    assert response.status_code == 202, response.text
    retried = response.json()
    assert retried["simulation_id"] == created["simulation_id"]
    assert retried["run_id"] != created["run_id"]

    with db_module.session_scope() as db:
        original = db.get(GenerationRun, created["run_id"])
        revalidation = db.get(GenerationRun, retried["run_id"])
        assert revalidation.spec_id == original.spec_id
        assert revalidation.detail["revalidation_of"] == original.id

    run = client.get(f"/api/v1/runs/{retried['run_id']}").json()
    assert run["state"] == "failed_validation"
    assert "artifact_publication" in run["detail"]["mandatory_failures"]
    report = client.get(
        f"/api/v1/simulations/{created['simulation_id']}/report"
    ).json()
    statuses = {item["layer"]: item["status"] for item in report["validation"]}
    assert statuses.keys() >= MANDATORY_VALIDATION_LAYERS
    assert statuses["requirements_and_schema"] == "PASS"
    assert statuses["capability_declaration"] == "PASS"
