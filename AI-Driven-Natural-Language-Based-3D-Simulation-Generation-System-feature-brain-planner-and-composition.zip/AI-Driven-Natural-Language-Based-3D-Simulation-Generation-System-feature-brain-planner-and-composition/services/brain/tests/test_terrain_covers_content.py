"""The ground must cover the world placement actually uses.

Regression for run_fe54172d97b94f6ca972a87fddf8b5b5, which PUBLISHED (17/18 gates, no
mandatory failures) and still looked wrong. The planner declared a 12 x 15 m village
holding two 8 x 6 m dwellings; `_content_scaled_dimensions` grew the zones to fit,
placement spread content over 31 x 39 m, and `build_terrain` alone read the raw
declaration -- so the ground stayed a 12 x 15 m lattice. Because `terrain_field.gd`
rebuilds the ground from that field extent, most of the village stood past the edge of
its own ground.

Two sources for one fact, which is the shape of nearly every defect found this session.

FIXED by `_fit_declared_dimensions`, in the PLANNER. Deriving the extent inside terrain
instead also worked and was reverted: it made the heightfield a function of the content,
so adding one entity re-seated every entity and
`test_localized_addition_re_solves_only_the_added_entity` failed. Growing the
DECLARATION once keeps every later reader agreeing without any of them holding a second
opinion, and idempotence is what keeps the number still during a localized repair --
which is asserted below, because it is the property the whole approach rests on.
"""

from __future__ import annotations

import copy

from agents.simulation_planner import _fit_declared_dimensions
from pcg.semantic import generate_semantic_world_plan
from tests.test_simulation_core import _dog_village


def _cramped_village(fit: bool = True) -> dict:
    """A village declared far smaller than the buildings it contains.

    `fit=False` returns the spec as the planner would have drafted it, before the
    dimension fit runs -- which is what the raw defect looked like.
    """
    spec = copy.deepcopy(_dog_village())
    spec["environment"]["dimensions_m"] = {"width": 12, "depth": 15, "max_height": 8}
    spec["environment"]["terrain"] = "rolling"
    template = next(
        entity
        for entity in spec["entities"]
        if entity.get("role") != "controlled_agent"
    )
    for suffix in ("a", "b"):
        dwelling = copy.deepcopy(template)
        dwelling["entity_id"] = f"ent_dwelling_{suffix}"
        dwelling["semantic_type"] = "detached_house"
        dwelling["physical"]["bbox_m"] = [8.0, 4.0, 6.0]
        spec["entities"].append(dwelling)
    if fit:
        # What the planner does, at the point it does it.
        _fit_declared_dimensions(spec)
    return spec


def _off_the_ground(plan: dict) -> list[str]:
    half_w = plan["terrain"]["width_m"] / 2.0
    half_d = plan["terrain"]["depth_m"] / 2.0
    return [
        entity["entity_id"]
        for entity in plan["entities"]
        for position in [(entity.get("transform") or {}).get("position_m") or []]
        if len(position) >= 3
        and (abs(position[0]) > half_w or abs(position[2]) > half_d)
    ]


def test_the_ground_covers_every_placed_entity():
    plan = generate_semantic_world_plan(_cramped_village())
    assert _off_the_ground(plan) == []


def test_the_field_grows_past_the_declaration_when_content_demands_it():
    plan = generate_semantic_world_plan(_cramped_village())
    # Declared 12 x 15; two 8 x 6 m houses cannot fit, so the field must be larger.
    assert plan["terrain"]["width_m"] > 12.0
    assert plan["terrain"]["depth_m"] > 15.0


def test_the_default_village_also_stands_on_its_ground():
    # Not only the pathological case: the ordinary prompt must hold too.
    plan = generate_semantic_world_plan(copy.deepcopy(_dog_village()))
    assert _off_the_ground(plan) == []


def test_the_field_still_tracks_the_content_rather_than_ballooning():
    # The contract's promise is that a small honest number stays small. The field may
    # exceed the declaration, but it must stay proportionate to what is placed -- a
    # guard against "fix the floor by making every world enormous".
    plan = generate_semantic_world_plan(_cramped_village())
    xs = [
        position[0]
        for entity in plan["entities"]
        for position in [(entity.get("transform") or {}).get("position_m") or []]
        if len(position) >= 3
    ]
    content_span = max(xs) - min(xs)
    assert plan["terrain"]["width_m"] <= max(content_span * 4.0, 40.0)


def test_the_unfitted_spec_is_the_defect_this_guards_against():
    # Without the fit, the ground really is too small -- so the tests above are
    # measuring the fix rather than a world that never had the problem.
    plan = generate_semantic_world_plan(_cramped_village(fit=False))
    assert _off_the_ground(plan) != []


def test_the_fit_is_idempotent_so_a_repair_cannot_move_the_ground():
    # The property the whole approach rests on. If applying the fit twice changed the
    # number, a localized repair would resize the world and re-seat every entity, which
    # is exactly the failure that made the terrain-side version untenable.
    once = _cramped_village()
    twice = copy.deepcopy(once)
    _fit_declared_dimensions(twice)
    assert twice["environment"]["dimensions_m"] == once["environment"]["dimensions_m"]


def test_a_world_that_already_fits_is_left_alone():
    spec = copy.deepcopy(_dog_village())
    before = copy.deepcopy(spec["environment"]["dimensions_m"])
    _fit_declared_dimensions(spec)
    assert spec["environment"]["dimensions_m"] == before
