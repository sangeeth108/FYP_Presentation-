"""LLM planner: structured-output parsing, clamping, and the always-safe fallback."""

import json

import httpx
from agents.llm_planner import BRIEF_SCHEMA, llm_brief


class _Settings:
    llm_base_url = "http://mock"
    llm_model = "qwen3.6:27b"
    llm_timeout_seconds = 5.0


def _transport_returning(payload: dict | str) -> httpx.MockTransport:
    content = payload if isinstance(payload, str) else json.dumps(payload)

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        assert body["format"] == BRIEF_SCHEMA  # guided decoding is actually requested
        assert body["stream"] is False
        return httpx.Response(200, json={"message": {"content": content}})

    return httpx.MockTransport(handler)


GOOD = {
    "genre": "dungeon_crawl_3d",
    "camera": "isometric_3d",
    "zone_count": 9,
    "verticality_tiers": 2,
    "enemy_count": 8,
    "mood": "torchlit crypt, dust and echoes",
}


def test_valid_answer_becomes_a_brief():
    brief = llm_brief("delve a crypt", None, None, _Settings(), _transport_returning(GOOD))
    assert brief is not None
    assert brief.genre == "dungeon_crawl_3d"
    assert brief.zone_count == 9
    assert brief.mood == "torchlit crypt, dust and echoes"


def test_user_options_override_the_model():
    brief = llm_brief(
        "delve a crypt", "arena_combat_3d", "top_down_3d",
        _Settings(), _transport_returning(GOOD),
    )
    assert brief.genre == "arena_combat_3d"
    assert brief.camera == "top_down_3d"


def test_out_of_range_numbers_are_clamped():
    wild = dict(GOOD, zone_count=99, enemy_count=-3, verticality_tiers=7)
    brief = llm_brief("x", None, None, _Settings(), _transport_returning(wild))
    assert (brief.zone_count, brief.enemy_count, brief.verticality_tiers) == (20, 0, 3)


def test_garbage_and_unreachable_server_fall_back_to_none():
    assert llm_brief("x", None, None, _Settings(), _transport_returning("not json")) is None
    bad_enum = dict(GOOD, genre="mmo_shooter")
    assert llm_brief("x", None, None, _Settings(), _transport_returning(bad_enum)) is None

    def down(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("refused")

    assert llm_brief("x", None, None, _Settings(), httpx.MockTransport(down)) is None


# --- planner seed derives from the GAME seed (variety + reproducibility) ----


def test_planner_seed_is_reproducible_varies_with_seed_and_decorrelates_agents():
    """The 'unique games' fix: same prompt at a different seed must be able to
    produce a different design, without losing reproducibility (rule 14)."""
    from agents.llm_planner import DEFAULT_PLANNER_SEED, planner_seed

    class Ctx:
        def __init__(self, seed):
            self.seed = seed

    # reproducible: same game seed -> same sampling seed, every time
    assert planner_seed(Ctx(7), 0) == planner_seed(Ctx(7), 0)
    # varied: a different game seed -> a different sampling seed (variety is possible)
    assert planner_seed(Ctx(7), 0) != planner_seed(Ctx(8), 0)
    # decorrelated: the three agents don't move in lockstep on one seed
    assert planner_seed(Ctx(7), 0) != planner_seed(Ctx(7), 1)
    # seed 0 is a real seed, not "falsy -> default"
    assert planner_seed(Ctx(0), 0) != DEFAULT_PLANNER_SEED
    # in Ollama's valid non-negative int range
    assert 0 <= planner_seed(Ctx(2**40), 3) < 2**31


def test_planner_seed_falls_back_when_there_is_no_game_seed():
    # A bare Settings object (e.g. the editor path) has no .seed — keep the old
    # constant rather than crash, so those paths are unchanged.
    from agents.llm_planner import DEFAULT_PLANNER_SEED, planner_seed

    class BareSettings:
        llm_model = "x"

    assert planner_seed(BareSettings(), 0) == DEFAULT_PLANNER_SEED


def test_llm_brief_sends_the_derived_seed_not_the_constant():
    # The request must actually carry the game-derived seed, or the fix is inert.
    from agents.llm_planner import planner_seed

    class Ctx:
        llm_base_url = "http://mock"
        llm_model = "qwen3.6:27b"
        llm_timeout_seconds = 5.0
        seed = 99

    seen = {}

    def handler(request):
        body = json.loads(request.content)
        seen["seed"] = body["options"]["seed"]
        brief = {
            "genre": "arena_combat_3d", "camera": "third_person", "zone_count": 5,
            "verticality_tiers": 1, "enemy_count": 5, "mood": "grim",
            "lighting_preset": "overcast_day",
        }
        return httpx.Response(200, json={"message": {"content": json.dumps(brief)}})

    llm_brief("a duel", None, None, Ctx(), transport=httpx.MockTransport(handler))
    assert seen["seed"] == planner_seed(Ctx(), 0) != 4521
