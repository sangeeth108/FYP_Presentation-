"""ADR-0020: an unplaced entity the prompt never asked for is a gap, not a failure.

The market street placed EVERY entity and did not publish; the village lane missed one of
about thirty. `published` is a conjunction of seventeen gates, so one fence segment failed
the world and took six more by cascade.

Placement was also the only stage treating a partial result as total failure -- the asset
ladder, scatter, frontage and surface synthesis all degrade and disclose. These tests pin
the distinction the change rests on, and the rule that keeps it honest.
"""

from __future__ import annotations

from pcg.semantic import _classify_unplaced
from verification.contracts import required_entity_ids


def _spec(**overrides) -> dict:
    spec = {
        "entities": [
            {"entity_id": "ent_controlled_actor", "role": "controlled_agent"},
            {"entity_id": "ent_rake", "role": "prop"},
            {"entity_id": "ent_fence_s0", "role": "scenery"},
            {"entity_id": "ent_fence_s1", "role": "scenery"},
            {"entity_id": "ent_fence_s2", "role": "scenery"},
            {"entity_id": "ent_fence_s3", "role": "scenery"},
        ],
        "requirements": [
            {"requirement_id": "req_rake", "subject": "ent_rake", "predicate": "exists"},
            {"requirement_id": "req_fence", "subject": "ent_fence_s0", "predicate": "exists"},
        ],
        # s1..s3 trace to the fence through part_of, exactly as ADR-0016 arranges.
        "spatial_relations": [
            {"subject_id": f"ent_fence_s{n}", "target_id": "ent_fence_s0",
             "relation": "part_of", "hard": False}
            for n in (1, 2, 3)
        ],
    }
    spec.update(overrides)
    return spec


def test_the_prompt_decides_what_is_required():
    """Requirement subjects and the controlled actor. Segments are not required
    individually: one requirement covers the whole run and the rest trace through
    `part_of`, so the fence was asked for and segment two was not."""
    required = required_entity_ids(_spec())
    assert required == {"ent_controlled_actor", "ent_rake", "ent_fence_s0"}


def test_a_thing_the_prompt_asked_for_still_blocks():
    split = _classify_unplaced(_spec(), ["ent_rake"])
    assert split["unplaced_required"] == ["ent_rake"]
    assert split["unplaced_incidental"] == []


def test_the_controlled_actor_always_blocks():
    """No requirement mentions it in this fixture, and a world without its actor is
    not deliverable whatever the requirements say."""
    split = _classify_unplaced(_spec(), ["ent_controlled_actor"])
    assert split["unplaced_required"] == ["ent_controlled_actor"]


def test_one_segment_of_a_fence_is_a_gap_not_a_failure():
    """The case that was discarding otherwise-complete worlds."""
    split = _classify_unplaced(_spec(), ["ent_fence_s2"])
    assert split["unplaced_required"] == []
    assert split["unplaced_incidental"] == ["ent_fence_s2"]


def test_most_of_a_fence_missing_is_a_missing_fence():
    """The rule that stops this becoming a way to publish a world with no walls.

    Three of the group's four members gone is 75%, so what is absent is the fence
    itself. The FAILED MEMBERS become blocking rather than the head: the head normally
    placed fine, and marking an entity that placed cannot make the gate object, because
    the gate only reads entities that did not.
    """
    split = _classify_unplaced(_spec(), ["ent_fence_s1", "ent_fence_s2", "ent_fence_s3"])
    assert sorted(split["unplaced_required"]) == [
        "ent_fence_s1",
        "ent_fence_s2",
        "ent_fence_s3",
    ]
    assert split["unplaced_incidental"] == []


def test_half_a_group_is_not_yet_a_collapse():
    """The boundary is deliberately strict-greater-than, so an even split reads as a
    gappy fence rather than an absent one -- the direction that keeps a world."""
    split = _classify_unplaced(_spec(), ["ent_fence_s1", "ent_fence_s2"])
    assert split["unplaced_required"] == []
    assert len(split["unplaced_incidental"]) == 2


def test_nothing_unplaced_produces_empty_lists():
    split = _classify_unplaced(_spec(), [])
    assert split == {"unplaced_required": [], "unplaced_incidental": []}


def test_an_old_plan_without_the_split_still_fails_loudly():
    """A plan written before this change, or preserved through a repair, must not
    silently start passing: the validator falls back to the whole list."""
    from pcg.semantic import validate_semantic_world_plan

    plan = {
        "schema_version": "1.0.0",
        "simulation_id": "sim_x",
        "seed": 1,
        "world_bounds": {"min": [-10, 0, -10], "max": [10, 10, 10]},
        "zones": [{"zone_id": "main", "semantic_type": "main",
                   "bounds": {"min": [-9, 0, -9], "max": [9, 9, 9]}, "connected_to": []}],
        "entities": [],
        "behaviours": [],
        "relationships": [],
        "navigation": {"regions": ["main"], "required_reachability": [], "paths": []},
        # No `unplaced_required` key at all -- the pre-ADR shape.
        "constraint_summary": {
            "hard_constraints": [],
            "soft_relaxations": [],
            "unplaced_entities": ["ent_anything"],
        },
    }
    report = validate_semantic_world_plan(plan, require_measured_assets=False)
    assert any(e["code"] == "ENTITY_UNPLACED" for e in report["errors"])
