"""R2 artifact upload: config-gated, dependency-injected, never a hard dependency.

Tested with a fake S3 client (no boto3, no network): the upload logic, key
layout, public-URL construction, and graceful degradation are all exercised.
"""

from dataclasses import dataclass

from storage.r2 import delete_artifact_prefix, is_configured, upload_artifacts


@dataclass
class _Cfg:
    r2_enabled: bool = True
    r2_endpoint_url: str = "https://acct.r2.cloudflarestorage.com"
    r2_bucket: str = "promptplay-artifacts"
    r2_access_key_id: str = "key"
    r2_secret_access_key: str = "secret"
    r2_public_base_url: str = "https://cdn.example.com"
    artifact_gateway_base_url: str = ""
    promptplay_env: str = "development"


class _FakeS3:
    def __init__(self) -> None:
        self.uploaded: list[tuple[str, str, str]] = []  # (bucket, key, content_type)

    def upload_file(self, Filename, Bucket, Key, ExtraArgs):  # noqa: N803 — S3 API names
        self.uploaded.append((Bucket, Key, ExtraArgs.get("ContentType")))


class _FakeDeleteS3:
    def __init__(self):
        self.deleted = []

    def list_objects_v2(self, **request):
        prefix = request["Prefix"]
        return {
            "Contents": [
                {"Key": f"{prefix}index.html"},
                {"Key": f"{prefix}project.zip"},
            ],
            "IsTruncated": False,
        }

    def delete_objects(self, **request):
        self.deleted.extend(
            item["Key"] for item in request["Delete"]["Objects"]
        )


def _artifacts(tmp_path):
    (tmp_path / "index.html").write_text("<html></html>", encoding="utf-8")
    (tmp_path / "game.wasm").write_bytes(b"\0\1\2")
    (tmp_path / "project.zip").write_bytes(b"PK\x03\x04")
    return tmp_path


def test_disabled_returns_none(tmp_path):
    cfg = _Cfg(r2_enabled=False)
    assert not is_configured(cfg)
    assert upload_artifacts(_artifacts(tmp_path), "g3d_x", cfg, client=_FakeS3()) is None


def test_incomplete_config_returns_none(tmp_path):
    cfg = _Cfg(r2_bucket="")  # missing bucket
    assert not is_configured(cfg)
    assert upload_artifacts(_artifacts(tmp_path), "g3d_x", cfg, client=_FakeS3()) is None


def test_uploads_every_file_and_returns_public_urls(tmp_path):
    cfg = _Cfg()
    fake = _FakeS3()
    urls = upload_artifacts(_artifacts(tmp_path), "g3d_slug_ab12", cfg, client=fake)
    assert urls is not None
    assert urls["index.html"] == (
        "https://cdn.example.com/tenants/tenant_dev/runs/"
        "g3d_slug_ab12/index.html"
    )
    assert urls["project.zip"] == (
        "https://cdn.example.com/tenants/tenant_dev/runs/"
        "g3d_slug_ab12/project.zip"
    )
    keys = {k for _b, k, _ct in fake.uploaded}
    assert keys == {
        "tenants/tenant_dev/runs/g3d_slug_ab12/index.html",
        "tenants/tenant_dev/runs/g3d_slug_ab12/game.wasm",
        "tenants/tenant_dev/runs/g3d_slug_ab12/project.zip",
    }
    # content types are set (important for the browser to run the WASM game)
    ctypes = {k: ct for _b, k, ct in fake.uploaded}
    assert ctypes[
        "tenants/tenant_dev/runs/g3d_slug_ab12/index.html"
    ] == "text/html"


def test_production_requires_tenant_and_authenticated_gateway(tmp_path):
    configured = _Cfg(
        promptplay_env="production",
        artifact_gateway_base_url="https://artifacts.example.com",
        r2_public_base_url="",
    )
    assert (
        upload_artifacts(
            _artifacts(tmp_path),
            "run_a",
            configured,
            client=_FakeS3(),
        )
        is None
    )
    fake = _FakeS3()
    urls = upload_artifacts(
        _artifacts(tmp_path),
        "../../run_a",
        configured,
        client=fake,
        tenant_id="../../tenant-a",
    )
    assert urls is not None
    assert all(".." not in key for _bucket, key, _ctype in fake.uploaded)
    assert all(key.startswith("tenants/") for _bucket, key, _ctype in fake.uploaded)


def test_a_failing_client_degrades_to_none_not_a_crash(tmp_path):
    class Boom:
        def upload_file(self, **k):
            raise RuntimeError("network down")

    assert upload_artifacts(_artifacts(tmp_path), "g", _Cfg(), client=Boom()) is None


def test_private_artifacts_are_deleted_by_tenant_scoped_prefix():
    client = _FakeDeleteS3()
    assert delete_artifact_prefix(
        _Cfg(),
        tenant_id="tenant_a",
        run_prefix="g3d_a_deadbeef",
        client=client,
    )
    assert client.deleted == [
        "tenants/tenant_a/runs/g3d_a_deadbeef/index.html",
        "tenants/tenant_a/runs/g3d_a_deadbeef/project.zip",
    ]
