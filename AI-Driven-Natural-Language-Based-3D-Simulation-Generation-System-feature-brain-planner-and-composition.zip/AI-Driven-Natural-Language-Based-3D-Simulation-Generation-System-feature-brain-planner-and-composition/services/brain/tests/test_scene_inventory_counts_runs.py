"""The critic is asked a question the picture can answer.

Measured on a warehouse that otherwise passed 17 of 18 gates. Its perimeter is built from
34 wall segments, and the inventory handed the visual critic "34 Drywall Walls":

    "The environment overview does not visually represent 34 Drywall Walls as required
     by the scene inventory. The visible walls appear to be fewer in number."

The critic was right. Nobody can see 34 walls in that room, because there are not 34
walls in it -- there is one perimeter with four sides.
"""

import inspect
import re

from model_router import executors


def _inventory(entities: list[dict]) -> dict[str, int]:
    """Run the inventory pass exactly as `run_visual_semantic` builds it."""
    source = inspect.getsource(executors)
    pattern = re.search(r'segment_of_run = re\.compile\((r"[^"]+")\)', source)
    assert pattern, "the inventory no longer collapses run segments"
    segment_of_run = re.compile(eval(pattern.group(1)))  # noqa: S307 - our own literal

    inventory: dict[str, int] = {}
    runs_seen: set[str] = set()
    for entity in entities:
        if bool(entity.get("physical", {}).get("dynamic")) or entity.get("capabilities"):
            continue
        semantic_type = str(entity.get("semantic_type") or "unknown")
        match = segment_of_run.match(str(entity["entity_id"]))
        if match:
            run_id = match.group("run")
            if run_id in runs_seen:
                continue
            runs_seen.add(run_id)
        inventory[semantic_type] = inventory.get(semantic_type, 0) + 1
    return inventory


def _segments(run: str, count: int, semantic_type: str) -> list[dict]:
    return [
        {"entity_id": f"{run}_s{i}", "semantic_type": semantic_type} for i in range(count)
    ]


def test_a_perimeter_counts_once_per_side_not_once_per_segment() -> None:
    walls = (
        _segments("ent_drywall_walls_north", 7, "Drywall Walls")
        + _segments("ent_drywall_walls_south", 7, "Drywall Walls")
        + _segments("ent_drywall_walls_west", 10, "Drywall Walls")
        + _segments("ent_drywall_walls_east", 10, "Drywall Walls")
    )
    assert len(walls) == 34
    assert _inventory(walls) == {"Drywall Walls": 4}


def test_things_that_are_not_segments_are_counted_as_themselves() -> None:
    inventory = _inventory(
        [
            {"entity_id": "ent_racking_main", "semantic_type": "steel racking"},
            {"entity_id": "ent_racking_b", "semantic_type": "steel racking"},
            {"entity_id": "ent_pallet_stack", "semantic_type": "pallet stack"},
        ]
    )
    assert inventory == {"steel racking": 2, "pallet stack": 1}


def test_agents_and_interactables_stay_out_of_the_wide_shot() -> None:
    """They have dedicated close-ups; the overview must not duplicate that duty."""
    inventory = _inventory(
        [
            {"entity_id": "ent_forklift", "semantic_type": "forklift",
             "physical": {"dynamic": True}},
            {"entity_id": "ent_lever", "semantic_type": "lever", "capabilities": ["use"]},
            {"entity_id": "ent_crate", "semantic_type": "crate"},
        ]
    )
    assert inventory == {"crate": 1}
