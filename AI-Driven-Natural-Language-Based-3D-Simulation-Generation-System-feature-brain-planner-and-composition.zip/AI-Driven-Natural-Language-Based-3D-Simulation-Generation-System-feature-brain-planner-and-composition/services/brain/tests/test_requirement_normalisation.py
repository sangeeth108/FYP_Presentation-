"""A requirement must name something the spec contains, once.

Two of the three commonest traceability failures in this system's history, both visible in
one live harbour run:

    REQUIREMENT_SUBJECT_UNKNOWN   subject "ent_timber_jetty"
    DUPLICATE_REQUIREMENT_ID      req_timber_jetty, twice

Across every stored run, REQUIREMENT_SUBJECT_UNKNOWN appears 53 times, and it fails the
whole run each time. Both come from one place: `expand_linear_structures` replaces a run
with its segments, so `ent_timber_jetty` stops being an entity while the requirements the
planner wrote still name it -- and when the planner writes one requirement for the run and
another for its first segment, it reuses the id, because to the planner they are the same
thing.
"""

from agents.simulation_planner import _normalise_requirements

JETTY = [{"entity_id": "ent_timber_jetty_s0"}, {"entity_id": "ent_timber_jetty_s1"}]


def _spec(requirements: list[dict], entities: list[dict] | None = None) -> dict:
    return {"entities": list(entities if entities is not None else JETTY),
            "requirements": requirements}


def test_a_stale_run_id_follows_its_segments() -> None:
    candidate = _spec(
        [{"requirement_id": "req_jetty_exists", "predicate": "exists",
          "subject": "ent_timber_jetty", "target": "timber_jetty"}]
    )
    _normalise_requirements(candidate)
    assert candidate["requirements"][0]["subject"] == "ent_timber_jetty_s0"
    assert any("expanded into segments" in a["reason"] for a in candidate["approximations"])


def test_a_duplicate_id_keeps_the_copy_that_resolves() -> None:
    """The run-id copy is the stale one by construction."""
    candidate = _spec(
        [
            {"requirement_id": "req_timber_jetty", "predicate": "exists",
             "subject": "ent_timber_jetty", "target": "timber_jetty"},
            {"requirement_id": "req_timber_jetty", "predicate": "exists",
             "subject": "ent_timber_jetty_s0", "target": "jetty"},
        ]
    )
    _normalise_requirements(candidate)
    assert len(candidate["requirements"]) == 1
    assert candidate["requirements"][0]["subject"] == "ent_timber_jetty_s0"
    ids = [r["requirement_id"] for r in candidate["requirements"]]
    assert len(ids) == len(set(ids))


def test_a_requirement_naming_nothing_is_withdrawn() -> None:
    candidate = _spec(
        [{"requirement_id": "req_ghost", "predicate": "exists",
          "subject": "ent_nothing_at_all", "target": "ghost"}]
    )
    _normalise_requirements(candidate)
    assert candidate["requirements"] == []
    assert any("withdrawn" in a["reason"] for a in candidate["approximations"])


def test_the_simulation_is_always_a_valid_subject() -> None:
    """Simulation-level requirements name no entity and must survive."""
    candidate = _spec(
        [{"requirement_id": "req_explorable", "predicate": "is",
          "subject": "simulation", "target": "explorable"}]
    )
    _normalise_requirements(candidate)
    assert candidate["requirements"][0]["subject"] == "simulation"
    assert not candidate.get("approximations")


def test_scatter_species_are_valid_subjects() -> None:
    candidate = {
        "entities": list(JETTY),
        "scatter": [{"species_id": "spc_oak_tree"}],
        "requirements": [{"requirement_id": "req_trees", "predicate": "exists",
                          "subject": "spc_oak_tree", "target": "oak tree"}],
    }
    _normalise_requirements(candidate)
    assert candidate["requirements"][0]["subject"] == "spc_oak_tree"


def test_a_healthy_spec_is_left_exactly_as_it_is() -> None:
    good = [
        {"requirement_id": "req_a", "predicate": "exists",
         "subject": "ent_timber_jetty_s0", "target": "jetty"},
        {"requirement_id": "req_b", "predicate": "exists",
         "subject": "ent_timber_jetty_s1", "target": "jetty"},
    ]
    candidate = _spec([dict(r) for r in good])
    _normalise_requirements(candidate)
    assert candidate["requirements"] == good
    assert not candidate.get("approximations")
