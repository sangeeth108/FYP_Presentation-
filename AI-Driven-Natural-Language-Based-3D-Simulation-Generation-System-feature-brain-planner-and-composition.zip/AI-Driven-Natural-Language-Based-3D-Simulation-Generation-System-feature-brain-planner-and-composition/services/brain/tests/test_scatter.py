"""Scatter instancing: species + density -> seeded instances, honestly reported.

Scatter is what makes a place feel inhabited; `entities` cannot do it because an
entity is one listed object. These tests pin the properties that make the layer
trustworthy: it is reproducible from the seed, it never overlaps geometry, it
respects semantic attract/avoid, and when a requested density is physically
impossible it says so instead of overlapping or silently dropping instances.
"""

from __future__ import annotations

import math

import pytest
from pcg.scatter import instance_scatter

WORLD = [
    {
        "zone_id": "main",
        "semantic_type": "main",
        "bounds": {"min": [-50.0, 0.0, -50.0], "max": [50.0, 20.0, 50.0]},
    },
    {
        "zone_id": "grove",
        "semantic_type": "grove",
        "bounds": {"min": [-20.0, 0.0, -20.0], "max": [0.0, 20.0, 0.0]},
    },
]


def _species(**overrides) -> dict:
    species = {
        "species_id": "spc_fern",
        "semantic_type": "fern cluster",
        "asset": {
            "brief": "a low leafy fern cluster",
            "category": "environment",
            "requires_animation": False,
            "preferred_source": "procedural",
            "procedural_type": "semantic_box",
        },
        "density_per_100m2": 5.0,
    }
    species.update(overrides)
    return species


def _spec(species: list[dict], seed: int = 4521) -> dict:
    return {"meta": {"seed": seed}, "scatter": species}


def test_same_seed_gives_identical_instances():
    first = instance_scatter(_spec([_species()]), WORLD, [])
    second = instance_scatter(_spec([_species()]), WORLD, [])
    assert first == second
    assert first["instances"], "expected the sampler to place something"


def test_different_seed_gives_a_different_arrangement():
    a = instance_scatter(_spec([_species()], seed=1), WORLD, [])
    b = instance_scatter(_spec([_species()], seed=2), WORLD, [])
    assert a["instances"] != b["instances"]


def test_editing_one_species_does_not_reshuffle_another():
    """Per-species seeds: changing the fern density must not move the rocks."""
    both = _spec([_species(), _species(species_id="rock", density_per_100m2=2.0)])
    before = instance_scatter(both, WORLD, [])
    rocks_before = [i for i in before["instances"] if i["species_id"] == "rock"]

    changed = _spec(
        [_species(density_per_100m2=9.0), _species(species_id="rock", density_per_100m2=2.0)]
    )
    after = instance_scatter(changed, WORLD, [])
    rocks_after = [i for i in after["instances"] if i["species_id"] == "rock"]

    assert rocks_before == rocks_after


def test_instances_respect_minimum_spacing():
    result = instance_scatter(
        _spec([_species(density_per_100m2=20.0)]),
        WORLD,
        [],
        asset_descriptors={"spc_fern": {"world_dimensions_m": [2.0, 1.0, 2.0]}},
    )
    points = [(i["position_m"][0], i["position_m"][2]) for i in result["instances"]]
    spacing = result["species"][0]["spacing_m"]
    for index, (x, z) in enumerate(points):
        for ox, oz in points[index + 1 :]:
            assert math.dist((x, z), (ox, oz)) >= spacing - 1e-6


def test_impossible_density_is_reported_not_faked():
    """A 4 m-radius tree cannot pack at 6/100 m²; say so rather than overlap."""
    result = instance_scatter(
        _spec([_species(species_id="tree", density_per_100m2=6.0)]),
        WORLD,
        [],
        asset_descriptors={"tree": {"world_dimensions_m": [8.0, 12.0, 8.0]}},
    )
    report = result["species"][0]
    assert report["placed_instances"] < report["requested_instances"]
    assert report["achieved_density_per_100m2"] < report["requested_density_per_100m2"]
    assert report["shortfall_reason"] == "packing_limit"
    assert report["footprint_measured"] is True


def test_unmeasured_asset_still_places_and_says_so():
    result = instance_scatter(_spec([_species()]), WORLD, [])
    assert result["instances"]
    assert result["species"][0]["footprint_measured"] is False


def test_scatter_never_lands_inside_a_placed_entity():
    placed = [
        {
            "entity_id": "ent_temple",
            "semantic_type": "temple",
            "transform": {"position_m": [0.0, 0.0, 0.0]},
            "world_aabb": {"min": [-10.0, 0.0, -10.0], "max": [10.0, 8.0, 10.0]},
        }
    ]
    result = instance_scatter(_spec([_species(density_per_100m2=30.0)]), WORLD, placed)
    for instance in result["instances"]:
        x, _, z = instance["position_m"]
        assert not (-10.0 <= x <= 10.0 and -10.0 <= z <= 10.0)


def test_avoid_tags_push_instances_away():
    placed = [
        {
            "entity_id": "ent_pond",
            "semantic_type": "water pond",
            "transform": {"position_m": [30.0, 0.0, 30.0]},
            "world_aabb": {"min": [28.0, 0.0, 28.0], "max": [32.0, 1.0, 32.0]},
        }
    ]
    result = instance_scatter(
        _spec([_species(density_per_100m2=25.0, avoid_tags=["water"])]), WORLD, placed
    )
    for instance in result["instances"]:
        x, _, z = instance["position_m"]
        assert math.dist((x, z), (30.0, 30.0)) >= 12.0 - 1e-6


def test_zones_restrict_where_a_species_may_go():
    result = instance_scatter(
        _spec([_species(zones=["grove"], density_per_100m2=10.0)]), WORLD, []
    )
    assert result["instances"]
    for instance in result["instances"]:
        x, _, z = instance["position_m"]
        assert -20.0 <= x <= 0.0 and -20.0 <= z <= 0.0


def test_max_instances_caps_the_budget():
    """The cap binds the count, and the report says the cap was what bound it.

    `requested_instances` used to be read AFTER the cap, so a species clipped from
    hundreds to 25 reported requested=25, placed=25, shortfall=None -- a row claiming
    the ask was met when it had been overridden. The figure density asked for is now
    what `requested_instances` carries, with the cap recorded beside it, because a
    report whose purpose is disclosing shortfall must not be able to hide one.
    """
    result = instance_scatter(
        _spec([_species(density_per_100m2=200.0, max_instances=25)]), WORLD, []
    )
    report = result["species"][0]
    assert report["requested_instances"] > 25
    assert report["capped_to_instances"] == 25
    assert report["shortfall_reason"] == "instance_cap"
    assert len(result["instances"]) <= 25


def test_grouped_clustering_is_tighter_than_even():
    """Thickets, not a uniform sprinkle: grouped packs closer on average."""

    def mean_nearest(clustering: str) -> float:
        result = instance_scatter(
            _spec([_species(density_per_100m2=8.0, clustering=clustering)]), WORLD, []
        )
        points = [(i["position_m"][0], i["position_m"][2]) for i in result["instances"]]
        assert len(points) > 5
        total = 0.0
        for index, point in enumerate(points):
            others = points[:index] + points[index + 1 :]
            total += min(math.dist(point, other) for other in others)
        return total / len(points)

    assert mean_nearest("grouped") < mean_nearest("even")


def test_no_scatter_section_is_valid_and_empty():
    result = instance_scatter({"meta": {"seed": 1}}, WORLD, [])
    assert result == {"instances": [], "species": []}


def test_planner_guided_schema_exposes_scatter_to_the_llm():
    """The LLM can only emit fields its guided-decoding schema contains.

    ollama_simulation_schema() derives that schema from the canonical contract, so
    adding scatter to the contract is what makes it emittable — this pins that the
    derivation keeps it (including the nested species shape the model must follow).
    """
    from agents.simulation_planner import ollama_simulation_schema

    guided = ollama_simulation_schema()
    assert "scatter" in guided["properties"]
    species = guided["$defs"]["scatter_species"]
    assert set(species["required"]) == {
        "species_id",
        "semantic_type",
        "asset",
        "density_per_100m2",
        # Required on purpose: guided decoding only guarantees what is required,
        # and a live 27B run omitted size_m on all 10 species when it was
        # optional, which silently shrank every rainforest tree to the 1.5 m
        # fallback.
        "size_m",
    }
    # The compatibility view strips string-length bounds for the grammar adapter,
    # but the open-vocabulary semantic_type must survive as a free string.
    assert species["properties"]["semantic_type"]["type"] == "string"
    assert "enum" not in species["properties"]["semantic_type"]


def test_procedural_assets_are_normalised_so_scatter_does_not_drop_the_run():
    """The planner cannot see the conditional that requires `procedural_type`.

    Regression from a real run: the planner authored 6 scatter species, marked
    them procedural (trees and rocks naturally are), and omitted `procedural_type`
    — because ollama_simulation_schema() must strip `allOf`/`if`/`then` for the
    grammar adapter. Validation then rejected the WHOLE spec and the run fell back
    to the deterministic draft, i.e. a generic empty world. Normalising the field
    keeps the spec valid without weakening the canonical contract.
    """
    from agents.simulation_planner import _normalise_procedural_assets

    candidate = {
        "scatter": [
            {
                "species_id": "spc_fern",
                "asset": {
                    "brief": "a leafy fern",
                    "category": "environment",
                    "requires_animation": False,
                    "preferred_source": "procedural",
                },
            }
        ],
        "entities": [
            {
                "asset": {
                    "brief": "a mossy rock",
                    "category": "environment",
                    "requires_animation": False,
                    "preferred_source": "either",
                }
            }
        ],
    }
    _normalise_procedural_assets(candidate)

    assert candidate["scatter"][0]["asset"]["procedural_type"] == "semantic_box"
    # EVERY asset now carries a form, whatever its source. This assertion used to
    # be the opposite -- a non-procedural source was left untouched -- and that was
    # correct while only a `procedural` asset could reach the procedural builder.
    # Since the planner stopped being allowed to choose `procedural`, the whole
    # resolution ladder ends there instead, so any asset can arrive at the builder
    # and every one of them needs a fallback shape. A form is no longer the PLAN for
    # an object; it is what it degrades to.
    assert candidate["entities"][0]["asset"]["procedural_type"] == "semantic_box"


def test_a_normalised_procedural_scatter_spec_passes_the_canonical_schema():
    """End of the chain: after normalisation the untouched contract accepts it."""
    import jsonschema
    from agents.simulation_planner import _normalise_procedural_assets, simulation_schema

    species = {
        "species_id": "spc_buttress_tree",
        "semantic_type": "buttress root tree",
        "density_per_100m2": 4,
        "size_m": [9.0, 28.0, 9.0],
        "asset": {
            "brief": "a tall tropical tree with buttress roots",
            "category": "environment",
            "requires_animation": False,
            "preferred_source": "procedural",
        },
    }
    candidate = {"scatter": [species]}
    _normalise_procedural_assets(candidate)
    jsonschema.validate(
        candidate["scatter"][0],
        {**simulation_schema()["$defs"]["scatter_species"], "$defs": simulation_schema()["$defs"]},
    )


def test_scatter_is_optional_so_v1_0_0_specs_still_validate():
    """Backward compatibility: scatter is additive, never required."""
    from agents.simulation_planner import simulation_schema

    schema = simulation_schema()
    assert "scatter" not in schema["required"]
    assert schema["properties"]["schema_version"]["enum"] == ["1.1.0", "1.0.0"]


def test_out_of_range_entity_bounds_are_clamped_and_disclosed():
    """One bad number must not discard the whole plan.

    Regression from a real run: the planner sized an entity at 500 m against a
    200 m cap, validation rejected the ENTIRE spec, and the run fell back to the
    deterministic draft — a generic empty world identical for every prompt.
    """
    from agents.simulation_planner import (
        _clamp_entity_bounds,
        _record_bound_approximations,
    )

    candidate = {
        "requirements": [{"requirement_id": "req_prompt_fidelity"}],
        "entities": [
            {
                "entity_id": "ent_river",
                "physical": {"bbox_m": [500.0, 2.0, 30.0], "dynamic": False, "mass_kg": 0.0},
            },
            {
                "entity_id": "ent_rock",
                "physical": {"bbox_m": [1.5, 1.0, 1.2], "dynamic": False, "mass_kg": 10.0},
            },
        ],
    }
    clamped = _clamp_entity_bounds(candidate)
    _record_bound_approximations(candidate, clamped)

    assert candidate["entities"][0]["physical"]["bbox_m"][0] == 200.0
    # An in-range entity must be left exactly as planned.
    assert candidate["entities"][1]["physical"]["bbox_m"] == [1.5, 1.0, 1.2]
    # The compromise is disclosed, never silent.
    assert candidate["approximations"][0]["user_visible"] is True
    assert "clamped" in candidate["approximations"][0]["reason"]


def test_clamping_is_a_no_op_for_a_valid_spec():
    from agents.simulation_planner import _clamp_entity_bounds

    candidate = {
        "entities": [
            {
                "entity_id": "ent_tree",
                "physical": {"bbox_m": [4.0, 12.0, 4.0], "dynamic": False, "mass_kg": 0.0},
            }
        ]
    }
    assert _clamp_entity_bounds(candidate) == []
    assert candidate["entities"][0]["physical"]["bbox_m"] == [4.0, 12.0, 4.0]


def test_total_instances_are_capped_by_a_global_budget():
    """Density x area is unbounded; the build budget is not.

    Regression from a real run: 6 species over a 500x500 m world produced 120,000
    instances (each species hitting a 20,000 default), which no <=90 MB web build
    can carry.
    """
    from pcg.scatter import _TOTAL_INSTANCE_BUDGET

    big = [
        {
            "zone_id": "main",
            "semantic_type": "main",
            "bounds": {"min": [-250.0, 0.0, -250.0], "max": [250.0, 20.0, 250.0]},
        }
    ]
    species = [
        _species(species_id=f"s{index}", density_per_100m2=density)
        for index, density in enumerate([4.5, 12.0, 8.0, 15.0, 6.0, 5.0])
    ]
    result = instance_scatter(_spec(species), big, [])

    assert len(result["instances"]) <= _TOTAL_INSTANCE_BUDGET
    assert all(r["shortfall_reason"] == "instance_budget" for r in result["species"])


def test_the_budget_preserves_the_planners_density_mix():
    """Scaling must be proportional: a dense understorey stays denser than canopy.

    Applying the per-species cap BEFORE scaling flattened every species to the
    same count, discarding the mix the planner chose.
    """
    big = [
        {
            "zone_id": "main",
            "semantic_type": "main",
            "bounds": {"min": [-250.0, 0.0, -250.0], "max": [250.0, 20.0, 250.0]},
        }
    ]
    sparse, dense = 4.5, 15.0
    species = [
        _species(species_id="sparse", density_per_100m2=sparse),
        _species(species_id="dense", density_per_100m2=dense),
    ]
    result = instance_scatter(_spec(species), big, [])
    counts = {r["species_id"]: r["placed_instances"] for r in result["species"]}

    assert counts["dense"] > counts["sparse"]
    # Ratio should track the density ratio rather than collapsing to equality.
    assert counts["dense"] / counts["sparse"] == pytest.approx(dense / sparse, rel=0.15)


# --- Species are assets too: measurement closes the loop ---------------------


def _species_manifest(path, *, dimensions=(6.0, 3.0, 6.0)) -> dict:
    path.write_bytes(b"glTF-binary-species-fixture")
    return {
        "spc_fern": {
            "tier": "generated",
            "component": "hunyuan3d",
            "path": str(path),
            "qa": {
                "passed": True,
                "bbox_dimensions": list(dimensions),
                "bbox_center": [0.0, 2.0, 0.0],
                "tri_count": 900,
            },
        }
    }


def test_scatter_species_get_measured_descriptors(tmp_path):
    """Without this a species had no descriptor at all, so no mesh reached the scene."""
    from assets.descriptors import descriptors_from_simulation_manifest

    spec = {"entities": [], "scatter": [_species(size_m=[1.4, 2.0, 1.3])]}
    manifest = _species_manifest(tmp_path / "fern.glb")
    descriptors, errors = descriptors_from_simulation_manifest(spec, manifest)

    assert "spc_fern" in descriptors
    assert descriptors["spc_fern"]["measurement"]["status"] == "MEASURED"
    assert descriptors["spc_fern"]["asset_ref"] == "scatter:spc_fern"
    assert errors == []


def test_a_measured_species_spaces_by_real_geometry_not_a_declared_guess(tmp_path):
    """The point of measuring is the SHAPE, not the size.

    A descriptor normalises the asset to the planner's declared `size_m`, so a
    measured species is never a different height. What it is, is the right
    proportions: a fern 6 units wide and 3 tall normalises to a 4 m spread on a
    2 m frame, and spacing has to respect the spread the declared 1.4 m box
    never mentioned.
    """
    from assets.descriptors import descriptors_from_simulation_manifest

    species = _species(size_m=[1.4, 2.0, 1.3])
    manifest = _species_manifest(tmp_path / "fern.glb")
    descriptors, _ = descriptors_from_simulation_manifest(
        {"entities": [], "scatter": [species]}, manifest
    )

    declared = instance_scatter(_spec([species]), WORLD, [])
    measured = instance_scatter(_spec([species]), WORLD, [], descriptors)

    assert declared["species"][0]["footprint_measured"] is False
    assert measured["species"][0]["footprint_measured"] is True
    # Real geometry is wider than the declared size, so spacing must grow.
    assert measured["species"][0]["spacing_m"] > declared["species"][0]["spacing_m"]


def test_an_unresolvable_species_is_advisory_not_fatal(tmp_path):
    """Decoration must never sink a simulation whose entities are all sound."""
    from assets.descriptors import descriptors_from_simulation_manifest

    spec = {"entities": [], "scatter": [_species()]}
    descriptors, errors = descriptors_from_simulation_manifest(spec, {})

    assert descriptors == {}
    assert [error["code"] for error in errors] == ["SCATTER_ASSET_UNRESOLVED"]
    assert errors[0]["severity"] == "advisory"


def test_invented_species_ids_are_slugged_into_the_canonical_form():
    """An id becomes a scene node name, so free text would crash the writer."""
    from agents.simulation_planner import _normalise_species_ids

    candidate = {
        "scatter": [
            {"species_id": "Tree Fern!", "semantic_type": "fern"},
            {"species_id": "spc_buttress_tree", "semantic_type": "tree"},
            {"semantic_type": "Fallen Log"},
        ]
    }
    _normalise_species_ids(candidate)
    assert [item["species_id"] for item in candidate["scatter"]] == [
        "spc_tree_fern",
        "spc_buttress_tree",
        "spc_fallen_log",
    ]


def test_colliding_species_ids_stay_distinct():
    """Two kinds must not collapse into one field just because they slug alike."""
    from agents.simulation_planner import _normalise_species_ids

    candidate = {
        "scatter": [
            {"species_id": "tree fern"},
            {"species_id": "Tree-Fern"},
            {"species_id": "TREE_FERN"},
        ]
    }
    _normalise_species_ids(candidate)
    ids = [item["species_id"] for item in candidate["scatter"]]
    assert ids == ["spc_tree_fern", "spc_tree_fern_2", "spc_tree_fern_3"]
    assert len(set(ids)) == 3


def test_ground_cover_density_is_expressible_and_still_bounded_by_geometry():
    """A fern mat is ~400/100m2; the old 200 ceiling clamped accuracy as if it were error.

    Raising the ceiling is safe because nothing about physical plausibility
    depends on it: spacing comes from the measured footprint and the total from
    the global budget, so an impossible ask is still reported as a shortfall
    rather than granted.
    """
    dense = _species(species_id="spc_fern_mat", density_per_100m2=400.0, size_m=[0.6, 0.6, 0.6])
    result = instance_scatter(_spec([dense]), WORLD, [])
    report = result["species"][0]

    assert report["requested_density_per_100m2"] == 400.0
    # 0.6 m fronds cannot pack at 400/100m2; geometry says so, not the schema.
    assert report["achieved_density_per_100m2"] < 400.0
    assert report["shortfall_reason"] in {"packing_limit", "instance_budget"}


def test_an_absurd_density_is_still_rejected_by_the_range_clamp():
    """The ceiling moved; it did not disappear."""
    from agents.simulation_planner import _clamp_out_of_range_numbers

    candidate = {
        "scatter": [
            {
                "species_id": "spc_rock",
                "semantic_type": "boulder",
                "density_per_100m2": 100000,
                "size_m": [2.0, 1.5, 2.0],
                "asset": {
                    "brief": "a boulder",
                    "category": "environment",
                    "requires_animation": False,
                    "preferred_source": "procedural",
                    "procedural_type": "semantic_box",
                },
            }
        ]
    }
    _clamp_out_of_range_numbers(candidate)
    assert candidate["scatter"][0]["density_per_100m2"] == 5000


def test_a_constraint_that_cannot_be_evaluated_is_declared_ignored():
    """With no heightfield supplied, a slope limit cannot be judged at all.

    This used to be the only case, because the ground was one flat slab: a slope
    limit was not satisfied but meaningless, and saying so kept a spec from
    claiming a guarantee nothing enforced. The field now exists, so the disclosure
    narrows to what remains true -- no field, no judgement. `instance_scatter` is
    called here without one, which is the path this describes.
    """
    steep = _species(slope_max_degrees=20.0)
    plain = _species(species_id="spc_plain")

    result = instance_scatter(_spec([steep, plain]), WORLD, [])
    by_id = {item["species_id"]: item for item in result["species"]}

    assert by_id["spc_fern"]["ignored_constraints"] == ["slope_max_degrees"]
    assert by_id["spc_plain"]["ignored_constraints"] == []


def test_declaring_a_slope_limit_changes_nothing_without_a_field():
    """Nothing can act on the value when there is no ground to measure."""
    with_slope = instance_scatter(_spec([_species(slope_max_degrees=5.0)]), WORLD, [])
    without = instance_scatter(_spec([_species()]), WORLD, [])
    assert with_slope["instances"] == without["instances"]


def test_every_scatter_species_must_declare_its_form():
    """A species with no form is built as a plain block.

    Measured: a tea plantation produced thirteen species, every one with
    procedural_type unset, because the field is only auto-filled when
    preferred_source is "procedural" and the planner had chosen "either". The
    resolution ladder can fall through to the procedural tier for ANY species,
    so the form is required rather than conditional -- the same lesson as
    size_m, where an instruction was a hope and a required field is a
    constraint.
    """
    import jsonschema
    from agents.simulation_planner import simulation_schema

    schema = simulation_schema()
    assert (
        schema["$defs"]["scatter_species"]["properties"]["asset"]["$ref"]
        == "#/$defs/scatter_asset_requirement"
    )
    assert "procedural_type" in schema["$defs"]["scatter_asset_requirement"]["required"]

    formless = {
        "species_id": "spc_tea_bush",
        "semantic_type": "camellia_sinensis",
        "size_m": [1.0, 1.2, 1.0],
        "density_per_100m2": 100.0,
        "asset": {
            "brief": "a wild tea bush",
            "category": "environment",
            "requires_animation": False,
            "preferred_source": "either",
        },
    }
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(
            formless,
            {**schema["$defs"]["scatter_species"], "$defs": schema["$defs"]},
        )


def test_the_form_vocabulary_matches_what_the_builders_implement():
    """A form the contract offers but nobody builds would fail at generation."""
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "services" / "worker"))
    from agents.simulation_planner import simulation_schema
    from asset_farm.procedural import _SUPPORTED

    declared = set(
        simulation_schema()["$defs"]["scatter_asset_requirement"]["properties"][
            "procedural_type"
        ]["enum"]
    )
    assert declared == set(_SUPPORTED)


def _hilly():
    """A field with real relief, for judging a slope limit against."""
    from pcg.terrain import build_terrain

    return build_terrain(
        {
            "world_kind": "outdoor",
            "terrain_surface": "stone",
            "dimensions_m": {"width": 80.0, "depth": 80.0, "max_height": 12.0},
        },
        seed=42,
    )


def test_a_slope_limit_keeps_scatter_off_steep_ground():
    """The last place the flat-ground assumption was written down.

    The sampler declared `slope_max_degrees` ignored, correctly, while the ground
    was a plane. Measured on a stone field with no limit, the steepest ground under
    an instance is 20.4 degrees; with an 8 degree limit it is 7.9, and the
    constraint stops being disclosed as ignored because it is now enforced.
    """
    terrain = _hilly()
    spec = _spec([_species(slope_max_degrees=8.0)])
    result = instance_scatter(spec, WORLD, [], terrain=terrain)

    steepest = max(
        terrain.slope_degrees_at(item["position_m"][0], item["position_m"][2])
        for item in result["instances"]
    )
    assert steepest <= 8.0
    assert result["species"][0]["ignored_constraints"] == []

    # Without the limit the same field puts instances on ground twice as steep, so
    # the limit is doing the work rather than the terrain happening to be gentle.
    unlimited = instance_scatter(_spec([_species()]), WORLD, [], terrain=terrain)
    loosest = max(
        terrain.slope_degrees_at(item["position_m"][0], item["position_m"][2])
        for item in unlimited["instances"]
    )
    assert loosest > 8.0


def test_a_flat_field_satisfies_a_slope_limit_rather_than_ignoring_it():
    """On level ground a 20 degree limit is met, not meaningless.

    An indoor or built-surface world still gets a field, one whose heights are all
    zero. Declaring the constraint ignored there would understate what the world
    guarantees.
    """
    from pcg.terrain import flat_terrain

    result = instance_scatter(
        _spec([_species(slope_max_degrees=20.0)]),
        WORLD,
        [],
        terrain=flat_terrain(80.0, 80.0),
    )
    assert result["species"][0]["ignored_constraints"] == []
    assert result["instances"], "level ground should not reject anything"


def test_ground_too_steep_to_plant_says_so_rather_than_blaming_packing():
    """A shortfall has to name its cause for the repair loop to act on it.

    Measured on the same field: at a 3 degree limit 329 of 346 instances place, at
    1 degree only 45. Reporting `packing_limit` for that would point a repair at
    spacing, which is not what refused the placement.
    """
    terrain = _hilly()
    result = instance_scatter(
        _spec([_species(slope_max_degrees=1.0)]), WORLD, [], terrain=terrain
    )
    report = result["species"][0]
    assert report["placed_instances"] < report["requested_instances"]
    assert report["shortfall_reason"] == "slope_limit"


def test_ground_detail_is_bounded_but_never_dropped():
    """A meadow came back as 11,590 near-invisible meshes at 16 per square metre.

    Measured on a real run: 0.1 m grass blades and 0.05 m pine needles were both
    requested at the contract maximum of 5000 per 100 m2, while the 7 m pine trees
    the prompt actually asked for were requested at 1.6 and only one was placed. The
    world was a speckled carpet with its own content buried in it.

    Only the DENSITY of small instances is bounded, and only below a quarter of a
    metre. Which plants belong in a meadow is the planner's judgement and is left
    alone -- this is rendering economics, not a view about meadows. Nothing is
    dropped: the species still appears, at a count a viewer can resolve.
    """
    from agents.simulation_planner import _bound_scatter_density

    candidate = {
        "scatter": [
            {"species_id": "spc_grass", "size_m": [0.1, 0.2, 0.1],
             "density_per_100m2": 5000},
            {"species_id": "spc_needles", "size_m": [0.05, 0.02, 0.05],
             "density_per_100m2": 5000.0},
            # Above the threshold: untouched, whatever was asked for.
            {"species_id": "spc_thyme", "size_m": [0.3, 0.05, 0.3],
             "density_per_100m2": 200},
            {"species_id": "spc_pine", "size_m": [0.35, 7.0, 0.35],
             "density_per_100m2": 1.6},
        ]
    }
    _bound_scatter_density(candidate)
    by_id = {item["species_id"]: item for item in candidate["scatter"]}

    assert by_id["spc_grass"]["density_per_100m2"] == 60.0
    assert by_id["spc_needles"]["density_per_100m2"] == 60.0
    # Every species survives; none is removed.
    assert len(candidate["scatter"]) == 4
    # A species a viewer can actually see keeps exactly what was requested.
    assert by_id["spc_thyme"]["density_per_100m2"] == 200
    assert by_id["spc_pine"]["density_per_100m2"] == 1.6

    # Reducing what somebody asked for has to be visible to them.
    reduced = {
        item["requirement_id"]
        for item in candidate["approximations"]
        if item["user_visible"]
    }
    assert reduced == {"spc_grass", "spc_needles"}


def test_a_sparse_small_species_is_left_exactly_as_asked():
    """The bound is on density, not on being small.

    A handful of pebbles is a legitimate request and must survive untouched, or the
    rule would be an opinion about what belongs in a world rather than a limit on
    what the frame can draw.
    """
    from agents.simulation_planner import _bound_scatter_density

    candidate = {
        "scatter": [
            {"species_id": "spc_pebbles", "size_m": [0.08, 0.05, 0.08],
             "density_per_100m2": 12}
        ]
    }
    _bound_scatter_density(candidate)
    assert candidate["scatter"][0]["density_per_100m2"] == 12
    assert "approximations" not in candidate


def test_a_species_that_belongs_somewhere_is_kept_to_a_handful():
    """168 street lamps at one per 50 m2 was the measured shape of this bug.

    The village diagnostic's largest species by instance count was a street lamp,
    sprinkled by rejection sampling with no relation to any path, beside 28 trees.
    Nothing was over budget -- 328 instances against a ceiling of 12,000 -- so no
    economic limit could have caught it. What the contract lacked was the question.
    """
    from agents.simulation_planner import _POSITIONED_CEILING, _bound_positioned_scatter

    candidate = {
        "scatter": [
            {"species_id": "spc_lamp", "size_m": [0.5, 3.0, 0.5],
             "density_per_100m2": 1.0, "placement_is_incidental": False},
            {"species_id": "spc_fern", "size_m": [0.6, 0.4, 0.6],
             "density_per_100m2": 40.0, "placement_is_incidental": True},
        ]
    }
    _bound_positioned_scatter(candidate)
    by_id = {item["species_id"]: item for item in candidate["scatter"]}

    assert by_id["spc_lamp"]["max_instances"] == _POSITIONED_CEILING
    # A fern genuinely does not care where it grows, so nothing about it changes --
    # including its density, which is this rule's neighbour and not this rule.
    assert "max_instances" not in by_id["spc_fern"]
    assert by_id["spc_fern"]["density_per_100m2"] == 40.0

    # Fewer lamps than somebody asked for is a change to their world.
    disclosed = [
        item for item in candidate["approximations"] if item["user_visible"]
    ]
    assert [item["requirement_id"] for item in disclosed] == ["spc_lamp"]
    assert "belongs somewhere specific" in disclosed[0]["reason"]


def test_an_unanswered_species_is_left_alone_rather_than_guessed_at():
    """Absent is not false.

    Making the field required would invalidate every preserved spec, so absent has
    to mean "the planner did not say" and behave exactly as before. Inferring the
    answer from the species name is the noun table this system keeps refusing to
    build: `spc_lamp` here is deliberately named like the thing that IS positioned,
    and must still be untouched, because the name is not the claim.
    """
    from agents.simulation_planner import _bound_positioned_scatter

    candidate = {
        "scatter": [
            {"species_id": "spc_lamp", "size_m": [0.5, 3.0, 0.5],
             "density_per_100m2": 1.0}
        ]
    }
    _bound_positioned_scatter(candidate)
    assert "max_instances" not in candidate["scatter"][0]
    assert "approximations" not in candidate


def test_a_tighter_cap_the_planner_chose_is_not_loosened():
    """The ceiling is an upper bound, never a target.

    A planner asking for two of something positioned is being more careful than this
    rule requires, and raising it to six would be us adding content nobody asked for.
    """
    from agents.simulation_planner import _bound_positioned_scatter

    candidate = {
        "scatter": [
            {"species_id": "spc_bench", "size_m": [1.6, 0.9, 0.6],
             "density_per_100m2": 0.5, "max_instances": 2,
             "placement_is_incidental": False}
        ]
    }
    _bound_positioned_scatter(candidate)
    assert candidate["scatter"][0]["max_instances"] == 2
    # Nothing was reduced, so there is nothing to disclose.
    assert "approximations" not in candidate


def test_an_instance_cap_is_reported_as_a_shortfall_not_as_success():
    """Otherwise the report says the species got exactly what it asked for.

    A lamp capped from 168 to 6 came out as requested=6, achieved=6, reason=None --
    a row asserting a guarantee nothing gave (rules 11/13). `requested_instances`
    has to stay the figure density asked for, with the cap recorded beside it.
    """
    from pcg.scatter import instance_scatter

    spec = {
        "meta": {"seed": 7},
        "scatter": [
            {
                "species_id": "spc_lamp",
                "semantic_type": "cast_iron_street_lamp",
                "size_m": [0.5, 3.0, 0.5],
                "density_per_100m2": 1.0,
                "max_instances": 6,
                "clustering": "random",
            }
        ],
    }
    report = instance_scatter(spec, WORLD, [], {})["species"][0]

    assert report["placed_instances"] == 6
    # 1.0 per 100 m2 over the fixture's 10,400 m2 of zones.
    assert report["requested_instances"] == 104
    assert report["capped_to_instances"] == 6
    assert report["shortfall_reason"] == "instance_cap"


def test_a_species_within_its_own_cap_reports_no_shortfall():
    """The cap only speaks when it actually bound something.

    A `max_instances` above what density wanted did not limit anything, and saying
    it did would make the honest reason unreadable by crying wolf on every species
    that carries a harmless ceiling.
    """
    from pcg.scatter import instance_scatter

    spec = {
        "meta": {"seed": 7},
        "scatter": [
            {
                "species_id": "spc_boulder",
                "semantic_type": "granite_boulder",
                "size_m": [1.2, 0.8, 1.2],
                "density_per_100m2": 2.0,
                "max_instances": 500,
                "clustering": "random",
            }
        ],
    }
    report = instance_scatter(spec, WORLD, [], {})["species"][0]

    assert report["capped_to_instances"] is None
    assert report["shortfall_reason"] != "instance_cap"
