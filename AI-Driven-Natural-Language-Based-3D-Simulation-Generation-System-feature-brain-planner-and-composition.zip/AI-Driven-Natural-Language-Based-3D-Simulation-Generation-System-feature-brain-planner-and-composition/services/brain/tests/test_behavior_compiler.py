"""Capabilities compile to deterministic data, never arbitrary scripts."""

from __future__ import annotations

import json

from behaviors.compiler import (
    compile_behavior_plan,
    execute_probe,
    validate_compiled_behaviors,
)

from tests.test_simulation_core import _dog_village


def test_dog_village_compiles_locomotion_and_real_door_state_machines():
    plan, errors = compile_behavior_plan(_dog_village())
    assert validate_compiled_behaviors(plan)["status"] == "PASS"
    capability_ids = {graph["capability_id"] for graph in plan["graphs"]}
    assert {"locomotion", "animal", "openable", "camera_control"} <= capability_ids
    # Asset qualification has not run, so compilation must not assume the dog
    # is rigged merely because the planner requested animation.
    assert any(
        error["capability_id"] == "animal"
        and error["code"] == "RUNTIME_BINDING_INCOMPLETE"
        for error in errors
    )


def test_measured_rigged_animal_qualifies_partial_runtime_binding():
    spec = _dog_village()
    descriptors = {
        "ent_controlled_actor": {
            "animation": {"rigged": True, "locomotion_compatible": True}
        }
    }
    _, errors = compile_behavior_plan(spec, descriptors)
    assert not any(
        error["capability_id"] == "animal"
        and error["code"] == "RUNTIME_BINDING_INCOMPLETE"
        for error in errors
    )


def test_unrigged_animal_cannot_qualify_partial_runtime_binding():
    spec = _dog_village()
    descriptors = {
        "ent_controlled_actor": {
            "animation": {"rigged": False, "locomotion_compatible": False}
        }
    }
    _, errors = compile_behavior_plan(spec, descriptors)
    error = next(item for item in errors if item["capability_id"] == "animal")
    assert set(error["missing"]) == {"rigged", "locomotion_compatible"}


def test_openable_probe_changes_runtime_state_and_collision():
    plan, _ = compile_behavior_plan(_dog_village())
    graph = next(
        item for item in plan["graphs"] if item["capability_id"] == "openable"
    )
    result = execute_probe(graph, graph["probes"][0])
    assert result["status"] == "PASS"
    assert result["state"] == "open"
    assert result["properties"]["open"] is True
    assert result["properties"]["collision_enabled"] is False


def test_unavailable_runtime_binding_is_a_compile_error_not_a_fake_success():
    """An unimplemented capability must fail loudly rather than compile hollow.

    This used to name `dialogue` as the example, which was correct until dialogue
    was implemented -- exactly the way a test can quietly stop testing anything.
    It now asks the registry which capability is genuinely unavailable, so it
    keeps meaning what it says as capabilities land.
    """
    from capabilities.registry import capability_index

    unavailable = sorted(
        capability_id
        for capability_id, entry in capability_index().items()
        if entry["status"] == "unavailable"
    )
    if not unavailable:
        return  # nothing left unimplemented; nothing to assert
    capability_id = unavailable[0]
    spec = _dog_village()
    spec["entities"][0]["capabilities"].append(capability_id)
    spec["capabilities"].append(capability_id)
    plan, errors = compile_behavior_plan(spec)
    graph = next(
        graph for graph in plan["graphs"] if graph["capability_id"] == capability_id
    )
    assert graph["runtime_binding"] is None
    assert any(
        error["capability_id"] == capability_id and error["status"] == "unavailable"
        for error in errors
    )


def test_behavior_contract_contains_no_executable_source_code():
    plan, _ = compile_behavior_plan(_dog_village())
    serialized = json.dumps(plan).lower()
    assert "gdscript" not in serialized
    assert "extends node" not in serialized
    assert "eval(" not in serialized


def test_sittable_is_bound_and_compiles_without_a_binding_error():
    """Seating is implemented, not merely enumerated.

    `sittable` sat in the schema enum with `runtime_binding: None` and a
    behaviour template that nothing honoured, so every prompt containing
    ordinary seating -- a museum, a library, a waiting room, a park -- declared
    it and failed behaviour compilation with RUNTIME_BINDING_INCOMPLETE. The
    runtime now seats the player on the entity and releases them again, so the
    capability is bound.
    """
    from behaviors.compiler import compile_behavior_plan
    from capabilities.registry import capability_index

    entry = capability_index()["sittable"]
    assert entry["status"] == "supported"
    assert entry["runtime_binding"], "a supported capability needs a binding"

    spec = {
        "meta": {"simulation_id": "sim_seat"},
        "capabilities": ["sittable"],
        "entities": [
            {
                "entity_id": "ent_bench",
                "capabilities": ["sittable"],
                "semantic_type": "bench",
                "role": "furniture",
            }
        ],
        "requirements": [],
    }
    plan, errors = compile_behavior_plan(spec)
    assert errors == []
    assert [(g["entity_id"], g["capability_id"]) for g in plan["graphs"]] == [
        ("ent_bench", "sittable")
    ]


def test_a_supported_capability_never_lacks_a_runtime_binding():
    """The invariant behind the whole capability-status field.

    `supported` means the engine can build it. A supported entry with no
    binding is the contradiction that made `sittable` fail for months while
    reporting itself as available to anyone reading the enum.
    """
    from capabilities.registry import capability_index

    for capability_id, entry in capability_index().items():
        if entry.get("status") == "supported":
            assert entry.get("runtime_binding"), capability_id


def test_pickup_carry_drop_is_bound_and_compiles():
    """Carrying is implemented, not just collection.

    The manifest said "collection is implemented; persistent carry and drop are
    not complete", and in the runtime that meant the graph advanced through
    grounded/carried/dropped while the object never left the ground: nothing
    honoured `carried` or `physics_enabled`. The object is now reparented to the
    player, so it follows them through walking, teleporting and the immersive
    rig alike, and is set back down in front of them on drop.
    """
    from behaviors.compiler import compile_behavior_plan
    from capabilities.registry import capability_index

    entry = capability_index()["pickup_carry_drop"]
    assert entry["status"] == "supported"
    assert entry["runtime_binding"]

    spec = {
        "meta": {"simulation_id": "sim_carry"},
        "capabilities": ["pickup_carry_drop"],
        "entities": [
            {
                "entity_id": "ent_crate",
                "capabilities": ["pickup_carry_drop"],
                "semantic_type": "crate",
                "role": "prop",
            }
        ],
        "requirements": [],
    }
    plan, errors = compile_behavior_plan(spec)
    assert errors == []
    graph = plan["graphs"][0]
    # Both directions must exist, or the object can be picked up and never set
    # down -- the failure `interact()` used to guarantee for sittable.
    triggers = {t["trigger"] for t in graph["transitions"]}
    assert {"pickup", "drop"} <= triggers


def test_machine_states_are_distinguishable_and_the_limitation_is_honest():
    """A running machine differs from a stopped one, and says what it still lacks.

    The manifest claimed "binary operating state works" while nothing in the
    runtime honoured `operating`, so off, running and failed rendered
    identically: the claim was true only of the data. The runtime now drives a
    visible spin, stops it to rest, and leaves a FAILED machine seized where it
    stopped so a seizure is distinguishable from being switched off.

    It stays PARTIAL on purpose. A machine consumes no inputs and produces no
    outputs, and the limitation now names that rather than understating the
    state machine.
    """
    from behaviors.compiler import compile_behavior_plan
    from capabilities.registry import capability_index

    entry = capability_index()["machine"]
    assert entry["status"] == "partial"
    limitation = " ".join(entry["limitations"]).lower()
    assert "input" in limitation and "output" in limitation
    assert "binary operating state works" not in limitation

    spec = {
        "meta": {"simulation_id": "sim_machine"},
        "capabilities": ["machine"],
        "entities": [
            {
                "entity_id": "ent_press",
                "capabilities": ["machine"],
                "semantic_type": "press",
                "role": "equipment",
            }
        ],
        "requirements": [],
    }
    plan, errors = compile_behavior_plan(spec)
    assert errors == []
    states = {s["state_id"] for s in plan["graphs"][0]["states"]}
    assert {"off", "running", "failed"} <= states


def test_a_sensor_can_be_reached_without_a_key_press():
    """`sense` was in no input map, so nothing in a running world could fire it.

    The graph compiled correctly and the state was reachable only from a test
    harness -- the same shape of fault as sittable and machine, but worse: a
    sensor that waits to be pressed is not a sensor at all. The runtime now
    samples the player's distance each frame, so the trigger belongs to no input
    map by design and must stay out of `interact()`'s preference list.

    This asserts the two properties the runtime depends on: the trigger names it
    samples for, and that leaving is possible so the sensor can fire more than
    once.
    """
    from behaviors.compiler import compile_behavior_plan

    spec = {
        "meta": {"simulation_id": "sim_sensor"},
        "capabilities": ["sensor_trigger"],
        "entities": [
            {
                "entity_id": "ent_plate",
                "capabilities": ["sensor_trigger"],
                "semantic_type": "pressure_plate",
                "role": "prop",
            }
        ],
        "requirements": [],
    }
    plan, errors = compile_behavior_plan(spec)
    assert errors == []
    graph = plan["graphs"][0]
    triggers = {t["trigger"] for t in graph["transitions"]}
    assert {"sense", "reset"} <= triggers
    assert graph["initial_state"] == "idle"
    assert graph["runtime_binding"]


def test_the_sensor_limitation_does_not_overclaim_sensing():
    """Proximity is not sensing in general, and the manifest has to say so.

    The old wording ("boolean triggers work; general sensor sampling and logging
    are incomplete") was vague enough to read as almost finished. A factory
    prompt asking for a sensor that counts items or starts a machine gets
    neither, and the limitation must name both so the gap is visible before
    someone builds on it.
    """
    from capabilities.registry import capability_index

    entry = capability_index()["sensor_trigger"]
    assert entry["status"] == "partial"
    limitation = " ".join(entry["limitations"]).lower()
    assert "proximity" in limitation
    assert "count" in limitation or "quantit" in limitation
    assert "history" in limitation or "log" in limitation
    assert "boolean triggers work" not in limitation


def test_a_vehicle_can_reach_moving_and_get_back_out_of_it():
    """`moving` was reachable from nothing and was a dead end once reached.

    `drive` appeared in no input map, so the state compiled and validated while
    being enterable only from a test harness -- the sittable fault again. Worse,
    `moving` accepts only `stop`, which `interact()` did not offer either, so a
    driver who did reach it was stuck in a vehicle forever.

    Throttle now comes from the movement keys, which is why `drive` must stay out
    of the interact map: one key cannot mean both "drive off" and "get out" from
    the same state. `stop` must stay in it, because it is the only way out of
    `moving`.
    """
    from behaviors.compiler import compile_behavior_plan

    spec = {
        "meta": {"simulation_id": "sim_vehicle"},
        "capabilities": ["vehicle"],
        "entities": [
            {
                "entity_id": "ent_cart",
                "capabilities": ["vehicle"],
                "semantic_type": "cart",
                "role": "vehicle",
            }
        ],
        "requirements": [],
    }
    plan, errors = compile_behavior_plan(spec)
    assert errors == []
    graph = plan["graphs"][0]
    transitions = {(t["from_state"], t["trigger"]): t["to_state"] for t in graph["transitions"]}
    assert transitions[("parked", "enter")] == "occupied"
    assert transitions[("occupied", "drive")] == "moving"
    # Every state must have a way out, or the player is trapped in it.
    reachable_out = {state for state, _ in transitions}
    assert {"parked", "occupied", "moving"} <= reachable_out


def test_the_vehicle_limitation_names_what_driving_still_lacks():
    """The old wording described the body and hid that nothing drove.

    "Vehicle bodies and doors work; deterministic driving dynamics are
    incomplete" reads as a refinement pending, when in fact a vehicle could not
    move at all. Driving now works kinematically, and the limitation has to name
    the parts that are still absent so the next person does not assume physics.
    """
    from capabilities.registry import capability_index

    entry = capability_index()["vehicle"]
    assert entry["status"] == "partial"
    limitation = " ".join(entry["limitations"]).lower()
    assert "kinematic" in limitation
    assert "momentum" in limitation or "braking" in limitation
    assert "deterministic driving dynamics are incomplete" not in limitation


def test_animation_requirement_comes_from_capabilities_not_from_the_planner():
    """A tractor marked "animated" killed a whole run at a gate it could not pass.

    `requires_animation` is not a stylistic wish: it means the entity must be
    matched to a rigged asset with locomotion-compatible clips, and
    `asset_animation_compatibility` is mandatory. A farm-yard prompt had its
    tractor marked animated, no rigged tractor exists in any kit, and every gate
    behind the failure came back NOT_RUN.

    Which capabilities need a rig is declared in the packs, so the flag is
    derived from them rather than guessed in free text -- and derived in both
    directions, because an entity carrying `animal` with the flag omitted would
    otherwise have skipped the check and shipped an unrigged creature.
    """
    from agents.simulation_planner import (
        _capabilities_requiring_a_rig,
        _normalise_animation_requirement,
    )

    # Read from the manifests, so a capability added later is classified by its
    # own declaration rather than by a list here.
    assert _capabilities_requiring_a_rig() == frozenset({"animal", "locomotion"})

    candidate = {
        "entities": [
            {
                "entity_id": "ent_tractor",
                "capabilities": ["vehicle"],
                "asset": {"requires_animation": True},
            },
            {
                "entity_id": "ent_dog",
                "capabilities": ["animal"],
                "asset": {"requires_animation": False},
            },
            {
                "entity_id": "ent_actor",
                "capabilities": ["locomotion", "camera_control"],
                "asset": {"requires_animation": True},
            },
        ]
    }
    _normalise_animation_requirement(candidate)
    flags = {
        entity["entity_id"]: entity["asset"]["requires_animation"]
        for entity in candidate["entities"]
    }
    assert flags == {"ent_tractor": False, "ent_dog": True, "ent_actor": True}
    # Both corrections are disclosed; the actor was already right and needs no note.
    disclosed = {item["requirement_id"] for item in candidate["approximations"]}
    assert disclosed == {"ent_tractor", "ent_dog"}


def test_guidance_names_the_objects_that_carry_each_capability():
    """Listing a capability is not the same as recognising the object with it.

    A farm prompt asking for "a bench under an apple tree" produced a bench with
    no capabilities at all while sittable sat in the supported list directly
    above it, so the world had seating nobody could sit on.

    The examples must stay keyed to the live status buckets. The previous
    hardcoded one -- "a bench is furniture, not a sittable" -- became false the
    day sittable gained a binding, inside the very function that exists to keep
    this text from going stale.
    """
    from agents.simulation_planner import _EXEMPLARS, capability_guidance
    from capabilities.registry import capability_index

    guidance = capability_guidance()
    index = capability_index()
    assert "a bench, chair, stool, pew or sofa is sittable" in guidance

    for capability_id, phrase in _EXEMPLARS.items():
        status = index[capability_id]["status"]
        if status in {"supported", "partial"}:
            assert phrase in guidance, capability_id
        else:
            # An uninstalled capability must take its own examples out with it,
            # or the prompt teaches the planner to ask for something the engine
            # will refuse to compile.
            assert phrase not in guidance, capability_id


def test_dialogue_compiles_one_state_per_line_and_carries_the_words():
    """The last capability with no binding at all now has one.

    Dialogue is the only capability whose content the planner must write; naming
    it is not enough. The graph shape follows from that: one state per line, with
    the text riding in that state's observable properties, so the words a visitor
    reads stay inside the state machine where `runtime_interactions` can assert
    them. A two-state graph would have put line progression in the runtime, which
    could then display anything and still report the right state.
    """
    from behaviors.compiler import compile_behavior_plan, validate_behavior_plan

    lines = [
        "Mind the platform edge.",
        "Trains run every ten minutes.",
        "Have a good journey.",
    ]
    spec = {
        "meta": {"simulation_id": "sim_dialogue"},
        "capabilities": ["dialogue"],
        "entities": [
            {
                "entity_id": "ent_guard",
                "capabilities": ["dialogue"],
                "dialogue": lines,
                "semantic_type": "guard",
                "role": "interactive_object",
            }
        ],
        "requirements": [],
    }
    plan, errors = compile_behavior_plan(spec)
    assert errors == []
    validate_behavior_plan(plan)
    graph = plan["graphs"][0]
    assert graph["runtime_binding"] == "dialogue_lines"

    spoken = {
        state["state_id"]: state["observable_properties"]
        for state in graph["states"]
    }
    assert spoken["idle"] == {"speaking": False, "line": "", "line_index": -1}
    for index, line in enumerate(lines):
        assert spoken[f"speaking_{index}"] == {
            "speaking": True,
            "line": line,
            "line_index": index,
        }

    moves = {(t["from_state"], t["trigger"]): t["to_state"] for t in graph["transitions"]}
    assert moves[("idle", "talk")] == "speaking_0"
    assert moves[("speaking_0", "talk")] == "speaking_1"
    # Talking past the last line closes the conversation; without this the
    # visitor is stuck reading it with no way forward.
    assert moves[("speaking_2", "talk")] == "idle"
    # And `end` is available from every line, not just the last.
    for index in range(len(lines)):
        assert moves[(f"speaking_{index}", "end")] == "idle"


def test_two_speakers_hold_different_conversations():
    """The graph is built per entity, not looked up per capability.

    Every other capability shares one fixed shape across every entity that has
    it. Dialogue cannot: if both speakers drew from the same template they would
    say the same words, which is the failure mode a shared table invites.
    """
    from behaviors.compiler import compile_behavior_plan

    spec = {
        "meta": {"simulation_id": "sim_two"},
        "capabilities": ["dialogue"],
        "entities": [
            {
                "entity_id": "ent_guard",
                "capabilities": ["dialogue"],
                "dialogue": ["Mind the platform edge."],
                "semantic_type": "guard",
                "role": "interactive_object",
            },
            {
                "entity_id": "ent_vendor",
                "capabilities": ["dialogue"],
                "dialogue": ["Tea, two rupees.", "No change, sorry."],
                "semantic_type": "vendor",
                "role": "interactive_object",
            },
        ],
        "requirements": [],
    }
    plan, errors = compile_behavior_plan(spec)
    assert errors == []
    said = {
        graph["entity_id"]: [
            state["observable_properties"]["line"]
            for state in graph["states"]
            if state["observable_properties"]["speaking"]
        ]
        for graph in plan["graphs"]
    }
    assert said == {
        "ent_guard": ["Mind the platform edge."],
        "ent_vendor": ["Tea, two rupees.", "No change, sorry."],
    }


def test_a_speaker_with_no_lines_becomes_a_plain_object():
    """Nothing may invent a greeting for a guard nobody wrote lines for.

    `entity.dialogue` is required only when the capability is present, and that
    is a conditional rule the grammar adapter strips, so the planner cannot see
    it. Two rules of that kind have already cost whole runs.

    A speaker with no lines is not a speaker awaiting content; it is a plain
    object that was mislabelled. Shipping a person who visibly does nothing when
    you talk to them reads worse than one who was never offered a conversation,
    and the top-level capability list has to let go of dialogue too or
    capability_declaration fails on a capability no entity holds.
    """
    from agents.simulation_planner import _normalise_dialogue

    candidate = {
        "capabilities": ["dialogue", "locomotion"],
        "entities": [
            {
                "entity_id": "ent_guide",
                "capabilities": ["dialogue", "locomotion"],
                "dialogue": [],
            },
            # Lines on something that is not a speaker fail validation as surely
            # as a speaker with no lines.
            {
                "entity_id": "ent_crate",
                "capabilities": ["pickup_carry_drop"],
                "dialogue": ["I am a crate"],
            },
        ],
    }
    _normalise_dialogue(candidate)
    assert candidate["entities"][0]["capabilities"] == ["locomotion"]
    assert "dialogue" not in candidate["entities"][0]
    assert "dialogue" not in candidate["entities"][1]
    assert candidate["capabilities"] == ["locomotion"]
    # The visitor is told, because a person they expected to talk to is now a
    # statue.
    assert candidate["approximations"][0]["requirement_id"] == "ent_guide"
    assert candidate["approximations"][0]["user_visible"] is True


def test_an_over_long_line_is_trimmed_rather_than_rejected():
    """The canonical schema caps a line at 200 characters.

    One talkative sentence would otherwise throw out the entire spec and drop the
    run to the deterministic fallback -- a generic empty world -- which is a
    catastrophic response to a comma.
    """
    from agents.simulation_planner import _normalise_dialogue

    candidate = {
        "capabilities": ["dialogue"],
        "entities": [
            {
                "entity_id": "ent_guide",
                "capabilities": ["dialogue"],
                "dialogue": ["word " * 80],
            }
        ],
    }
    _normalise_dialogue(candidate)
    assert len(candidate["entities"][0]["dialogue"][0]) <= 200
    assert candidate["entities"][0]["capabilities"] == ["dialogue"]


def test_a_lineless_speaker_reaching_the_compiler_is_reported_not_raised():
    """The planner strips these; a hand-written spec can still bring one in.

    Edit round-trips and hand-authored specs do not pass through the planner
    normalisation, and the house rule is that validators return {code, ...}
    objects. A traceback out of the compiler would take the whole run down over
    one entity, and would tell the repair loop nothing it could act on.
    """
    from behaviors.compiler import compile_behavior_plan

    spec = {
        "meta": {"simulation_id": "sim_mute"},
        "capabilities": ["dialogue"],
        "entities": [
            {
                "entity_id": "ent_statue",
                "capabilities": ["dialogue"],
                "semantic_type": "guard",
                "role": "interactive_object",
            }
        ],
        "requirements": [],
    }
    plan, errors = compile_behavior_plan(spec)
    assert plan["graphs"] == []
    assert [error["code"] for error in errors] == ["DIALOGUE_LINES_MISSING"]
    assert errors[0]["entity_id"] == "ent_statue"


def test_the_declaration_gate_resolves_capabilities_entities_hold():
    """It resolved the top-level list only, which is not what the spec uses.

    A railway-platform run declared `camera_control` and `locomotion` at the top
    while its entities held `dialogue`, `sittable` and `openable`. Three
    capabilities reached the build without ever being resolved against the pack
    registry -- by the gate whose entire job is to resolve them. Behaviour
    compilation still checked runtime bindings per entity, so the hole was
    specifically the platform-support check, which nothing else performs.
    """
    from capabilities.registry import capability_index
    from worker.simulation_tasks import _planning_gate_reports

    spec = {
        "capabilities": ["locomotion"],
        "requirements": [],
        "entities": [
            {"entity_id": "ent_guard", "capabilities": ["dialogue"]},
            {"entity_id": "ent_bench", "capabilities": ["sittable"]},
        ],
        "request": {"target_platforms": ["web"]},
    }
    report = _planning_gate_reports(spec)["capability_declaration"]
    resolved = {item["capability_id"] for item in report["evidence"]["resolved"]}
    assert resolved == {"locomotion", "dialogue", "sittable"}
    # Bound-but-partial is not a gap; only an unbound capability fails closed.
    assert report["status"] == "PASS"

    # And an unbound capability held only by an entity must now be caught, which
    # is the whole point: it used to sail straight through.
    unbound = sorted(
        capability_id
        for capability_id, entry in capability_index().items()
        if entry["status"] == "unavailable"
    )
    if unbound:
        spec["entities"].append(
            {"entity_id": "ent_thing", "capabilities": [unbound[0]]}
        )
        blocked = _planning_gate_reports(spec)["capability_declaration"]
        assert blocked["status"] == "FAIL"
        assert blocked["errors"][0]["code"] == "CAPABILITY_INCOMPLETE"


def _wired_spec(links: list[dict]) -> dict:
    return {
        "meta": {"simulation_id": "sim_wired"},
        "capabilities": ["sensor_trigger", "openable", "machine"],
        "requirements": [],
        "entities": [
            {"entity_id": "ent_plate", "capabilities": ["sensor_trigger"],
             "semantic_type": "pressure_plate", "role": "prop"},
            {"entity_id": "ent_door", "capabilities": ["openable"],
             "semantic_type": "door", "role": "structure"},
            {"entity_id": "ent_press", "capabilities": ["machine"],
             "semantic_type": "press", "role": "equipment"},
        ],
        "causal_links": links,
    }


def _link(link_id: str, when: tuple, then: tuple) -> dict:
    return {
        "link_id": link_id,
        "when": {
            "entity_id": when[0],
            "capability_id": when[1],
            "enters_state": when[2],
        },
        "then": {
            "entity_id": then[0],
            "capability_id": then[1],
            "trigger": then[2],
        },
    }


def test_one_capability_can_cause_another():
    """Three limitations described the same missing mechanism.

    `sensor_trigger` said a sensor "does not drive another entity", `machine` said
    process graphs "are not installed", and `dialogue` said "nothing said can change
    the world". A transition could not fire another capability trigger, so every
    world was a set of objects that each worked alone.

    Attached to the transitions that ARRIVE at the state rather than to the state, so
    it fires on the change: a sensor held in `triggered` while somebody stands on the
    plate opens the door once, not once per frame.
    """
    from behaviors.compiler import compile_behavior_plan, validate_behavior_plan

    spec = _wired_spec([
        _link("lnk_open", ("ent_plate", "sensor_trigger", "triggered"),
              ("ent_door", "openable", "interact")),
        _link("lnk_run", ("ent_plate", "sensor_trigger", "triggered"),
              ("ent_press", "machine", "start")),
    ])
    plan, errors = compile_behavior_plan(spec)
    assert errors == []
    validate_behavior_plan(plan)

    plate = next(g for g in plan["graphs"] if g["entity_id"] == "ent_plate")
    arriving = [t for t in plate["transitions"] if t["to_state"] == "triggered"]
    assert arriving, "the state has to be reachable for a link to fire"
    for transition in arriving:
        targets = {(e["entity_id"], e["trigger"]) for e in transition["emits"]}
        assert targets == {("ent_door", "interact"), ("ent_press", "start")}

    # A transition that does not reach the state carries nothing, and a graph with no
    # wiring omits the key entirely so it serialises exactly as it did before.
    assert all(
        "emits" not in t for t in plate["transitions"] if t["to_state"] != "triggered"
    )
    door = next(g for g in plan["graphs"] if g["entity_id"] == "ent_door")
    assert all("emits" not in t for t in door["transitions"])


def test_a_link_that_cannot_work_is_refused_rather_than_compiled():
    """A world that looks wired and is not is worse than one with no wiring.

    Each refusal carries its own code so a repair can tell which end was wrong: the
    entity, the state it claims to enter, or the trigger the far end accepts.
    """
    from behaviors.compiler import compile_behavior_plan

    cases = {
        "CAUSAL_LINK_UNRESOLVED": _link(
            "lnk_a", ("ent_plate", "sensor_trigger", "triggered"),
            ("ent_ghost", "openable", "interact")),
        "CAUSAL_LINK_STATE_UNKNOWN": _link(
            "lnk_b", ("ent_plate", "sensor_trigger", "exploded"),
            ("ent_door", "openable", "interact")),
        "CAUSAL_LINK_TRIGGER_UNKNOWN": _link(
            "lnk_c", ("ent_plate", "sensor_trigger", "triggered"),
            ("ent_door", "openable", "detonate")),
        "CAUSAL_LINK_SELF_REFERENTIAL": _link(
            "lnk_d", ("ent_door", "openable", "open"),
            ("ent_door", "openable", "interact")),
    }
    for code, link in cases.items():
        plan, errors = compile_behavior_plan(_wired_spec([link]))
        assert code in {error["code"] for error in errors}, code
        wired = sum(
            1 for g in plan["graphs"] for t in g["transitions"] if t.get("emits")
        )
        assert wired == 0, f"{code} must wire nothing"


def test_an_entity_lacking_the_capability_is_not_wired():
    """The right entity with the wrong capability is still unresolvable."""
    from behaviors.compiler import compile_behavior_plan

    plan, errors = compile_behavior_plan(_wired_spec([
        _link("lnk_e", ("ent_door", "sensor_trigger", "triggered"),
              ("ent_door", "openable", "interact"))
    ]))
    assert "CAUSAL_LINK_UNRESOLVED" in {error["code"] for error in errors}
    assert not any(t.get("emits") for g in plan["graphs"] for t in g["transitions"])


def test_a_cycle_compiles_because_an_oscillator_is_a_real_world():
    """Two things driving each other is a design, not necessarily a mistake.

    A machine that trips a sensor that stops the machine is a world somebody might
    want, so cycles are not refused. The runtime caps chain depth instead. Verified
    in the engine: a ring of four links whose every hop is accepted reports "causal
    chain exceeded 8 steps" and returns in 47 ms rather than locking the frame.

    An earlier attempt at that probe used two doors toggling each other and proved
    nothing -- `openable` refuses `interact` from `opening`, so the state machine
    stopped the chain on its own before the cap was ever reached.
    """
    from behaviors.compiler import compile_behavior_plan

    plan, errors = compile_behavior_plan(_wired_spec([
        _link("lnk_f", ("ent_plate", "sensor_trigger", "triggered"),
              ("ent_press", "machine", "start")),
        _link("lnk_g", ("ent_press", "machine", "running"),
              ("ent_plate", "sensor_trigger", "reset")),
    ]))
    assert errors == []
    assert sum(
        len(t.get("emits", [])) for g in plan["graphs"] for t in g["transitions"]
    ) == 2


def test_the_planner_drops_a_link_it_cannot_honour_and_says_so():
    """From the planner an unresolvable link is routine, not fatal.

    The model writes a link against an entity it then renames or drops. Failing the
    run would throw away a world that is otherwise fine, and guessing which entity
    was meant would invent a causal claim nobody made -- the visitor would watch the
    wrong thing happen and believe it.
    """
    from agents.simulation_planner import _normalise_causal_links

    candidate = {
        "entities": [
            {"entity_id": "ent_plate", "capabilities": ["sensor_trigger"]},
            {"entity_id": "ent_door", "capabilities": ["openable"]},
        ],
        "causal_links": [
            _link("lnk_good", ("ent_plate", "sensor_trigger", "triggered"),
                  ("ent_door", "openable", "interact")),
            _link("lnk_ghost", ("ent_plate", "sensor_trigger", "triggered"),
                  ("ent_missing", "openable", "interact")),
        ],
    }
    _normalise_causal_links(candidate)
    assert [link["link_id"] for link in candidate["causal_links"]] == ["lnk_good"]
    assert candidate["approximations"][0]["requirement_id"] == "lnk_ghost"
    assert candidate["approximations"][0]["user_visible"] is True


def test_the_three_limitations_no_longer_deny_wiring():
    """Each denied this was possible, in the same words three different ways.

    What a machine still lacks is QUANTITIES: it consumes nothing and produces
    nothing, so a line of machines can be sequenced by cause while nothing is counted
    or depleted along it. That is narrower, and true.
    """
    from capabilities.registry import capability_index

    index = capability_index()
    sensor = " ".join(index["sensor_trigger"]["limitations"])
    assert "does not drive another entity" not in sensor
    assert "causal_links" in sensor

    dialogue = " ".join(index["dialogue"]["limitations"])
    assert "nothing said can change the world" not in dialogue

    machine = " ".join(index["machine"]["limitations"])
    assert "are not installed" not in machine
    assert "quantities" in machine.lower()
