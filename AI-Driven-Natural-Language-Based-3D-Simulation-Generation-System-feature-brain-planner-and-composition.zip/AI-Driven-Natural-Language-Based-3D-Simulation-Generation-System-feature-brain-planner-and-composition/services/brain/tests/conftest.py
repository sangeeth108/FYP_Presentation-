"""Test fixtures. Runs the whole stack on SQLite with Celery in eager mode — so the
suite needs NO Postgres, NO Redis, NO Docker. The production path (psycopg + real
Redis) is exercised via `docker compose` and CI service containers.
"""

from __future__ import annotations

import os
import tempfile
from collections.abc import Iterator

import pytest

# Must be set BEFORE importing the app so the module-level engine picks them up.
# Each pytest process needs its own file. CI shards and local parallel batches
# previously raced while dropping/creating the same SQLite tables.
_TMP_DB = os.path.join(
    tempfile.gettempdir(),
    f"serendib_brain_test_{os.getpid()}.db",
)
os.environ["DATABASE_URL"] = f"sqlite+pysqlite:///{_TMP_DB}"
os.environ["CELERY_TASK_ALWAYS_EAGER"] = "true"
# Unit/integration tests must never inherit live GPU/engine switches from the
# developer's .env. External model, asset and engine paths have dedicated smoke
# tests; the default suite is deterministic and offline.
os.environ["LLM_ENABLED"] = "false"
os.environ["ASSET_GEN_ENABLED"] = "false"
os.environ["AUDIO_GEN_ENABLED"] = "false"
os.environ["GODOT_BIN"] = ""
os.environ["API_SECRET_KEY"] = "test-only-secret-key-at-least-thirty-two-bytes"
os.environ["TRAINING_PSEUDONYM_KEY"] = "test-pseudonym-key-at-least-thirty-two-bytes"

from core import db as db_module  # noqa: E402
from core.db import Base  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from main import app  # noqa: E402
from sqlalchemy import event  # noqa: E402


@event.listens_for(db_module.engine, "connect")
def _enforce_sqlite_foreign_keys(dbapi_connection, _connection_record) -> None:
    """Keep local integration tests aligned with PostgreSQL FK behavior."""
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.close()


@event.listens_for(db_module.engine, "begin")
def _defer_sqlite_foreign_keys(connection) -> None:
    """Defer FK checks to COMMIT for the current transaction. The ORM models
    declare FK *columns* but no relationships, so the unit of work has no basis
    to order parent inserts before children within a single flush. PostgreSQL
    supports DEFERRABLE constraints for exactly this; SQLite offers the same via
    this per-transaction pragma (it resets on each COMMIT/ROLLBACK, so it must be
    re-armed on every begin). Referential integrity is still fully enforced — it
    is simply checked once at commit rather than statement-by-statement."""
    connection.exec_driver_sql("PRAGMA defer_foreign_keys=ON")


@pytest.fixture(autouse=True)
def _fresh_db() -> Iterator[None]:
    # Rebuild the schema for each test for isolation (file-backed so the eager
    # Celery task and the request share the same SQLite database).
    Base.metadata.drop_all(bind=db_module.engine)
    Base.metadata.create_all(bind=db_module.engine)
    yield
    Base.metadata.drop_all(bind=db_module.engine)


@pytest.fixture
def client() -> Iterator[TestClient]:
    with TestClient(app) as c:
        yield c
