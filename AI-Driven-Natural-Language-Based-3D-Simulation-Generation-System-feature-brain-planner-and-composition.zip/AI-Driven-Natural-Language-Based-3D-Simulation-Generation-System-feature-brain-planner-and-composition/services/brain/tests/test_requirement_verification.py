"""Planner-independent requirement traceability and omission detection."""

from __future__ import annotations

from behaviors.compiler import compile_behavior_plan
from pcg.semantic import generate_semantic_world_plan
from verification.contracts import (
    deterministic_independent_critique,
    verify_requirement_traceability,
)

from tests.test_semantic_pcg import _measured_descriptors
from tests.test_simulation_core import _dog_village


def _compiled():
    spec = _dog_village()
    behaviors, _ = compile_behavior_plan(spec)
    world = generate_semantic_world_plan(
        spec, _measured_descriptors(spec), behaviors["graphs"]
    )
    return spec, behaviors, world


def test_every_dog_village_requirement_has_traceability_evidence():
    spec, behaviors, world = _compiled()
    report = verify_requirement_traceability(spec, world, behaviors)
    assert report["status"] == "PASS", report["errors"]
    assert len(report["evidence"]["traceability_matrix"]) == len(
        spec["requirements"]
    )


def test_missing_presence_contract_is_detected():
    spec, behaviors, world = _compiled()
    spec["requirements"] = [
        item
        for item in spec["requirements"]
        if item["subject"] != "ent_house_1"
    ]
    report = verify_requirement_traceability(spec, world, behaviors)
    assert report["status"] == "FAIL"
    assert any(
        error["code"] == "ENTITY_PRESENCE_REQUIREMENT_MISSING"
        for error in report["errors"]
    )


def test_dangling_spatial_target_is_detected():
    spec, behaviors, world = _compiled()
    spec["spatial_relations"][0]["target_id"] = "ent_missing_landmark"
    report = verify_requirement_traceability(spec, world, behaviors)
    assert any(
        error["code"] == "SPATIAL_TARGET_UNKNOWN" for error in report["errors"]
    )


def test_independent_critic_catches_prompt_actor_omission():
    spec, behaviors, world = _compiled()
    spec["entities"][0]["semantic_type"] = "person"
    report = deterministic_independent_critique(spec, world, behaviors)
    assert report["status"] == "FAIL"
    assert any(error["code"] == "PROMPT_ACTOR_OMITTED" for error in report["errors"])



def test_one_described_thing_may_be_built_from_several_entities():
    """A prompt naming "a fence" once is satisfied by four fence segments.

    Two rules previously made that impossible: every entity had to be the subject
    of an `exists` requirement, and every requirement's source_text had to appear
    VERBATIM in the prompt. Four segments needed four requirements, and three of
    them had no words in the prompt to quote. Measured on a twelve-prompt corpus,
    that collision was half of all traceability failures -- and in every case the
    planner was decomposing described content, not inventing new content.

    `part_of` carries coverage from the segment that holds the requirement to the
    ones that do not. It groups only: every placement consumer matches a specific
    relation name, so it moves nothing.
    """
    from verification.contracts import _presence_is_traced

    spec = {
        "requirements": [{"subject": "ent_fence_west", "predicate": "exists"}],
        "spatial_relations": [
            {
                "subject_id": "ent_fence_north",
                "target_id": "ent_fence_west",
                "relation": "part_of",
            },
            # A part of a part is still covered.
            {
                "subject_id": "ent_fence_east",
                "target_id": "ent_fence_north",
                "relation": "part_of",
            },
        ],
    }
    assert _presence_is_traced(spec, "ent_fence_west")
    assert _presence_is_traced(spec, "ent_fence_north")
    assert _presence_is_traced(spec, "ent_fence_east")


def test_an_entity_nobody_asked_for_is_still_caught():
    """The rule has to stay load-bearing, or widening it was vandalism.

    This is the difference between accepting a grouping the planner declares and
    synthesising the missing requirements ourselves: requirements derived from
    entities could never fail to cover entities, so the check would always pass
    and would catch nothing.
    """
    from verification.contracts import _presence_is_traced

    spec = {
        "requirements": [{"subject": "ent_fence_west", "predicate": "exists"}],
        "spatial_relations": [
            # Points at something with no requirement of its own.
            {
                "subject_id": "ent_barbecue",
                "target_id": "ent_gazebo",
                "relation": "part_of",
            },
            # And a relation that is not a grouping claim carries nothing.
            {
                "subject_id": "ent_lamp",
                "target_id": "ent_fence_west",
                "relation": "near",
            },
        ],
    }
    assert not _presence_is_traced(spec, "ent_barbecue")
    assert not _presence_is_traced(spec, "ent_lamp")
    assert not _presence_is_traced(spec, "ent_unmentioned")


def test_a_grouping_cycle_does_not_hang_the_validator():
    """A spec is model-authored, so it can contain a loop.

    Two entities each declared part of the other would walk forever without a
    visited set, and a validator that hangs is worse than one that rejects.
    """
    from verification.contracts import _presence_is_traced

    spec = {
        "requirements": [{"subject": "ent_real", "predicate": "exists"}],
        "spatial_relations": [
            {"subject_id": "ent_a", "target_id": "ent_b", "relation": "part_of"},
            {"subject_id": "ent_b", "target_id": "ent_a", "relation": "part_of"},
        ],
    }
    assert not _presence_is_traced(spec, "ent_a")


def test_part_of_is_in_the_contract_and_moves_nothing():
    """The relation must exist in the closed enum, and must not move anything.

    Deliberately not `attached_to`, which is already in the enum: that carries
    local_offset_m and local_rotation_y_degrees and drives the attachment solver,
    so four segments declared attached to each other would be physically relocated
    onto one another.

    This used to be checked by asserting the string "part_of" appeared nowhere in
    pcg/semantic.py -- a proxy for "no placement consumer reads it", which held
    only while nothing at all read it. `linear_structures` made the relation
    load-bearing for CONFLICT (a wall's segments must be allowed to abut, and with
    clearance between them a 16-segment wall lost six segments to its own
    neighbours), so the proxy started failing on a change that did not violate the
    property it stood for.

    The property itself is what is asserted now: adding a `part_of` relation must
    leave every transform in the plan identical. Waiving a clearance check is not
    moving anything, and a behavioural test can tell the two apart where a string
    search cannot.
    """
    import copy

    from agents.simulation_planner import simulation_schema
    from pcg.semantic import generate_semantic_world_plan

    schema = simulation_schema()
    relation = schema["$defs"]["spatial_relation"]["properties"]["relation"]
    assert "part_of" in relation["enum"]

    # The same fixture the placement tests use, so this exercises a real world
    # rather than a two-object toy that could not collide in the first place.
    from tests.test_simulation_core import _dog_village

    spec = _dog_village()
    without = generate_semantic_world_plan(copy.deepcopy(spec))

    pair = [entity["entity_id"] for entity in spec["entities"]][:2]
    grouped = copy.deepcopy(spec)
    grouped["spatial_relations"].append(
        {
            "subject_id": pair[1],
            "target_id": pair[0],
            "relation": "part_of",
            "hard": False,
        }
    )
    with_group = generate_semantic_world_plan(grouped)

    def transforms(plan: dict) -> dict:
        return {
            entity["entity_id"]: entity["transform"]
            for entity in plan["entities"]
        }

    assert transforms(without) == transforms(with_group)
