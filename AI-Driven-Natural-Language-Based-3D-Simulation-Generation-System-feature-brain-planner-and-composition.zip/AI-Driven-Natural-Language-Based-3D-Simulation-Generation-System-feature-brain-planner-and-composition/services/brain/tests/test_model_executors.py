import json

import model_router.executors as executors
from core.config import Settings
from model_router.executors import _validate_response
from model_router.registry import ModelDescriptor


def _route():
    return ModelDescriptor(
        model_id="critic",
        provider="ollama",
        roles=("critic",),
        modalities=("text",),
        context_window=8192,
        structured_output=True,
        licence_id="test",
        regions=("local",),
        available=True,
        deployment="test",
        model_digest="a" * 64,
        version="test",
        structured_output_reliability=1.0,
        suitability={"critic": 1.0},
        estimated_latency_ms=1,
        estimated_cost_per_million_tokens_usd=0.0,
        endpoint="http://critic.test",
    )


def _error(requirement_id="req_one"):
    return {
        "code": "MISSING_ENTITY",
        "path": "entities",
        "message": "required entity is absent",
        "hint": "add the entity",
        "requirement_ids": [requirement_id],
    }


def test_model_verdict_is_schema_and_requirement_bound():
    route = _route()
    valid = _validate_response(
        {"status": "FAIL", "errors": [_error()]},
        route,
        allowed_requirement_ids={"req_one"},
    )
    assert valid["status"] == "FAIL"

    malformed = _validate_response(
        {"status": "PASS", "errors": [], "override": "trust me"},
        route,
        allowed_requirement_ids={"req_one"},
    )
    assert malformed["status"] == "UNAVAILABLE"

    unknown = _validate_response(
        {"status": "FAIL", "errors": [_error("req_invented")]},
        route,
        allowed_requirement_ids={"req_one"},
    )
    assert unknown["status"] == "UNAVAILABLE"


def test_visual_critic_receives_fixed_camera_subject_manifest(tmp_path, monkeypatch):
    image = tmp_path / "view_00.png"
    image.write_bytes(b"not-decoded-by-the-mocked-transport")
    captured = {}

    def fake_chat(**kwargs):
        captured.update(kwargs)
        return {"status": "PASS", "errors": []}

    monkeypatch.setattr(executors, "_ollama_chat", fake_chat)
    result = executors.run_visual_critic(
        _route(),
        spec={
            "requirements": [{"requirement_id": "req_door"}],
            "entities": [
                {
                    "entity_id": "ent_door",
                    "semantic_type": "hinged_door",
                    "asset": {"brief": "a separate open wooden door leaf"},
                }
            ],
        },
        image_paths=[image],
        settings=Settings(),
        view_manifest=[
            {
                "file": "validation_views/view_00.png",
                "subject_entity_id": "ent_door",
                "purpose": "open_door_leaf_closeup",
            }
        ],
    )
    payload = json.loads(captured["content"])
    assert result["status"] == "PASS"
    assert payload["canonical_views"] == [
        {
            "image_index": 0,
            "file": "validation_views/view_00.png",
            "subject_entity_id": "ent_door",
            "purpose": "open_door_leaf_closeup",
        }
    ]


def test_visual_critic_scopes_each_view_to_its_camera_subject(tmp_path, monkeypatch):
    calls = []

    def fake_chat(**kwargs):
        calls.append(kwargs)
        return {"status": "PASS", "errors": []}

    monkeypatch.setattr(executors, "_ollama_chat", fake_chat)
    images = []
    entities = []
    requirements = []
    manifest = []
    for index in range(5):
        image = tmp_path / f"view_{index:02d}.png"
        image.write_bytes(f"image-{index}".encode())
        images.append(image)
        entity_id = f"ent_{index}"
        entities.append(
            {
                "entity_id": entity_id,
                "semantic_type": "animal",
                "asset": {"brief": f"animal {index}"},
                "physical": {"dynamic": True},
            }
        )
        requirements.append(
            {
                "requirement_id": f"req_{index}",
                "subject": entity_id,
                "validator": "entity_presence",
            }
        )
        manifest.append(
            {
                "file": image.name,
                "subject_entity_id": entity_id,
                "purpose": "entity_closeup",
            }
        )
    result = executors.run_visual_critic(
        _route(),
        spec={"requirements": requirements, "entities": entities},
        image_paths=images,
        settings=Settings(),
        view_manifest=manifest,
    )
    assert result["status"] == "PASS"
    assert result["evidence"]["batch_count"] == 5
    assert all(len(call["images"]) == 1 for call in calls)
    fifth = json.loads(calls[4]["content"])
    assert [item["entity_id"] for item in fifth["entities"]] == ["ent_4"]
    assert [item["requirement_id"] for item in fifth["requirements"]] == ["req_4"]


def test_visual_overview_does_not_guess_specific_entity_identity(tmp_path, monkeypatch):
    image = tmp_path / "overview.png"
    image.write_bytes(b"overview")
    captured = {}

    def fake_chat(**kwargs):
        captured.update(kwargs)
        return {"status": "PASS", "errors": []}

    monkeypatch.setattr(executors, "_ollama_chat", fake_chat)
    result = executors.run_visual_critic(
        _route(),
        spec={
            "requirements": [
                {
                    "requirement_id": "req_scene",
                    "subject": "simulation",
                    "validator": "visual_semantic",
                },
                {
                    "requirement_id": "req_house",
                    "subject": "ent_house",
                    "validator": "entity_presence",
                },
            ],
            "entities": [
                {
                    "entity_id": "ent_house",
                    "semantic_type": "house",
                    "asset": {"brief": "a village house"},
                    "physical": {"dynamic": False},
                },
                {
                    "entity_id": "ent_dog",
                    "semantic_type": "dog",
                    "asset": {"brief": "a dog"},
                    "physical": {"dynamic": True},
                }
            ],
        },
        image_paths=[image],
        settings=Settings(),
        view_manifest=[
            {
                "file": image.name,
                "subject_entity_id": "environment_overview",
                "purpose": "overview",
            }
        ],
    )
    payload = json.loads(captured["content"])
    assert result["status"] == "PASS"
    # The key is ABSENT, not empty. An overview scopes no per-entity targets, and a
    # measured run failed with "the scene_inventory specifies the need for
    # 'observation_point', 'structure', and 'tree', but no entities are provided in the
    # 'entities' array for this view" -- the model reading an empty array as a claim that
    # nothing is there, despite an instruction saying it never means that. A key that is
    # not sent cannot be misread (ADR-0009: enforce, do not re-explain).
    assert "entities" not in payload
    assert payload["scene_inventory"] == [
        {"semantic_type": "house", "count": 1}
    ]
    assert [item["requirement_id"] for item in payload["requirements"]] == [
        "req_scene"
    ]
