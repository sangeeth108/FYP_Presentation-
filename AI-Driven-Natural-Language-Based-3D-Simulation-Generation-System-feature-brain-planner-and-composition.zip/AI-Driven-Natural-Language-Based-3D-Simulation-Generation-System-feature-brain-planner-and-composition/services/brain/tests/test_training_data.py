"""Training-data pipeline (P4, RQ4): corpus + dataset split.

The two ways a distillation fine-tune silently becomes worthless:
  1. train/test contamination — training on an eval prompt, so Ablation E is
     measuring memorisation;
  2. a leaky holdout — the same spec in train and test, inflating the score.
These pin both. The LLM generation itself is exercised by a live smoke run, not
here (no GPU in CI).
"""

import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO / "eval"))
sys.path.insert(0, str(REPO / "eval" / "training"))

from export_distillation import _governance_eligible  # noqa: E402
from prompt_corpus import _eval_prompts, disjoint_corpus  # noqa: E402
from train_qlora import load_pairs, split_by_spec_hash  # noqa: E402

# --- the corpus is clean --------------------------------------------------


def test_corpus_is_reproducible_from_its_seed():
    assert [p["prompt"] for p in disjoint_corpus()] == [p["prompt"] for p in disjoint_corpus()]


def test_corpus_never_overlaps_the_eval_sets():
    # Training on an eval prompt would invalidate Ablation E. This is THE rule.
    corpus = {p["prompt"].strip().lower() for p in disjoint_corpus()}
    assert corpus.isdisjoint(_eval_prompts())


def test_corpus_prompts_are_unique_and_well_formed():
    corpus = disjoint_corpus()
    prompts = [p["prompt"] for p in corpus]
    assert len(prompts) == len(set(prompts))  # no duplicate training examples
    assert all(len(p["prompt"]) >= 8 and p["prompt"] == p["prompt"].strip() for p in corpus)
    assert len({p["seed"] for p in corpus}) == len(corpus)  # distinct seeds


def test_corpus_spans_the_design_space():
    # It must exercise character identity and collection, not just escapes, or the
    # student never learns player_identity / collect_n.
    text = " ".join(p["prompt"] for p in disjoint_corpus()).lower()
    assert "as a" in text  # character-identity prompts
    assert "collect" in text or "gather" in text  # collection prompts


# --- the holdout split does not leak --------------------------------------


def _pair(spec_hash, prompt="p"):
    return {
        "messages": [
            {"role": "system", "content": "s"},
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": "{}"},
        ],
        "meta": {"spec_hash": spec_hash},
    }


def test_split_is_by_spec_hash_never_leaking_a_spec_across_the_split():
    # Two rows share a spec_hash -> they must land on the SAME side, or the test
    # score is inflated by a spec the model saw in training.
    pairs = [_pair(f"h{i}") for i in range(20)] + [_pair("h0")]  # h0 appears twice
    train, test = split_by_spec_hash(pairs)
    train_h = {p["meta"]["spec_hash"] for p in train}
    test_h = {p["meta"]["spec_hash"] for p in test}
    assert train_h.isdisjoint(test_h)  # no spec on both sides
    assert "h0" in train_h or "h0" in test_h
    assert "h0" not in (train_h & test_h)  # the duplicated spec did not leak


def test_split_is_deterministic():
    pairs = [_pair(f"h{i}") for i in range(20)]
    a = split_by_spec_hash(pairs)
    b = split_by_spec_hash(pairs)
    assert [p["meta"] for p in a[0]] == [p["meta"] for p in b[0]]  # seeded, stable


def test_tiny_sets_keep_everything_for_training():
    # With too few specs to hold out, don't strand data in a test split.
    pairs = [_pair(f"h{i}") for i in range(4)]
    train, test = split_by_spec_hash(pairs)
    assert len(train) == 4 and len(test) == 0


def test_load_pairs_dedups_the_same_spec_from_two_sources(tmp_path):
    # Generated + DB-export may both hold one spec; it is one training example.
    f1 = tmp_path / "a.jsonl"
    f2 = tmp_path / "b.jsonl"
    import json

    f1.write_text(json.dumps(_pair("dup")) + "\n", encoding="utf-8")
    f2.write_text(json.dumps(_pair("dup")) + "\n" + json.dumps(_pair("uniq")) + "\n",
                  encoding="utf-8")
    pairs = load_pairs([f1, f2])
    assert len(pairs) == 2  # dup collapsed, uniq kept


class _StoredSpec:
    def __init__(self, source=None, eligible=False):
        self.data_source = source
        self.training_eligible = eligible


def test_training_export_requires_allowed_source_and_explicit_eligibility():
    assert _governance_eligible(_StoredSpec("synthetic", True))
    assert _governance_eligible(_StoredSpec("controlled", True))
    assert not _governance_eligible(_StoredSpec("synthetic", False))
    assert not _governance_eligible(_StoredSpec("production_user", True))
    assert not _governance_eligible(_StoredSpec(None, True))
    assert not _governance_eligible(object())
