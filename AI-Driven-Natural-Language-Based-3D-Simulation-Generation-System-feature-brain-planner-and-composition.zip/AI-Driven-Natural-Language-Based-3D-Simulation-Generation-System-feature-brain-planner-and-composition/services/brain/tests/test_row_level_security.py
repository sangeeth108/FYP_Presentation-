from pathlib import Path

import pytest
from core import db as db_module
from core.models import User
from core.security import Principal, ensure_generation_age_eligible
from fastapi import HTTPException


def test_rls_migration_covers_tenant_and_child_evidence_tables():
    source = (
        Path(__file__).parents[1]
        / "migrations"
        / "versions"
        / "0009_row_level_security.py"
    ).read_text(encoding="utf-8")
    for table in (
        "simulations",
        "generation_runs",
        "simulation_specs",
        "world_plans",
        "training_eligibility",
        "dataset_versions",
        "validation_evidence",
        "simulation_artifacts",
    ):
        assert f'"{table}"' in source
    assert "ENABLE ROW LEVEL SECURITY" in source
    assert "current_setting('app.tenant_id', true)" in source


def test_every_run_scoped_evidence_table_has_a_policy():
    """`stage_artifacts` shipped in 0013 with no policy while its siblings had one.

    Any table hanging off `generation_runs` holds per-tenant content, so this
    asserts the whole family is covered across every migration rather than
    trusting that whoever adds the next one remembers.
    """
    versions = Path(__file__).parents[1] / "migrations" / "versions"
    combined = "\n".join(
        path.read_text(encoding="utf-8") for path in sorted(versions.glob("0*.py"))
    )
    for table in (
        "validation_evidence",
        "simulation_artifacts",
        "capability_gaps",
        "stage_artifacts",
    ):
        assert f'r.id = {table}.run_id' in combined, f"{table} has no run-scoped policy"
        assert "r.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')" in combined


def test_under_13_and_unknown_users_cannot_generate():
    db_session = db_module.SessionLocal()
    principal = Principal(
        user_id="blocked",
        tenant_id="tenant_dev",
        roles=frozenset({"user"}),
        age_band="under_13",
        subject="blocked",
    )
    db_session.add(User(id="blocked", subject="blocked", age_band="under_13"))
    db_session.flush()
    try:
        ensure_generation_age_eligible(db_session, principal)
        raise AssertionError("under-13 user unexpectedly passed")
    except HTTPException as exc:
        assert exc.status_code == 403
        assert "13+" in str(exc.detail)

    db_session.add(User(id="unknown", subject="unknown", age_band="unknown"))
    db_session.flush()
    unknown = Principal(
        user_id="unknown",
        tenant_id="tenant_dev",
        roles=frozenset({"user"}),
        age_band="unknown",
        subject="unknown",
    )
    try:
        ensure_generation_age_eligible(db_session, unknown)
        raise AssertionError("unknown-age user unexpectedly passed")
    except HTTPException as exc:
        assert exc.status_code == 403
        assert "age assurance" in str(exc.detail)
    finally:
        db_session.close()


def _postgres_url() -> str | None:
    """The database to audit, from a dedicated variable.

    Deliberately NOT `DATABASE_URL`: conftest overwrites that with SQLite for
    every test, so a check keyed on it could never run and would sit in the
    suite looking like coverage it does not provide. This is a deployment audit
    you point at a real environment:

        RLS_AUDIT_DATABASE_URL=postgresql+psycopg://... pytest -k bypass
    """
    import os

    url = os.environ.get("RLS_AUDIT_DATABASE_URL", "")
    return url if url.startswith("postgresql") else None


@pytest.mark.skipif(
    not _postgres_url(), reason="deployment audit: set RLS_AUDIT_DATABASE_URL to run"
)
def test_the_application_role_does_not_bypass_row_level_security():
    """Policies are inert if the connecting role is a superuser.

    Measured on the development stack: with `app.tenant_id` set to one tenant, a
    superuser sees BOTH tenants' rows while a plain role sees one, and an unset
    tenant yields zero. PostgreSQL exempts superusers and BYPASSRLS roles from
    every policy — `FORCE ROW LEVEL SECURITY` does not change that, it only
    extends enforcement to the table owner.

    So the thirty-odd policies in 0009-0014 protect nothing unless the service
    connects as an ordinary role. This test states that requirement where it
    cannot be forgotten; a text-only assertion that the migration mentions a
    table would pass even against a database with no policies at all.
    """
    import sqlalchemy

    engine = sqlalchemy.create_engine(_postgres_url())
    with engine.connect() as connection:
        row = connection.execute(
            sqlalchemy.text(
                "SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user"
            )
        ).one()
    superuser, bypass = bool(row[0]), bool(row[1])
    assert not superuser and not bypass, (
        "the application connects as a role that bypasses RLS "
        f"(superuser={superuser}, bypassrls={bypass}), so every tenant policy "
        "in migrations 0009-0014 is inert. Create an ordinary role for the "
        "service and grant it only the privileges it needs."
    )
