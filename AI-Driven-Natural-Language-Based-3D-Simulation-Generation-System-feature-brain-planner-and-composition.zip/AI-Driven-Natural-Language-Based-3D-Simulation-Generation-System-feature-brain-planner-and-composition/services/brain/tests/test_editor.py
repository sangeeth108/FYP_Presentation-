"""Serendib Assist edit engine: plain-language edits -> bounded, valid spec.

The guarantees that matter: an edit NEVER mutates the input spec, NEVER pushes a
field out of its schema range or the registry, and the result stays schema-valid
(so re-export can't ship a broken game). And it is honest about what it can't do.
"""

import copy
import json
from pathlib import Path

import jsonschema
from agents.editor import plan_edit

REPO = Path(__file__).resolve().parents[3]
SPEC = json.loads((REPO / "contracts" / "examples" / "golden_game.spec.json").read_text("utf-8"))
SCHEMA = json.loads((REPO / "contracts" / "game_spec.schema.json").read_text("utf-8"))


def _speeds(spec):
    return [e["stats"]["speed"] for e in spec["entities"]["enemies"]]


def test_faster_raises_speed_and_leaves_the_input_untouched():
    before = copy.deepcopy(SPEC)
    r = plan_edit(SPEC, "make the skeletons faster")
    assert all(n > o for n, o in zip(_speeds(r.spec), _speeds(SPEC), strict=True))
    assert r.any_change and any("faster" in c for c in r.changed)
    assert before == SPEC, "the input spec must never be mutated"
    jsonschema.validate(r.spec, SCHEMA)  # still in contract


def test_harder_raises_health_and_damage_within_bounds():
    r = plan_edit(SPEC, "make it much harder and more brutal")
    for e in r.spec["entities"]["enemies"]:
        assert 1 <= e["stats"]["health"] <= 100
        assert 1 <= e["stats"]["damage"] <= 20
    assert any("tougher" in c for c in r.changed)
    jsonschema.validate(r.spec, SCHEMA)


def test_peaceful_removes_all_enemies():
    r = plan_edit(SPEC, "make it peaceful, no enemies")
    assert r.spec["entities"]["enemies"] == []
    assert any("removed all enemies" in c for c in r.changed)
    jsonschema.validate(r.spec, SCHEMA)


def test_lighting_edit_is_registry_bound():
    r = plan_edit(SPEC, "make the dungeon darker and more torchlit")
    assert r.spec["world"]["lighting_preset_id"] in ("cave_torchlit", "moonlit_night")
    jsonschema.validate(r.spec, SCHEMA)


def test_more_enemies_respects_the_budget():
    r = plan_edit(SPEC, "add a huge horde of enemies")
    total = sum(e["count"] for e in r.spec["entities"]["enemies"])
    assert total <= r.spec["budgets"]["max_enemies"]
    jsonschema.validate(r.spec, SCHEMA)


def test_resize_stays_in_range():
    big = plan_edit(SPEC, "make the level much bigger and sprawling")
    assert 3 <= big.spec["world"]["zone_graph"]["zone_count"] <= 20
    small = plan_edit(SPEC, "make it smaller and more compact")
    assert 3 <= small.spec["world"]["zone_graph"]["zone_count"] <= 20
    jsonschema.validate(big.spec, SCHEMA)
    jsonschema.validate(small.spec, SCHEMA)


def test_unsupported_requests_are_reported_not_silently_dropped():
    r = plan_edit(SPEC, "add a final boss with a bow and an inventory system")
    assert "a unique boss enemy" in r.rejected
    assert "ranged combat" in r.rejected
    assert "inventory/crafting" in r.rejected


def test_a_no_op_instruction_changes_nothing():
    r = plan_edit(SPEC, "hello there")
    assert not r.any_change
    assert r.spec == SPEC  # equal by value; input still untouched


def test_combined_edit_applies_every_recognized_part():
    r = plan_edit(SPEC, "make the skeletons faster, tougher, and the crypt darker")
    joined = " ".join(r.changed)
    assert "faster" in joined and "tougher" in joined and "lighting" in joined
    jsonschema.validate(r.spec, SCHEMA)


# --- LLM edit path (guided JSON), tested with a mock transport ---
import httpx  # noqa: E402
from agents.editor import EditOps, apply_ops, keyword_ops, llm_edit  # noqa: E402


class _Settings:
    llm_base_url = "http://mock"
    llm_model = "qwen3.6:27b"
    llm_timeout_seconds = 5.0


def _mock(payload) -> httpx.MockTransport:
    def handler(request):
        # The lighting enum must be the registry's presets (invention impossible).
        enum = json.loads(request.content)["format"]["properties"]["lighting_preset_id"]["enum"]
        assert "cave_torchlit" in enum
        return httpx.Response(200, json={"message": {"content": json.dumps(payload)}})

    return httpx.MockTransport(handler)


def test_llm_edit_applies_bounded_ops():
    payload = {"difficulty_factor": 1.5, "lighting_preset_id": "moonlit_night"}
    r = llm_edit(SPEC, "make it moodier and a bit harder", _Settings(), transport=_mock(payload))
    assert r is not None
    assert any("tougher" in c for c in r.changed)
    assert r.spec["world"]["lighting_preset_id"] == "moonlit_night"
    jsonschema.validate(r.spec, SCHEMA)


def test_llm_edit_clamps_out_of_range_factors():
    r = llm_edit(SPEC, "ludicrous speed", _Settings(), transport=_mock({"speed_factor": 99.0}))
    for e in r.spec["entities"]["enemies"]:
        assert 1 <= e["stats"]["speed"] <= 8  # clamped despite the absurd factor


def test_llm_edit_falls_back_on_a_dead_model():
    def down(request):
        raise httpx.ConnectError("refused")

    assert llm_edit(SPEC, "x", _Settings(), transport=httpx.MockTransport(down)) is None


def test_keyword_ops_and_apply_ops_compose():
    ops = keyword_ops("make them faster and the crypt darker")
    assert ops.speed_factor > 1.0 and ops.lighting_preset_id == "cave_torchlit"
    r = apply_ops(SPEC, EditOps(remove_enemies=True))
    assert r.spec["entities"]["enemies"] == []
