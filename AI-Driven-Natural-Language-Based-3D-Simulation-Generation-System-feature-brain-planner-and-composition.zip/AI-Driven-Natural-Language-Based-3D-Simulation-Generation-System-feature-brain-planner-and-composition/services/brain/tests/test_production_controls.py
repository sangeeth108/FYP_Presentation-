"""Readiness, correlation, safe metrics, and request-size boundaries."""

from __future__ import annotations


def test_health_readiness_and_security_headers(client):
    health = client.get("/healthz", headers={"X-Correlation-ID": "test-request-123"})
    assert health.status_code == 200
    assert health.headers["x-correlation-id"] == "test-request-123"
    assert health.headers["x-content-type-options"] == "nosniff"
    assert "frame-ancestors" in health.headers["content-security-policy"]

    ready = client.get("/readyz")
    assert ready.status_code == 200
    assert ready.json()["checks"]["database"] == "ok"
    assert ready.json()["checks"]["capability_registry"] == "ok"


def test_metrics_use_route_templates_and_never_include_prompt_content(client):
    secret_prompt = "never-log-this-" * 300
    invalid = client.post(
        "/api/v1/simulations",
        json={"prompt": secret_prompt, "target_platforms": ["web"]},
    )
    assert invalid.status_code == 422
    metrics = client.get("/metrics")
    assert metrics.status_code == 200
    assert "serendib_http_requests_total" in metrics.text
    assert secret_prompt not in metrics.text
    assert "/api/v1/simulations" in metrics.text


def test_oversized_requests_are_rejected_before_parsing(client):
    response = client.post(
        "/api/v1/simulations",
        content=b"x" * 2_000_001,
        headers={"Content-Type": "application/json"},
    )
    assert response.status_code == 413
