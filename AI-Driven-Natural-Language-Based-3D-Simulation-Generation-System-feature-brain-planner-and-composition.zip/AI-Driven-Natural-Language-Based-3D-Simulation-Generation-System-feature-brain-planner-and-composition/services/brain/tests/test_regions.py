"""Paving is a surface, not two thousand objects.

Measured: the village's paths came back as **2,239 loose paving slabs**, instanced as
scatter with no collision, because the contract could only express objects and the only
way to say "this ground is paved" was to strew slab-shaped things over it. That is the
59-wall-panels mistake one dimension up.

The engine end of this is verified separately, by loading a written project in the real
Serendib binary: a village with one 24 m stone square came back with 16,348 grass
vertices and exactly 36 stone ones, matching the count computed here.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path

import jsonschema
from pcg.regions import paint_regions
from pcg.semantic import generate_semantic_world_plan, validate_semantic_world_plan

from tests.test_simulation_core import _dog_village

_CONTRACT = (
    Path(__file__).resolve().parents[3] / "contracts" / "simulation_spec.schema.json"
)


def _region(**overrides) -> dict:
    region = {
        "region_id": "rgn_market_square",
        "semantic_type": "cobbled_market_square",
        "source_text": "a village",
        "surface": "stone",
        "polygon_m": [-10.0, -10.0, 10.0, -10.0, 10.0, 10.0, -10.0, 10.0],
    }
    region.update(overrides)
    return region


def test_a_declared_area_paints_the_ground_it_covers():
    """A 20 m square on a 100 m world at a 33-vertex lattice is 7x7 vertices."""
    painted, families, notes = paint_regions({"regions": [_region()]}, 100.0, 100.0, 33)
    assert families == ["", "stone"]
    assert sum(1 for value in painted if value) == 49
    assert not notes

    # And it is a square, not a scatter of hits: every painted vertex sits inside the
    # declared box, and every vertex inside it is painted.
    step = 100.0 / 32
    for row in range(33):
        for column in range(33):
            x = -50.0 + column * step
            z = -50.0 + row * step
            inside = abs(x) <= 10.0 and abs(z) <= 10.0
            assert bool(painted[row * 33 + column]) == inside, (x, z)


def test_winding_does_not_matter():
    """The contract explicitly does not constrain it.

    A planner drawing a courtyard clockwise and one drawing it anticlockwise must get
    the same yard, which is why this is a crossing-parity test rather than a winding
    number.
    """
    clockwise = _region()
    anticlockwise = _region(polygon_m=list(reversed(clockwise["polygon_m"])))
    first, _, _ = paint_regions({"regions": [clockwise]}, 100.0, 100.0, 33)
    second, _, _ = paint_regions({"regions": [anticlockwise]}, 100.0, 100.0, 33)
    assert first == second


def test_a_later_area_wins_where_two_overlap():
    """Declaration order is the only tie-break the planner can see.

    Area would mean a small inset yard could never sit inside a large paved square,
    which is a perfectly normal thing to describe.
    """
    inset = _region(
        region_id="rgn_inset",
        semantic_type="gravel_patch",
        surface="sand",
        polygon_m=[-4.0, -4.0, 4.0, -4.0, 4.0, 4.0, -4.0, 4.0],
    )
    painted, families, _ = paint_regions(
        {"regions": [_region(), inset]}, 100.0, 100.0, 33
    )
    assert families == ["", "stone", "sand"]
    assert painted[16 * 33 + 16] == 2  # the centre is gravel
    # x = 6.25: outside the 4 m gravel patch, inside the 10 m square.
    assert painted[16 * 33 + 18] == 1


def test_an_area_smaller_than_a_grid_cell_is_disclosed():
    """A courtyard that vanished is one somebody asked for.

    Silence would make the ground look simply wrong rather than explained, which is
    the difference rules 11 and 13 are about.
    """
    tiny = _region(
        region_id="rgn_step",
        polygon_m=[40.1, 40.1, 40.4, 40.1, 40.4, 40.4],
        surface="wood",
    )
    painted, _, notes = paint_regions({"regions": [tiny]}, 100.0, 100.0, 33)
    assert not any(painted)
    assert len(notes) == 1
    assert notes[0]["user_visible"] is True
    assert "grid" in notes[0]["reason"]


def test_no_regions_costs_nothing_and_ships_nothing():
    """The overwhelmingly common case.

    Every spec written before this feature has no regions, and the plan must not grow
    a 16,384-entry array of zeros for them.
    """
    painted, families, notes = paint_regions({}, 100.0, 100.0, 33)
    assert set(painted) == {0}
    assert families == [""]
    assert not notes

    plan = generate_semantic_world_plan(copy.deepcopy(_dog_village()))
    assert "surface_grid" not in plan["terrain"]
    assert "surface_families" not in plan["terrain"]


def test_the_painted_grid_rides_on_the_terrain_block():
    """Same lattice as the heights, deliberately.

    Sampling at a different resolution would put the seam between two surfaces
    somewhere other than where the ground changes shape.
    """
    spec = copy.deepcopy(_dog_village())
    spec["regions"] = [
        _region(polygon_m=[-12.0, -12.0, 12.0, -12.0, 12.0, 12.0, -12.0, 12.0])
    ]
    plan = generate_semantic_world_plan(spec)
    terrain = plan["terrain"]

    assert len(terrain["surface_grid"]) == len(terrain["heights_m"])
    assert len(terrain["surface_grid"]) == terrain["grid"] ** 2
    assert terrain["surface_families"] == ["", "stone"]
    assert sum(1 for value in terrain["surface_grid"] if value) == 36

    report = validate_semantic_world_plan(plan, require_measured_assets=False)
    assert report["status"] == "PASS", report.get("errors")


def test_a_spec_with_regions_validates_against_the_contract():
    spec = copy.deepcopy(_dog_village())
    spec["regions"] = [_region()]
    jsonschema.Draft202012Validator(
        json.loads(_CONTRACT.read_text(encoding="utf-8"))
    ).validate(spec)


def test_the_surface_vocabulary_is_closed_and_excludes_unspecified():
    """`unspecified` is absent on purpose.

    A region whose surface is unspecified is indistinguishable from the ground around
    it, so there would be nothing to paint -- unlike `environment.terrain_surface`,
    where it is the honest way to decline.
    """
    schema = json.loads(_CONTRACT.read_text(encoding="utf-8"))
    region_surface = schema["$defs"]["region"]["properties"]["surface"]["enum"]
    ground_surface = schema["properties"]["environment"]["properties"][
        "terrain_surface"
    ]["enum"]
    assert "unspecified" in ground_surface
    assert "unspecified" not in region_surface
    assert set(region_surface) == set(ground_surface) - {"unspecified"}


def test_the_writer_only_tints_by_vertex_when_something_was_painted():
    """Turning it on unconditionally is the ADR-0010 defect again.

    A flat world's ground is a BoxMesh with no COLOR array; vertex colour then
    defaults to white and every such world goes back to drawing default white. Both
    branches are verified in the real engine: with regions the ground comes back with
    a COLOR array and a white material albedo, without them it has no COLOR array and
    keeps the family tint.
    """
    import sys

    worker = str(Path(__file__).resolve().parents[2] / "worker")
    if worker not in sys.path:
        sys.path.insert(0, worker)
    from godot_client.surfaces import surface_sub_resources

    plain = surface_sub_resources(7, "grass")
    tinted = surface_sub_resources(7, "grass", vertex_tinted_ground=True)

    assert "vertex_color_use_as_albedo" not in plain
    assert "albedo_color = Color(0.29, 0.42, 0.21, 1)" in plain

    assert "vertex_color_use_as_albedo = true" in tinted
    assert "albedo_color = Color(1, 1, 1, 1)" in tinted
    # Only the ground. The path material has no per-vertex colours to read.
    assert tinted.count("vertex_color_use_as_albedo") == 1


def test_foliage_does_not_grow_on_paving():
    """A fern sprouting from cobbles is the 2,239 slabs from the other direction.

    Regions replaced loose paving objects with a painted surface; this stops the
    world then strewing plants across that surface. Only growing things are refused
    and only over a hard surface: a crate or a boulder on a courtyard is perfectly
    ordinary, and soil, sand, grass and snow all support growth, so excluding those
    would empty a meadow.
    """
    from pcg.scatter import instance_scatter

    zones = [
        {
            "zone_id": "main",
            "semantic_type": "main",
            "bounds": {"min": [-50.0, 0.0, -50.0], "max": [50.0, 20.0, 50.0]},
        }
    ]

    def _spec(paved: bool) -> dict:
        spec = {
            "meta": {"seed": 5},
            "scatter": [
                {
                    "species_id": "spc_fern",
                    "semantic_type": "fern",
                    "size_m": [0.6, 0.5, 0.6],
                    "density_per_100m2": 30.0,
                    "clustering": "random",
                    "asset": {
                        "brief": "fern",
                        "category": "foliage",
                        "requires_animation": False,
                        "preferred_source": "either",
                        "procedural_type": "ground_cover",
                    },
                }
            ],
        }
        if paved:
            spec["regions"] = [_region(
                polygon_m=[-25.0, -25.0, 25.0, -25.0, 25.0, 25.0, -25.0, 25.0]
            )]
        return spec

    def _inside(result: dict) -> int:
        return sum(
            1
            for item in result["instances"]
            if abs(item["position_m"][0]) <= 25 and abs(item["position_m"][2]) <= 25
        )

    bare = instance_scatter(_spec(False), zones, [], {})
    paved = instance_scatter(_spec(True), zones, [], {})

    assert _inside(bare) > 0, "without a region the ferns do land there"
    assert _inside(paved) == 0, "with stone paving they do not"
    # Nothing is lost: the sampler places them on the ground that is left.
    assert len(paved["instances"]) == len(bare["instances"])
