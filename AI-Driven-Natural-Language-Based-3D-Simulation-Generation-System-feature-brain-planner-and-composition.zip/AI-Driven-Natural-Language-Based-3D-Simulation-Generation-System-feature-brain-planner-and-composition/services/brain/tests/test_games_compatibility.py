def test_games_endpoint_adapts_to_canonical_simulation(client, monkeypatch):
    import api.simulations as simulations_api

    queued: list[str] = []
    monkeypatch.setattr(
        simulations_api.run_simulation_generation,
        "delay",
        lambda run_id: queued.append(run_id),
    )
    response = client.post(
        "/api/v1/games",
        json={
            "prompt": "As a dog, explore a village.",
            "options": {
                "genre": "collect_explore_3d",
                "camera": "third_person",
            },
        },
    )
    assert response.status_code == 202
    body = response.json()
    assert body["game_id"].startswith("sim_")
    assert body["job_id"].startswith("run_")
    assert queued == [body["job_id"]]
    assert response.headers["deprecation"] == "true"
    assert 'rel="successor-version"' in response.headers["link"]

    canonical = client.get(f"/api/v1/simulations/{body['game_id']}")
    assert canonical.status_code == 200
    assert canonical.json()["prompt"] == "As a dog, explore a village."

    legacy_status = client.get(f"/api/v1/jobs/{body['job_id']}")
    assert legacy_status.status_code == 200
    assert legacy_status.json()["detail"]["deprecated_adapter"] is True
