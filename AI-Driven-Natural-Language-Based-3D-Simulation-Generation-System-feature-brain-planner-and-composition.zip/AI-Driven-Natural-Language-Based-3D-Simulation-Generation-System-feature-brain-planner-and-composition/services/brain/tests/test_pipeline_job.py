"""Canonical planning regressions that replaced game-template job assertions."""

from copy import deepcopy

from agents.simulation_planner import plan_simulation
from core.config import get_settings


def _plan(prompt: str, seed: int, size: str = "small") -> dict:
    return plan_simulation(
        prompt=prompt,
        simulation_id=f"sim_pipeline_test_{seed:08x}",
        seed=seed,
        size_profile=size,
        target_platforms=["web", "desktop"],
        domain_constraints={},
        settings=get_settings(),
    )[0]


def _stable(spec: dict) -> dict:
    result = deepcopy(spec)
    result["lineage"]["created_at"] = "<time>"
    return result


def test_seeded_neutral_planning_is_reproducible():
    first = _plan("Inspect a factory machine and its safety sensor.", 4521)
    second = _plan("Inspect a factory machine and its safety sensor.", 4521)
    different = _plan("Inspect a factory machine and its safety sensor.", 99)
    assert _stable(first) == _stable(second)
    assert first["meta"]["seed"] == 4521
    assert different["meta"]["seed"] == 99
    assert _stable(first) != _stable(different)


def test_prompt_content_shapes_simulation_entities_not_a_game_genre():
    village = _plan("As a dog, explore a village with usable doors.", 1)
    factory = _plan("Inspect a factory machine triggered by a sensor.", 1)
    assert village["environment"]["semantic_type"] == "village"
    assert any(item["semantic_type"] == "house" for item in village["entities"])
    assert factory["environment"]["semantic_type"] == "factory"
    assert any("machine" in item["capabilities"] for item in factory["entities"])
    assert "genre" not in village["meta"]
    assert "objectives" not in village
    assert "enemies" not in village


def test_world_size_profiles_are_hard_area_limits():
    small = _plan("Explore a forest ecosystem.", 1, "small")
    medium = _plan("Explore a forest ecosystem.", 1, "medium")
    assert small["environment"]["dimensions_m"]["width"] == 500
    assert small["environment"]["dimensions_m"]["depth"] == 500
    assert medium["environment"]["dimensions_m"]["width"] == 1000
    assert medium["environment"]["dimensions_m"]["depth"] == 1000
