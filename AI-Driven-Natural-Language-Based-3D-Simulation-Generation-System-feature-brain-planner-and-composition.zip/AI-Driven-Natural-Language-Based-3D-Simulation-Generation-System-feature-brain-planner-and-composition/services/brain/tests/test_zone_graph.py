import pytest
from pcg.zone_graph import PCGError, generate_zone_graph


def test_same_seed_same_graph():
    a = generate_zone_graph(seed=4521, zone_count=7)
    b = generate_zone_graph(seed=4521, zone_count=7)
    assert a.zones == b.zones
    assert a.edges == b.edges


def test_different_seeds_differ():
    a = generate_zone_graph(seed=1, zone_count=12)
    b = generate_zone_graph(seed=2, zone_count=12)
    assert (a.zones, a.edges) != (b.zones, b.edges)


def test_connected_for_many_seeds_and_sizes():
    for seed in range(25):
        for zone_count in (3, 5, 12, 20):
            g = generate_zone_graph(seed=seed, zone_count=zone_count)
            assert len(g.zones) == zone_count
            assert g.is_connected()


def test_lock_and_key_structure():
    g = generate_zone_graph(seed=4521, zone_count=8, verticality_tiers=2)
    kinds = [z.kind for z in g.zones]
    assert kinds.count("entry") == 1
    assert kinds.count("exit") == 1
    assert kinds.count("key") == 1
    exit_id = next(z.zone_id for z in g.zones if z.kind == "exit")
    exit_edges = [e for e in g.edges if exit_id in (e.a, e.b)]
    assert len(exit_edges) == 1, "exit must be reachable only through the locked edge"
    assert exit_edges[0].kind == "locked"
    assert all(z.tier in (0, 1) for z in g.zones)


def test_no_edge_spans_more_than_one_tier():
    """A ramp bridges exactly one tier (rise 1.5 vs the 1.6 walkable step), so a
    2-tier jump across an edge is an unclimbable cliff — the level renders fine
    and is unsolvable (gate 5 KEY_UNREACHABLE). Tiers are drawn per zone before
    the edges exist, so this invariant has to be enforced, not assumed.

    Regression: 'descend the torchlit crypts' made the planner ask for 3 tiers,
    and the key sat behind a 3.0-unit drop.
    """
    for algorithm in ("room_corridor", "bsp", "cellular_caves", "wfc_dressing"):
        for seed in range(40):
            for zone_count in (5, 8, 14, 20):
                g = generate_zone_graph(
                    seed=seed,
                    zone_count=zone_count,
                    algorithm=algorithm,
                    verticality_tiers=3,
                )
                tier = {z.zone_id: z.tier for z in g.zones}
                for e in g.edges:
                    assert abs(tier[e.a] - tier[e.b]) <= 1, (
                        f"cliff on {algorithm} seed={seed} n={zone_count}: "
                        f"{e.a}(t{tier[e.a]}) -> {e.b}(t{tier[e.b]})"
                    )
                assert min(tier.values()) == 0  # the ground tier survives


def test_verticality_survives_the_tier_relaxation():
    """Relaxing tiers must not flatten the world into one storey."""
    multi_tier = 0
    for seed in range(20):
        g = generate_zone_graph(seed=seed, zone_count=12, verticality_tiers=3)
        if len({z.tier for z in g.zones}) > 1:
            multi_tier += 1
    assert multi_tier >= 18, "verticality was crushed out of nearly every level"


def test_bad_inputs_raise_machine_readable_errors():
    with pytest.raises(PCGError) as exc:
        generate_zone_graph(seed=0, zone_count=2)
    err = exc.value.to_dict()
    assert err["code"] == "zone_count_out_of_range"
    assert err["path"] == "world.zone_graph.zone_count"
    assert err["hint"]

    with pytest.raises(PCGError) as exc:
        generate_zone_graph(seed=0, zone_count=5, algorithm="voronoi_swamp")
    assert exc.value.code == "algorithm_not_implemented"

    with pytest.raises(PCGError) as exc:
        generate_zone_graph(seed=0, zone_count=5, verticality_tiers=4)
    assert exc.value.code == "verticality_out_of_range"
