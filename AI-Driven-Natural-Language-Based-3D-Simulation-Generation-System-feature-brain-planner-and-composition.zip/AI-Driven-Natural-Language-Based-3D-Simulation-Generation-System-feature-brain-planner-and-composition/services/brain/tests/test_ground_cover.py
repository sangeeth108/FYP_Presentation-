"""Outdoor ground is never bare.

Measured across 425 stored outdoor specs: 390 of them (92%) carried no `scatter` at all,
including eight consecutive village runs at ten entities and zero ground cover -- a
handful of buildings standing on a bare plane.
"""

import json
from pathlib import Path

import jsonschema
from agents.simulation_planner import _ground_carries_its_own_cover

_SCHEMA = json.loads(
    (
        Path(__file__).resolve().parents[3] / "contracts/simulation_spec.schema.json"
    ).read_text(encoding="utf-8")
)


def _outdoor(surface: str, **extra) -> dict:
    return {"environment": {"world_kind": "outdoor", "terrain_surface": surface}, **extra}


def test_bare_grass_gets_cover() -> None:
    candidate = _outdoor("grass")
    _ground_carries_its_own_cover(candidate)

    species = candidate["scatter"]
    assert len(species) >= 2
    assert {s["species_id"] for s in species} >= {"spc_grass_tuft"}
    # Cover, not content: everything low, incidental and capped.
    assert all(s["size_m"][1] <= 1.0 for s in species)
    assert all(s["placement_is_incidental"] for s in species)
    assert all(s["max_instances"] <= 2000 for s in species)
    assert any(a["requirement_id"] == "environment.scatter" for a in candidate["approximations"])


def test_every_generated_species_satisfies_the_schema() -> None:
    """The rule writes spec, so it must write spec that validates."""
    validator = jsonschema.Draft202012Validator(
        {**_SCHEMA["$defs"]["scatter_species"], "$defs": _SCHEMA["$defs"]}
    )
    for surface in ("grass", "soil", "sand", "gravel", "snow", "rock", "dirt", "stone"):
        candidate = _outdoor(surface)
        _ground_carries_its_own_cover(candidate)
        assert candidate.get("scatter"), surface
        for species in candidate["scatter"]:
            errors = sorted(validator.iter_errors(species), key=str)
            assert not errors, f"{surface}: {[e.message for e in errors]}"


def test_a_world_that_dressed_itself_is_left_alone() -> None:
    authored = [{"species_id": "spc_oak"}]
    candidate = _outdoor("grass", scatter=list(authored))
    _ground_carries_its_own_cover(candidate)
    assert candidate["scatter"] == authored


def test_indoor_and_paved_worlds_grow_nothing() -> None:
    indoors = {"environment": {"world_kind": "indoor", "terrain_surface": "concrete"}}
    _ground_carries_its_own_cover(indoors)
    assert not indoors.get("scatter")

    paved = _outdoor("concrete")
    _ground_carries_its_own_cover(paved)
    assert not paved.get("scatter")


def test_the_ground_is_read_in_its_own_words_not_only_the_enum() -> None:
    """The rule keyed on `terrain_surface` alone and fired on nothing.

    Measured across 592 stored specs: `terrain_surface` was "unspecified" 347 times and
    absent 63 more, while the free-text `terrain` said `grass_and_paths` 410 times. The
    planner does say what its ground is -- just not in the enum.
    """
    candidate = {
        "environment": {
            "world_kind": "outdoor",
            "terrain": "grass_and_paths",
            "terrain_surface": "unspecified",
        }
    }
    _ground_carries_its_own_cover(candidate)
    assert candidate.get("scatter")
    assert candidate["scatter"][0]["species_id"] == "spc_grass_tuft"


def test_ground_that_says_nothing_about_itself_grows_nothing() -> None:
    """104 stored worlds describe their ground as `contextual_terrain unspecified`.

    That is a non-answer, and guessing grass for it would put a lawn in a car park.
    """
    candidate = {
        "environment": {
            "world_kind": "outdoor",
            "terrain": "contextual_terrain",
            "terrain_surface": "unspecified",
            "semantic_type": "requested_environment",
        }
    }
    _ground_carries_its_own_cover(candidate)
    assert not candidate.get("scatter")


def test_mixed_worlds_are_dressed_too() -> None:
    """115 stored worlds are `mixed`; their outdoor ground is still ground."""
    candidate = {
        "environment": {"world_kind": "mixed", "terrain": "paved_and_soil"}
    }
    _ground_carries_its_own_cover(candidate)
    assert candidate.get("scatter")
    assert candidate["scatter"][0]["species_id"] == "spc_weed_clump"
