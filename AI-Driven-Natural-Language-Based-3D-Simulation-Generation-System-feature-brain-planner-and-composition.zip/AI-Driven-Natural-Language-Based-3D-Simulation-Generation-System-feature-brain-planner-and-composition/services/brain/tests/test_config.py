"""Settings must not depend on where the process was launched from.

Regression: `env_file=".env"` is resolved against the CWD. The API (launched
from services/brain, no .env there) fell back to the built-in defaults, while
the benchmark (launched from the repo root) loaded the root .env — which still
carried a stale vLLM `LLM_BASE_URL`. Result: connection refused, a *silent*
fallback to the rule parser, and 20/20 prompts still reporting PASS. The brain
was switched off and every gate was green.
"""

import os
import subprocess
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
BRAIN = REPO / "services" / "brain"

PROBE = (
    "import json,sys;"
    f"sys.path.insert(0, {str(BRAIN)!r});"
    "from core.config import Settings;"
    "s = Settings();"
    "print(json.dumps({'llm': s.llm_base_url, 'db': s.database_url}))"
)


def _settings_from(cwd: Path) -> dict:
    import json

    env = {**os.environ}
    for key in ("LLM_BASE_URL", "DATABASE_URL"):  # let the .env / defaults speak
        env.pop(key, None)
    out = subprocess.run(
        [sys.executable, "-c", PROBE], cwd=cwd, capture_output=True, text=True, env=env, check=True
    )
    return json.loads(out.stdout.strip().splitlines()[-1])


def test_settings_are_identical_from_repo_root_and_from_the_service_dir():
    assert _settings_from(REPO) == _settings_from(BRAIN)


def test_env_file_is_anchored_to_the_repo_root():
    from core.config import ENV_FILE

    assert ENV_FILE == REPO / ".env"
    assert ENV_FILE.is_absolute()
