"""Localized repairs are typed, hash-bound, bounded, and monotonic."""

from __future__ import annotations

from copy import deepcopy

import pytest
from behaviors.compiler import compile_behavior_plan
from pcg.semantic import (
    generate_semantic_world_plan,
    validate_semantic_world_plan,
)
from repair.typed_patches import (
    apply_world_patch,
    bounded_localized_repair,
    plan_hash,
    propose_typed_patch,
)

from tests.test_semantic_pcg import _measured_descriptors
from tests.test_simulation_core import _dog_village


def _inputs():
    spec = _dog_village()
    descriptors = _measured_descriptors(spec)
    behavior, _ = compile_behavior_plan(spec)
    plan = generate_semantic_world_plan(spec, descriptors, behavior["graphs"])
    return spec, descriptors, behavior["graphs"], plan


def test_overlap_mutation_is_repaired_without_regenerating_unaffected_entities():
    spec, descriptors, graphs, original = _inputs()
    broken = deepcopy(original)
    left, right = broken["entities"][0], broken["entities"][1]
    right["transform"]["position_m"] = list(left["transform"]["position_m"])
    right["world_aabb"] = deepcopy(left["world_aabb"])
    broken_report = validate_semantic_world_plan(
        broken, require_measured_assets=False
    )
    assert broken_report["status"] == "FAIL"
    repaired, report, lineage = bounded_localized_repair(
        spec=spec,
        asset_descriptors=descriptors,
        behaviour_graphs=graphs,
        initial_plan=broken,
        validator=lambda candidate: validate_semantic_world_plan(
            candidate, require_measured_assets=False
        ),
    )
    assert report["status"] == "PASS"
    assert len(lineage) == 1
    affected = set(lineage[0]["patch"]["operations"][0]["entity_ids"])
    original_positions = {
        item["entity_id"]: item["transform"]["position_m"]
        for item in original["entities"]
    }
    repaired_positions = {
        item["entity_id"]: item["transform"]["position_m"]
        for item in repaired["entities"]
    }
    assert all(
        repaired_positions[entity_id] == position
        for entity_id, position in original_positions.items()
        if entity_id not in affected
    )


def test_patch_is_rejected_if_the_plan_changed_after_proposal():
    spec, descriptors, graphs, plan = _inputs()
    report = {
        "status": "FAIL",
        "errors": [
            {
                "code": "ENTITY_OUTSIDE_ZONE",
                "entity_id": plan["entities"][0]["entity_id"],
            }
        ],
    }
    patch = propose_typed_patch(report, plan)
    changed = deepcopy(plan)
    changed["seed"] += 1
    with pytest.raises(ValueError, match="precondition hash"):
        apply_world_patch(
            patch,
            spec=spec,
            asset_descriptors=descriptors,
            behaviour_graphs=graphs,
            current_plan=changed,
        )
    assert patch["precondition_plan_hash"] == plan_hash(plan)


def test_asset_or_capability_failures_cannot_be_patched_as_placement():
    _, _, _, plan = _inputs()
    report = {
        "status": "FAIL",
        "errors": [
            {"code": "ASSET_NOT_MEASURED", "entity_id": "ent_controlled_actor"}
        ],
    }
    assert propose_typed_patch(report, plan) is None


def test_repair_budget_cannot_exceed_three_cycles():
    spec, descriptors, graphs, plan = _inputs()
    with pytest.raises(ValueError, match="between 0 and 3"):
        bounded_localized_repair(
            spec=spec,
            asset_descriptors=descriptors,
            behaviour_graphs=graphs,
            initial_plan=plan,
            validator=lambda _: {"status": "PASS", "errors": []},
            max_cycles=4,
        )

