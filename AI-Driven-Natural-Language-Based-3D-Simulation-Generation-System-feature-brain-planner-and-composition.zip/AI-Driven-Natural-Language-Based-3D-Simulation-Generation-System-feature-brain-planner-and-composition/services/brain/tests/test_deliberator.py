"""Stage 3: critique, revise, stop. Mostly a test of the guardrails.

Deliberation is the stage most able to make things worse -- a review loop that
must find something will find something, and a revision driven by an invented
defect damages a sound brief while looking like diligence. These tests pin the
properties that make it safe to run at all.
"""

from __future__ import annotations

import json

import httpx
from agents.deliberator import deliberate_brief, ollama_critique_schema


class _Settings:
    llm_timeout_seconds = 5


BRIEF = {
    "place": "flooded_subway_platform",
    "world_size_m": {"width": 40.0, "depth": 18.0, "max_height": 5.0},
    "individual": [
        {
            "name": "Ticket barrier",
            "semantic_type": "turnstile_bank",
            "size_m": [3.0, 1.2, 1.0],
            "why_individual": "the visitor passes through it",
        }
    ],
    "mass": [
        {
            "name": "Ceiling tile",
            "semantic_type": "shattered_ceiling_tile",
            "size_m": [0.6, 0.02, 0.6],
            "per_100m2": 40.0,
            "form": "ground_cover",
        }
    ],
    "conditions": {
        "ground": "flooded_concrete",
        "light": "emergency_only",
        "weather": "none",
    },
}

# Every critique must state what each check examined; the fixtures carry it so
# they exercise the same contract the model does.
_CHECKS = {
    "contradiction": "compared every field against the description",
    "plausibility": "densest entry is 40 per 100 m2 at 0.6 m2 each: 24 m2, fits",
    "abstraction": "no individual entry occurs in quantity",
}

_SOUND = {"verdict": "sound", "checks": _CHECKS, "findings": []}


def _finding(path: str = "mass[0].per_100m2") -> dict:
    return {
        "verdict": "needs_revision",
        "checks": _CHECKS,
        "findings": [
            {
                "path": path,
                "problem": "the description says the floor is carpeted in tile",
                "correction": "raise the density to 200",
                "severity": "contradicts_description",
            }
        ],
    }


def _client(responses):
    """Serve a queue of replies; each POST takes the next."""
    queue = list(responses)

    class _Stub:
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def post(self, url, json=None):
            payload = queue.pop(0)
            if isinstance(payload, Exception):
                raise payload
            import json as _json

            return httpx.Response(
                200,
                json={"message": {"content": _json.dumps(payload)}},
                request=httpx.Request("POST", "http://t/api/chat"),
            )

    return _Stub


def test_a_sound_brief_is_left_completely_alone(monkeypatch):
    """The expected outcome for good input, and it must cost one call, not four."""
    monkeypatch.setattr(httpx, "Client", _client([_SOUND]))
    result = deliberate_brief(
        BRIEF, "desc", settings=_Settings(), model_id="q", base_url="http://x"
    )
    assert result.brief == BRIEF
    assert result.changed is False
    assert result.stopped_because == "sound"
    assert len(result.rounds) == 1


def test_a_real_finding_is_applied(monkeypatch):
    revised = json.loads(json.dumps(BRIEF))
    revised["mass"][0]["per_100m2"] = 200.0
    monkeypatch.setattr(httpx, "Client", _client([_finding(), revised, _SOUND]))

    result = deliberate_brief(
        BRIEF, "desc", settings=_Settings(), model_id="q", base_url="http://x"
    )
    assert result.brief["mass"][0]["per_100m2"] == 200.0
    assert result.changed is True


def test_the_loop_stops_when_the_brief_stops_changing(monkeypatch):
    """Stability, not agreement: agreement is reachable by capitulation."""
    unchanged = json.loads(json.dumps(BRIEF))
    monkeypatch.setattr(httpx, "Client", _client([_finding(), unchanged]))

    result = deliberate_brief(
        BRIEF, "desc", settings=_Settings(), model_id="q", base_url="http://x"
    )
    assert result.stopped_because == "stable"
    assert result.changed is False
    assert len(result.rounds) == 1


def test_rounds_are_hard_capped(monkeypatch):
    """A loop that has not converged in two rounds is not going to."""
    first = json.loads(json.dumps(BRIEF))
    first["mass"][0]["per_100m2"] = 100.0
    second = json.loads(json.dumps(BRIEF))
    second["mass"][0]["per_100m2"] = 300.0
    monkeypatch.setattr(
        httpx, "Client", _client([_finding(), first, _finding(), second])
    )

    result = deliberate_brief(
        BRIEF, "desc", settings=_Settings(), model_id="q", base_url="http://x"
    )
    assert result.stopped_because == "round_cap"
    assert len(result.rounds) == 2


def test_a_broken_revision_never_costs_the_brief(monkeypatch):
    """Deliberation may improve a brief or leave it; it may never lose it."""
    monkeypatch.setattr(httpx, "Client", _client([_finding(), {"place": "nonsense"}]))
    result = deliberate_brief(
        BRIEF, "desc", settings=_Settings(), model_id="q", base_url="http://x"
    )
    assert result.brief == BRIEF
    assert result.stopped_because.startswith("error:")


def test_an_unavailable_model_returns_the_input(monkeypatch):
    monkeypatch.setattr(httpx, "Client", _client([httpx.ConnectError("down")]))
    result = deliberate_brief(
        BRIEF, "desc", settings=_Settings(), model_id="q", base_url="http://x"
    )
    assert result.brief == BRIEF


def test_no_model_configured_is_a_no_op():
    result = deliberate_brief(
        BRIEF, "desc", settings=_Settings(), model_id=None, base_url=None
    )
    assert result.brief == BRIEF
    assert result.stopped_because == "no_model"
    assert result.rounds == []


def test_the_callers_brief_is_never_mutated(monkeypatch):
    revised = json.loads(json.dumps(BRIEF))
    revised["mass"][0]["per_100m2"] = 999.0
    monkeypatch.setattr(httpx, "Client", _client([_finding(), revised, _SOUND]))
    original = json.loads(json.dumps(BRIEF))

    deliberate_brief(
        BRIEF, "d", settings=_Settings(), model_id="q", base_url="http://x"
    )
    assert original == BRIEF


def test_zero_findings_is_a_first_class_answer():
    """A critic that cannot say nothing will invent something."""
    schema = ollama_critique_schema()
    assert "sound" in schema["properties"]["verdict"]["enum"]
    assert schema["properties"]["findings"].get("minItems") in (None, 0)


def test_only_substantive_severities_exist():
    """Style is not a finding; a round trip has to be earned."""
    severities = set(
        ollama_critique_schema()["$defs"]["finding"]["properties"]["severity"]["enum"]
    )
    assert severities == {
        "contradicts_description",
        "physically_implausible",
        "wrong_abstraction",
    }


def test_neither_agent_is_told_who_wrote_what(monkeypatch):
    """Attribution produces deference to the loudest voice, not the right point."""
    sent: list = []

    class _Stub:
        def __init__(self, *args, **kwargs):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return False

        def post(self, url, json=None):
            sent.append(json)
            import json as _json

            return httpx.Response(
                200,
                json={"message": {"content": _json.dumps(_SOUND)}},
                request=httpx.Request("POST", "http://t/api/chat"),
            )

    monkeypatch.setattr(httpx, "Client", _Stub)
    deliberate_brief(
        BRIEF, "d", settings=_Settings(), model_id="q", base_url="http://x"
    )

    # Anonymity is a property of the conversation: what each side is shown.
    conversation = json.dumps([call["messages"] for call in sent]).lower()
    for word in ("critic", "planner", "agent", "reviser", "extractor", "wrote"):
        assert word not in conversation, f"{word} leaks authorship into the conversation"

    # And the schema travels with the request, so design rationale must not ride
    # along in it either — it is prompt text the model reads.
    schemas = json.dumps([call.get("format") for call in sent]).lower()
    assert "failure mode" not in schemas
    assert "diligence" not in schemas


def test_deliberate_is_the_third_declared_stage():
    from core.stages import STAGE_ORDER, stage_ordinal

    assert STAGE_ORDER[2] == "deliberate"
    assert (
        stage_ordinal("extract")
        < stage_ordinal("deliberate")
        < stage_ordinal("scene_spec")
    )


def test_findings_are_acted_on_even_when_the_verdict_says_sound(monkeypatch):
    """The two fields disagree, and the findings are the ones that did work.

    Measured: the model computed that 900 beds need 567 square metres of a 100
    square metre floor, named the correction, and set verdict `sound` anyway.
    Reading the verdict first discarded every finding it produced and made the
    stage look incapable when it was working correctly.
    """
    contradictory = {
        "verdict": "sound",
        "checks": _CHECKS,
        "findings": [
            {
                "path": "mass[0].per_100m2",
                "problem": "900 beds require 567 of 100 available square metres",
                "correction": "reduce the density to 6",
                "severity": "physically_implausible",
            }
        ],
    }
    revised = json.loads(json.dumps(BRIEF))
    revised["mass"][0]["per_100m2"] = 6.0
    monkeypatch.setattr(httpx, "Client", _client([contradictory, revised, _SOUND]))

    result = deliberate_brief(
        BRIEF, "desc", settings=_Settings(), model_id="q", base_url="http://x"
    )
    assert result.changed is True, "a finding must be applied whatever the verdict says"
    assert result.brief["mass"][0]["per_100m2"] == 6.0


def test_an_overlong_critique_is_repaired_not_discarded(monkeypatch):
    """The critique is a guided artefact and needs the same repair as the rest.

    Omitting it cost the stage every finding it produced: the model's
    plausibility working ran past the field's length bound and the whole
    critique was thrown away. Third occurrence of one class -- anything a
    context-free grammar cannot enforce -- in a third artefact.
    """
    wordy = {
        "verdict": "needs_revision",
        "checks": {
            "contradiction": "checked every field against the description",
            "plausibility": "showing the working " * 40,  # far past the bound
            "abstraction": "no individual entry occurs in quantity",
        },
        "findings": [
            {
                "path": "mass[0].per_100m2",
                "problem": "too dense to pack",
                "correction": "reduce to 6",
                "severity": "physically_implausible",
            }
        ],
    }
    revised = json.loads(json.dumps(BRIEF))
    revised["mass"][0]["per_100m2"] = 6.0
    monkeypatch.setattr(httpx, "Client", _client([wordy, revised, _SOUND]))

    result = deliberate_brief(
        BRIEF, "desc", settings=_Settings(), model_id="q", base_url="http://x"
    )
    assert result.changed is True
    assert result.stopped_because != "error:ValidationError"


def test_every_check_must_be_reported():
    """A check that need not be stated is a check that need not be performed.

    Requiring the working is the same mechanism as `why_individual` in the
    brief: the field exists to force the judgement, not to document it.
    """
    from agents.deliberator import scene_critique_schema

    schema = scene_critique_schema()
    assert "checks" in schema["required"]
    assert set(schema["properties"]["checks"]["required"]) == {
        "contradiction",
        "plausibility",
        "abstraction",
    }
