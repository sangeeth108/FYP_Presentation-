"""Canonical and legacy specification persistence remains fail-closed."""

from core import db as db_module
from core.config import get_settings
from core.db import Base
from core.models import (
    Game,
    Job,
    Simulation,
    SimulationSpecRecord,
    Spec,
    Tenant,
    User,
)


def _fresh():
    Base.metadata.drop_all(bind=db_module.engine)
    Base.metadata.create_all(bind=db_module.engine)


def _legacy_identity_and_job():
    with db_module.session_scope() as session:
        session.add(Tenant(id="tenant_dev", name="Dev", slug="dev"))
        session.add(User(id="user_dev", subject="dev", age_band="adult"))
        session.flush()  # identity rows must land before FK-bearing game
        session.add(
            Game(
                id="g3d_persist_deadbeef",
                title="Persist",
                prompt="a persistence test world",
                tenant_id="tenant_dev",
                owner_id="user_dev",
            )
        )
        session.flush()  # game must land before the job that references it
        session.add(
            Job(
                id="job_persist",
                game_id="g3d_persist_deadbeef",
                tenant_id="tenant_dev",
                owner_id="user_dev",
            )
        )


def test_canonical_spec_is_versioned_and_never_trainable_by_boolean_shortcut():
    _fresh()
    with db_module.session_scope() as session:
        session.add(Tenant(id="tenant_dev", name="Dev", slug="dev"))
        session.add(User(id="user_dev", subject="dev", age_band="adult"))
        session.flush()  # identity rows must land before FK-bearing simulation
        simulation = Simulation(
            id="sim_persist_deadbeef",
            tenant_id="tenant_dev",
            owner_id="user_dev",
            title="Persist",
            prompt="a persistence test simulation",
            size_profile="small",
            target_platforms=["web"],
            seed=1,
        )
        session.add(simulation)
        session.flush()  # simulation must land before its spec record
        session.add(
            SimulationSpecRecord(
                id="sim_spec_persist",
                simulation_id=simulation.id,
                tenant_id="tenant_dev",
                owner_id="user_dev",
                version=1,
                schema_version="1.0.0",
                spec_hash="a" * 64,
                source="deterministic_fallback",
                body={"schema_version": "1.0.0"},
                data_source="production_user",
                training_eligible=False,
            )
        )
    with db_module.session_scope() as session:
        record = session.get(SimulationSpecRecord, "sim_spec_persist")
        assert record.version == 1
        assert record.data_source == "production_user"
        assert record.training_eligible is False


def test_legacy_spec_storage_is_unclassified_and_ineligible():
    _fresh()
    _legacy_identity_and_job()
    import worker.tasks as tasks

    tasks._store_spec(
        "job_persist",
        "g3d_persist_deadbeef",
        {"schema_version": "2.0.0"},
        "b" * 64,
        "rules",
        get_settings(),
    )
    with db_module.session_scope() as session:
        row = session.query(Spec).one()
        assert row.data_source == "legacy_unclassified"
        assert row.training_eligible is False


def test_legacy_store_is_idempotent_per_job():
    _fresh()
    _legacy_identity_and_job()
    import worker.tasks as tasks

    for _ in range(2):
        tasks._store_spec(
            "job_persist",
            "g3d_persist_deadbeef",
            {"schema_version": "2.0.0"},
            "c" * 64,
            "rules",
            get_settings(),
        )
    with db_module.session_scope() as session:
        assert session.query(Spec).count() == 1


def test_a_refusing_database_does_not_crash_legacy_build(monkeypatch):
    _fresh()
    import worker.tasks as tasks

    class Refuses:
        def __enter__(self):
            raise RuntimeError("db unavailable")

        def __exit__(self, *exc):
            return False

    monkeypatch.setattr(tasks.db, "session_scope", lambda: Refuses())
    tasks._store_spec(
        "j1",
        "g1",
        {"schema_version": "2.0.0"},
        "h",
        "rules",
        get_settings(),
    )


def test_a_junk_legacy_spec_is_skipped_without_raising():
    _fresh()
    import worker.tasks as tasks

    tasks._store_spec("nojob", "nogame", {}, "h", "rules", get_settings())
