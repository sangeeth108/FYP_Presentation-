"""Every generated asset in one world shares one art direction.

Measured before this existed: `style_anchor` was absent from all 30 stored simulation
specs, and the string did not appear in `simulation_planner.py` at all. Both ends of the
mechanism were already built -- `agents/style.py` derives the anchor, `backends_gpu`
prepends it to every SDXL prompt -- and only the simulation planner never wrote the
field, so each asset's prompt was its own brief alone.

`style.py` states the consequence: "a crypt's sarcophagus and its torch can come out in
different styles -- the game looks incoherent." That is why an independently generated
set cannot read as one place, whatever the placement or lighting does.
"""

import copy

import pytest

from agents.simulation_planner import _set_style_anchor, ollama_simulation_schema
from agents.style import BASE_STYLE, derive_simulation_style_anchor


def _spec(**environment) -> dict:
    return {
        "meta": {"simulation_id": "sim_style_test", "title": "T", "seed": 1},
        "environment": environment,
    }


def test_the_planner_writes_an_anchor():
    spec = _spec(semantic_type="village", time_of_day="midday", weather="clear")
    _set_style_anchor(spec)
    assert spec["meta"]["style_anchor"]


def test_every_anchor_carries_the_frozen_art_direction():
    """BASE_STYLE is the v1 look (CLAUDE.md §1, "stylized low-poly"). An anchor without
    it would let one world drift off the product's own art direction."""
    for environment in (
        {"semantic_type": "village", "time_of_day": "midday", "weather": "clear"},
        {"semantic_type": "factory_yard", "time_of_day": "dusk", "weather": "overcast"},
        {},
    ):
        assert BASE_STYLE in derive_simulation_style_anchor(environment)


def test_the_place_leads_and_is_open_vocabulary():
    """`semantic_type` is used verbatim rather than mapped. A table of places would
    refuse every noun it had not been told about -- the mistake the procedural
    vocabulary avoids by naming FORMS instead of things."""
    anchor = derive_simulation_style_anchor(
        {"semantic_type": "kelp forest", "time_of_day": "night", "weather": "fog"}
    )
    assert anchor.startswith("kelp forest setting")


def test_it_is_deterministic():
    """Rule 14: the same world always looks the same, so a spec is reproducible."""
    environment = {"semantic_type": "village", "time_of_day": "dawn", "weather": "rain"}
    assert derive_simulation_style_anchor(environment) == derive_simulation_style_anchor(
        copy.deepcopy(environment)
    )


def test_two_worlds_that_differ_get_different_anchors():
    day = derive_simulation_style_anchor({"semantic_type": "village", "time_of_day": "midday"})
    night = derive_simulation_style_anchor({"semantic_type": "village", "time_of_day": "night"})
    assert day != night


def test_the_anchor_fits_the_contract_bound():
    long_place = "a " + "very " * 60 + "long place name"
    assert len(derive_simulation_style_anchor({"semantic_type": long_place})) <= 200


def test_the_model_is_never_asked_to_author_it():
    """MACHINE-AUTHORED. `meta` is dropped from the grammar wholesale, so the decoder
    cannot spend tokens on a field derived from the settled environment -- and a
    per-run invention is exactly what a SHARED art direction must not be."""
    assert "meta" not in ollama_simulation_schema().get("properties", {})


def test_a_spec_without_an_environment_is_left_alone():
    spec = {"meta": {"simulation_id": "s", "title": "T", "seed": 1}}
    _set_style_anchor(spec)
    # An anchor of pure BASE_STYLE is still valid; what must not happen is a crash.
    assert isinstance(spec["meta"].get("style_anchor", ""), str)
