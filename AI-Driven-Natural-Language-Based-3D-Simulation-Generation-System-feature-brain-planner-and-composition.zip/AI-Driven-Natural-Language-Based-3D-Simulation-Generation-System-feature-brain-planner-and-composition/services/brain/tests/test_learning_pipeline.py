import json
from datetime import UTC, datetime

import pytest
from core import db as db_module
from core.models import (
    ConsentRecord,
    ContentRight,
    DatasetItem,
    FeedbackEvent,
    GenerationRun,
    ModelDeployment,
    Simulation,
    SimulationSpecRecord,
    Tenant,
    TrainingEligibility,
    User,
    ValidationEvidence,
)
from learning.attestations import sign_attestation
from learning.datasets import build_dataset_version
from learning.deletion import purge_training_copies
from learning.eligibility import evaluate_eligibility
from learning.export import (
    DatasetExportError,
    export_frozen_dataset,
)
from learning.lifecycle import (
    LifecycleError,
    advance_canary,
    approve_training_candidate,
    create_training_candidate,
    promote_model,
    register_model_candidate,
    register_model_evaluation,
)
from model_router.registry import route_model
from worker.learning_tasks import execute_governed_training


def _db():
    return db_module.SessionLocal()


def _qualified_planner_row(db, *, suffix="one", consent=True):
    now = datetime.now(UTC)
    tenant_id = f"tenant_{suffix}"
    user_id = f"user_{suffix}"
    db.add(
        Tenant(
            id=tenant_id,
            name=suffix,
            slug=suffix,
            training_policy="global",
        )
    )
    db.add(User(id=user_id, subject=user_id, age_band="adult"))
    db.flush()  # identity rows must land before the FK-bearing simulation graph
    simulation = Simulation(
        id=f"sim_{suffix}",
        tenant_id=tenant_id,
        owner_id=user_id,
        title="Village",
        prompt="As a dog, explore a village with usable doors.",
        size_profile="small",
        target_platforms=["web", "desktop"],
        seed=7,
        status="completed",
    )
    spec = SimulationSpecRecord(
        id=f"spec_{suffix}",
        simulation_id=simulation.id,
        tenant_id=tenant_id,
        owner_id=user_id,
        version=1,
        schema_version="1.0.0",
        spec_hash=("a" * 63) + suffix[0],
        source="planner",
        planner_model="test-planner",
        body={"schema_version": "1.0.0", "entities": [], "requirements": []},
    )
    run = GenerationRun(
        id=f"run_{suffix}",
        simulation_id=simulation.id,
        spec_id=spec.id,
        tenant_id=tenant_id,
        owner_id=user_id,
        state="completed",
        stage="completed",
        completed_at=now,
    )
    right = ContentRight(
        id=f"right_{suffix}",
        tenant_id=tenant_id,
        owner_id=user_id,
        resource_type="simulation_spec",
        resource_id=spec.id,
        rights_basis="user_attestation",
        training_allowed=True,
        verified_at=now,
    )
    consent_record = ConsentRecord(
        id=f"consent_{suffix}",
        tenant_id=tenant_id,
        subject_user_id=user_id,
        actor_user_id=user_id,
        consent_kind="subject",
        scope="global",
        data_category="prompt_spec",
        granted=consent,
        disclosure_version="v1",
        locale="en",
    )
    eligibility = TrainingEligibility(
        id=f"elig_{suffix}",
        tenant_id=tenant_id,
        owner_id=user_id,
        resource_type="simulation_spec",
        resource_id=spec.id,
        training_scope="global",
        data_category="prompt_spec",
        data_source="production_user",
        content_right_id=right.id,
        moderation_status="approved",
        quality_status="approved",
    )
    # Flush in FK-dependency order: SQLAlchemy has no relationships here, so the
    # unit of work won't order parents before children on its own.
    db.add(simulation)
    db.flush()
    db.add_all([spec, right, consent_record])
    db.flush()
    db.add_all([run, eligibility])  # run->sim,spec ; eligibility->content_right
    db.flush()
    db.add(
        ValidationEvidence(
            id=f"evidence_{suffix}",
            run_id=run.id,
            layer="runtime",
            status="PASS",
            mandatory=True,
            validator="probe",
            validator_version="1",
            requirement_ids=[],
            evidence={},
            errors=[],
        )
    )
    db.flush()
    evaluate_eligibility(db, eligibility)
    db.flush()
    return eligibility


def test_dataset_builder_rechecks_consent_and_snapshots_provenance():
    db = _db()
    try:
        qualified = _qualified_planner_row(db, suffix="qualified")
        denied = _qualified_planner_row(db, suffix="denied", consent=False)
        assert qualified.status == "eligible"
        assert denied.status == "ineligible"

        dataset = build_dataset_version(
            db, scope="global", target="planner", tenant_id=None
        )
        db.flush()
        items = db.query(DatasetItem).filter_by(dataset_version_id=dataset.id).all()
        assert dataset.status == "frozen"
        assert dataset.item_count == 1
        assert len(items) == 1
        assert items[0].eligibility_id == qualified.id
        assert items[0].consent_snapshot["subject"]["granted"] is True
        assert items[0].rights_snapshot["training_allowed"] is True
        assert "owner_id" not in items[0].sanitized_payload
    finally:
        db.close()


def test_frozen_dataset_export_is_hashed_sanitized_and_split_stable(tmp_path):
    db = _db()
    try:
        _qualified_planner_row(db, suffix="export")
        dataset = build_dataset_version(
            db, scope="global", target="planner", tenant_id=None
        )
        db.flush()
        result = export_frozen_dataset(
            db,
            dataset=dataset,
            export_root=tmp_path,
        )
        output = tmp_path / dataset.id
        assert result["manifest_hash"] == dataset.manifest_hash
        assert result["counts"] == {"train": 1, "validation": 0, "test": 0}
        exported = (output / "train.jsonl").read_text(encoding="utf-8")
        assert "As a dog, explore a village" in exported
        assert "user_export" not in exported
        assert (output / "manifest.json").is_file()
    finally:
        db.close()


def test_dataset_export_rechecks_withdrawal_immediately_before_copy(tmp_path):
    db = _db()
    try:
        eligibility = _qualified_planner_row(db, suffix="export_withdrawn")
        dataset = build_dataset_version(
            db, scope="global", target="planner", tenant_id=None
        )
        consent = db.get(ConsentRecord, eligibility.consent_record_id)
        consent.granted = False
        consent.withdrawn_at = datetime.now(UTC)
        db.flush()
        with pytest.raises(DatasetExportError, match="no longer training eligible"):
            export_frozen_dataset(db, dataset=dataset, export_root=tmp_path)
        assert not (tmp_path / dataset.id).exists()
    finally:
        db.close()


def _release_metrics():
    return {
        "critical_safety_regression": False,
        "executable_correctness_delta": 0.01,
        "privacy_tests": {
            "memorization": True,
            "pii_extraction": True,
            "tenant_leakage": True,
        },
        "primary_metric_improved": True,
        "cost_or_latency_materially_reduced": False,
        "frozen_benchmark": True,
        "research_training_overlap": False,
    }


def _complete_training(training, *, digest_char: str):
    training.state = "COMPLETED"
    training.artifact_ref = f"/controlled/models/{training.id}"
    training.metrics = {"artifact_digest": "sha256:" + (digest_char * 64)}
    training.completed_at = datetime.now(UTC)


def _planner_model_card(dataset, base_model="base"):
    return {
        "dataset_card": {"manifest_hash": dataset.manifest_hash},
        "training_manifest": {"base_model": base_model},
        "limitations": ["supported capability packs only"],
        "runtime": {
            "provider": "ollama",
            "model_id": "serendib-planner-test",
            "endpoint": "http://model.test:11434",
            "modalities": ["text"],
            "structured_output": True,
        },
    }


def _signed_evaluation(db, model, *, benchmark="sha256:frozen-v1"):
    key = "test-evaluation-signing-key-32-characters"
    values = {
        "model_version_id": model.id,
        "evaluator": "serendib-eval",
        "evaluator_version": "1.0",
        "benchmark_digest": benchmark,
        "artifact_digest": model.digest,
        "metrics": _release_metrics(),
    }
    return register_model_evaluation(
        db,
        model=model,
        signature=sign_attestation(key=key, **values),
        signing_key=key,
        **{key_: value for key_, value in values.items() if key_ != "model_version_id"},
    )


def test_model_lifecycle_requires_approval_and_5_then_25_percent_canary():
    db = _db()
    try:
        eligibility = _qualified_planner_row(db, suffix="life")
        dataset = build_dataset_version(
            db,
            scope="global",
            target="planner",
            tenant_id=None,
        )
        db.flush()
        training = create_training_candidate(
            db,
            dataset=dataset,
            target="planner",
            base_model="base",
            config={},
            monthly_window=True,
        )
        with pytest.raises(LifecycleError):
            register_model_candidate(
                db,
                training_run=training,
                name="candidate",
                licence_id="internal",
                model_card={
                    "dataset_card": {},
                    "training_manifest": {},
                    "limitations": [],
                },
            )
        approve_training_candidate(training, approved_by=eligibility.owner_id)
        with pytest.raises(LifecycleError, match="completed training run"):
            register_model_candidate(
                db,
                training_run=training,
                name="candidate",
                licence_id="internal",
                model_card=_planner_model_card(dataset),
            )
        _complete_training(training, digest_char="c")
        model = register_model_candidate(
            db,
            training_run=training,
            name="candidate",
            licence_id="internal",
            model_card=_planner_model_card(dataset),
        )
        evaluation = _signed_evaluation(db, model)
        for state in ("EVALUATED", "SHADOW", "CANARY"):
            promote_model(db, model=model, target_state=state, evaluation=evaluation)
            db.flush()
        canary = (
            db.query(ModelDeployment)
            .filter_by(model_version_id=model.id, stage="canary")
            .one()
        )
        assert canary.traffic_percent == 5
        with pytest.raises(LifecycleError):
            promote_model(db, model=model, target_state="PRODUCTION")
        canary_evaluation = _signed_evaluation(
            db, model, benchmark="sha256:canary-observation-v1"
        )
        advance_canary(canary, model=model, evaluation=canary_evaluation)
        assert canary.traffic_percent == 25
        promote_model(db, model=model, target_state="PRODUCTION", evaluation=evaluation)
        db.flush()
        production = (
            db.query(ModelDeployment)
            .filter_by(model_version_id=model.id, stage="production")
            .one()
        )
        assert production.traffic_percent == 100
        assert model.state == "PRODUCTION"
        db.commit()
        routed = route_model("planner", tenant_id="tenant_any", routing_key="run_42")
        assert routed is not None
        assert routed.model_id == "serendib-planner-test"
        assert routed.model_digest == model.digest
        assert routed.endpoint == "http://model.test:11434"
    finally:
        db.close()


def test_deletion_tombstone_removes_dataset_copy_and_quarantines_derivatives():
    db = _db()
    try:
        eligibility = _qualified_planner_row(db, suffix="delete")
        dataset = build_dataset_version(
            db, scope="global", target="planner", tenant_id=None
        )
        training = create_training_candidate(
            db,
            dataset=dataset,
            target="planner",
            base_model="base",
            config={},
            monthly_window=True,
        )
        approve_training_candidate(training, approved_by=eligibility.owner_id)
        _complete_training(training, digest_char="d")
        model = register_model_candidate(
            db,
            training_run=training,
            name="delete-me",
            licence_id="internal",
            model_card=_planner_model_card(dataset),
        )
        db.flush()
        result = purge_training_copies(
            db,
            owner_id=eligibility.owner_id,
            tenant_id=eligibility.tenant_id,
            create_tombstones=True,
            reason="test_deletion",
        )
        assert result["dataset_items_removed"] == 1
        assert result["models_quarantined"] == 1
        assert model.state == "QUARANTINED"
        assert dataset.status == "withdrawal_rebuild_required"
    finally:
        db.close()


def test_approved_ranker_training_executes_only_the_fixed_governed_runner(
    tmp_path, monkeypatch
):
    db = _db()
    now = datetime.now(UTC)
    try:
        db.add(
            Tenant(
                id="tenant_ranker",
                name="Ranker",
                slug="ranker",
                training_policy="global",
            )
        )
        db.add(User(id="user_ranker", subject="user_ranker", age_band="adult"))
        feedback = FeedbackEvent(
            id="feedback_ranker",
            tenant_id="tenant_ranker",
            owner_id="user_ranker",
            kind="asset_choice",
            payload={
                "chosen": {
                    "semantic_score": 0.95,
                    "rig_compatible": True,
                    "triangle_cost": 1000,
                },
                "rejected": {
                    "semantic_score": 0.2,
                    "rig_compatible": False,
                    "triangle_cost": 5000,
                },
            },
        )
        right = ContentRight(
            id="right_ranker",
            tenant_id="tenant_ranker",
            owner_id="user_ranker",
            resource_type="feedback",
            resource_id=feedback.id,
            rights_basis="user_attestation_verified",
            training_allowed=True,
            verified_at=now,
        )
        consent = ConsentRecord(
            id="consent_ranker",
            tenant_id="tenant_ranker",
            subject_user_id="user_ranker",
            actor_user_id="user_ranker",
            consent_kind="subject",
            scope="global",
            data_category="assets",
            granted=True,
            disclosure_version="v1",
            locale="en",
        )
        eligibility = TrainingEligibility(
            id="elig_ranker",
            tenant_id="tenant_ranker",
            owner_id="user_ranker",
            resource_type="feedback",
            resource_id=feedback.id,
            training_scope="global",
            data_category="assets",
            data_source="production_user",
            content_right_id=right.id,
            moderation_status="approved",
            quality_status="approved",
        )
        db.add_all([feedback, right, consent, eligibility])
        db.flush()
        evaluate_eligibility(db, eligibility)
        assert eligibility.status == "eligible"
        db.flush()
        dataset = build_dataset_version(
            db, scope="global", target="asset_ranker", tenant_id=None
        )
        training = create_training_candidate(
            db,
            dataset=dataset,
            target="asset_ranker",
            base_model="serendib-pairwise-linear-v1",
            config={},
            monthly_window=True,
        )
        approve_training_candidate(training, approved_by="user_ranker")
        training.state = "QUEUED"
        training_id = training.id
        db.commit()
    finally:
        db.close()

    monkeypatch.setattr(
        "worker.learning_tasks.get_settings",
        lambda: type(
            "TrainingSettings",
            (),
            {
                "training_runner_enabled": True,
                "promptplay_env": "development",
                "production_training_enabled": False,
                "training_work_dir": str(tmp_path / "training"),
                "training_subprocess_timeout_seconds": 30,
            },
        )(),
    )
    result = execute_governed_training.run(training_id)
    assert result["state"] == "COMPLETED"
    assert result["artifact_digest"].startswith("sha256:")
    db = _db()
    try:
        completed = db.get(type(training), training_id)
        assert completed.state == "COMPLETED"
        assert completed.metrics["dataset_manifest_hash"] == dataset.manifest_hash
        model_path = tmp_path / "training" / "runs" / training_id / "model"
        ranker = json.loads((model_path / "ranker.json").read_text(encoding="utf-8"))
        assert ranker["target"] == "asset_ranker"
        assert ranker["hard_constraints_must_be_pre_filtered"] is True
    finally:
        db.close()
