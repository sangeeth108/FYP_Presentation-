"""Layout is the shape of the PLACE, not a feature of one object in it.

Giving `extract` a third bucket with no sense of when it does not apply made a baker's
workspace produce one route and four runs, a dusty attic a boundary wall, and a storage
room a street. On the 12-prompt corpus every run that used composition failed to publish
and all three that did not, did: published fell 6 to 3.

Gated on SCALE rather than on a list of indoor place types, because any such list is the
noun ceiling this codebase keeps refusing to build -- "kitchen" would be caught and
"galley" would not. A countertop edge is short relative to its world whatever the room is
called.
"""

from __future__ import annotations

import pytest
from pcg.layout_bridge import materialise_layout


def _built(world: tuple[float, float], **entry) -> int:
    candidate = {
        "environment": {"dimensions_m": {"width": world[0], "depth": world[1]}}
    }
    materialise_layout(candidate, {"layout": [entry]})
    return sum(
        len(candidate.get(key) or [])
        for key in ("routes", "regions", "linear_structures")
    )


@pytest.mark.parametrize(
    ("label", "world", "entry"),
    [
        # Exactly a quarter of a 12 m kitchen, and still furniture -- which is why
        # proportion alone was not enough and an absolute floor was needed.
        ("countertop edge", (12.0, 12.0),
         {"name": "countertop", "shape": "run", "reason": "x",
          "from_m": [-1.5, 0.0], "to_m": [1.5, 0.0], "width_m": 0.1}),
        ("shelving run", (12.0, 12.0),
         {"name": "shelving", "shape": "run", "reason": "x",
          "from_m": [-2.5, 0.0], "to_m": [2.5, 0.0], "width_m": 0.4}),
        # A room's floor is already environment.terrain_surface.
        ("rug-sized floor patch", (12.0, 12.0),
         {"name": "floor", "shape": "area", "reason": "x",
          "from_m": [-1.0, -1.0], "to_m": [1.0, 1.0], "width_m": 2.0}),
    ],
)
def test_a_feature_of_one_object_is_not_layout(label, world, entry):
    assert _built(world, **entry) == 0, label


@pytest.mark.parametrize(
    ("label", "world", "entry"),
    [
        ("boundary wall", (100.0, 100.0),
         {"name": "boundary wall", "shape": "run", "reason": "x",
          "from_m": [-40.0, -30.0], "to_m": [40.0, -30.0], "width_m": 0.5}),
        ("market street", (100.0, 100.0),
         {"name": "market street", "shape": "route", "reason": "x",
          "from_m": [-30.0, 0.0], "to_m": [30.0, 0.0], "width_m": 6.0}),
        # A modest plot still has real layout: the gate is proportional, so a small
        # world is not simply excluded from having a fence.
        ("garden fence on a small plot", (30.0, 30.0),
         {"name": "fence", "shape": "run", "reason": "x",
          "from_m": [-12.0, -10.0], "to_m": [12.0, -10.0], "width_m": 0.2}),
        ("plaza", (100.0, 100.0),
         {"name": "plaza", "shape": "area", "reason": "x",
          "from_m": [10.0, -15.0], "to_m": [40.0, 15.0], "width_m": 30.0}),
    ],
)
def test_the_shape_of_the_place_still_gets_through(label, world, entry):
    assert _built(world, **entry) == 1, label


def test_a_world_that_does_not_state_its_size_still_rejects_tiny_lines():
    """The proportional half needs a world extent; the absolute floor does not.

    A spec with no declared dimensions must not become a hole through which every
    countertop returns.
    """
    candidate: dict = {}
    materialise_layout(candidate, {"layout": [
        {"name": "countertop", "shape": "run", "reason": "x",
         "from_m": [-1.5, 0.0], "to_m": [1.5, 0.0], "width_m": 0.1}
    ]})
    assert not candidate.get("linear_structures")
