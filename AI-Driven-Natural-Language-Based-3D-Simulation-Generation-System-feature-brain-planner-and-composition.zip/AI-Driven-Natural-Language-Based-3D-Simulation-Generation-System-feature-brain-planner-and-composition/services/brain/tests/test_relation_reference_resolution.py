"""A relation naming a composition primitive must resolve, not fail the world.

Regression for run_23b6c991e31044eeaab68c8ebb6b2f06, which failed the mandatory
`requirement_traceability` gate on `SPATIAL_TARGET_UNKNOWN` for `struct_perimeter_wall`
and `route_central_path`. The old check only validated ids beginning `ent_`, exempting
every other prefix as a zone reference; measured over 400 specs that exemption protected
one real thing (`simulation`) and let four invented ids through.
"""

from agents.simulation_planner import _normalise_spatial_relations


def _spec(relations: list[dict], **extra) -> dict:
    spec = {
        "entities": [
            {"entity_id": "ent_garden_hose"},
            {"entity_id": "ent_perimeter_wall_s0"},
            {"entity_id": "ent_perimeter_wall_s1"},
        ],
        "spatial_relations": relations,
    }
    spec.update(extra)
    return spec


def _near(target: str, subject: str = "ent_garden_hose") -> dict:
    return {"subject_id": subject, "relation": "near", "target_id": target, "hard": False}


def test_a_run_reference_resolves_to_one_of_its_segments():
    # `struct_perimeter_wall` is the id the planner actually wrote; the run expanded to
    # `ent_perimeter_wall_s*`, so the wall it means does exist.
    spec = _spec([_near("struct_perimeter_wall")])
    _normalise_spatial_relations(spec)
    assert len(spec["spatial_relations"]) == 1
    assert spec["spatial_relations"][0]["target_id"].startswith("ent_perimeter_wall_s")


def test_the_rewrite_is_disclosed():
    spec = _spec([_near("struct_perimeter_wall")])
    _normalise_spatial_relations(spec)
    assert any(
        "struct_perimeter_wall" in item["reason"] for item in spec["approximations"]
    )


def test_a_near_miss_on_the_slug_still_resolves():
    # `central_path` for a `central_pathway` scatter species: prefix match, either way.
    spec = _spec(
        [_near("route_central_path")],
        scatter=[{"species_id": "ent_central_pathway"}],
    )
    _normalise_spatial_relations(spec)
    assert spec["spatial_relations"][0]["target_id"] == "ent_central_pathway"


def test_a_reference_to_nothing_is_still_dropped():
    spec = _spec([_near("struct_nonexistent_thing")])
    _normalise_spatial_relations(spec)
    assert spec["spatial_relations"] == []


def test_the_world_itself_remains_a_valid_target():
    # The one legitimate non-entity target, 12 uses across 400 specs.
    spec = _spec([_near("simulation")])
    _normalise_spatial_relations(spec)
    assert spec["spatial_relations"] == [_near("simulation")]


def test_an_existing_part_of_group_is_left_exactly_as_it_was():
    # These already point at a real segment, so nothing may rewrite them: ADR-0020's
    # group-collapse rule keys on the head, and moving it would change the grouping.
    relations = [
        {
            "subject_id": "ent_perimeter_wall_s1",
            "relation": "part_of",
            "target_id": "ent_perimeter_wall_s0",
            "hard": True,
        }
    ]
    spec = _spec([dict(relations[0])])
    _normalise_spatial_relations(spec)
    assert spec["spatial_relations"] == relations


def test_an_unknown_subject_is_dropped_not_resolved_into_a_wall():
    # A subject naming nothing is a relation about nothing; resolving it by slug would
    # invent a constraint on an unrelated entity.
    spec = _spec([_near("ent_perimeter_wall_s0", subject="ent_ghost")])
    _normalise_spatial_relations(spec)
    assert spec["spatial_relations"] == []
