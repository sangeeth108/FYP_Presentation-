"""Tiny incidental scatter is built, not photographed.

Measured on the forest floor: `spc_leaf_litter` is 10 cm across, `placement_is_incidental`,
and declared `preferred_source: "either"` -- so it went to image-to-3D like everything
else. One SDXL image, one TRELLIS reconstruction, 1,200 triangles and a baked-in dark
texture, and 1,143 instances of it came out as BLACK FLAT PANELS strewn over the grass:
the most visible defect in the finished render, for something the prompt never asked about.
"""

from agents.simulation_planner import _small_incidental_scatter_is_procedural as build_it


def _species(species_id: str, size: list[float], *, incidental: bool = True) -> dict:
    return {
        "species_id": species_id,
        "size_m": size,
        "placement_is_incidental": incidental,
        "asset": {"preferred_source": "either", "procedural_type": "irregular_mass"},
    }


def _source(candidate: dict, species_id: str) -> str:
    return next(
        s["asset"]["preferred_source"]
        for s in candidate["scatter"]
        if s["species_id"] == species_id
    )


def test_a_scrap_is_built_from_a_form() -> None:
    candidate = {"scatter": [_species("spc_leaf_litter", [0.1, 0.15, 0.1])]}
    build_it(candidate)
    assert _source(candidate, "spc_leaf_litter") == "procedural"
    assert candidate["approximations"][0]["requirement_id"] == "spc_leaf_litter"


def test_a_stick_is_a_scrap_however_long_it_is() -> None:
    """The MIDDLE dimension decides, not the largest.

    A branch is declared 1.0 x 0.05 x 0.05 m -- a metre long and five centimetres
    through. Measuring the largest dimension called it content; nothing about it has a
    silhouette worth reconstructing from a photograph.
    """
    candidate = {"scatter": [_species("spc_branches", [1.0, 0.05, 0.05])]}
    build_it(candidate)
    assert _source(candidate, "spc_branches") == "procedural"


def test_something_with_a_silhouette_keeps_its_choice() -> None:
    """Nobody sees the outline of a 10 cm scrap; a 12 m tree is all outline."""
    candidate = {
        "scatter": [
            _species("spc_ferns", [0.5, 1.5, 0.5]),
            _species("spc_canopy_tree", [5.0, 12.0, 5.0]),
        ]
    }
    build_it(candidate)
    assert _source(candidate, "spc_ferns") == "either"
    assert _source(candidate, "spc_canopy_tree") == "either"


def test_something_placed_deliberately_keeps_its_choice() -> None:
    """`placement_is_incidental` is the planner saying this hardly matters. If it did not
    say that, the size alone is not permission to change what the thing is."""
    candidate = {"scatter": [_species("spc_signpost", [0.2, 0.3, 0.2], incidental=False)]}
    build_it(candidate)
    assert _source(candidate, "spc_signpost") == "either"


def test_an_explicit_procedural_choice_is_not_re_recorded() -> None:
    candidate = {"scatter": [_species("spc_pebble", [0.1, 0.1, 0.1])]}
    candidate["scatter"][0]["asset"]["preferred_source"] = "procedural"
    build_it(candidate)
    assert not candidate.get("approximations")


def test_a_world_without_scatter_is_untouched() -> None:
    candidate: dict = {}
    build_it(candidate)
    assert candidate == {}
