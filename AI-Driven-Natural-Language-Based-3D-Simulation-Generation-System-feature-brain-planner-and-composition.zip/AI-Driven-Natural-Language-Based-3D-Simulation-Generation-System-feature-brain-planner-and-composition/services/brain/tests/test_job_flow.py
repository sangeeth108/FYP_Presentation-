"""Deprecated job status is a read-only view over the canonical run."""


def test_create_game_then_job_completes(client):
    resp = client.post(
        "/api/v1/games",
        json={
            "prompt": "a foggy village where I scavenge supplies and escape by boat",
            "options": {"genre": "topdown_survival_escape_3d", "camera": "top_down_3d"},
        },
    )
    assert resp.status_code == 202, resp.text
    body = resp.json()
    assert body["game_id"].startswith("sim_")
    job_id = body["job_id"]

    got = client.get(f"/api/v1/jobs/{job_id}")
    assert got.status_code == 200, got.text
    data = got.json()
    assert data["state"] == "FAILED"
    assert data["detail"]["deprecated_adapter"] is True
    assert data["detail"]["canonical_state"] == "failed_validation"
    # `visual_semantic` is advisory: it runs and is reported, but a verdict from
    # a model looking at pictures does not block publication. It was failing
    # correct worlds -- two houses filling a third of the frame called "not
    # visible" -- and `mandatory_failures` was collecting every non-PASS layer
    # regardless of whether it was mandatory, which made the distinction
    # impossible to express.
    assert "visual_semantic" not in data["detail"]["mandatory_failures"]
    assert "cross_platform_parity" in data["detail"]["mandatory_failures"]
    assert data["detail"].get("spec_hash")
    assert data["detail"].get("world_plan_hash")
    assert data["game_id"] == body["game_id"]


def test_unknown_job_is_404(client):
    assert client.get("/api/v1/jobs/does-not-exist").status_code == 404


def test_short_prompt_is_422(client):
    r = client.post("/api/v1/games", json={"prompt": "hi"})
    assert r.status_code == 422


def test_invalid_genre_is_422(client):
    r = client.post(
        "/api/v1/games",
        json={"prompt": "a valid enough prompt here", "options": {"genre": "mmo_shooter"}},
    )
    assert r.status_code == 422
