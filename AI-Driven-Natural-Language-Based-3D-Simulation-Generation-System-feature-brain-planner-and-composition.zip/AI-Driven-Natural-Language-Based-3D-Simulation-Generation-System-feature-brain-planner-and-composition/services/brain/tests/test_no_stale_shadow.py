"""Modules must load from source, never from a stale build artifact.

`services/brain/build/lib/` holds a setuptools copy of the whole package. It is
untracked and gitignored, so it is invisible to review, and it drifts the moment
anyone edits source without rebuilding -- right now its copies of
verification/contracts.py, pcg/semantic.py and agents/simulation_planner.py all
differ from the files they shadow.

Nothing imports from it today. That is worth knowing rather than assuming: when
a fix appeared not to take effect during a debugging session, "is the worker
loading the stale copy?" cost real time to rule out. This answers it once, and
keeps answering it.

If the shadow is ever deleted these tests still pass -- they assert where code
comes FROM, not that the artifact is absent.
"""

from __future__ import annotations

from pathlib import Path

import pytest

_BRAIN = Path(__file__).resolve().parents[1]
_SHADOW = _BRAIN / "build" / "lib"


@pytest.mark.parametrize(
    "module_name",
    [
        "pcg.semantic",
        "verification.contracts",
        "agents.simulation_planner",
        "core.validation_contract",
        "model_router.executors",
        "worker.native_pipeline",
    ],
)
def test_module_loads_from_source(module_name: str):
    """The import must resolve to the tree under review, not a build copy."""
    module = __import__(module_name, fromlist=["_"])
    loaded = Path(module.__file__).resolve()
    assert _SHADOW not in loaded.parents, (
        f"{module_name} loaded from the build artifact at {loaded}. "
        "Edits to source would have no effect and a review would be reading "
        "different code from the one that runs."
    )
    assert loaded.is_relative_to(_BRAIN), f"{module_name} loaded from {loaded}"
