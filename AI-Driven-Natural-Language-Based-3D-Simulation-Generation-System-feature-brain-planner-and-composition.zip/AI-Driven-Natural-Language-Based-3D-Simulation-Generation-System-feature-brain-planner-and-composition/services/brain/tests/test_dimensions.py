"""Geometry the planner could not have checked is corrected deterministically.

Every case here is a size a real run actually emitted. They are invisible in
text and obvious in a picture, which is exactly the check a language model does
not have -- so the fix is to stop asking it for the number, not to ask more
firmly.
"""

from __future__ import annotations

import pytest
from pcg.dimensions import canonical_bbox, correct_bbox


@pytest.mark.parametrize(
    ("declared", "semantic_type", "expected_height"),
    [
        ([0.1, 2.1, 1.8], "hinged_wooden_door", 2.1),   # a door on its side
        ([0.1, 0.1, 1.8], "wooden_fence_post", 1.8),    # a plank on the ground
        ([0.4, 0.4, 8.0], "oak_tree", 8.0),             # a felled oak
        ([0.3, 0.3, 0.9], "fire_hydrant", 0.9),         # hydrant lying down
    ],
)
def test_a_thing_lying_on_its_side_is_stood_up(declared, semantic_type, expected_height):
    corrected, reason = correct_bbox(declared, semantic_type)
    assert reason is not None, "an axis-swapped size must be reported, not silently kept"
    assert corrected[1] == pytest.approx(expected_height, rel=0.02), (
        "the longest declared dimension is the one the model got right"
    )
    assert corrected[1] == max(corrected), "height must end up the tallest axis"


def test_a_correct_size_is_left_alone():
    corrected, reason = correct_bbox([0.9, 2.0, 0.1], "front_door")
    assert reason is None
    assert corrected == [0.9, 2.0, 0.1]


def test_a_genuinely_unusual_size_survives():
    """A cathedral door really is twice a domestic one; do not average it away."""
    corrected, reason = correct_bbox([3.0, 6.5, 0.12], "cathedral_door")
    assert reason is None
    assert corrected == [3.0, 6.5, 0.12]


def test_an_unknown_kind_is_not_touched():
    """The library corrects what it knows; it never invents a size for the rest."""
    corrected, reason = correct_bbox([2.0, 3.0, 4.0], "quantum_resonator")
    assert reason is None
    assert corrected == [2.0, 3.0, 4.0]


def test_a_missing_size_falls_back_to_the_real_one():
    corrected, reason = correct_bbox(None, "front_door")
    assert reason is not None
    assert corrected == list(canonical_bbox("door"))


def test_specific_kinds_win_over_the_generic_ones_they_contain():
    """'doorway' must not resolve to 'door', or an opening becomes a leaf."""
    assert canonical_bbox("doorway") != canonical_bbox("door")
    assert canonical_bbox("fence_post") == canonical_bbox("post")


def test_height_is_always_the_middle_value_in_the_table():
    """The convention this whole module exists to enforce."""
    for kind in ("door", "post", "tree", "house", "person", "hydrant", "lamp"):
        box = canonical_bbox(kind)
        assert box is not None and box[1] > 0
