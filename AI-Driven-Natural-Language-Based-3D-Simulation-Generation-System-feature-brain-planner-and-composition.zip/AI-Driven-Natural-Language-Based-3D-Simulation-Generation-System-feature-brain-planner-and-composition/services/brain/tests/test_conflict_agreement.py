"""Placement and validation must answer the same question the same way.

They used to answer it separately and drifted FIVE times, each found only when
a run failed: hard-adjacency pairs known to one and not the other; transitive
assemblies likewise; axis-aligned boxes in one and oriented in the other;
different clearance semantics; and an asymmetry where "does A clear B" answered
differently from "does B clear A" because padding grows a box along its OWN
axes.

None were bugs in either implementation. They were bugs in there being two.
"""

from __future__ import annotations

import math

from pcg.semantic import _aabb, entities_conflict


def _placed(entity_id: str, position, dimensions, yaw=0.0, clearance=0.25) -> dict:
    return {
        "entity_id": entity_id,
        "dimensions_m": list(dimensions),
        "transform": {"position_m": list(position), "rotation_y_degrees": yaw},
        "world_aabb": _aabb(list(position), list(dimensions), yaw),
        "interaction_clearance_m": clearance,
    }


def test_the_answer_does_not_depend_on_which_one_you_ask_about():
    """The asymmetry that survived the first attempt at a shared function."""
    for yaw in (0.0, 13.0, 37.5, 45.0, 88.0, 137.0):
        house = _placed("house", [0, 2, 0], [6.0, 4.0, 5.0], yaw)
        for offset in (2.0, 3.0, 3.5, 4.0, 4.6, 5.5, 8.0):
            stoop = _placed("stoop", [offset, 0.3, 0.0], [1.5, 0.6, 0.6], yaw)
            forward = entities_conflict(
                stoop["transform"]["position_m"],
                stoop["dimensions_m"],
                yaw,
                stoop["interaction_clearance_m"],
                house,
                adjacent=False,
            )
            backward = entities_conflict(
                house["transform"]["position_m"],
                house["dimensions_m"],
                yaw,
                house["interaction_clearance_m"],
                stoop,
                adjacent=False,
            )
            assert forward == backward, (
                f"asymmetric at yaw={yaw} offset={offset}: "
                f"stoop-vs-house={forward} house-vs-stoop={backward}"
            )


def test_a_rotated_box_does_not_claim_ground_it_does_not_occupy():
    """A 6x5 m house turned a few degrees swallowed the ground beside it."""
    house = _placed("house", [0, 2, 0], [6.0, 4.0, 5.0], 15.0)
    # Well clear of the true footprint, inside the inflated axis-aligned box.
    beside = _placed("post", [4.6, 0.6, 3.6], [0.12, 1.2, 0.12], 0.0)
    assert not entities_conflict(
        beside["transform"]["position_m"], beside["dimensions_m"], 0.0,
        beside["interaction_clearance_m"], house, adjacent=False,
    )


def test_things_that_genuinely_overlap_still_conflict():
    """The check must not have been relaxed into uselessness."""
    a = _placed("a", [0, 1, 0], [2.0, 2.0, 2.0])
    b = _placed("b", [0.5, 1, 0.5], [2.0, 2.0, 2.0])
    assert entities_conflict([0.5, 1, 0.5], [2.0, 2.0, 2.0], 0.0, 0.25, a, adjacent=False)
    # ... and even when the spec says they belong together, real overlap counts.
    assert entities_conflict([0.5, 1, 0.5], [2.0, 2.0, 2.0], 0.0, 0.25, a, adjacent=True)


def test_an_explicit_adjacency_waives_clearance_but_not_overlap():
    """A door and its own stoop must not be pushed 1.5 m apart."""
    door = _placed("door", [0, 1, 0], [0.9, 2.0, 0.05], 0.0, clearance=1.5)
    # Just in front of the door: inside its clearance, touching nothing.
    stoop_position, stoop_dimensions = [0.0, 0.3, -0.6], [1.5, 0.6, 0.6]
    assert entities_conflict(
        stoop_position, stoop_dimensions, 0.0, 0.25, door, adjacent=False
    ), "without an explicit adjacency the 1.5 m clearance applies"
    assert not entities_conflict(
        stoop_position, stoop_dimensions, 0.0, 0.25, door, adjacent=True
    ), "an explicit adjacency waives clearance"


def test_both_callers_use_the_shared_function():
    """Guards the wiring: a re-implementation is how all five drifts started."""
    import inspect

    from pcg import semantic

    source = inspect.getsource(semantic)
    assert source.count("entities_conflict(") >= 3, "placer and validator must both call it"
    validator = inspect.getsource(semantic.validate_semantic_world_plan)
    assert "_overlaps(" not in validator, "validator must not hand-roll the check again"
