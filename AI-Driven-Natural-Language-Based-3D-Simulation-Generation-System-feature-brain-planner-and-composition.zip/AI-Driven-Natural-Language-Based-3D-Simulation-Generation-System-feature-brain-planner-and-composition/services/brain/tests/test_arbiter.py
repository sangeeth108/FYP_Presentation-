"""Arbiter: priority-stack merge, hard-band clamping, full decision log."""

import json
from pathlib import Path

from orchestrator.arbiter import Proposal, arbitrate, arbitrate_spec

BASE = json.loads(
    (Path(__file__).resolve().parents[3] / "contracts" / "examples" / "golden_game.spec.json")
    .read_text(encoding="utf-8")
)


def test_higher_band_wins_and_is_logged():
    spec, log = arbitrate(
        BASE,
        [
            Proposal("aesthetics_agent", "aesthetics", {"meta.mood": "gloomy"}),
            Proposal("planner", "designer_intent", {"meta.mood": "heroic"}),
        ],
    )
    assert spec["meta"]["mood"] == "heroic"
    decision = next(d for d in log if d["path"] == "meta.mood")
    assert decision["source"] == "planner"
    assert decision["band"] == "designer_intent"
    assert decision["losers"][0]["value"] == "gloomy"


def test_order_breaks_ties_within_a_band():
    spec, _ = arbitrate(
        BASE,
        [
            Proposal("planner", "designer_intent", {"meta.camera": "isometric_3d"}, order=0),
            Proposal("user_options", "designer_intent", {"meta.camera": "top_down_3d"}, order=10),
        ],
    )
    assert spec["meta"]["camera"] == "top_down_3d"  # higher order wins the tie


def test_scope_allowlist_clamps_illegal_genre():
    spec, log = arbitrate(
        BASE, [Proposal("rogue", "designer_intent", {"meta.genre": "mmo_shooter"})]
    )
    assert spec["meta"]["genre"] in (
        "topdown_survival_escape_3d",
        "arena_combat_3d",
        "collect_explore_3d",
        "dungeon_crawl_3d",
    )
    override = next(d for d in log if d["path"] == "meta.genre" and d["source"] == "arbiter")
    assert override["reason"] == "genre_not_in_allowlist"
    assert override["overridden_from"] == "mmo_shooter"


def test_platform_limit_caps_build_budget():
    spec, log = arbitrate(
        BASE, [Proposal("greedy", "designer_intent", {"budgets.max_web_build_mb": 250})]
    )
    assert spec["budgets"]["max_web_build_mb"] == 90
    override = next(
        d for d in log if d["path"] == "budgets.max_web_build_mb" and d["source"] == "arbiter"
    )
    assert override["overridden_from"] == 250
    assert override["band"] == "platform_limits"


def test_enemy_cap_clamped_both_ways():
    hi, _ = arbitrate(BASE, [Proposal("p", "designer_intent", {"budgets.max_enemies": 99})])
    assert hi["budgets"]["max_enemies"] == 25
    lo, _ = arbitrate(BASE, [Proposal("p", "designer_intent", {"budgets.max_enemies": 1})])
    assert lo["budgets"]["max_enemies"] == 5


def test_arbitrate_spec_user_option_beats_planner_inference():
    spec, log = arbitrate_spec(
        BASE,
        planner_patches={"meta.genre": "dungeon_crawl_3d", "meta.camera": "isometric_3d"},
        user_option_patches={"meta.camera": "third_person"},
    )
    assert spec["meta"]["genre"] == "dungeon_crawl_3d"  # planner-only field kept
    assert spec["meta"]["camera"] == "third_person"  # user's explicit pick wins
    cam = next(d for d in log if d["path"] == "meta.camera")
    assert cam["source"] == "user_options"


def test_decision_log_is_json_serializable():
    _, log = arbitrate_spec(BASE, {"meta.mood": "tense"}, {"meta.camera": "top_down_3d"})
    json.dumps(log)  # raises if any value is non-serializable
    assert all("path" in d and "source" in d and "band" in d for d in log)
