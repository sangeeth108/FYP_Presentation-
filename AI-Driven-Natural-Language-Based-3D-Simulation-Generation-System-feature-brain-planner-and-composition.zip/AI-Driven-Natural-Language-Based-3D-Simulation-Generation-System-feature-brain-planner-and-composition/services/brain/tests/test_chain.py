"""Multi-agent chain: each agent owns one job, the Arbiter merges, and the
merged spec stays schema-valid with full decision provenance."""

import json
from pathlib import Path

import jsonschema
from agents.chain import AgentContext, author_spec, run_chain

REPO = Path(__file__).resolve().parents[3]
BASE = json.loads(
    (REPO / "contracts" / "examples" / "golden_game.spec.json").read_text(encoding="utf-8")
)
SCHEMA = json.loads((REPO / "contracts" / "game_spec.schema.json").read_text(encoding="utf-8"))


def test_chain_produces_a_schema_valid_spec():
    result = run_chain(BASE, AgentContext(prompt="a torchlit dungeon crawl", seed=7))
    jsonschema.validate(result.spec, SCHEMA)  # raises on violation
    assert result.brief_source == "rules"  # no LLM in tests
    assert result.spec["meta"]["genre"] == "dungeon_crawl_3d"
    assert result.spec["world"]["zone_graph"]["algorithm"] == "wfc_dressing"
    assert result.spec["world"]["lighting_preset_id"] == "cave_torchlit"


def test_every_agent_contributes_and_is_logged():
    result = run_chain(BASE, AgentContext(prompt="escape the foggy village", seed=3))
    agents = [p["agent"] for p in result.agent_proposals]
    assert agents == [
        "prompt_analyzer",
        "world_designer",
        "mechanics",
        "game_designer",
        "content_designer",
    ]
    # Each agent's patches are non-empty and land in the arbiter's log.
    assert all(p["patches"] for p in result.agent_proposals)
    deciders = {d["source"] for d in result.arbiter_decisions}
    assert {"prompt_analyzer", "world_designer", "mechanics"} <= deciders

    # Provenance: the world designer owns topology, mechanics owns the controller.
    topology = next(
        d for d in result.arbiter_decisions if d["path"] == "world.zone_graph.algorithm"
    )
    assert topology["source"] == "world_designer"
    controller = next(
        d for d in result.arbiter_decisions if d["path"] == "player.controller_template_id"
    )
    assert controller["source"] == "mechanics"


def test_explicit_user_option_beats_agent_inference():
    result = run_chain(
        BASE,
        AgentContext(prompt="a torchlit dungeon crawl", seed=7, camera="third_person"),
    )
    assert result.spec["meta"]["camera"] == "third_person"  # user wins over the analyzer
    cam = next(d for d in result.arbiter_decisions if d["path"] == "meta.camera")
    assert cam["source"] == "user_options"
    # ...and the agent's losing proposal is recorded, not silently dropped.
    assert any(loser["source"] == "prompt_analyzer" for loser in cam["losers"])


def test_chain_is_deterministic():
    ctx = AgentContext(prompt="a huge arena battle with a horde", seed=11)
    a, b = run_chain(BASE, ctx), run_chain(BASE, ctx)
    assert a.spec == b.spec
    assert a.arbiter_decisions == b.arbiter_decisions


def test_chain_matches_the_legacy_spec_builder():
    """The agent chain must produce exactly what the single-planner path did.

    This guards the CI-enforced 20/20 benchmark gate while the pipeline
    swaps over to agents-as-patches: if the two ever diverge, this fails.
    """
    from agents.intent import parse_intent
    from agents.spec_builder import build_spec

    for prompt in (
        "escape the foggy zombie village",
        "a tiny peaceful garden to explore",
        "a huge dungeon crawl with a horde of skeletons on many floors",
        "a moonlit arena duel against guards",
    ):
        seed = 4521
        legacy = build_spec(
            BASE, parse_intent(prompt), "g3d_x_00000000", prompt, seed
        )
        chained = author_spec(
            BASE, AgentContext(prompt=prompt, seed=seed), "g3d_x_00000000", prompt
        ).spec
        assert chained == legacy, f"divergence for: {prompt}"
