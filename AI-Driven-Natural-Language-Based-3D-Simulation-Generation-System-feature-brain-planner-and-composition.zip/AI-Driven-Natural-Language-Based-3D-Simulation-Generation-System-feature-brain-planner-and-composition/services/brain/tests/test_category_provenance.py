"""A specific thing may be sourced from the general word the prompt used.

The largest cause of failed publication in this system's history. Measured across every
stored run:

    requirement_traceability      96 failures, second only to the vision critic
      REQUIREMENT_SOURCE_NOT_TRACEABLE      96
      ENTITY_PRESENCE_REQUIREMENT_MISSING   88

A requirement's `source_text` must appear VERBATIM in the prompt -- that is what stops the
planner inventing content nobody asked for. But elaborating is the planner's job: given
"a student watches animals react to changing weather" it authored `ent_white_tailed_deer_01`,
`ent_cardinal_01`, `ent_blue_jay_01` and `ent_white_footed_mouse_01`, and not one of those
names occurs in the prompt. Four correct, well-chosen animals, refused for being specific,
and the run could not publish.
"""

from agents.simulation_planner import _is_creature, _nouns_for, _verbatim_span

FOREST = (
    "Create a forest ecosystem lesson where a student watches animals react to "
    "changing weather."
)


def _source(prompt: str, semantic_type: str) -> str | None:
    entity = {"entity_id": f"ent_{semantic_type}_01", "semantic_type": semantic_type}
    return _verbatim_span(prompt, *_nouns_for(entity))


def test_the_four_animals_that_blocked_publication() -> None:
    for semantic_type in (
        "white_tailed_deer",
        "cardinal",
        "blue_jay",
        "white_footed_mouse",
    ):
        assert _source(FOREST, semantic_type) == "animals", semantic_type


def test_a_specific_word_still_wins_when_the_prompt_uses_it() -> None:
    """`_verbatim_span` returns the LONGEST candidate, so provenance stays as precise
    as the prompt allows."""
    prompt = "A forest with a white tailed deer and other animals."
    assert _source(prompt, "white_tailed_deer") == "white tailed deer"


def test_content_nobody_mentioned_still_has_nothing_to_point_at() -> None:
    """The category word must itself occur in the prompt. This is provenance, not a
    loophole -- a barbecue in a forest lesson is still unsourced."""
    assert _source(FOREST, "barbecue_grill") is None
    assert _source(FOREST, "drywall_walls") is None
    # No animal word in the prompt at all: a deer cannot be sourced either.
    assert _source("Build a warehouse safety simulation.", "white_tailed_deer") is None


def test_other_categories_reach_their_own_general_words() -> None:
    assert _source("A village of houses and gardens.", "cottage") == "houses"
    assert _source("A courtyard with plants.", "boxwood_shrub") == "plants"
    assert _source("A yard with vehicles parked.", "delivery_cart") == "vehicles"
    assert _source("A platform with people waiting.", "tea_vendor") == "people"


def test_woodland_fauna_are_creatures() -> None:
    """`_is_creature` also gates the `animal` capability, so this widens both."""
    for semantic_type in ("cardinal", "blue_jay", "chipmunk", "frog", "butterfly"):
        assert _is_creature({"semantic_type": semantic_type}), semantic_type
    for semantic_type in ("drywall_walls", "forklift", "dog_kennel"):
        assert not _is_creature({"semantic_type": semantic_type}), semantic_type
