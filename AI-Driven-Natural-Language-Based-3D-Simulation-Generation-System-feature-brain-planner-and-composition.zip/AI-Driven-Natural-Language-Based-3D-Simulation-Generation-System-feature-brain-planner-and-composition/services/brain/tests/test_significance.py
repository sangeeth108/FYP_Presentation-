"""Significance tests for the ablations, validated against scipy.

These implementations are pure stdlib because scipy is not a dependency of any
service and CI installs almost nothing — importing it here would break collection
the moment a test touched this module (exactly what kept the worker job red for
months with httpx). But "pure stdlib" is worthless if it is pure and WRONG, so
where scipy happens to be installed these are checked against it, and skipped
where it isn't.

Statistics done wrong is worse than statistics not done: a bad p-value in a
dissertation is a claim you cannot defend.
"""

import math
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "eval"))

from metrics.significance import (  # noqa: E402
    bootstrap_ci,
    cliffs_delta,
    holm_bonferroni,
    mcnemar_exact,
    wilcoxon,
)

scipy_stats = pytest.importorskip("scipy.stats", reason="scipy is a dev nicety, not a dependency")


# --- the choice of test is the important part -----------------------------


def test_wilcoxon_on_binary_data_is_anti_conservative_which_is_why_we_use_mcnemar():
    """The reason this module exists.

    On paired BINARY data every non-zero difference has magnitude 1, so Wilcoxon
    ranks nothing but ties and its normal approximation reports significance that
    is not there. Same data, opposite conclusions — and the wrong one would put a
    false claim in the dissertation.
    """
    x = [1] * 18 + [0] * 2
    y = [1] * 13 + [0] * 1 + [1] * 1 + [0] * 5

    wrong = scipy_stats.wilcoxon(x, y).pvalue  # what the plan's wording implies
    right = mcnemar_exact(x, y).p_value

    assert wrong < 0.05  # "significant"
    assert right > 0.05  # ...it is not
    # Opposite conclusions from identical data. That is the entire point; the
    # exact ratio is not a claim worth making.


def test_mcnemar_matches_scipys_exact_binomial():
    # McNemar exact IS a binomial test on the discordant pairs; scipy has no
    # mcnemar in stats, so check it against the binomial it reduces to.
    for b, c in [(5, 1), (1, 5), (10, 3), (0, 4), (7, 7), (2, 0)]:
        x = [1] * b + [0] * c + [1] * 3 + [0] * 3
        y = [0] * b + [1] * c + [1] * 3 + [0] * 3
        got = mcnemar_exact(x, y)
        expected = scipy_stats.binomtest(min(b, c), b + c, 0.5).pvalue
        assert got.p_value == pytest.approx(expected, abs=1e-9), (b, c)
        assert got.n == b + c


def test_identical_arms_are_never_significant():
    x = [1, 0, 1, 1, 0]
    got = mcnemar_exact(x, list(x))
    assert got.p_value == 1.0 and got.n == 0
    assert "identical" in got.note


# --- wilcoxon, where it IS the right test (continuous) --------------------


def test_wilcoxon_matches_scipy_on_continuous_data():
    # Latency-shaped: paired, continuous, no ties.
    x = [12.4, 18.1, 9.7, 22.3, 15.0, 11.2, 19.8, 25.1, 13.3, 16.6, 20.2, 8.9]
    y = [14.1, 17.2, 11.9, 26.0, 15.9, 12.8, 21.0, 24.2, 15.1, 18.0, 22.9, 10.4]
    got = wilcoxon(x, y)
    expected = scipy_stats.wilcoxon(x, y, correction=True, mode="approx").pvalue
    assert got.p_value == pytest.approx(expected, rel=0.02)


def test_wilcoxon_handles_ties_and_zero_differences():
    x = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0]
    y = [1.0, 2.5, 3.0, 4.5, 5.0, 6.5, 7.0, 8.5, 9.0, 10.5, 11.0, 12.5]
    got = wilcoxon(x, y)
    assert got.n == 6  # the six identical pairs are dropped, not counted
    assert 0.0 <= got.p_value <= 1.0


def test_wilcoxon_says_so_when_n_is_too_small_to_trust():
    got = wilcoxon([1.0, 2.0, 3.0], [2.0, 3.0, 4.0])
    assert "unreliable" in got.note  # the caller must not quote this as a finding


def test_paired_data_of_different_lengths_is_refused():
    with pytest.raises(ValueError, match="same length"):
        wilcoxon([1.0, 2.0], [1.0])
    with pytest.raises(ValueError, match="same length"):
        mcnemar_exact([1, 0], [1])


# --- effect size ----------------------------------------------------------


def test_cliffs_delta_is_signed_and_bounded():
    assert cliffs_delta([5, 6, 7], [1, 2, 3]) == (1.0, "large")  # complete dominance
    assert cliffs_delta([1, 2, 3], [5, 6, 7]) == (-1.0, "large")  # ...and reversed
    delta, label = cliffs_delta([1, 2, 3], [1, 2, 3])
    assert delta == 0.0 and label == "negligible"


def test_cliffs_delta_measures_dominance_not_magnitude():
    """A caveat worth knowing before quoting this in a dissertation.

    Half of x is 0.1 higher than every y — a difference no player could perceive
    — and Cliff's delta calls it LARGE. It is not wrong: delta answers "does x
    stochastically dominate y", not "by how much". So report it for direction and
    consistency, and report the raw medians/means for magnitude. Reading delta as
    "how big is the effect in game terms" would overclaim.
    """
    x = [10.0] * 30 + [10.1] * 30
    y = [10.0] * 60
    delta, label = cliffs_delta(x, y)
    assert delta == pytest.approx(0.5)  # 30x60 of 60x60 comparisons favour x
    assert label == "large"  # ...on a 0.1 difference. Dominance, not magnitude.


# --- bootstrap ------------------------------------------------------------


def test_bootstrap_ci_brackets_the_mean_and_is_reproducible():
    values = [12.0, 14.0, 11.0, 15.0, 13.0, 12.5, 14.5, 13.5, 11.5, 16.0]
    lo, hi = bootstrap_ci(values)
    mean = sum(values) / len(values)
    assert lo < mean < hi
    assert (lo, hi) == bootstrap_ci(values)  # seeded: same data, same CI (rule 14)


def test_a_wider_confidence_level_gives_a_wider_interval():
    values = [float(v) for v in range(20)]
    lo95, hi95 = bootstrap_ci(values, confidence=0.95)
    lo99, hi99 = bootstrap_ci(values, confidence=0.99)
    assert (hi99 - lo99) >= (hi95 - lo95)


# --- multiple comparisons -------------------------------------------------


def test_holm_is_more_powerful_than_bonferroni_but_still_controls_the_family():
    # p=0.01 with 4 tests: Bonferroni needs <= 0.0125, Holm compares to 0.05/4
    # for the smallest, then 0.05/3, ... Holm rejects at least as much as
    # Bonferroni, never more than is safe.
    ps = {"a": 0.001, "b": 0.01, "c": 0.04, "d": 0.9}
    out = holm_bonferroni(ps, alpha=0.05)
    assert out["a"]["significant"]  # 4 * 0.001 = 0.004
    assert out["b"]["significant"]  # 3 * 0.01  = 0.03
    assert not out["c"]["significant"]  # 2 * 0.04 = 0.08 > 0.05 -> stop
    assert not out["d"]["significant"]  # step-down: everything after also fails


def test_holm_step_down_stops_at_the_first_failure():
    # Even though 1 * 0.04 = 0.04 < 0.05, 'c' must NOT be rescued after 'b' failed.
    ps = {"a": 0.049, "b": 0.04}
    out = holm_bonferroni(ps, alpha=0.05)
    assert not out["a"]["significant"] and not out["b"]["significant"]


def test_adjusted_p_values_are_monotone_and_bounded():
    ps = {f"t{i}": p for i, p in enumerate([0.001, 0.02, 0.03, 0.5, 0.99])}
    out = holm_bonferroni(ps)
    adjusted = [out[k]["p_adjusted"] for k in sorted(out, key=lambda k: out[k]["rank"])]
    assert adjusted == sorted(adjusted)  # never decreases as raw p grows
    assert all(0.0 <= a <= 1.0 for a in adjusted)


def test_no_tests_is_not_a_crash():
    assert holm_bonferroni({}) == {}


def test_a_single_test_is_uncorrected():
    out = holm_bonferroni({"only": 0.03})
    assert out["only"]["p_adjusted"] == pytest.approx(0.03)
    assert out["only"]["significant"]


def test_phi_is_a_real_normal_cdf():
    from metrics.significance import _phi

    assert _phi(0.0) == pytest.approx(0.5)
    assert _phi(1.96) == pytest.approx(0.975, abs=1e-3)
    assert _phi(-1.96) == pytest.approx(0.025, abs=1e-3)
    assert math.isclose(_phi(8.0), 1.0, abs_tol=1e-9)
