"""The P2 MID-DEMO gate as a CI-enforced invariant.

Runs the frozen 20-prompt benchmark through the real brain-side pipeline and
asserts the documented gate: >=80% pass unaided. Fast (~20 x 30ms), so it
guards every push against a regression that would sink the mid-demo.
"""

import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO / "services" / "worker"))
sys.path.insert(0, str(REPO / "eval"))

from run_benchmark import run_benchmark  # noqa: E402


def test_frozen_benchmark_meets_the_mid_demo_gate():
    summary, results = run_benchmark()
    assert summary.total == 20, "the frozen set must stay at 20 prompts"
    assert summary.gate_met, (
        f"pass rate {summary.pass_rate:.0%} < {summary.gate_threshold:.0%}: "
        f"{[r.prompt_id for r in results if r.verdict != 'PASS']}"
    )
    # Every prompt must be schema-valid and route to its expected genre —
    # a regression in either is a real quality drop even if the gate holds.
    assert summary.schema_valid == 20
    # Static planning is not a production result. Without engine exports and
    # runtime probes the report must never claim production readiness.
    assert summary.built == 0
    assert summary.played == 0
    assert summary.production_passed == 0
    assert summary.production_ready is False
    assert summary.genre_matched == 20, (
        f"genre mismatches: {[(r.prompt_id, r.genre) for r in results if not r.genre_match]}"
    )


def test_benchmark_is_reproducible():
    _, a = run_benchmark()
    _, b = run_benchmark()
    assert [r.level_plan_hash for r in a] == [r.level_plan_hash for r in b]
