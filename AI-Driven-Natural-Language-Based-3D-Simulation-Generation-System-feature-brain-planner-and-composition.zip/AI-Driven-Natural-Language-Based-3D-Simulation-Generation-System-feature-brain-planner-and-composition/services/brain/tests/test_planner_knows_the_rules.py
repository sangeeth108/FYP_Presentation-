"""Every rule a validator enforces must be one the planner was told.

Eight conventions lived only inside verification/contracts.py: the literal
`can_explore` predicate, the actor's own noun in semantic_type, verbatim
source_text, an `exists` requirement per entity, time and weather matching the
prompt exactly, distinct requirement ids, capability ids from a closed list.
The planner had no way to know any of them. Each was found the same way -- a
run failed, the cause was traced back, and a rule was added to the system
prompt. Eight separate times.

Schema `description` fields do not help: the contract reaches the model through
Ollama's `format` grammar, which carries structure and discards prose. The
system prompt is the only channel.

So this test pins the coupling. Adding a validator rule the planner can prevent,
without telling the planner, fails here rather than in a run three prompts
later.
"""

from __future__ import annotations

import inspect
import re
from pathlib import Path

import pytest
from agents import simulation_planner

_CONTRACTS = (
    Path(__file__).resolve().parents[1] / "verification" / "contracts.py"
)

# For each error code the PLANNER can avoid, a phrase that must appear in its
# system prompt. The phrase is deliberately a fragment of the guidance, not the
# whole of it, so rewording the explanation does not break the test but deleting
# it does.
PLANNER_PREVENTABLE: dict[str, str] = {
    "PROMPT_ACTION_OMITTED": "can_explore",
    "PROMPT_ACTOR_OMITTED": "ent_controlled_actor.semantic_type",
    "PROMPT_ENVIRONMENT_OMITTED": "environment.semantic_type",
    "PROMPT_TIME_CONTRADICTION": "time_of_day",
    "PROMPT_WEATHER_CONTRADICTION": "weather",
    "REQUIREMENT_SOURCE_NOT_TRACEABLE": "VERBATIM",
    "ENTITY_PRESENCE_REQUIREMENT_MISSING": "exists",
    "ACTOR_IDENTITY_REQUIREMENT_MISSING": "ent_controlled_actor",
    "REQUIREMENT_SUBJECT_UNKNOWN": "subject",
    "DUPLICATE_REQUIREMENT_ID": "distinct",
    "CAPABILITY_BEHAVIOR_OMITTED": "Capabilities",
    "REQUIRED_BEHAVIOR_GRAPH_MISSING": "capabilit",
}

# Codes the planner cannot prevent: they describe what placement or the world
# builder did, not what the spec said.
NOT_PLANNER_PREVENTABLE = {
    "REQUIRED_ENTITY_NOT_PLACED",
    "SPEC_WORLD_ENTITY_COUNT_DISAGREEMENT",
    "SPATIAL_SUBJECT_UNKNOWN",
    "SPATIAL_TARGET_UNKNOWN",
    "REQUIREMENT_NOT_OBSERVABLE",
}


def _validator_codes() -> set[str]:
    source = _CONTRACTS.read_text(encoding="utf-8")
    return set(re.findall(r'"code":\s*"([A-Z_]+)"', source))


def _planner_prompt() -> str:
    """The system prompt the planner is actually given."""
    return inspect.getsource(simulation_planner)


def test_every_validator_code_is_accounted_for():
    """A new rule must be classified, so it cannot be added and forgotten."""
    known = set(PLANNER_PREVENTABLE) | NOT_PLANNER_PREVENTABLE
    unclassified = _validator_codes() - known
    assert not unclassified, (
        f"verification/contracts.py emits {sorted(unclassified)} and this test "
        "does not know whether the planner can prevent it. Add it to "
        "PLANNER_PREVENTABLE with the guidance that stops it, or to "
        "NOT_PLANNER_PREVENTABLE with a reason."
    )


def test_no_stale_entries():
    """A rule removed from the validator should not linger here."""
    stale = (set(PLANNER_PREVENTABLE) | NOT_PLANNER_PREVENTABLE) - _validator_codes()
    assert not stale, f"{sorted(stale)} is no longer emitted by any validator"


@pytest.mark.parametrize(
    ("code", "phrase"), sorted(PLANNER_PREVENTABLE.items())
)
def test_the_planner_is_told_about_this_rule(code: str, phrase: str):
    """The rule exists in the validator; it must also exist in the prompt."""
    assert phrase in _planner_prompt(), (
        f"{code} is enforced by a validator but its guidance ({phrase!r}) is "
        "not in the planner's system prompt. A rule the model is never told is "
        "a rule it will break, and the failure will surface as a wasted run."
    )
