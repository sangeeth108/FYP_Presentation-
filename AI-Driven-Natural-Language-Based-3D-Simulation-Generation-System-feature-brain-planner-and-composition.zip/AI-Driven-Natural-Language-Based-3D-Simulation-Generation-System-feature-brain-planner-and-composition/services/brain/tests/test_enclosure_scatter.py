"""Mass content belongs inside the building the prompt is about.

Measured on a warehouse run that passed all eighteen gates: the walls enclosed 40x60 m of
a 77x93 m world, and because scatter samples the WORLD, 219 of 275 instances (80%) --
including all ten racking units -- were laid down outside the building. Pallets in a
field, with the warehouse itself nearly bare.

Shrinking the world to its walls was tried instead and measured worse: it left four wall
segments unplaced and took the run from 18/18 gates to 8/18, because the spec also
carries free-standing wall entities that need ground of their own. The world stays
generous; only the scatter comes inside.
"""

from pcg.enclosure import enclosure_extent
from pcg.scatter import _zone_rects

_SIDES = {
    "north": ([-20.0, -30.0], [20.0, -30.0]),
    "south": ([-20.0, 30.0], [20.0, 30.0]),
    "west": ([-20.0, -30.0], [-20.0, 30.0]),
    "east": ([20.0, -30.0], [20.0, 30.0]),
}


def _ring(*, without: str | None = None) -> list[dict]:
    return [
        {
            "structure_id": f"lin_wall_{side}",
            "semantic_type": "wall",
            "from_m": list(start),
            "to_m": list(end),
        }
        for side, (start, end) in _SIDES.items()
        if side != without
    ]


def _world_zone() -> list[dict]:
    return [
        {
            "zone_id": "zone_world",
            "bounds": {"min": [-38.5, 0.0, -46.4], "max": [38.5, 6.0, 46.4]},
        }
    ]


def test_a_closed_ring_is_recognised() -> None:
    assert enclosure_extent(_ring()) == (-20.0, -30.0, 20.0, 30.0)


def test_three_walls_are_not_an_enclosure() -> None:
    """A courtyard with an open side encloses nothing to scatter into."""
    assert enclosure_extent(_ring(without="east")) is None
    assert enclosure_extent([]) is None
    assert enclosure_extent(None) is None


def test_scatter_is_clipped_to_the_walls() -> None:
    rects = _zone_rects({}, _world_zone(), enclosure_extent(_ring()))
    assert len(rects) == 1
    assert rects[0]["min"][0] == -20.0 and rects[0]["max"][0] == 20.0
    assert rects[0]["min"][2] == -30.0 and rects[0]["max"][2] == 30.0
    # Height is the zone's business, not the wall ring's.
    assert rects[0]["max"][1] == 6.0


def test_an_unwalled_world_scatters_everywhere() -> None:
    """A forest has no walls, and must not be confined by their absence."""
    rects = _zone_rects({}, _world_zone(), None)
    assert rects[0]["max"][0] == 38.5


def test_walls_that_share_no_ground_with_a_zone_do_not_empty_the_world() -> None:
    """Better the world as it was than nowhere at all to put anything."""
    faraway = [
        {"zone_id": "zone_far", "bounds": {"min": [200.0, 0.0, 200.0],
                                           "max": [240.0, 6.0, 240.0]}}
    ]
    rects = _zone_rects({}, faraway, enclosure_extent(_ring()))
    assert rects == [faraway[0]["bounds"]]


def test_a_species_keeps_its_own_zone_restriction() -> None:
    zones = _world_zone() + [
        {"zone_id": "zone_bay", "bounds": {"min": [-10.0, 0.0, -10.0],
                                           "max": [10.0, 6.0, 10.0]}}
    ]
    rects = _zone_rects({"zones": ["zone_bay"]}, zones, enclosure_extent(_ring()))
    assert len(rects) == 1
    assert rects[0]["max"][0] == 10.0
