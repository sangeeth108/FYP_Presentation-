from pcg.layout import generate_layout
from pcg.placement import EnemySpec, PropSpec, generate_placement
from pcg.zone_graph import generate_zone_graph


def test_bsp_same_seed_same_graph():
    a = generate_zone_graph(seed=4521, zone_count=9, algorithm="bsp")
    b = generate_zone_graph(seed=4521, zone_count=9, algorithm="bsp")
    assert a.zones == b.zones
    assert a.edges == b.edges


def test_bsp_is_a_tree_and_connected():
    for seed in range(25):
        for zone_count in (3, 5, 12, 20):
            g = generate_zone_graph(seed=seed, zone_count=zone_count, algorithm="bsp")
            assert len(g.zones) == zone_count
            assert len(g.edges) == zone_count - 1  # tree: no loops
            assert g.is_connected()


def test_bsp_lock_and_key_invariants():
    for seed in range(25):
        g = generate_zone_graph(seed=seed, zone_count=8, algorithm="bsp")
        kinds = {z.zone_id: z.kind for z in g.zones}
        assert list(kinds.values()).count("entry") == 1
        assert list(kinds.values()).count("exit") == 1
        assert list(kinds.values()).count("key") == 1

        exit_id = next(zid for zid, k in kinds.items() if k == "exit")
        exit_edges = [e for e in g.edges if exit_id in (e.a, e.b)]
        assert len(exit_edges) == 1
        assert exit_edges[0].kind == "locked"
        neighbor = exit_edges[0].a if exit_edges[0].b == exit_id else exit_edges[0].b
        assert kinds[neighbor] == "key"


def test_bsp_differs_from_room_corridor_topology():
    bsp = generate_zone_graph(seed=4521, zone_count=12, algorithm="bsp")
    chain = generate_zone_graph(seed=4521, zone_count=12, algorithm="room_corridor")
    bsp_pairs = {frozenset((e.a, e.b)) for e in bsp.edges}
    chain_pairs = {frozenset((e.a, e.b)) for e in chain.edges}
    assert bsp_pairs != chain_pairs


def test_bsp_graphs_drive_layout_and_placement():
    enemies = [EnemySpec(enemy_id="guard", count=4)]
    props = [PropSpec(prop_id="chest", placement_tags=("loot",))]
    for seed in range(10):
        g = generate_zone_graph(seed=seed, zone_count=10, algorithm="bsp")
        layout = generate_layout(g)
        assert layout.has_no_overlaps()
        result = generate_placement(g, layout, enemies, props)
        assert len(result.entities) == 5
