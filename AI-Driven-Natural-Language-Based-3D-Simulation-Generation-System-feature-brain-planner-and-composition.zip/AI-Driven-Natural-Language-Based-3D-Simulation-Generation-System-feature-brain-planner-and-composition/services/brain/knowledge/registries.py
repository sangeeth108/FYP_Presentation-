"""Registries — the allowlist that makes invented IDs impossible.

Every template/preset/kit id an agent may put in a spec must exist HERE, and
the registry is derived from what is actually implemented (the vetted
`engine/templates/*.gd` files and the kit the writer honors) — so it cannot
drift into promising behavior the engine does not deliver. Drift against the
worker's own maps is guarded by tests.

This is the "allowlist enforcement" of docs/GENERATION_PIPELINE.md: an agent
that hallucinates `controller_hover_bike` fails immediately with a
machine-readable error, instead of producing a broken build later.

(The DB-backed registry tables with params-schemas + RAG notes are the next
step; the filesystem is the source of truth today and stays authoritative.)
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

_REPO = Path(__file__).resolve().parents[3]
TEMPLATES_DIR = _REPO / "engine" / "templates"
KITS_DIR = _REPO / "content" / "kits"

# Vetted WorldEnvironment presets. Source of truth for the whole brain
# (agents/intent imports these); drift vs the worker's implementations is
# asserted in tests.
LIGHTING_PRESETS: tuple[str, ...] = (
    "overcast_day",
    "moonlit_night",
    "dusk_fog",
    "sunny_bright",
    "cave_torchlit",
)

# Interactables the project writer honors. Some are behavior templates
# (`door_hinged*` -> door_hinged.gd, `locked` variant reuses it); the rest are
# honored by the curated asset kit, which resolves them to real GLB models.
KIT_INTERACTABLES: tuple[str, ...] = (
    "chest_lidded",
    "pickup_supply",
    "lever_switch",
    "spawn_site",
    "ladder_climbable",
    "gate_sliding",
    "objective_trigger",
)
DOOR_INTERACTABLES: tuple[str, ...] = ("door_hinged", "door_hinged_lockable")


@lru_cache(maxsize=1)
def script_templates() -> dict[str, frozenset[str]]:
    """{category -> template ids} scanned from the vetted GDScript templates."""
    found: dict[str, set[str]] = {}
    for path in sorted(TEMPLATES_DIR.rglob("*.gd")):
        category = path.parent.name  # ai | controllers | interactables | objectives | ui
        found.setdefault(category, set()).add(path.stem)
    return {category: frozenset(ids) for category, ids in found.items()}


@lru_cache(maxsize=1)
def registry() -> dict[str, frozenset[str]]:
    """The full allowlist, keyed by the spec field each set governs."""
    scripts = script_templates()
    objectives = scripts.get("objectives", frozenset())
    return {
        "controller_template_id": scripts.get("controllers", frozenset()),
        "ai_template_id": scripts.get("ai", frozenset()),
        # No combat template exists yet — melee lives inside ai_patrol_chase.
        # An empty set means any combat_template_id is rejected, on purpose.
        "combat_template_id": frozenset(),
        "interactable_template_id": frozenset(KIT_INTERACTABLES) | frozenset(DOOR_INTERACTABLES),
        # player_death is a fail state, not a selectable objective.
        "objective_template_id": objectives - {"player_death"},
        "fail_template_id": objectives & {"player_death"},
        "lighting_preset_id": frozenset(LIGHTING_PRESETS),
    }


def unknown_ids(spec: dict) -> list[dict]:
    """Every id in the spec that is NOT in the registry, as error objects."""
    allow = registry()
    found: list[tuple[str, str, str]] = []  # (json path, field, id)

    def check(json_path: str, field: str, value: object) -> None:
        if value is None:
            return
        found.append((json_path, field, str(value)))

    check("$.player.controller_template_id", "controller_template_id",
          spec["player"].get("controller_template_id"))
    check("$.world.lighting_preset_id", "lighting_preset_id",
          spec["world"].get("lighting_preset_id"))
    for i, enemy in enumerate(spec["entities"]["enemies"]):
        check(f"$.entities.enemies[{i}].ai_template_id", "ai_template_id",
              enemy.get("ai_template_id"))
        check(f"$.entities.enemies[{i}].combat_template_id", "combat_template_id",
              enemy.get("combat_template_id"))
    for i, prop in enumerate(spec["entities"]["props"]):
        check(f"$.entities.props[{i}].interactable_template_id", "interactable_template_id",
              prop.get("interactable_template_id"))
    for i, objective in enumerate(spec["objectives"]):
        check(f"$.objectives[{i}].objective_template_id", "objective_template_id",
              objective.get("objective_template_id"))
    for i, fail in enumerate(spec.get("fail_states", [])):
        check(f"$.fail_states[{i}].fail_template_id", "fail_template_id",
              fail.get("fail_template_id"))

    errors = []
    for json_path, field, value in found:
        legal = allow[field]
        if value not in legal:
            errors.append(
                {
                    "code": "TEMPLATE_ID_NOT_IN_REGISTRY",
                    "path": json_path,
                    "message": f"'{value}' is not a vetted {field}",
                    "hint": (
                        f"Allowed: {', '.join(sorted(legal))}."
                        if legal
                        else f"No {field} is implemented yet — omit the field."
                    ),
                    "failure_class": "schema",
                }
            )
    return errors
