"""Knowledge layer: registries (allowlist enforcement) and, next, RAG over
design notes (bge-m3 + pgvector)."""

from knowledge.registries import LIGHTING_PRESETS, registry, script_templates, unknown_ids

__all__ = ["LIGHTING_PRESETS", "registry", "script_templates", "unknown_ids"]
