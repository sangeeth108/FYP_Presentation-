"""RAG over design knowledge (RQ3: does retrieval improve controllability?).

Embeds the curated design notes with **bge-m3** (served locally by Ollama,
MIT — see the licensing ledger) and retrieves the top-k most relevant notes
for a prompt. Retrieved notes are injected into the planner's context so the
LLM designs with *this system's* real capabilities in mind, instead of
inventing mechanics — measurably reducing spec drift (ablation C vs D).

Robustness, in the same spirit as the rest of the brain: the embedder is
never a hard dependency. If Ollama is unavailable or the model is missing,
retrieval falls back to deterministic keyword scoring over the notes' tags,
so generation still gets relevant knowledge and nothing hangs.

Storage: the corpus is a dozen notes, so an in-memory index (cached per
process) is the right size. pgvector persistence becomes worthwhile when the
corpus grows or is shared across workers — the `search()` seam stays the same.
"""

from __future__ import annotations

import json
import math
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import httpx

NOTES_PATH = Path(__file__).resolve().parent / "notes" / "design_notes.json"
EMBED_MODEL = "bge-m3"
EMBED_TIMEOUT = 30.0

# Cosine floor for the embedding path. Measured on bge-m3 against this corpus:
# on-topic prompts score 0.62-0.71 at the top, gibberish peaks at 0.41 and
# off-domain questions at 0.25. Below this floor the prompt simply isn't about
# game design, so we retrieve NOTHING rather than pollute the planner's context.
MIN_TOP_SIMILARITY = 0.5
QUERY_STOPWORDS = {
    "what",
    "when",
    "where",
    "which",
    "who",
    "why",
    "how",
}


@dataclass(frozen=True)
class Note:
    id: str
    tags: tuple[str, ...]
    text: str


@lru_cache(maxsize=1)
def load_notes() -> tuple[Note, ...]:
    data = json.loads(NOTES_PATH.read_text(encoding="utf-8"))
    return tuple(
        Note(id=n["id"], tags=tuple(n["tags"]), text=n["text"]) for n in data["notes"]
    )


def _embed(
    texts: list[str], base_url: str, transport: httpx.BaseTransport | None = None
) -> list[list[float]] | None:
    """bge-m3 embeddings via Ollama. None on ANY failure (caller falls back)."""
    try:
        with httpx.Client(base_url=base_url, timeout=EMBED_TIMEOUT, transport=transport) as client:
            response = client.post(
                "/api/embed",
                json={"model": EMBED_MODEL, "input": texts, "keep_alive": "30m"},
            )
            response.raise_for_status()
            vectors = response.json()["embeddings"]
        if len(vectors) != len(texts):
            return None
        return vectors
    except Exception:
        return None


def _cosine(a: list[float], b: list[float]) -> float:
    # strict: both vectors come from the same embed model, so unequal lengths mean
    # a corrupt index — silently truncating would hide it behind a plausible score.
    dot = sum(x * y for x, y in zip(a, b, strict=True))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


@lru_cache(maxsize=4)
def _note_vectors(base_url: str) -> tuple[list[float], ...] | None:
    """Embed the corpus once per process (the notes never change at runtime)."""
    notes = load_notes()
    vectors = _embed([f"{' '.join(n.tags)}. {n.text}" for n in notes], base_url)
    return tuple(vectors) if vectors else None


def _keyword_scores(query: str, notes: tuple[Note, ...]) -> list[float]:
    """Deterministic fallback: overlap between the prompt's words and tags."""
    words = {
        word
        for word in re.findall(r"[a-z]+", query.lower())
        if word not in QUERY_STOPWORDS
    }
    scores = []
    for note in notes:
        hits = sum(
            1
            for tag in note.tags
            if any(
                word.startswith(tag[:4]) or tag.startswith(word[:4])
                for word in words
                if len(word) > 3
            )
        )
        scores.append(float(hits))
    return scores


def search(query: str, k: int = 3, base_url: str = "http://localhost:11434") -> list[Note]:
    """Top-k design notes for a prompt. Never raises; never returns nothing
    useful — falls back to keyword scoring if the embedder is unavailable."""
    notes = load_notes()
    note_vectors = _note_vectors(base_url)

    floor = 0.0  # keyword path: any tag hit is a real signal
    scores: list[float] | None = None
    if note_vectors is not None:
        query_vector = _embed([query], base_url)
        if query_vector:
            scores = [_cosine(query_vector[0], v) for v in note_vectors]
            floor = MIN_TOP_SIMILARITY
    if scores is None:
        scores = _keyword_scores(query, notes)

    if not scores or max(scores) <= floor:
        return []  # off-domain / gibberish: better to retrieve nothing than noise

    ranked = sorted(zip(scores, range(len(notes)), strict=True), key=lambda p: (-p[0], p[1]))
    return [notes[i] for score, i in ranked[:k] if score > 0]


def as_context(notes: list[Note]) -> str:
    """Render retrieved notes for injection into the planner's system prompt."""
    if not notes:
        return ""
    lines = ["Relevant design knowledge for THIS system (follow it):"]
    lines += [f"- {n.text}" for n in notes]
    return "\n".join(lines)
