"""Artifact storage backends (local + Cloudflare R2)."""
