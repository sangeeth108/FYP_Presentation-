"""Cloudflare R2 artifact upload (P3 hybrid deploy).

Uploads a job's published artifacts (web build + downloadable project) to R2 so
they are shareable with $0 egress, and returns their public URLs. R2 speaks the
S3 API, so this uses an S3 client — injected for tests, lazily boto3 in prod.

Never a hard dependency: OFF by default, and any failure returns None so the
pipeline keeps the local /artifacts copy and the job still succeeds. Secrets come
from the environment only (§13) — this module never reads or writes them to disk.
"""

from __future__ import annotations

import logging
import mimetypes
import re
from pathlib import Path
from typing import Protocol

log = logging.getLogger(__name__)


class _S3Client(Protocol):
    def upload_file(self, Filename: str, Bucket: str, Key: str, ExtraArgs: dict) -> None: ...


def _boto3_client(settings) -> _S3Client:
    """The real R2 client (S3-compatible). Imported lazily so a deployment that
    doesn't use R2 never needs boto3 installed."""
    import boto3  # noqa: PLC0415 — optional dependency, only the R2 path needs it

    return boto3.client(
        "s3",
        endpoint_url=settings.r2_endpoint_url,
        aws_access_key_id=settings.r2_access_key_id,
        aws_secret_access_key=settings.r2_secret_access_key,
        region_name="auto",
    )


def is_configured(settings) -> bool:
    delivery_base = getattr(settings, "artifact_gateway_base_url", "") or (
        getattr(settings, "r2_public_base_url", "")
        if getattr(settings, "promptplay_env", "development") != "production"
        else ""
    )
    return bool(
        settings.r2_enabled
        and settings.r2_endpoint_url
        and settings.r2_bucket
        and settings.r2_access_key_id
        and settings.r2_secret_access_key
        and delivery_base
    )


def _safe_segment(value: str) -> str:
    segment = re.sub(r"[^A-Za-z0-9_-]", "_", value.strip())
    if not segment or segment in {".", ".."}:
        raise ValueError("invalid artifact key segment")
    return segment[:128]


def _safe_filename(value: str) -> str:
    filename = re.sub(r"[^A-Za-z0-9_.-]", "_", value.strip())
    if not filename or filename in {".", ".."} or ".." in filename:
        raise ValueError("invalid artifact filename")
    return filename[:255]


def upload_artifacts(
    local_dir: Path,
    key_prefix: str,
    settings,
    client: _S3Client | None = None,
    *,
    tenant_id: str | None = None,
) -> dict[str, str] | None:
    """Upload every file in ``local_dir`` under ``key_prefix/`` and return
    {filename: public_url}. None if R2 is not configured or the upload fails —
    the caller keeps the local copy either way."""
    if not is_configured(settings):
        return None
    if not tenant_id:
        if getattr(settings, "promptplay_env", "development") == "production":
            log.error("R2 upload denied: production artifact lacks tenant identity")
            return None
        tenant_id = "tenant_dev"
    if client is None:
        try:
            client = _boto3_client(settings)
        except Exception as exc:  # boto3 missing / bad config
            log.warning("R2 client unavailable (%s) — keeping local artifacts", exc)
            return None

    base = (
        getattr(settings, "artifact_gateway_base_url", "")
        or getattr(settings, "r2_public_base_url", "")
    ).rstrip("/")
    urls: dict[str, str] = {}
    try:
        scoped_prefix = (
            f"tenants/{_safe_segment(tenant_id)}/runs/{_safe_segment(key_prefix)}"
        )
        for path in sorted(local_dir.iterdir()):
            if not path.is_file():
                continue
            key = f"{scoped_prefix}/{_safe_filename(path.name)}"
            ctype = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
            client.upload_file(
                str(path),
                settings.r2_bucket,
                key,
                {
                    "ContentType": ctype,
                    "CacheControl": "private, max-age=0, no-store",
                },
            )
            urls[path.name] = f"{base}/{key}"
    except Exception as exc:  # a mid-upload failure must not fail the job
        log.warning("R2 upload failed (%s) — keeping local artifacts", exc)
        return None
    return urls


def delete_artifact_prefix(
    settings,
    *,
    tenant_id: str,
    run_prefix: str,
    client=None,
) -> bool:
    """Delete every private object for one tenant-owned compatibility build."""
    if not is_configured(settings):
        return getattr(settings, "promptplay_env", "development") != "production"
    if client is None:
        try:
            client = _boto3_client(settings)
        except Exception as exc:
            log.warning("R2 deletion client unavailable (%s)", type(exc).__name__)
            return False
    prefix = (
        f"tenants/{_safe_segment(tenant_id)}/runs/{_safe_segment(run_prefix)}/"
    )
    try:
        continuation = None
        while True:
            request = {"Bucket": settings.r2_bucket, "Prefix": prefix}
            if continuation:
                request["ContinuationToken"] = continuation
            page = client.list_objects_v2(**request)
            keys = [
                {"Key": item["Key"]}
                for item in page.get("Contents", [])
                if item.get("Key", "").startswith(prefix)
            ]
            if keys:
                client.delete_objects(
                    Bucket=settings.r2_bucket,
                    Delete={"Objects": keys, "Quiet": True},
                )
            if not page.get("IsTruncated"):
                break
            continuation = page.get("NextContinuationToken")
            if not continuation:
                return False
    except Exception as exc:
        log.warning("R2 artifact deletion failed (%s)", type(exc).__name__)
        return False
    return True
