"""Prompt/spec/world traceability checks independent from the planner."""

from __future__ import annotations

import re


def _scatter_subjects(spec: dict) -> set[str]:
    """Names a requirement may use to talk about mass content.

    Scatter was unaddressable: `subject` accepted an entity_id or the literal
    "simulation" and nothing else, so a prompt asking for chickens -- correctly
    modelled as scatter, because they occur in quantity -- could not carry a
    requirement about them at all. A real run wrote `scatter_chickens` and was
    told the subject was unknown, with no legal way to say what it meant.

    Species are matched by id, by semantic_type, and by either prefixed with
    `scatter_`, because that is how the planner refers to them when nothing
    tells it otherwise.
    """
    names: set[str] = set()
    for species in spec.get("scatter") or []:
        for value in (species.get("species_id"), species.get("semantic_type")):
            if not value:
                continue
            names.add(str(value))
            names.add(f"scatter_{value}")
    return names


def _actor_from_prompt(prompt: str) -> str | None:
    match = re.search(
        r"\bas\s+(?:a|an)\s+([a-z][a-z -]{0,40}?)(?=\s+(?:explore|roam|walk|"
        r"drive|operate|inspect|visit|help|travel)\b|[,.;]|$)",
        prompt.lower(),
    )
    return match.group(1).strip() if match else None


def _prompt_environment(prompt: str) -> str | None:
    lower = prompt.lower()
    for value in (
        "village",
        "town",
        "city",
        "factory",
        "warehouse",
        "forest",
        "farm",
        "hospital",
        "school",
        "laboratory",
        "museum",
        "island",
    ):
        if value in lower:
            return value
    return None


def extract_observable_prompt_atoms(prompt: str) -> list[dict]:
    """Small deterministic intake oracle used to catch planner omissions."""
    atoms: list[dict] = []
    actor = _actor_from_prompt(prompt)
    if actor:
        atoms.append({"atom_id": "actor_identity", "kind": "actor", "value": actor})
    environment = _prompt_environment(prompt)
    if environment:
        atoms.append(
            {
                "atom_id": "environment_identity",
                "kind": "environment",
                "value": environment,
            }
        )
    lower = prompt.lower()
    if any(word in lower for word in ("explore", "roam", "walk", "visit")):
        atoms.append(
            {"atom_id": "exploration_action", "kind": "action", "value": "explore"}
        )
    for value in ("rain", "snow", "fog"):
        if value in lower:
            atoms.append({"atom_id": f"weather_{value}", "kind": "weather", "value": value})
    if "night" in lower:
        atoms.append({"atom_id": "time_night", "kind": "time", "value": "night"})
    return atoms


def required_entity_ids(spec: dict) -> set[str]:
    """Entities the PROMPT asked for, as opposed to ones the planner added as texture.

    Three sources, and each is a claim somebody made rather than an inference:

      * the subject of an `exists` requirement -- the prompt named this thing;
      * the subject of any other requirement, because a requirement about a thing
        presupposes the thing;
      * the controlled actor, which every world needs whether or not a requirement
        mentions it.

    Segments of a run are deliberately NOT required individually. One requirement is
    written against the whole run and the rest trace through `part_of` (ADR-0016), so a
    fence's segments are texture: the fence was asked for, segment nine was not. That is
    the distinction ADR-0020 rests on, and it is why this reads requirements rather than
    counting entities.
    """
    required: set[str] = set()
    for requirement in spec.get("requirements") or ():
        subject = str(requirement.get("subject") or "")
        if subject.startswith("ent_"):
            required.add(subject)
    for entity in spec.get("entities") or ():
        if entity.get("role") == "controlled_agent":
            required.add(str(entity.get("entity_id")))
    return required


# What an entity calls itself when it has no body: a driver of behaviour rather than a
# thing in the world. The planner authors these to hold logic belonging to no visible
# object -- an ecosystem's weather response, a spawner, a scoring rule.
_LOGIC_ROLES = frozenset({"logic_driver", "controller", "system", "director"})
_LOGIC_TYPES = frozenset({"system_entity", "sensor_trigger", "controller", "logic"})


def _is_disembodied(entity: dict) -> bool:
    """Whether this entity is logic rather than something anybody could look at.

    Judged on what the spec SAYS, not on size: a 10 cm entity may be a real pebble.
    """
    if str(entity.get("role") or "").strip().lower() in _LOGIC_ROLES:
        return True
    return str(entity.get("semantic_type") or "").strip().lower() in _LOGIC_TYPES


def _performs_a_capability(spec: dict, entity_id: str) -> bool:
    """Whether a capability names this entity as the thing that performs it (ADR-0021)."""
    for capability in spec.get("capabilities") or ():
        if isinstance(capability, dict) and str(capability.get("entity_id") or "") == entity_id:
            return True
    return False


def _presence_is_traced(spec: dict, entity_id: str) -> bool:
    """Whether this entity traces back to something the prompt asked for.

    Directly, by being the subject of an `exists` requirement -- or indirectly, by
    being `part_of` an entity that is.

    The indirect route exists because one described thing is often several built
    things. A prompt naming "a fence" once is satisfied by four fence segments, and
    demanding a separate requirement per segment collided with the rule that a
    requirement's `source_text` must appear VERBATIM in the prompt: three of the
    four could not be sourced, so there was no legal way to build a fence. Measured
    on a twelve-prompt corpus that collision was half of all traceability failures,
    and in every case the planner was DECOMPOSING described content rather than
    inventing new content.

    The check stays load-bearing. An entity that is neither a subject nor part of a
    covered one still fails, so a barbecue nobody mentioned has nothing to point at.
    The grouping is a claim the PLANNER makes and the spec records, which is what
    separates this from synthesising the missing requirements in our own code -- that
    would make the rule a tautology, since requirements derived from entities can
    never fail to cover entities.

    Chains are followed so a part of a part is covered, with a visited set because a
    spec is model-authored and a cycle would otherwise hang the validator.
    """
    covered = {
        item["subject"]
        for item in spec["requirements"]
        if item["predicate"] == "exists"
    }
    if entity_id in covered:
        return True
    parents = {
        relation["subject_id"]: relation["target_id"]
        for relation in spec.get("spatial_relations") or ()
        if relation.get("relation") == "part_of"
    }
    seen: set[str] = set()
    cursor = parents.get(entity_id)
    while cursor is not None and cursor not in seen:
        if cursor in covered:
            return True
        seen.add(cursor)
        cursor = parents.get(cursor)
    return False


def verify_requirement_traceability(
    spec: dict,
    world_plan: dict,
    behavior_plan: dict,
) -> dict:
    errors: list[dict] = []
    evidence_matrix: list[dict] = []
    entity_by_id = {entity["entity_id"]: entity for entity in spec["entities"]}
    world_entities = {
        entity["entity_id"] for entity in world_plan.get("entities", [])
    }
    graph_keys = {
        (graph["entity_id"], graph["capability_id"])
        for graph in behavior_plan.get("graphs", [])
    }

    requirement_ids = [item["requirement_id"] for item in spec["requirements"]]
    if len(requirement_ids) != len(set(requirement_ids)):
        errors.append({"code": "DUPLICATE_REQUIREMENT_ID"})

    for requirement in spec["requirements"]:
        requirement_id = requirement["requirement_id"]
        subject = requirement["subject"]
        references: list[str] = []
        if subject in entity_by_id:
            references.append(f"spec.entities:{subject}")
            if subject in world_entities:
                references.append(f"world_plan.entities:{subject}")
            else:
                errors.append(
                    {
                        "code": "REQUIRED_ENTITY_NOT_PLACED",
                        "requirement_id": requirement_id,
                        "entity_id": subject,
                    }
                )
            if requirement["predicate"] == "supports":
                for capability_id in str(requirement["target"]).split(","):
                    capability_id = capability_id.strip()
                    if (subject, capability_id) in graph_keys:
                        references.append(
                            f"behavior:{subject}:{capability_id}"
                        )
                    else:
                        errors.append(
                            {
                                "code": "REQUIRED_BEHAVIOR_GRAPH_MISSING",
                                "requirement_id": requirement_id,
                                "entity_id": subject,
                                "capability_id": capability_id,
                            }
                        )
        elif subject != "simulation" and subject not in _scatter_subjects(spec):
            errors.append(
                {
                    "code": "REQUIREMENT_SUBJECT_UNKNOWN",
                    "requirement_id": requirement_id,
                    "subject": subject,
                }
            )
        if not requirement["observable"].strip():
            errors.append(
                {
                    "code": "REQUIREMENT_NOT_OBSERVABLE",
                    "requirement_id": requirement_id,
                }
            )
        # Traceable to either thing the request actually said: the prompt in
        # the user's words, or the expanded description the system agreed with
        # them. Checking the prompt alone failed five requirements in a run
        # where the planner quoted the description faithfully -- "Red fire
        # hydrant" is not in the prompt, but it is not invention either, and the
        # expand stage is the reason the planner has those words at all.
        _sources = " ".join(
            text.lower()
            for text in (
                spec["request"]["prompt"],
                spec["request"].get("source_description") or "",
            )
        )
        if requirement["source_text"].lower() not in _sources:
            errors.append(
                {
                    "code": "REQUIREMENT_SOURCE_NOT_TRACEABLE",
                    "requirement_id": requirement_id,
                }
            )
        evidence_matrix.append(
            {
                "requirement_id": requirement_id,
                "responsible_validator": requirement["validator"],
                "references": references,
            }
        )

    for entity_id in entity_by_id:
        if entity_id == "ent_controlled_actor":
            predicates = {
                item["predicate"]
                for item in spec["requirements"]
                if item["subject"] == entity_id
            }
            if not ({"is", "exists"} & predicates):
                errors.append(
                    {
                        "code": "ACTOR_IDENTITY_REQUIREMENT_MISSING",
                        "entity_id": entity_id,
                    }
                )
            continue
        # An invisible thing cannot satisfy a requirement about being SEEN.
        #
        # Measured on the forest prompt, which blocked publication run after run on one
        # entity whose own spec reads:
        #
        #     role "logic_driver", semantic_type "system_entity",
        #     brief "Invisible logic entity driving ecosystem behaviors"
        #
        # The planner authors these to hold behaviour belonging to no visible object --
        # an ecosystem's weather response, a spawner, a scoring rule. Asking such a thing
        # to trace to a noun in the prompt asks the wrong question: it is not content
        # somebody described, it is the mechanism by which described content behaves.
        #
        # Not a free pass, and deliberately narrow. It applies only to an entity that
        # DECLARES itself logic and that a capability names as the performer (ADR-0021),
        # so it must be doing a job the spec records. An invented ornament calling itself
        # a controller still fails here, because no capability would name it.
        entity = entity_by_id[entity_id]
        if _is_disembodied(entity) and _performs_a_capability(spec, entity_id):
            continue
        if not _presence_is_traced(spec, entity_id):
            errors.append(
                {
                    "code": "ENTITY_PRESENCE_REQUIREMENT_MISSING",
                    "entity_id": entity_id,
                }
            )

    known_relation_ids = {*entity_by_id, *[zone["zone_id"] for zone in world_plan["zones"]]}
    for relation in spec["spatial_relations"]:
        if relation["subject_id"] not in entity_by_id:
            errors.append(
                {
                    "code": "SPATIAL_SUBJECT_UNKNOWN",
                    "entity_id": relation["subject_id"],
                }
            )
        if relation["target_id"] not in known_relation_ids:
            errors.append(
                {
                    "code": "SPATIAL_TARGET_UNKNOWN",
                    "entity_id": relation["target_id"],
                }
            )

    return {
        "status": "FAIL" if errors else "PASS",
        "errors": errors,
        "evidence": {
            "requirement_count": len(spec["requirements"]),
            "traceability_matrix": evidence_matrix,
        },
    }


def _environment_surface(spec: dict) -> list[str]:
    """Every field that legitimately answers "what place is this?".

    The check used to read `environment.semantic_type` alone, which made it a
    test of one naming choice rather than of whether the world matches the
    prompt. A run for "a forest ecosystem lesson" was named
    `temperate_deciduous_woodland_edge_learning_plot` and failed, because
    "forest" is not a substring of "woodland" -- and this is a MANDATORY gate,
    so a world that was exactly what the user asked for was refused
    publication. The same shape breaks wood/forest, jungle/rainforest and
    shop/retail_store.
    """
    environment = spec.get("environment") or {}
    surface = [
        str(environment.get("semantic_type") or ""),
        str(environment.get("terrain") or ""),
    ]
    surface += [
        str(zone.get("semantic_type") or "")
        for zone in (environment.get("zones") or [])
    ]
    # Requirement targets count. The forest run recorded
    # `requirements[0].target = "forest"` and an observable reading "The
    # simulation represents a forest environment" -- the planner had understood
    # the prompt and written it into the field this same critic validates
    # elsewhere. Reading only `semantic_type` made the gate a test of one naming
    # choice while the answer sat two fields away.
    surface += [
        str(requirement.get("target") or "")
        for requirement in (spec.get("requirements") or [])
    ]
    return [value.lower() for value in surface if value]


def _atom_is_present(atom_value: str, surface: list[str]) -> bool:
    """Literal containment across every field that names the place.

    Embedding similarity was tried here and measured, and it cannot do this
    job: scoring a prompt noun against a semantic type puts true and false
    pairs on top of each other. "reef" against "coral_atoll_lagoon" scores
    0.614 and should pass; "village" against "industrial_car_factory_floor"
    scores 0.627 and should fail. Comparing against the compound's parts
    instead of the whole raises every score and preserves the inversion. No
    threshold separates them, so any cutoff would be fitted to noise -- and a
    mandatory gate with an invented cutoff is worse than a brittle one.
    """
    return any(atom_value in value for value in surface)


def deterministic_independent_critique(
    spec: dict,
    world_plan: dict,
    behavior_plan: dict,
) -> dict:
    """A non-generative omission/contradiction critic used before model critique."""
    errors: list[dict] = []
    atoms = extract_observable_prompt_atoms(spec["request"]["prompt"])
    controlled = next(
        (
            entity
            for entity in spec["entities"]
            if entity["role"] == "controlled_agent"
        ),
        None,
    )
    for atom in atoms:
        if atom["kind"] == "actor" and (
            controlled is None
            or atom["value"] not in controlled["semantic_type"].lower()
        ):
            errors.append(
                {
                    "code": "PROMPT_ACTOR_OMITTED",
                    "atom": atom,
                    "actual": controlled["semantic_type"] if controlled else None,
                }
            )
        elif atom["kind"] == "environment" and not _atom_is_present(
            atom["value"], _environment_surface(spec)
        ):
            errors.append(
                {
                    "code": "PROMPT_ENVIRONMENT_OMITTED",
                    "atom": atom,
                    "actual": spec["environment"]["semantic_type"],
                    # What was actually searched, so a failure is arguable
                    # rather than mysterious: the reader can see whether the
                    # world really omitted the subject or merely named it
                    # differently everywhere the gate looked.
                    "searched": _environment_surface(spec),
                }
            )
        elif atom["kind"] == "action" and not any(
            requirement["predicate"] == "can_explore"
            for requirement in spec["requirements"]
        ):
            errors.append({"code": "PROMPT_ACTION_OMITTED", "atom": atom})
        elif atom["kind"] == "weather" and spec["environment"]["weather"] != atom["value"]:
            errors.append(
                {
                    "code": "PROMPT_WEATHER_CONTRADICTION",
                    "atom": atom,
                    "actual": spec["environment"]["weather"],
                }
            )
        elif atom["kind"] == "time" and spec["environment"]["time_of_day"] != atom["value"]:
            errors.append(
                {
                    "code": "PROMPT_TIME_CONTRADICTION",
                    "atom": atom,
                    "actual": spec["environment"]["time_of_day"],
                }
            )
    if len(world_plan["entities"]) != len(spec["entities"]):
        errors.append(
            {
                "code": "SPEC_WORLD_ENTITY_COUNT_DISAGREEMENT",
                "spec_count": len(spec["entities"]),
                "world_count": len(world_plan["entities"]),
            }
        )
    compiled_pairs = {
        (graph["entity_id"], graph["capability_id"])
        for graph in behavior_plan["graphs"]
    }
    for entity in spec["entities"]:
        for capability_id in entity["capabilities"]:
            if (entity["entity_id"], capability_id) not in compiled_pairs:
                errors.append(
                    {
                        "code": "CAPABILITY_BEHAVIOR_OMITTED",
                        "entity_id": entity["entity_id"],
                        "capability_id": capability_id,
                    }
                )
    # A naming disagreement is disclosed, not published-blocking.
    #
    # PROMPT_ENVIRONMENT_OMITTED fires when the prompt's noun appears in none of
    # the fields that name the place. That is worth telling the user, but it
    # cannot decide correctness: a run for "a forest ecosystem lesson" named its
    # world `temperate_deciduous_woodland_edge_learning_plot`, which is exactly
    # what was asked for, and the gate refused to publish it. Embedding
    # similarity was measured as an alternative and cannot separate a synonym
    # from an unrelated place (see `_atom_is_present`).
    #
    # The failure this check was reaching for -- a stock world generated for a
    # prompt it does not match -- is already caught structurally by the lineage
    # gate, which refuses any artifact the planning model did not author. A
    # lexical proxy should not also hold a veto that the real guard already has.
    disclosed = [error for error in errors if error["code"] == "PROMPT_ENVIRONMENT_OMITTED"]
    blocking = [error for error in errors if error["code"] != "PROMPT_ENVIRONMENT_OMITTED"]
    return {
        "status": "FAIL" if blocking else "PASS",
        "errors": blocking,
        "evidence": {
            "prompt_atoms": atoms,
            # Kept in the evidence rather than dropped: the reader can still see
            # that the world was named unlike the prompt, and decide.
            "naming_disclosures": disclosed,
        },
    }

