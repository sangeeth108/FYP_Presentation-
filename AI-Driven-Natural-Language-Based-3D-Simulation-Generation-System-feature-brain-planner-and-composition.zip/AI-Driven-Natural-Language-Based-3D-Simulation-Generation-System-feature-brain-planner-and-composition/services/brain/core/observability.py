"""PII-safe request correlation, metrics, and production security headers."""

from __future__ import annotations

import json
import logging
import re
import threading
import time
import uuid
from collections import defaultdict

from fastapi import FastAPI, Request
from fastapi.responses import PlainTextResponse

from core.config import get_settings

log = logging.getLogger("serendib.http")
_SAFE_ID = re.compile(r"^[A-Za-z0-9_.:-]{8,128}$")
_LOCK = threading.Lock()
_REQUESTS: dict[tuple[str, str, int], int] = defaultdict(int)
_DURATION_SUM: dict[tuple[str, str], float] = defaultdict(float)
_IN_FLIGHT = 0


def _correlation_id(value: str | None) -> str:
    if value and _SAFE_ID.fullmatch(value):
        return value
    return str(uuid.uuid4())


def _route_label(request: Request) -> str:
    """The low-cardinality ROUTE TEMPLATE, e.g. "/api/v1/jobs/{job_id}".

    Version-robust: Starlette <=1.0 exposed the full path on scope["route"].path,
    but >=1.1 (include_router no longer flattens sub-routers) exposes only the
    router-relative path there (e.g. "/simulations", missing the "/api/v1" prefix).
    Reconstruct the full template from the request path with path-param values
    masked back to their names — never the raw values (ids), which would leak PII
    and explode metric cardinality.
    """
    if request.scope.get("route") is None:
        return "unmatched"
    path = request.url.path
    for name, value in (request.scope.get("path_params") or {}).items():
        path = path.replace(str(value), "{" + name + "}", 1)
    return path or "unmatched"


def configure_request_controls(app: FastAPI) -> None:
    @app.middleware("http")
    async def request_controls(request: Request, call_next):
        global _IN_FLIGHT
        settings = get_settings()
        correlation_id = _correlation_id(request.headers.get("x-correlation-id"))
        request.state.correlation_id = correlation_id
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                too_large = int(content_length) > settings.max_request_bytes
            except ValueError:
                too_large = True
            if too_large:
                return PlainTextResponse(
                    "request body too large",
                    status_code=413,
                    headers={"X-Correlation-ID": correlation_id},
                )

        started = time.perf_counter()
        with _LOCK:
            _IN_FLIGHT += 1
        status = 500
        try:
            response = await call_next(request)
            status = response.status_code
        finally:
            elapsed = time.perf_counter() - started
            route = _route_label(request)
            with _LOCK:
                _IN_FLIGHT = max(0, _IN_FLIGHT - 1)
                _REQUESTS[(request.method, route, status)] += 1
                _DURATION_SUM[(request.method, route)] += elapsed
            # Never log query strings, request bodies, prompts, credentials,
            # asset names, or user identifiers.
            log.info(
                json.dumps(
                    {
                        "event": "http_request",
                        "correlation_id": correlation_id,
                        "method": request.method,
                        "route": route,
                        "status": status,
                        "duration_ms": round(elapsed * 1000, 2),
                    },
                    separators=(",", ":"),
                )
            )

        response.headers["X-Correlation-ID"] = correlation_id
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; "
            # blob: is granted to img-src ONLY: the engine sets the browser window
            # icon from a blob URL it builds in memory. script-src never gets it, so
            # no code can be loaded or eval'd from a blob.
            "connect-src 'self'; img-src 'self' data: blob:; "
            "style-src 'self' 'unsafe-inline'; "
            "frame-ancestors 'self'"
            if request.url.path.startswith("/artifacts/")
            else "default-src 'none'; frame-ancestors 'none'"
        )
        if settings.promptplay_env == "production":
            response.headers["Strict-Transport-Security"] = (
                "max-age=31536000; includeSubDomains"
            )
        return response


def prometheus_text() -> str:
    """Dependency-free Prometheus exposition; collectors aggregate replicas."""
    lines = [
        "# HELP serendib_http_requests_total HTTP requests by route and status.",
        "# TYPE serendib_http_requests_total counter",
    ]
    with _LOCK:
        requests = dict(_REQUESTS)
        durations = dict(_DURATION_SUM)
        in_flight = _IN_FLIGHT
    for (method, route, status), count in sorted(requests.items()):
        labels = f'method="{method}",route="{route}",status="{status}"'
        lines.append(f"serendib_http_requests_total{{{labels}}} {count}")
    lines.extend(
        [
            "# HELP serendib_http_request_duration_seconds_sum Total request duration.",
            "# TYPE serendib_http_request_duration_seconds_sum counter",
        ]
    )
    for (method, route), value in sorted(durations.items()):
        labels = f'method="{method}",route="{route}"'
        lines.append(
            f"serendib_http_request_duration_seconds_sum{{{labels}}} {value:.6f}"
        )
    lines.extend(
        [
            "# HELP serendib_http_requests_in_flight Current in-flight requests.",
            "# TYPE serendib_http_requests_in_flight gauge",
            f"serendib_http_requests_in_flight {in_flight}",
            "",
        ]
    )
    return "\n".join(lines)
