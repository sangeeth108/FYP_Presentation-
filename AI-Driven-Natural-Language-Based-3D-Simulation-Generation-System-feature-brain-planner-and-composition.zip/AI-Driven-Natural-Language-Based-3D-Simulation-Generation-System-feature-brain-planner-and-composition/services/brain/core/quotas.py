"""Fail-closed per-tenant generation admission and idempotent lease release."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy.orm import Session

from core.ids import new_resource_id
from core.models import GenerationLease, GenerationRun, TenantQuota

# A slot is reserved on submit and released on completion. If a worker/host dies
# mid-run the release never fires and the slot LEAKS — the tenant then 429s
# forever on a phantom "3/3 running". A lease is stale when its run is terminal
# or missing, or when it has sat far longer than any real generation could take
# (generation is minutes, not hours). Releasing stale leases + recomputing the
# counter from the leases that are ACTUALLY still active makes the quota
# self-healing instead of a one-way ratchet.
STALE_LEASE_SECONDS = 1800  # 30 min — well past a real generation, catches crashes


def _is_terminal_run(run: GenerationRun | None) -> bool:
    return run is None or run.state == "completed" or run.state.startswith("failed_")


class QuotaExceeded(RuntimeError):
    def __init__(self, code: str, message: str, retry_after_seconds: int) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.retry_after_seconds = retry_after_seconds


def _month_start(now: datetime) -> datetime:
    return datetime(now.year, now.month, 1, tzinfo=UTC)


def _as_utc(value: datetime) -> datetime:
    # SQLite drops timezone offsets even for timezone=True columns. Production
    # PostgreSQL returns aware values; normalize both before comparing windows.
    return value.replace(tzinfo=UTC) if value.tzinfo is None else value.astimezone(UTC)


def _release_stale_leases(db: Session, tenant_id: str, now: datetime) -> int:
    """Release this tenant's leaked leases (terminal/missing run, or too old) and
    return how many. Called before admission so a crash-leaked slot self-heals on
    the next submit rather than 429-ing forever."""
    cutoff = now - timedelta(seconds=STALE_LEASE_SECONDS)
    active = (
        db.query(GenerationLease)
        .filter_by(tenant_id=tenant_id, state="active")
        .with_for_update()
        .all()
    )
    released = 0
    for lease in active:
        run = db.query(GenerationRun).filter_by(id=lease.run_id).one_or_none()
        if _is_terminal_run(run) or _as_utc(lease.reserved_at) < cutoff:
            lease.state = "released"
            lease.released_at = now
            released += 1
    if released:
        db.flush()
    return released


def _sync_active_count(db: Session, quota: TenantQuota) -> None:
    """Recompute active_generations from leases that are ACTUALLY active — the
    authoritative source of truth, so the counter can never drift or leak."""
    quota.active_generations = (
        db.query(GenerationLease)
        .filter_by(tenant_id=quota.tenant_id, state="active")
        .count()
    )


def reconcile_generation_quotas(db: Session) -> int:
    """Release every tenant's stale leases and re-sync counters. Run on worker
    startup so a crash mid-run cannot wedge the quota. Returns leases released."""
    now = datetime.now(UTC)
    tenant_ids = [q.tenant_id for q in db.query(TenantQuota).all()]
    released = 0
    for tenant_id in tenant_ids:
        released += _release_stale_leases(db, tenant_id, now)
    for quota in db.query(TenantQuota).all():
        _sync_active_count(db, quota)
        quota.updated_at = now
    db.flush()
    return released


def reserve_generation_slot(db: Session, tenant_id: str, run_id: str) -> TenantQuota:
    now = datetime.now(UTC)
    quota = (
        db.query(TenantQuota)
        .filter_by(tenant_id=tenant_id)
        .with_for_update()
        .one_or_none()
    )
    if quota is None:
        quota = TenantQuota(
            tenant_id=tenant_id,
            max_concurrent_generations=3,
            monthly_generation_limit=100,
            active_generations=0,
            window_started_at=_month_start(now),
            window_generations=0,
            gpu_seconds_limit=36_000,
            gpu_seconds_used=0,
        )
        db.add(quota)
        db.flush()
    if _as_utc(quota.window_started_at) < _month_start(now):
        quota.window_started_at = _month_start(now)
        quota.window_generations = 0
        quota.gpu_seconds_used = 0
    # Self-heal before admission: drop any leaked slots (a crashed run's lease that
    # never released) and recompute the live count, so a stale reservation can't
    # 429 a tenant forever.
    _release_stale_leases(db, tenant_id, now)
    _sync_active_count(db, quota)
    if quota.active_generations >= quota.max_concurrent_generations:
        raise QuotaExceeded(
            "CONCURRENT_GENERATION_LIMIT",
            "tenant concurrent generation limit reached",
            30,
        )
    if quota.window_generations >= quota.monthly_generation_limit:
        raise QuotaExceeded(
            "MONTHLY_GENERATION_LIMIT",
            "tenant monthly generation limit reached",
            86_400,
        )
    quota.active_generations += 1
    quota.window_generations += 1
    quota.updated_at = now
    db.add(
        GenerationLease(
            id=new_resource_id("lease"),
            run_id=run_id,
            tenant_id=tenant_id,
            state="active",
            reserved_at=now,
        )
    )
    db.flush()
    return quota


def release_generation_slot(db: Session, run_id: str) -> bool:
    lease = (
        db.query(GenerationLease)
        .filter_by(run_id=run_id)
        .with_for_update()
        .one_or_none()
    )
    if lease is None or lease.state != "active":
        return False
    quota = (
        db.query(TenantQuota)
        .filter_by(tenant_id=lease.tenant_id)
        .with_for_update()
        .one_or_none()
    )
    if quota is not None:
        quota.active_generations = max(0, quota.active_generations - 1)
        quota.updated_at = datetime.now(UTC)
    lease.state = "released"
    lease.released_at = datetime.now(UTC)
    return True
