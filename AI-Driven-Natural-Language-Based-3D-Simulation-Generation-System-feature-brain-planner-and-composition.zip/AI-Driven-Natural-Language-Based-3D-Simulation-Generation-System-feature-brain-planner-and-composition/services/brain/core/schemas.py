"""Pydantic request/response models for the API (see docs/API_DOCUMENTATION.md)."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, model_validator

# Allowlists mirror contracts/game_spec.schema.json (meta.genre / meta.camera).
Genre = Literal[
    "topdown_survival_escape_3d",
    "arena_combat_3d",
    "collect_explore_3d",
    "dungeon_crawl_3d",
]
Camera = Literal["third_person", "top_down_3d", "isometric_3d"]


class CreateGameOptions(BaseModel):
    genre: Genre | None = None
    camera: Camera | None = None


class CreateGameRequest(BaseModel):
    prompt: str = Field(min_length=8, max_length=2000)
    # Bounded to signed 32-bit: the seed column is a PostgreSQL INTEGER, so an
    # out-of-range client-supplied seed must 422 at the boundary rather than
    # crashing the insert.
    seed: int | None = Field(default=None, ge=0, le=2_147_483_647)
    options: CreateGameOptions | None = None


class CreateGameResponse(BaseModel):
    game_id: str
    job_id: str


class EditPreviewRequest(BaseModel):
    """Serendib Assist: a plain-language edit against a game the dock already
    holds (its downloaded project's spec)."""

    spec: dict
    instruction: str = Field(min_length=1, max_length=500)


class EditPreviewResponse(BaseModel):
    changed: list[str]  # human-readable, shown in the dock
    rejected: list[str]  # asked-for but unsupported in v1
    valid: bool  # the edited spec is still schema-valid (safe to re-export)
    spec: dict  # the edited spec (the dock re-exports this)


class PhaseInfo(BaseModel):
    stage: str
    state: str


class ArtifactInfo(BaseModel):
    kind: str
    url: str | None = None


class JobStatusResponse(BaseModel):
    game_id: str
    state: str
    detail: dict = Field(default_factory=dict)
    phases: list[PhaseInfo] = Field(default_factory=list)
    artifacts: list[ArtifactInfo] = Field(default_factory=list)


TrainingScope = Literal["global", "tenant_private"]
TrainingDataCategory = Literal["prompt_spec", "telemetry", "assets"]


class ConsentChoice(BaseModel):
    scope: TrainingScope
    data_category: TrainingDataCategory
    granted: bool


class TrainingConsentUpdate(BaseModel):
    disclosure_version: str = Field(min_length=1, max_length=32)
    locale: str = Field(default="en", min_length=2, max_length=16)
    choices: list[ConsentChoice] = Field(min_length=1, max_length=6)


class ConsentStatusItem(BaseModel):
    scope: TrainingScope
    data_category: TrainingDataCategory
    subject_granted: bool
    guardian_granted: bool | None = None
    effective: bool


class TrainingConsentStatus(BaseModel):
    user_id: str
    age_band: str
    guardian_required: bool
    choices: list[ConsentStatusItem]


class GuardianRelationshipCreate(BaseModel):
    minor_user_id: str = Field(min_length=1, max_length=64)
    verification_reference: str = Field(min_length=8, max_length=255)


class AgeAssuranceReviewRequest(BaseModel):
    age_band: Literal["under_13", "13_15", "16_17", "adult"]
    provider: str = Field(min_length=2, max_length=80)
    evidence_reference: str = Field(min_length=8, max_length=255)
    expires_at: datetime | None = None


class GuardianRelationshipResponse(BaseModel):
    relationship_id: str
    status: str


class FeedbackRequest(BaseModel):
    simulation_id: str | None = Field(default=None, max_length=64)
    kind: Literal[
        "rating",
        "requirement_correction",
        "asset_choice",
        "placement_correction",
        "pairwise_preference",
    ]
    rating: int | None = Field(default=None, ge=1, le=5)
    payload: dict = Field(default_factory=dict)
    rights_attested: bool = False
    learning_target: Literal["asset_ranker", "placement_ranker"] | None = None

    @model_validator(mode="after")
    def validate_learning_target(self):
        expected = {
            "asset_choice": "asset_ranker",
            "placement_correction": "placement_ranker",
        }.get(self.kind)
        if expected and self.learning_target not in {None, expected}:
            raise ValueError(f"{self.kind} can train only {expected}")
        if self.kind == "pairwise_preference" and self.learning_target is None:
            raise ValueError("pairwise_preference requires learning_target")
        return self


class FeedbackResponse(BaseModel):
    feedback_id: str
    training_status: str


class UsageEventRequest(BaseModel):
    simulation_id: str = Field(min_length=1, max_length=64)
    event_type: Literal[
        "navigation_reached",
        "interaction_succeeded",
        "interaction_failed",
        "simulation_completed",
        "placement_adjusted",
    ]
    payload: dict = Field(default_factory=dict)


class UsageEventResponse(BaseModel):
    usage_event_id: str
    training_status: str


class DataSubjectRequestResponse(BaseModel):
    request_id: str
    request_type: Literal["export", "delete"]
    state: str
    result: dict | None = None


class CreateSimulationRequest(BaseModel):
    prompt: str = Field(min_length=8, max_length=4000)
    size_profile: Literal["auto", "small", "medium"] = "auto"
    target_platforms: list[Literal["web", "desktop"]] = Field(
        default_factory=lambda: ["web", "desktop"], min_length=1, max_length=2
    )
    # Bounded to signed 32-bit: the seed column is a PostgreSQL INTEGER, so an
    # out-of-range client-supplied seed must 422 at the boundary rather than
    # crashing the insert.
    seed: int | None = Field(default=None, ge=0, le=2_147_483_647)
    domain_constraints: dict = Field(default_factory=dict)
    training_rights_attested: bool = False


class CreateSimulationResponse(BaseModel):
    simulation_id: str
    run_id: str


class SimulationRunResponse(BaseModel):
    run_id: str
    simulation_id: str
    state: str
    stage: str
    detail: dict = Field(default_factory=dict)
    repair_attempts: int = 0
    max_repair_attempts: int = 3


class StageSummaryResponse(BaseModel):
    """One entry in the inspector's stage rail (no payload — that is fetched separately)."""

    stage: str
    ordinal: int
    status: str
    summary: dict = Field(default_factory=dict)
    errors: list = Field(default_factory=list)
    model_id: str | None = None
    duration_ms: int | None = None
    edited: bool = False


class StageListResponse(BaseModel):
    run_id: str
    stages: list[StageSummaryResponse] = Field(default_factory=list)


class StagePayloadResponse(StageSummaryResponse):
    """A single stage including its full inspectable output."""

    payload: dict = Field(default_factory=dict)


class StageEditRequest(BaseModel):
    """A human-corrected stage payload, to re-run the pipeline downstream from."""

    payload: dict


class SimulationResponse(BaseModel):
    simulation_id: str
    title: str
    prompt: str
    size_profile: str
    target_platforms: list[str]
    status: str
    current_run_id: str | None = None
    spec: dict | None = None
    world_plan: dict | None = None
    artifacts: list[ArtifactInfo] = Field(default_factory=list)
    approximations: list[dict] = Field(default_factory=list)


class SimulationEditRequest(BaseModel):
    instruction: str = Field(min_length=1, max_length=1000)


class SimulationReportResponse(BaseModel):
    simulation_id: str
    run_id: str | None
    requirements: list[dict] = Field(default_factory=list)
    world_plan_hash: str | None = None
    validation: list[dict] = Field(default_factory=list)
    approximations: list[dict] = Field(default_factory=list)
    capability_gaps: list[dict] = Field(default_factory=list)


class ModelRouteOverrideRequest(BaseModel):
    model_id: str = Field(min_length=1, max_length=160)
    scope: Literal["tenant", "global"] = "tenant"
    enabled: bool = True


class TrainingEligibilityReviewRequest(BaseModel):
    moderation_status: Literal["approved", "rejected"]
    quality_status: Literal["approved", "rejected"]


class ContentRightsReviewRequest(BaseModel):
    approved: bool
    rights_basis: Literal[
        "user_attestation_verified",
        "contract",
        "licence",
        "first_party",
    ]
    licence_id: str | None = Field(default=None, max_length=120)


class DatasetBuildRequest(BaseModel):
    scope: TrainingScope
    target: Literal["planner", "asset_ranker", "placement_ranker"]


class TrainingCandidateRequest(BaseModel):
    dataset_version_id: str = Field(min_length=1, max_length=64)
    base_model: str = Field(min_length=1, max_length=160)
    config: dict = Field(default_factory=dict)
    monthly_window: bool = False


class ModelCandidateRequest(BaseModel):
    training_run_id: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=1, max_length=160)
    licence_id: str = Field(min_length=1, max_length=120)
    model_card: dict


class ModelEvaluationAttestationRequest(BaseModel):
    evaluator: str = Field(min_length=3, max_length=80)
    evaluator_version: str = Field(min_length=1, max_length=64)
    benchmark_digest: str = Field(min_length=16, max_length=128)
    artifact_digest: str = Field(min_length=16, max_length=128)
    metrics: dict
    signature: str = Field(min_length=64, max_length=128)


class ModelPromotionRequest(BaseModel):
    target_state: Literal[
        "EVALUATED",
        "SHADOW",
        "CANARY",
        "PRODUCTION",
        "RETIRED",
        "REJECTED",
        "QUARANTINED",
    ]
    evaluation_id: str | None = Field(default=None, max_length=64)


class CanaryAdvanceRequest(BaseModel):
    evaluation_id: str = Field(min_length=1, max_length=64)


class ResearchExclusionRequest(BaseModel):
    prompt: str = Field(min_length=8, max_length=4000)
    exclusion_type: Literal["benchmark", "user_study", "research_holdout"]
    purpose: str = Field(min_length=3, max_length=120)
    study_id: str | None = Field(default=None, max_length=80)
