"""Immutable security and governance audit helpers."""

from __future__ import annotations

from sqlalchemy.orm import Session

from core.ids import new_resource_id
from core.models import AuditEvent
from core.security import Principal


def record_audit(
    db: Session,
    principal: Principal,
    action: str,
    resource_type: str,
    resource_id: str | None,
    detail: dict | None = None,
) -> AuditEvent:
    event = AuditEvent(
        id=new_resource_id("audit"),
        tenant_id=principal.tenant_id,
        actor_user_id=principal.user_id,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        detail=detail or {},
    )
    db.add(event)
    return event
