"""Application settings, loaded from environment / .env (see repo-root .env.example)."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

# Anchored to the repo root, NOT the working directory. A CWD-relative ".env"
# means the API, the Celery worker and the benchmark each load different
# settings depending on where they were launched from — which silently turned
# the whole LLM brain off in a benchmark run (wrong base_url -> connection
# refused -> quiet fallback to the rule parser, every game still "passing").
ENV_FILE = Path(__file__).resolve().parents[3] / ".env"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=ENV_FILE, env_file_encoding="utf-8", extra="ignore"
    )

    promptplay_env: str = "development"

    # Single Postgres driver (psycopg v3), used synchronously by API + Celery + Alembic.
    database_url: str = "postgresql+psycopg://promptplay:change-me@localhost:5432/promptplay"

    redis_url: str = "redis://localhost:6379/0"
    celery_broker_url: str = "redis://localhost:6379/1"
    celery_result_backend: str = "redis://localhost:6379/2"

    cors_origins: str = "http://localhost:3000"
    api_secret_key: str = "change-me"
    auth_required: bool = False
    oidc_issuer: str = ""
    oidc_audience: str = ""
    oidc_jwks_url: str = ""
    oidc_algorithms: str = "RS256"
    default_tenant_id: str = "tenant_dev"
    default_user_id: str = "user_dev"
    default_residency_region: str = "local"
    training_pseudonym_key: str = ""
    production_training_enabled: bool = False
    training_runner_enabled: bool = False
    training_dataset_kms_key_id: str = ""
    enterprise_adapter_kms_key_id: str = ""
    model_evaluation_signing_key: str = ""
    kms_region: str = ""
    kms_endpoint_url: str = ""
    training_work_dir: str = "./artifacts/training"
    training_plaintext_dir: str = "/run/serendib-training"
    training_subprocess_timeout_seconds: int = 86_400
    max_request_bytes: int = 2_000_000
    max_upload_bytes: int = 100_000_000

    # Set true in tests so Celery runs tasks inline (no broker needed).
    celery_task_always_eager: bool = False

    # --- P2 planner (Ollama structured outputs; falls back to rule-based S1) ---
    llm_enabled: bool = False
    llm_base_url: str = "http://localhost:11434"
    llm_model: str = "qwen3.6:27b"  # pinned planner (DECISION_LOG #2), Q4 fits the 32GB 5090
    llm_model_digest: str = ""
    # A cold 17 GB load costs ~50s; the planner also sends keep_alive=30m so
    # only the first request after a long idle pays it. Under this, the call
    # times out and the rule-based parser takes over (never a hard failure).
    llm_timeout_seconds: float = 180.0
    # Stage 1 (expand): describe the place in prose before formalising it, so
    # sizes and densities are reasoned about rather than guessed under schema
    # pressure. A runtime toggle because it is an ablation arm, not a fixture:
    # the dissertation needs both halves reproducible on the same build. Costs
    # roughly one extra planner call (~50 s) per generation.
    expand_enabled: bool = True
    # Stage 2 (extract): read the prose into an explicit few-vs-many split
    # before the spec is written. Only runs when expand did; a separate arm
    # so the ablation can attribute any change to the right stage.
    extract_enabled: bool = True
    # Stage 3 (deliberate): critique the reading and revise it. The most
    # expensive arm (up to two rounds x two calls) and the one most able to
    # do harm, so it is measured like the others and can be switched off
    # without touching the rest of the chain.
    deliberate_enabled: bool = True
    critic_enabled: bool = False
    critic_base_url: str = "http://localhost:11434"
    critic_model: str = ""
    critic_model_digest: str = ""
    critic_timeout_seconds: float = 180.0
    vision_enabled: bool = False
    vision_base_url: str = "http://localhost:11434"
    vision_model: str = ""
    vision_model_digest: str = ""
    vision_timeout_seconds: float = 180.0
    # RAG over design notes (bge-m3 via the same Ollama). Ablation D toggle:
    # C = rag_enabled false, D = true. Falls back to keyword scoring if the
    # embedder is unavailable, so it is never a hard dependency.
    rag_enabled: bool = True

    # --- P3 asset farm (S5 generation tier) --------------------------------
    # OFF by default: the curated CC0 kit ships until the GPU farm is set up
    # (docs/ASSET_FARM_SETUP.md). "mock" = deterministic placeholder (tests/dev),
    # "gpu" = the real SDXL -> TRELLIS -> Blender pipeline. A misbehaving backend
    # can never break a game: the resolver falls back to curated on any failure.
    asset_gen_enabled: bool = False
    # "mock" | "local" (in-process SDXL+TripoSR) | "gpu" (ComfyUI+WSL TRELLIS)
    asset_gen_backend: str = "mock"
    # Hunyuan3D-2.1 shape model. Geometry only: the texture half needs a custom
    # CUDA rasteriser that does not build on this toolchain, so meshes arrive
    # untextured and carry an assigned material. Better geometry than TripoSR,
    # no colour where TripoSR had poor colour -- an honest trade, not a
    # uniform upgrade.
    hunyuan3d_checkpoint_dir: str = ""
    hunyuan3d_package_dir: str = ""
    comfyui_base_url: str = "http://localhost:8188"  # the gpu backend's SDXL host
    blender_bin: str = ""  # full path to blender.exe (it is often not on the
    # subprocess PATH); empty = the gpu backend's default "blender"

    # Sound generation is a SEPARATE switch from mesh generation: Stable Audio and
    # TRELLIS are different models that cannot be co-resident in 32 GB, so they are
    # enabled and sequenced independently. OFF -> the curated CC0 sound sets ship.
    audio_gen_enabled: bool = False
    audio_gen_backend: str = "mock"  # "mock" | "gpu"

    # --- Cloudflare R2 artifact storage (P3 hybrid deploy) -----------------
    # OFF by default: builds publish locally and are served at /artifacts. When
    # configured (an R2 bucket + $0-egress public base URL), the worker also
    # uploads the web build + downloadable project and records shareable URLs.
    # Secrets live in the environment / a vault — NEVER in the repo (§13).
    r2_enabled: bool = False
    r2_endpoint_url: str = ""  # https://<account>.r2.cloudflarestorage.com
    r2_bucket: str = ""
    r2_access_key_id: str = ""
    r2_secret_access_key: str = ""
    # Authenticated artifact gateway/CDN prefix. The bucket itself stays private.
    artifact_gateway_base_url: str = ""
    # Deprecated development-only fallback; production validation rejects it.
    r2_public_base_url: str = ""

    # --- P1 pipeline (S2-stub spec -> S4 PCG -> optional S6/S7 export) ---
    spec_path: str = ""  # empty = repo contracts/examples/golden_game.spec.json
    templates_dir: str = ""  # empty = repo engine/templates
    godot_bin: str = ""  # set to the pinned Serendib 4.6.3 binary to enable export
    desktop_export_platform: str = "Windows Desktop"
    playwright_browser_bin: str = ""
    # Published builds, served at /artifacts. Anchored to the repository root
    # rather than the working directory: every consumer calls
    # `Path(artifacts_dir).resolve()`, so a bare "./artifacts" meant the API and
    # the worker each wrote to whatever directory they happened to be launched
    # from. Both are normally started in services/brain, so it worked by
    # coincidence and left two artifact trees behind -- and a job could report
    # `completed` with a play URL the server could not serve, because the
    # publisher and the static mount had resolved different paths.
    artifacts_dir: str = str(ENV_FILE.parent / "artifacts")

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def oidc_algorithms_list(self) -> list[str]:
        return [a.strip() for a in self.oidc_algorithms.split(",") if a.strip()]

    def validate_production(self) -> None:
        if self.promptplay_env != "production":
            return
        missing = []
        if self.api_secret_key == "change-me" or len(self.api_secret_key) < 32:
            missing.append("API_SECRET_KEY")
        if not self.oidc_issuer:
            missing.append("OIDC_ISSUER")
        if not self.oidc_audience:
            missing.append("OIDC_AUDIENCE")
        if not self.oidc_jwks_url:
            missing.append("OIDC_JWKS_URL")
        if len(self.training_pseudonym_key) < 32:
            missing.append("TRAINING_PSEUDONYM_KEY")
        if not self.auth_required:
            missing.append("AUTH_REQUIRED=true")
        if self.llm_enabled and len(self.llm_model_digest) < 32:
            missing.append("LLM_MODEL_DIGEST")
        if not self.critic_enabled or not self.critic_model:
            missing.append("CRITIC_ENABLED=true and CRITIC_MODEL")
        elif len(self.critic_model_digest) < 32:
            missing.append("CRITIC_MODEL_DIGEST")
        if not self.vision_enabled or not self.vision_model:
            missing.append("VISION_ENABLED=true and VISION_MODEL")
        elif len(self.vision_model_digest) < 32:
            missing.append("VISION_MODEL_DIGEST")
        if not self.r2_enabled:
            missing.append("R2_ENABLED=true")
        for name, value in (
            ("R2_ENDPOINT_URL", self.r2_endpoint_url),
            ("R2_BUCKET", self.r2_bucket),
            ("R2_ACCESS_KEY_ID", self.r2_access_key_id),
            ("R2_SECRET_ACCESS_KEY", self.r2_secret_access_key),
            ("ARTIFACT_GATEWAY_BASE_URL", self.artifact_gateway_base_url),
            ("GODOT_BIN", self.godot_bin),
        ):
            if not value:
                missing.append(name)
        if any(
            origin == "*" or "localhost" in origin
            for origin in self.cors_origins_list
        ):
            missing.append("production CORS_ORIGINS")
        if self.r2_public_base_url:
            missing.append("R2_PUBLIC_BASE_URL must be empty (private bucket required)")
        if self.production_training_enabled:
            if not self.training_runner_enabled:
                missing.append("TRAINING_RUNNER_ENABLED=true")
            if not self.training_dataset_kms_key_id:
                missing.append("TRAINING_DATASET_KMS_KEY_ID")
            if not self.enterprise_adapter_kms_key_id:
                missing.append("ENTERPRISE_ADAPTER_KMS_KEY_ID")
            if len(self.model_evaluation_signing_key) < 32:
                missing.append("MODEL_EVALUATION_SIGNING_KEY")
            if not self.kms_region:
                missing.append("KMS_REGION")
            plaintext = Path(self.training_plaintext_dir)
            if not plaintext.is_absolute() or Path("/run") not in plaintext.parents:
                missing.append("TRAINING_PLAINTEXT_DIR must be under a tmpfs-mounted /run")
        if missing:
            raise RuntimeError(
                "production security configuration is incomplete: " + ", ".join(missing)
            )


@lru_cache
def get_settings() -> Settings:
    return Settings()
