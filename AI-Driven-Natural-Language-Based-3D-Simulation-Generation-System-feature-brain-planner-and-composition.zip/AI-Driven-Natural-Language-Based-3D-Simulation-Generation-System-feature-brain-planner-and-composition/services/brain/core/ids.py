"""Identifier helpers. game_id must match the schema pattern ^g3d_[a-z0-9_]+_[a-f0-9]{8}$."""

from __future__ import annotations

import re
import secrets
import uuid

_slug_re = re.compile(r"[^a-z0-9]+")


def slugify(text: str, maxlen: int = 24) -> str:
    slug = _slug_re.sub("_", text.lower().strip()).strip("_")
    slug = slug[:maxlen].strip("_")
    return slug or "game"


def new_game_id(seed_text: str) -> str:
    return f"g3d_{slugify(seed_text)}_{secrets.token_hex(4)}"


def new_simulation_id(seed_text: str) -> str:
    return f"sim_{slugify(seed_text)}_{secrets.token_hex(4)}"


def new_job_id() -> str:
    return str(uuid.uuid4())


def new_resource_id(prefix: str) -> str:
    """Opaque, sortable-enough identifier for production-owned records."""
    safe_prefix = slugify(prefix, maxlen=20)
    return f"{safe_prefix}_{uuid.uuid4().hex}"
