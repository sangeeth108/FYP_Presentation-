"""Recording each pipeline stage so a run can be inspected step by step.

The run's `detail` blob only carried the final summary, so when a generation came
out wrong there was no way to see WHERE it went wrong — you could not look at what
the brain decided before the engine stage ran. Every stage now writes its real
output here, which is what makes the inspector possible: pause after a stage, read
its JSON, edit it, and re-run downstream from the edit.

Recording is best-effort by design (rule: telemetry must never cost a build). A
failure to file the paperwork must not fail a generation that otherwise succeeded.
"""

from __future__ import annotations

import logging

from core import db
from core.ids import new_resource_id
from core.models import StageArtifact

log = logging.getLogger(__name__)

# Canonical order. The inspector renders the rail from this, so a stage that is
# not listed here simply appends after the known ones rather than disappearing.
STAGE_ORDER: tuple[str, ...] = (
    "expand",
    "extract",
    "deliberate",
    "scene_spec",
    "assets",
    "layout",
    "materialize",
    "verify",
    "publish",
)


def stage_ordinal(stage: str) -> int:
    try:
        return STAGE_ORDER.index(stage)
    except ValueError:
        return len(STAGE_ORDER)


def record_stage(
    run_id: str,
    stage: str,
    *,
    status: str,
    payload: dict | None = None,
    summary: dict | None = None,
    errors: list | None = None,
    model_id: str | None = None,
    duration_ms: int | None = None,
) -> None:
    """Upsert one stage's output for a run.

    Re-running a stage overwrites it in place (one row per run+stage), so the
    inspector always shows the current truth for that step rather than a history
    the reader has to disambiguate. `edited` is deliberately NOT cleared here: a
    human override stays flagged even after the stage is recomputed.
    """
    try:
        with db.session_scope() as session:
            existing = (
                session.query(StageArtifact)
                .filter_by(run_id=run_id, stage=stage)
                .one_or_none()
            )
            if existing is None:
                session.add(
                    StageArtifact(
                        id=new_resource_id("stage"),
                        run_id=run_id,
                        stage=stage,
                        ordinal=stage_ordinal(stage),
                        status=status,
                        payload=payload or {},
                        summary=summary or {},
                        errors=errors or [],
                        model_id=model_id,
                        duration_ms=duration_ms,
                    )
                )
                return
            existing.status = status
            existing.ordinal = stage_ordinal(stage)
            if payload is not None:
                existing.payload = payload
            if summary is not None:
                existing.summary = summary
            if errors is not None:
                existing.errors = errors
            if model_id is not None:
                existing.model_id = model_id
            if duration_ms is not None:
                existing.duration_ms = duration_ms
    except Exception as exc:  # noqa: BLE001 — inspection must never break a build
        log.warning("could not record stage %s for run %s: %s", stage, run_id, exc)


def stages_for(run_id: str) -> list[dict]:
    """Every recorded stage for a run, in pipeline order."""
    try:
        with db.session_scope() as session:
            rows = (
                session.query(StageArtifact)
                .filter_by(run_id=run_id)
                .order_by(StageArtifact.ordinal, StageArtifact.created_at)
                .all()
            )
            return [
                {
                    "stage": row.stage,
                    "ordinal": row.ordinal,
                    "status": row.status,
                    "summary": row.summary or {},
                    "errors": row.errors or [],
                    "model_id": row.model_id,
                    "duration_ms": row.duration_ms,
                    "edited": row.edited,
                }
                for row in rows
            ]
    except Exception as exc:  # noqa: BLE001
        log.warning("could not read stages for run %s: %s", run_id, exc)
        return []


def stage_payload(run_id: str, stage: str) -> dict | None:
    """One stage's full output, or None when it has not run."""
    with db.session_scope() as session:
        row = (
            session.query(StageArtifact)
            .filter_by(run_id=run_id, stage=stage)
            .one_or_none()
        )
        if row is None:
            return None
        return {
            "stage": row.stage,
            "status": row.status,
            "payload": row.payload or {},
            "summary": row.summary or {},
            "errors": row.errors or [],
            "model_id": row.model_id,
            "duration_ms": row.duration_ms,
            "edited": row.edited,
        }


def replace_stage_payload(run_id: str, stage: str, payload: dict) -> bool:
    """Accept a human-edited payload for a stage; returns False if it never ran.

    This is the inspector's control point: correcting a stage and re-running the
    rest is how the brain is tested apart from the 3D pipeline. The override is
    flagged (`edited`) so downstream evidence and any training signal can tell a
    human-corrected target from a model-authored one.
    """
    with db.session_scope() as session:
        row = (
            session.query(StageArtifact)
            .filter_by(run_id=run_id, stage=stage)
            .one_or_none()
        )
        if row is None:
            return False
        row.payload = payload
        row.edited = True
        return True
