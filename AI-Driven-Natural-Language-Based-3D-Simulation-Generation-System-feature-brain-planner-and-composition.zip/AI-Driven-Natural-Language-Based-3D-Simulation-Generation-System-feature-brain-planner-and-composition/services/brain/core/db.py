"""Database engine, session factory, and helpers.

One synchronous SQLAlchemy stack. FastAPI runs sync handlers in a threadpool;
Celery tasks and Alembic are sync too — so there is a single driver (psycopg v3)
and a single session style everywhere. `session_scope` and `get_db` look up the
module-global `SessionLocal`/`engine` at call time, so tests can monkeypatch them.
"""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager

from sqlalchemy import create_engine, text
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from core.config import get_settings


class Base(DeclarativeBase):
    pass


_settings = get_settings()

# echo stays off; pool_pre_ping avoids stale connections on the VPS.
engine = create_engine(_settings.database_url, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False, future=True)


def get_db() -> Iterator[Session]:
    """FastAPI dependency — a request-scoped session (caller commits explicitly)."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@contextmanager
def session_scope() -> Iterator[Session]:
    """Transactional scope for background work (Celery tasks).

    Commits on success, rolls back on error.
    """
    db = SessionLocal()
    try:
        if db.get_bind().dialect.name == "postgresql":
            # Background workers use a separate least-privilege database role.
            # RLS still requires an explicit, transaction-local service marker;
            # an ordinary API session never receives this value.
            db.execute(text("SELECT set_config('app.worker_bypass', 'on', true)"))
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
