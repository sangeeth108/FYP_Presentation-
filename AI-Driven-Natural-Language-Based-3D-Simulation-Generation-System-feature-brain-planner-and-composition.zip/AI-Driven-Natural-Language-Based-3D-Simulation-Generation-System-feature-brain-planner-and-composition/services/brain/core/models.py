"""ORM models. P0 hello-job needs only `games` and `jobs`.

Portable column types (String/Integer/JSON/DateTime) so the same models run on
Postgres (prod) and SQLite (tests). Richer tables (specs, artifacts, lineage,
validation_reports, repair_attempts, registries) arrive in P1+ per
docs/DATABASE_SCHEMA.md.
"""

from __future__ import annotations

import enum
from datetime import UTC, datetime

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from core.db import Base


def _utcnow() -> datetime:
    return datetime.now(UTC)


class JobState(enum.StrEnum):
    QUEUED = "QUEUED"
    PLANNING = "PLANNING"
    SPEC_FROZEN = "SPEC_FROZEN"
    BUILDING_LEVEL = "BUILDING_LEVEL"
    RESOLVING_ASSETS = "RESOLVING_ASSETS"
    ASSEMBLING = "ASSEMBLING"
    EXPORTING = "EXPORTING"
    VALIDATING = "VALIDATING"
    DEPLOYED = "DEPLOYED"
    REPAIRING = "REPAIRING"
    FAILED = "FAILED"


class Game(Base):
    __tablename__ = "games"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)  # g3d_<slug>_<hash>
    title: Mapped[str] = mapped_column(String(120))
    prompt: Mapped[str] = mapped_column(String(2000))
    genre: Mapped[str | None] = mapped_column(String(48), nullable=True)
    camera: Mapped[str | None] = mapped_column(String(24), nullable=True)
    seed: Mapped[int | None] = mapped_column(Integer, nullable=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="RESTRICT"), default="tenant_dev", index=True
    )
    owner_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), default="user_dev"
    )
    residency_region: Mapped[str] = mapped_column(String(32), default="local")
    retention_class: Mapped[str] = mapped_column(String(32), default="development")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    jobs: Mapped[list[Job]] = relationship(back_populates="game", cascade="all, delete-orphan")


class Job(Base):
    __tablename__ = "jobs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)  # uuid4
    game_id: Mapped[str] = mapped_column(ForeignKey("games.id", ondelete="CASCADE"), index=True)
    state: Mapped[str] = mapped_column(String(24), default=JobState.QUEUED.value, index=True)
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="RESTRICT"), default="tenant_dev", index=True
    )
    owner_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), default="user_dev"
    )
    residency_region: Mapped[str] = mapped_column(String(32), default="local")
    retention_class: Mapped[str] = mapped_column(String(32), default="development")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow
    )

    game: Mapped[Game] = relationship(back_populates="jobs")


class Spec(Base):
    """The frozen canonical game_spec (docs/DATABASE_SCHEMA.md).

    Specified since P0 and never built: the pipeline recorded only `spec_hash`,
    so the spec BODY existed solely inside each built project's game_spec.json —
    recoverable, but not queryable, and gone when the artifacts folder is.

    That is the P4 distillation set being thrown away. Every job already produces
    exactly the pair a fine-tune needs — `games.prompt` -> this body — and the
    validator says which pairs are any good, so the training data is a *byproduct*
    of running the system rather than a labelling effort. It only works if we keep
    it from now on: `eval/README.md` names "building the harness in P5" as a
    top-10 risk, and a spec not stored today can never be recovered.

    Written at SPEC_FROZEN, so it is the spec as PLANNED, before the deterministic
    stages could fail — the planner is what a distillation set is about, and a
    build failure downstream is a label, not a reason to drop the row.
    """

    __tablename__ = "specs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)  # = job_id
    game_id: Mapped[str] = mapped_column(ForeignKey("games.id", ondelete="CASCADE"), index=True)
    job_id: Mapped[str] = mapped_column(ForeignKey("jobs.id", ondelete="CASCADE"), index=True)
    schema_version: Mapped[str] = mapped_column(String(16))
    spec_hash: Mapped[str] = mapped_column(String(64), index=True)  # ETag; NOT unique:
    # the same prompt+seed legitimately re-plans to the same spec on a rebuild.
    brief_source: Mapped[str] = mapped_column(String(16), index=True)  # llm | rules | edit
    planner_model: Mapped[str | None] = mapped_column(String(120), nullable=True)
    data_source: Mapped[str] = mapped_column(
        String(32), default="legacy_unclassified", index=True
    )
    training_eligible: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="RESTRICT"), default="tenant_dev", index=True
    )
    owner_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), default="user_dev"
    )
    residency_region: Mapped[str] = mapped_column(String(32), default="local")
    retention_class: Mapped[str] = mapped_column(String(32), default="development")
    body: Mapped[dict] = mapped_column(JSON)
    frozen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class Tenant(Base):
    __tablename__ = "tenants"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    name: Mapped[str] = mapped_column(String(160))
    slug: Mapped[str] = mapped_column(String(80), unique=True)
    residency_region: Mapped[str] = mapped_column(String(32), default="local")
    training_policy: Mapped[str] = mapped_column(String(32), default="disabled")
    status: Mapped[str] = mapped_column(String(24), default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class User(Base):
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    subject: Mapped[str] = mapped_column(String(255), unique=True)
    email_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    age_band: Mapped[str] = mapped_column(String(16), default="unknown")
    status: Mapped[str] = mapped_column(String(24), default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow
    )


class Membership(Base):
    __tablename__ = "memberships"
    __table_args__ = (
        UniqueConstraint("tenant_id", "user_id", "role", name="uq_membership_role"),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    role: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(24), default="active")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class TenantQuota(Base):
    __tablename__ = "tenant_quotas"

    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), primary_key=True
    )
    max_concurrent_generations: Mapped[int] = mapped_column(Integer, default=3)
    monthly_generation_limit: Mapped[int] = mapped_column(Integer, default=100)
    active_generations: Mapped[int] = mapped_column(Integer, default=0)
    window_started_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow
    )
    window_generations: Mapped[int] = mapped_column(Integer, default=0)
    gpu_seconds_limit: Mapped[int] = mapped_column(Integer, default=36_000)
    gpu_seconds_used: Mapped[int] = mapped_column(Integer, default=0)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow
    )


class AgeAssurance(Base):
    __tablename__ = "age_assurance"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), default="tenant_dev", index=True
    )
    user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    age_band: Mapped[str] = mapped_column(String(16))
    provider: Mapped[str] = mapped_column(String(80))
    evidence_ref: Mapped[str] = mapped_column(String(255))
    verified_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class GuardianRelationship(Base):
    __tablename__ = "guardian_relationships"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "minor_user_id",
            "guardian_user_id",
            name="uq_guardian_relationship",
        ),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), default="tenant_dev", index=True
    )
    minor_user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    guardian_user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    status: Mapped[str] = mapped_column(String(24), default="pending")
    verification_ref: Mapped[str | None] = mapped_column(String(255), nullable=True)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class AuditEvent(Base):
    __tablename__ = "audit_events"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str | None] = mapped_column(
        ForeignKey("tenants.id", ondelete="SET NULL"), nullable=True, index=True
    )
    actor_user_id: Mapped[str | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    action: Mapped[str] = mapped_column(String(120), index=True)
    resource_type: Mapped[str] = mapped_column(String(64))
    resource_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class ConsentRecord(Base):
    __tablename__ = "consent_records"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    subject_user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    actor_user_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )
    consent_kind: Mapped[str] = mapped_column(String(24))
    scope: Mapped[str] = mapped_column(String(24))
    data_category: Mapped[str] = mapped_column(String(32))
    granted: Mapped[bool] = mapped_column(Boolean, default=False)
    disclosure_version: Mapped[str] = mapped_column(String(32))
    locale: Mapped[str] = mapped_column(String(16))
    guardian_relationship_id: Mapped[str | None] = mapped_column(
        ForeignKey("guardian_relationships.id", ondelete="SET NULL"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    withdrawn_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class ContentRight(Base):
    __tablename__ = "content_rights"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id", "resource_type", "resource_id", name="uq_content_right_resource"
        ),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    owner_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    resource_type: Mapped[str] = mapped_column(String(48))
    resource_id: Mapped[str] = mapped_column(String(128))
    rights_basis: Mapped[str] = mapped_column(String(48))
    training_allowed: Mapped[bool] = mapped_column(Boolean, default=False)
    licence_id: Mapped[str | None] = mapped_column(String(120), nullable=True)
    verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class TrainingEligibility(Base):
    __tablename__ = "training_eligibility"
    __table_args__ = (
        UniqueConstraint(
            "resource_type",
            "resource_id",
            "training_scope",
            name="uq_training_eligibility_resource_scope",
        ),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    owner_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    resource_type: Mapped[str] = mapped_column(String(48))
    resource_id: Mapped[str] = mapped_column(String(128))
    training_scope: Mapped[str] = mapped_column(String(24))
    data_category: Mapped[str] = mapped_column(String(32), default="prompt_spec")
    data_source: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(24), default="quarantined", index=True)
    consent_record_id: Mapped[str | None] = mapped_column(
        ForeignKey("consent_records.id", ondelete="SET NULL"), nullable=True
    )
    guardian_consent_record_id: Mapped[str | None] = mapped_column(
        ForeignKey("consent_records.id", ondelete="SET NULL"), nullable=True
    )
    content_right_id: Mapped[str | None] = mapped_column(
        ForeignKey("content_rights.id", ondelete="SET NULL"), nullable=True
    )
    moderation_status: Mapped[str] = mapped_column(String(24), default="pending")
    quality_status: Mapped[str] = mapped_column(String(24), default="pending")
    pseudonym_key: Mapped[str | None] = mapped_column(String(64), nullable=True)
    exclusion_reason: Mapped[str | None] = mapped_column(String(160), nullable=True)
    legal_hold: Mapped[bool] = mapped_column(Boolean, default=False)
    deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    evaluated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class FeedbackEvent(Base):
    __tablename__ = "feedback_events"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    owner_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    simulation_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    kind: Mapped[str] = mapped_column(String(32))
    rating: Mapped[int | None] = mapped_column(Integer, nullable=True)
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class UsageEvent(Base):
    __tablename__ = "usage_events"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    owner_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    simulation_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    event_type: Mapped[str] = mapped_column(String(64))
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class DataSubjectRequest(Base):
    __tablename__ = "data_subject_requests"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    owner_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    request_type: Mapped[str] = mapped_column(String(24))
    state: Mapped[str] = mapped_column(String(24), default="queued")
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    result: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow
    )
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class DatasetVersion(Base):
    __tablename__ = "dataset_versions"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str | None] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), nullable=True, index=True
    )
    scope: Mapped[str] = mapped_column(String(24))
    status: Mapped[str] = mapped_column(String(24), default="draft")
    target: Mapped[str] = mapped_column(String(32), default="planner")
    split_policy_version: Mapped[str] = mapped_column(String(32), default="strict-v1")
    manifest_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    item_count: Mapped[int] = mapped_column(Integer, default=0)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    frozen_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class DatasetItem(Base):
    __tablename__ = "dataset_items"
    __table_args__ = (
        UniqueConstraint(
            "dataset_version_id", "eligibility_id", name="uq_dataset_item_eligibility"
        ),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    dataset_version_id: Mapped[str] = mapped_column(
        ForeignKey("dataset_versions.id", ondelete="CASCADE"), index=True
    )
    eligibility_id: Mapped[str] = mapped_column(
        ForeignKey("training_eligibility.id", ondelete="RESTRICT"), index=True
    )
    tenant_id: Mapped[str | None] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), nullable=True, index=True
    )
    target: Mapped[str] = mapped_column(String(32))
    owner_pseudonym: Mapped[str] = mapped_column(String(64), index=True)
    prompt_family_hash: Mapped[str] = mapped_column(String(64), index=True)
    time_bucket: Mapped[str] = mapped_column(String(16), index=True)
    content_hash: Mapped[str] = mapped_column(String(64))
    split: Mapped[str] = mapped_column(String(16))
    consent_snapshot: Mapped[dict] = mapped_column(JSON, default=dict)
    rights_snapshot: Mapped[dict] = mapped_column(JSON, default=dict)
    sanitized_payload: Mapped[dict] = mapped_column(JSON, default=dict)
    source_created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class TrainingRun(Base):
    __tablename__ = "training_runs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    dataset_version_id: Mapped[str] = mapped_column(
        ForeignKey("dataset_versions.id", ondelete="RESTRICT"), index=True
    )
    tenant_id: Mapped[str | None] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), nullable=True, index=True
    )
    target: Mapped[str] = mapped_column(String(32))
    base_model: Mapped[str] = mapped_column(String(160))
    state: Mapped[str] = mapped_column(String(24), default="candidate")
    config: Mapped[dict] = mapped_column(JSON, default=dict)
    metrics: Mapped[dict] = mapped_column(JSON, default=dict)
    artifact_ref: Mapped[str | None] = mapped_column(String(512), nullable=True)
    approved_by: Mapped[str | None] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), nullable=True
    )
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class ModelVersion(Base):
    __tablename__ = "model_versions"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    training_run_id: Mapped[str | None] = mapped_column(
        ForeignKey("training_runs.id", ondelete="SET NULL"), nullable=True
    )
    tenant_id: Mapped[str | None] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), nullable=True, index=True
    )
    name: Mapped[str] = mapped_column(String(160))
    target: Mapped[str] = mapped_column(String(32))
    state: Mapped[str] = mapped_column(String(24), default="candidate")
    digest: Mapped[str] = mapped_column(String(128))
    licence_id: Mapped[str] = mapped_column(String(120))
    model_card: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class ModelEvaluation(Base):
    """Signed, immutable release evidence produced by the evaluation service."""

    __tablename__ = "model_evaluations"
    __table_args__ = (
        UniqueConstraint(
            "model_version_id",
            "artifact_digest",
            "benchmark_digest",
            name="uq_model_evaluation_artifact_benchmark",
        ),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    model_version_id: Mapped[str] = mapped_column(
        ForeignKey("model_versions.id", ondelete="CASCADE"), index=True
    )
    tenant_id: Mapped[str | None] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), nullable=True, index=True
    )
    evaluator: Mapped[str] = mapped_column(String(80))
    evaluator_version: Mapped[str] = mapped_column(String(64))
    benchmark_digest: Mapped[str] = mapped_column(String(128))
    artifact_digest: Mapped[str] = mapped_column(String(128))
    metrics: Mapped[dict] = mapped_column(JSON)
    signature: Mapped[str] = mapped_column(String(128))
    verified: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class ModelDeployment(Base):
    __tablename__ = "model_deployments"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    model_version_id: Mapped[str] = mapped_column(
        ForeignKey("model_versions.id", ondelete="CASCADE"), index=True
    )
    tenant_id: Mapped[str | None] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), nullable=True, index=True
    )
    stage: Mapped[str] = mapped_column(String(24))
    traffic_percent: Mapped[int] = mapped_column(Integer, default=0)
    state: Mapped[str] = mapped_column(String(24), default="inactive")
    metrics: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class SecurityIncident(Base):
    __tablename__ = "security_incidents"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str | None] = mapped_column(
        ForeignKey("tenants.id", ondelete="SET NULL"), nullable=True, index=True
    )
    severity: Mapped[str] = mapped_column(String(16))
    state: Mapped[str] = mapped_column(String(24), default="open")
    category: Mapped[str] = mapped_column(String(64))
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class DeletionTombstone(Base):
    __tablename__ = "deletion_tombstones"
    __table_args__ = (
        UniqueConstraint(
            "tenant_id",
            "resource_type",
            "resource_id",
            name="uq_deletion_tombstone_resource",
        ),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    owner_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    resource_type: Mapped[str] = mapped_column(String(48))
    resource_id: Mapped[str] = mapped_column(String(128))
    content_hash: Mapped[str | None] = mapped_column(String(64), nullable=True)
    reason: Mapped[str] = mapped_column(String(64), default="user_deletion")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class ResearchExclusion(Base):
    __tablename__ = "research_exclusions"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    fingerprint: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    exclusion_type: Mapped[str] = mapped_column(String(32))
    purpose: Mapped[str] = mapped_column(String(120))
    study_id: Mapped[str | None] = mapped_column(String(80), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class Simulation(Base):
    __tablename__ = "simulations"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    owner_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), index=True
    )
    title: Mapped[str] = mapped_column(String(120))
    prompt: Mapped[str] = mapped_column(String(4000))
    size_profile: Mapped[str] = mapped_column(String(16))
    target_platforms: Mapped[list] = mapped_column(JSON)
    seed: Mapped[int] = mapped_column(Integer)
    status: Mapped[str] = mapped_column(String(32), default="queued")
    current_spec_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    current_run_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    residency_region: Mapped[str] = mapped_column(String(32), default="local")
    retention_class: Mapped[str] = mapped_column(String(32), default="standard")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow
    )


class SimulationSpecRecord(Base):
    __tablename__ = "simulation_specs"
    __table_args__ = (
        UniqueConstraint("simulation_id", "version", name="uq_simulation_spec_version"),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    simulation_id: Mapped[str] = mapped_column(
        ForeignKey("simulations.id", ondelete="CASCADE"), index=True
    )
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    owner_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), index=True
    )
    version: Mapped[int] = mapped_column(Integer)
    schema_version: Mapped[str] = mapped_column(String(16))
    spec_hash: Mapped[str] = mapped_column(String(64), index=True)
    source: Mapped[str] = mapped_column(String(32))
    planner_model: Mapped[str | None] = mapped_column(String(160), nullable=True)
    body: Mapped[dict] = mapped_column(JSON)
    data_source: Mapped[str] = mapped_column(String(32), default="production_user")
    training_eligible: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class GenerationRun(Base):
    __tablename__ = "generation_runs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    simulation_id: Mapped[str] = mapped_column(
        ForeignKey("simulations.id", ondelete="CASCADE"), index=True
    )
    spec_id: Mapped[str | None] = mapped_column(
        ForeignKey("simulation_specs.id", ondelete="SET NULL"), nullable=True
    )
    world_plan_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    owner_id: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT"), index=True
    )
    state: Mapped[str] = mapped_column(String(32), default="queued", index=True)
    stage: Mapped[str] = mapped_column(String(32), default="intake")
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    model_routes: Mapped[dict] = mapped_column(JSON, default=dict)
    repair_attempts: Mapped[int] = mapped_column(Integer, default=0)
    max_repair_attempts: Mapped[int] = mapped_column(Integer, default=3)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow
    )
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class GenerationLease(Base):
    __tablename__ = "generation_leases"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    run_id: Mapped[str] = mapped_column(
        ForeignKey("generation_runs.id", ondelete="CASCADE"), unique=True, index=True
    )
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    state: Mapped[str] = mapped_column(String(16), default="active", index=True)
    reserved_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    released_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class WorldPlanRecord(Base):
    __tablename__ = "world_plans"
    __table_args__ = (
        UniqueConstraint("run_id", name="uq_world_plan_run"),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    run_id: Mapped[str] = mapped_column(
        ForeignKey("generation_runs.id", ondelete="CASCADE"), index=True
    )
    spec_id: Mapped[str] = mapped_column(
        ForeignKey("simulation_specs.id", ondelete="CASCADE"), index=True
    )
    simulation_id: Mapped[str] = mapped_column(
        ForeignKey("simulations.id", ondelete="CASCADE"), index=True
    )
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    plan_hash: Mapped[str] = mapped_column(String(64), index=True)
    schema_version: Mapped[str] = mapped_column(String(16))
    compiler_version: Mapped[str] = mapped_column(String(32))
    body: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class AssetDescriptorRecord(Base):
    __tablename__ = "asset_descriptors"
    __table_args__ = (
        UniqueConstraint(
            "run_id",
            "entity_id",
            name="uq_asset_descriptor_entity_run",
        ),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    run_id: Mapped[str] = mapped_column(
        ForeignKey("generation_runs.id", ondelete="CASCADE"), index=True
    )
    simulation_id: Mapped[str] = mapped_column(
        ForeignKey("simulations.id", ondelete="CASCADE"), index=True
    )
    tenant_id: Mapped[str] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), index=True
    )
    entity_id: Mapped[str] = mapped_column(String(80))
    asset_ref: Mapped[str] = mapped_column(String(160))
    content_hash: Mapped[str] = mapped_column(String(64))
    measurement_status: Mapped[str] = mapped_column(String(24))
    body: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class ModelRouteOverride(Base):
    __tablename__ = "model_route_overrides"
    __table_args__ = (
        UniqueConstraint("tenant_id", "role", name="uq_model_route_tenant_role"),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    tenant_id: Mapped[str | None] = mapped_column(
        ForeignKey("tenants.id", ondelete="CASCADE"), nullable=True, index=True
    )
    role: Mapped[str] = mapped_column(String(24), index=True)
    model_id: Mapped[str] = mapped_column(String(160))
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    created_by: Mapped[str] = mapped_column(
        ForeignKey("users.id", ondelete="RESTRICT")
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow
    )


class ValidationEvidence(Base):
    __tablename__ = "validation_evidence"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    run_id: Mapped[str] = mapped_column(
        ForeignKey("generation_runs.id", ondelete="CASCADE"), index=True
    )
    layer: Mapped[str] = mapped_column(String(48))
    status: Mapped[str] = mapped_column(String(16))
    mandatory: Mapped[bool] = mapped_column(Boolean, default=True)
    validator: Mapped[str] = mapped_column(String(80))
    validator_version: Mapped[str] = mapped_column(String(32))
    requirement_ids: Mapped[list] = mapped_column(JSON, default=list)
    evidence: Mapped[dict] = mapped_column(JSON, default=dict)
    errors: Mapped[list] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class StageArtifact(Base):
    """One pipeline stage's output, kept so a run can be inspected step by step.

    The run's `detail` blob only ever held the final summary, so there was no way
    to see what the brain actually decided before the engine stage ran. Persisting
    each stage separately is what lets the inspector pause after every stage, show
    that stage's real JSON, and re-run downstream from an edited version — which is
    also how the brain gets tested without touching the 3D pipeline.
    """

    __tablename__ = "stage_artifacts"
    __table_args__ = (
        UniqueConstraint("run_id", "stage", name="uq_stage_artifact_run_stage"),
    )

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    run_id: Mapped[str] = mapped_column(
        ForeignKey("generation_runs.id", ondelete="CASCADE"), index=True
    )
    stage: Mapped[str] = mapped_column(String(48))
    ordinal: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(16), default="PENDING")
    # The inspectable output. `summary` holds the few headline numbers the stage
    # rail shows without downloading the whole payload.
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    summary: Mapped[dict] = mapped_column(JSON, default=dict)
    errors: Mapped[list] = mapped_column(JSON, default=list)
    model_id: Mapped[str | None] = mapped_column(String(160), nullable=True)
    duration_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # True when a human replaced this stage's payload in the inspector. That edit
    # is the strongest training signal there is (a corrected target), so it is
    # recorded rather than silently overwritten.
    edited: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=_utcnow, onupdate=_utcnow
    )


class SimulationArtifact(Base):
    __tablename__ = "simulation_artifacts"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    run_id: Mapped[str] = mapped_column(
        ForeignKey("generation_runs.id", ondelete="CASCADE"), index=True
    )
    kind: Mapped[str] = mapped_column(String(32))
    platform: Mapped[str | None] = mapped_column(String(16), nullable=True)
    uri: Mapped[str] = mapped_column(String(1024))
    content_hash: Mapped[str | None] = mapped_column(String(128), nullable=True)
    bytes: Mapped[int | None] = mapped_column(Integer, nullable=True)
    ai_generated: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class CapabilityGap(Base):
    __tablename__ = "capability_gaps"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    simulation_id: Mapped[str] = mapped_column(
        ForeignKey("simulations.id", ondelete="CASCADE"), index=True
    )
    run_id: Mapped[str] = mapped_column(
        ForeignKey("generation_runs.id", ondelete="CASCADE"), index=True
    )
    requirement_id: Mapped[str | None] = mapped_column(String(80), nullable=True)
    capability_id: Mapped[str] = mapped_column(String(80))
    status: Mapped[str] = mapped_column(String(24), default="open")
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
