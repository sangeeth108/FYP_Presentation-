"""OIDC-compatible request identity and tenant boundary.

Production accepts only issuer/audience-validated bearer tokens resolved through
the configured JWKS endpoint. Development has one explicit local principal so
the offline test and contributor workflows remain usable.
"""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass

import jwt
from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import text
from sqlalchemy.orm import Session

from core.config import get_settings
from core.db import get_db

_bearer = HTTPBearer(auto_error=False)


@dataclass(frozen=True)
class Principal:
    user_id: str
    tenant_id: str
    roles: frozenset[str]
    age_band: str
    subject: str

    def has_any_role(self, allowed: set[str]) -> bool:
        return bool(self.roles.intersection(allowed))


def _claims_from_token(token: str) -> dict:
    settings = get_settings()
    try:
        if settings.oidc_jwks_url:
            key = jwt.PyJWKClient(settings.oidc_jwks_url).get_signing_key_from_jwt(token).key
            return jwt.decode(
                token,
                key,
                algorithms=settings.oidc_algorithms_list,
                audience=settings.oidc_audience,
                issuer=settings.oidc_issuer,
            )
        if settings.promptplay_env == "production":
            raise HTTPException(status_code=503, detail="OIDC is not configured")
        return jwt.decode(
            token,
            settings.api_secret_key,
            algorithms=["HS256"],
            options={"verify_aud": False},
        )
    except HTTPException:
        raise
    except jwt.PyJWTError as exc:
        raise HTTPException(status_code=401, detail="invalid bearer token") from exc


def current_principal(
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer),
) -> Principal:
    settings = get_settings()
    if credentials is None:
        if settings.promptplay_env == "production" or settings.auth_required:
            raise HTTPException(status_code=401, detail="bearer token required")
        return Principal(
            user_id=settings.default_user_id,
            tenant_id=settings.default_tenant_id,
            roles=frozenset({"platform_admin", "user"}),
            age_band="adult",
            subject="development",
        )

    claims = _claims_from_token(credentials.credentials)
    subject = str(claims.get("sub") or "")
    user_id = str(claims.get("serendib_user_id") or claims.get("user_id") or subject)
    tenant_id = str(claims.get("tenant_id") or "")
    raw_roles = claims.get("roles") or ["user"]
    roles = (
        frozenset(str(role) for role in raw_roles)
        if isinstance(raw_roles, list)
        else frozenset({str(raw_roles)})
    )
    if not subject or not user_id or not tenant_id:
        raise HTTPException(status_code=401, detail="token lacks subject or tenant identity")
    return Principal(
        user_id=user_id,
        tenant_id=tenant_id,
        roles=roles,
        age_band=str(claims.get("age_band") or "unknown"),
        subject=subject,
    )


def require_roles(*roles: str):
    allowed = set(roles)

    def dependency(principal: Principal = Depends(current_principal)) -> Principal:
        if not principal.has_any_role(allowed):
            raise HTTPException(status_code=403, detail="insufficient role")
        return principal

    return dependency


def ensure_principal_records(db: Session, principal: Principal) -> None:
    """Provision the minimum local identity records after external authentication."""
    from core.ids import new_resource_id
    from core.models import Membership, Tenant, User

    changed = False
    tenant = db.get(Tenant, principal.tenant_id)
    if tenant is None:
        changed = True
        tenant = Tenant(
            id=principal.tenant_id,
            name=f"Tenant {principal.tenant_id[:24]}",
            slug=principal.tenant_id[:80],
            residency_region=get_settings().default_residency_region,
            training_policy="disabled",
        )
        db.add(tenant)
    user = db.get(User, principal.user_id)
    if user is None:
        changed = True
        user = User(
            id=principal.user_id,
            subject=principal.subject,
            age_band=principal.age_band,
        )
        db.add(user)
    if user.status == "active":
        for role in principal.roles:
            exists = (
                db.query(Membership)
                .filter_by(
                    tenant_id=principal.tenant_id,
                    user_id=principal.user_id,
                    role=role,
                )
                .first()
            )
            if exists is None:
                changed = True
                db.add(
                    Membership(
                        id=new_resource_id("membership"),
                        tenant_id=principal.tenant_id,
                        user_id=principal.user_id,
                        role=role,
                    )
                )
    db.flush()
    # Provisioning can happen on a read-only first request. Persist it here so a
    # following guardian/privacy request sees the same externally authenticated
    # subject instead of relying on endpoint-specific commits.
    if changed:
        db.commit()


def _apply_database_identity(db: Session, principal: Principal) -> None:
    """Bind PostgreSQL RLS settings to the current transaction."""
    if db.get_bind().dialect.name != "postgresql":
        return
    db.execute(
        text("SELECT set_config('app.tenant_id', :tenant_id, true)"),
        {"tenant_id": principal.tenant_id},
    )
    db.execute(
        text("SELECT set_config('app.user_id', :user_id, true)"),
        {"user_id": principal.user_id},
    )
    db.execute(
        text("SELECT set_config('app.platform_admin', :is_admin, true)"),
        {"is_admin": "on" if "platform_admin" in principal.roles else "off"},
    )


def tenant_db(
    principal: Principal = Depends(current_principal),
    db: Session = Depends(get_db),
) -> Iterator[Session]:
    """Request database dependency with fail-closed tenant RLS context."""
    _apply_database_identity(db, principal)
    ensure_principal_records(db, principal)
    # Provisioning may commit and clear transaction-local settings.
    _apply_database_identity(db, principal)
    yield db


def ensure_generation_age_eligible(db: Session, principal: Principal) -> None:
    """Enforce the public 13+ product boundary using persisted identity state."""
    from datetime import UTC, datetime

    from core.models import AgeAssurance, User

    user = db.get(User, principal.user_id)
    if user is None or user.status != "active":
        raise HTTPException(status_code=403, detail="active user account required")
    if user.age_band == "under_13":
        raise HTTPException(status_code=403, detail="Serendib is available to users aged 13+")
    if user.age_band == "unknown":
        raise HTTPException(status_code=403, detail="age assurance is required")
    if get_settings().promptplay_env == "production":
        now = datetime.now(UTC)
        assurance = (
            db.query(AgeAssurance)
            .filter_by(
                tenant_id=principal.tenant_id,
                user_id=principal.user_id,
                age_band=user.age_band,
            )
            .filter(
                (AgeAssurance.expires_at.is_(None))
                | (AgeAssurance.expires_at > now)
            )
            .order_by(AgeAssurance.verified_at.desc())
            .first()
        )
        if assurance is None:
            raise HTTPException(status_code=403, detail="verified age assurance is required")
