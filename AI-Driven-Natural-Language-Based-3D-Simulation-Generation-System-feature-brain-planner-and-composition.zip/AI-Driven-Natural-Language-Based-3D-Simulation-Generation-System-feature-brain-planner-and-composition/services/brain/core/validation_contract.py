"""Authoritative mandatory validation-layer contract for release decisions."""

MANDATORY_PREPUBLICATION_LAYERS = frozenset(
    {
        "requirements_and_schema",
        "capability_declaration",
        "capability_resolution",
        "requirement_traceability",
        "deterministic_critic",
        "independent_model_critic",
        "behavior_compilation",
        "asset_geometry",
        "asset_animation_compatibility",
        "semantic_placement",
        "native_world_plan_compilation",
        "runtime_interactions",
        "navigation_reachability",
        "import_export",
        "cross_platform_parity",
        "lineage",
    }
)

MANDATORY_VALIDATION_LAYERS = MANDATORY_PREPUBLICATION_LAYERS | frozenset(
    {"artifact_publication"}
)

# Runs on every job and appears in the evidence, but does not block publication.
#
# It is the one layer whose judgement comes from a model looking at pictures
# rather than from measurement, and it was failing correct worlds: two houses
# filling a third of the frame reported as "not visible", a Husky matched from
# "an animated, rigged dog" reported as "not a dog". The same model swapped
# dog/cow/horse labels in an earlier run, which is why the batching was already
# reduced to one camera subject per request. A verdict that unreliable can
# inform a reviewer; it should not be the thing standing between a verified
# build and the user.
#
# Everything that MEASURES the artifact -- schema, capabilities, placement,
# behaviour compilation, native compilation, runtime interactions, navigation,
# import/export, cross-platform parity, lineage -- stays mandatory. Move this
# back into the set above once a vision model strong enough to be trusted is
# the default.
ADVISORY_LAYERS = frozenset({"visual_semantic"})
