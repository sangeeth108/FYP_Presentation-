"""Provider-independent model catalog and routing."""
