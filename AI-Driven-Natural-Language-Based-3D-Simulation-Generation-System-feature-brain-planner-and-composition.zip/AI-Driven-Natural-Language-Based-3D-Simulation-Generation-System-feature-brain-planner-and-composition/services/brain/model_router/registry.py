"""Model-role routing with explicit unavailable roles."""

from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass

from core.config import get_settings


@dataclass(frozen=True)
class ModelDescriptor:
    model_id: str
    provider: str
    roles: tuple[str, ...]
    modalities: tuple[str, ...]
    context_window: int
    structured_output: bool
    licence_id: str
    regions: tuple[str, ...]
    available: bool
    deployment: str
    model_digest: str
    version: str
    structured_output_reliability: float
    suitability: dict[str, float]
    estimated_latency_ms: int
    estimated_cost_per_million_tokens_usd: float
    endpoint: str

    def public_dict(self) -> dict:
        public = asdict(self)
        public.pop("endpoint", None)
        return public


def model_catalog() -> list[ModelDescriptor]:
    settings = get_settings()
    def configured_digest(configured: str, role: str, model: str) -> str:
        return configured or hashlib.sha256(
            f"unverified-development:{role}:{model}".encode()
        ).hexdigest()

    planner_digest = configured_digest(
        settings.llm_model_digest, "planner", settings.llm_model
    )
    return [
        ModelDescriptor(
            model_id=settings.llm_model,
            provider="ollama",
            roles=("planner",),
            modalities=("text",),
            context_window=32768,
            structured_output=True,
            licence_id="see_licensing_ledger",
            regions=("local",),
            available=settings.llm_enabled,
            deployment="private",
            model_digest=planner_digest,
            version="configured",
            structured_output_reliability=0.8,
            suitability={"planner": 0.9, "critic": 0.2, "vision": 0.0},
            estimated_latency_ms=5000,
            estimated_cost_per_million_tokens_usd=0.0,
            endpoint=settings.llm_base_url,
        ),
        ModelDescriptor(
            model_id=settings.critic_model or "independent_critic_unconfigured",
            provider="ollama" if settings.critic_model else "none",
            roles=("critic",),
            modalities=("text",),
            context_window=32768 if settings.critic_model else 0,
            structured_output=bool(settings.critic_model),
            licence_id="see_licensing_ledger" if settings.critic_model else "none",
            regions=("local",) if settings.critic_model else (),
            available=bool(settings.critic_enabled and settings.critic_model),
            deployment="private" if settings.critic_model else "unavailable",
            model_digest=configured_digest(
                settings.critic_model_digest,
                "critic",
                settings.critic_model or "unconfigured",
            ),
            version="configured" if settings.critic_model else "unconfigured",
            structured_output_reliability=0.8 if settings.critic_model else 0.0,
            suitability={"planner": 0.0, "critic": 0.9, "vision": 0.0},
            estimated_latency_ms=5000 if settings.critic_model else 0,
            estimated_cost_per_million_tokens_usd=0.0,
            endpoint=settings.critic_base_url,
        ),
        ModelDescriptor(
            model_id=settings.vision_model or "vision_validator_unconfigured",
            provider="ollama" if settings.vision_model else "none",
            roles=("vision",),
            modalities=("image", "text"),
            context_window=32768 if settings.vision_model else 0,
            structured_output=bool(settings.vision_model),
            licence_id="see_licensing_ledger" if settings.vision_model else "none",
            regions=("local",) if settings.vision_model else (),
            available=bool(settings.vision_enabled and settings.vision_model),
            deployment="private" if settings.vision_model else "unavailable",
            model_digest=configured_digest(
                settings.vision_model_digest,
                "vision",
                settings.vision_model or "unconfigured",
            ),
            version="configured" if settings.vision_model else "unconfigured",
            structured_output_reliability=0.8 if settings.vision_model else 0.0,
            suitability={"planner": 0.0, "critic": 0.0, "vision": 0.9},
            estimated_latency_ms=6000 if settings.vision_model else 0,
            estimated_cost_per_million_tokens_usd=0.0,
            endpoint=settings.vision_base_url,
        ),
    ]


def _deployment_descriptor(role: str, tenant_id: str | None, routing_key: str | None):
    """Return an active tenant-isolated production/canary deployment, if any."""
    if role not in {"planner", "critic", "vision"}:
        return None
    try:
        from core import db
        from core.models import ModelDeployment, ModelVersion
        from sqlalchemy import or_

        with db.session_scope() as session:
            query = (
                session.query(ModelDeployment, ModelVersion)
                .join(ModelVersion, ModelVersion.id == ModelDeployment.model_version_id)
                .filter(
                    ModelDeployment.state == "active",
                    ModelDeployment.stage.in_(("production", "canary")),
                    ModelVersion.state.in_(("PRODUCTION", "CANARY")),
                    ModelVersion.target == role,
                )
            )
            if tenant_id is None:
                query = query.filter(ModelDeployment.tenant_id.is_(None))
            else:
                query = query.filter(
                    or_(
                        ModelDeployment.tenant_id == tenant_id,
                        ModelDeployment.tenant_id.is_(None),
                    )
                )
            rows = query.order_by(ModelDeployment.created_at.desc()).all()
            for scope in ((tenant_id,) if tenant_id is None else (tenant_id, None)):
                scoped = [row for row in rows if row[0].tenant_id == scope]
                canary = next((row for row in scoped if row[0].stage == "canary"), None)
                production = next(
                    (row for row in scoped if row[0].stage == "production"), None
                )
                selected = production
                if canary is not None and routing_key:
                    bucket = int(
                        hashlib.sha256(
                            f"{tenant_id}:{role}:{routing_key}".encode()
                        ).hexdigest()[:8],
                        16,
                    ) % 100
                    if bucket < canary[0].traffic_percent:
                        selected = canary
                if selected is None:
                    continue
                deployment, model = selected
                runtime = (model.model_card or {}).get("runtime") or {}
                provider = runtime.get("provider")
                model_id = runtime.get("model_id")
                endpoint = runtime.get("endpoint")
                if provider != "ollama" or not model_id or not endpoint:
                    continue
                modalities = tuple(runtime.get("modalities") or ["text"])
                return ModelDescriptor(
                    model_id=str(model_id),
                    provider=provider,
                    roles=(role,),
                    modalities=modalities,
                    context_window=int(runtime.get("context_window") or 8192),
                    structured_output=bool(runtime.get("structured_output", True)),
                    licence_id=model.licence_id,
                    regions=tuple(runtime.get("regions") or ["local"]),
                    available=True,
                    deployment=deployment.stage,
                    model_digest=model.digest,
                    version=model.id,
                    structured_output_reliability=float(
                        runtime.get("structured_output_reliability") or 0.8
                    ),
                    suitability={role: float(runtime.get("suitability") or 0.9)},
                    estimated_latency_ms=int(runtime.get("estimated_latency_ms") or 5000),
                    estimated_cost_per_million_tokens_usd=float(
                        runtime.get("estimated_cost_per_million_tokens_usd") or 0.0
                    ),
                    endpoint=str(endpoint),
                )
    except Exception:
        return None
    return None


def route_model(
    role: str,
    override_model_id: str | None = None,
    tenant_id: str | None = None,
    routing_key: str | None = None,
) -> ModelDescriptor | None:
    if override_model_id is None and tenant_id is not None:
        try:
            from core import db
            from core.models import ModelRouteOverride

            with db.session_scope() as session:
                override = (
                    session.query(ModelRouteOverride)
                    .filter_by(tenant_id=tenant_id, role=role, enabled=True)
                    .one_or_none()
                )
                if override is None:
                    override = (
                        session.query(ModelRouteOverride)
                        .filter(
                            ModelRouteOverride.tenant_id.is_(None),
                            ModelRouteOverride.role == role,
                            ModelRouteOverride.enabled.is_(True),
                        )
                        .order_by(ModelRouteOverride.updated_at.desc())
                        .first()
                    )
                override_model_id = override.model_id if override else None
        except Exception:
            # Registry routing remains available during DB readiness incidents;
            # production completion still fails downstream mandatory validators.
            override_model_id = None
    deployed = _deployment_descriptor(role, tenant_id, routing_key)
    if deployed is not None and override_model_id in {
        None,
        deployed.model_id,
        deployed.version,
    }:
        return deployed
    candidates = [
        model
        for model in model_catalog()
        if role in model.roles
        and (override_model_id is None or model.model_id == override_model_id)
    ]
    return next((model for model in candidates if model.available), None)
