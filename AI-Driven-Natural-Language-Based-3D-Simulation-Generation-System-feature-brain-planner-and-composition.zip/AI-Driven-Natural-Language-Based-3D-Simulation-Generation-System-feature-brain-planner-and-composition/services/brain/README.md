# services/brain — FastAPI orchestration brain

The single always-on backend (Hetzner VPS). API gateway + (later) LangGraph agent chain + arbiter + repair + job planner. Agents are **modules here, not microservices**.

## Status (P0 — hello-job implemented)

A production-shaped vertical slice proving **web → API → Redis/Celery → Postgres**:
- `POST /api/v1/games` → creates `games` + `jobs` rows, enqueues a Celery task, returns **202** `{game_id, job_id}`.
- Celery `run_generation_job` (no AI/GPU) advances the job to `DEPLOYED`.
- `GET /api/v1/jobs/{id}` → job state snapshot. `GET /healthz` → `{"status":"ok"}`.

One synchronous SQLAlchemy 2.0 stack on **psycopg v3** (API runs in FastAPI's threadpool; Celery + Alembic are sync too) — one driver, one session style.

## Layout (actual)

| Path | Purpose | Owner |
|---|---|---|
| `main.py` | FastAPI app factory (`create_app`) + CORS + router mounts | M1 |
| `api/` | Routers: `health.py`, `games.py`, `jobs.py` | M1 |
| `core/` | `config.py` (pydantic-settings), `db.py` (engine/session), `models.py` (Game/Job), `schemas.py`, `ids.py` | M1/M2 |
| `worker/` | `celery_app.py` + `tasks.py` (hello-job) | M1 |
| `migrations/` | Alembic env + `versions/0001_initial.py` (games, jobs) | M1 |
| `tests/` | pytest on SQLite + eager Celery (no Docker needed) | All |
| `orchestrator/ agents/ knowledge/ pcg/ repair/ contracts/ services/` | **empty (.gitkeep)** — filled in P1/P2 per their phases | M2/M4 |

## Run

```bash
# From services/brain, with deps installed (pip install .[dev]):
export DATABASE_URL=postgresql+psycopg://promptplay:change-me@localhost:5432/promptplay
alembic upgrade head                       # create tables
uvicorn main:app --reload                  # http://localhost:8000/docs
celery -A worker.celery_app worker -l info # separate terminal — the queue consumer

# Or the whole stack via Docker (from repo root):
docker compose up -d                       # postgres + redis + brain + celery

# Tests need neither Postgres nor Redis (SQLite + eager Celery):
python -m pytest
```

## When updated

Every endpoint change → `docs/API_DOCUMENTATION.md`; every model/migration change → `docs/DATABASE_SCHEMA.md` + a new Alembic revision.

## Common mistakes to avoid

- Building 9 different agent code paths later — one harness shape, instantiated 9× (P2).
- Referencing an ID not in the registries — allowlists are enforced, not suggested (P2).
- Blocking an HTTP request on generation — everything long-running is 202 + job (already the pattern).
- Editing tables without a migration — `alembic revision` every schema change.
