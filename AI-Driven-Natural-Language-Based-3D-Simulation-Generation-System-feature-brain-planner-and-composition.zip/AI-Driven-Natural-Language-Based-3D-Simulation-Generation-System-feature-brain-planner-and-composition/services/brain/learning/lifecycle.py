"""Manually approved training and model deployment lifecycle."""

from __future__ import annotations

from datetime import UTC, datetime

from core.ids import new_resource_id
from core.models import (
    DatasetItem,
    DatasetVersion,
    DeletionTombstone,
    ModelDeployment,
    ModelEvaluation,
    ModelVersion,
    ResearchExclusion,
    TrainingEligibility,
    TrainingRun,
)
from sqlalchemy.orm import Session

from learning.attestations import verify_attestation
from learning.eligibility import evaluate_eligibility

MODEL_STATES = {
    "CANDIDATE",
    "EVALUATED",
    "SHADOW",
    "CANARY",
    "PRODUCTION",
    "RETIRED",
    "REJECTED",
    "QUARANTINED",
}


class LifecycleError(RuntimeError):
    pass


def create_training_candidate(
    db: Session,
    *,
    dataset: DatasetVersion,
    target: str,
    base_model: str,
    config: dict,
    monthly_window: bool,
) -> TrainingRun:
    if dataset.status != "frozen" or not dataset.manifest_hash:
        raise LifecycleError("dataset must be frozen with a reproducible manifest")
    if target != dataset.target:
        raise LifecycleError("training target does not match dataset target")
    items = (
        db.query(DatasetItem)
        .filter_by(dataset_version_id=dataset.id)
        .all()
    )
    if len(items) != dataset.item_count:
        raise LifecycleError("dataset manifest item count does not match stored items")
    for item in items:
        eligibility = db.get(TrainingEligibility, item.eligibility_id)
        if eligibility is None:
            raise LifecycleError("dataset eligibility record is missing")
        evaluate_eligibility(db, eligibility)
        if eligibility.status != "eligible":
            raise LifecycleError("dataset contains an item that is no longer eligible")
        if (
            db.query(DeletionTombstone)
            .filter_by(
                tenant_id=eligibility.tenant_id,
                resource_type=eligibility.resource_type,
                resource_id=eligibility.resource_id,
            )
            .first()
            is not None
        ):
            raise LifecycleError("dataset contains a deleted resource")
        if (
            db.query(ResearchExclusion)
            .filter_by(fingerprint=item.prompt_family_hash, active=True)
            .first()
            is not None
        ):
            raise LifecycleError("dataset overlaps a current research exclusion")
    if len(items) < 500 and not monthly_window:
        raise LifecycleError("training requires 500 new examples or the monthly window")
    if not items:
        raise LifecycleError("empty datasets cannot start training")
    run = TrainingRun(
        id=new_resource_id("training"),
        dataset_version_id=dataset.id,
        tenant_id=dataset.tenant_id,
        target=target,
        base_model=base_model,
        state="CANDIDATE",
        config={
            **config,
            "dataset_manifest_hash": dataset.manifest_hash,
            "manual_approval_required": True,
            "monthly_window": monthly_window,
        },
        metrics={},
    )
    db.add(run)
    return run


def approve_training_candidate(
    run: TrainingRun, *, approved_by: str
) -> TrainingRun:
    if run.state != "CANDIDATE":
        raise LifecycleError("only candidate training runs can be approved")
    run.approved_by = approved_by
    run.approved_at = datetime.now(UTC)
    run.state = "APPROVED"
    return run


def register_model_candidate(
    db: Session,
    *,
    training_run: TrainingRun,
    name: str,
    licence_id: str,
    model_card: dict,
) -> ModelVersion:
    if training_run.state != "COMPLETED":
        raise LifecycleError("model registration requires a completed training run")
    artifact_digest = (training_run.metrics or {}).get("artifact_digest")
    if (
        not isinstance(artifact_digest, str)
        or not artifact_digest.startswith("sha256:")
        or len(artifact_digest) != 71
        or not training_run.artifact_ref
    ):
        raise LifecycleError("training run has no verified model artifact")
    required = {"dataset_card", "training_manifest", "limitations"}
    if not required.issubset(model_card):
        raise LifecycleError("model card is incomplete")
    dataset_hash = (training_run.config or {}).get("dataset_manifest_hash")
    if model_card["dataset_card"].get("manifest_hash") != dataset_hash:
        raise LifecycleError("model card dataset digest does not match the training run")
    if model_card["training_manifest"].get("base_model") != training_run.base_model:
        raise LifecycleError("model card base model does not match the training run")
    if training_run.target in {"planner", "critic", "vision"}:
        runtime = model_card.get("runtime")
        if not isinstance(runtime, dict) or not all(
            runtime.get(key) for key in ("provider", "model_id", "endpoint")
        ):
            raise LifecycleError("LLM model card requires a serving runtime manifest")
        if runtime["provider"] != "ollama":
            raise LifecycleError("only the allowlisted Ollama serving provider is supported")
    elif training_run.target in {"asset_ranker", "placement_ranker"}:
        runtime = model_card.get("runtime") or {}
        runtime_ref = runtime.get("artifact_ref")
        if not runtime_ref:
            raise LifecycleError("ranker model card requires a verified runtime artifact mount")
        try:
            from pathlib import Path

            from learning.rankers import load_ranker_artifact

            load_ranker_artifact(
                Path(runtime_ref),
                expected_target=training_run.target,
                expected_digest=artifact_digest,
                model_version_id="registration_probe",
            )
        except Exception as exc:
            raise LifecycleError("ranker runtime artifact verification failed") from exc
    immutable_card = {
        **model_card,
        "artifact": {
            "ref": training_run.artifact_ref,
            "digest": artifact_digest,
        },
    }
    model = ModelVersion(
        id=new_resource_id("model"),
        training_run_id=training_run.id,
        tenant_id=training_run.tenant_id,
        name=name,
        target=training_run.target,
        state="CANDIDATE",
        digest=artifact_digest,
        licence_id=licence_id,
        model_card=immutable_card,
    )
    db.add(model)
    return model


def register_model_evaluation(
    db: Session,
    *,
    model: ModelVersion,
    evaluator: str,
    evaluator_version: str,
    benchmark_digest: str,
    artifact_digest: str,
    metrics: dict,
    signature: str,
    signing_key: str,
) -> ModelEvaluation:
    values = {
        "model_version_id": model.id,
        "evaluator": evaluator,
        "evaluator_version": evaluator_version,
        "benchmark_digest": benchmark_digest,
        "artifact_digest": artifact_digest,
        "metrics": metrics,
    }
    if artifact_digest != model.digest:
        raise LifecycleError("evaluation artifact digest does not match the model")
    if not verify_attestation(key=signing_key, signature=signature, **values):
        raise LifecycleError("evaluation attestation signature is invalid")
    evaluation = ModelEvaluation(
        id=new_resource_id("evaluation"),
        model_version_id=model.id,
        tenant_id=model.tenant_id,
        evaluator=evaluator,
        evaluator_version=evaluator_version,
        benchmark_digest=benchmark_digest,
        artifact_digest=artifact_digest,
        metrics=metrics,
        signature=signature.lower(),
        verified=True,
    )
    db.add(evaluation)
    return evaluation


def _verified_evaluation(
    model: ModelVersion, evaluation: ModelEvaluation | None
) -> dict:
    if evaluation is None or not evaluation.verified:
        raise LifecycleError("promotion requires verified evaluation evidence")
    if evaluation.model_version_id != model.id or evaluation.artifact_digest != model.digest:
        raise LifecycleError("evaluation evidence belongs to another model artifact")
    return dict(evaluation.metrics or {})


def evaluate_release_metrics(metrics: dict) -> list[str]:
    """Return blocking promotion reasons from frozen evaluation results."""
    failures: list[str] = []
    if metrics.get("critical_safety_regression") is not False:
        failures.append("critical_safety_result_missing_or_regressed")
    correctness_delta = metrics.get("executable_correctness_delta")
    if not isinstance(correctness_delta, (int, float)) or correctness_delta < -0.01:
        failures.append("executable_correctness_regression")
    privacy = metrics.get("privacy_tests")
    if not isinstance(privacy, dict) or not all(
        privacy.get(key) is True
        for key in ("memorization", "pii_extraction", "tenant_leakage")
    ):
        failures.append("privacy_tests_failed_or_missing")
    improved = metrics.get("primary_metric_improved") is True
    efficient = metrics.get("cost_or_latency_materially_reduced") is True
    noninferior = (
        isinstance(correctness_delta, (int, float)) and correctness_delta >= -0.01
    )
    if not improved and not (efficient and noninferior):
        failures.append("no_quality_or_efficiency_improvement")
    if metrics.get("frozen_benchmark") is not True:
        failures.append("frozen_benchmark_missing")
    if metrics.get("research_training_overlap") is not False:
        failures.append("research_dataset_overlap_not_ruled_out")
    return failures


def promote_model(
    db: Session,
    *,
    model: ModelVersion,
    target_state: str,
    evaluation: ModelEvaluation | None = None,
) -> ModelVersion:
    if target_state not in MODEL_STATES:
        raise LifecycleError("invalid model state")
    if target_state in {"REJECTED", "QUARANTINED", "RETIRED"}:
        model.state = target_state
        if target_state in {"QUARANTINED", "RETIRED"}:
            for deployment in (
                db.query(ModelDeployment)
                .filter_by(model_version_id=model.id, state="active")
                .all()
            ):
                deployment.state = "inactive"
                deployment.traffic_percent = 0
                deployment.ended_at = datetime.now(UTC)
        return model

    expected = {
        "EVALUATED": "CANDIDATE",
        "SHADOW": "EVALUATED",
        "CANARY": "SHADOW",
        "PRODUCTION": "CANARY",
    }
    if model.state != expected.get(target_state):
        raise LifecycleError(
            f"invalid transition {model.state} -> {target_state}"
        )
    metrics = _verified_evaluation(model, evaluation)
    failures = evaluate_release_metrics(metrics)
    if failures:
        raise LifecycleError("promotion blocked: " + ",".join(failures))
    model.model_card = {
        **dict(model.model_card),
        "evaluation": {"id": evaluation.id, "metrics": metrics},
    }
    model.state = target_state
    if target_state == "SHADOW":
        db.add(
            ModelDeployment(
                id=new_resource_id("deployment"),
                model_version_id=model.id,
                tenant_id=model.tenant_id,
                stage="shadow",
                traffic_percent=0,
                state="active",
                metrics={"evaluation_id": evaluation.id},
            )
        )
    elif target_state == "CANARY":
        for deployment in (
            db.query(ModelDeployment)
            .filter_by(model_version_id=model.id, stage="shadow", state="active")
            .all()
        ):
            deployment.state = "inactive"
            deployment.ended_at = datetime.now(UTC)
        db.add(
            ModelDeployment(
                id=new_resource_id("deployment"),
                model_version_id=model.id,
                tenant_id=model.tenant_id,
                stage="canary",
                traffic_percent=5,
                state="active",
                metrics={"evaluation_id": evaluation.id},
            )
        )
    elif target_state == "PRODUCTION":
        canary = (
            db.query(ModelDeployment)
            .filter_by(model_version_id=model.id, stage="canary", state="active")
            .order_by(ModelDeployment.created_at.desc())
            .first()
        )
        if canary is None or canary.traffic_percent != 25:
            model.state = "CANARY"
            raise LifecycleError("production requires successful 5% and 25% canaries")
        canary.state = "inactive"
        canary.ended_at = datetime.now(UTC)
        prior_production = (
            db.query(ModelDeployment)
            .join(ModelVersion, ModelVersion.id == ModelDeployment.model_version_id)
            .filter(
                ModelDeployment.stage == "production",
                ModelDeployment.state == "active",
                ModelVersion.target == model.target,
                ModelDeployment.tenant_id == model.tenant_id,
                ModelDeployment.model_version_id != model.id,
            )
            .all()
        )
        for deployment in prior_production:
            deployment.state = "inactive"
            deployment.traffic_percent = 0
            deployment.ended_at = datetime.now(UTC)
        db.add(
            ModelDeployment(
                id=new_resource_id("deployment"),
                model_version_id=model.id,
                tenant_id=model.tenant_id,
                stage="production",
                traffic_percent=100,
                state="active",
                metrics={**metrics, "evaluation_id": evaluation.id},
            )
        )
    return model


def advance_canary(
    deployment: ModelDeployment,
    *,
    model: ModelVersion,
    evaluation: ModelEvaluation,
) -> ModelDeployment:
    if (
        deployment.stage != "canary"
        or deployment.state != "active"
        or deployment.traffic_percent != 5
    ):
        raise LifecycleError("only an active 5% canary can advance")
    if deployment.model_version_id != model.id:
        raise LifecycleError("deployment belongs to another model")
    observed_metrics = _verified_evaluation(model, evaluation)
    failures = evaluate_release_metrics(observed_metrics)
    if failures:
        deployment.state = "inactive"
        deployment.traffic_percent = 0
        deployment.ended_at = datetime.now(UTC)
        deployment.metrics = {
            **observed_metrics,
            "evaluation_id": evaluation.id,
            "rollback_reasons": failures,
        }
        raise LifecycleError("canary rolled back: " + ",".join(failures))
    deployment.traffic_percent = 25
    deployment.metrics = {**observed_metrics, "evaluation_id": evaluation.id}
    return deployment
