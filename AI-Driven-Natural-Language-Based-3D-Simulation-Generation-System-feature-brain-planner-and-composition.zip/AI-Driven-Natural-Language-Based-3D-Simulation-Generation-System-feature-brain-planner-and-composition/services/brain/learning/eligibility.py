"""Fail-closed training eligibility evaluation.

This module is the only place allowed to move production content from
``quarantined`` to ``eligible``. Every missing signal is a denial.
"""

from __future__ import annotations

import hashlib
import hmac
from datetime import UTC, datetime

from core.config import get_settings
from core.models import (
    ConsentRecord,
    GuardianRelationship,
    Tenant,
    TrainingEligibility,
    User,
)
from sqlalchemy.orm import Session

TEEN_BANDS = {"13_15", "16_17", "teen"}


def _latest_consent(
    db: Session,
    *,
    subject_user_id: str,
    tenant_id: str,
    scope: str,
    category: str,
    kind: str,
) -> ConsentRecord | None:
    return (
        db.query(ConsentRecord)
        .filter_by(
            subject_user_id=subject_user_id,
            tenant_id=tenant_id,
            scope=scope,
            data_category=category,
            consent_kind=kind,
        )
        .order_by(ConsentRecord.created_at.desc(), ConsentRecord.id.desc())
        .first()
    )


def _pseudonym(owner_id: str, tenant_id: str) -> str | None:
    key = get_settings().training_pseudonym_key
    if not key:
        return None
    return hmac.new(
        key.encode("utf-8"),
        f"{tenant_id}:{owner_id}".encode(),
        hashlib.sha256,
    ).hexdigest()


def evaluate_eligibility(
    db: Session,
    eligibility: TrainingEligibility,
    *,
    data_category: str | None = None,
) -> TrainingEligibility:
    """Recompute one resource from authoritative current records."""
    category = data_category or eligibility.data_category
    if category not in {"prompt_spec", "telemetry", "assets"}:
        eligibility.status = "ineligible"
        eligibility.exclusion_reason = "data_category_invalid"
        return eligibility
    if eligibility.data_category != category:
        eligibility.status = "ineligible"
        eligibility.exclusion_reason = "data_category_mismatch"
        return eligibility
    eligibility.evaluated_at = datetime.now(UTC)
    eligibility.status = "ineligible"
    eligibility.exclusion_reason = None
    eligibility.consent_record_id = None
    eligibility.guardian_consent_record_id = None
    eligibility.pseudonym_key = None

    if eligibility.deleted:
        eligibility.exclusion_reason = "deleted"
        return eligibility
    if eligibility.legal_hold:
        eligibility.exclusion_reason = "legal_hold"
        return eligibility
    if eligibility.data_source not in {"production_user", "controlled", "synthetic"}:
        eligibility.exclusion_reason = "unapproved_source"
        return eligibility
    if eligibility.moderation_status != "approved":
        eligibility.exclusion_reason = "moderation_not_approved"
        return eligibility
    if eligibility.quality_status != "approved":
        eligibility.exclusion_reason = "quality_not_approved"
        return eligibility
    if not eligibility.content_right_id:
        eligibility.exclusion_reason = "content_rights_missing"
        return eligibility

    from core.models import ContentRight

    content_right = db.get(ContentRight, eligibility.content_right_id)
    if (
        content_right is None
        or not content_right.training_allowed
        or content_right.verified_at is None
    ):
        eligibility.exclusion_reason = "training_rights_not_verified"
        return eligibility

    tenant = db.get(Tenant, eligibility.tenant_id)
    allowed_policies = (
        {"global", "hybrid"}
        if eligibility.training_scope == "global"
        else {"private", "hybrid"}
    )
    if tenant is None or tenant.training_policy not in allowed_policies:
        eligibility.exclusion_reason = "tenant_policy_disabled"
        return eligibility

    own = _latest_consent(
        db,
        subject_user_id=eligibility.owner_id,
        tenant_id=eligibility.tenant_id,
        scope=eligibility.training_scope,
        category=category,
        kind="subject",
    )
    if own is None or not own.granted or own.withdrawn_at is not None:
        eligibility.exclusion_reason = "subject_consent_missing"
        return eligibility
    eligibility.consent_record_id = own.id

    user = db.get(User, eligibility.owner_id)
    if user is None or user.status != "active":
        eligibility.exclusion_reason = "user_not_active"
        return eligibility
    if user.age_band in {"unknown", "under_13"}:
        eligibility.exclusion_reason = "age_not_eligible"
        return eligibility
    if user.age_band in TEEN_BANDS:
        relationship = (
            db.query(GuardianRelationship)
            .filter_by(
                tenant_id=eligibility.tenant_id,
                minor_user_id=user.id,
                status="verified",
            )
            .filter(GuardianRelationship.revoked_at.is_(None))
            .first()
        )
        if relationship is None:
            eligibility.exclusion_reason = "verified_guardian_missing"
            return eligibility
        guardian = _latest_consent(
            db,
            subject_user_id=user.id,
            tenant_id=eligibility.tenant_id,
            scope=eligibility.training_scope,
            category=category,
            kind="guardian",
        )
        if (
            guardian is None
            or not guardian.granted
            or guardian.withdrawn_at is not None
            or guardian.guardian_relationship_id != relationship.id
        ):
            eligibility.exclusion_reason = "guardian_consent_missing"
            return eligibility
        eligibility.guardian_consent_record_id = guardian.id

    pseudonym = _pseudonym(eligibility.owner_id, eligibility.tenant_id)
    if pseudonym is None:
        eligibility.exclusion_reason = "pseudonym_key_unavailable"
        return eligibility

    eligibility.pseudonym_key = pseudonym
    eligibility.status = "eligible"
    return eligibility


def reevaluate_owner_resources(db: Session, owner_id: str, tenant_id: str) -> None:
    rows = (
        db.query(TrainingEligibility)
        .filter_by(owner_id=owner_id, tenant_id=tenant_id)
        .all()
    )
    for row in rows:
        evaluate_eligibility(db, row)
