"""Removal of consent-withdrawn/deleted records from training copies."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime

from core.ids import new_resource_id
from core.models import (
    DatasetItem,
    DatasetVersion,
    DeletionTombstone,
    ModelDeployment,
    ModelVersion,
    TrainingEligibility,
    TrainingRun,
)
from sqlalchemy.orm import Session


def _rehash_dataset(db: Session, dataset: DatasetVersion) -> None:
    items = (
        db.query(DatasetItem)
        .filter_by(dataset_version_id=dataset.id)
        .order_by(DatasetItem.content_hash)
        .all()
    )
    dataset.item_count = len(items)
    dataset.status = "withdrawal_rebuild_required"
    manifest = [
        {"content_hash": item.content_hash, "split": item.split, "target": item.target}
        for item in items
    ]
    dataset.manifest_hash = hashlib.sha256(
        json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def purge_training_copies(
    db: Session,
    *,
    owner_id: str,
    tenant_id: str,
    create_tombstones: bool,
    reason: str,
) -> dict:
    """Remove current dataset copies and quarantine every derived model.

    The caller must run with tenant RLS identity for private copies and a
    worker/service identity for global copies.
    """
    eligibility_rows = (
        db.query(TrainingEligibility)
        .filter_by(owner_id=owner_id, tenant_id=tenant_id)
        .all()
    )
    eligibility_ids = [row.id for row in eligibility_rows]
    if create_tombstones:
        for row in eligibility_rows:
            existing = (
                db.query(DeletionTombstone)
                .filter_by(
                    tenant_id=tenant_id,
                    resource_type=row.resource_type,
                    resource_id=row.resource_id,
                )
                .first()
            )
            if existing is None:
                db.add(
                    DeletionTombstone(
                        id=new_resource_id("tombstone"),
                        tenant_id=tenant_id,
                        owner_id=owner_id,
                        resource_type=row.resource_type,
                        resource_id=row.resource_id,
                        reason=reason,
                    )
                )

    items = (
        db.query(DatasetItem)
        .filter(DatasetItem.eligibility_id.in_(eligibility_ids))
        .all()
        if eligibility_ids
        else []
    )
    dataset_ids = {item.dataset_version_id for item in items}
    for item in items:
        db.delete(item)
    db.flush()

    affected_training_runs: list[TrainingRun] = []
    for dataset_id in dataset_ids:
        dataset = db.get(DatasetVersion, dataset_id)
        if dataset is None:
            continue
        _rehash_dataset(db, dataset)
        affected_training_runs.extend(
            db.query(TrainingRun).filter_by(dataset_version_id=dataset_id).all()
        )
    training_run_ids = {run.id for run in affected_training_runs}
    dataset_copy_refs: set[str] = set()
    for run in affected_training_runs:
        copy_ref = (run.config or {}).get("dataset_copy_ref") or (
            run.config or {}
        ).get("dataset_envelope_ref")
        if isinstance(copy_ref, str) and copy_ref:
            dataset_copy_refs.add(copy_ref)
        run.config = {
            **dict(run.config or {}),
            "dataset_copy_ref": None,
            "dataset_envelope_ref": None,
            "dataset_copy_deleted_at": datetime.now(UTC).isoformat(),
        }
        run.state = "QUARANTINED"
        run.metrics = {
            **dict(run.metrics or {}),
            "quarantine_reason": reason,
            "quarantined_at": datetime.now(UTC).isoformat(),
        }
    models = (
        db.query(ModelVersion)
        .filter(ModelVersion.training_run_id.in_(training_run_ids))
        .all()
        if training_run_ids
        else []
    )
    for model in models:
        model.state = "QUARANTINED"
        model.model_card = {
            **dict(model.model_card or {}),
            "quarantine_reason": reason,
            "quarantined_at": datetime.now(UTC).isoformat(),
        }
        for deployment in (
            db.query(ModelDeployment)
            .filter_by(model_version_id=model.id, state="active")
            .all()
        ):
            deployment.state = "inactive"
            deployment.traffic_percent = 0
            deployment.ended_at = datetime.now(UTC)
    return {
        "eligibility_records": len(eligibility_rows),
        "dataset_items_removed": len(items),
        "datasets_affected": len(dataset_ids),
        "models_quarantined": len(models),
        "dataset_copy_refs": sorted(dataset_copy_refs),
    }
