"""Consent-qualified dataset construction.

Dataset rows are immutable, sanitized snapshots. The builder re-evaluates every
eligibility record from authoritative consent/rights state immediately before
copying it and refuses unverified simulation outputs.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from core.ids import new_resource_id
from core.models import (
    ConsentRecord,
    ContentRight,
    DatasetItem,
    DatasetVersion,
    DeletionTombstone,
    FeedbackEvent,
    GenerationRun,
    ResearchExclusion,
    Simulation,
    SimulationSpecRecord,
    TrainingEligibility,
    UsageEvent,
    ValidationEvidence,
)
from sqlalchemy.orm import Session

from learning.eligibility import evaluate_eligibility

ALLOWED_TARGETS = {"planner", "asset_ranker", "placement_ranker"}
_EMAIL = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)
_PHONE = re.compile(r"(?<!\d)(?:\+?\d[\s().-]?){8,15}(?!\d)")
_GPS = re.compile(r"(?<!\d)-?\d{1,3}\.\d{4,}\s*[,/]\s*-?\d{1,3}\.\d{4,}(?!\d)")
_SECRET = re.compile(
    r"\b(?:api[_ -]?key|password|secret|private[_ -]?key|bearer)\b\s*[:=]\s*\S+",
    re.I,
)
_WORD = re.compile(r"[a-z][a-z0-9_-]{1,}")
_STOP = {
    "a",
    "an",
    "and",
    "as",
    "at",
    "build",
    "create",
    "for",
    "in",
    "of",
    "on",
    "simulate",
    "the",
    "to",
    "with",
}


class DatasetBuildError(RuntimeError):
    pass


@dataclass(frozen=True)
class _Candidate:
    eligibility: TrainingEligibility
    target: str
    payload: dict
    content_hash: str
    family_hash: str
    source_created_at: datetime
    consent_snapshot: dict
    rights_snapshot: dict


def prompt_fingerprint(prompt: str) -> str:
    normalized = " ".join(prompt.lower().split())
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def prompt_family_fingerprint(prompt: str) -> str:
    tokens = sorted(
        {
            token
            for token in _WORD.findall(prompt.lower())
            if token not in _STOP and not token.isdigit()
        }
    )
    return hashlib.sha256(" ".join(tokens).encode("utf-8")).hexdigest()


def _sanitize_text(value: str) -> str | None:
    if _SECRET.search(value) or _GPS.search(value):
        return None
    return _PHONE.sub("[PHONE_REMOVED]", _EMAIL.sub("[EMAIL_REMOVED]", value))


def _sanitize(value: Any) -> Any | None:
    if isinstance(value, str):
        return _sanitize_text(value)
    if isinstance(value, list):
        result = []
        for item in value:
            clean = _sanitize(item)
            if clean is None and item is not None:
                return None
            result.append(clean)
        return result
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            if str(key).lower() in {
                "email",
                "ip",
                "ip_address",
                "latitude",
                "longitude",
                "precise_location",
                "token",
                "credential",
            }:
                continue
            clean = _sanitize(item)
            if clean is None and item is not None:
                return None
            result[str(key)] = clean
        return result
    return value


def _consent_snapshot(db: Session, row: TrainingEligibility) -> dict | None:
    subject = db.get(ConsentRecord, row.consent_record_id)
    if subject is None:
        return None
    guardian = (
        db.get(ConsentRecord, row.guardian_consent_record_id)
        if row.guardian_consent_record_id
        else None
    )
    return {
        "captured_at": datetime.now(UTC).isoformat(),
        "scope": row.training_scope,
        "data_category": row.data_category,
        "subject": {
            "record_id": subject.id,
            "granted": subject.granted,
            "disclosure_version": subject.disclosure_version,
            "locale": subject.locale,
            "created_at": subject.created_at.isoformat(),
        },
        "guardian": (
            {
                "record_id": guardian.id,
                "granted": guardian.granted,
                "disclosure_version": guardian.disclosure_version,
                "created_at": guardian.created_at.isoformat(),
            }
            if guardian
            else None
        ),
    }


def _rights_snapshot(db: Session, row: TrainingEligibility) -> dict | None:
    right = db.get(ContentRight, row.content_right_id)
    if right is None or not right.training_allowed or right.verified_at is None:
        return None
    return {
        "record_id": right.id,
        "basis": right.rights_basis,
        "licence_id": right.licence_id,
        "training_allowed": right.training_allowed,
        "verified_at": right.verified_at.isoformat(),
    }


def _verified_planner_payload(
    db: Session, row: TrainingEligibility
) -> tuple[dict, str, datetime] | None:
    spec = db.get(SimulationSpecRecord, row.resource_id)
    if spec is None or spec.tenant_id != row.tenant_id or spec.owner_id != row.owner_id:
        return None
    run = (
        db.query(GenerationRun)
        .filter_by(spec_id=spec.id, tenant_id=row.tenant_id, state="completed")
        .order_by(GenerationRun.completed_at.desc())
        .first()
    )
    if run is None:
        return None
    evidence = (
        db.query(ValidationEvidence)
        .filter_by(run_id=run.id, mandatory=True)
        .all()
    )
    if not evidence or any(item.status != "PASS" for item in evidence):
        return None
    simulation = db.get(Simulation, spec.simulation_id)
    if simulation is None:
        return None
    prompt = _sanitize_text(simulation.prompt)
    body = _sanitize(spec.body)
    if prompt is None or body is None:
        return None
    return (
        {
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "You are the Serendib simulation planner. Emit only a "
                        "valid canonical SimulationSpec JSON object."
                    ),
                },
                {"role": "user", "content": prompt},
                {
                    "role": "assistant",
                    "content": json.dumps(body, sort_keys=True, separators=(",", ":")),
                },
            ],
            "provenance": {
                "spec_hash": spec.spec_hash,
                "planner_model": spec.planner_model,
                "mandatory_validation_count": len(evidence),
            },
        },
        prompt,
        spec.created_at,
    )


def _feedback_payload(
    db: Session, row: TrainingEligibility, target: str
) -> tuple[dict, str, datetime] | None:
    feedback = db.get(FeedbackEvent, row.resource_id)
    if (
        feedback is None
        or feedback.tenant_id != row.tenant_id
        or feedback.owner_id != row.owner_id
    ):
        return None
    allowed = {
        "asset_ranker": {"asset_choice", "pairwise_preference"},
        "placement_ranker": {"placement_correction", "pairwise_preference"},
    }
    if feedback.kind not in allowed[target]:
        return None
    if (
        feedback.kind == "pairwise_preference"
        and (feedback.payload or {}).get("_learning_target") != target
    ):
        return None
    clean = _sanitize(feedback.payload)
    if not isinstance(clean, dict) or not clean:
        return None
    family_source = json.dumps(clean, sort_keys=True)
    return (
        {
            "feedback_kind": feedback.kind,
            "rating": feedback.rating,
            "features": clean,
            "simulation_id_hash": (
                hashlib.sha256(feedback.simulation_id.encode("utf-8")).hexdigest()
                if feedback.simulation_id
                else None
            ),
        },
        family_source,
        feedback.created_at,
    )


def _telemetry_payload(
    db: Session, row: TrainingEligibility
) -> tuple[dict, str, datetime] | None:
    event = db.get(UsageEvent, row.resource_id)
    if (
        event is None
        or event.tenant_id != row.tenant_id
        or event.owner_id != row.owner_id
        or event.event_type != "placement_adjusted"
    ):
        return None
    clean = _sanitize(event.payload)
    if not isinstance(clean, dict) or not clean:
        return None
    # The trainer accepts only explicit chosen/rejected candidates. Navigation
    # and interaction events remain useful product telemetry but cannot become
    # ranking labels merely because an event was successful.
    has_pair = (
        isinstance(
            clean.get("chosen") or clean.get("selected") or clean.get("accepted"),
            dict,
        )
        and isinstance(
            clean.get("rejected_candidates") or clean.get("rejected"),
            (dict, list),
        )
    ) or (
        isinstance(clean.get("candidate_a"), dict)
        and isinstance(clean.get("candidate_b"), dict)
        and clean.get("preferred") in {"a", "b"}
    )
    if not has_pair:
        return None
    family_source = json.dumps(clean, sort_keys=True)
    return (
        {
            "feedback_kind": "placement_telemetry",
            "rating": None,
            "features": clean,
            "simulation_id_hash": (
                hashlib.sha256(event.simulation_id.encode("utf-8")).hexdigest()
                if event.simulation_id
                else None
            ),
        },
        family_source,
        event.created_at,
    )


def _candidate(
    db: Session, row: TrainingEligibility, target: str
) -> _Candidate | None:
    evaluate_eligibility(db, row)
    if row.status != "eligible" or not row.pseudonym_key:
        return None
    if (
        db.query(DeletionTombstone)
        .filter_by(
            tenant_id=row.tenant_id,
            resource_type=row.resource_type,
            resource_id=row.resource_id,
        )
        .first()
        is not None
    ):
        return None
    if target == "planner" and row.resource_type == "simulation_spec":
        loaded = _verified_planner_payload(db, row)
    elif target in {"asset_ranker", "placement_ranker"} and row.resource_type == "feedback":
        loaded = _feedback_payload(db, row, target)
    elif target == "placement_ranker" and row.resource_type == "usage_event":
        loaded = _telemetry_payload(db, row)
    else:
        return None
    if loaded is None:
        return None
    payload, family_source, source_created_at = loaded
    family = prompt_family_fingerprint(family_source)
    excluded = (
        db.query(ResearchExclusion)
        .filter(
            ResearchExclusion.active.is_(True),
            ResearchExclusion.fingerprint.in_(
                [prompt_fingerprint(family_source), family]
            ),
        )
        .first()
    )
    if excluded is not None:
        return None
    consent = _consent_snapshot(db, row)
    rights = _rights_snapshot(db, row)
    if consent is None or rights is None:
        return None
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    return _Candidate(
        eligibility=row,
        target=target,
        payload=payload,
        content_hash=hashlib.sha256(canonical.encode("utf-8")).hexdigest(),
        family_hash=family,
        source_created_at=source_created_at,
        consent_snapshot=consent,
        rights_snapshot=rights,
    )


def _strict_splits(candidates: list[_Candidate]) -> tuple[dict[str, str], int]:
    """Return content-hash splits with user/tenant/family/time leakage blocked.

    A temporal holdout contains only users, tenants and prompt families first
    observed after the cutoff. Recent rows sharing a pre-cutoff group are
    excluded from the frozen dataset instead of leaking across the boundary.
    """
    if len(candidates) < 10:
        return ({item.content_hash: "train" for item in candidates}, 0)
    ordered = sorted(candidates, key=lambda item: item.source_created_at)
    cutoff = ordered[max(1, int(len(ordered) * 0.8)) - 1].source_created_at
    early = [item for item in ordered if item.source_created_at <= cutoff]
    late = [item for item in ordered if item.source_created_at > cutoff]
    seen_tenants = {item.eligibility.tenant_id for item in early}
    seen_users = {item.eligibility.pseudonym_key for item in early}
    seen_families = {item.family_hash for item in early}
    result = {item.content_hash: "train" for item in early}
    excluded = 0
    for item in late:
        if (
            item.eligibility.tenant_id in seen_tenants
            or item.eligibility.pseudonym_key in seen_users
            or item.family_hash in seen_families
        ):
            excluded += 1
            continue
        bucket = int(item.content_hash[:8], 16) % 2
        result[item.content_hash] = "validation" if bucket == 0 else "test"
    return result, excluded


def build_dataset_version(
    db: Session,
    *,
    scope: str,
    target: str,
    tenant_id: str | None,
) -> DatasetVersion:
    if scope not in {"global", "tenant_private"}:
        raise DatasetBuildError("unsupported dataset scope")
    if target not in ALLOWED_TARGETS:
        raise DatasetBuildError("unsupported learning target")
    if scope == "global" and tenant_id is not None:
        raise DatasetBuildError("global datasets cannot be tenant-bound")
    if scope == "tenant_private" and not tenant_id:
        raise DatasetBuildError("private datasets require a tenant")

    query = db.query(TrainingEligibility).filter_by(
        training_scope=scope,
        status="eligible",
        deleted=False,
        legal_hold=False,
    )
    if tenant_id:
        query = query.filter_by(tenant_id=tenant_id)
    candidates = [
        candidate
        for row in query.all()
        if (candidate := _candidate(db, row, target)) is not None
    ]
    deduped = {candidate.content_hash: candidate for candidate in candidates}
    splits, leakage_exclusions = _strict_splits(list(deduped.values()))
    selected = [
        candidate
        for candidate in deduped.values()
        if candidate.content_hash in splits
    ]
    version = DatasetVersion(
        id=new_resource_id("dataset"),
        tenant_id=tenant_id,
        scope=scope,
        target=target,
        status="frozen",
        split_policy_version="strict-v1",
        item_count=len(selected),
        metadata_json={
            "leakage_exclusions": leakage_exclusions,
            "eligible_candidates": len(candidates),
            "deduplicated_candidates": len(deduped),
            "builder_version": "1.0.0",
        },
        frozen_at=datetime.now(UTC),
    )
    db.add(version)
    db.flush()
    manifest_rows = []
    for candidate in sorted(selected, key=lambda item: item.content_hash):
        row = candidate.eligibility
        split = splits[candidate.content_hash]
        db.add(
            DatasetItem(
                id=new_resource_id("dataset_item"),
                dataset_version_id=version.id,
                eligibility_id=row.id,
                tenant_id=row.tenant_id,
                target=target,
                owner_pseudonym=row.pseudonym_key,
                prompt_family_hash=candidate.family_hash,
                time_bucket=candidate.source_created_at.strftime("%Y-%m"),
                content_hash=candidate.content_hash,
                split=split,
                consent_snapshot=candidate.consent_snapshot,
                rights_snapshot=candidate.rights_snapshot,
                sanitized_payload=candidate.payload,
                source_created_at=candidate.source_created_at,
            )
        )
        manifest_rows.append(
            {
                "content_hash": candidate.content_hash,
                "split": split,
                "target": target,
            }
        )
    manifest = {
        "dataset_id": version.id,
        "scope": scope,
        "tenant_id": tenant_id,
        "target": target,
        "split_policy_version": version.split_policy_version,
        "items": manifest_rows,
    }
    version.manifest_hash = hashlib.sha256(
        json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    db.flush()
    return version
