"""Cryptographic boundary for model evaluation results."""

from __future__ import annotations

import hashlib
import hmac
import json


def attestation_payload(
    *,
    model_version_id: str,
    evaluator: str,
    evaluator_version: str,
    benchmark_digest: str,
    artifact_digest: str,
    metrics: dict,
) -> bytes:
    body = {
        "artifact_digest": artifact_digest,
        "benchmark_digest": benchmark_digest,
        "evaluator": evaluator,
        "evaluator_version": evaluator_version,
        "metrics": metrics,
        "model_version_id": model_version_id,
    }
    return json.dumps(body, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sign_attestation(*, key: str, **values) -> str:
    if len(key) < 32:
        raise ValueError("evaluation signing key must contain at least 32 characters")
    return hmac.new(
        key.encode("utf-8"), attestation_payload(**values), hashlib.sha256
    ).hexdigest()


def verify_attestation(*, key: str, signature: str, **values) -> bool:
    if len(key) < 32:
        return False
    expected = sign_attestation(key=key, **values)
    return hmac.compare_digest(expected, signature.lower())
