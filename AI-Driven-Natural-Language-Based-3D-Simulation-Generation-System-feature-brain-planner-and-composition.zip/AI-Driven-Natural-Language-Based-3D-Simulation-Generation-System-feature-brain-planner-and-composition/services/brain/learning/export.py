"""Reproducible, fail-closed export of frozen governed dataset snapshots.

Only the already-sanitized payload is written. Authoritative consent, rights,
deletion, research-exclusion and manifest state are checked again immediately
before export so a stale frozen row cannot enter a trainer.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
from pathlib import Path

from core.models import (
    DatasetItem,
    DatasetVersion,
    DeletionTombstone,
    ResearchExclusion,
    TrainingEligibility,
)
from sqlalchemy.orm import Session

from learning.eligibility import evaluate_eligibility

_SAFE_ID = re.compile(r"^[a-zA-Z0-9_-]{1,80}$")
_SPLITS = ("train", "validation", "test")


class DatasetExportError(RuntimeError):
    pass


def _canonical_hash(payload: dict) -> str:
    encoded = json.dumps(
        payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _manifest(dataset: DatasetVersion, items: list[DatasetItem]) -> dict:
    return {
        "dataset_id": dataset.id,
        "scope": dataset.scope,
        "tenant_id": dataset.tenant_id,
        "target": dataset.target,
        "split_policy_version": dataset.split_policy_version,
        "items": [
            {
                "content_hash": item.content_hash,
                "split": item.split,
                "target": item.target,
            }
            for item in sorted(items, key=lambda row: row.content_hash)
        ],
    }


def _revalidate_item(db: Session, dataset: DatasetVersion, item: DatasetItem) -> None:
    if item.target != dataset.target or item.split not in _SPLITS:
        raise DatasetExportError("dataset item target or split is invalid")
    if _canonical_hash(item.sanitized_payload) != item.content_hash:
        raise DatasetExportError("dataset item content hash mismatch")
    eligibility = db.get(TrainingEligibility, item.eligibility_id)
    if eligibility is None:
        raise DatasetExportError("dataset item eligibility is missing")
    evaluate_eligibility(db, eligibility)
    if eligibility.status != "eligible":
        raise DatasetExportError("dataset item is no longer training eligible")
    if eligibility.tenant_id != item.tenant_id:
        raise DatasetExportError("dataset item tenant snapshot mismatch")
    if dataset.scope == "global" and eligibility.training_scope != "global":
        raise DatasetExportError("private eligibility entered a global dataset")
    if (
        dataset.scope == "tenant_private"
        and (
            eligibility.training_scope != "tenant_private"
            or eligibility.tenant_id != dataset.tenant_id
        )
    ):
        raise DatasetExportError("cross-tenant item entered a private dataset")
    if (
        db.query(DeletionTombstone)
        .filter_by(
            tenant_id=eligibility.tenant_id,
            resource_type=eligibility.resource_type,
            resource_id=eligibility.resource_id,
        )
        .first()
        is not None
    ):
        raise DatasetExportError("deleted content cannot be exported")
    if (
        db.query(ResearchExclusion)
        .filter_by(fingerprint=item.prompt_family_hash, active=True)
        .first()
        is not None
    ):
        raise DatasetExportError("research holdout content cannot be exported")


def validate_frozen_dataset(
    db: Session, dataset: DatasetVersion
) -> list[DatasetItem]:
    if dataset.status != "frozen" or not dataset.manifest_hash:
        raise DatasetExportError("dataset is not an immutable frozen snapshot")
    items = (
        db.query(DatasetItem)
        .filter_by(dataset_version_id=dataset.id)
        .order_by(DatasetItem.content_hash)
        .all()
    )
    if not items or len(items) != dataset.item_count:
        raise DatasetExportError("dataset item count is empty or inconsistent")
    for item in items:
        _revalidate_item(db, dataset, item)
    actual = _canonical_hash(_manifest(dataset, items))
    if actual != dataset.manifest_hash:
        raise DatasetExportError("dataset manifest hash mismatch")
    return items


def export_frozen_dataset(
    db: Session,
    *,
    dataset: DatasetVersion,
    export_root: Path,
) -> dict:
    """Atomically write split JSONL and a signed-input manifest.

    ``export_root`` must be an operator-controlled training workspace. The
    dataset id is validated before it becomes a path component.
    """
    if not _SAFE_ID.fullmatch(dataset.id):
        raise DatasetExportError("unsafe dataset identifier")
    items = validate_frozen_dataset(db, dataset)
    root = export_root.resolve()
    root.mkdir(parents=True, exist_ok=True)
    output = (root / dataset.id).resolve()
    if output.parent != root:
        raise DatasetExportError("dataset export escaped the training workspace")
    temporary = (root / f".{dataset.id}.{os.getpid()}.tmp").resolve()
    if temporary.parent != root:
        raise DatasetExportError("temporary export escaped the training workspace")
    if temporary.exists():
        shutil.rmtree(temporary)
    temporary.mkdir()
    try:
        counts: dict[str, int] = {}
        hashes: dict[str, str] = {}
        for split in _SPLITS:
            path = temporary / f"{split}.jsonl"
            split_items = [item for item in items if item.split == split]
            with path.open("w", encoding="utf-8", newline="\n") as handle:
                for item in split_items:
                    record = {
                        **item.sanitized_payload,
                        "meta": {
                            "content_hash": item.content_hash,
                            "target": item.target,
                            "split": item.split,
                            "dataset_manifest_hash": dataset.manifest_hash,
                        },
                    }
                    handle.write(
                        json.dumps(
                            record,
                            sort_keys=True,
                            separators=(",", ":"),
                            ensure_ascii=False,
                        )
                        + "\n"
                    )
            counts[split] = len(split_items)
            hashes[path.name] = _file_hash(path)
        export_manifest = {
            **_manifest(dataset, items),
            "manifest_hash": dataset.manifest_hash,
            "counts": counts,
            "files": hashes,
            "contains_user_identifiers": False,
            "tenant_scope_identifier_in_manifest": dataset.tenant_id is not None,
        }
        manifest_path = temporary / "manifest.json"
        manifest_path.write_text(
            json.dumps(export_manifest, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
            newline="\n",
        )
        if output.exists():
            shutil.rmtree(output)
        temporary.replace(output)
    except Exception:
        if temporary.exists():
            shutil.rmtree(temporary)
        raise
    return {
        "dataset_version_id": dataset.id,
        "target": dataset.target,
        "path": str(output),
        "manifest_hash": dataset.manifest_hash,
        "counts": counts,
        "files": hashes,
    }
