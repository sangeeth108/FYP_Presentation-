"""Streaming KMS envelope encryption for governed datasets and model artifacts."""

from __future__ import annotations

import base64
import hashlib
import json
import os
import shutil
from pathlib import Path

_MAGIC = b"SERENDIB-KMS-1\n"
_TAG_BYTES = 16


class KmsEnvelopeCipher:
    def __init__(self, *, region: str = "", endpoint_url: str = "") -> None:
        import boto3

        options = {}
        if region:
            options["region_name"] = region
        if endpoint_url:
            options["endpoint_url"] = endpoint_url
        self.client = boto3.client("kms", **options)

    def encrypt_file(self, source: Path, destination: Path, *, key_id: str) -> None:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

        if source.is_symlink() or not source.is_file():
            raise ValueError("envelope source must be a regular file")
        generated = self.client.generate_data_key(KeyId=key_id, KeySpec="AES_256")
        plaintext_key = bytearray(generated["Plaintext"])
        nonce = os.urandom(12)
        header = json.dumps(
            {
                "encrypted_data_key": base64.b64encode(
                    generated["CiphertextBlob"]
                ).decode("ascii"),
                "key_id": key_id,
                "nonce": base64.b64encode(nonce).decode("ascii"),
                "source_name": source.name,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        encryptor = Cipher(
            algorithms.AES(bytes(plaintext_key)), modes.GCM(nonce)
        ).encryptor()
        encryptor.authenticate_additional_data(header)
        destination.parent.mkdir(parents=True, exist_ok=True)
        try:
            with source.open("rb") as reader, destination.open("wb") as writer:
                writer.write(_MAGIC)
                writer.write(len(header).to_bytes(4, "big"))
                writer.write(header)
                for block in iter(lambda: reader.read(1024 * 1024), b""):
                    writer.write(encryptor.update(block))
                writer.write(encryptor.finalize())
                writer.write(encryptor.tag)
        finally:
            for index in range(len(plaintext_key)):
                plaintext_key[index] = 0

    def decrypt_file(self, source: Path, destination: Path) -> None:
        from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

        size = source.stat().st_size
        with source.open("rb") as reader:
            if reader.read(len(_MAGIC)) != _MAGIC:
                raise ValueError("unsupported envelope format")
            header_size = int.from_bytes(reader.read(4), "big")
            if not 16 <= header_size <= 64_000:
                raise ValueError("invalid envelope header length")
            header = reader.read(header_size)
            body = json.loads(header)
            ciphertext_offset = len(_MAGIC) + 4 + header_size
            ciphertext_size = size - ciphertext_offset - _TAG_BYTES
            if ciphertext_size < 0:
                raise ValueError("truncated envelope")
            reader.seek(size - _TAG_BYTES)
            tag = reader.read(_TAG_BYTES)
            decrypted_key = self.client.decrypt(
                CiphertextBlob=base64.b64decode(body["encrypted_data_key"]),
                KeyId=body["key_id"],
            )["Plaintext"]
            plaintext_key = bytearray(decrypted_key)
            decryptor = Cipher(
                algorithms.AES(bytes(plaintext_key)),
                modes.GCM(base64.b64decode(body["nonce"]), tag),
            ).decryptor()
            decryptor.authenticate_additional_data(header)
            reader.seek(ciphertext_offset)
            remaining = ciphertext_size
            destination.parent.mkdir(parents=True, exist_ok=True)
            try:
                with destination.open("wb") as writer:
                    while remaining:
                        block = reader.read(min(1024 * 1024, remaining))
                        if not block:
                            raise ValueError("truncated encrypted payload")
                        remaining -= len(block)
                        writer.write(decryptor.update(block))
                    writer.write(decryptor.finalize())
            finally:
                for index in range(len(plaintext_key)):
                    plaintext_key[index] = 0


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def seal_directory(
    source: Path, destination: Path, *, cipher: KmsEnvelopeCipher, key_id: str
) -> dict:
    source = source.resolve()
    destination = destination.resolve()
    temporary = destination.with_name(f".{destination.name}.{os.getpid()}.tmp")
    if temporary.exists():
        shutil.rmtree(temporary)
    temporary.mkdir(parents=True)
    files = []
    try:
        for path in sorted(item for item in source.rglob("*") if item.is_file()):
            if path.is_symlink():
                raise ValueError("encrypted artifacts cannot contain symbolic links")
            relative = path.relative_to(source)
            encrypted_relative = Path(str(relative) + ".kms")
            target = temporary / encrypted_relative
            cipher.encrypt_file(path, target, key_id=key_id)
            files.append(
                {
                    "encrypted_path": encrypted_relative.as_posix(),
                    "plaintext_path": relative.as_posix(),
                    "plaintext_sha256": _hash(path),
                }
            )
        manifest = {"format": "serendib_kms_directory_v1", "key_id": key_id, "files": files}
        (temporary / "envelope_manifest.json").write_text(
            json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        if destination.exists():
            shutil.rmtree(destination)
        temporary.replace(destination)
        return manifest
    except Exception:
        if temporary.exists():
            shutil.rmtree(temporary)
        raise


def unseal_directory(
    source: Path, destination: Path, *, cipher: KmsEnvelopeCipher
) -> None:
    manifest = json.loads((source / "envelope_manifest.json").read_text(encoding="utf-8"))
    if manifest.get("format") != "serendib_kms_directory_v1":
        raise ValueError("invalid encrypted directory manifest")
    destination = destination.resolve()
    temporary = destination.with_name(f".{destination.name}.{os.getpid()}.tmp")
    if destination.exists() or temporary.exists():
        raise FileExistsError("unseal destination already exists")
    temporary.mkdir(parents=True)
    try:
        for item in manifest.get("files", []):
            encrypted = (source / item["encrypted_path"]).resolve()
            output = (temporary / item["plaintext_path"]).resolve()
            if source.resolve() not in encrypted.parents or temporary not in output.parents:
                raise ValueError("encrypted directory path traversal detected")
            cipher.decrypt_file(encrypted, output)
            if _hash(output) != item["plaintext_sha256"]:
                raise ValueError("decrypted artifact hash mismatch")
        temporary.replace(destination)
    except Exception:
        if temporary.exists():
            shutil.rmtree(temporary)
        raise
