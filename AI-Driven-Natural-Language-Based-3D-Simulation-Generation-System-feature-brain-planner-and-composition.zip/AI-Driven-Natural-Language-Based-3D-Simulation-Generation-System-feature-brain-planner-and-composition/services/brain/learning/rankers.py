"""Safe inference for consent-qualified asset and placement rankers.

Rankers only order candidates that already passed deterministic hard gates. The
artifact is JSON, never pickle or model-generated executable code.
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path


def _tree_digest(root: Path) -> str:
    digest = hashlib.sha256()
    files = sorted(path for path in root.rglob("*") if path.is_file())
    if not files:
        raise ValueError("ranker artifact directory is empty")
    for path in files:
        if path.is_symlink():
            raise ValueError("ranker artifacts cannot contain symbolic links")
        relative = path.relative_to(root).as_posix().encode("utf-8")
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
    return "sha256:" + digest.hexdigest()


def _flatten(value: dict, prefix: str = "") -> dict[str, float]:
    result: dict[str, float] = {}
    for key, item in sorted(value.items()):
        name = f"{prefix}.{key}" if prefix else str(key)
        if isinstance(item, bool):
            result[name] = 1.0 if item else 0.0
        elif isinstance(item, (int, float)) and math.isfinite(float(item)):
            result[name] = float(item)
        elif isinstance(item, dict):
            result.update(_flatten(item, name))
    return result


@dataclass(frozen=True)
class LinearRanker:
    target: str
    feature_names: tuple[str, ...]
    weights: tuple[float, ...]
    model_version_id: str
    model_digest: str

    def score(self, features: dict) -> float:
        flattened = _flatten(features)
        return sum(
            weight * flattened.get(name, 0.0)
            for name, weight in zip(self.feature_names, self.weights, strict=True)
        )


def load_ranker_artifact(
    artifact_dir: Path,
    *,
    expected_target: str,
    expected_digest: str,
    model_version_id: str,
) -> LinearRanker:
    artifact_dir = artifact_dir.resolve()
    if _tree_digest(artifact_dir) != expected_digest:
        raise ValueError("ranker artifact digest verification failed")
    ranker_path = artifact_dir / "ranker.json"
    if not ranker_path.is_file() or ranker_path.stat().st_size > 5_000_000:
        raise ValueError("ranker.json is missing or exceeds the size limit")
    body = json.loads(ranker_path.read_text(encoding="utf-8"))
    names = body.get("feature_names")
    weights = body.get("weights")
    if (
        body.get("format") != "serendib_pairwise_linear_v1"
        or body.get("target") != expected_target
        or body.get("hard_constraints_must_be_pre_filtered") is not True
        or not isinstance(names, list)
        or not isinstance(weights, list)
        or len(names) != len(weights)
        or not 1 <= len(names) <= 2048
        or not all(isinstance(name, str) and 0 < len(name) <= 160 for name in names)
        or not all(isinstance(value, (int, float)) and math.isfinite(value) for value in weights)
    ):
        raise ValueError("ranker artifact contract is invalid")
    return LinearRanker(
        target=expected_target,
        feature_names=tuple(names),
        weights=tuple(float(value) for value in weights),
        model_version_id=model_version_id,
        model_digest=expected_digest,
    )


def load_active_ranker(
    target: str, *, tenant_id: str | None, routing_key: str
) -> LinearRanker | None:
    if target not in {"asset_ranker", "placement_ranker"}:
        raise ValueError("unsupported ranker target")
    try:
        from core import db
        from core.models import ModelDeployment, ModelVersion
        from sqlalchemy import or_

        with db.session_scope() as session:
            query = (
                session.query(ModelDeployment, ModelVersion)
                .join(ModelVersion, ModelVersion.id == ModelDeployment.model_version_id)
                .filter(
                    ModelDeployment.state == "active",
                    ModelDeployment.stage.in_(("production", "canary")),
                    ModelVersion.state.in_(("PRODUCTION", "CANARY")),
                    ModelVersion.target == target,
                )
            )
            if tenant_id is None:
                query = query.filter(ModelDeployment.tenant_id.is_(None))
                scopes = (None,)
            else:
                query = query.filter(
                    or_(
                        ModelDeployment.tenant_id == tenant_id,
                        ModelDeployment.tenant_id.is_(None),
                    )
                )
                scopes = (tenant_id, None)
            rows = query.order_by(ModelDeployment.created_at.desc()).all()
            selected = None
            for scope in scopes:
                scoped = [row for row in rows if row[0].tenant_id == scope]
                canary = next((row for row in scoped if row[0].stage == "canary"), None)
                production = next(
                    (row for row in scoped if row[0].stage == "production"), None
                )
                selected = production
                if canary is not None:
                    bucket = int(
                        hashlib.sha256(
                            f"{tenant_id}:{target}:{routing_key}".encode()
                        ).hexdigest()[:8],
                        16,
                    ) % 100
                    if bucket < canary[0].traffic_percent:
                        selected = canary
                if selected is not None:
                    break
            if selected is None:
                return None
            _, model = selected
            card = model.model_card or {}
            artifact_ref = (card.get("runtime") or {}).get("artifact_ref") or (
                card.get("artifact") or {}
            ).get("ref")
            if not artifact_ref:
                return None
            return load_ranker_artifact(
                Path(artifact_ref),
                expected_target=target,
                expected_digest=model.digest,
                model_version_id=model.id,
            )
    except Exception:
        return None
