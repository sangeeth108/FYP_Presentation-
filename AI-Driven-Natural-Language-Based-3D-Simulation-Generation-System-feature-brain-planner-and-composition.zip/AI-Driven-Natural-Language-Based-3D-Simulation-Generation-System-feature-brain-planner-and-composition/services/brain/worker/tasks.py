"""The generation pipeline as the Celery job (replaces the P0 hello-job).

P1 scope — NO LLM: the frozen golden spec stands in for the planner (S2
arrives in P2 with guided decoding); the user's prompt/seed personalize
``meta.title`` / ``meta.seed`` so every job builds a distinct, deterministic
world. Below the spec everything is the deterministic spine:

  S3  jsonschema validation against the frozen v2 schema
  S4  seeded PCG (zone graph -> layout -> placement -> level plan)
  S6  Godot project assembly    (only when GODOT_BIN is configured)
  S7  headless WebGL2 export    (only when GODOT_BIN is configured)
  S8  publish build under artifacts/<game_id>/ (served at /artifacts)

Job states advance per stage so the progress UI shows real phases. Every
failure lands in FAILED with a machine-readable {code, path, message, hint}.
"""

from __future__ import annotations

import hashlib
import json
import logging
import shutil
import sys
from datetime import UTC
from pathlib import Path

from core import db
from core.config import get_settings
from core.models import Game, Job, JobState

from worker.celery_app import celery_app

log = logging.getLogger(__name__)
_REPO_ROOT = Path(__file__).resolve().parents[3]


def _spec_path(settings) -> Path:
    if settings.spec_path:
        return Path(settings.spec_path)
    return _REPO_ROOT / "contracts" / "examples" / "golden_game.spec.json"


def _deploy_serendib_assist(project_dir: Path) -> None:
    """Copy the Serendib Assist addon into the downloadable project and enable it,
    so opening the project in Serendib shows the AI-edit dock (the P3 round-trip).

    The addon is pure @tool editor UI + HTTP + file I/O; it never runs at game
    runtime and executes no generated code.
    """
    src = _REPO_ROOT / "engine" / "serendib" / "assist"
    if not src.is_dir():
        return
    dest = project_dir / "addons" / "serendib_assist"
    dest.mkdir(parents=True, exist_ok=True)
    for name in ("plugin.cfg", "serendib_assist.gd", "assist_dock.gd"):
        if (src / name).is_file():
            shutil.copy2(src / name, dest / name)

    project_godot = project_dir / "project.godot"
    if project_godot.is_file():
        text = project_godot.read_text(encoding="utf-8")
        if "serendib_assist/plugin.cfg" not in text:
            text += (
                '\n[editor_plugins]\n\n'
                'enabled=PackedStringArray("res://addons/serendib_assist/plugin.cfg")\n'
            )
            project_godot.write_text(text, encoding="utf-8")


def _schema_path() -> Path:
    return _REPO_ROOT / "contracts" / "game_spec.schema.json"


def _templates_dir(settings) -> Path:
    if settings.templates_dir:
        return Path(settings.templates_dir)
    return _REPO_ROOT / "engine" / "templates"


def _set_state(job_id: str, state: JobState, **detail_updates) -> None:
    with db.session_scope() as session:
        job = session.get(Job, job_id)
        if job is None:
            return
        job.state = state.value
        detail = dict(job.detail or {})
        detail.update(detail_updates)
        job.detail = detail


def _store_spec(
    job_id: str,
    game_id: str,
    spec: dict,
    spec_hash: str,
    brief_source: str,
    settings,
    *,
    data_source: str = "legacy_unclassified",
    training_eligible: bool = False,
) -> None:
    """Persist the frozen spec (docs/DATABASE_SCHEMA.md `specs`).

    This is the P4 distillation set accumulating as a byproduct of ordinary use:
    `games.prompt` -> this body is exactly the pair a fine-tune trains on, and the
    validator verdict on the job says which pairs are worth training on. A spec not
    stored today can never be recovered, so this runs on every job, LLM or rules —
    the rules rows are the control group.

    Never fails a job: a game that built is a game that built, whether or not we
    managed to file its paperwork.
    """
    from core.models import Spec

    try:
        with db.session_scope() as session:
            if session.get(Spec, job_id) is not None:
                return  # a retried job re-freezes the same spec; keep the first
            game = session.get(Game, game_id)
            session.add(
                Spec(
                    id=job_id,
                    game_id=game_id,
                    job_id=job_id,
                    schema_version=spec.get("schema_version", ""),
                    spec_hash=spec_hash,
                    brief_source=brief_source,
                    planner_model=settings.llm_model if brief_source == "llm" else None,
                    data_source=data_source,
                    training_eligible=training_eligible,
                    tenant_id=game.tenant_id if game else "tenant_dev",
                    owner_id=game.owner_id if game else "user_dev",
                    residency_region=game.residency_region if game else "local",
                    retention_class=game.retention_class if game else "development",
                    body=spec,
                )
            )
    except Exception as exc:  # noqa: BLE001 — telemetry must never break a build
        log.warning("could not store spec for job %s: %s", job_id, exc)


def _free_planner_vram(settings) -> None:
    """Sequence plan -> assets (CLAUDE.md §4): unload the LLM planner from the GPU
    so the diffusion/3D generators have the VRAM. The 32B-class planner (~17 GB)
    and SDXL+TripoSR (~9 GB) cannot co-reside in 32 GB — running both starves the
    planner and it falls back to rules (a capsule, wrong genre). So once the LLM
    has finished imagining the game, unload it, THEN generate.

    Best-effort: Ollama reloads the planner (cold) on the next job's first call,
    absorbed by the 180 s llm_timeout_seconds. A failure here just means the model
    stays resident and generation is tight — never a broken build.
    """
    if not settings.llm_enabled:
        return
    import httpx  # local: only the GPU-sequencing path needs it

    try:
        with httpx.Client(base_url=settings.llm_base_url, timeout=30.0) as client:
            # keep_alive=0 tells Ollama to evict the model right after this call.
            client.post("/api/generate", json={"model": settings.llm_model, "keep_alive": 0})
        log.info("unloaded planner %s -> freed VRAM for asset generation", settings.llm_model)
    except Exception as exc:  # noqa: BLE001 — sequencing is best-effort
        log.warning("could not unload planner (%s); generation VRAM may be tight", exc)


@celery_app.task(name="run_generation_job")
def run_generation_job(job_id: str) -> str:
    settings = get_settings()
    with db.session_scope() as session:
        job = session.get(Job, job_id)
        if job is None:
            return f"missing:{job_id}"
        game = session.get(Game, job.game_id)
        game_id, title, seed = game.id, game.title, game.seed
        tenant_id = game.tenant_id
        prompt, genre, camera = game.prompt, game.genre, game.camera
        # Serendib Assist re-export stashes the edited spec on the job.
        spec_override = (job.detail or {}).get("reexport_spec")

    try:
        _run_pipeline(
            job_id, game_id, title, seed, prompt, genre, camera, settings,
            spec_override=spec_override,
            tenant_id=tenant_id,
        )
    except Exception as exc:  # every stage failure becomes machine-readable
        error = (
            exc.to_dict()
            if hasattr(exc, "to_dict")
            else {"code": "pipeline_error", "path": "", "message": str(exc), "hint": ""}
        )
        _set_state(job_id, JobState.FAILED, error=error)
    return job_id


def _run_pipeline(
    job_id: str,
    game_id: str,
    title: str,
    seed: int | None,
    prompt: str,
    genre: str | None,
    camera: str | None,
    settings,
    spec_override: dict | None = None,
    tenant_id: str = "tenant_dev",
) -> None:
    # --- S1 + S2: prompt -> brief -> spec (rule-based until the P2 LLM) -----
    _set_state(job_id, JobState.PLANNING)
    spec_file = _spec_path(settings)
    if not spec_file.is_file():
        # A container missing its contracts cannot produce or validate output.
        _set_state(
            job_id,
            JobState.FAILED,
            error={
                "code": "SPEC_CONTRACT_UNAVAILABLE",
                "path": str(spec_file),
                "message": "the required frozen contract is unavailable",
                "hint": "include the contracts tree in the signed worker image",
            },
        )
        return
    # --- S1+S2: the multi-agent chain (CLAUDE.md §6 "agents-as-patches").
    # Prompt Analyzer (LLM or rules) -> World Designer -> Mechanics, each
    # emitting JSON patches that the Arbiter merges under the constraint
    # priority stack (hard bands clamp illegal/over-budget values), with
    # every field's decider recorded.
    from agents.chain import AgentContext, author_spec

    if seed is None:
        seed = int.from_bytes(hashlib.sha256(game_id.encode()).digest()[:4], "big")

    if spec_override is not None:
        # Serendib Assist re-export: build from an ALREADY-edited spec, skipping
        # the planner. The edit endpoint bounded + validated it, but the same
        # registry + schema gates below still run — an edited spec is not trusted
        # any more than a planned one.
        spec = json.loads(json.dumps(spec_override))
        spec["meta"]["game_id"] = game_id
        spec["meta"]["seed"] = seed
        brief_source = "edit"
        arbiter_decisions, agent_proposals, retrieved_notes = [], [], []
    else:
        base_spec = json.loads(spec_file.read_text(encoding="utf-8"))
        chain = author_spec(
            base_spec,
            AgentContext(
                prompt=prompt,
                seed=seed,
                genre=genre,
                camera=camera,
                llm_enabled=settings.llm_enabled,
                llm_base_url=settings.llm_base_url,
                llm_model=settings.llm_model,
                llm_timeout_seconds=settings.llm_timeout_seconds,
                rag_enabled=settings.rag_enabled,
            ),
            game_id,
            title,
        )
        spec = chain.spec
        brief_source = chain.brief_source
        arbiter_decisions = chain.arbiter_decisions
        agent_proposals = chain.agent_proposals
        retrieved_notes = chain.retrieved_notes

    # --- Allowlist enforcement: an agent may not invent template ids -------
    # (docs/GENERATION_PIPELINE.md: "invented IDs impossible by construction")
    from knowledge.registries import unknown_ids

    invented = unknown_ids(spec)
    if invented:
        first = invented[0]
        raise _StageError(
            code=first["code"],
            path=first["path"],
            message=first["message"]
            + (f" (+{len(invented) - 1} more)" if len(invented) > 1 else ""),
            hint=first["hint"],
        )

    # --- S3: schema validation ----------------------------------------------
    import jsonschema

    schema = json.loads(_schema_path().read_text(encoding="utf-8"))
    try:
        jsonschema.validate(spec, schema)
    except jsonschema.ValidationError as exc:
        raise _StageError(
            code="spec_schema_violation",
            path="/".join(str(p) for p in exc.absolute_path),
            message=exc.message[:300],
            hint="The spec must validate against contracts/game_spec.schema.json v2.",
        ) from exc
    spec_hash = hashlib.sha256(
        json.dumps(spec, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    from datetime import datetime

    # --- S5: resolve every asset_brief (cache -> curated -> generate -> QA) ---
    # No backend configured -> curated wins and this only RECORDS provenance; a
    # real GPU backend (set up later) makes it produce unique assets. Either way
    # the resolution manifest lands in lineage.
    worker_dir = _REPO_ROOT / "services" / "worker"
    if str(worker_dir) not in sys.path:
        sys.path.insert(0, str(worker_dir))
    from asset_farm.pipeline import (
        resolution_summary,
        resolve_spec_assets,
        shippable_models,
        shippable_sounds,
    )
    from asset_farm.registry import select_audio_backend, select_backend

    kit_dir = _REPO_ROOT / "content" / "kits"  # the curated ROOT: one folder per pack
    sfx_dir = _REPO_ROOT / "content" / "kits" / "catsfx"
    asset_backend = select_backend(settings)  # None unless asset_gen_enabled
    audio_backend = select_audio_backend(settings)  # None unless audio_gen_enabled
    # Plan -> assets sequencing: the LLM has finished imagining the game, so free
    # its VRAM before the generators load (they cannot co-reside in 32 GB). Only
    # when something will actually generate; curated-only jobs keep the planner hot.
    if asset_backend is not None or audio_backend is not None:
        _free_planner_vram(settings)
    asset_manifest = resolve_spec_assets(
        spec,
        kit_dir=kit_dir if kit_dir.is_dir() else None,
        sfx_dir=sfx_dir if sfx_dir.is_dir() else None,
        cache_dir=Path(settings.artifacts_dir).resolve() / "asset_cache",
        work_dir=Path(settings.artifacts_dir).resolve() / "asset_work" / spec["meta"]["game_id"],
        backend=asset_backend,
        audio_backend=audio_backend,
        # bge-m3 lives on the same Ollama as the planner. It powers TWO tiers: the
        # semantic cache (reuse a generated asset for a similar brief — only useful
        # when a backend generates) AND the semantic curated match (pick the owned
        # model a brief describes), which is valuable even with generation OFF.
        # So enable it whenever RAG is on, not only when a backend runs; the
        # keyword tier still covers the case where the embedder is unreachable.
        # Never a hard dependency either way.
        embed_base_url=settings.llm_base_url if settings.rag_enabled else None,
    )
    # Second half of plan->assets sequencing: free the generators' VRAM now the
    # asset phase is done, so the NEXT job's LLM planning (esp. the Content
    # Designer) is not starved by SDXL/TripoSR left resident across jobs — which
    # is what made it time out and fall back to base content (a capsule).
    if asset_backend is not None:
        from asset_farm.backends_local import unload_models

        if unload_models():
            log.info("freed generator VRAM after asset resolution")

    spec["lineage"] = {
        "prompt": prompt,
        "seeds": {"master": seed},
        "model_digests": {"planner": settings.llm_model if brief_source == "llm" else "rules"},
        "spec_hash": spec_hash,
        "created_at": datetime.now(UTC).isoformat(),
    }
    # The asset resolution manifest is JOB metadata (which tier each asset came
    # from), not canonical spec — the spec schema is frozen at v2.0.0, so it stays
    # in job detail rather than forcing a schema bump. Gate 1 correctly refused it
    # inside spec.lineage, which is exactly the guard working.
    _set_state(
        job_id, JobState.SPEC_FROZEN,
        spec_hash=spec_hash,
        seed=seed,
        agents=[p["agent"] for p in agent_proposals],
        retrieved_notes=retrieved_notes,
        arbiter_decisions=arbiter_decisions,
        genre=spec["meta"]["genre"],
        camera=spec["meta"]["camera"],
        brief_source=brief_source,
        asset_tiers=resolution_summary(asset_manifest),
        asset_resolution=asset_manifest,
    )
    _store_spec(job_id, game_id, spec, spec_hash, brief_source, settings)

    # --- S4..S7 as one repairable attempt; the repair loop re-invokes ONLY
    # the responsible node (docs/VALIDATION_PLAN.md repair policy) ------------
    from pcg.pipeline import run_pcg
    from pcg.serialize import to_level_plan, to_level_plan_json
    from repair.loop import (
        MAX_ATTEMPTS_PER_CLASS,
        RepairAttempt,
        deterministic_spec_fixes,
        level_reroll_seed,
        responsible_action,
    )
    from validators.gates import collect_quest_of, run_gates

    artifacts_root = Path(settings.artifacts_dir).resolve()
    project_dir = artifacts_root / game_id / "project"

    def attempt(level_seed: int, use_kit: bool) -> tuple[dict, dict | None, dict, dict]:
        """Run S4 (+S6/S7 when Godot is available) once; returns
        (plan, build_result|None, gate_report, level_detail)."""
        _set_state(job_id, JobState.BUILDING_LEVEL)
        pcg_spec = json.loads(json.dumps(spec))
        pcg_spec["meta"]["seed"] = level_seed
        # Outdoor worlds are FLAT (single tier): the open ground navmesh is one
        # plane, so raised tiers would float above it and strand the bot. Force it
        # here so an outdoor village is always traversable (verified: flat outdoor
        # -> GREEDYBOT_OK; multi-tier outdoor -> the bot times out).
        if pcg_spec.get("world", {}).get("kind") == "outdoor":
            pcg_spec.setdefault("world", {}).setdefault("zone_graph", {})["verticality_tiers"] = 1
        out = run_pcg(pcg_spec)
        plan = to_level_plan(out)
        level_detail = {
            "level_plan_hash": hashlib.sha256(to_level_plan_json(out).encode()).hexdigest(),
            "zones": len(plan["zones"]),
            "entities": len(plan["entities"]),
            "level_seed": level_seed,
        }
        spec["lineage"]["seeds"]["level"] = level_seed

        result = None
        if settings.godot_bin:
            from godot_client.exporter import export_web
            from godot_client.project_writer import write_project

            _set_state(job_id, JobState.ASSEMBLING, **level_detail)
            # Composite interactive objects (ADR-0008): the planner authored
            # entities.objects (archetypes); place them in the level (seeded) and
            # expand each into parts+sockets. Empty when the game has no objects.
            from agents.composition_patterns import expand_all, place_objects

            authored_objects = spec.get("entities", {}).get("objects", [])
            composites = expand_all(
                place_objects(authored_objects, plan.get("rooms", []), level_seed)
            )
            # Give each object its body shell if the farm resolved one (generated,
            # or a curated vehicle/building kit later). Rides the same kit lever as
            # the other assets: the bare-build retry ships doors without a body.
            if use_kit and composites:
                worn = shippable_models(asset_manifest)
                for composite in composites:
                    body = worn.get(f"object:{composite['object_id']}")
                    if body is not None:
                        composite["parent_mesh_rel"] = str(body)
            level_detail["composite_count"] = len(composites)
            write_project(
                plan,
                spec["meta"]["title"],
                project_dir,
                templates_dir=_templates_dir(settings),
                player_config=spec["player"],
                enemy_configs={
                    e["enemy_id"]: e.get("stats", {}) for e in spec["entities"]["enemies"]
                },
                lighting_preset=spec["world"].get("lighting_preset_id", "overcast_day"),
                kit_dir=(_REPO_ROOT / "content" / "kits") if use_kit else None,
                # Enemy sound rides the same lever as the models: the bare-build
                # repair retry strips curated assets, and audio is one of them.
                sfx_dir=(_REPO_ROOT / "content" / "kits" / "catsfx") if use_kit else None,
                prop_configs={
                    p["prop_id"]: p.get("interactable_template_id")
                    for p in spec["entities"]["props"]
                },
                # What the asset farm actually made for this game — the generated
                # models finally reach the scene instead of only the lineage record.
                # Rides the same repair lever as the kit: the bare-build retry
                # strips every asset, generated ones included.
                asset_models=shippable_models(asset_manifest) if use_kit else None,
                # ...and what it made this game's characters SOUND like.
                asset_sounds=shippable_sounds(asset_manifest) if use_kit else None,
                # None unless the spec asks for a collect_n hunt, in which case the
                # relics replace the key zone as what unlocks the exit door.
                collect_quest=collect_quest_of(spec),
                # Composite objects with interactable parts (doors, lids, levers)
                # snapped to sockets — empty until the brain emits them (phase 3).
                composites=composites,
                # indoor (walled rooms) vs outdoor (open ground + mountain ring).
                world_kind=spec.get("world", {}).get("kind", "indoor"),
            )
            # Ship the canonical spec inside the downloadable project so Serendib
            # Assist (the AI-dock) can read it, edit it, and re-export — the P3
            # round-trip. It is data, never executed.
            (project_dir / "game_spec.json").write_text(
                json.dumps(spec, indent=2), encoding="utf-8"
            )
            _deploy_serendib_assist(project_dir)
            _set_state(job_id, JobState.EXPORTING)
            result = export_web(project_dir, Path(settings.godot_bin))
            pck = next((p for p in result["files"] if p.suffix == ".pck"), None)
            if pck is not None:
                spec["lineage"]["build_hash"] = hashlib.sha256(pck.read_bytes()).hexdigest()

        _set_state(job_id, JobState.VALIDATING, **level_detail)
        # Gate 6: actually PLAY the game. Until now nothing supplied a verdict,
        # so the dynamic gate recorded SKIPPED on every job and a game that could
        # not be finished still passed validation.
        bot_verdict = None
        affordance_verdict = None
        if settings.godot_bin:
            from bots.runner import run_affordance_check, run_greedy_bot

            bot_verdict = run_greedy_bot(settings.godot_bin, project_dir)
            level_detail["bot_verdict"] = bot_verdict
            # ADR-0008: prove every composed affordance opens. Only meaningful when
            # the game HAS composites; otherwise the oracle reports doors=0 -> OK.
            if composites:
                affordance_verdict = run_affordance_check(settings.godot_bin, project_dir)
                level_detail["affordance_verdict"] = affordance_verdict
        report = run_gates(
            spec,
            plan,
            schema=schema,
            build_result=result,
            bot_verdict=bot_verdict,
            affordance_verdict=affordance_verdict,
            # Gate 3 judges what the farm actually shipped. It never blocks on a
            # QA failure (the resolver already fell back — that IS the design);
            # it verifies the promise that nothing ships un-gated.
            asset_manifest=asset_manifest,
        )
        return plan, result, report, level_detail

    repair_log: list[dict] = []
    class_counts: dict[str, int] = {}
    level_seed = seed
    use_kit = True
    plan, result, report, level_detail = attempt(level_seed, use_kit)
    while report["verdict"] != "PASS":
        failure_class = report["errors"][0]["failure_class"]
        class_counts[failure_class] = class_counts.get(failure_class, 0) + 1
        count = class_counts[failure_class]
        action = responsible_action(failure_class, count)
        if count > MAX_ATTEMPTS_PER_CLASS or action == "none":
            break
        _set_state(job_id, JobState.REPAIRING, repair_attempts=repair_log)
        errors_before = [e["code"] for e in report["errors"]]
        if action == "fix_spec_deterministically":
            if not deterministic_spec_fixes(spec, report["errors"]):
                break  # nothing rule-fixable: fail fast
        elif action == "reroll_level_seed":
            # A logic failure may still have a precise, rule-based remedy — a
            # collect goal asking for more relics than the level can hold. Fixing
            # the spec beats re-rolling the entire world and hoping; only reroll
            # when there is nothing specific to fix (e.g. an unreachable key).
            if deterministic_spec_fixes(spec, report["errors"]):
                action = "fix_spec_deterministically"
            else:
                level_seed = level_reroll_seed(seed, count)
        elif action == "drop_kit_models":
            use_kit = False
        # "reexport" / "curated_substitute": re-run the attempt as-is

        plan, result, report, level_detail = attempt(level_seed, use_kit)
        errors_after = [e["code"] for e in report["errors"]]
        repair_log.append(
            RepairAttempt(failure_class, count, action, errors_before, errors_after).to_dict()
        )
        if report["verdict"] != "PASS" and len(errors_after) >= len(errors_before):
            break  # monotonic-progress check: this attempt did not shrink the error set

    if report["verdict"] != "PASS":
        _set_state(job_id, JobState.FAILED, validation=report, repair_attempts=repair_log)
        return
    if not settings.godot_bin:
        # Static schema/PCG success is not a built, launched simulation. Preserve
        # it as preflight evidence and fail the release gate when mandatory
        # engine validators could not run.
        release_report = json.loads(json.dumps(report))
        skipped = [
            gate
            for gate in release_report.get("gates", [])
            if gate.get("verdict") == "SKIPPED"
        ]
        release_report["verdict"] = "FAIL"
        release_report.setdefault("errors", []).append(
            {
                "gate": 4,
                "code": "BUILD_AND_RUNTIME_VALIDATION_NOT_RUN",
                "path": "$.release",
                "message": (
                    "GODOT_BIN is not configured, so no Serendib artifact was "
                    "built, launched, or runtime-probed"
                ),
                "hint": "configure the pinned Serendib engine and rerun mandatory gates",
                "failure_class": "export",
                "data": {
                    "skipped_gates": [gate.get("gate") for gate in skipped],
                },
            }
        )
        _set_state(
            job_id, JobState.FAILED,
            **level_detail,
            deterministic_validation=report,
            validation=release_report,
            repair_attempts=repair_log,
            export="not run (GODOT_BIN not configured)",
        )
        return

    from godot_client.packager import package_project

    publish_dir = artifacts_root / game_id
    for built in result["files"]:
        shutil.copyfile(built, publish_dir / built.name)
    package_project(project_dir, publish_dir / "project.zip", spec["meta"]["title"])

    # Hybrid deploy: also push to R2 for a shareable ($0-egress) URL. Off unless
    # configured; a failure keeps the local /artifacts copy, so the job still ships.
    from storage.r2 import upload_artifacts

    r2_urls = upload_artifacts(
        publish_dir,
        game_id,
        settings,
        tenant_id=tenant_id,
    ) or {}
    if settings.promptplay_env == "production" and not r2_urls:
        _set_state(
            job_id,
            JobState.FAILED,
            **level_detail,
            validation={
                **report,
                "verdict": "FAIL",
                "errors": [
                    {
                        "code": "ARTIFACT_PUBLISH_FAILED",
                        "message": "private artifact delivery is unavailable",
                    }
                ],
            },
            repair_attempts=repair_log,
            export="private artifact publication failed",
        )
        return
    play_url = r2_urls.get("index.html", f"/artifacts/{game_id}/index.html")
    download_url = r2_urls.get("project.zip", f"/artifacts/{game_id}/project.zip")

    _set_state(
        job_id, JobState.DEPLOYED,
        **level_detail,
        validation=report,
        repair_attempts=repair_log,
        play_path=play_url,
        download_path=download_url,
        published_to=("r2" if r2_urls else "local"),
        build_mb=round(result["total_bytes"] / 1024 / 1024, 1),
    )


class _StageError(ValueError):
    def __init__(self, code: str, path: str, message: str, hint: str) -> None:
        super().__init__(message)
        self.code, self.path, self.message, self.hint = code, path, message, hint

    def to_dict(self) -> dict:
        return {"code": self.code, "path": self.path, "message": self.message, "hint": self.hint}
