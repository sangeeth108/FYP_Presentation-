"""Celery application. Run the worker with:  celery -A worker.celery_app worker -l info

In P0 the only task is the hello-job (worker/tasks.py) — no AI, no GPU. The real
GPU pull-worker (services/worker) is a separate process added in later phases.
"""

from __future__ import annotations

import logging

from celery import Celery
from celery.signals import worker_ready
from core.config import get_settings

log = logging.getLogger(__name__)
_settings = get_settings()

celery_app = Celery(
    "promptplay",
    broker=_settings.celery_broker_url,
    backend=_settings.celery_result_backend,
    include=[
        "worker.tasks",
        "worker.simulation_tasks",
        "worker.learning_tasks",
        "worker.privacy_tasks",
    ],
)

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="UTC",
    enable_utc=True,
    task_always_eager=_settings.celery_task_always_eager,  # True in tests → run inline
    task_eager_propagates=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_reject_on_worker_lost=True,
    task_routes={
        "run_simulation_generation": {"queue": "planning"},
        "build_simulation_generation": {"queue": "serendib_build"},
        "run_generation_job": {"queue": "serendib_build"},
        "purge_user_training_data": {"queue": "privacy"},
        "purge_all_user_training_data": {"queue": "privacy"},
        "process_data_subject_request": {"queue": "privacy"},
        "execute_governed_training": {"queue": "gpu_training"},
    },
    task_time_limit=3600,
    task_soft_time_limit=3300,
)


@worker_ready.connect
def _reconcile_quotas_on_start(**_: object) -> None:
    """On boot, release generation slots leaked by a previous crash (a run whose
    lease never released) so the quota can't stay wedged at "3/3 running" and
    429 every new submission. Best-effort: never blocks the worker from starting."""
    try:
        from core import db
        from core.quotas import reconcile_generation_quotas

        with db.session_scope() as session:
            released = reconcile_generation_quotas(session)
        if released:
            log.info("startup: released %d stale generation lease(s)", released)
    except Exception as exc:  # noqa: BLE001 — reconciliation must never break boot
        log.warning("startup quota reconciliation skipped: %s", exc)
