"""Data-subject export and deletion processors.

The API only records authenticated requests. These service-identity tasks
perform the cross-table work outside the request and persist a transparent
terminal result.
"""

from __future__ import annotations

import hashlib
import shutil
from datetime import UTC, datetime
from pathlib import Path

from core import db
from core.config import get_settings
from core.models import (
    AgeAssurance,
    ConsentRecord,
    ContentRight,
    DataSubjectRequest,
    FeedbackEvent,
    Game,
    GenerationRun,
    GuardianRelationship,
    Membership,
    Simulation,
    SimulationSpecRecord,
    TrainingEligibility,
    UsageEvent,
    User,
)
from storage.r2 import delete_artifact_prefix

from worker.celery_app import celery_app


def _export_payload(session, request: DataSubjectRequest) -> dict:
    owner_id = request.owner_id
    simulations = session.query(Simulation).filter_by(owner_id=owner_id).all()
    simulation_ids = [item.id for item in simulations]
    specs = (
        session.query(SimulationSpecRecord)
        .filter(SimulationSpecRecord.owner_id == owner_id)
        .all()
    )
    feedback = session.query(FeedbackEvent).filter_by(owner_id=owner_id).all()
    usage = session.query(UsageEvent).filter_by(owner_id=owner_id).all()
    consents = (
        session.query(ConsentRecord)
        .filter(ConsentRecord.subject_user_id == owner_id)
        .all()
    )
    memberships = session.query(Membership).filter_by(user_id=owner_id).all()
    return {
        "format_version": "1.0.0",
        "generated_at": datetime.now(UTC).isoformat(),
        "scope": "all_serendib_tenants",
        "simulations": [
            {
                "simulation_id": item.id,
                "tenant_id": item.tenant_id,
                "title": item.title,
                "prompt": item.prompt,
                "size_profile": item.size_profile,
                "target_platforms": item.target_platforms,
                "seed": item.seed,
                "status": item.status,
                "created_at": item.created_at.isoformat(),
            }
            for item in simulations
        ],
        "simulation_specs": [
            {
                "spec_id": item.id,
                "simulation_id": item.simulation_id,
                "version": item.version,
                "spec_hash": item.spec_hash,
                "body": item.body,
                "created_at": item.created_at.isoformat(),
            }
            for item in specs
        ],
        "feedback": [
            {
                "feedback_id": item.id,
                "tenant_id": item.tenant_id,
                "simulation_id": item.simulation_id,
                "kind": item.kind,
                "rating": item.rating,
                "payload": item.payload,
                "created_at": item.created_at.isoformat(),
            }
            for item in feedback
        ],
        "usage_events": [
            {
                "event_id": item.id,
                "tenant_id": item.tenant_id,
                "simulation_id": item.simulation_id,
                "event_type": item.event_type,
                "payload": item.payload,
                "created_at": item.created_at.isoformat(),
            }
            for item in usage
        ],
        "training_consents": [
            {
                "consent_id": item.id,
                "tenant_id": item.tenant_id,
                "kind": item.consent_kind,
                "scope": item.scope,
                "data_category": item.data_category,
                "granted": item.granted,
                "disclosure_version": item.disclosure_version,
                "created_at": item.created_at.isoformat(),
                "withdrawn_at": (
                    item.withdrawn_at.isoformat() if item.withdrawn_at else None
                ),
            }
            for item in consents
        ],
        "memberships": [
            {
                "tenant_id": item.tenant_id,
                "role": item.role,
                "status": item.status,
            }
            for item in memberships
        ],
        "summary": {
            "simulation_count": len(simulation_ids),
            "spec_count": len(specs),
            "feedback_count": len(feedback),
            "usage_event_count": len(usage),
        },
    }


def _delete_content(session, request: DataSubjectRequest) -> dict:
    owner_id = request.owner_id
    settings = get_settings()
    games = session.query(Game).filter_by(owner_id=owner_id).all()
    simulations = session.query(Simulation).filter_by(owner_id=owner_id).all()
    simulation_ids = [simulation.id for simulation in simulations]
    runs = (
        session.query(GenerationRun)
        .filter(GenerationRun.simulation_id.in_(simulation_ids))
        .all()
        if simulation_ids
        else []
    )
    storage_targets = [
        (game.tenant_id, game.id) for game in games
    ] + [(run.tenant_id, run.id) for run in runs]
    storage_failures = [
        run_prefix
        for tenant_id, run_prefix in storage_targets
        if not delete_artifact_prefix(
            settings,
            tenant_id=tenant_id,
            run_prefix=run_prefix,
        )
    ]
    if storage_failures:
        raise RuntimeError("private artifact deletion failed")
    artifact_root = Path(settings.artifacts_dir).resolve()
    for simulation in simulations:
        simulation_root = (artifact_root / simulation.id).resolve()
        if artifact_root not in simulation_root.parents:
            raise RuntimeError("local simulation artifact path escaped its root")
        if simulation_root.exists():
            if not simulation_root.is_dir() or simulation_root.is_symlink():
                raise RuntimeError("local simulation artifact path is unsafe")
            shutil.rmtree(simulation_root)

    # Training copies were purged first by the Celery chain. Delete remaining
    # eligibility before rights/consent rows to avoid retaining content links.
    eligibility_deleted = (
        session.query(TrainingEligibility)
        .filter_by(owner_id=owner_id)
        .delete(synchronize_session=False)
    )
    session.query(ContentRight).filter_by(owner_id=owner_id).delete(
        synchronize_session=False
    )
    feedback_deleted = session.query(FeedbackEvent).filter_by(owner_id=owner_id).delete(
        synchronize_session=False
    )
    usage_deleted = session.query(UsageEvent).filter_by(owner_id=owner_id).delete(
        synchronize_session=False
    )
    simulation_count = len(simulations)
    for simulation in simulations:
        session.delete(simulation)
    # Transitional compatibility builds are user-owned too.
    for game in games:
        session.delete(game)
    session.flush()

    session.query(ConsentRecord).filter(
        (ConsentRecord.subject_user_id == owner_id)
        | (ConsentRecord.actor_user_id == owner_id)
    ).delete(synchronize_session=False)
    session.query(AgeAssurance).filter_by(user_id=owner_id).delete(
        synchronize_session=False
    )
    session.query(GuardianRelationship).filter(
        (GuardianRelationship.minor_user_id == owner_id)
        | (GuardianRelationship.guardian_user_id == owner_id)
    ).delete(synchronize_session=False)
    session.query(Membership).filter_by(user_id=owner_id).delete(
        synchronize_session=False
    )
    user = session.get(User, owner_id)
    if user is not None:
        tombstone = hashlib.sha256(
            f"deleted:{owner_id}".encode()
        ).hexdigest()
        user.subject = f"deleted:{tombstone}"
        user.email_hash = None
        user.age_band = "unknown"
        user.status = "deleted"
    return {
        "content_deleted": True,
        "simulations_deleted": simulation_count,
        "compatibility_games_deleted": len(games),
        "feedback_deleted": feedback_deleted,
        "usage_events_deleted": usage_deleted,
        "eligibility_records_deleted": eligibility_deleted,
        "non_content_tombstone_retained": True,
        "completed_at": datetime.now(UTC).isoformat(),
    }


@celery_app.task(name="process_data_subject_request")
def process_data_subject_request(request_id: str) -> str:
    with db.session_scope() as session:
        request = session.get(DataSubjectRequest, request_id)
        if request is None:
            return f"missing:{request_id}"
        if request.state == "completed":
            return request_id
        request.state = "processing"
        try:
            if request.request_type == "export":
                request.result = _export_payload(session, request)
            elif request.request_type == "delete":
                request.result = _delete_content(session, request)
            else:
                raise ValueError("unsupported data-subject request")
            request.state = "completed"
            request.completed_at = datetime.now(UTC)
        except Exception as exc:
            request.state = "failed"
            request.result = {
                "code": "PRIVACY_REQUEST_FAILED",
                "error_type": type(exc).__name__,
            }
        return request_id
