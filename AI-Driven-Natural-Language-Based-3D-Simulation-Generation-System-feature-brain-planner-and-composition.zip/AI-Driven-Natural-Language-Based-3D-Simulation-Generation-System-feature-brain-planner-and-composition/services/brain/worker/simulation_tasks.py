"""Canonical neutral simulation orchestration with fail-closed release gates."""

from __future__ import annotations

import hashlib
import json
import shutil
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path

from agents.brief_extractor import brief_as_planner_input, extract_brief
from agents.deliberator import deliberate_brief
from agents.prompt_expander import expand_prompt
from agents.simulation_planner import (
    apply_localized_edit,
    plan_simulation,
    validate_simulation_spec,
)
from capabilities.registry import resolve_capabilities
from core import db
from core.config import get_settings
from core.ids import new_resource_id
from core.models import (
    AssetDescriptorRecord,
    CapabilityGap,
    ContentRight,
    GenerationRun,
    Simulation,
    SimulationArtifact,
    SimulationSpecRecord,
    TrainingEligibility,
    ValidationEvidence,
    WorldPlanRecord,
)
from core.quotas import release_generation_slot
from core.stages import record_stage
from core.validation_contract import (
    MANDATORY_PREPUBLICATION_LAYERS,
    MANDATORY_VALIDATION_LAYERS,
)
from model_router.registry import route_model
from storage.r2 import upload_artifacts

from worker.celery_app import celery_app
from worker.native_pipeline import run_native_pipeline


def _update_run(
    run_id: str,
    *,
    state: str | None = None,
    stage: str | None = None,
    **detail,
) -> None:
    with db.session_scope() as session:
        run = session.get(GenerationRun, run_id)
        if run is None:
            return
        if state:
            run.state = state
        if stage:
            run.stage = stage
        merged = dict(run.detail or {})
        merged.update(detail)
        run.detail = merged
        if state and (
            state == "completed"
            or state.startswith("failed_")
        ):
            run.completed_at = datetime.now(UTC)


def _record_evidence(
    session,
    run_id: str,
    *,
    layer: str,
    status: str,
    mandatory: bool,
    validator: str,
    errors: list | None = None,
    evidence: dict | None = None,
    requirement_ids: list | None = None,
) -> None:
    session.add(
        ValidationEvidence(
            id=new_resource_id("evidence"),
            run_id=run_id,
            layer=layer,
            status=status,
            mandatory=mandatory,
            validator=validator,
            validator_version="1.0.0",
            requirement_ids=requirement_ids or [],
            evidence=evidence or {},
            errors=errors or [],
        )
    )


def _route_record(route) -> dict | None:
    if route is None:
        return None
    return {
        "model_id": route.model_id,
        "provider": route.provider,
        "version": route.version,
        "digest": route.model_digest,
        "deployment": route.deployment,
    }


def _planning_gate_reports(spec: dict) -> dict[str, dict]:
    requirements = [
        item.get("requirement_id") for item in spec.get("requirements", [])
    ]
    schema_errors: list[dict] = []
    try:
        validate_simulation_spec(spec)
    except Exception as exc:
        schema_errors.append(
            {
                "code": "SIMULATION_SPEC_INVALID",
                "type": type(exc).__name__,
                "message": str(exc)[:500],
            }
        )
    # Every capability the spec actually uses, not just the ones listed at the
    # top. A railway-platform spec held `dialogue`, `sittable` and `openable` on
    # its entities while declaring only `camera_control` and `locomotion`, so
    # three capabilities reached the build without ever being resolved against
    # the pack registry -- and this is the gate whose entire job is to resolve
    # them. The runtime-binding half was still covered per entity by behaviour
    # compilation; the platform-support half was not checked at all.
    declared = list(spec.get("capabilities", []))
    for entity in spec.get("entities", []) or ():
        if isinstance(entity, dict):
            declared.extend(entity.get("capabilities") or ())
    resolved, gaps = resolve_capabilities(
        declared,
        spec.get("request", {}).get("target_platforms", []),
    )
    return {
        "requirements_and_schema": {
            "status": "FAIL" if schema_errors else "PASS",
            "validator": "simulation_spec_schema",
            "errors": schema_errors,
            "evidence": {"requirements": len(requirements)},
            "requirement_ids": [item for item in requirements if item],
        },
        "capability_declaration": {
            "status": "FAIL" if gaps else "PASS",
            "validator": "capability_pack_registry",
            "errors": [
                {
                    "code": "CAPABILITY_INCOMPLETE",
                    "capability_id": gap["capability_id"],
                    "status": gap["status"],
                    "message": gap["reason"],
                }
                for gap in gaps
            ],
            "evidence": {
                "resolved": [
                    {
                        "capability_id": item["capability_id"],
                        "pack_id": item["pack_id"],
                        "pack_version": item["pack_version"],
                        "status": item["status"],
                    }
                    for item in resolved
                ]
            },
            "requirement_ids": [],
        },
    }


def _persist_spec_and_governance(
    *,
    run_id: str,
    values: dict,
    spec: dict,
    source: str,
    planner_route,
    critic_route,
    vision_route,
    capability_gaps: list[dict],
    resolved_capabilities: list[dict],
) -> str:
    serialized = json.dumps(spec, sort_keys=True, separators=(",", ":"))
    spec_hash = hashlib.sha256(serialized.encode("utf-8")).hexdigest()
    with db.session_scope() as session:
        version = (
            session.query(SimulationSpecRecord)
            .filter_by(simulation_id=values["simulation_id"])
            .count()
            + 1
        )
        record = SimulationSpecRecord(
            id=new_resource_id("sim_spec"),
            simulation_id=values["simulation_id"],
            tenant_id=values["tenant_id"],
            owner_id=values["owner_id"],
            version=version,
            schema_version=spec["schema_version"],
            spec_hash=spec_hash,
            source=source,
            planner_model=spec["lineage"]["planner"],
            body=spec,
            data_source="production_user",
            training_eligible=False,
        )
        session.add(record)
        # Scalar foreign-key IDs do not create an ORM dependency edge. Persist
        # the spec before GenerationRun/Simulation point at it.
        session.flush()
        run = session.get(GenerationRun, run_id)
        run.spec_id = record.id
        run.model_routes = {
            "planner": _route_record(planner_route if source != "edit" else None),
            "planner_result": spec["lineage"]["planner"],
            "critic": _route_record(critic_route),
            "vision": _route_record(vision_route),
        }
        simulation = session.get(Simulation, values["simulation_id"])
        simulation.current_spec_id = record.id
        requirements = [item["requirement_id"] for item in spec["requirements"]]
        _record_evidence(
            session,
            run_id,
            layer="requirements_and_schema",
            status="PASS",
            mandatory=True,
            validator="simulation_spec_schema",
            evidence={"spec_hash": spec_hash, "requirements": len(requirements)},
            requirement_ids=requirements,
        )
        _record_evidence(
            session,
            run_id,
            layer="capability_declaration",
            status="FAIL" if capability_gaps else "PASS",
            mandatory=True,
            validator="capability_pack_registry",
            evidence={
                "resolved": [
                    {
                        "capability_id": item["capability_id"],
                        "pack_id": item["pack_id"],
                        "pack_version": item["pack_version"],
                        "status": item["status"],
                    }
                    for item in resolved_capabilities
                ]
            },
            errors=[
                {
                    "code": "CAPABILITY_INCOMPLETE",
                    "capability_id": gap["capability_id"],
                    "status": gap["status"],
                    "message": gap["reason"],
                }
                for gap in capability_gaps
            ],
        )
        for gap in capability_gaps:
            session.add(
                CapabilityGap(
                    id=new_resource_id("gap"),
                    simulation_id=values["simulation_id"],
                    run_id=run_id,
                    requirement_id=None,
                    capability_id=gap["capability_id"],
                    status="open",
                    detail=gap,
                )
            )
        right = ContentRight(
            id=new_resource_id("right"),
            tenant_id=values["tenant_id"],
            owner_id=values["owner_id"],
            resource_type="simulation_spec",
            resource_id=record.id,
            rights_basis=(
                "user_attestation" if values["rights_attested"] else "unverified"
            ),
            training_allowed=values["rights_attested"],
            verified_at=None,
        )
        session.add(right)
        session.flush()
        for scope in ("global", "tenant_private"):
            session.add(
                TrainingEligibility(
                    id=new_resource_id("eligibility"),
                    tenant_id=values["tenant_id"],
                    owner_id=values["owner_id"],
                    resource_type="simulation_spec",
                    resource_id=record.id,
                    training_scope=scope,
                    data_category="prompt_spec",
                    data_source="production_user",
                    status="quarantined",
                    content_right_id=right.id,
                    moderation_status="pending",
                    quality_status="pending",
                    exclusion_reason="awaiting_moderation_and_quality",
                )
            )
    return record.id


def _publish_staged_artifacts(
    *,
    result: dict,
    settings,
    values: dict,
    run_id: str,
) -> tuple[dict[str, tuple[str, str | None]], dict]:
    publish_dir = (
        Path(settings.artifacts_dir).resolve()
        / values["simulation_id"]
        / run_id
    )
    publish_dir.mkdir(parents=True, exist_ok=True)
    paths = result["artifact_paths"]
    if "web_build" in paths:
        for source in sorted(paths["web_build"].iterdir()):
            if source.is_file():
                shutil.copyfile(source, publish_dir / source.name)
    file_names = {
        "editable_project": "project.zip",
        "desktop_build": "desktop.zip",
    }
    for kind, filename in file_names.items():
        if kind in paths:
            shutil.copyfile(paths[kind], publish_dir / filename)

    r2_urls = upload_artifacts(
        publish_dir,
        run_id,
        settings,
        tenant_id=values["tenant_id"],
    ) or {}
    if settings.promptplay_env == "production" and not r2_urls:
        return {}, {
            "status": "FAIL",
            "validator": "private_artifact_gateway",
            "errors": [{"code": "ARTIFACT_PUBLISH_FAILED"}],
            "evidence": {},
            "requirement_ids": [],
        }
    local_base = f"/artifacts/{values['simulation_id']}/{run_id}"
    artifacts: dict[str, tuple[str, str | None]] = {}
    if (publish_dir / "index.html").is_file():
        artifacts["web_build"] = (
            r2_urls.get("index.html", f"{local_base}/index.html"),
            "web",
        )
    if (publish_dir / "desktop.zip").is_file():
        artifacts["desktop_build"] = (
            r2_urls.get("desktop.zip", f"{local_base}/desktop.zip"),
            "desktop",
        )
    if (publish_dir / "project.zip").is_file():
        artifacts["editable_project"] = (
            r2_urls.get("project.zip", f"{local_base}/project.zip"),
            None,
        )
    return artifacts, {
        "status": "PASS",
        "validator": "private_artifact_gateway",
        "errors": [],
        "evidence": {
            "published_to": "r2" if r2_urls else "local_development",
            "artifact_kinds": sorted(artifacts),
        },
        "requirement_ids": [],
    }


def _run_values(session, run_id: str) -> tuple[GenerationRun, dict] | None:
    run = session.get(GenerationRun, run_id)
    if run is None:
        return None
    simulation = session.get(Simulation, run.simulation_id)
    if simulation is None:
        return None
    detail = dict(run.detail or {})
    return run, {
        "simulation_id": simulation.id,
        "prompt": simulation.prompt,
        "seed": simulation.seed,
        "size_profile": simulation.size_profile,
        "target_platforms": list(simulation.target_platforms),
        "tenant_id": simulation.tenant_id,
        "owner_id": simulation.owner_id,
        "title": simulation.title,
        "domain_constraints": detail.get("domain_constraints", {}),
        "rights_attested": bool(detail.get("training_rights_attested")),
        "edit_instruction": detail.get("edit_instruction"),
        "base_spec_id": detail.get("base_spec_id"),
    }


def _release_slot(run_id: str) -> None:
    with db.session_scope() as session:
        release_generation_slot(session, run_id)


@celery_app.task(name="run_simulation_generation")
def run_simulation_generation(run_id: str) -> str:
    """Persist the independently retryable CPU planning stage, then enqueue build."""
    settings = get_settings()
    try:
        with db.session_scope() as session:
            loaded = _run_values(session, run_id)
            if loaded is None:
                return f"missing:{run_id}"
            run, values = loaded
            if run.spec_id:
                build_simulation_generation.apply_async(args=[run_id])
                return run_id

        _update_run(run_id, state="planning", stage="requirements")
        if values["edit_instruction"] and values["base_spec_id"]:
            with db.session_scope() as session:
                base = session.get(SimulationSpecRecord, values["base_spec_id"])
                if base is None:
                    _update_run(
                        run_id,
                        state="failed_requirements",
                        stage="requirements",
                        error={"code": "BASE_SPEC_NOT_FOUND"},
                    )
                    _release_slot(run_id)
                    return run_id
                spec, changes, rejected = apply_localized_edit(
                    base.body, values["edit_instruction"]
                )
            if not changes:
                _update_run(
                    run_id,
                    state="failed_requirements",
                    stage="requirements",
                    rejected=rejected,
                )
                _release_slot(run_id)
                return run_id
            source = "edit"
            planner_route = None
        else:
            planner_route = route_model(
                "planner", tenant_id=values["tenant_id"], routing_key=run_id
            )
            # Stage 1: think about the place in prose before formalising it.
            # Best-effort by design -- `expansion` is None when the model is
            # unavailable or says nothing useful, and planning proceeds from the
            # raw prompt exactly as before.
            expansion = (
                expand_prompt(
                    values["prompt"],
                    settings=settings,
                    model_id=(planner_route.model_id if planner_route else None),
                    base_url=(planner_route.endpoint if planner_route else None),
                    seed=values["seed"],
                )
                if settings.expand_enabled
                else None
            )
            record_stage(
                run_id,
                "expand",
                status="PASS" if expansion else "SKIPPED",
                payload=expansion.as_stage_payload() if expansion else {},
                summary={
                    "expanded": expansion is not None,
                    "prompt_characters": len(values["prompt"]),
                    "description_characters": (
                        len(expansion.description) if expansion else 0
                    ),
                    "duration_ms": expansion.duration_ms if expansion else 0,
                },
                model_id=expansion.model_id if expansion else None,
            )
            # Stage 2: read the prose into the few-vs-many decision explicitly,
            # rather than letting it fall out of filling a large schema.
            extraction = (
                extract_brief(
                    expansion.description,
                    settings=settings,
                    model_id=(planner_route.model_id if planner_route else None),
                    base_url=(planner_route.endpoint if planner_route else None),
                    seed=values["seed"],
                )
                if expansion and settings.extract_enabled
                else None
            )
            record_stage(
                run_id,
                "extract",
                status="PASS" if extraction else "SKIPPED",
                payload=extraction.as_stage_payload() if extraction else {},
                summary={
                    "extracted": extraction is not None,
                    "individual": (
                        len(extraction.brief.get("individual") or []) if extraction else 0
                    ),
                    "mass": len(extraction.brief.get("mass") or []) if extraction else 0,
                    "duration_ms": extraction.duration_ms if extraction else 0,
                },
                model_id=extraction.model_id if extraction else None,
            )
            # Stage 3: critique the reading, revise it, stop when it settles.
            # Never destructive — a failed deliberation returns what went in.
            if extraction and settings.deliberate_enabled:
                deliberation = deliberate_brief(
                    extraction.brief,
                    expansion.description,
                    settings=settings,
                    model_id=(planner_route.model_id if planner_route else None),
                    base_url=(planner_route.endpoint if planner_route else None),
                    seed=values["seed"],
                )
                extraction = replace(extraction, brief=deliberation.brief)
                record_stage(
                    run_id,
                    "deliberate",
                    status="PASS",
                    payload=deliberation.as_stage_payload(),
                    summary={
                        "rounds": len(deliberation.rounds),
                        "changed": deliberation.changed,
                        "stopped_because": deliberation.stopped_because,
                        "duration_ms": deliberation.duration_ms,
                    },
                    model_id=deliberation.model_id,
                )
            spec, source = plan_simulation(
                brief=(
                    brief_as_planner_input(extraction)
                    if extraction
                    else (expansion.description if expansion else None)
                ),
                prompt=values["prompt"],
                simulation_id=values["simulation_id"],
                seed=values["seed"],
                size_profile=values["size_profile"],
                target_platforms=values["target_platforms"],
                domain_constraints=values["domain_constraints"],
                settings=settings,
                planner_model_id=(planner_route.model_id if planner_route else None),
                planner_base_url=(planner_route.endpoint if planner_route else None),
            )
            changes, rejected = [], []

        resolved_capabilities, capability_gaps = resolve_capabilities(
            spec["capabilities"], spec["request"]["target_platforms"]
        )
        for gap in capability_gaps:
            spec.setdefault("approximations", []).append(
                {
                    "requirement_id": "req_prompt_fidelity",
                    "reason": (
                        f"{gap['capability_id']} is {gap['status']}: {gap['reason']}"
                    )[:300],
                    "user_visible": True,
                }
            )
        critic_route = route_model(
            "critic", tenant_id=values["tenant_id"], routing_key=run_id
        )
        vision_route = route_model(
            "vision", tenant_id=values["tenant_id"], routing_key=run_id
        )
        _persist_spec_and_governance(
            run_id=run_id,
            values=values,
            spec=spec,
            source=source,
            planner_route=planner_route,
            critic_route=critic_route,
            vision_route=vision_route,
            capability_gaps=capability_gaps,
            resolved_capabilities=resolved_capabilities,
        )
        _update_run(
            run_id,
            state="queued_build",
            stage="asset_resolution",
            spec_hash=hashlib.sha256(
                json.dumps(spec, sort_keys=True, separators=(",", ":")).encode()
            ).hexdigest(),
            localized_changes=changes,
            rejected=rejected,
        )
        build_simulation_generation.apply_async(args=[run_id])
        return run_id
    except Exception as exc:
        _update_run(
            run_id,
            state="failed_planning",
            stage="requirements",
            error={
                "code": "SIMULATION_PLANNING_ERROR",
                "type": type(exc).__name__,
                "message": str(exc)[:500],
            },
        )
        _release_slot(run_id)
        return run_id


@celery_app.task(name="build_simulation_generation")
def build_simulation_generation(run_id: str) -> str:
    """Resolve assets, compile, validate and publish from the persisted spec."""
    settings = get_settings()
    try:
        with db.session_scope() as session:
            loaded = _run_values(session, run_id)
            if loaded is None:
                return f"missing:{run_id}"
            run, values = loaded
            if run.state in {"completed", "failed_validation"}:
                return run_id
            spec_record = session.get(SimulationSpecRecord, run.spec_id)
            if spec_record is None:
                raise RuntimeError("persisted SimulationSpec is missing")
            spec = spec_record.body
            spec_record_id = spec_record.id
            planner_record = dict((run.model_routes or {}).get("planner") or {})
            planner_digest = planner_record.get("digest")
            changes = list((run.detail or {}).get("localized_changes", []))
            existing_evidence = {
                row.layer: row.status
                for row in session.query(ValidationEvidence).filter_by(
                    run_id=run_id, mandatory=True
                )
            }
            base_world_plan = None
            if values["base_spec_id"]:
                previous_plan = (
                    session.query(WorldPlanRecord)
                    .filter_by(spec_id=values["base_spec_id"])
                    .order_by(WorldPlanRecord.created_at.desc())
                    .first()
                )
                base_world_plan = previous_plan.body if previous_plan else None

        planner_memory_route = route_model(
            "planner", tenant_id=values["tenant_id"], routing_key=run_id
        )
        critic_route = route_model(
            "critic", tenant_id=values["tenant_id"], routing_key=run_id
        )
        vision_route = route_model(
            "vision", tenant_id=values["tenant_id"], routing_key=run_id
        )
        _update_run(run_id, state="building", stage="native_world_plan")
        result = run_native_pipeline(
            spec=spec,
            settings=settings,
            run_id=run_id,
            tenant_id=values["tenant_id"],
            planner_memory_route=planner_memory_route,
            planner_digest=planner_digest,
            critic_route=critic_route,
            vision_route=vision_route,
            base_world_plan=base_world_plan,
            changed_paths=changes,
        )
        reports = dict(result["reports"])
        for layer, report in _planning_gate_reports(spec).items():
            if layer not in existing_evidence:
                reports[layer] = report
        status_by_layer = {
            **existing_evidence,
            **{layer: report["status"] for layer, report in reports.items()},
        }
        for layer in sorted(MANDATORY_PREPUBLICATION_LAYERS):
            if layer not in status_by_layer:
                reports[layer] = {
                    "status": "NOT_RUN",
                    "validator": "mandatory_validation_contract",
                    "errors": [{"code": "MANDATORY_VALIDATOR_NOT_RUN"}],
                    "evidence": {},
                    "requirement_ids": [],
                }
                status_by_layer[layer] = "NOT_RUN"
        prepublication_failures = sorted(
            layer
            for layer in MANDATORY_PREPUBLICATION_LAYERS
            if status_by_layer.get(layer) != "PASS"
        )
        artifacts: dict[str, tuple[str, str | None]] = {}
        if prepublication_failures:
            reports["artifact_publication"] = {
                "status": "NOT_RUN",
                "validator": "private_artifact_gateway",
                "errors": [
                    {
                        "code": "ARTIFACT_PUBLICATION_BLOCKED_BY_VALIDATION",
                        "failed_layers": prepublication_failures,
                    }
                ],
                "evidence": {},
                "requirement_ids": [],
            }
        else:
            artifacts, reports["artifact_publication"] = _publish_staged_artifacts(
                result=result,
                settings=settings,
                values=values,
                run_id=run_id,
            )

        with db.session_scope() as session:
            plan_id = new_resource_id("world_plan")
            plan_record = WorldPlanRecord(
                id=plan_id,
                run_id=run_id,
                spec_id=spec_record_id,
                simulation_id=values["simulation_id"],
                tenant_id=values["tenant_id"],
                plan_hash=result["world_plan_hash"],
                schema_version=result["world_plan"]["schema_version"],
                compiler_version="semantic_pcg_native_v1",
                body=result["world_plan"],
            )
            session.add(plan_record)
            session.flush()
            run = session.get(GenerationRun, run_id)
            run.world_plan_id = plan_id
            run.model_routes = {
                **dict(run.model_routes or {}),
                **result["ranker_routes"],
            }
            for descriptor in result["asset_descriptors"].values():
                session.add(
                    AssetDescriptorRecord(
                        id=new_resource_id("asset_descriptor"),
                        run_id=run_id,
                        simulation_id=values["simulation_id"],
                        tenant_id=values["tenant_id"],
                        entity_id=descriptor["entity_id"],
                        asset_ref=descriptor["asset_ref"],
                        content_hash=descriptor["content_hash"],
                        measurement_status=descriptor["measurement"]["status"],
                        body=descriptor,
                    )
                )
            for layer, report in reports.items():
                _record_evidence(
                    session,
                    run_id,
                    layer=layer,
                    status=report["status"],
                    # From the contract, not hardcoded. Every row was stored
                    # `mandatory=True`, including `visual_semantic`, which
                    # ADVISORY_LAYERS explicitly excludes. Release decisions
                    # filter by the contract so publication was never actually
                    # blocked, but the stored flag is what the report endpoint
                    # returns and what the UI renders, so an advisory layer was
                    # shown to users as "required" and its failure looked like a
                    # broken build instead of a note.
                    mandatory=layer in MANDATORY_VALIDATION_LAYERS,
                    validator=report["validator"],
                    errors=report.get("errors", []),
                    evidence=report.get("evidence", {}),
                    requirement_ids=report.get("requirement_ids", []),
                )
            session.flush()
            evidence_rows = session.query(ValidationEvidence).filter_by(
                run_id=run_id, mandatory=True
            )
            final_statuses = {row.layer: row.status for row in evidence_rows}
            mandatory_failures = sorted(
                {
                    layer
                    for layer in MANDATORY_VALIDATION_LAYERS
                    if final_statuses.get(layer) != "PASS"
                }
                | {
                    # Rows that did not pass AND are actually mandatory. This
                    # clause used to take EVERY non-PASS row, which made the
                    # field's name a lie: an advisory layer landed in
                    # `mandatory_failures` purely by not passing, so marking a
                    # layer advisory had no effect anywhere and publication
                    # stayed blocked by a gate that was supposed to only advise.
                    row.layer
                    for row in evidence_rows
                    if row.status != "PASS" and row.layer in MANDATORY_VALIDATION_LAYERS
                }
            )
            run.repair_attempts = len(result["repair_lineage"])
            run.detail = {
                **dict(run.detail or {}),
                "world_plan_hash": result["world_plan_hash"],
                "semantic_repair_lineage": result["repair_lineage"],
                "asset_resolution": result["asset_manifest"],
                "mandatory_failures": mandatory_failures,
            }
            simulation = session.get(Simulation, values["simulation_id"])
            if mandatory_failures:
                run.state = "failed_validation"
                run.stage = "validation"
                simulation.status = "failed_validation"
            else:
                for kind, (uri, platform) in artifacts.items():
                    session.add(
                        SimulationArtifact(
                            id=new_resource_id("artifact"),
                            run_id=run_id,
                            kind=kind,
                            platform=platform,
                            uri=uri,
                        )
                    )
                run.state = "completed"
                run.stage = "completed"
                simulation.status = "completed"
            run.completed_at = datetime.now(UTC)
        return run_id
    except Exception as exc:
        _update_run(
            run_id,
            state="failed_build",
            stage="failed",
            error={
                "code": "SIMULATION_PIPELINE_ERROR",
                "type": type(exc).__name__,
                "message": str(exc)[:500],
            },
        )
        return run_id
    finally:
        _release_slot(run_id)
