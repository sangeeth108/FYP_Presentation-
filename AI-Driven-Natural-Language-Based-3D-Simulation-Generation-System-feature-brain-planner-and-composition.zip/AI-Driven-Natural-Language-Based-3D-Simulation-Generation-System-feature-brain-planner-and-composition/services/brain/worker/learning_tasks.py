"""Service-identity privacy jobs for global and tenant-private training copies."""

from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

from core import db
from core.config import get_settings
from core.models import DatasetVersion, DataSubjectRequest, TrainingEligibility, TrainingRun
from learning.deletion import purge_training_copies
from learning.encryption import KmsEnvelopeCipher, seal_directory
from learning.export import export_frozen_dataset

from worker.celery_app import celery_app

_REPO = Path(__file__).resolve().parents[3]


def _tree_digest(root: Path) -> str:
    digest = hashlib.sha256()
    files = sorted(path for path in root.rglob("*") if path.is_file())
    if not files:
        raise RuntimeError("trainer produced no model artifact")
    for path in files:
        relative = path.relative_to(root).as_posix().encode("utf-8")
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
    return digest.hexdigest()


def _fixed_training_command(
    run: TrainingRun, export: dict, output_dir: Path
) -> list[str]:
    dataset_dir = Path(export["path"])
    common = [
        "--data",
        str(dataset_dir / "train.jsonl"),
        "--validation-data",
        str(dataset_dir / "validation.jsonl"),
        "--test-data",
        str(dataset_dir / "test.jsonl"),
        "--manifest",
        str(dataset_dir / "manifest.json"),
        "--out",
        str(output_dir),
    ]
    if run.target == "planner":
        script = _REPO / "eval" / "training" / "train_qlora.py"
        command = [sys.executable, str(script), *common, "--base", run.base_model]
        epochs = (run.config or {}).get("epochs")
        if epochs is not None:
            if not isinstance(epochs, (int, float)) or not 0.1 <= float(epochs) <= 10:
                raise RuntimeError("planner epochs must be between 0.1 and 10")
            command.extend(["--epochs", str(float(epochs))])
        return command
    if run.target in {"asset_ranker", "placement_ranker"}:
        script = _REPO / "eval" / "training" / "train_pairwise_ranker.py"
        return [
            sys.executable,
            str(script),
            *common,
            "--target",
            run.target,
        ]
    raise RuntimeError("unsupported governed training target")


@celery_app.task(name="execute_governed_training")
def execute_governed_training(run_id: str) -> dict:
    """Run one allowlisted trainer from an approved immutable dataset.

    There is deliberately no command or script field in the API contract.
    Operators enable this task only in the isolated signed GPU-training image.
    """
    settings = get_settings()
    if not settings.training_runner_enabled:
        raise RuntimeError("governed training runner is disabled")
    if settings.promptplay_env == "production" and not settings.production_training_enabled:
        raise RuntimeError("production training kill switch is disabled")
    work_root = Path(settings.training_work_dir).resolve()
    work_root.mkdir(parents=True, exist_ok=True)
    production = settings.promptplay_env == "production"
    plaintext_run_root: Path | None = None
    cipher: KmsEnvelopeCipher | None = None
    sealed_dataset_ref: str | None = None
    artifact_ref: str | None = None
    allowed_environment = {
        "PATH",
        "SYSTEMROOT",
        "WINDIR",
        "TEMP",
        "TMP",
        "HOME",
        "USERPROFILE",
        "LOCALAPPDATA",
        "CUDA_VISIBLE_DEVICES",
        "CUDA_HOME",
        "NVIDIA_VISIBLE_DEVICES",
        "HF_HOME",
        "HF_TOKEN",
        "HUGGINGFACE_HUB_CACHE",
        "TRANSFORMERS_CACHE",
        "PYTHONIOENCODING",
    }
    try:
        with db.session_scope() as session:
            run = session.get(TrainingRun, run_id)
            if run is None:
                raise RuntimeError("training run not found")
            if run.state != "QUEUED" or run.approved_at is None or not run.approved_by:
                raise RuntimeError("training run is not approved and queued")
            dataset = session.get(DatasetVersion, run.dataset_version_id)
            if dataset is None:
                raise RuntimeError("training dataset not found")
            dataset_scope = dataset.scope
            run.state = "PREPARING"
            if production:
                plaintext_base = Path(settings.training_plaintext_dir).resolve()
                plaintext_base.mkdir(parents=True, exist_ok=True, mode=0o700)
                plaintext_run_root = (plaintext_base / run_id).resolve()
                if plaintext_run_root.parent != plaintext_base:
                    raise RuntimeError("training plaintext path escaped its tmpfs root")
                if plaintext_run_root.exists():
                    shutil.rmtree(plaintext_run_root)
                plaintext_run_root.mkdir(mode=0o700)
                export_root = plaintext_run_root / "datasets"
                cipher = KmsEnvelopeCipher(
                    region=settings.kms_region,
                    endpoint_url=settings.kms_endpoint_url,
                )
                kms_key_id = (
                    settings.enterprise_adapter_kms_key_id
                    if dataset_scope == "tenant_private"
                    else settings.training_dataset_kms_key_id
                )
            else:
                export_root = work_root / "datasets"
                kms_key_id = ""
            export = export_frozen_dataset(
                session,
                dataset=dataset,
                export_root=export_root,
            )
            if production:
                sealed_dataset = (work_root / "sealed_datasets" / dataset.id).resolve()
                seal_directory(
                    Path(export["path"]),
                    sealed_dataset,
                    cipher=cipher,
                    key_id=kms_key_id,
                )
                sealed_dataset_ref = str(sealed_dataset)
            run.config = {
                **dict(run.config or {}),
                "export_manifest_hash": export["manifest_hash"],
                "export_file_hashes": export["files"],
                "dataset_envelope_ref": sealed_dataset_ref,
                "dataset_copy_ref": sealed_dataset_ref or export["path"],
                "dataset_encrypted_at_rest": production,
            }
            target = run.target

        if production:
            expected_parent = plaintext_run_root
        else:
            runs_root = (work_root / "runs").resolve()
            expected_parent = (runs_root / run_id).resolve()
            if expected_parent.parent != runs_root:
                raise RuntimeError("training artifact path escaped the controlled workspace")
        output_dir = (expected_parent / "model").resolve()
        if output_dir.parent != expected_parent:
            raise RuntimeError("training artifact path escaped the controlled workspace")
        output_dir.mkdir(parents=True, exist_ok=True)
        with db.session_scope() as session:
            current = session.get(TrainingRun, run_id)
            if current is None or current.state != "PREPARING":
                raise RuntimeError("training run changed while preparing")
            current.state = "RUNNING"
            command = _fixed_training_command(current, export, output_dir)

        environment = {
            key: value for key, value in os.environ.items() if key in allowed_environment
        }
        result = subprocess.run(
            command,
            cwd=str(_REPO),
            env=environment,
            capture_output=True,
            text=True,
            timeout=settings.training_subprocess_timeout_seconds,
            shell=False,
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"trainer exited {result.returncode}: {result.stderr[-1000:]}"
            )
        artifact_digest = _tree_digest(output_dir)
        if production:
            sealed_model = (work_root / "sealed_models" / run_id).resolve()
            model_key_id = (
                settings.enterprise_adapter_kms_key_id
                if target in {"planner", "asset_ranker", "placement_ranker"}
                and dataset_scope == "tenant_private"
                else settings.training_dataset_kms_key_id
            )
            seal_directory(
                output_dir,
                sealed_model,
                cipher=cipher,
                key_id=model_key_id,
            )
            artifact_ref = str(sealed_model)
        else:
            artifact_ref = str(output_dir)
    except Exception as exc:
        with db.session_scope() as session:
            failed = session.get(TrainingRun, run_id)
            if failed is not None:
                failed.state = "FAILED"
                failed.metrics = {
                    **dict(failed.metrics or {}),
                    "failure_type": type(exc).__name__,
                    "failure": str(exc)[:1000],
                    "failed_at": datetime.now(UTC).isoformat(),
                }
        raise
    finally:
        if plaintext_run_root is not None and plaintext_run_root.exists():
            shutil.rmtree(plaintext_run_root)

    with db.session_scope() as session:
        completed = session.get(TrainingRun, run_id)
        if completed is None:
            raise RuntimeError("training run disappeared")
        completed.state = "COMPLETED"
        completed.artifact_ref = artifact_ref
        completed.metrics = {
            **dict(completed.metrics or {}),
            "artifact_digest": f"sha256:{artifact_digest}",
            "dataset_manifest_hash": export["manifest_hash"],
            "stdout_tail": result.stdout[-2000:],
            "artifact_encrypted_at_rest": production,
        }
        completed.completed_at = datetime.now(UTC)
    return {
        "training_run_id": run_id,
        "state": "COMPLETED",
        "artifact_digest": f"sha256:{artifact_digest}",
    }


def _delete_dataset_copy_refs(refs: list[str]) -> int:
    work_root = Path(get_settings().training_work_dir).resolve()
    allowed_roots = {
        (work_root / "datasets").resolve(),
        (work_root / "sealed_datasets").resolve(),
    }
    removed = 0
    for value in refs:
        path = Path(value).resolve()
        if path in allowed_roots or not any(root in path.parents for root in allowed_roots):
            raise RuntimeError("training dataset deletion path escaped its controlled root")
        if path.exists():
            if not path.is_dir() or path.is_symlink():
                raise RuntimeError("training dataset copy is not a safe directory")
            shutil.rmtree(path)
            removed += 1
    return removed


@celery_app.task(name="purge_user_training_data")
def purge_user_training_data(
    owner_id: str,
    tenant_id: str,
    create_tombstones: bool,
    reason: str,
) -> dict:
    with db.session_scope() as session:
        result = purge_training_copies(
            session,
            owner_id=owner_id,
            tenant_id=tenant_id,
            create_tombstones=create_tombstones,
            reason=reason,
        )
    refs = result.pop("dataset_copy_refs", [])
    result["dataset_copy_directories_deleted"] = _delete_dataset_copy_refs(refs)
    return result


@celery_app.task(name="purge_all_user_training_data")
def purge_all_user_training_data(
    owner_id: str,
    create_tombstones: bool,
    reason: str,
    request_id: str | None = None,
) -> dict:
    try:
        refs: list[str] = []
        with db.session_scope() as session:
            tenant_ids = sorted(
                {
                    row[0]
                    for row in session.query(TrainingEligibility.tenant_id)
                    .filter_by(owner_id=owner_id)
                    .distinct()
                    .all()
                }
            )
            totals = {
                "dataset_items_removed": 0,
                "datasets_affected": 0,
                "models_quarantined": 0,
            }
            for tenant_id in tenant_ids:
                result = purge_training_copies(
                    session,
                    owner_id=owner_id,
                    tenant_id=tenant_id,
                    create_tombstones=create_tombstones,
                    reason=reason,
                )
                refs.extend(result.pop("dataset_copy_refs", []))
                for key in totals:
                    totals[key] += int(result[key])
        removed = _delete_dataset_copy_refs(refs)
        return {
            **totals,
            "tenants_affected": len(tenant_ids),
            "dataset_copy_directories_deleted": removed,
        }
    except Exception as exc:
        if request_id:
            with db.session_scope() as session:
                request = session.get(DataSubjectRequest, request_id)
                if request is not None:
                    request.state = "failed"
                    request.result = {
                        "code": "TRAINING_COPY_DELETION_FAILED",
                        "error_type": type(exc).__name__,
                    }
                    request.completed_at = datetime.now(UTC)
        raise
