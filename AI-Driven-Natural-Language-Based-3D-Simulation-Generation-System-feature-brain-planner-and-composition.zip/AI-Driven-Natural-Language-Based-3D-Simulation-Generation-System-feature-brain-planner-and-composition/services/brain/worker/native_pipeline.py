"""Canonical SimulationSpec -> measured WorldPlan -> Serendib artifacts pipeline."""

from __future__ import annotations

import hashlib
import json
import logging
import sys
from pathlib import Path

from assets.descriptors import descriptors_from_simulation_manifest
from behaviors.compiler import compile_behavior_plan, validate_compiled_behaviors
from capabilities.registry import resolve_capabilities
from core.stages import record_stage
from learning.rankers import load_active_ranker
from model_router.executors import run_independent_critic, run_visual_critic
from pcg.semantic import generate_semantic_world_plan, validate_semantic_world_plan
from repair.typed_patches import bounded_localized_repair
from verification.contracts import (
    deterministic_independent_critique,
    verify_requirement_traceability,
)

_REPO = Path(__file__).resolve().parents[3]
_WORKER = _REPO / "services" / "worker"
log = logging.getLogger(__name__)


def _replace_implausible_meshes(
    spec: dict, manifest: dict, work_dir: Path
) -> dict:
    """Rebuild any entity whose resolved mesh would normalise to the wrong shape.

    Returns the manifest with those entries replaced by procedural geometry built to
    the declared box, each carrying a `substitution` note so the swap appears in the
    stage summary an inspector reads rather than only in the geometry.

    Deliberately not fatal in any branch: this runs on every build, and an exception
    here would fail worlds that the defect it guards against would merely have made
    ugly.
    """
    from assets.descriptors import implausible_proportions, normalised_dimensions
    from asset_farm.procedural import resolve_procedural_asset

    for entity in spec.get("entities") or ():
        entity_id = entity.get("entity_id")
        entry = manifest.get(entity_id)
        if not entry or entry.get("tier") in {"unresolved", "procedural"}:
            continue
        imported = ((entry.get("qa") or {}).get("bbox_dimensions")) or None
        declared = ((entity.get("physical") or {}).get("bbox_m")) or None
        if not imported or not declared or len(imported) != 3 or len(declared) != 3:
            continue
        try:
            would_be = normalised_dimensions(declared, imported)
            implausible, ratio, axis = implausible_proportions(declared, would_be)
        except Exception:  # arithmetic on model-authored numbers
            continue
        if not implausible:
            continue
        # A rig cannot be rebuilt procedurally, and swapping a rigged mesh for a box
        # takes `rigged`/`locomotion_compatible` away from the descriptor -- which fails
        # the `animal` and `locomotion` capability qualifications and so fails the whole
        # world. The local generator refuses characters for exactly this reason
        # ("rig-less mesh gen is for props/scenery"), and this is the same rule.
        #
        # Measured: the curated Husky imports as [0.99, 3.19, 3.89] and normalises to
        # [0.19, 0.6, 0.73] against a declared [0.8, 0.6, 1.2], so a symmetric proportion
        # check flags it. A narrow dog that walks beats a correctly-proportioned box.
        if bool((entity.get("asset") or {}).get("requires_animation")):
            log.info(
                "%s is out of proportion (%.2fx on %s) but needs a rig; keeping the mesh",
                entity_id,
                ratio,
                "xyz"[axis],
            )
            continue
        try:
            replacement = resolve_procedural_asset(entity, work_dir / "procedural")
        except Exception:
            log.warning("could not rebuild %s procedurally; keeping the mesh", entity_id)
            continue
        if replacement.get("tier") == "unresolved":
            continue
        replacement["substitution"] = {
            # Both directions now, so an undershoot does not report itself as "0x".
            "reason": (
                (
                    f"the resolved mesh would have been {ratio:.1f}x its declared size "
                    f"on {'xyz'[axis]}"
                )
                if ratio >= 1.0
                else (
                    f"the resolved mesh would have been {1.0 / max(ratio, 1e-9):.0f}x "
                    f"too THIN on {'xyz'[axis]} -- a slab where a solid was declared"
                )
            )
            + "; rebuilt to the declared box",
            "declared_m": [round(float(value), 4) for value in declared],
            "would_have_been_m": [round(value, 4) for value in would_be],
        }
        replacement.setdefault("entity_id", entity_id)
        replacement.setdefault("curated_rel", None)
        replacement.setdefault(
            "requires_animation", bool((entity.get("asset") or {}).get("requires_animation"))
        )
        log.info(
            "replaced %s: mesh would have been %.3fx declared on %s",
            entity_id,
            ratio,
            "xyz"[axis],
        )
        manifest[entity_id] = replacement
    return manifest


def frontage_approximations(world_plan: dict) -> list[dict]:
    """What the layout could not honour, in the shape the report renders.

    `soft_relaxations` and `frontage_notes` have always been written onto the world
    plan and never surfaced anywhere a person looks -- the same gap `asset_tiers` had
    before the run page started reading it. An honest record that nothing displays is
    honest to nobody (rules 11/13), and a house that gave up its plot on the street is
    exactly the compromise somebody asked about.

    Only FRONTAGE relaxations are lifted. A `near` relaxation is a distance nobody
    stated in words, and reporting every one of those would bury the compromises that
    answer something the person actually described.

    A separate function rather than eight lines inline, so it can be tested against
    real plan data instead of by searching this file for a string.
    """
    summary = world_plan.get("constraint_summary") or {}
    records: list[dict] = []
    for relaxation in summary.get("soft_relaxations") or ():
        if not isinstance(relaxation, dict):
            continue
        if relaxation.get("constraint") != "frontage":
            continue
        records.append(
            {
                "requirement_id": str(relaxation.get("entity_id") or "unknown"),
                "reason": str(relaxation.get("reason") or "")[:300],
                "user_visible": True,
            }
        )
    for note in summary.get("frontage_notes") or ():
        if isinstance(note, dict):
            records.append(note)
    return records


def _report(
    status: str,
    validator: str,
    *,
    errors: list[dict] | None = None,
    evidence: dict | None = None,
    requirement_ids: list[str] | None = None,
) -> dict:
    return {
        "status": status,
        "validator": validator,
        "errors": errors or [],
        "evidence": evidence or {},
        "requirement_ids": requirement_ids or [],
    }


def _worker_imports() -> None:
    value = str(_WORKER)
    if value not in sys.path:
        sys.path.insert(0, value)


def _error(exc: Exception, code: str) -> dict:
    if hasattr(exc, "to_dict"):
        return exc.to_dict()
    return {
        "code": code,
        "path": "",
        "message": str(exc)[:500],
        "hint": "inspect the signed worker logs and retry the affected stage",
    }


def _unload_planner_for_asset_generation(planner_route) -> None:
    """Best-effort Ollama VRAM handoff before a real asset generator starts."""
    if (
        planner_route is None
        or planner_route.provider != "ollama"
        or not planner_route.endpoint
        or not planner_route.model_id
    ):
        return
    try:
        import httpx

        with httpx.Client(base_url=planner_route.endpoint, timeout=30.0) as client:
            response = client.post(
                "/api/generate",
                json={"model": planner_route.model_id, "keep_alive": 0},
            )
            response.raise_for_status()
        log.info("released planner VRAM before asset generation")
    except Exception as exc:  # noqa: BLE001 - memory handoff must not hide asset errors
        log.warning("could not release planner VRAM before asset generation: %s", exc)


def _release_asset_generator_memory(backend) -> None:
    """Release only in-process generator state; remote GPU workers own their memory."""
    if backend is None:
        return
    if backend.__class__.__module__ != "asset_farm.backends_local":
        return
    try:
        from asset_farm.backends_local import unload_models

        if unload_models():
            log.info("released in-process asset generator VRAM")
    except Exception as exc:  # noqa: BLE001 - validation must still report asset outcome
        log.warning("could not release in-process asset generator VRAM: %s", exc)



# Below this share of the world's longest side the content is islands on a plain rather
# than a place. Matches `_MIN_LAYOUT_FILL` in the critic; kept here too because the
# pipeline decides what to DO about it.
_TIGHTEN_FILL_BELOW = 0.55

# Room left around the content when the world is tightened: enough that nothing sits on
# the boundary, little enough that the place still reads as one.
_TIGHTEN_MARGIN_M = 6.0


def _content_span(world_plan: dict) -> tuple[float, float]:
    positions = [
        (entity.get("transform") or {}).get("position_m") or []
        for entity in world_plan.get("entities") or []
    ]
    positions = [p for p in positions if len(p) >= 3]
    if not positions:
        return 0.0, 0.0
    return (
        max(p[0] for p in positions) - min(p[0] for p in positions),
        max(p[2] for p in positions) - min(p[2] for p in positions),
    )


def _unplaced_count(world_plan: dict) -> int:
    summary = world_plan.get("constraint_summary") or {}
    return len(summary.get("unplaced_entities") or [])


def _tighten_world_to_its_content(
    spec: dict,
    world_plan: dict,
    *,
    descriptors: dict,
    behaviour_graphs: list,
    placement_ranker,
) -> tuple[dict, dict]:
    """Re-plan in a world sized to the content, keeping it only if nothing is lost.

    Returns `(plan, report)`. The report always says what was measured and whether the
    tighter plan was taken, so a loose world that could not be tightened is visible
    rather than silent.
    """
    positions = [
        (entity.get("transform") or {}).get("position_m") or []
        for entity in world_plan.get("entities") or []
    ]
    positions = [p for p in positions if len(p) >= 3]
    span_x, span_z = _content_span(world_plan)
    bounds = world_plan.get("world_bounds") or {}
    minimum = bounds.get("min") or [0, 0, 0]
    maximum = bounds.get("max") or [0, 0, 0]
    world_x = float(maximum[0]) - float(minimum[0])
    world_z = float(maximum[2]) - float(minimum[2])
    fill = max(
        span_x / world_x if world_x else 0.0,
        span_z / world_z if world_z else 0.0,
    )
    report = {
        "fill_ratio": round(fill, 3),
        "world_m": [round(world_x, 1), round(world_z, 1)],
        "content_span_m": [round(span_x, 1), round(span_z, 1)],
    }
    # MEASURE ONLY. The re-plan that used to live here has been removed.
    #
    # It shrank `environment.dimensions_m` and re-planned, and it could never work: this
    # session measured that the declared extent is INERT, because
    # `_content_scaled_dimensions` recomputes the world from content x
    # `_PACKING_ALLOWANCE`. Observed on run_f58d4b7cb2d44e6ead4ce7abcf4b5eda -- the world
    # was 39.9 x 34.0 m before and 39.9 x 34.0 m after, for a fill change of 0.50 to
    # 0.52, while the re-plan discarded a world that `bounded_localized_repair` had
    # already fixed and lost `ent_ped_door`, failing the run on a cascade of seven gates.
    #
    # Keeping an action that cannot achieve its purpose and can undo repair is strictly
    # worse than reporting the number, so what remains is the number. World size is
    # bounded below by hard adjacency (see `_PACKING_ALLOWANCE`), and the way to raise
    # fill is more content, not a smaller world.
    if fill < _TIGHTEN_FILL_BELOW and positions:
        report["sparse"] = True
    return world_plan, report


def run_native_pipeline(
    *,
    spec: dict,
    settings,
    run_id: str,
    tenant_id: str,
    planner_memory_route,
    planner_digest: str | None,
    critic_route,
    vision_route,
    base_world_plan: dict | None = None,
    changed_paths: list[str] | None = None,
) -> dict:
    _worker_imports()
    from asset_farm.pipeline import resolution_summary, resolve_simulation_assets
    from asset_farm.registry import select_backend
    from godot_client.exporter import export_desktop, export_web
    from godot_client.packager import package_directory, package_project
    from godot_client.simulation_probe import (
        capture_canonical_views,
        compare_platform_traces,
        run_desktop_probe,
        run_project_probe,
        run_web_probe,
    )
    from godot_client.simulation_project_writer import write_simulation_project
    from godot_client.surfaces import resolve_ground_family

    # The spec the rest of the pipeline builds from, recorded before anything
    # consumes it so the inspector can show what the brain actually decided even
    # when a later stage fails.
    record_stage(
        run_id,
        "scene_spec",
        status="PASS",
        payload=spec,
        summary={
            "entities": len(spec.get("entities") or []),
            "capabilities": len(spec.get("capabilities") or []),
            "requirements": len(spec.get("requirements") or []),
            "scatter_species": len(spec.get("scatter") or []),
            "schema_version": spec.get("schema_version"),
        },
        model_id=(spec.get("lineage") or {}).get("planner"),
    )

    artifacts_root = Path(settings.artifacts_dir).resolve()
    staging_root = artifacts_root / ".staging" / run_id
    project_dir = staging_root / "project"
    kit_dir = _REPO / "content" / "kits"
    backend = select_backend(settings)
    asset_ranker = load_active_ranker(
        "asset_ranker", tenant_id=tenant_id, routing_key=run_id
    )
    placement_ranker = load_active_ranker(
        "placement_ranker", tenant_id=tenant_id, routing_key=run_id
    )
    if backend is not None:
        _unload_planner_for_asset_generation(planner_memory_route)
    try:
        manifest = resolve_simulation_assets(
            spec,
            kit_dir=kit_dir if kit_dir.is_dir() else None,
            cache_dir=artifacts_root / "asset_cache",
            work_dir=artifacts_root / "asset_work" / run_id,
            backend=backend,
            embed_base_url=(
                settings.llm_base_url
                if settings.rag_enabled and settings.llm_enabled
                else None
            ),
            asset_ranker=asset_ranker,
        )
    finally:
        _release_asset_generator_memory(backend)

    # A resolved mesh still has to be the SHAPE that was asked for.
    #
    # Normalisation scales an import by height, and a mesh whose proportions disagree
    # with the declaration explodes: an attic window declared as a ten-centimetre panel
    # came back lying on its face and normalised to 10.84 m across, which no room could
    # hold. It went unplaced and took the world plan and five cascading gates with it.
    #
    # Swapped here rather than refused later. The descriptor builder runs after this and
    # its errors are terminal -- refusing there fails `asset_geometry` instead of
    # falling back, which is measurably worse than the defect it was meant to fix. The
    # ladder's own floor is procedural geometry built to the declared box exactly, so
    # that is what an implausible mesh is replaced with.
    manifest = _replace_implausible_meshes(
        spec, manifest, artifacts_root / "asset_work" / run_id
    )

    record_stage(
        run_id,
        "assets",
        status="PASS",
        payload={"manifest": manifest},
        summary={
            "resolved": len(manifest),
            "tiers": resolution_summary(manifest),
            # A body that is not the one the prompt asked for is the single most
            # visible compromise the farm can make; it belongs in the summary the
            # inspector reads, not only in a manifest note.
            "substitutions": [
                {"entity_id": label, **entry["substitution"]}
                for label, entry in sorted(manifest.items())
                if entry.get("substitution")
            ],
        },
    )
    descriptors, descriptor_errors = descriptors_from_simulation_manifest(spec, manifest)
    resolved_capabilities, capability_gaps = resolve_capabilities(
        spec["capabilities"],
        spec["request"]["target_platforms"],
        spec=spec,
        asset_descriptors=descriptors,
        final=True,
    )
    behavior_plan, behavior_compile_errors = compile_behavior_plan(spec, descriptors)
    behavior_validation = validate_compiled_behaviors(behavior_plan)

    affected_entity_ids = None
    changes = changed_paths or []
    if base_world_plan is not None:
        if "environment.dimensions_m" in changes:
            affected_entity_ids = {entity["entity_id"] for entity in spec["entities"]}
        else:
            affected_entity_ids = {
                path.split(".", 1)[1]
                for path in changes
                if path.startswith("entities.")
            }
    world_plan = generate_semantic_world_plan(
        spec,
        descriptors,
        behavior_plan["graphs"],
        preserved_plan=base_world_plan,
        affected_entity_ids=affected_entity_ids,
        placement_ranker=placement_ranker,
    )
    world_plan, spatial_report, repair_lineage = bounded_localized_repair(
        spec=spec,
        asset_descriptors=descriptors,
        behaviour_graphs=behavior_plan["graphs"],
        initial_plan=world_plan,
        validator=lambda candidate: validate_semantic_world_plan(
            candidate, require_measured_assets=False
        ),
        max_cycles=3,
        placement_ranker=placement_ranker,
    )
    measured_report = validate_semantic_world_plan(
        world_plan, require_measured_assets=True
    )
    traceability = verify_requirement_traceability(spec, world_plan, behavior_plan)
    deterministic_critic = deterministic_independent_critique(
        spec, world_plan, behavior_plan
    )
    plan_json = json.dumps(world_plan, sort_keys=True, separators=(",", ":"))
    plan_hash = hashlib.sha256(plan_json.encode("utf-8")).hexdigest()

    scatter_plan = world_plan.get("scatter") or {}

    # See the layout NOW, not after assets and a Godot build.
    #
    # Nothing looked at pixels until the end of the run -- about ten minutes --
    # so the cheap mistakes cost the full price to find: an oak lying felled, a
    # village spread over 51 m of a 73 m world with the player 52 m from half
    # of it, content huddled in one corner. All invisible in the JSON directly
    # above and obvious in a picture. This costs ~30 ms and needs no assets, no
    # engine and no GPU, so it can sit in the loop rather than at the end of it.
    #
    # It never raises: a preview that fails must not take a run with it.
    # A world sized to its content, when it can be had for free. Measured on two real
    # runs: fill 0.48 and 0.51, meaning half the ground was empty and the place read as
    # scattered objects. Done BEFORE the preview so the picture shows what actually
    # ships, and before the build, which is the whole reason the preview exists.
    world_plan, layout_report = _tighten_world_to_its_content(
        spec,
        world_plan,
        descriptors=descriptors,
        behaviour_graphs=behavior_plan["graphs"],
        placement_ranker=placement_ranker,
    )

    preview_report: dict = {"rendered": False, "reason": "not attempted"}
    try:
        from pcg.preview import render_world_plan

        preview_report = render_world_plan(
            world_plan, staging_root / "preview" / "layout.png"
        )
    except Exception as exc:  # noqa: BLE001 -- diagnostics cannot break the run
        preview_report = {"rendered": False, "reason": f"{type(exc).__name__}: {exc}"}

    record_stage(
        run_id,
        "layout",
        status="PASS" if spatial_report.get("status") == "PASS" else "FAIL",
        payload=world_plan,
        summary={
            "layout": layout_report,
            "placed_entities": len(world_plan.get("entities") or []),
            "scatter_instances": len(scatter_plan.get("instances") or []),
            "repair_attempts": len(repair_lineage),
            "world_plan_hash": plan_hash,
            # Content vs world is the number that catches a village lost on a
            # plain, without anyone having to open the image.
            "preview": preview_report,
        },
        errors=list(spatial_report.get("errors") or []),
    )

    # Advisory errors describe decoration that degraded to a placeholder, not a
    # world that cannot be built; they are reported but must not fail the gate.
    scatter_advisories = [
        error for error in descriptor_errors if error.get("severity") == "advisory"
    ]
    measurement_errors = [
        error for error in descriptor_errors if error.get("severity") != "advisory"
    ]
    measurement_errors.extend(
        error
        for error in measured_report.get("errors", [])
        if error.get("code") == "ASSET_NOT_MEASURED"
    )
    behavior_errors = [
        *behavior_compile_errors,
        *behavior_validation.get("errors", []),
    ]
    animation_errors = []
    for entity in spec["entities"]:
        if not entity["asset"]["requires_animation"]:
            continue
        descriptor = descriptors.get(entity["entity_id"])
        if (
            descriptor is None
            or not descriptor["animation"]["rigged"]
            or not descriptor["animation"]["locomotion_compatible"]
        ):
            animation_errors.append(
                {
                    "code": "ANIMATED_ENTITY_ASSET_INCOMPATIBLE",
                    "entity_id": entity["entity_id"],
                    "message": "animated entities require a rigged locomotion-compatible asset",
                }
            )

    model_critic = run_independent_critic(
        critic_route,
        spec=spec,
        world_plan=world_plan,
        behavior_plan=behavior_plan,
        settings=settings,
    )
    reports = {
        "capability_resolution": _report(
            "FAIL" if capability_gaps else "PASS",
            "asset_qualified_capability_registry",
            errors=[
                {
                    "code": "CAPABILITY_INCOMPLETE",
                    **gap,
                }
                for gap in capability_gaps
            ],
            evidence={
                "resolved": [
                    {
                        "capability_id": item["capability_id"],
                        "pack_id": item["pack_id"],
                        "pack_version": item["pack_version"],
                        "qualification_status": item.get("qualification_status", "PASS"),
                    }
                    for item in resolved_capabilities
                ]
            },
        ),
        "requirement_traceability": _report(
            traceability["status"],
            "requirement_contract_traceability",
            errors=traceability["errors"],
            evidence=traceability.get("evidence", {}),
            requirement_ids=[item["requirement_id"] for item in spec["requirements"]],
        ),
        "deterministic_critic": _report(
            deterministic_critic["status"],
            "independent_contract_critic",
            errors=deterministic_critic["errors"],
            evidence=deterministic_critic.get("evidence", {}),
        ),
        "independent_model_critic": _report(
            model_critic["status"],
            critic_route.model_id if critic_route is not None else "critic_model_router",
            errors=model_critic["errors"],
            evidence=model_critic.get("evidence", {}),
        ),
        "behavior_compilation": _report(
            "FAIL" if behavior_errors else "PASS",
            "typed_behavior_graph_compiler",
            errors=behavior_errors,
            evidence={
                "graph_count": len(behavior_plan["graphs"]),
                "offline_probe_count": len(behavior_validation.get("results", [])),
            },
        ),
        "asset_geometry": _report(
            (
                "PASS"
                if not measurement_errors
                and all(
                    entity["entity_id"] in descriptors for entity in spec["entities"]
                )
                else "FAIL"
            ),
            "asset_descriptor_and_imported_bounds",
            errors=measurement_errors,
            evidence={
                "descriptor_count": len(descriptors),
                "required_entity_count": len(spec["entities"]),
                "scatter_species_measured": sum(
                    1
                    for species in spec.get("scatter") or ()
                    if species["species_id"] in descriptors
                ),
                "scatter_advisories": scatter_advisories,
                "asset_tiers": resolution_summary(manifest),
                "world_plan_hash": plan_hash,
            },
        ),
        "asset_animation_compatibility": _report(
            "FAIL" if animation_errors else "PASS",
            "skeleton_and_animation_contract",
            errors=animation_errors,
        ),
        "semantic_placement": _report(
            spatial_report["status"],
            "semantic_world_plan_constraints",
            errors=spatial_report.get("errors", []),
            evidence={**spatial_report.get("evidence", {}), "world_plan_hash": plan_hash},
        ),
    }

    prerequisites_pass = all(
        reports[name]["status"] == "PASS"
        for name in (
            "capability_resolution",
            "behavior_compilation",
            "asset_geometry",
            "asset_animation_compatibility",
            "semantic_placement",
        )
    )
    # ADR-0020: a gap the prompt did not ask about is still a gap somebody may notice.
    for entity_id in (world_plan.get("constraint_summary") or {}).get(
        "unplaced_incidental"
    ) or ():
        spec.setdefault("approximations", []).append(
            {
                "requirement_id": str(entity_id),
                "reason": (
                    "there was no clear ground for this, so it was left out; it is part "
                    "of the scenery rather than something the description asked for"
                )[:300],
                "user_visible": True,
            }
        )

    for record in frontage_approximations(world_plan):
        spec.setdefault("approximations", []).append(record)

    # Surface synthesis falls back to a neutral family when nothing named one.
    # Recorded rather than passed off as the requested surface (§7 approximation
    # record), so a flat-looking ground is traceable to an unnamed terrain.
    _, surface_approximation = resolve_ground_family(spec.get("environment") or {})
    if surface_approximation:
        spec.setdefault("approximations", []).append(
            {
                "requirement_id": "req_prompt_fidelity",
                "reason": surface_approximation[:300],
                "user_visible": True,
            }
        )

    compiled = False
    if prerequisites_pass:
        try:
            write_simulation_project(spec, world_plan, descriptors, project_dir)
            compiled = True
            reports["native_world_plan_compilation"] = _report(
                "PASS",
                "world_plan_to_serendib_scene_compiler",
                evidence={"world_plan_hash": plan_hash, "project_dir": str(project_dir)},
            )
        except Exception as exc:
            reports["native_world_plan_compilation"] = _report(
                "FAIL",
                "world_plan_to_serendib_scene_compiler",
                errors=[_error(exc, "NATIVE_COMPILATION_FAILED")],
            )
    else:
        reports["native_world_plan_compilation"] = _report(
            "NOT_RUN",
            "world_plan_to_serendib_scene_compiler",
            errors=[{"code": "NATIVE_COMPILATION_PREREQUISITE_FAILED"}],
        )

    artifact_paths: dict[str, Path] = {}
    export_results: dict[str, dict] = {}
    project_probe = _report(
        "NOT_RUN",
        "serendib_runtime_probe",
        errors=[{"code": "NATIVE_PROJECT_NOT_COMPILED"}],
    )
    visual = _report(
        "NOT_RUN",
        "vision_model",
        errors=[{"code": "NATIVE_PROJECT_NOT_COMPILED"}],
    )
    parity = _report(
        "NOT_RUN",
        "desktop_web_state_probe",
        errors=[{"code": "NATIVE_PROJECT_NOT_COMPILED"}],
    )
    export_report = _report(
        "NOT_RUN",
        "serendib_dual_export",
        errors=[{"code": "NATIVE_PROJECT_NOT_COMPILED"}],
    )

    if compiled:
        source_zip = staging_root / "project.zip"
        package_project(project_dir, source_zip, spec["meta"]["title"])
        artifact_paths["editable_project"] = source_zip
        if not settings.godot_bin:
            unavailable = [{"code": "SERENDIB_BINARY_NOT_CONFIGURED"}]
            project_probe = _report("UNAVAILABLE", "serendib_runtime_probe", errors=unavailable)
            export_report = _report("UNAVAILABLE", "serendib_dual_export", errors=unavailable)
            visual = _report("UNAVAILABLE", "vision_model", errors=unavailable)
            parity = _report("UNAVAILABLE", "desktop_web_state_probe", errors=unavailable)
        else:
            godot_bin = Path(settings.godot_bin)
            project_probe_result = run_project_probe(godot_bin, project_dir)
            project_probe = _report(
                project_probe_result["status"],
                "serendib_runtime_probe",
                errors=project_probe_result["errors"],
                evidence=project_probe_result.get("evidence", {}),
            )
            export_errors: list[dict] = []
            targets = set(spec["request"]["target_platforms"])
            if "web" in targets:
                try:
                    export_results["web"] = export_web(project_dir, godot_bin)
                    artifact_paths["web_build"] = export_results["web"]["build_dir"]
                except Exception as exc:
                    export_errors.append(_error(exc, "WEB_EXPORT_FAILED"))
            if "desktop" in targets:
                try:
                    export_results["desktop"] = export_desktop(
                        project_dir, godot_bin, settings.desktop_export_platform
                    )
                    desktop_zip = staging_root / "desktop.zip"
                    package_directory(export_results["desktop"]["build_dir"], desktop_zip)
                    artifact_paths["desktop_build"] = desktop_zip
                except Exception as exc:
                    export_errors.append(_error(exc, "DESKTOP_EXPORT_FAILED"))
            export_report = _report(
                "FAIL" if export_errors else "PASS",
                "serendib_dual_export",
                errors=export_errors,
                evidence={
                    "requested_platforms": sorted(targets),
                    "exported_platforms": sorted(export_results),
                },
            )

            if vision_route is None:
                visual = _report(
                    "UNAVAILABLE",
                    "vision_model_router",
                    errors=[{"code": "VISION_VALIDATOR_UNAVAILABLE"}],
                )
            else:
                capture = capture_canonical_views(godot_bin, project_dir)
                image_paths = [
                    Path(value)
                    for value in capture.get("evidence", {}).get("image_paths", [])
                ]
                if capture["status"] != "PASS":
                    visual = _report(
                        capture["status"],
                        "canonical_view_capture",
                        errors=capture["errors"],
                        evidence=capture.get("evidence", {}),
                    )
                else:
                    vision = run_visual_critic(
                        vision_route,
                        spec=spec,
                        image_paths=image_paths,
                        settings=settings,
                        asset_descriptors=descriptors,
                        view_manifest=list(
                            capture.get("evidence", {}).get("view_manifest", [])
                        ),
                    )
                    visual = _report(
                        vision["status"],
                        vision_route.model_id,
                        errors=vision["errors"],
                        evidence={
                            **vision.get("evidence", {}),
                            "image_hashes": {
                                path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                                for path in image_paths
                            },
                        },
                    )

            if {"web", "desktop"}.issubset(targets):
                if "web" in export_results and "desktop" in export_results:
                    desktop_probe = run_desktop_probe(
                        export_results["desktop"]["executable"]
                    )
                    browser_path = (
                        Path(settings.playwright_browser_bin)
                        if settings.playwright_browser_bin
                        else None
                    )
                    web_probe = run_web_probe(
                        export_results["web"]["build_dir"], browser_path
                    )
                    compared = compare_platform_traces(desktop_probe, web_probe)
                    parity = _report(
                        compared["status"],
                        "desktop_web_state_probe",
                        errors=compared["errors"],
                        evidence=compared.get("evidence", {}),
                    )
                else:
                    parity = _report(
                        "NOT_RUN",
                        "desktop_web_state_probe",
                        errors=[{"code": "DUAL_EXPORT_FAILED"}],
                    )
            else:
                parity = _report(
                    "PASS",
                    "desktop_web_state_probe",
                    evidence={"not_applicable": True, "requested_platforms": sorted(targets)},
                )

    reports["runtime_interactions"] = project_probe
    reports["navigation_reachability"] = {
        **project_probe,
        "validator": "serendib_navigation_runtime_probe",
    }
    reports["import_export"] = export_report
    reports["visual_semantic"] = visual
    reports["cross_platform_parity"] = parity
    # A spec the brain did not actually author cannot pass lineage.
    #
    # When the planner call fails the pipeline substitutes a canned spec and
    # records `deterministic_fallback_v1` -- and NOTHING read that marker, so a
    # run whose prompt asked for "a small village ... and a dog wandering
    # between them" produced a stock four-house village with no dog and passed
    # 13 of 15 gates. The fallback is internally consistent, so every structural
    # gate is satisfied; only the vision critic noticed, and it is the one gate
    # that is allowed to be UNAVAILABLE. Lineage is exactly the claim being
    # violated -- this artifact does not derive from this prompt -- so it fails
    # here, loudly, rather than shipping something the user never asked for.
    planner_marker = str((spec.get("lineage") or {}).get("planner") or "")
    lineage_errors: list[dict] = []
    if planner_marker.startswith("deterministic_fallback"):
        lineage_errors.append(
            {
                "code": "SPEC_NOT_MODEL_AUTHORED",
                "path": "lineage.planner",
                "message": (
                    "the planning model did not produce this specification; it "
                    f"came from the built-in fallback ({planner_marker}), which "
                    "describes a stock scene rather than this prompt"
                ),
                "hint": (
                    "check the planner model is reachable and that "
                    "llm_timeout_seconds covers a full guided-decoding pass"
                ),
            }
        )
    reports["lineage"] = _report(
        "FAIL" if lineage_errors else "PASS",
        "generation_lineage_manifest",
        errors=lineage_errors,
        evidence={
            "planner": planner_marker,
            "spec_hash": hashlib.sha256(
                json.dumps(spec, sort_keys=True, separators=(",", ":")).encode("utf-8")
            ).hexdigest(),
            "world_plan_hash": plan_hash,
            "seed": spec["meta"]["seed"],
            "planner_digest": planner_digest,
            "critic_digest": critic_route.model_digest if critic_route else None,
            "vision_digest": vision_route.model_digest if vision_route else None,
            "asset_ranker_digest": (
                asset_ranker.model_digest if asset_ranker is not None else None
            ),
            "placement_ranker_digest": (
                placement_ranker.model_digest if placement_ranker is not None else None
            ),
        },
    )
    # The full 18-layer verdict set, so the inspector can show exactly which gate
    # objected instead of only the run's final state.
    record_stage(
        run_id,
        "verify",
        status=(
            "PASS"
            if all(item.get("status") == "PASS" for item in reports.values())
            else "FAIL"
        ),
        payload={"reports": reports},
        summary={
            "layers": len(reports),
            "passed": sum(1 for item in reports.values() if item.get("status") == "PASS"),
            "failed": sorted(
                layer
                for layer, item in reports.items()
                if item.get("status") not in {"PASS", "NOT_RUN"}
            ),
        },
    )

    return {
        "world_plan": world_plan,
        "world_plan_hash": plan_hash,
        "asset_manifest": manifest,
        "asset_descriptors": descriptors,
        "behavior_plan": behavior_plan,
        "repair_lineage": repair_lineage,
        "reports": reports,
        "artifact_paths": artifact_paths,
        "staging_root": staging_root,
        "ranker_routes": {
            "asset_ranker": (
                {
                    "version": asset_ranker.model_version_id,
                    "digest": asset_ranker.model_digest,
                    "deployment": "active",
                }
                if asset_ranker is not None
                else None
            ),
            "placement_ranker": (
                {
                    "version": placement_ranker.model_version_id,
                    "digest": placement_ranker.model_digest,
                    "deployment": "active",
                }
                if placement_ranker is not None
                else None
            ),
        },
    }
