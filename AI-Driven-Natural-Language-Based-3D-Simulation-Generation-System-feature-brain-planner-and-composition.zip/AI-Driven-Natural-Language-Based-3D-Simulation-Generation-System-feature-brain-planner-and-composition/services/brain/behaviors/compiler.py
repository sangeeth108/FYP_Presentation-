"""Compile semantic capabilities into data-only deterministic state machines.

The compiler emits no scripts. Runtime packs consume these graphs through
allowlisted bindings, and probes assert observable state rather than appearance.
"""

from __future__ import annotations

import json
from copy import deepcopy
from functools import lru_cache
from pathlib import Path

import jsonschema
from capabilities.registry import capability_entity_error, capability_index

_REPO = Path(__file__).resolve().parents[3]
_SCHEMA_PATH = _REPO / "contracts" / "behavior_plan.schema.json"


@lru_cache(maxsize=1)
def behavior_plan_schema() -> dict:
    return json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))


def validate_behavior_plan(plan: dict) -> None:
    jsonschema.validate(plan, behavior_plan_schema())


def _state(state_id: str, **properties) -> dict:
    return {"state_id": state_id, "observable_properties": properties}


def _transition(
    from_state: str,
    to_state: str,
    trigger: str,
    *,
    duration_ms: int = 0,
    effects: dict | None = None,
) -> dict:
    return {
        "transition_id": f"{from_state}__{trigger}__{to_state}",
        "from_state": from_state,
        "to_state": to_state,
        "trigger": trigger,
        "guard": {"kind": "always", "parameters": {}},
        "effects": [
            {"property": key, "value": value}
            for key, value in (effects or {}).items()
        ],
        "duration_ms": duration_ms,
    }


_DIALOGUE_LINE_LIMIT = 6


def dialogue_template(lines: list[str]) -> dict:
    """Build a conversation graph from the lines an entity was given.

    One state per line, because the alternative is a two-state graph whose line
    progression lives in the runtime -- and then the words the visitor actually
    reads are decided somewhere no probe can see. Here the text rides in each
    state's observable properties, so `runtime_interactions` can assert the exact
    line a visitor gets and the runtime only has to display what it is handed.

    Talking past the last line ends the conversation, which is what pressing the
    interact key repeatedly should do. `end` exists from every line as well, so a
    caller can leave in the middle without walking to the end first.
    """
    spoken = [line for line in lines if str(line).strip()][:_DIALOGUE_LINE_LIMIT]
    if not spoken:
        raise ValueError("a dialogue graph needs at least one line")
    states = [_state("idle", speaking=False, line="", line_index=-1)]
    transitions = []
    for index, line in enumerate(spoken):
        state_id = f"speaking_{index}"
        states.append(
            _state(state_id, speaking=True, line=str(line), line_index=index)
        )
        previous = "idle" if index == 0 else f"speaking_{index - 1}"
        transitions.append(_transition(previous, state_id, "talk"))
        transitions.append(_transition(state_id, "idle", "end"))
    # Talking again at the last line closes the conversation rather than leaving
    # the visitor stuck reading it with no way forward.
    transitions.append(_transition(f"speaking_{len(spoken) - 1}", "idle", "talk"))
    return {
        "initial": "idle",
        "states": states,
        "transitions": transitions,
        "probe": (
            ["talk"],
            "speaking_0",
            {"speaking": True, "line": str(spoken[0]), "line_index": 0},
        ),
    }


_TEMPLATES: dict[str, dict] = {
    "locomotion": {
        "initial": "idle",
        "states": [
            _state("idle", moving=False, speed_mps=0.0),
            _state("moving", moving=True, speed_mps=4.0),
        ],
        "transitions": [
            _transition("idle", "moving", "move_start"),
            _transition("moving", "idle", "move_stop"),
        ],
        "probe": (["move_start"], "moving", {"moving": True}),
    },
    "camera_control": {
        "initial": "following",
        "states": [
            _state("following", camera_input_active=True),
            _state("orbiting", camera_input_active=True),
        ],
        "transitions": [
            _transition("following", "orbiting", "orbit_start"),
            _transition("orbiting", "following", "orbit_stop"),
        ],
        "probe": (["orbit_start"], "orbiting", {"camera_input_active": True}),
    },
    "openable": {
        "initial": "closed",
        "states": [
            _state("closed", open=False, collision_enabled=True),
            _state("opening", open=False, collision_enabled=True),
            _state("open", open=True, collision_enabled=False),
            _state("closing", open=True, collision_enabled=False),
        ],
        "transitions": [
            _transition("closed", "opening", "interact"),
            _transition("opening", "open", "tick", duration_ms=500),
            _transition("open", "closing", "interact"),
            _transition("closing", "closed", "tick", duration_ms=500),
        ],
        "probe": (
            ["interact", "tick"],
            "open",
            {"open": True, "collision_enabled": False},
        ),
    },
    "lockable": {
        "initial": "locked",
        "states": [
            _state("locked", locked=True, open=False, collision_enabled=True),
            _state("closed", locked=False, open=False, collision_enabled=True),
            _state("open", locked=False, open=True, collision_enabled=False),
        ],
        "transitions": [
            _transition("locked", "closed", "unlock"),
            _transition("closed", "open", "interact", duration_ms=500),
            _transition("open", "closed", "interact", duration_ms=500),
        ],
        "probe": (
            ["unlock", "interact"],
            "open",
            {"locked": False, "open": True, "collision_enabled": False},
        ),
    },
    "pickup_carry_drop": {
        "initial": "grounded",
        "states": [
            _state("grounded", carried=False, physics_enabled=True),
            _state("carried", carried=True, physics_enabled=False),
            _state("dropped", carried=False, physics_enabled=True),
        ],
        "transitions": [
            _transition("grounded", "carried", "pickup"),
            _transition("carried", "dropped", "drop"),
            _transition("dropped", "carried", "pickup"),
        ],
        "probe": (
            ["pickup", "drop"],
            "dropped",
            {"carried": False, "physics_enabled": True},
        ),
    },
    "sittable": {
        "initial": "available",
        "states": [
            _state("available", occupied=False),
            _state("occupied", occupied=True),
        ],
        "transitions": [
            _transition("available", "occupied", "sit"),
            _transition("occupied", "available", "stand"),
        ],
        "probe": (["sit"], "occupied", {"occupied": True}),
    },
    "dialogue": {
        "initial": "idle",
        "states": [
            _state("idle", speaking=False),
            _state("speaking", speaking=True),
        ],
        "transitions": [
            _transition("idle", "speaking", "talk"),
            _transition("speaking", "idle", "finish"),
        ],
        "probe": (["talk"], "speaking", {"speaking": True}),
    },
    "animal": {
        "initial": "idle",
        "states": [
            _state("idle", moving=False, animation="idle"),
            _state("walking", moving=True, animation="walk"),
            _state("reacting", moving=False, animation="react"),
        ],
        "transitions": [
            _transition("idle", "walking", "move_start"),
            _transition("walking", "idle", "move_stop"),
            _transition("idle", "reacting", "stimulus"),
            _transition("reacting", "idle", "tick", duration_ms=750),
        ],
        "probe": (
            ["move_start"],
            "walking",
            {"moving": True, "animation": "walk"},
        ),
    },
    "vehicle": {
        "initial": "parked",
        "states": [
            _state("parked", occupied=False, moving=False),
            _state("occupied", occupied=True, moving=False),
            _state("moving", occupied=True, moving=True),
        ],
        "transitions": [
            _transition("parked", "occupied", "enter"),
            _transition("occupied", "moving", "drive"),
            _transition("moving", "occupied", "stop"),
            _transition("occupied", "parked", "exit"),
        ],
        "probe": (
            ["enter", "drive"],
            "moving",
            {"occupied": True, "moving": True},
        ),
    },
    "machine": {
        "initial": "off",
        "states": [
            _state("off", operating=False, failed=False),
            _state("running", operating=True, failed=False),
            _state("failed", operating=False, failed=True),
        ],
        "transitions": [
            _transition("off", "running", "start"),
            _transition("running", "off", "stop"),
            _transition("running", "failed", "fail"),
            _transition("failed", "off", "reset"),
        ],
        "probe": (["start"], "running", {"operating": True, "failed": False}),
    },
    "time_weather": {
        "initial": "stable",
        "states": [
            _state("stable", transition_active=False),
            _state("transitioning", transition_active=True),
        ],
        "transitions": [
            _transition("stable", "transitioning", "set_environment"),
            _transition("transitioning", "stable", "tick", duration_ms=1000),
        ],
        "probe": (
            ["set_environment", "tick"],
            "stable",
            {"transition_active": False},
        ),
    },
    "sensor_trigger": {
        "initial": "idle",
        "states": [
            _state("idle", triggered=False),
            _state("triggered", triggered=True),
        ],
        "transitions": [
            _transition("idle", "triggered", "sense"),
            _transition("triggered", "idle", "reset"),
        ],
        "probe": (["sense"], "triggered", {"triggered": True}),
    },
    "ecosystem_process": {
        "initial": "stable",
        "states": [
            _state("stable", update_count=0),
            _state("updating", update_count=0),
        ],
        "transitions": [
            _transition("stable", "updating", "simulate_step"),
            _transition(
                "updating",
                "stable",
                "commit",
                effects={"update_count": 1},
            ),
        ],
        "probe": (["simulate_step", "commit"], "stable", {"update_count": 1}),
    },
}


def _requirement_ids(spec: dict, entity_id: str | None, capability_id: str) -> list[str]:
    matches = []
    for requirement in spec["requirements"]:
        if entity_id and requirement["subject"] != entity_id:
            continue
        target_values = {
            value.strip() for value in str(requirement["target"]).split(",")
        }
        if capability_id in target_values or requirement["predicate"] in {
            "can_explore",
            "supports",
        }:
            matches.append(requirement["requirement_id"])
    return matches


def _graph(
    spec: dict,
    capability_id: str,
    entity_id: str | None,
    binding: dict,
    entity: dict | None = None,
) -> dict:
    if capability_id == "dialogue":
        # Built from this entity's own lines rather than looked up, so two
        # people in the same world hold different conversations.
        template = dialogue_template(list((entity or {}).get("dialogue", [])))
    else:
        template = deepcopy(_TEMPLATES[capability_id])
    triggers, expected_state, expected_properties = template["probe"]
    suffix = entity_id or "world"
    return {
        "graph_id": f"behavior:{suffix}:{capability_id}",
        "entity_id": entity_id,
        "capability_id": capability_id,
        "pack_id": binding["pack_id"],
        "pack_version": binding["pack_version"],
        "runtime_binding": binding["runtime_binding"],
        "initial_state": template["initial"],
        "states": template["states"],
        "transitions": template["transitions"],
        "probes": [
            {
                "probe_id": f"probe:{suffix}:{capability_id}",
                "triggers": triggers,
                "expected_state": expected_state,
                "expected_properties": expected_properties,
                "requirement_ids": _requirement_ids(
                    spec, entity_id, capability_id
                ),
            }
        ],
        "deterministic": True,
    }


def _wire_causal_links(spec: dict, graphs: list[dict]) -> list[dict]:
    """Attach each causal link to the transitions that bring its state about.

    Returns error objects for links that cannot be honoured. Nothing is repaired: a
    link naming an entity the spec does not contain is a planning mistake, and
    compiling it anyway would produce a world that looks wired and is not, which is
    harder to notice than a world with no wiring at all.

    Attached per transition rather than per state so that it fires on the CHANGE. A
    sensor sitting in `triggered` while the player stands on it must open the door
    once, not once per frame.
    """
    errors: list[dict] = []
    by_key: dict[tuple[str, str], dict] = {
        (graph["entity_id"], graph["capability_id"]): graph
        for graph in graphs
        if graph.get("entity_id")
    }
    for link in spec.get("causal_links") or ():
        link_id = str(link.get("link_id") or "unknown")
        when = link.get("when") or {}
        then = link.get("then") or {}
        source = by_key.get((when.get("entity_id"), when.get("capability_id")))
        target = by_key.get((then.get("entity_id"), then.get("capability_id")))
        if source is None or target is None:
            missing = when if source is None else then
            errors.append(
                {
                    "code": "CAUSAL_LINK_UNRESOLVED",
                    "link_id": link_id,
                    "entity_id": missing.get("entity_id"),
                    "capability_id": missing.get("capability_id"),
                    "message": (
                        "a causal link names an entity/capability pair that this "
                        "spec does not compile"
                    ),
                }
            )
            continue
        state = str(when.get("enters_state") or "")
        if state not in {item["state_id"] for item in source["states"]}:
            errors.append(
                {
                    "code": "CAUSAL_LINK_STATE_UNKNOWN",
                    "link_id": link_id,
                    "entity_id": when.get("entity_id"),
                    "capability_id": when.get("capability_id"),
                    "state": state,
                    "message": "the source capability has no such state to enter",
                }
            )
            continue
        trigger = str(then.get("trigger") or "")
        if trigger not in {item["trigger"] for item in target["transitions"]}:
            errors.append(
                {
                    "code": "CAUSAL_LINK_TRIGGER_UNKNOWN",
                    "link_id": link_id,
                    "entity_id": then.get("entity_id"),
                    "capability_id": then.get("capability_id"),
                    "trigger": trigger,
                    "message": "the target capability accepts no such trigger",
                }
            )
            continue
        if source is target:
            # A capability driving itself is always a mistake: the transition that
            # fires the trigger has already changed the state the trigger acts on.
            errors.append(
                {
                    "code": "CAUSAL_LINK_SELF_REFERENTIAL",
                    "link_id": link_id,
                    "entity_id": then.get("entity_id"),
                    "capability_id": then.get("capability_id"),
                    "message": "a capability cannot drive itself",
                }
            )
            continue
        emit = {
            "entity_id": then["entity_id"],
            "capability_id": then["capability_id"],
            "trigger": trigger,
            "link_id": link_id,
        }
        arriving = [
            transition
            for transition in source["transitions"]
            if transition["to_state"] == state
        ]
        if not arriving:
            errors.append(
                {
                    "code": "CAUSAL_LINK_STATE_UNREACHABLE",
                    "link_id": link_id,
                    "entity_id": when.get("entity_id"),
                    "capability_id": when.get("capability_id"),
                    "state": state,
                    "message": (
                        "no transition reaches that state, so the link could never "
                        "fire"
                    ),
                }
            )
            continue
        for transition in arriving:
            transition.setdefault("emits", []).append(dict(emit))
    return errors


def compile_behavior_plan(
    spec: dict,
    asset_descriptors: dict[str, dict] | None = None,
) -> tuple[dict, list[dict]]:
    registry = capability_index()
    graphs: list[dict] = []
    errors: list[dict] = []
    assigned: set[str] = set()
    for entity in spec["entities"]:
        for capability_id in entity["capabilities"]:
            assigned.add(capability_id)
            binding = registry.get(capability_id)
            if binding is None or (
                capability_id not in _TEMPLATES and capability_id != "dialogue"
            ):
                errors.append(
                    {
                        "code": "BEHAVIOR_TEMPLATE_UNAVAILABLE",
                        "entity_id": entity["entity_id"],
                        "capability_id": capability_id,
                    }
                )
                continue
            if capability_id == "dialogue" and not [
                line for line in (entity.get("dialogue") or []) if str(line).strip()
            ]:
                # The planner strips these before they arrive, but a hand-written
                # spec or an edit round-trip can still declare a speaker with
                # nothing to say, and nothing here can invent a line for them.
                errors.append(
                    {
                        "code": "DIALOGUE_LINES_MISSING",
                        "entity_id": entity["entity_id"],
                        "capability_id": capability_id,
                        "message": (
                            "an entity with the dialogue capability needs a "
                            "`dialogue` array of the lines it speaks"
                        ),
                    }
                )
                continue
            graphs.append(
                _graph(
                    spec,
                    capability_id,
                    entity["entity_id"],
                    binding,
                    entity=entity,
                )
            )
            qualification_error = capability_entity_error(
                binding,
                (asset_descriptors or {}).get(entity["entity_id"]),
            )
            if qualification_error is not None:
                errors.append(
                    {
                        "code": "RUNTIME_BINDING_INCOMPLETE",
                        "entity_id": entity["entity_id"],
                        "capability_id": capability_id,
                        "status": binding["status"],
                        "limitations": binding["limitations"],
                        "missing": qualification_error["missing"],
                    }
                )

    for capability_id in spec["capabilities"]:
        if capability_id in assigned:
            continue
        binding = registry.get(capability_id)
        if binding is None or capability_id not in _TEMPLATES:
            errors.append(
                {
                    "code": "BEHAVIOR_TEMPLATE_UNAVAILABLE",
                    "entity_id": None,
                    "capability_id": capability_id,
                }
            )
            continue
        graphs.append(_graph(spec, capability_id, None, binding))
        qualification_error = capability_entity_error(binding, None)
        if qualification_error is not None:
            errors.append(
                {
                    "code": "RUNTIME_BINDING_INCOMPLETE",
                    "entity_id": None,
                    "capability_id": capability_id,
                    "status": binding["status"],
                    "limitations": binding["limitations"],
                    "missing": qualification_error["missing"],
                }
            )
    errors.extend(_wire_causal_links(spec, graphs))

    plan = {
        "schema_version": "1.0.0",
        "simulation_id": spec["meta"]["simulation_id"],
        "graphs": graphs,
    }
    validate_behavior_plan(plan)
    return plan, errors


def execute_probe(graph: dict, probe: dict) -> dict:
    """Run the same finite-state semantics used by headless runtime probes."""
    states = {
        state["state_id"]: deepcopy(state["observable_properties"])
        for state in graph["states"]
    }
    current = graph["initial_state"]
    properties = deepcopy(states[current])
    trace = [{"state": current, "properties": deepcopy(properties)}]
    for trigger in probe["triggers"]:
        transition = next(
            (
                item
                for item in graph["transitions"]
                if item["from_state"] == current and item["trigger"] == trigger
            ),
            None,
        )
        if transition is None:
            return {
                "status": "FAIL",
                "code": "TRANSITION_NOT_FOUND",
                "trigger": trigger,
                "state": current,
                "trace": trace,
            }
        current = transition["to_state"]
        properties = deepcopy(states[current])
        for effect in transition["effects"]:
            properties[effect["property"]] = effect["value"]
        trace.append({"state": current, "properties": deepcopy(properties)})
    expected = probe["expected_properties"]
    passed = current == probe["expected_state"] and all(
        properties.get(key) == value for key, value in expected.items()
    )
    return {
        "status": "PASS" if passed else "FAIL",
        "state": current,
        "properties": properties,
        "expected_state": probe["expected_state"],
        "expected_properties": expected,
        "trace": trace,
    }


def validate_compiled_behaviors(plan: dict) -> dict:
    errors: list[dict] = []
    results: list[dict] = []
    try:
        validate_behavior_plan(plan)
    except jsonschema.ValidationError as exc:
        return {
            "status": "FAIL",
            "errors": [
                {
                    "code": "BEHAVIOR_PLAN_SCHEMA_INVALID",
                    "path": list(exc.absolute_path),
                    "message": exc.message,
                }
            ],
            "results": [],
        }
    for graph in plan["graphs"]:
        state_ids = {state["state_id"] for state in graph["states"]}
        if graph["initial_state"] not in state_ids:
            errors.append(
                {
                    "code": "INITIAL_STATE_MISSING",
                    "graph_id": graph["graph_id"],
                }
            )
            continue
        for transition in graph["transitions"]:
            if (
                transition["from_state"] not in state_ids
                or transition["to_state"] not in state_ids
            ):
                errors.append(
                    {
                        "code": "TRANSITION_STATE_MISSING",
                        "graph_id": graph["graph_id"],
                        "transition_id": transition["transition_id"],
                    }
                )
        for probe in graph["probes"]:
            result = execute_probe(graph, probe)
            results.append(
                {
                    "graph_id": graph["graph_id"],
                    "probe_id": probe["probe_id"],
                    **result,
                }
            )
            if result["status"] != "PASS":
                errors.append(
                    {
                        "code": "BEHAVIOR_PROBE_FAILED",
                        "graph_id": graph["graph_id"],
                        "probe_id": probe["probe_id"],
                        "result": result,
                    }
                )
    return {
        "status": "FAIL" if errors else "PASS",
        "errors": errors,
        "results": results,
    }
