"""The Arbiter — merge partial spec patches under the constraint priority
stack, logging which source decided every field (docs/ARCHITECTURE.md).

Documented stack, highest wins:
    platform_limits > scope_allowlist > playability
    > designer_intent > user_preference > cost > aesthetics

Two hard bands (platform_limits, scope_allowlist) don't just win — they
*clamp*: a merged value outside the allowlist/budget caps is overridden to
the nearest legal value and the override is logged. Everything is rule-
based and recorded (the tie-break LLM call is a later addition); the
decision log is dissertation data (RQ2: how conflicts were resolved).

Today's proposal sources: hard platform/scope defaults, the planner's
brief (designer_intent), and the user's explicit request options. Explicit
user options are elevated ABOVE the brief's inference for the fields the
user actually chose — an explicit pick is stronger evidence of intent than
inference — implemented via proposal order within equal handling. When the
full LangGraph agent chain lands, each agent simply contributes more
Proposals; this merge logic already exists.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field

# Band -> priority (higher wins). Mirrors the documented stack exactly.
BANDS: dict[str, int] = {
    "platform_limits": 70,
    "scope_allowlist": 60,
    "playability": 50,
    "designer_intent": 40,
    "user_preference": 30,
    "cost": 20,
    "aesthetics": 10,
}

GENRES = (
    "topdown_survival_escape_3d",
    "arena_combat_3d",
    "collect_explore_3d",
    "dungeon_crawl_3d",
)
CAMERAS = ("third_person", "top_down_3d", "isometric_3d")
MAX_WEB_BUILD_MB = 90
MAX_ENEMIES = 25
MAX_PROPS = 200


@dataclass
class Proposal:
    source: str  # e.g. "planner", "user_options", "platform"
    band: str  # a key of BANDS
    patches: dict[str, object]  # dotted path -> value, e.g. "meta.camera": "top_down_3d"
    order: int = 0  # tiebreak within a band; higher applied later (wins)


@dataclass
class Decision:
    path: str
    chosen: object
    source: str
    band: str
    losers: list[dict] = field(default_factory=list)  # [{source, band, value}]
    reason: str = "highest_band"
    overridden_from: object = None  # set when a hard band clamped the value

    def to_dict(self) -> dict:
        d = {
            "path": self.path,
            "chosen": self.chosen,
            "source": self.source,
            "band": self.band,
            "reason": self.reason,
        }
        if self.losers:
            d["losers"] = self.losers
        if self.overridden_from is not None:
            d["overridden_from"] = self.overridden_from
        return d


def _set_path(target: dict, dotted: str, value: object) -> None:
    keys = dotted.split(".")
    node = target
    for key in keys[:-1]:
        node = node.setdefault(key, {})
    node[keys[-1]] = value


def _get_path(target: dict, dotted: str, default: object = None) -> object:
    node = target
    for key in dotted.split("."):
        if not isinstance(node, dict) or key not in node:
            return default
        node = node[key]
    return node


def arbitrate(base_spec: dict, proposals: list[Proposal]) -> tuple[dict, list[dict]]:
    """Merge proposals onto a copy of base_spec; return (spec, decision_log)."""
    spec = copy.deepcopy(base_spec)
    decisions: list[Decision] = []

    # Gather every proposed value per field, sorted by (band, order) desc.
    by_path: dict[str, list[tuple[int, int, Proposal, object]]] = {}
    for p in proposals:
        if p.band not in BANDS:
            raise ValueError(f"unknown band '{p.band}'")
        for path, value in p.patches.items():
            by_path.setdefault(path, []).append((BANDS[p.band], p.order, p, value))

    for path, candidates in by_path.items():
        candidates.sort(key=lambda c: (c[0], c[1]), reverse=True)
        _, _, winner, chosen = candidates[0]
        losers = [
            {"source": p.source, "band": p.band, "value": v}
            for _, _, p, v in candidates[1:]
        ]
        _set_path(spec, path, chosen)
        decisions.append(
            Decision(
                path=path,
                chosen=chosen,
                source=winner.source,
                band=winner.band,
                losers=losers,
            )
        )

    _enforce_hard_constraints(spec, decisions)
    return spec, [d.to_dict() for d in decisions]


def _enforce_hard_constraints(spec: dict, decisions: list[Decision]) -> None:
    """Platform/scope bands clamp: illegal merged values are overridden to
    the nearest legal one and the override recorded."""

    def clamp(path: str, legal, band: str, reason: str) -> None:
        current = _get_path(spec, path)
        fixed = legal(current)
        if fixed != current:
            _set_path(spec, path, fixed)
            decisions.append(
                Decision(
                    path=path, chosen=fixed, source="arbiter", band=band,
                    reason=reason, overridden_from=current,
                )
            )

    clamp(
        "meta.genre",
        lambda v: v if v in GENRES else GENRES[2],  # collect_explore is the safe default
        "scope_allowlist", "genre_not_in_allowlist",
    )
    clamp(
        "meta.camera",
        lambda v: v if v in CAMERAS else CAMERAS[0],
        "scope_allowlist", "camera_not_in_allowlist",
    )
    clamp(
        "budgets.max_web_build_mb",
        lambda v: min(v, MAX_WEB_BUILD_MB) if isinstance(v, int) else MAX_WEB_BUILD_MB,
        "platform_limits", "web_build_cap",
    )
    clamp(
        "budgets.max_enemies",
        lambda v: max(5, min(v, MAX_ENEMIES)) if isinstance(v, int) else MAX_ENEMIES,
        "scope_allowlist", "enemy_cap",
    )
    clamp(
        "budgets.max_props",
        lambda v: max(50, min(v, MAX_PROPS)) if isinstance(v, int) else MAX_PROPS,
        "scope_allowlist", "prop_cap",
    )


def arbitrate_spec(
    base_spec: dict,
    planner_patches: dict[str, object],
    user_option_patches: dict[str, object] | None = None,
) -> tuple[dict, list[dict]]:
    """Today's wiring: reconcile the planner's brief-derived patches
    (designer_intent) with the user's explicit request options, under the
    priority stack, plus the hard platform/scope clamps. Returns
    (merged_spec, decision_log)."""
    proposals = [
        Proposal(source="planner", band="designer_intent", patches=planner_patches, order=0),
    ]
    if user_option_patches:
        # Explicit picks outrank the brief's inference for the fields the
        # user actually chose (an explicit pick is stronger evidence of
        # intent): same band, higher order so they win the tiebreak and the
        # log shows user_options as the decider.
        proposals.append(
            Proposal(
                source="user_options",
                band="designer_intent",
                patches=user_option_patches,
                order=10,
            )
        )
    return arbitrate(base_spec, proposals)
