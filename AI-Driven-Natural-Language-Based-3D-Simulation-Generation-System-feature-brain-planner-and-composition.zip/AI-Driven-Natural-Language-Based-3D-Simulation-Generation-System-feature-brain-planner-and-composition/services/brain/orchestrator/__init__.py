"""Arbiter (P2): merge agent JSON patches under the constraint priority
stack, recording which rule decided every field (docs/ARCHITECTURE.md)."""

from orchestrator.arbiter import (
    BANDS,
    Proposal,
    arbitrate,
    arbitrate_spec,
)

__all__ = ["BANDS", "Proposal", "arbitrate", "arbitrate_spec"]
