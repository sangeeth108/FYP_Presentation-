"""Localized repair loop (P2). Never regenerate the whole game: classify
the failure, re-invoke only the responsible node, cap 3 attempts/class
with monotonic-progress checks. Every attempt is recorded — that record
is dissertation data (RQ2)."""

from repair.loop import (
    MAX_ATTEMPTS_PER_CLASS,
    RepairAttempt,
    deterministic_spec_fixes,
    level_reroll_seed,
    responsible_action,
)

__all__ = [
    "MAX_ATTEMPTS_PER_CLASS",
    "RepairAttempt",
    "deterministic_spec_fixes",
    "level_reroll_seed",
    "responsible_action",
]
