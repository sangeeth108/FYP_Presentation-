"""Repair loop v1 (docs/VALIDATION_PLAN.md repair policy).

Failure class -> responsible node -> localized action:

  schema  -> S2 spec builder   -> deterministic spec fixes (lockstep fields,
                                  budget clamps) — no LLM, reviewable rules
  logic   -> S4 PCG            -> re-roll ONLY the level (seed + attempt salt;
                                  the spec is untouched, determinism kept)
  build   -> S6/S7 writer/export -> degrade: retry once, then drop kit models
  asset   -> S5 asset farm     -> curated substitution (P3; no-op today)
  quality -> advisory          -> never blocks, never repaired automatically

Caps: MAX_ATTEMPTS_PER_CLASS per class; monotonic progress required (an
attempt that does not shrink the error set fails fast).
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field

MAX_ATTEMPTS_PER_CLASS = 3
_SEED_SALT = 1_000_003  # prime stride keeps re-rolled seeds deterministic + disjoint


@dataclass
class RepairAttempt:
    failure_class: str
    attempt: int  # 1-based within the class
    action: str
    errors_before: list[str] = field(default_factory=list)  # error codes
    errors_after: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


def responsible_action(failure_class: str, attempt: int) -> str:
    """Which localized action handles this class on this attempt."""
    if failure_class == "schema":
        return "fix_spec_deterministically"
    if failure_class == "logic":
        return "reroll_level_seed"
    if failure_class == "build":
        return "reexport" if attempt == 1 else "drop_kit_models"
    if failure_class == "asset":
        return "curated_substitute"
    return "none"  # quality is advisory


def level_reroll_seed(base_seed: int, attempt: int) -> int:
    """Deterministic re-roll: same job + same attempt = same level, always."""
    return (base_seed + attempt * _SEED_SALT) % (2**31)


def deterministic_spec_fixes(spec: dict, errors: list[dict]) -> list[str]:
    """Apply reviewable, rule-based fixes for schema-class gate errors
    in place; returns the list of fixes applied (empty = nothing fixable)."""
    fixes: list[str] = []
    controller_by_camera = {
        "third_person": "controller_third_person",
        "top_down_3d": "controller_topdown_3d",
        "isometric_3d": "controller_isometric_3d",
    }
    for error in errors:
        code = error.get("code")
        if code == "CAMERA_CONTROLLER_MISMATCH":
            spec["player"]["controller_template_id"] = controller_by_camera[
                spec["meta"]["camera"]
            ]
            fixes.append("controller_locked_to_camera")
        elif code == "ENEMY_BUDGET_EXCEEDED":
            budget = spec["budgets"].get("max_enemies", 25)
            remaining = budget
            for enemy in spec["entities"]["enemies"]:
                enemy["count"] = max(1, min(enemy["count"], remaining))
                remaining = max(0, remaining - enemy["count"])
            fixes.append("enemy_counts_clamped_to_budget")
        elif code == "PROP_BUDGET_EXCEEDED":
            budget = spec["budgets"].get("max_props", 200)
            spec["entities"]["props"] = spec["entities"]["props"][:budget]
            fixes.append("props_trimmed_to_budget")
        elif code == "COLLECT_QUEST_IMPOSSIBLE":
            # The goal asks for more relics than the level can physically hold
            # (placement crowds and then caps the roster in a tight level). Ask
            # for what is actually there rather than re-rolling the whole level
            # three times and failing the job over the eighth relic.
            placed = int((error.get("data") or {}).get("placed", 0))
            if placed >= 1 and _clamp_collect_count(spec, placed):
                fixes.append("collect_count_clamped_to_placed_pickups")
    return fixes


def _clamp_collect_count(spec: dict, placed: int) -> bool:
    for objective in spec.get("objectives", []):
        if objective.get("objective_template_id") != "collect_n":
            continue
        params = objective.setdefault("params", {})
        if params.get("required_count", 0) > placed:
            params["required_count"] = placed
            return True
    return False
