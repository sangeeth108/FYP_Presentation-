"""Typed, bounded, localized WorldPlan repair.

Only allowlisted operations are accepted. Patches cannot inject source code or
replace an entire simulation; they re-solve the smallest named entity set and
carry a hash precondition to prevent stale repair application.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable
from functools import lru_cache
from pathlib import Path
from typing import Any

import jsonschema
from pcg.semantic import generate_semantic_world_plan

_REPO = Path(__file__).resolve().parents[3]
_SCHEMA_PATH = _REPO / "contracts" / "world_patch.schema.json"
MAX_REPAIR_CYCLES = 3
_REPAIRABLE = {
    "ENTITY_OVERLAP_OR_CLEARANCE",
    "ENTITY_OUTSIDE_ZONE",
    "INVALID_TERRAIN_SUPPORT",
    "ENTITY_UNPLACED",
}


@lru_cache(maxsize=1)
def world_patch_schema() -> dict:
    return json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))


def plan_hash(plan: dict) -> str:
    canonical = json.dumps(plan, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def validate_world_patch(patch: dict) -> None:
    jsonschema.validate(patch, world_patch_schema())


def propose_typed_patch(report: dict, plan: dict) -> dict | None:
    affected: set[str] = set()
    codes: set[str] = set()
    for error in report.get("errors", []):
        code = error.get("code")
        if code not in _REPAIRABLE:
            continue
        codes.add(code)
        if error.get("entity_id"):
            affected.add(error["entity_id"])
        affected.update(error.get("entity_ids", []))
    if not affected:
        return None
    digest = plan_hash(plan)
    patch = {
        "schema_version": "1.0.0",
        "patch_id": f"patch_{digest[:12]}_{len(affected)}",
        "precondition_plan_hash": digest,
        "source_validator": "semantic_world_plan_constraints",
        "operations": [
            {
                "op": "re_solve_entities",
                "entity_ids": sorted(affected),
                "reason": "Repair " + ", ".join(sorted(codes)),
            }
        ],
    }
    validate_world_patch(patch)
    return patch


def apply_world_patch(
    patch: dict,
    *,
    spec: dict,
    asset_descriptors: dict[str, dict],
    behaviour_graphs: list[dict],
    current_plan: dict,
    placement_ranker: Any | None = None,
) -> dict:
    validate_world_patch(patch)
    current_hash = plan_hash(current_plan)
    if patch["precondition_plan_hash"] != current_hash:
        raise ValueError("world patch precondition hash does not match current plan")
    known_ids = {entity["entity_id"] for entity in spec["entities"]}
    affected: set[str] = set()
    for operation in patch["operations"]:
        if operation["op"] != "re_solve_entities":
            raise ValueError(f"unsupported world patch operation {operation['op']}")
        affected.update(operation["entity_ids"])
    unknown = affected - known_ids
    if unknown:
        raise ValueError(f"world patch references unknown entities: {sorted(unknown)}")
    return generate_semantic_world_plan(
        spec,
        asset_descriptors,
        behaviour_graphs,
        preserved_plan=current_plan,
        affected_entity_ids=affected,
        placement_ranker=placement_ranker,
    )


def bounded_localized_repair(
    *,
    spec: dict,
    asset_descriptors: dict[str, dict],
    behaviour_graphs: list[dict],
    initial_plan: dict,
    validator: Callable[[dict], dict],
    max_cycles: int = MAX_REPAIR_CYCLES,
    placement_ranker: Any | None = None,
) -> tuple[dict, dict, list[dict]]:
    if max_cycles < 0 or max_cycles > MAX_REPAIR_CYCLES:
        raise ValueError(f"max_cycles must be between 0 and {MAX_REPAIR_CYCLES}")
    current = initial_plan
    report = validator(current)
    lineage: list[dict] = []
    for cycle in range(1, max_cycles + 1):
        if report["status"] == "PASS":
            break
        patch = propose_typed_patch(report, current)
        if patch is None:
            break
        before_codes = [error["code"] for error in report.get("errors", [])]
        repaired = apply_world_patch(
            patch,
            spec=spec,
            asset_descriptors=asset_descriptors,
            behaviour_graphs=behaviour_graphs,
            current_plan=current,
            placement_ranker=placement_ranker,
        )
        repaired_report = validator(repaired)
        after_codes = [error["code"] for error in repaired_report.get("errors", [])]
        lineage.append(
            {
                "cycle": cycle,
                "patch": patch,
                "before_plan_hash": plan_hash(current),
                "after_plan_hash": plan_hash(repaired),
                "errors_before": before_codes,
                "errors_after": after_codes,
            }
        )
        current = repaired
        report = repaired_report
        if report["status"] != "PASS" and len(after_codes) >= len(before_codes):
            break
    return current, report, lineage
