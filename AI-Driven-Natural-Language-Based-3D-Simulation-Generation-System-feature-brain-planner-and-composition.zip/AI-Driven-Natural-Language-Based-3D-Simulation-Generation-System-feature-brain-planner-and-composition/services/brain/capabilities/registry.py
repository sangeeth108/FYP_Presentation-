"""Filesystem-backed, schema-validated capability-pack registry."""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

import jsonschema

_REPO = Path(__file__).resolve().parents[3]
_PACKS = _REPO / "capabilities" / "packs"
_SCHEMA = json.loads(
    (_REPO / "contracts" / "capability_pack.schema.json").read_text(encoding="utf-8")
)


class CapabilityRegistryError(ValueError):
    pass


@lru_cache(maxsize=1)
def load_packs() -> list[dict]:
    packs = []
    capability_owner: dict[str, str] = {}
    for path in sorted(_PACKS.glob("*/manifest.json")):
        manifest = json.loads(path.read_text(encoding="utf-8"))
        jsonschema.validate(manifest, _SCHEMA)
        for capability in manifest["capabilities"]:
            capability_id = capability["capability_id"]
            if capability_id in capability_owner:
                raise CapabilityRegistryError(
                    f"{capability_id} is declared by both "
                    f"{capability_owner[capability_id]} and {manifest['pack_id']}"
                )
            capability_owner[capability_id] = manifest["pack_id"]
        packs.append(manifest)
    return packs


@lru_cache(maxsize=1)
def capability_index() -> dict[str, dict]:
    index = {}
    for pack in load_packs():
        for capability in pack["capabilities"]:
            index[capability["capability_id"]] = {
                **capability,
                "pack_id": pack["pack_id"],
                "pack_version": pack["version"],
                "platforms": pack["platforms"],
            }
    return index


def resolve_capabilities(
    capability_ids: list[str],
    target_platforms: list[str],
    *,
    spec: dict | None = None,
    asset_descriptors: dict[str, dict] | None = None,
    final: bool = False,
) -> tuple[list[dict], list[dict]]:
    resolved = []
    gaps = []
    index = capability_index()
    for capability_id in sorted(set(capability_ids)):
        capability = index.get(capability_id)
        if capability is None:
            gaps.append(
                {
                    "capability_id": capability_id,
                    "status": "unavailable",
                    "reason": "No capability pack declares this capability.",
                }
            )
            continue
        missing_platforms = sorted(set(target_platforms) - set(capability["platforms"]))
        item = dict(capability)
        if missing_platforms:
            gaps.append(
                {
                    "capability_id": capability_id,
                    "status": "unavailable",
                    "reason": f"Unsupported platforms: {', '.join(missing_platforms)}",
                }
            )
        elif capability["status"] != "supported" and capability.get("qualification"):
            consumers = [
                entity
                for entity in (spec or {}).get("entities", [])
                if capability_id in entity.get("capabilities", [])
            ]
            if not final:
                item["qualification_status"] = "DEFERRED"
            else:
                failed_entities = []
                for entity in consumers:
                    descriptor = (asset_descriptors or {}).get(entity["entity_id"])
                    error = capability_entity_error(capability, descriptor)
                    if error is not None:
                        failed_entities.append(
                            {
                                "entity_id": entity["entity_id"],
                                "missing": error["missing"],
                            }
                        )
                if not consumers:
                    failed_entities.append(
                        {"entity_id": None, "missing": ["capability_consumer"]}
                    )
                if failed_entities:
                    gaps.append(
                        {
                            "capability_id": capability_id,
                            "status": "partial",
                            "reason": "Capability asset qualification failed.",
                            "entities": failed_entities,
                        }
                    )
                else:
                    item["qualification_status"] = "PASS"
        elif capability["status"] != "supported" and capability.get("runtime_binding"):
            # Bound-but-partial. A declared runtime_binding means a VETTED behaviour
            # template exists, so the documented subset genuinely runs. Failing these
            # outright made `machine`, `sensor_trigger`, `vehicle`, `pickup_carry_drop`
            # and `time_weather` impossible to ever publish — only doors and walking
            # were left — which is not what "partial" means. `animal` already proves
            # partial capabilities are meant to QUALIFY, not to be banned.
            # The limitations stay attached as disclosure, and the runtime probes
            # remain the real gate on whether the spec's requirements are met.
            item["qualification_status"] = "PASS_WITH_LIMITATIONS"
        elif capability["status"] != "supported":
            # No runtime binding at all: nothing vetted can be bound, so this
            # genuinely cannot run and must fail closed.
            gaps.append(
                {
                    "capability_id": capability_id,
                    "status": capability["status"],
                    "reason": " ".join(capability["limitations"]),
                }
            )
        resolved.append(item)
    return resolved, gaps


def capability_entity_error(
    capability: dict,
    descriptor: dict | None,
) -> dict | None:
    """Return missing measured requirements for one partial capability consumer."""
    if capability.get("status") == "supported":
        return None
    qualification = capability.get("qualification")
    if not qualification:
        # No per-entity qualification declared, so the capability qualifies on its
        # runtime binding alone: a vetted template is bound (runs the documented
        # subset) or nothing is (genuinely unavailable). Reporting a BOUND
        # capability as missing "supported_runtime_binding" was simply untrue —
        # `machine` declares lever_switch and `sensor_trigger` declares
        # objective_trigger, and both have vetted behaviour templates.
        if capability.get("runtime_binding"):
            return None
        return {
            "status": capability.get("status", "unavailable"),
            "missing": ["supported_runtime_binding"],
        }
    if qualification.get("kind") != "asset_animation":
        return {"status": "unavailable", "missing": ["known_qualification_kind"]}
    animation = (descriptor or {}).get("animation") or {}
    missing = [
        requirement
        for requirement in qualification.get("requires", [])
        if not bool(animation.get(requirement))
    ]
    if missing:
        return {"status": "partial", "missing": missing}
    return None
