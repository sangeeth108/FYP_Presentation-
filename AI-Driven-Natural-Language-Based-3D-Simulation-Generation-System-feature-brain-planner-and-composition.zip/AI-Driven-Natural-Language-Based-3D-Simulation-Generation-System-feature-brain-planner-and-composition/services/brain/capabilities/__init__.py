"""Capability-pack discovery and resolution."""
