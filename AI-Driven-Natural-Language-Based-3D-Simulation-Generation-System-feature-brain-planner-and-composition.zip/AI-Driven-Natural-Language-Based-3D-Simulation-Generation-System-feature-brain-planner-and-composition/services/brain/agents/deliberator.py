"""Stage 3 -- deliberate: critique a SceneBrief, revise it, agree, stop.

The last reasoning stage, and the one most likely to do harm, so its design is
mostly guardrails.

**Nothing is a legitimate answer.** A critic obliged to produce findings will
produce findings, and a revision driven by an invented defect makes the world
worse while looking like diligence. The critique contract allows zero findings
and the prompt says plainly that `sound` is the expected verdict for a good
brief. Only three things are worth a round trip -- the brief contradicts the
description, describes something physically impossible, or put a kind on the
wrong side of the individual/mass split. Style is not a finding.

**Anonymity.** The critic is never told the brief was written by another model,
and the reviser is never told which agent raised a finding. Both are presented
as text to be judged on its own terms. Attribution is what produces deference to
whichever voice sounds most authoritative rather than to whichever point is
right.

**Stability, not consensus.** The loop stops when the brief stops changing, not
when the agents agree -- agreement is cheap and reachable by capitulation. A
round that changes nothing is the signal that deliberation is finished, and the
round cap is hard because a loop that has not converged by then is not going to.

**Never destructive.** Every failure -- unavailable model, malformed critique, a
revision that will not validate -- returns the brief that went in. Deliberation
can improve a brief or leave it alone; it can never lose it.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

import httpx
import jsonschema

from agents.brief_extractor import ollama_brief_schema, scene_brief_schema
from agents.schema_bounds import clamp_to_schema, dedupe_unique_arrays

log = logging.getLogger(__name__)
_CRITIQUE_PATH = (
    Path(__file__).resolve().parents[3] / "contracts" / "scene_critique.schema.json"
)

# Two rounds is the ceiling that pays. A third has never changed anything in
# testing, and every round is two model calls on a machine that also has to
# generate meshes.
_MAX_ROUNDS = 2


@lru_cache(maxsize=1)
def scene_critique_schema() -> dict:
    return json.loads(_CRITIQUE_PATH.read_text(encoding="utf-8"))


def ollama_critique_schema() -> dict:
    """Critique schema in the grammar adapter's subset (drops length bounds)."""
    from copy import deepcopy

    def normalize(node: object) -> object:
        if isinstance(node, list):
            return [normalize(value) for value in node]
        if not isinstance(node, dict):
            return node
        return {
            key: normalize(value)
            for key, value in node.items()
            if key not in {"$schema", "$id", "minLength", "maxLength"}
        }

    view = normalize(deepcopy(scene_critique_schema()))
    if not isinstance(view, dict):
        raise TypeError("SceneCritique schema must be an object")
    return view


# The first version of this prompt told the model that `sound` was the expected
# answer and that it lost nothing by giving it. That defended against invented
# findings and over-corrected: the critic returned `sound` for a corridor whose
# ground was recorded as deep snow, for 900 hospital beds per 100 m2, and for
# six identical beds listed as individuals. A critic that cannot fail anything
# is worse than no critic, because it costs a model call and manufactures
# confidence. The rebalanced version below states the checks as work to perform
# rather than as grounds for exemption, and keeps the empty finding list
# available without advertising it.
_CRITIC = (
    "Check a structured reading of a place against the description it was read "
    "from. Work through these three checks in order and report what you find.\n\n"
    "1. CONTRADICTION. Compare every field against the description. Ground "
    "surface, light, weather, sizes and the identity of the place must all match "
    "what the description actually says. A reading that states something the "
    "description does not support is a contradiction even if it is plausible on "
    "its own.\n\n"
    "2. PHYSICAL PLAUSIBILITY. For each entry in `mass`, ask whether "
    "`per_100m2` instances of something `size_m` in size can physically occupy "
    "100 square metres. A 2 m bed cannot occur 900 times in a 10 m square. "
    "Ground cover that touches runs into the hundreds; furniture is single "
    "digits.\n\n"
    "3. ABSTRACTION. Anything occurring in quantity belongs in `mass`. Check "
    "every `why_individual`: if the reason amounts to no more than the "
    "description having mentioned the object, or if several entries are the same "
    "kind differing only by a number, they belong in `mass` instead.\n\n"
    "Record what each check examined in `checks`, including the arithmetic for "
    "the densest mass entry. A check you cannot state is a check you did not "
    "perform.\n\n"
    "Report one finding per problem, each naming a path and a specific "
    "correction that could be applied without asking you what you meant. If all "
    "three checks pass, answer `sound` with an empty findings list. Do not "
    "report wording, completeness or style. Return JSON only."
)

_REVISER = (
    "Apply the listed corrections to the reading and return the corrected "
    "reading.\n\n"
    "Change only what the corrections name. Everything else must survive exactly "
    "as it was -- this is an edit, not a rewrite, and anything you alter beyond "
    "the corrections is a defect you introduced. Return JSON only."
)


@dataclass
class Deliberation:
    """The brief that survived, plus what happened to it."""

    brief: dict
    rounds: list[dict] = field(default_factory=list)
    model_id: str = ""
    duration_ms: int = 0
    stopped_because: str = "no_rounds_run"

    @property
    def changed(self) -> bool:
        return any(item["applied"] for item in self.rounds)

    def as_stage_payload(self) -> dict:
        return {
            "brief": self.brief,
            "rounds": self.rounds,
            "model_id": self.model_id,
            "duration_ms": self.duration_ms,
            "stopped_because": self.stopped_because,
            "changed": self.changed,
        }


def _fingerprint(brief: dict) -> str:
    return json.dumps(brief, sort_keys=True, separators=(",", ":"))


def _call(client, model_id: str, system: str, user: str, schema: dict, seed: int) -> dict:
    response = client.post(
        "/api/chat",
        json={
            "model": model_id,
            "stream": False,
            "format": schema,
            "think": False,
            "keep_alive": "30m",
            "options": {"temperature": 0.1, "seed": seed},
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        },
    )
    response.raise_for_status()
    return json.loads(response.json()["message"]["content"])


def deliberate_brief(
    brief: dict,
    description: str,
    *,
    settings,
    model_id: str | None,
    base_url: str | None,
    seed: int = 0,
    max_rounds: int = _MAX_ROUNDS,
) -> Deliberation:
    """Critique and revise a brief until it stops changing. Never returns nothing."""
    result = Deliberation(brief=brief, model_id=model_id or "")
    if not model_id or not base_url:
        result.stopped_because = "no_model"
        return result

    started = time.monotonic()
    current = json.loads(json.dumps(brief))  # never mutate the caller's brief

    try:
        with httpx.Client(
            base_url=base_url, timeout=settings.llm_timeout_seconds
        ) as client:
            for round_index in range(max_rounds):
                # The critic sees the reading and the source, and is told nothing
                # about who wrote either.
                critique = _call(
                    client,
                    model_id,
                    _CRITIC,
                    json.dumps(
                        {"description": description, "reading": current},
                        separators=(",", ":"),
                    ),
                    ollama_critique_schema(),
                    seed + round_index,
                )
                # The critique is a guided artefact like any other, so it needs
                # the same repair. Omitting it here cost the stage every finding
                # it produced: the model's plausibility working ("6 beds at
                # ~1.8 m2 is 10.8 m2 of a 100 m2 floor") ran past the field's
                # length bound, the whole critique was discarded, and the stage
                # looked incapable. Third occurrence of one class -- anything a
                # context-free grammar cannot enforce -- in a third artefact.
                dedupe_unique_arrays(critique, scene_critique_schema())
                clamp_to_schema(critique, scene_critique_schema())
                jsonschema.validate(critique, scene_critique_schema())
                findings = critique.get("findings") or []

                # Findings are authoritative; the verdict is advisory.
                #
                # These two fields disagree often, and in both directions: the
                # model computed that 900 beds need 567 m2 of a 100 m2 floor,
                # named the correction, and still set verdict `sound`. Reading
                # the verdict first discarded every finding it produced and made
                # the stage look incapable when it was working. A field the
                # model treats as a formality cannot gate one it treats as work.
                verdict = critique.get("verdict")
                if findings and verdict == "sound":
                    log.info(
                        "critique reported %d finding(s) with verdict 'sound'; "
                        "acting on the findings",
                        len(findings),
                    )
                if not findings:
                    result.rounds.append(
                        {"round": round_index + 1, "findings": 0, "applied": False}
                    )
                    result.stopped_because = "sound"
                    break

                # The reviser receives corrections as plain text, with no hint of
                # who raised them -- a finding is judged on whether it is right.
                revised = _call(
                    client,
                    model_id,
                    _REVISER,
                    json.dumps(
                        {
                            "reading": current,
                            "corrections": [
                                {"path": f["path"], "correction": f["correction"]}
                                for f in findings
                            ],
                        },
                        separators=(",", ":"),
                    ),
                    ollama_brief_schema(),
                    seed + round_index,
                )
                dedupe_unique_arrays(revised, scene_brief_schema())
                clamp_to_schema(revised, scene_brief_schema())
                jsonschema.validate(revised, scene_brief_schema())

                applied = _fingerprint(revised) != _fingerprint(current)
                result.rounds.append(
                    {
                        "round": round_index + 1,
                        "findings": len(findings),
                        "applied": applied,
                        "severities": sorted({f["severity"] for f in findings}),
                    }
                )
                if not applied:
                    # Stability, not agreement: a round that changes nothing is
                    # the end of the conversation whatever anyone claims.
                    result.stopped_because = "stable"
                    break
                current = revised
            else:
                result.stopped_because = "round_cap"
    except Exception as exc:
        # Whatever went wrong, the brief that came in is still good.
        log.warning("deliberation abandoned, keeping the original brief: %s", exc)
        result.stopped_because = f"error:{type(exc).__name__}"
        result.duration_ms = int((time.monotonic() - started) * 1000)
        return result

    result.brief = current
    result.duration_ms = int((time.monotonic() - started) * 1000)
    return result
