"""Per-game style anchor (P3): one visual descriptor every generated asset shares.

Without it, each asset's SDXL prompt is only its own brief, so a crypt's
sarcophagus and its torch can come out in different styles — the game looks
incoherent. The style anchor is a short prefix (schema: meta.style_anchor, <=200
chars) prepended to every asset prompt, derived deterministically from the game's
genre + lighting so the whole set reads as one art direction.

Deterministic on purpose (like parse_intent): the same brief always yields the
same look, so a game's assets are reproducible. The base "low-poly stylized" is
the frozen v1 art direction (§1).
"""

from __future__ import annotations

from agents.intent import Brief

# Lighting preset -> palette/mood words. Lighting is the strongest style signal.
_LIGHTING_STYLE: dict[str, str] = {
    "cave_torchlit": "torch-lit gloom, weathered dark stone, muted earthy palette",
    "dusk_fog": "foggy dusk, desaturated cold tones, worn and damp",
    "moonlit_night": "cold moonlight, deep blue shadows, silvered highlights",
    "sunny_bright": "bright warm sunlight, cheerful saturated palette, soft shadows",
    "overcast_day": "flat overcast light, natural muted colours",
}

# Genre -> material/form language.
_GENRE_STYLE: dict[str, str] = {
    "dungeon_crawl_3d": "gothic carved stone and iron",
    "arena_combat_3d": "battle-worn steel and masonry",
    "collect_explore_3d": "soft rounded natural forms",
    "topdown_survival_escape_3d": "grimy improvised materials",
}

BASE_STYLE = "low-poly stylized game asset, cohesive art direction"


def derive_style_anchor(brief: Brief) -> str:
    """A short, coherent visual prefix for every asset in this game."""
    parts = [
        _GENRE_STYLE.get(brief.genre, ""),
        _LIGHTING_STYLE.get(brief.lighting_preset, ""),
        BASE_STYLE,
    ]
    anchor = ", ".join(p for p in parts if p)
    return anchor[:200]


# --- the simulation path ---------------------------------------------------
# The game_spec path derives its anchor from genre + lighting preset. A simulation has
# neither: it describes a PLACE (`environment.semantic_type`, open vocabulary) under a
# time and a weather. Same idea, same BASE_STYLE, different vocabulary -- and reusing the
# base is the point, because it is the frozen v1 art direction (§1).

_TIME_STYLE: dict[str, str] = {
    "dawn": "low golden dawn light, long soft shadows",
    "morning": "clear morning light, gentle shadows",
    "midday": "bright overhead daylight, crisp short shadows",
    "afternoon": "warm afternoon light",
    "dusk": "amber dusk light, long raking shadows",
    "night": "cool moonlight, deep blue shadows",
}

_WEATHER_STYLE: dict[str, str] = {
    "clear": "clean saturated colours",
    "cloudy": "soft diffused light, gently muted colours",
    "overcast": "flat even light, muted natural colours",
    "rain": "wet darkened surfaces, desaturated palette",
    "fog": "hazy pale distance, low contrast",
    "snow": "cold bright palette, pale surfaces",
}


def derive_simulation_style_anchor(environment: dict | None) -> str:
    """One visual descriptor every generated asset in this world shares.

    Deterministic (rule 14): the same environment always yields the same look, so a
    world's assets are reproducible.

    The PLACE leads. `semantic_type` is open vocabulary -- "village", "factory yard",
    "kelp forest" -- and is used verbatim rather than mapped, because a table of places
    would refuse every noun it had not been told about, which is the same mistake the
    procedural vocabulary avoids by naming forms instead of things.
    """
    environment = environment or {}
    place = str(environment.get("semantic_type") or "").replace("_", " ").strip()
    parts = [
        f"{place} setting" if place else "",
        _TIME_STYLE.get(str(environment.get("time_of_day") or "").lower(), ""),
        _WEATHER_STYLE.get(str(environment.get("weather") or "").lower(), ""),
        BASE_STYLE,
    ]
    return ", ".join(part for part in parts if part)[:200]
