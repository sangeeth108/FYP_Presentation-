"""Content Designer agent (ADR-0003 Phase A): the LLM authors the actual
contents of the world — which props exist, and the enemy roster.

This is where "thinking-based uniqueness" lands. Until now every game got the
same ten props from the base spec, so worlds felt templated. Here the planner
*designs* the contents: a crypt gets bone-piles and torches, a sunny meadow
gets crates and banners — each with its own written asset brief.

Safety is by construction, not by hope:
  * the allowed `interactable_template_id`s are injected into the guided-JSON
    **enum** straight from the registry, so an invented id is literally
    unrepresentable in the model's output;
  * everything is re-validated and clamped afterwards anyway (budgets,
    duplicate ids, registry membership);
  * any failure -> None, and the caller keeps the deterministic base content.

Node names derive from `prop_id`, so duplicate ids would collide in the Godot
scene — they are de-duplicated here, not left to chance.
"""

from __future__ import annotations

import json
import logging

import httpx
from knowledge.registries import registry

from agents.composition_patterns import known_archetypes
from agents.intent import Brief
from agents.llm_planner import planner_seed

log = logging.getLogger(__name__)

MAX_PROPS = 14
MAX_ENEMY_KINDS = 3
MAX_OBJECTS = 4  # composite interactive objects (a car, a house) — kept few; each
# is a footprint the level must fit and the affordance oracle must clear.


def entities_schema() -> dict:
    """Guided-JSON schema whose enums ARE the registry allowlist."""
    allow = registry()
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["player_brief", "enemies", "props"],
        "properties": {
            # WHO the player is (spec v2.1.0). "as a dog, explore the village" has
            # to be able to make the player a dog; before this field existed the
            # answer was always an untextured capsule, whatever the prompt said.
            "player_brief": _asset_brief_schema("character", 8000),
            "enemies": {
                "type": "array",
                "maxItems": MAX_ENEMY_KINDS,
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["enemy_id", "ai_template_id", "count", "stats", "asset_brief"],
                    "properties": {
                        "enemy_id": {"type": "string", "maxLength": 40},
                        "ai_template_id": {
                            "type": "string",
                            "enum": sorted(allow["ai_template_id"]),
                        },
                        "count": {"type": "integer", "minimum": 1, "maximum": 25},
                        "stats": {
                            "type": "object",
                            "additionalProperties": False,
                            "required": ["health", "damage", "speed"],
                            "properties": {
                                "health": {"type": "integer", "minimum": 1, "maximum": 100},
                                "damage": {"type": "integer", "minimum": 1, "maximum": 20},
                                "speed": {"type": "number", "minimum": 1, "maximum": 8},
                            },
                        },
                        "asset_brief": _asset_brief_schema("character", 8000),
                    },
                },
            },
            "props": {
                "type": "array",
                "minItems": 4,
                "maxItems": MAX_PROPS,
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "required": [
                        "prop_id",
                        "interactable_template_id",
                        "placement_tags",
                        "asset_brief",
                    ],
                    "properties": {
                        "prop_id": {"type": "string", "maxLength": 40},
                        "interactable_template_id": {
                            "type": "string",
                            "enum": sorted(allow["interactable_template_id"]),
                        },
                        "placement_tags": {
                            "type": "array",
                            "maxItems": 3,
                            "items": {"type": "string", "maxLength": 24},
                        },
                        "asset_brief": _asset_brief_schema("prop", 2000),
                    },
                },
            },
            # Composite interactive OBJECTS (ADR-0008): things whose PARTS the
            # player operates — a car whose doors open, a house you enter, a chest
            # you unlock. The planner only NAMES the archetype (a fixed menu); the
            # deterministic pattern library decides the doors/lids/sockets, so the
            # model never authors geometry (rule 10). Optional — most games have none.
            "objects": {
                "type": "array",
                "maxItems": MAX_OBJECTS,
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["object_id", "archetype", "bbox", "brief"],
                    "properties": {
                        "object_id": {"type": "string", "maxLength": 40},
                        "archetype": {"type": "string", "enum": sorted(known_archetypes())},
                        # rough metric size [width, height, depth]; clamped in sanitize.
                        "bbox": {
                            "type": "array",
                            "minItems": 3,
                            "maxItems": 3,
                            "items": {"type": "number", "minimum": 0.5, "maximum": 15},
                        },
                        "brief": {"type": "string", "minLength": 3, "maxLength": 200},
                        "placement_tags": {
                            "type": "array",
                            "maxItems": 3,
                            "items": {"type": "string", "maxLength": 24},
                        },
                    },
                },
            },
        },
    }


def _asset_brief_schema(category: str, tri_budget: int) -> dict:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["brief", "category", "tri_budget"],
        "properties": {
            "brief": {"type": "string", "minLength": 3, "maxLength": 200},
            "category": {
                "type": "string",
                # The mesh-producing subset of AssetBrief's categories. Spelled
                # out rather than derived because this is a GRAMMAR the model
                # generates against, and it must exclude the audio and texture
                # categories a mesh brief can never be. Kept in step with
                # asset_farm.brief.CATEGORIES by test_category_bridge.
                "enum": ["prop", "building_module", "character", "foliage"],
            },
            "tri_budget": {"type": "integer", "minimum": 50, "maximum": 20000},
        },
    }


SYSTEM_PROMPT = """You are the content designer for PromptPlay 3D. Given a game \
idea and its brief, decide WHO THE PLAYER IS and WHAT EXISTS in the world: the props \
and the enemy roster.

Rules:
- `player_brief` describes the player's own body, in the third person. If the idea \
says who you are ("as a dog, explore the village", "play as a knight"), that IS the \
player: write it ("a scruffy village dog, low-poly, floppy ears"). If the idea never \
says, infer the fitting protagonist for the setting and say so plainly. Describe only \
the character's appearance — never the camera, the controls or the scene.
- Pick props only from the allowed interactable ids (the schema enforces this). \
Use them creatively: chest_lidded = any container, lever_switch = any wall fixture, \
ladder_climbable = any climbable, spawn_site = a checkpoint landmark, gate_sliding = a \
barrier, objective_trigger = a banner/marker, pickup_supply = a lootable, door_hinged / \
door_hinged_lockable = doors.
- Write a vivid, specific `brief` for each asset that matches the game's mood \
(e.g. "a bone-choked funerary urn, cracked and ash-stained"), because that text is what \
the asset pipeline builds from.
- 4-14 props total. Each needs a unique, DESCRIPTIVE snake_case prop_id naming the thing \
itself, not its template: `bone_urn`, `femur_lever`, `wisteria_trellis` — never `chest_lidded` \
or `prop_1`. These become the node names in the editable project the player downloads, so a \
human must be able to read the scene tree and know what everything is.
- Enemies: 1-2 kinds fitting the theme, total count near the requested density. \
Stats: health 1-100, damage 1-20, speed 1-8 (a shambler is slow+tough, a rogue fast+frail).
- placement_tags are free-text hints like ["loot"], ["spawn"], ["critical_path"].
- `objects` (optional, 0-4): composite things the player OPERATES — a car whose \
doors open, a house you enter, a chest you unlock, a cabinet, a gate. Give each a \
descriptive snake_case object_id, an `archetype` from the allowed menu (the schema \
enforces it), a rough metric `bbox` [width, height, depth] in metres (a car ~[2,1.5,4], \
a cottage ~[6,4,6], a chest ~[1,0.8,0.6]), and a `brief` for its body's look. Do NOT \
describe the doors/lids — the engine adds those correctly from the archetype. Only add \
objects the idea actually calls for; a bare dungeon needs none.
Answer with JSON only."""


def ensure_pickups(props: list[dict], quest: dict | None) -> list[dict]:
    """Guarantee the world holds at least as many collectibles as the goal demands.

    A collect_n game whose level contains nothing to collect builds perfectly and
    can never be won (gate 5 catches it as COLLECT_QUEST_IMPOSSIBLE). The goal and
    the content must never disagree, so if the author fell short — or never ran —
    top the world up deterministically rather than shipping an unwinnable game.
    """
    if quest is None:
        return props

    needed = quest["required_count"]
    have = sum(1 for p in props if p["interactable_template_id"] == "pickup_supply")
    if have >= needed:
        return props

    noun = quest["label"].rstrip("s").lower() or "relic"
    topped = list(props)
    seen = {p["prop_id"] for p in props}
    for i in range(needed - have):
        prop_id = _unique(f"{noun}_{i + 1:02d}", seen)
        topped.append(
            {
                "prop_id": prop_id,
                "interactable_template_id": "pickup_supply",
                "placement_tags": ["loot"],
                "asset_brief": {
                    "brief": f"a {noun} the player must gather to escape",
                    "category": "prop",
                    "tri_budget": 600,
                },
            }
        )
    return topped[:MAX_PROPS] if len(topped) <= MAX_PROPS else topped


def llm_entities(
    prompt: str,
    brief: Brief,
    settings,
    knowledge: str = "",
    transport: httpx.BaseTransport | None = None,
    quest: dict | None = None,
) -> dict | None:
    """Ask the planner to author the world's contents. None on any failure."""
    system = SYSTEM_PROMPT if not knowledge else f"{SYSTEM_PROMPT}\n\n{knowledge}"
    goal = ""
    if quest is not None:
        goal = (
            f"\nThe GOAL of this game is to gather {quest['required_count']} "
            f"{quest['label'].lower()}, so at least {quest['required_count']} of your props "
            "MUST use interactable_template_id 'pickup_supply' — those are the things the "
            "player collects. Name and describe them as that theme's treasures."
        )
    user = (
        f"Game idea: {prompt}\n"
        f"Genre: {brief.genre}. Mood: {brief.mood}. Lighting: {brief.lighting_preset}.\n"
        f"Zones: {brief.zone_count}. Target total enemies: {brief.enemy_count}.{goal}"
    )
    try:
        with httpx.Client(
            base_url=settings.llm_base_url,
            timeout=settings.llm_timeout_seconds,
            transport=transport,
        ) as client:
            response = client.post(
                "/api/chat",
                json={
                    "model": settings.llm_model,
                    "stream": False,
                    "format": entities_schema(),
                    "keep_alive": "30m",
                    "options": {"temperature": 0.6, "seed": planner_seed(settings, 2)},
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                },
            )
            response.raise_for_status()
            raw = json.loads(response.json()["message"]["content"])
    except Exception as exc:
        log.warning(
            "Content Designer unavailable (%s: %s) at %s — keeping the base content",
            type(exc).__name__,
            exc,
            settings.llm_base_url,
        )
        return None

    try:
        return sanitize(raw, brief)
    except (KeyError, TypeError, ValueError) as exc:
        log.warning("Content Designer output rejected (%s) — keeping the base content", exc)
        return None


def sanitize(raw: dict, brief: Brief) -> dict | None:
    """Re-validate the model's content against the registry and the budgets.
    The enum makes invented ids impossible; this is the belt to that braces,
    and it de-duplicates ids (Godot node names derive from them)."""
    allow = registry()

    props: list[dict] = []
    seen: set[str] = set()
    for prop in raw.get("props", [])[:MAX_PROPS]:
        if prop["interactable_template_id"] not in allow["interactable_template_id"]:
            continue  # unreachable via the enum, but never trust the model
        prop_id = _unique(prop["prop_id"], seen)
        props.append(
            {
                "prop_id": prop_id,
                "interactable_template_id": prop["interactable_template_id"],
                "placement_tags": list(prop.get("placement_tags", []))[:3],
                "asset_brief": prop["asset_brief"],
            }
        )
    if len(props) < 4:
        return None  # too sparse to be a world — keep the deterministic content

    enemies: list[dict] = []
    if brief.enemy_count > 0:
        budget = min(brief.enemy_count, 25)
        for enemy in raw.get("enemies", [])[:MAX_ENEMY_KINDS]:
            if enemy["ai_template_id"] not in allow["ai_template_id"] or budget <= 0:
                continue
            count = max(1, min(int(enemy["count"]), budget))
            budget -= count
            enemies.append(
                {
                    "enemy_id": _unique(enemy["enemy_id"], seen),
                    "ai_template_id": enemy["ai_template_id"],
                    "count": count,
                    "stats": enemy["stats"],
                    "asset_brief": enemy["asset_brief"],
                }
            )
        if not enemies:
            return None  # the brief wanted enemies and we got none — fall back

    out = {"props": props, "enemies": enemies}

    # Composite interactive objects (ADR-0008). The archetype enum makes an invented
    # kind impossible; this is the belt to that: drop anything not in the vetted
    # menu, dedupe ids (they become node names), clamp the footprint. The parts +
    # sockets are added downstream by the pattern library, never by the model.
    objects: list[dict] = []
    for obj in raw.get("objects", [])[:MAX_OBJECTS]:
        if obj.get("archetype") not in known_archetypes():
            continue  # unreachable via the enum, but never trust the model
        raw_bbox = obj.get("bbox") or []
        if len(raw_bbox) != 3:
            continue
        bbox = [max(0.5, min(float(v), 15.0)) for v in raw_bbox]
        brief = str(obj.get("brief", "")).strip()
        if not (3 <= len(brief) <= 200):
            continue
        objects.append(
            {
                "object_id": _unique(obj["object_id"], seen),
                "archetype": obj["archetype"],
                "bbox": bbox,
                "brief": brief,
                "placement_tags": list(obj.get("placement_tags", []))[:3],
            }
        )
    if objects:
        out["objects"] = objects

    # WHO the player is. Optional on purpose: a model that omits it (or writes a
    # junk one) costs the game its props too if we hard-fail here, and the capsule
    # is a working fallback. The schema clamps length; we only sanity-check shape.
    player_brief = raw.get("player_brief")
    if isinstance(player_brief, dict) and isinstance(player_brief.get("brief"), str):
        text = player_brief["brief"].strip()
        if 3 <= len(text) <= 200:
            out["player_brief"] = {
                "brief": text,
                "category": "character",  # a player is always a character, whatever it claims
                "tri_budget": max(50, min(int(player_brief.get("tri_budget", 8000)), 20000)),
            }
    return out


def _unique(candidate: str, seen: set[str]) -> str:
    base = "".join(c if c.isalnum() else "_" for c in candidate.lower()).strip("_") or "item"
    name = base
    suffix = 2
    while name in seen:
        name = f"{base}_{suffix}"
        suffix += 1
    seen.add(name)
    return name
