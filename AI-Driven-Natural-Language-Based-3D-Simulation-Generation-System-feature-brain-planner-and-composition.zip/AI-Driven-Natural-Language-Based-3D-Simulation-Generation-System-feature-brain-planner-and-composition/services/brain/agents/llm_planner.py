"""S1 (LLM): prompt -> Brief via Ollama structured outputs.

Guided decoding for real: the Brief JSON schema is passed as Ollama's
``format``, so the local Qwen planner can only emit schema-shaped JSON
(same principle as vLLM+xgrammar, which replaces this transport in P3+).
Everything is still validated and clamped afterwards — the LLM proposes,
deterministic code disposes. ANY failure (server down, timeout, bad JSON,
out-of-enum) returns None and the caller falls back to the rule-based
parser, so the platform never depends on the GPU being up.

Explicit user options (genre/camera) always override the model.
"""

from __future__ import annotations

import json
import logging

import httpx

from agents.intent import CAMERAS, GENRES, LIGHTING_PRESETS, Brief

log = logging.getLogger(__name__)

DEFAULT_PLANNER_SEED = 4521


def planner_seed(settings, salt: int = 0) -> int:
    """The Ollama sampling seed for a planner call, derived from the GAME seed.

    Every agent used a hardcoded 4521, so the same prompt always produced the
    same design — the "unique games" promise was frozen: a different game seed
    only reshuffled the floor plan (PCG), never the enemies, player identity or
    win condition. Deriving the sampling seed from the game seed gives BOTH
    reproducibility (same seed -> same game, rule 14) and variety (different seed
    -> a genuinely different design of the same idea).

    `salt` decorrelates the agents so brief/objective/content don't move in
    lockstep. Falls back to the constant when there is no game seed (a bare
    Settings object, e.g. the editor path), preserving old behaviour there.
    """
    base = getattr(settings, "seed", None)
    if base is None:
        return DEFAULT_PLANNER_SEED
    # Knuth multiplicative hash, kept in Ollama's valid non-negative int range.
    return (int(base) * 2654435761 + salt) % (2**31)


BRIEF_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "required": [
        "genre",
        "camera",
        "zone_count",
        "verticality_tiers",
        "enemy_count",
        "mood",
        "lighting_preset",
    ],
    "properties": {
        "genre": {"type": "string", "enum": list(GENRES)},
        "camera": {"type": "string", "enum": list(CAMERAS)},
        "zone_count": {"type": "integer", "minimum": 3, "maximum": 20},
        "verticality_tiers": {"type": "integer", "minimum": 1, "maximum": 3},
        "enemy_count": {"type": "integer", "minimum": 0, "maximum": 25},
        "mood": {"type": "string", "maxLength": 60},
        "lighting_preset": {"type": "string", "enum": list(LIGHTING_PRESETS)},
    },
}

SYSTEM_PROMPT = """You are the game designer for PromptPlay 3D, which builds small \
browser 3D games (3-8 minute sessions) from one player prompt. Map the prompt onto \
the fixed design space in the JSON schema:
- genre: topdown_survival_escape_3d (escape/survive threats), arena_combat_3d \
(fighting in a bounded space), collect_explore_3d (peaceful-ish exploration), \
dungeon_crawl_3d (rooms and corridors, delving).
- camera: top_down_3d suits survival/escape, third_person suits arena/exploring, \
isometric_3d suits dungeon crawls. Follow the prompt if it implies a view.
- zone_count: 3-5 tiny, 6-9 medium, 10-20 large/sprawling.
- verticality_tiers: 2-3 only if towers/floors/cliffs are implied, else 1.
- enemy_count: 0 for peaceful ideas, 3-6 light, 8-15 dangerous, 16-25 horde.
- mood: a short atmospheric phrase (max 60 chars) capturing the prompt's feel.
- lighting_preset: overcast_day (neutral), moonlit_night (dark/night), dusk_fog \
(misty/haunted/twilight), sunny_bright (cheerful/day), cave_torchlit (underground/warm dark).
Answer with JSON only."""


def llm_brief(
    prompt: str,
    genre: str | None,
    camera: str | None,
    settings,
    transport: httpx.BaseTransport | None = None,
    knowledge: str = "",
) -> Brief | None:
    """Ask the local planner for a Brief; None on any failure (caller falls back).

    `knowledge` carries RAG-retrieved design notes (RQ3): grounding the planner
    in what this system actually implements reduces spec drift."""
    system_prompt = SYSTEM_PROMPT if not knowledge else f"{SYSTEM_PROMPT}\n\n{knowledge}"
    try:
        with httpx.Client(
            base_url=settings.llm_base_url,
            timeout=settings.llm_timeout_seconds,
            transport=transport,
        ) as client:
            response = client.post(
                "/api/chat",
                json={
                    "model": settings.llm_model,
                    "stream": False,
                    "format": BRIEF_SCHEMA,
                    # Keep the 17 GB model resident between jobs: a cold load
                    # costs ~50s and would blow the timeout into a silent
                    # rules fallback on the first request after idle.
                    "keep_alive": "30m",
                    "options": {"temperature": 0.3, "seed": planner_seed(settings, 0)},
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": prompt},
                    ],
                },
            )
            response.raise_for_status()
            raw = json.loads(response.json()["message"]["content"])
    except Exception as exc:
        # Falling back to the rule parser is correct (a dead GPU must never stop
        # generation) — but it must never be SILENT. A misconfigured base_url
        # once turned the whole brain off while every game still "passed".
        log.warning(
            "LLM planner unavailable (%s: %s) at %s — falling back to the rule parser",
            type(exc).__name__,
            exc,
            settings.llm_base_url,
        )
        return None

    try:
        picked_genre = genre if genre in GENRES else raw["genre"]
        picked_camera = camera if camera in CAMERAS else raw["camera"]
        if picked_genre not in GENRES or picked_camera not in CAMERAS:
            return None
        lighting = raw.get("lighting_preset")
        return Brief(
            genre=picked_genre,
            camera=picked_camera,
            zone_count=max(3, min(20, int(raw["zone_count"]))),
            verticality_tiers=max(1, min(3, int(raw["verticality_tiers"]))),
            enemy_count=max(0, min(25, int(raw["enemy_count"]))),
            mood=str(raw["mood"])[:60],
            lighting_preset=lighting if lighting in LIGHTING_PRESETS else "overcast_day",
        )
    except (KeyError, TypeError, ValueError):
        return None
