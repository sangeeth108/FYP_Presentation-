"""S2 (deterministic stage): Brief -> canonical game_spec.

Applies the brief onto the vetted base spec (the golden game's, schema-
frozen v2) as a small, reviewable patch: genre, camera, world shape,
enemy count, title, mood, seed. The guided-JSON planner (full P2) will
emit richer specs through the same seam; the schema validation in the
task gates both identically.
"""

from __future__ import annotations

import copy

from agents.intent import Brief

_CONTROLLER_BY_CAMERA = {
    "third_person": "controller_third_person",
    "top_down_3d": "controller_topdown_3d",
    "isometric_3d": "controller_isometric_3d",
}

# Each genre gets its own level topology (all four vetted PCG algorithms):
# escape = paths with loops; arena = structured chambers (bisection tree);
# exploration = organic warren; dungeon = paced chain (WFC-dressed kinds).
_ALGORITHM_BY_GENRE = {
    "topdown_survival_escape_3d": "room_corridor",
    "arena_combat_3d": "bsp",
    "collect_explore_3d": "cellular_caves",
    "dungeon_crawl_3d": "wfc_dressing",
}

# Prompts set in an OPEN place get an outdoor world (open ground + a mountain
# ring) instead of walled rooms. Keyword-driven so it is deterministic and shared
# by the agent chain and this builder (their equivalence guard depends on parity).
_OUTDOOR_HINTS = frozenset({
    "village", "town", "city", "forest", "field", "meadow", "park", "garden", "farm",
    "outdoor", "open", "wilderness", "valley", "mountain", "mountains", "hill", "hills",
    "beach", "coast", "island", "street", "market", "courtyard", "countryside", "plaza",
    "harbor", "harbour", "woods", "grove", "orchard", "ranch", "desert", "savanna",
    "jungle", "prairie", "pasture", "campsite", "camp", "yard", "square", "lakeside",
    "riverside",
})


def world_kind_for(prompt: str) -> str:
    """'outdoor' when the idea is set in an open place, else 'indoor' (default)."""
    words = set((prompt or "").lower().replace("-", " ").replace(",", " ").split())
    return "outdoor" if words & _OUTDOOR_HINTS else "indoor"


def build_spec(
    base_spec: dict,
    brief: Brief,
    game_id: str,
    title: str,
    seed: int,
) -> dict:
    """Return a new schema-valid spec personalized by the brief."""
    spec = copy.deepcopy(base_spec)
    meta = spec["meta"]
    meta["game_id"] = game_id
    meta["title"] = (title or meta["title"])[:80]
    meta["genre"] = brief.genre
    meta["camera"] = brief.camera
    meta["seed"] = seed
    meta["mood"] = brief.mood
    # One art direction for the whole game's generated assets (kept in sync with
    # the agent chain's Prompt Analyzer — the equivalence guard checks this).
    from agents.style import derive_style_anchor

    meta["style_anchor"] = derive_style_anchor(brief)

    spec["world"]["lighting_preset_id"] = brief.lighting_preset
    spec["world"]["kind"] = world_kind_for(title)  # indoor rooms vs an open outdoor world
    zone_graph = spec["world"]["zone_graph"]
    zone_graph["algorithm"] = _ALGORITHM_BY_GENRE[brief.genre]
    zone_graph["zone_count"] = brief.zone_count
    zone_graph["verticality_tiers"] = brief.verticality_tiers

    spec["player"]["controller_template_id"] = _CONTROLLER_BY_CAMERA[brief.camera]

    if brief.enemy_count == 0:
        spec["entities"]["enemies"] = []
    else:
        for enemy in spec["entities"]["enemies"]:
            enemy["count"] = min(brief.enemy_count, 25)
    spec["budgets"]["max_enemies"] = max(5, min(25, brief.enemy_count))

    session = spec["budgets"]["session_minutes"]
    spec["budgets"]["session_minutes"] = max(3, min(8, session + (brief.zone_count - 7) // 3))
    return spec
