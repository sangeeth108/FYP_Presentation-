"""Multi-agent chain (P2 agent harness, ADR-0003 Phase A).

Each agent has ONE job and the SAME shape — context -> (guided) decision ->
JSON patch -> logged — and the Arbiter merges every agent's patches under
the constraint priority stack. This is the "many agents, each a specific
task" structure from CLAUDE.md §6, built so uniqueness comes from the
agents' composed decisions, not from free code.

This checkpoint wires the first specialists (Prompt Analyzer, World
Designer, Mechanics) over the SCALAR design fields, reusing the already-
tested intent + spec-builder logic. Entity-list authoring (richer, unique
per-zone placement) and the remaining agents are the next expansion; the
harness shape here is what they plug into.

No free gameplay code, ever — agents emit spec patches; templates execute.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field

from knowledge.rag import as_context, search
from orchestrator.arbiter import Proposal, arbitrate

from agents.content_designer import ensure_pickups, llm_entities
from agents.game_designer import collect_objectives, llm_objective
from agents.intent import Brief, parse_intent
from agents.llm_planner import llm_brief
from agents.spec_builder import _ALGORITHM_BY_GENRE, _CONTROLLER_BY_CAMERA, world_kind_for


@dataclass
class AgentContext:
    prompt: str
    seed: int
    genre: str | None = None  # explicit user option
    camera: str | None = None  # explicit user option
    llm_enabled: bool = False
    llm_base_url: str = "http://localhost:11434"
    llm_model: str = "qwen3.6:27b"
    llm_timeout_seconds: float = 90.0
    rag_enabled: bool = True  # ablation D toggle (C = off, D = on)
    knowledge: str = ""  # RAG-retrieved notes, set by the Prompt Analyzer
    # Set by the Game Designer when it picks a collect_n goal; the Content
    # Designer reads it so the world actually contains the things to collect.
    quest: dict | None = None


@dataclass
class ChainResult:
    brief: Brief
    brief_source: str  # "llm" | "rules"
    spec: dict
    agent_proposals: list[dict] = field(default_factory=list)  # {agent, band, patches}
    arbiter_decisions: list[dict] = field(default_factory=list)
    retrieved_notes: list[str] = field(default_factory=list)  # RAG provenance (RQ3)


class PromptAnalyzerAgent:
    """S1: prompt -> Brief (safety/genre/tone). Also owns meta identity +
    lighting patches. Retrieves design knowledge (RAG) to ground the planner,
    uses the LLM when enabled, else the rule parser."""

    name = "prompt_analyzer"
    band = "designer_intent"

    def analyze(self, ctx: AgentContext) -> tuple[Brief, str, list[str]]:
        retrieved: list[str] = []
        if ctx.rag_enabled:
            notes = search(ctx.prompt, k=3, base_url=ctx.llm_base_url)
            retrieved = [n.id for n in notes]
            ctx.knowledge = as_context(notes)  # downstream agents design grounded too

        if ctx.llm_enabled:
            brief = llm_brief(ctx.prompt, ctx.genre, ctx.camera, ctx, knowledge=ctx.knowledge)
            if brief is not None:
                return brief, "llm", retrieved
        return parse_intent(ctx.prompt, genre=ctx.genre, camera=ctx.camera), "rules", retrieved

    def propose(self, ctx: AgentContext, brief: Brief, spec: dict) -> dict[str, object]:
        from agents.style import derive_style_anchor

        return {
            "meta.genre": brief.genre,
            "meta.camera": brief.camera,
            "meta.mood": brief.mood,
            # One art direction the whole game's generated assets share.
            "meta.style_anchor": derive_style_anchor(brief),
            "world.lighting_preset_id": brief.lighting_preset,
        }


class WorldDesignerAgent:
    """World: level topology + scale (genre picks the PCG algorithm)."""

    name = "world_designer"
    band = "designer_intent"

    def propose(self, ctx: AgentContext, brief: Brief, spec: dict) -> dict[str, object]:
        return {
            "world.zone_graph.algorithm": _ALGORITHM_BY_GENRE[brief.genre],
            "world.zone_graph.zone_count": brief.zone_count,
            "world.zone_graph.verticality_tiers": brief.verticality_tiers,
            # indoor rooms vs an open outdoor world (a village/field), from the prompt.
            "world.kind": world_kind_for(ctx.prompt),
        }


class MechanicsAgent:
    """Mechanics: controller (per camera), budgets, pacing."""

    name = "mechanics"
    band = "designer_intent"

    def propose(self, ctx: AgentContext, brief: Brief, spec: dict) -> dict[str, object]:
        session = spec["budgets"]["session_minutes"] + (brief.zone_count - 7) // 3
        return {
            "player.controller_template_id": _CONTROLLER_BY_CAMERA[brief.camera],
            "budgets.max_enemies": max(5, min(25, brief.enemy_count)),
            "budgets.session_minutes": max(3, min(8, session)),
        }


class GameDesignerAgent:
    """Goal: WHAT the player must do to win (ADR-0003 — the brain's first real
    choice of game *kind*, not just decoration). Picks a win condition from the
    registry's implemented objectives; with no LLM it keeps the reach_zone spine,
    byte-identical to the legacy builder."""

    name = "game_designer"
    band = "designer_intent"

    def propose(self, ctx: AgentContext, brief: Brief, spec: dict) -> dict[str, object]:
        if ctx.llm_enabled:
            quest = llm_objective(ctx.prompt, brief, ctx, knowledge=ctx.knowledge)
            if quest is not None:
                ctx.quest = quest  # the Content Designer must now author the relics
                return {"objectives": collect_objectives(quest, spec["objectives"][-1])}
        return {"objectives": copy.deepcopy(spec["objectives"])}


class ContentDesignerAgent:
    """Content: WHAT exists in the world — the props and the enemy roster
    (ADR-0003 Phase A). With the LLM it authors unique contents per game;
    without it, the deterministic base content (count-clamped) is kept, so
    rules mode stays byte-identical to the legacy builder."""

    name = "content_designer"
    band = "designer_intent"

    def propose(self, ctx: AgentContext, brief: Brief, spec: dict) -> dict[str, object]:
        if ctx.llm_enabled:
            authored = llm_entities(
                ctx.prompt, brief, ctx, knowledge=ctx.knowledge, quest=ctx.quest
            )
            if authored is not None:
                patch: dict[str, object] = {
                    "entities.props": ensure_pickups(authored["props"], ctx.quest),
                    "entities.enemies": authored["enemies"],
                }
                # WHO the player is (spec v2.1.0). Only the LLM path decides this:
                # reading "as a dog" out of free text is exactly the ambiguity the
                # planner exists for, and rules mode must stay byte-identical.
                if "player_brief" in authored:
                    patch["player.asset_brief"] = authored["player_brief"]
                    patch["schema_version"] = "2.1.0"  # the spec now uses a v2.1 field
                # Composite interactive objects (ADR-0008): a car, a house. Only
                # the LLM path decides these; the pattern library expands them and
                # placement drops them in during materialization (worker).
                if authored.get("objects"):
                    patch["entities.objects"] = authored["objects"]
                return patch

        # Deterministic fallback: the vetted base content, enemy counts clamped.
        if brief.enemy_count == 0:
            enemies: list[dict] = []
        else:
            enemies = copy.deepcopy(spec["entities"]["enemies"])
            for enemy in enemies:
                enemy["count"] = min(brief.enemy_count, 25)
        patches: dict[str, object] = {"entities.enemies": enemies}
        if ctx.quest is not None:
            # A hunt whose world contains nothing to hunt is unwinnable — and the
            # base spec has no collectibles at all. Never let the goal and the
            # content disagree, even when the content agent failed.
            patches["entities.props"] = ensure_pickups(
                copy.deepcopy(spec["entities"]["props"]), ctx.quest
            )
        return patches


DEFAULT_AGENTS = (
    WorldDesignerAgent(),
    MechanicsAgent(),
    GameDesignerAgent(),  # picks the goal BEFORE content, so the relics get authored
    ContentDesignerAgent(),
)


def run_chain(base_spec: dict, ctx: AgentContext) -> ChainResult:
    """Run the agent chain: analyzer sets the brief, specialists propose
    patches, the Arbiter merges them (plus explicit user options) under the
    priority stack. Returns the merged spec + full decision provenance."""
    analyzer = PromptAnalyzerAgent()
    brief, brief_source, retrieved_notes = analyzer.analyze(ctx)

    proposals: list[Proposal] = []
    agent_proposals: list[dict] = []
    for order, agent in enumerate([analyzer, *DEFAULT_AGENTS]):
        patches = agent.propose(ctx, brief, base_spec)
        proposals.append(Proposal(source=agent.name, band=agent.band, patches=patches, order=order))
        agent_proposals.append({"agent": agent.name, "band": agent.band, "patches": patches})
    order = len(proposals)

    # Explicit user options outrank inference for the fields the user chose.
    user_patches: dict[str, object] = {}
    if ctx.genre:
        user_patches["meta.genre"] = ctx.genre
    if ctx.camera:
        user_patches["meta.camera"] = ctx.camera
    if user_patches:
        proposals.append(
            Proposal(
                source="user_options",
                band="designer_intent",
                patches=user_patches,
                order=order,
            )
        )

    spec, decisions = arbitrate(base_spec, proposals)
    return ChainResult(
        brief=brief,
        brief_source=brief_source,
        spec=spec,
        agent_proposals=agent_proposals,
        arbiter_decisions=decisions,
        retrieved_notes=retrieved_notes,
    )


def author_spec(
    base_spec: dict, ctx: AgentContext, game_id: str, title: str
) -> ChainResult:
    """Production entry point (S1+S2): run the agent chain, then stamp the
    job's identity (not an agent decision — these are job facts, so they are
    set directly rather than contested through the priority stack)."""
    result = run_chain(base_spec, ctx)
    result.spec["meta"]["game_id"] = game_id
    result.spec["meta"]["title"] = (title or result.spec["meta"]["title"])[:80]
    result.spec["meta"]["seed"] = ctx.seed
    return result
