"""Serendib Assist edit engine (P3 AI-dock): a plain-language instruction against
an existing game -> a validated, registry-bound change to its spec.

This is the brain half of the P3 gate ("download -> open in Serendib -> AI-dock
edit -> re-export"). Same discipline as the rest of the system: **the LLM/heuristics
decide WHAT to change; only bounded edits to allow-listed spec fields happen** —
never free code (§10 rule 10, §14). An edit can make skeletons faster or the
crypt darker; it cannot invent a mechanic or write GDScript.

Deterministic first (this file): keyword rules produce bounded numeric/enum
patches, clamped to the schema and the registry, so a request can never push the
spec out of contract. The guided-JSON LLM path layers on later behind the same
`plan_edit` shape, exactly as llm_planner sits behind parse_intent.

Every edit reports what it changed AND what it could not do, so the dock can tell
the user honestly ("made them faster; 'add a boss' isn't supported yet").
"""

from __future__ import annotations

import copy
import json
import logging
import re
from dataclasses import dataclass, field

import httpx
from knowledge.registries import registry

log = logging.getLogger(__name__)

# Registry-bound lighting synonyms -> preset id. Only ids the engine honors.
_LIGHTING_WORDS: list[tuple[str, str]] = [
    (r"\b(torchlit|torch|crypt|dungeon)\b", "cave_torchlit"),
    (r"\b(fog\w*|dusk|misty|mist)\b", "dusk_fog"),
    (r"\b(night|moonlit|moon|dark\w*)\b", "moonlit_night"),
    (r"\b(sunny|bright|cheerful|daylight)\b", "sunny_bright"),
    (r"\b(overcast|cloudy|grey|gray|neutral)\b", "overcast_day"),
]

SPEED_MIN, SPEED_MAX = 1.0, 8.0
HEALTH_MIN, HEALTH_MAX = 1, 100
DAMAGE_MIN, DAMAGE_MAX = 1, 20
ZONE_MIN, ZONE_MAX = 3, 20


@dataclass
class EditResult:
    spec: dict  # a NEW spec (the input is never mutated)
    changed: list[str] = field(default_factory=list)  # human-readable, for the dock
    rejected: list[str] = field(default_factory=list)  # asked-for but unsupported

    @property
    def any_change(self) -> bool:
        return bool(self.changed)

    def to_dict(self) -> dict:
        return {"changed": self.changed, "rejected": self.rejected}


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


@dataclass
class EditOps:
    """The bounded, structured edit BOTH paths (keyword + LLM) produce. Applying
    these is the single place the safety guarantees live — so an LLM can only ever
    request one of these bounded operations, never an arbitrary spec mutation."""

    speed_factor: float = 1.0  # multiply enemy speed
    difficulty_factor: float = 1.0  # multiply enemy health + damage
    count_factor: float = 1.0  # multiply enemy counts
    remove_enemies: bool = False
    lighting_preset_id: str | None = None  # must be a registry preset
    zone_count_delta: int = 0  # +/- rooms


def apply_ops(spec: dict, ops: EditOps, rejected: list[str] | None = None) -> EditResult:
    """Apply bounded ops to a COPY of the spec. Every change is clamped to its
    schema range and lighting is registry-checked, so the result cannot leave the
    contract regardless of what asked for it."""
    new = copy.deepcopy(spec)
    changed: list[str] = []
    enemies = new.get("entities", {}).get("enemies", [])

    if ops.speed_factor > 1.001:
        _scale_enemy_stat(
            enemies, "speed", ops.speed_factor, SPEED_MIN, SPEED_MAX, changed, "faster"
        )
    elif ops.speed_factor < 0.999:
        _scale_enemy_stat(
            enemies, "speed", ops.speed_factor, SPEED_MIN, SPEED_MAX, changed, "slower"
        )

    if ops.difficulty_factor > 1.001:
        _scale_enemy_stat(
            enemies, "health", ops.difficulty_factor, HEALTH_MIN, HEALTH_MAX, changed, "tougher"
        )
        _scale_enemy_stat(
            enemies, "damage", ops.difficulty_factor, DAMAGE_MIN, DAMAGE_MAX, changed, "hit harder"
        )
    elif ops.difficulty_factor < 0.999:
        _scale_enemy_stat(
            enemies, "health", ops.difficulty_factor, HEALTH_MIN, HEALTH_MAX, changed, "weaker"
        )
        _scale_enemy_stat(
            enemies, "damage", ops.difficulty_factor, DAMAGE_MIN, DAMAGE_MAX, changed, "hit softer"
        )

    budget = new.get("budgets", {}).get("max_enemies", 25)
    if ops.remove_enemies:
        if enemies:
            new["entities"]["enemies"] = []
            changed.append("removed all enemies")
    elif ops.count_factor > 1.001:
        _scale_enemy_count(enemies, ops.count_factor, budget, changed, "more enemies")
    elif ops.count_factor < 0.999:
        _scale_enemy_count(enemies, ops.count_factor, budget, changed, "fewer enemies")

    if ops.lighting_preset_id:
        allowed = registry()["lighting_preset_id"]
        current = new.get("world", {}).get("lighting_preset_id")
        if ops.lighting_preset_id in allowed and ops.lighting_preset_id != current:
            new["world"]["lighting_preset_id"] = ops.lighting_preset_id
            changed.append(f"lighting -> {ops.lighting_preset_id}")

    if ops.zone_count_delta and new.get("world", {}).get("zone_graph"):
        _resize_level(new["world"]["zone_graph"], ops.zone_count_delta, changed)

    return EditResult(spec=new, changed=changed, rejected=list(rejected or []))


def keyword_ops(instruction: str) -> EditOps:
    """Deterministic keyword -> bounded ops (the tested floor)."""
    text = instruction.lower()
    ops = EditOps()
    if re.search(r"\b(faster|quicker|speed\w* up|more agile)\b", text):
        ops.speed_factor = 1.3
    elif re.search(r"\b(slower|sluggish|slow\w* down)\b", text):
        ops.speed_factor = 0.75
    if re.search(r"\b(harder|tougher|stronger|deadl\w+|brutal)\b", text):
        ops.difficulty_factor = 1.4
    elif re.search(r"\b(easier|weaker|gentler|softer)\b", text):
        ops.difficulty_factor = 0.7
    if re.search(r"\b(no enemies|remove enemies|peaceful|empty it out)\b", text):
        ops.remove_enemies = True
    elif re.search(r"\b(more enemies|extra enemies|a horde|swarm|crowd\w*)\b", text):
        ops.count_factor = 1.5
    elif re.search(r"\b(fewer enemies|less enemies|thin\w* out)\b", text):
        ops.count_factor = 0.6
    for pattern, preset in _LIGHTING_WORDS:
        if re.search(pattern, text):
            ops.lighting_preset_id = preset
            break
    if re.search(r"\b(bigger|larger|expand|more rooms|sprawling)\b", text):
        ops.zone_count_delta = 4
    elif re.search(r"\b(smaller|tighter|fewer rooms|compact|shrink)\b", text):
        ops.zone_count_delta = -4
    return ops


def plan_edit(spec: dict, instruction: str) -> EditResult:
    """Deterministic plain-language edit: keyword -> bounded ops -> apply. The
    input spec is never mutated and the result stays in contract."""
    return apply_ops(spec, keyword_ops(instruction), _unsupported_requests(instruction.lower(), []))


# --- LLM edit path (guided JSON), the layer above the keyword floor ---------
def _ops_schema() -> dict:
    """Guided-JSON schema for the edit ops. Factors are RANGE-bounded and lighting
    is a registry ENUM, so an invented value is unrepresentable in the output —
    the same 'invention is impossible by construction' guarantee as the planner."""
    return {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "speed_factor": {"type": "number", "minimum": 0.5, "maximum": 2.0},
            "difficulty_factor": {"type": "number", "minimum": 0.5, "maximum": 2.0},
            "count_factor": {"type": "number", "minimum": 0.5, "maximum": 2.0},
            "remove_enemies": {"type": "boolean"},
            "lighting_preset_id": {
                "type": "string",
                "enum": [*sorted(registry()["lighting_preset_id"]), "keep"],
            },
            "zone_count_delta": {"type": "integer", "minimum": -8, "maximum": 8},
        },
    }


_EDIT_SYSTEM = """You edit an existing low-poly 3D game by choosing BOUNDED changes.
Given the game's current settings and a user's request, output JSON with only the
fields that should change. Rules:
- speed_factor / difficulty_factor / count_factor multiply enemy speed / (health+
  damage) / counts. 1.0 = no change; stay within 0.5..2.0.
- remove_enemies: true only if the user wants a peaceful/empty game.
- lighting_preset_id: pick from the allowed presets (the schema enforces this), or
  "keep" to leave it.
- zone_count_delta: +/- rooms (-8..8), 0 to leave the size.
You cannot add mechanics, bosses, ranged combat, inventory, story, or multiplayer —
only these bounded tweaks. Output JSON only."""


def _ops_from_llm(raw: dict) -> EditOps:
    """Clamp the model's numbers into EditOps (belt to the schema's braces)."""
    def num(key: str) -> float:
        return _clamp(float(raw.get(key, 1.0)), 0.5, 2.0)

    preset = raw.get("lighting_preset_id")
    return EditOps(
        speed_factor=num("speed_factor"),
        difficulty_factor=num("difficulty_factor"),
        count_factor=num("count_factor"),
        remove_enemies=bool(raw.get("remove_enemies", False)),
        lighting_preset_id=preset if preset in registry()["lighting_preset_id"] else None,
        zone_count_delta=int(_clamp(int(raw.get("zone_count_delta", 0)), -8, 8)),
    )


def llm_edit(
    spec: dict, instruction: str, settings, transport: httpx.BaseTransport | None = None
) -> EditResult | None:
    """LLM-planned edit via guided JSON. None on any failure (caller falls back to
    the deterministic keyword path — a dead model must never break editing)."""
    summary = {
        "genre": spec.get("meta", {}).get("genre"),
        "lighting": spec.get("world", {}).get("lighting_preset_id"),
        "zone_count": spec.get("world", {}).get("zone_graph", {}).get("zone_count"),
        "enemy_kinds": len(spec.get("entities", {}).get("enemies", [])),
    }
    try:
        with httpx.Client(
            base_url=settings.llm_base_url,
            timeout=settings.llm_timeout_seconds,
            transport=transport,
        ) as client:
            response = client.post(
                "/api/chat",
                json={
                    "model": settings.llm_model,
                    "stream": False,
                    "format": _ops_schema(),
                    "keep_alive": "30m",
                    "options": {"temperature": 0.2, "seed": 4521},
                    "messages": [
                        {"role": "system", "content": _EDIT_SYSTEM},
                        {
                            "role": "user",
                            "content": f"Current game: {summary}\nRequest: {instruction}",
                        },
                    ],
                },
            )
            response.raise_for_status()
            raw = json.loads(response.json()["message"]["content"])
    except Exception as exc:
        log.warning("LLM edit unavailable (%s) — falling back to keyword edit", exc)
        return None

    try:
        ops = _ops_from_llm(raw)
    except (KeyError, TypeError, ValueError):
        return None
    # The LLM handles the bounded tweaks; still report the same unsupported asks.
    return apply_ops(spec, ops, _unsupported_requests(instruction.lower(), []))


def _scale_enemy_stat(
    enemies: list[dict], stat: str, factor: float, lo: float, hi: float,
    changed: list[str], label: str,
) -> None:
    touched = False
    for e in enemies:
        stats = e.setdefault("stats", {})
        if stat in stats:
            new_v = _clamp(stats[stat] * factor, lo, hi)
            new_v = round(new_v) if isinstance(stats[stat], int) else round(new_v, 2)
            if new_v != stats[stat]:
                stats[stat] = new_v
                touched = True
    if touched:
        changed.append(f"enemies {label}")


def _scale_enemy_count(
    enemies: list[dict], factor: float, budget: int, changed: list[str], label: str
) -> None:
    total = sum(e.get("count", 0) for e in enemies)
    if not total:
        return
    target = int(_clamp(total * factor, 1, budget))
    if target == total:
        return
    # Distribute the new total across kinds proportionally, at least 1 each.
    scale = target / total
    for e in enemies:
        e["count"] = max(1, round(e.get("count", 1) * scale))
    changed.append(f"{label} (~{target})")


def _resize_level(zg: dict, delta: int, changed: list[str]) -> None:
    old = zg.get("zone_count", 7)
    new_n = int(_clamp(old + delta, ZONE_MIN, ZONE_MAX))
    if new_n != old:
        zg["zone_count"] = new_n
        changed.append(f"level size {old} -> {new_n} rooms")


# Things users plausibly ask for that the v1 template vocabulary can't do — named
# so the dock can be honest instead of silently ignoring them.
_UNSUPPORTED = [
    (r"\b(boss|final boss)\b", "a unique boss enemy"),
    (r"\b(ranged|archer\w*|shoot\w*|gun|bow)\b", "ranged combat"),
    (r"\b(inventory|craft\w*|shop|economy)\b", "inventory/crafting"),
    (r"\b(multiplayer|co-?op|pvp)\b", "multiplayer"),
    (r"\b(story|dialogue|npc|quest giver)\b", "story/dialogue"),
]


def _unsupported_requests(text: str, changed: list[str]) -> list[str]:
    return [what for pattern, what in _UNSUPPORTED if re.search(pattern, text)]
