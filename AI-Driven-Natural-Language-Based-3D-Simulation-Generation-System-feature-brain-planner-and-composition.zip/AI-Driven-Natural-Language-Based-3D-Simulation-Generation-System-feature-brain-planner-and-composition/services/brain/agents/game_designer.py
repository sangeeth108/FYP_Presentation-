"""Game Designer agent: chooses the GOAL — what the player must do to win.

Until now the engine had exactly one win condition (`reach_zone`), so every
generated game was fetch-the-key-and-reach-the-exit no matter what the player
asked for. `collect_n` gave it a second, and this agent is what lets the brain
actually *choose* between them. It is the first genuine decision about what kind
of game this is, rather than what the game is decorated with.

Safety, as everywhere: the choices are the registry's objective template ids,
injected straight into the guided-JSON **enum**, so a goal the engine cannot run
is unrepresentable in the model's output. The spatial spine (entry -> ... ->
locked door -> exit) is identical either way, so every reachability guarantee
survives whichever goal is picked — only the unlock condition differs.

Rules mode (no LLM) keeps `reach_zone`, byte-identical to the legacy builder, so
the CI benchmark gate is untouched.
"""

from __future__ import annotations

import json
import logging

import httpx
from knowledge.registries import registry

from agents.intent import Brief
from agents.llm_planner import planner_seed

log = logging.getLogger(__name__)

MIN_COLLECT = 3
MAX_COLLECT = 8


def objective_schema() -> dict:
    """Guided-JSON schema whose enum IS the registry's implemented objectives."""
    allow = sorted(registry()["objective_template_id"])
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["objective_template_id", "reason"],
        "properties": {
            "objective_template_id": {"type": "string", "enum": allow},
            # Only read when collect_n is chosen; harmless otherwise.
            "required_count": {
                "type": "integer",
                "minimum": MIN_COLLECT,
                "maximum": MAX_COLLECT,
            },
            "label": {"type": "string", "maxLength": 20},  # HUD noun: "Relics"
            "reason": {"type": "string", "maxLength": 160},
        },
    }


SYSTEM_PROMPT = """You are the game designer for PromptPlay 3D. Pick the WIN \
CONDITION for this game from the allowed objective templates (the schema enforces \
the list).

What they mean:
- reach_zone: find the key zone, which unlocks the exit door, then escape. A \
classic "get out alive" goal. Good for escapes, chases, survival.
- collect_n: gather N collectibles scattered across the level; gathering them \
unlocks the exit door. Good for hunts, looting, exploration, gathering \
("find the relics", "collect the samples", "steal the treasure").

If you pick collect_n, also set required_count (3-8) and a short plural `label` \
naming what is gathered, as the HUD shows it: "Relics", "Samples", "Coins".

Pick the goal the player's idea actually describes. Answer with JSON only."""


def llm_objective(
    prompt: str,
    brief: Brief,
    settings,
    knowledge: str = "",
    transport: httpx.BaseTransport | None = None,
) -> dict | None:
    """Ask the designer to choose the win condition. None on any failure."""
    system = SYSTEM_PROMPT if not knowledge else f"{SYSTEM_PROMPT}\n\n{knowledge}"
    user = f"Game idea: {prompt}\nGenre: {brief.genre}. Mood: {brief.mood}."
    try:
        with httpx.Client(
            base_url=settings.llm_base_url,
            timeout=settings.llm_timeout_seconds,
            transport=transport,
        ) as client:
            response = client.post(
                "/api/chat",
                json={
                    "model": settings.llm_model,
                    "stream": False,
                    "format": objective_schema(),
                    "keep_alive": "30m",
                    "options": {"temperature": 0.2, "seed": planner_seed(settings, 1)},
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": user},
                    ],
                },
            )
            response.raise_for_status()
            raw = json.loads(response.json()["message"]["content"])
    except Exception as exc:
        log.warning(
            "Game Designer unavailable (%s: %s) at %s — keeping the reach_zone goal",
            type(exc).__name__,
            exc,
            settings.llm_base_url,
        )
        return None

    try:
        return sanitize(raw)
    except (KeyError, TypeError, ValueError):
        return None


def sanitize(raw: dict) -> dict | None:
    """Re-validate against the registry; None means 'keep the default goal'."""
    template = raw.get("objective_template_id")
    if template not in registry()["objective_template_id"]:
        return None  # unreachable via the enum, but never trust the model
    if template != "collect_n":
        return None  # reach_zone is the default spine — nothing to change

    count = int(raw.get("required_count") or MIN_COLLECT)
    label = str(raw.get("label") or "Relics").strip()[:20] or "Relics"
    return {
        "objective_template_id": "collect_n",
        "required_count": max(MIN_COLLECT, min(MAX_COLLECT, count)),
        "label": label,
        "reason": str(raw.get("reason", ""))[:160],
    }


def collect_objectives(quest: dict, exit_objective: dict) -> list[dict]:
    """The objectives list for a collect_n game: gather N, then escape.

    The exit objective keeps its own template and win flag; only what UNLOCKS it
    changes (`requires_objective`), which is exactly what the writer and gate 5
    already understand.
    """
    exit_copy = dict(exit_objective)
    exit_copy["params"] = dict(exit_copy.get("params", {}))
    exit_copy["params"]["requires_objective"] = "collect_relics"
    return [
        {
            "objective_id": "collect_relics",
            "objective_template_id": "collect_n",
            "params": {
                "required_count": quest["required_count"],
                "label": quest["label"],
            },
            "is_win_condition": False,
        },
        exit_copy,
    ]
