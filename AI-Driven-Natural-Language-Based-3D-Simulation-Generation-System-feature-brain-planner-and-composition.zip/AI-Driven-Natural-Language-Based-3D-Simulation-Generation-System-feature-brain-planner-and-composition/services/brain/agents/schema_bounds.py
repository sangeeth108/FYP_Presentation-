"""Repair what a context-free grammar cannot express, against any schema.

Guided decoding enforces *structure* -- shape, types, required fields, enums --
and nothing else. Numeric ranges and `uniqueItems` are not expressible in a
grammar, so a model is free to violate them and one bad value throws away an
entire artefact.

This was fixed once for the SimulationSpec and the fix was welded to that
schema. Adding a second guided-JSON stage immediately reproduced the same
failure: three of ten SceneBriefs were rejected for `per_100m2: 10000` against a
5000 cap and `width: 4` against an 8 m floor -- accurate readings of small rooms
and dense ground cover, thrown away by the identical bug one file over.

So the repair lives here, parameterised by schema, and every guided stage uses
it. That is finding F3 in `docs/DEFECTS_AND_DECISIONS.md` applied to itself:
the class is "anything a grammar cannot enforce", not "numbers in the spec".
"""

from __future__ import annotations

import math

# Smallest step away from an exclusive bound. Only ever applied to a value the
# model already put out of range, so the distortion is bounded by the schema.
_EXCLUSIVE_EPSILON = 1e-3


def _resolver(schema: dict):
    definitions = schema.get("$defs", {})

    def resolve(node: object, depth: int = 0) -> dict:
        while isinstance(node, dict) and "$ref" in node and depth < 10:
            reference = str(node["$ref"])
            if not reference.startswith("#/$defs/"):
                return node
            node = definitions.get(reference.rsplit("/", 1)[-1], {})
            depth += 1
        return node if isinstance(node, dict) else {}

    return resolve


def clamp_to_schema(candidate: dict, schema: dict) -> list[dict]:
    """Fit every value to the bound the grammar could not enforce.

    Numbers to their range, strings to their length. Returns what changed so
    the caller can disclose it rather than distort silently.
    """
    resolve = _resolver(schema)
    clamped: list[dict] = []

    def bound(value: float, node: dict, path: str) -> float:
        bounded = float(value)
        minimum = node.get("minimum")
        maximum = node.get("maximum")
        exclusive_min = node.get("exclusiveMinimum")
        exclusive_max = node.get("exclusiveMaximum")
        if minimum is not None:
            bounded = max(bounded, float(minimum))
        if maximum is not None:
            bounded = min(bounded, float(maximum))
        if exclusive_min is not None and bounded <= float(exclusive_min):
            bounded = float(exclusive_min) + _EXCLUSIVE_EPSILON
        if exclusive_max is not None and bounded >= float(exclusive_max):
            bounded = float(exclusive_max) - _EXCLUSIVE_EPSILON
        if node.get("type") == "integer":
            # Rounding must move INTO the range, never back out of it.
            bounded = math.ceil(bounded) if bounded > float(value) else math.floor(bounded)
        if bounded == float(value):
            return value
        clamped.append({"path": path, "requested": float(value), "applied": bounded})
        return bounded

    def walk(value: object, node: dict, path: str) -> object:
        node = resolve(node)
        if not node:
            return value
        if isinstance(value, dict):
            properties = node.get("properties") or {}
            for key, child in value.items():
                if key in properties:
                    value[key] = walk(child, properties[key], f"{path}.{key}" if path else key)
            return value
        if isinstance(value, list):
            prefix = node.get("prefixItems")
            items = node.get("items")
            for index, child in enumerate(value):
                sub = (
                    prefix[index]
                    if isinstance(prefix, list) and index < len(prefix)
                    else items
                )
                if isinstance(sub, dict):
                    value[index] = walk(child, sub, f"{path}[{index}]")
            return value
        if isinstance(value, str):
            # Length is a bound too, and the grammar adapter strips minLength /
            # maxLength outright -- so the model never sees the limit and cannot
            # respect it. Three of ten SceneBriefs were discarded because a
            # thoughtful `why_individual` ran to 140 characters against a 120
            # cap. Losing the tail of a justification costs nothing; losing the
            # brief costs the stage.
            limit = node.get("maxLength")
            if isinstance(limit, int) and len(value) > limit:
                clamped.append(
                    {"path": path, "requested": len(value), "applied": limit}
                )
                return value[:limit].rstrip()
            return value
        # bool is a subclass of int; a flag is not a measurement.
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return value
        return bound(value, node, path)

    walk(candidate, schema, "")
    return clamped


def dedupe_unique_arrays(candidate: dict, schema: dict) -> None:
    """Drop repeats from arrays the schema marks `uniqueItems`, preserving order.

    A grammar can emit an array of enum values but has no memory of which it
    already used, so a repeated entry is as unenforceable as an out-of-range
    number -- and cost a coral reef its entire world.
    """
    resolve = _resolver(schema)

    def walk(value: object, node: dict) -> None:
        node = resolve(node)
        if not node:
            return
        if isinstance(value, dict):
            properties = node.get("properties") or {}
            for key, child in value.items():
                if key in properties:
                    walk(child, properties[key])
            return
        if isinstance(value, list):
            if node.get("uniqueItems"):
                seen: list = []
                for item in value:
                    if item not in seen:
                        seen.append(item)
                if len(seen) != len(value):
                    value[:] = seen
            items = node.get("items")
            if isinstance(items, dict):
                for child in value:
                    walk(child, items)

    walk(candidate, schema)
