"""Agent chain (P2). Current stage: deterministic rule-based S1/S2 —
the same context -> decision -> patch -> validate shape the guided-JSON
LLM agents plug into later. Ambiguity up, determinism down.
"""

from agents.intent import Brief, parse_intent
from agents.spec_builder import build_spec

__all__ = ["Brief", "build_spec", "parse_intent"]
