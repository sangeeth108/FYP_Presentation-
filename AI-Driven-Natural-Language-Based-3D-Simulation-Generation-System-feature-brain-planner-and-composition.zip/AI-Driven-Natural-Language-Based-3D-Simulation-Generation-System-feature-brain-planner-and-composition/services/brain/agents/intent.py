"""S1: prompt -> structured brief (rule-based, deterministic).

This is the honest pre-LLM intent parser: transparent keyword rules over
the v1 allowlists. In full P2 a guided-JSON classifier replaces the rules,
emitting the SAME Brief shape — nothing downstream changes. User-picked
options always beat keyword inference (user preference beats designer
intent in the constraint stack only below playability — here they're the
explicit designer).
"""

from __future__ import annotations

import re
from dataclasses import dataclass

# The registry is the allowlist: agents can only pick presets the engine
# actually implements. Deliberately re-exported for the LLM schema + rules —
# unused *here*, imported from here elsewhere, so the linter must be told.
from knowledge.registries import LIGHTING_PRESETS  # noqa: F401

GENRES = (
    "topdown_survival_escape_3d",
    "arena_combat_3d",
    "collect_explore_3d",
    "dungeon_crawl_3d",
)
CAMERAS = ("third_person", "top_down_3d", "isometric_3d")

_LIGHTING_RULES: list[tuple[str, str]] = [
    (r"\b(moon\w*|night|midnight|dark\w*)\b", "moonlit_night"),
    (r"\b(fog\w*|mist\w*|dusk|twilight|haunt\w*|spooky|eerie)\b", "dusk_fog"),
    (r"\b(cave|mine|crypt|underground|torch\w*|catacomb|dungeon)\b", "cave_torchlit"),
    (r"\b(sunn\w*|cheer\w*|bright|meadow|garden|summer)\b", "sunny_bright"),
]

_GENRE_RULES: list[tuple[str, str]] = [
    (r"\b(dungeon|crawl|cave|catacomb|underground|crypt|mine\w*|delve\w*)\b", "dungeon_crawl_3d"),
    (r"\b(escape|surviv\w*|zombie|village|flee|outbreak)\b", "topdown_survival_escape_3d"),
    (r"\b(collect|explore|treasure|gather|scaveng\w*|find|relic)\b", "collect_explore_3d"),
    (r"\b(arena|combat|fight|battle|duel|boss|guards?)\b", "arena_combat_3d"),
]

_DEFAULT_CAMERA: dict[str, str] = {
    "topdown_survival_escape_3d": "top_down_3d",
    "arena_combat_3d": "third_person",
    "collect_explore_3d": "third_person",
    "dungeon_crawl_3d": "isometric_3d",
}


@dataclass(frozen=True)
class Brief:
    genre: str
    camera: str
    zone_count: int
    verticality_tiers: int
    enemy_count: int
    mood: str
    lighting_preset: str = "overcast_day"


def parse_intent(
    prompt: str,
    genre: str | None = None,
    camera: str | None = None,
) -> Brief:
    """Deterministic brief from the prompt; explicit options always win."""
    text = prompt.lower()

    if genre not in GENRES:
        genre = next(
            (g for pattern, g in _GENRE_RULES if re.search(pattern, text)),
            "collect_explore_3d",
        )
    if camera not in CAMERAS:
        camera = _DEFAULT_CAMERA[genre]

    if re.search(r"\b(tiny|small|short|quick|little)\b", text):
        zone_count = 4
    elif re.search(r"\b(big|large|huge|sprawling|vast|long|massive)\b", text):
        zone_count = 12
    else:
        zone_count = 7

    verticality = 2 if re.search(r"\b(tower|cliff|floors?|levels?|ramparts?|tall)\b", text) else 1
    # The golden game proved tier-crossing works; single tier is the calm default.

    if re.search(r"\b(peaceful|no enemies|calm|cozy|relax\w*)\b", text):
        enemy_count = 0
    elif re.search(r"\b(horde|swarm|many enemies|crowded|army)\b", text):
        enemy_count = 12
    elif re.search(r"\b(few|couple|sparse)\b", text):
        enemy_count = 3
    else:
        enemy_count = 5

    lighting = next(
        (preset for pattern, preset in _LIGHTING_RULES if re.search(pattern, text)),
        "overcast_day",
    )

    mood = prompt.strip()[:60]
    return Brief(
        genre=genre,
        camera=camera,
        zone_count=zone_count,
        verticality_tiers=verticality,
        enemy_count=enemy_count,
        mood=mood,
        lighting_preset=lighting,
    )
