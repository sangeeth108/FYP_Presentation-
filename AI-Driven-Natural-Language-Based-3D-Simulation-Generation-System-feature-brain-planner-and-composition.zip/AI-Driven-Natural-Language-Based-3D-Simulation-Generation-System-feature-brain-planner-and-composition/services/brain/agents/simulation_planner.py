"""Natural-language request to neutral SimulationSpec.

The LLM may decide what belongs in the world, but only schema-bound capability
IDs are accepted. A deterministic planner remains available for offline use and
as a transparent approximation when the configured model is unavailable.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
from copy import deepcopy

from pcg.enclosure import names_an_enclosure
from datetime import UTC, datetime
from functools import lru_cache
from pathlib import Path

import httpx
import jsonschema

from agents.schema_bounds import clamp_to_schema, dedupe_unique_arrays
from pcg.layout_bridge import materialise_layout
from pcg.linear import expand_linear_structures

log = logging.getLogger(__name__)
_REPO = Path(__file__).resolve().parents[3]
_SCHEMA_PATH = _REPO / "contracts" / "simulation_spec.schema.json"


@lru_cache(maxsize=1)
def simulation_schema() -> dict:
    return json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))


# Everyday objects that carry each capability, used by capability_guidance().
# Kept beside the buckets it is filtered through rather than inline, so adding a
# capability means adding one line here and nothing else.
_EXEMPLARS = {
    "openable": "a door, gate, hatch or lid is openable",
    "lockable": "a door or gate that starts shut against the visitor is lockable",
    "sittable": "a bench, chair, stool, pew or sofa is sittable",
    "pickup_carry_drop": (
        "a crate, tool, book, sample or small box is pickup_carry_drop"
    ),
    "vehicle": "a car, cart, tractor, boat or forklift is a vehicle",
    "machine": "a press, pump, conveyor, mixer or generator is a machine",
    "sensor_trigger": (
        "a pressure plate, switch, scanner or light beam is a sensor_trigger"
    ),
    "animal": "a dog, cow, bird or fish is an animal",
    "dialogue": (
        "a guard, guide, shopkeeper, receptionist or passer-by is dialogue, and "
        "every one of them needs a `dialogue` array of what they say"
    ),
}


@lru_cache(maxsize=1)
def capability_guidance() -> str:
    """Tell the planner which capabilities actually have a runtime binding.

    The schema enum says what is EXPRESSIBLE; the registry says what is
    IMPLEMENTED, and they are not the same list. `sittable` was the case that
    proved it: in the enum, taught by this prompt as the bench exemplar, and
    carrying no runtime binding at all, so every prompt with ordinary seating --
    a museum, a library, a waiting room, a park -- failed behaviour compilation
    with RUNTIME_BINDING_INCOMPLETE. It has since been implemented and now
    reports supported, which is exactly why this list is read from the registry
    on every call rather than written down: the facts move.
    """
    from capabilities.registry import capability_index  # noqa: PLC0415

    ready: list[str] = []
    partial: list[str] = []
    missing: list[str] = []
    for cid, entry in sorted(capability_index().items()):
        status = str(entry.get("status") or entry.get("runtime_status") or "")
        if status == "supported":
            ready.append(cid)
        elif status == "partial":
            partial.append(cid)
        else:
            missing.append(cid)

    lines = [
        "Capability runtime status, which is NOT the same as the schema enum. "
        "The enum says what you may write; this says what the engine can "
        "actually build."
    ]
    if ready:
        lines.append(f"Fully supported, prefer these: {', '.join(ready)}.")
    if partial:
        lines.append(f"Partially supported, usable but limited: {', '.join(partial)}.")
    if missing:
        lines.append(
            f"NOT installed, do not use even though the schema accepts them: "
            f"{', '.join(missing)}. An entity that would need one of these "
            f"should simply be a plain object with no capability rather than a "
            f"broken one."
        )
    # Naming a capability is not the same as recognising the object that has
    # one. A farm prompt asking for "a bench under an apple tree" returned a
    # bench with no capabilities at all while sittable sat in the supported list
    # directly above, so the world had seating nobody could sit on.
    #
    # These examples are keyed to the buckets built above rather than written
    # into the sentence, because the last hardcoded example ("a bench is
    # furniture, not a sittable") became false the day sittable gained a
    # binding. A capability that is not installed drops its own examples here.
    lines.append(
        "Wire the place together with `causal_links`: when one entity's capability "
        "ENTERS a state, another entity's capability receives a trigger. A plate "
        "that opens a door, a guard whose warning unlocks the gate, a switch that "
        "starts the pump. Without them every object works alone and changes nothing "
        "about anything else, which is what makes a world feel staged. Only name "
        "entities and capabilities present in this spec."
    )
    installed = set(ready) | set(partial)
    recognised = [
        _EXEMPLARS[cid] for cid in sorted(installed) if cid in _EXEMPLARS
    ]
    if recognised:
        lines.append(
            "Recognising them: "
            + "; ".join(recognised)
            + ". Give an object the capability its real counterpart has -- a "
            "seat nobody can sit on and a door nobody can open are the most "
            "common way one of these worlds disappoints. Leave an entity plain "
            "when none of these fits it."
        )
    return " ".join(lines)


# A `minItems` FLOOR ON ENTITIES WAS TRIED AND DOES NOT WORK. Recorded because the
# measurement in isolation is convincing and the pipeline result is not.
#
# `entities` carried no description at all, so the planner named about eight things and
# stopped -- measured mean 7.6, and one forest lesson came back with three, which the
# visual critic correctly called "a single stump". Worked examples in the description
# moved that to 14 and are KEPT; they cost nothing and they help.
#
# The floor did not survive. In isolation it looked decisive -- same prompt and seed, 3
# entities without it and 22 with, across 22 distinct kinds, so it read as content rather
# than padding. In the pipeline it never once produced a spec:
#
#   floor 22, default window   truncated at 78,394 chars, line 3120
#   floor 22, num_ctx 65536    stopped truncating, TIMED OUT against 420 s
#   floor 14, num_ctx 32768    truncated at line 3244 after 579 s
#
# Every one fell back to `deterministic_fallback_v1`, which loses scatter, generation and
# the model's authorship together -- strictly worse than a smaller honest world. Forced
# to fill an array the model pads with ever more verbose entities rather than more
# things, which is the same runaway the `simulation_id` note above describes.
#
# So density is not bought here. It needs either a faster planner, a much longer budget,
# or entities cheap enough to enumerate -- a change to what an entity COSTS, not to how
# many are demanded.


def ollama_simulation_schema(size_profile: str | None = None) -> dict:
    """Return the canonical schema in Ollama's supported JSON-Schema subset.

    The local Qwen 3.6 grammar adapter supports local references but rejects
    conditional ``allOf`` rules, tuple ``prefixItems``, and string-length
    bounds while constructing its grammar. The returned candidate is always
    checked again against the untouched canonical schema, so this compatibility
    view can never weaken the product contract.
    """
    canonical = deepcopy(simulation_schema())

    # Never make the model generate a field we are about to throw away.
    #
    # `meta`, `request`, `lineage` and `schema_version` are all overwritten from
    # the draft the moment the response lands (see below), so every token spent
    # on them is wasted -- and one of them was worse than wasted.
    # `meta.simulation_id` carries the pattern ^sim_[a-z0-9_]+_[a-f0-9]{8}$,
    # whose [a-z0-9_]+ the grammar will happily let run forever. Measured: the
    # model reached that field on line 4 and emitted 32,700 tokens of
    # "..._twenty_nine_thousand_and_fourteen_twenty_nine_thousand_and_fifteen_"
    # before hitting the token cap, so the JSON was always truncated and the
    # planner ALWAYS fell back to its built-in draft. Raising num_ctx and
    # num_predict did not help; it only changed where the loop was cut off.
    # Dropping these four fields removes the trap and the wasted generation.
    _ASSIGNED_AFTER_GENERATION = ("meta", "request", "lineage", "schema_version")
    for field in _ASSIGNED_AFTER_GENERATION:
        canonical.get("properties", {}).pop(field, None)
    if isinstance(canonical.get("required"), list):
        canonical["required"] = [
            name
            for name in canonical["required"]
            if name not in _ASSIGNED_AFTER_GENERATION
        ]

    # One field the model must not be able to reach.
    #
    # `placement.anchor_m` is absolute world coordinates. It exists so that expanding
    # a `linear_structure` into segments can say where each segment goes -- the solver
    # positions by relation or by seeded search, and neither can express "exactly
    # here". Left in the grammar, a model would start hand-authoring layouts in raw
    # coordinates, which is the arrangement work this system does deterministically
    # downstream and the reason `linear_structures` exists at all. Stripping it here
    # is not a weakening of the contract: the canonical schema keeps the field, and
    # the post-expansion spec is validated against that.
    # Ask for the colour, do not merely permit it.
    #
    # Measured on a real run with the guidance in place: seven entities and ten species,
    # and NOT ONE palette. That is ADR-0009's finding again -- guidance improves the
    # average and never becomes reliable -- and the codebase already has the answer for
    # exactly this shape of failure. `procedural_type` was omitted by every species of a
    # thirteen-species run until it was made REQUIRED; after that it was always there.
    #
    # Required in the GRAMMAR only. The canonical contract keeps `palette_hex` optional,
    # so every spec written before it existed still validates and a repair that carries
    # one forward does not break (ADR-0015 chose optional for that reason and the reason
    # still holds). A guided decoder must emit a required field, which is the whole
    # difference between a field that exists and a field that arrives.
    for definition in ("asset_requirement", "scatter_asset_requirement"):
        node = canonical["$defs"].get(definition) or {}
        if "palette_hex" in (node.get("properties") or {}):
            required = list(node.get("required") or [])
            if "palette_hex" not in required:
                node["required"] = required + ["palette_hex"]

    for machine_authored in ("anchor_m", "anchor_yaw_degrees"):
        canonical["$defs"]["entity"]["properties"]["placement"]["properties"].pop(
            machine_authored, None
        )

    # The same trap, in the ids the model DOES have to invent.
    #
    # `^ent_[a-z0-9_]+$`, `^req_...` and `^spc_...` are all unbounded, so any one
    # of them can swallow the whole generation budget the way simulation_id did.
    # A grammar cannot be told "stop when it reads naturally"; it stops when the
    # repetition is bounded. 48 characters is far longer than any id the planner
    # has produced (`ent_stoop_house_b` is 17) while giving the decoder a wall.
    # Only the grammar view is bounded -- the canonical contract stays as it is,
    # and validation still runs against that, so nothing already stored becomes
    # invalid.
    def bound_patterns(node: object) -> object:
        if isinstance(node, list):
            return [bound_patterns(value) for value in node]
        if not isinstance(node, dict):
            return node
        result = {key: bound_patterns(value) for key, value in node.items()}
        pattern = result.get("pattern")
        if isinstance(pattern, str) and "+" in pattern:
            result["pattern"] = pattern.replace("]+", "]{1,48}")
        return result

    canonical = bound_patterns(canonical)
    if not isinstance(canonical, dict):
        raise TypeError("canonical SimulationSpec schema must be an object")

    def normalize(node: object) -> object:
        if isinstance(node, list):
            return [normalize(value) for value in node]
        if not isinstance(node, dict):
            return node
        result = {
            key: value
            for key, value in node.items()
            if key
            not in {
                "$schema",
                "$id",
                "allOf",
                "if",
                "then",
                "else",
                "minLength",
                "maxLength",
            }
        }
        prefix_items = result.pop("prefixItems", None)
        if isinstance(prefix_items, list) and prefix_items:
            normalized_prefix = [normalize(value) for value in prefix_items]
            result["items"] = normalized_prefix[0]
            result.setdefault("minItems", len(normalized_prefix))
            result.setdefault("maxItems", len(normalized_prefix))
        elif result.get("items") is False:
            result.pop("items")
        return {key: normalize(value) for key, value in result.items()}

    compatible = normalize(canonical)
    if not isinstance(compatible, dict):
        raise TypeError("canonical SimulationSpec schema must be an object")
    return compatible


def validate_simulation_spec(spec: dict) -> None:
    jsonschema.validate(spec, simulation_schema(), format_checker=jsonschema.FormatChecker())


def _slug(text: str) -> str:
    value = re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")
    return value[:48] or "entity"


def _actor_from(prompt: str) -> str:
    match = re.search(
        r"\bas\s+(?:a|an)\s+([a-z][a-z -]{0,40}?)(?=\s+(?:explore|roam|walk|"
        r"drive|operate|inspect|visit|help|survive|escape|collect|travel)\b|[,.;]|$)",
        prompt.lower(),
    )
    return (match.group(1).strip() if match else "visitor")[:40]


def _environment_from(prompt: str) -> tuple[str, str, str]:
    words = prompt.lower()
    choices = (
        ("village", "outdoor", "grass_and_paths"),
        ("town", "outdoor", "streets_and_plazas"),
        ("city", "outdoor", "urban_streets"),
        ("factory", "mixed", "industrial_floor"),
        ("warehouse", "indoor", "industrial_floor"),
        ("forest", "outdoor", "natural_ground"),
        ("farm", "outdoor", "soil_and_grass"),
        ("hospital", "indoor", "building_floor"),
        ("school", "mixed", "campus"),
        ("laboratory", "indoor", "laboratory_floor"),
        ("lab", "indoor", "laboratory_floor"),
        ("museum", "indoor", "building_floor"),
        ("island", "outdoor", "coastal_ground"),
    )
    for semantic, kind, terrain in choices:
        if semantic in words:
            return semantic, kind, terrain
    return "requested_environment", "mixed", "contextual_terrain"


def _entity(
    entity_id: str,
    name: str,
    semantic_type: str,
    role: str,
    *,
    category: str = "prop",
    bbox: tuple[float, float, float] = (1.0, 1.0, 1.0),
    capabilities: list[str] | None = None,
    animated: bool = False,
    zone: str = "main",
    dynamic: bool = False,
    brief: str | None = None,
    preferred_source: str = "either",
    procedural_type: str | None = None,
) -> dict:
    asset = {
        "brief": (brief or f"a production-ready 3D model of {name}")[:500],
        "category": category,
        "requires_animation": animated,
        "preferred_source": preferred_source,
    }
    if procedural_type is not None:
        asset["procedural_type"] = procedural_type
    return {
        "entity_id": f"ent_{_slug(entity_id)}",
        "name": name[:120],
        "semantic_type": semantic_type[:80],
        "role": role[:80],
        "asset": asset,
        "physical": {
            "bbox_m": list(bbox),
            "dynamic": dynamic,
            "mass_kg": 20.0 if dynamic else 0.0,
        },
        "capabilities": capabilities or [],
        "placement": {
            "zone": zone,
            "hard_constraints": ["inside_zone", "non_overlapping", "supported"],
            "soft_constraints": ["natural_spacing", "semantic_context"],
        },
    }


def _deterministic_draft(
    prompt: str,
    simulation_id: str,
    seed: int,
    size_profile: str,
    target_platforms: list[str],
    domain_constraints: dict | None,
) -> dict:
    lower = prompt.lower()
    environment, world_kind, terrain = _environment_from(prompt)
    actor = _actor_from(prompt)
    side = 500 if size_profile == "small" else 1000
    entities: list[dict] = []
    relations: list[dict] = []
    capabilities = {"locomotion", "camera_control"}

    actor_caps = ["locomotion"]
    if actor in _ANIMAL_SPECIES:
        actor_caps.append("animal")
        capabilities.add("animal")
    actor_entity = _entity(
        "controlled_actor",
        actor.title(),
        actor,
        "controlled_agent",
        category="character",
        bbox=(0.8, 1.2, 1.4) if actor == "dog" else (0.7, 1.8, 0.7),
        capabilities=actor_caps,
        animated=True,
        dynamic=True,
        brief=f"an animated, rigged {actor} suitable as the controlled simulation agent",
        zone="settlement" if environment in {"village", "town"} else "main",
    )
    entities.append(actor_entity)
    agents = [
        {
            "entity_id": "ent_controlled_actor",
            "controller": "user",
            "behaviour": {"mode": "direct_control"},
        }
    ]

    if environment in {"village", "town"}:
        building_count = 4 if size_profile == "small" else 8
        for index in range(building_count):
            house_id = f"house_{index + 1}"
            house = _entity(
                house_id,
                f"Village House {index + 1}",
                "house",
                "structure",
                category="structure",
                bbox=(9.0, 6.0, 8.0),
                zone="settlement",
                brief=(
                    "a complete village house shell with a clear front doorway "
                    "opening and no door leaf, suitable for a separate functional door"
                ),
                preferred_source="procedural",
                procedural_type="building_shell",
            )
            entities.append(house)
            door = _entity(
                f"{house_id}_door",
                f"Village House {index + 1} Front Door",
                "hinged_wooden_door",
                "entrance_door",
                category="prop",
                bbox=(1.1, 2.2, 0.14),
                capabilities=["openable"],
                zone="settlement",
                brief=(
                    "a separate wooden village front door leaf with visible hinges, "
                    "no wall and no surrounding building"
                ),
                preferred_source="procedural",
                procedural_type="hinged_door_leaf",
            )
            entities.append(door)
            relations.append(
                {
                    "subject_id": house["entity_id"],
                    "relation": "near",
                    "target_id": "ent_village_square",
                    "hard": False,
                    "distance_m": 35.0,
                }
            )
            relations.extend(
                [
                    {
                        "subject_id": door["entity_id"],
                        "relation": "attached_to",
                        "target_id": house["entity_id"],
                        "hard": True,
                        "local_offset_m": [0.0, -1.9, -4.06],
                        "local_rotation_y_degrees": 0.0,
                    },
                    {
                        "subject_id": door["entity_id"],
                        "relation": "connected_to",
                        "target_id": "ent_village_square",
                        "hard": True,
                    },
                ]
            )
        entities.append(
            _entity(
                "village_square",
                "Village Square",
                "public_square",
                "landmark",
                category="environment",
                bbox=(25.0, 0.5, 25.0),
                zone="settlement",
                brief="a flat durable village-square ground surface",
                preferred_source="procedural",
                procedural_type="semantic_box",
            )
        )
        relations.append(
            {
                "subject_id": actor_entity["entity_id"],
                "relation": "near",
                "target_id": "ent_village_square",
                "hard": False,
                "distance_m": 20.0,
            }
        )
        capabilities.add("openable")
        if any(word in lower for word in ("living", "inhabited", "busy", "active village")):
            for resident_id, species in (("resident_cow", "cow"), ("resident_horse", "horse")):
                resident = _entity(
                    resident_id,
                    f"Village {species.title()}",
                    species,
                    "village_resident",
                    category="character",
                    bbox=(1.2, 1.7, 2.4),
                    capabilities=["locomotion", "animal"],
                    animated=True,
                    dynamic=True,
                    zone="settlement",
                    brief=f"an animated rigged {species} living in a peaceful village",
                )
                entities.append(resident)
                relations.append(
                    {
                        "subject_id": resident["entity_id"],
                        "relation": "near",
                        "target_id": "ent_village_square",
                        "hard": False,
                        "distance_m": 30.0,
                    }
                )
                agents.append(
                    {
                        "entity_id": resident["entity_id"],
                        "controller": "schedule",
                        "behaviour": {
                            "mode": "village_wander",
                            "home_zone": "settlement",
                        },
                    }
                )
    elif environment in {"factory", "warehouse"}:
        entities.extend(
            [
                _entity(
                    "factory_building",
                    "Factory Building",
                    "industrial_building",
                    "structure",
                    category="structure",
                    bbox=(15.0, 10.0, 15.0),
                    capabilities=["openable"],
                    zone="industrial",
                ),
                _entity(
                    "production_machine",
                    "Production Machine",
                    "industrial_machine",
                    "process_equipment",
                    category="machine",
                    bbox=(4.0, 3.0, 5.0),
                    capabilities=["machine", "sensor_trigger"],
                    zone="industrial",
                ),
            ]
        )
        capabilities.update({"openable", "machine", "sensor_trigger"})
    elif environment == "forest":
        for index in range(12 if size_profile == "small" else 24):
            entities.append(
                _entity(
                    f"tree_cluster_{index + 1}",
                    f"Tree Cluster {index + 1}",
                    "tree_cluster",
                    "vegetation",
                    category="environment",
                    bbox=(5.0, 10.0, 5.0),
                    zone="woodland",
                )
            )
        capabilities.add("ecosystem_process")

    if any(word in lower for word in ("car", "vehicle", "truck", "bus", "tractor")):
        entities.append(
            _entity(
                "requested_vehicle",
                "Requested Vehicle",
                "vehicle",
                "transport",
                category="vehicle",
                bbox=(2.2, 1.8, 4.5),
                # No `sittable`: its runtime binding is not installed, so a
                # vehicle declaring it fails behaviour compilation with
                # RUNTIME_BINDING_INCOMPLETE. The fallback draft has to satisfy
                # the same gates as a planned spec, or rules mode publishes
                # worlds the product path would reject.
                capabilities=["vehicle", "openable"],
                animated=True,
                dynamic=True,
            )
        )
        capabilities.update({"vehicle", "openable"})
    if any(word in lower for word in ("talk", "villager", "people", "worker", "guide")):
        entities.append(
            _entity(
                "local_guide",
                "Local Guide",
                "person",
                "social_agent",
                category="character",
                bbox=(0.7, 1.8, 0.7),
                capabilities=["locomotion", "dialogue"],
                animated=True,
                dynamic=True,
            )
        )
        capabilities.add("dialogue")

    requirements = [
        {
            "requirement_id": "req_prompt_fidelity",
            "source_text": prompt,
            "subject": "simulation",
            "predicate": "represents",
            "target": environment,
            "priority": "required",
            "observable": "Rendered environment and entities match the requested scenario",
            "tolerance": None,
            "validator": "visual_semantic",
            "evidence": [],
        },
        {
            "requirement_id": "req_actor_identity",
            "source_text": prompt,
            "subject": "ent_controlled_actor",
            "predicate": "is",
            "target": actor,
            "priority": "required",
            "observable": f"The controlled visible agent is an animated {actor}",
            "tolerance": None,
            "validator": "asset_and_runtime",
            "evidence": [],
        },
        {
            "requirement_id": "req_explorable",
            "source_text": prompt,
            "subject": "ent_controlled_actor",
            "predicate": "can_explore",
            "target": environment,
            "priority": "required",
            "observable": "The controlled agent can navigate required regions without blockage",
            "tolerance": 1.0,
            "validator": "navigation_probe",
            "evidence": [],
        },
    ]
    for entity in entities[1:]:
        requirements.append(
            {
                "requirement_id": f"req_present_{entity['entity_id'][4:]}",
                "source_text": prompt,
                "subject": entity["entity_id"],
                "predicate": "exists",
                "target": entity["semantic_type"],
                "priority": "required",
                "observable": f"{entity['name']} exists with the requested semantic role",
                "tolerance": None,
                "validator": "entity_presence",
                "evidence": [],
            }
        )
        if entity["capabilities"]:
            requirements.append(
                {
                    "requirement_id": f"req_capability_{entity['entity_id'][4:]}",
                    "source_text": prompt,
                    "subject": entity["entity_id"],
                    "predicate": "supports",
                    "target": ",".join(entity["capabilities"]),
                    "priority": "required",
                    "observable": "Required state transitions succeed in the runtime probe",
                    "tolerance": None,
                    "validator": "interaction_probe",
                    "evidence": [],
                }
            )

    return {
        "schema_version": "1.0.0",
        "meta": {
            "simulation_id": simulation_id,
            "title": prompt[:120],
            "seed": seed,
        },
        "request": {
            "prompt": prompt,
            "size_profile": size_profile,
            "target_platforms": target_platforms,
            "domain_constraints": domain_constraints or {},
        },
        "requirements": requirements,
        "environment": {
            "semantic_type": environment,
            "world_kind": world_kind,
            "dimensions_m": {
                "width": side,
                "depth": side,
                "max_height": 80 if size_profile == "small" else 160,
            },
            "terrain": terrain,
            # The draft is a placeholder the model is told to replace, so it
            # declines to guess a surface rather than dressing a fallback world
            # up as a deliberate one.
            "terrain_surface": "unspecified",
            "time_of_day": "night" if "night" in lower else "day",
            "weather": "rain" if "rain" in lower else "clear",
            "zones": [
                {"zone_id": "main", "semantic_type": environment, "connected_to": []},
                {
                    "zone_id": (
                        "settlement"
                        if environment in {"village", "town"}
                        else "industrial"
                        if environment in {"factory", "warehouse"}
                        else "woodland"
                        if environment == "forest"
                        else "activity"
                    ),
                    "semantic_type": "activity_zone",
                    "connected_to": ["main"],
                },
            ],
        },
        "entities": entities,
        "spatial_relations": relations,
        "capabilities": sorted(capabilities),
        "agents": agents,
        "performance": {
            "desktop_target_fps": 60,
            "web_target_fps": 30,
            "desktop_memory_mb": 4096,
            "web_memory_mb": 1536,
        },
        "approximations": [],
        "lineage": {
            "prompt_hash": hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
            "planner": "deterministic_fallback_v1",
            "critic": None,
            "vision_model": None,
            "created_at": datetime.now(UTC).isoformat(),
        },
    }


_DEFAULT_PROCEDURAL_TYPE = "semantic_box"


def _infer_procedural_type(item: dict) -> tuple[str, str]:
    """Guess the form from shape and capability when the planner named none.

    Returns the form and the reason, because a guess that cannot be explained
    should not be made silently.

    This reads PROPORTIONS and CAPABILITIES, never the noun. A table from
    semantic_type to geometry is the closed-vocabulary ceiling this system
    exists to avoid -- it would resolve "painting" and fail "triptych". A shape
    that is thin, upright and rectangular is a panel whatever it is called, and
    a 60 x 15 x 80 m thing is an enclosure whatever it is called.

    The default it replaces was doing real damage: an `exhibition_hall`
    declared 80 x 15 x 60 became a SOLID BOX, so the museum was a cliff the
    visitor stood outside rather than a room. Every downstream measurement
    agreed with itself, which is why nothing caught it.
    """
    physical = item.get("physical") or {}
    bbox = physical.get("bbox_m")
    if not bbox:
        # A scatter species carries `size_m`, not `physical.bbox_m`, so reading only
        # the latter meant every inferred scatter form fell through to a box on the
        # "no measurable bounding box" branch -- a 7 m pine included. The shape is
        # right there under a different key.
        size = item.get("size_m")
        if isinstance(size, dict):
            bbox = [size.get("width"), size.get("height"), size.get("depth")]
        elif isinstance(size, list):
            bbox = list(size[:3])
    capabilities = set(item.get("capabilities") or ())
    if "openable" in capabilities:
        return "hinged_door_leaf", "declares the openable capability"
    if not isinstance(bbox, list) or len(bbox) < 3:
        return _DEFAULT_PROCEDURAL_TYPE, "has no measurable bounding box"
    try:
        width, height, depth = (float(bbox[0]), float(bbox[1]), float(bbox[2]))
    except (TypeError, ValueError):
        return _DEFAULT_PROCEDURAL_TYPE, "has a non-numeric bounding box"

    footprint = min(width, depth)
    span = max(width, depth)
    if height >= 2.2 and footprint >= 2.0:
        # Can a person stand up inside it and take a step? That is what makes a
        # thing a place rather than an object, and it is the test this uses.
        #
        # The threshold was six metres in the narrowest horizontal axis, which is
        # SUFFICIENT for a building and not NECESSARY: a 4 x 3 x 5 m stone cottage
        # missed it by two metres and was built as a solid box. Seen in a real
        # render, the "cottage" was a featureless grey cube in a field, and the
        # only gate that objected was the advisory visual critic -- every
        # measurement downstream agreed with itself, because a box is a perfectly
        # valid box.
        #
        # 2.2 m clears a standing person and 2.0 m of floor is a step in any
        # direction. A crate, a hay bale or a wardrobe fails one or both.
        return "building_shell", f"encloses space at {width:g}x{height:g}x{depth:g} m"
    if height >= 2.5 * span and span > 0.0:
        return "slender_post", f"stands {height:g} m over a {span:g} m footprint"
    thin = min(width, depth)
    if thin <= 0.12 * max(width, height) and height >= thin * 3.0:
        return "flat_panel", f"is an upright plate {thin:g} m thick"
    return _DEFAULT_PROCEDURAL_TYPE, "matches no form by its proportions"


def _parsed_brief(brief: str | None) -> dict | None:
    """The brief as an object, or None. It arrives as compact JSON from `extract`."""
    if not brief:
        return None
    try:
        parsed = json.loads(brief)
    except (TypeError, ValueError):
        return None
    return parsed if isinstance(parsed, dict) else None


def _route_through_generation(candidate: dict) -> None:
    """Send every asset down the full resolution ladder.

    `preferred_source: "procedural"` skips the cache, the curated library, the mesh
    generator and the texture system outright. Measured across 176 specs, the planner
    chose it for 50% of entities and 79% of scatter species -- so half the objects in
    every world were primitives, and 228 of them were literal boxes, while a working
    generator sat idle in the same job.

    Deciding that generation is not worth attempting requires knowing whether it would
    have succeeded, which is knowable only by attempting it. The ladder already ends in
    procedural geometry, so nothing is lost by asking: a 25 m dry-stone wall that no
    generator can produce still arrives as a procedural wall, just by the route that
    checks first.

    The cost is real and worth stating: a cold cache now attempts generation for assets
    that previously skipped straight to a primitive, which makes a first run slower. The
    cache is keyed by brief, so the cost falls away on repeats.

    Not a schema change. `procedural` remains valid in the contract -- the resolver uses
    it as its own final tier and preserved specs must keep validating. Only the
    planner's choice is overridden, and each override is disclosed because the planner
    asked for something specific and did not get it.
    """
    for section in ("entities", "scatter"):
        for item in candidate.get(section) or ():
            asset = item.get("asset") if isinstance(item, dict) else None
            if not isinstance(asset, dict):
                continue
            if asset.get("preferred_source") != "procedural":
                continue
            asset["preferred_source"] = "either"
            candidate.setdefault("approximations", []).append(
                {
                    "requirement_id": str(
                        item.get("entity_id") or item.get("species_id") or "unknown"
                    ),
                    "reason": (
                        "asked to be built from primitives, which skips the model "
                        "cache, the owned library and mesh generation; routed through "
                        "the full ladder instead, which still ends in procedural "
                        "geometry if nothing better resolves"
                    )[:300],
                    "user_visible": False,
                }
            )


def _normalise_procedural_assets(candidate: dict) -> None:
    """Fill `procedural_type` whenever the planner asked for a procedural asset.

    The canonical schema says "if preferred_source is procedural then
    procedural_type is required", but that is a conditional (`allOf`/`if`/`then`)
    and ollama_simulation_schema() must strip conditionals for the grammar
    adapter. So the planner cannot see the rule and routinely omits the field —
    which rejected the WHOLE spec and dropped the run to the deterministic
    fallback (a generic empty world). Scatter made this bite constantly, because
    trees and rocks are exactly what a planner marks procedural.

    Supplying the generic primitive is a normalisation, not a weakening: the
    untouched canonical schema still validates the result immediately afterwards.
    """
    for section in ("entities", "scatter"):
        for item in candidate.get(section) or ():
            asset = item.get("asset") if isinstance(item, dict) else None
            if not isinstance(asset, dict):
                continue
            # Filled regardless of source now that everything routes through the
            # full ladder. The form is no longer the PLAN for an object -- it is the
            # fallback the resolver lands on if the cache, the library and generation
            # all miss, so every asset needs one even when it expects a real mesh.
            # Leaving it unset used to be safe because only procedural assets could
            # reach the procedural builder; now any of them can.
            if not asset.get("procedural_type"):
                inferred, reason = _infer_procedural_type(item)
                asset["procedural_type"] = inferred
                # Disclosed, because the planner did not choose this. The field
                # used to be filled with `semantic_box` and nothing recorded
                # that a default had been substituted for a decision, so a world
                # of boxes looked like a world someone had designed as boxes.
                candidate.setdefault("approximations", []).append(
                    {
                        "requirement_id": str(
                            item.get("entity_id") or item.get("species_id") or "unknown"
                        ),
                        "reason": (
                            f"form not specified; built as {inferred} because it "
                            f"{reason}"
                        )[:300],
                        "user_visible": inferred == _DEFAULT_PROCEDURAL_TYPE,
                    }
                )


def _capabilities_requiring_a_rig() -> frozenset[str]:
    """Which capabilities can only be satisfied by a rigged, animated asset.

    Read from the packs rather than listed here, so a capability added later is
    classified by its own manifest instead of by a list somebody has to remember
    to update.
    """
    from capabilities.registry import capability_index  # noqa: PLC0415

    qualifying = set()
    for capability_id, entry in capability_index().items():
        qualification = entry.get("qualification") or {}
        if qualification.get("kind") == "asset_animation":
            qualifying.add(capability_id)
    return frozenset(qualifying)


def _normalise_animation_requirement(candidate: dict) -> None:
    """Decide `requires_animation` from the capabilities, not from free text.

    The flag is not a stylistic wish. It means "this entity must be matched to a
    rigged asset with locomotion-compatible clips", and `asset_animation_compatibility`
    is a mandatory gate. A farm-yard run died on it because the planner marked a
    tractor animated: no rigged tractor exists in any kit, so the run could not
    pass a gate it had been given no way to satisfy, and every later gate came
    back NOT_RUN behind it.

    Which capabilities actually need a rig is already declared in the packs, so
    the flag is derived from them. That corrects the flag in both directions --
    an entity carrying `animal` with the flag omitted would otherwise have
    skipped the check entirely and shipped an unrigged creature.
    """
    needs_rig = _capabilities_requiring_a_rig()
    for item in candidate.get("entities") or ():
        asset = item.get("asset") if isinstance(item, dict) else None
        if not isinstance(asset, dict):
            continue
        capabilities = set(item.get("capabilities") or ())
        derived = bool(capabilities & needs_rig)
        if bool(asset.get("requires_animation")) == derived:
            continue
        asset["requires_animation"] = derived
        # Disclosed either way. Clearing the flag changes what the entity will
        # be built from, and setting it changes which gate it must pass, so
        # neither should happen invisibly.
        reason = (
            f"animation requirement derived from capabilities "
            f"{sorted(capabilities) or 'none'}: "
            + (
                "a rigged animated asset is required"
                if derived
                else "no capability here needs a skeleton, so a rigged asset is not required"
            )
        )
        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": str(item.get("entity_id") or "unknown"),
                "reason": reason[:300],
                "user_visible": False,
            }
        )


# How many instances of a species survive when the planner has said its position
# carries meaning. Small on purpose: the point is to read as "some of these are here"
# without pretending the sampler knew where to put them.
_POSITIONED_CEILING = 6


def _bound_scatter_density(candidate: dict) -> None:
    """Keep the model's choice of species; bound what the engine has to draw.

    This is deliberately a "how" decision and not a "what" one. Which plants belong
    in a meadow is the planner's judgement and stays untouched. How many instances
    of a five-centimetre object a WebGL2 frame can afford is rendering economics,
    which is ours.

    Measured on a real run: 0.1 m grass blades and 0.05 m pine needles were both
    requested at the contract maximum of 5000 per 100 m2, giving 11,590 near-
    invisible meshes at sixteen per square metre -- a speckled carpet that buried
    the world's actual content, while the 7 m pines the prompt asked for were
    requested at 1.6 and only one landed.

    So only the DENSITY of small instances is capped, and only for species under a
    quarter of a metre, where hundreds per square metre cannot read as anything but
    noise. Nothing is dropped: a species the planner wanted still appears, at a
    count a viewer can resolve. Larger species are left entirely alone -- a boulder
    or a tree at whatever density was asked for.

    Disclosed as user-visible, because a meadow with fewer blades of grass than
    requested is a change to what somebody asked for.
    """
    small_extent_m = 0.25
    visible_ceiling = 60.0
    for species in candidate.get("scatter") or ():
        if not isinstance(species, dict):
            continue
        size = species.get("size_m")
        if isinstance(size, dict):
            extents = [
                float(size.get(key) or 0.0) for key in ("width", "height", "depth")
            ]
        elif isinstance(size, list):
            extents = [float(value or 0.0) for value in size[:3]]
        else:
            continue
        if not extents or max(extents) > small_extent_m:
            continue
        try:
            requested = float(species.get("density_per_100m2") or 0.0)
        except (TypeError, ValueError):
            continue
        if requested <= visible_ceiling:
            continue
        species["density_per_100m2"] = visible_ceiling
        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": str(species.get("species_id") or "unknown"),
                "reason": (
                    f"{max(extents):g} m across is ground detail rather than an "
                    f"object; density reduced from {requested:g} to "
                    f"{visible_ceiling:g} per 100 m2 so it reads as texture instead "
                    f"of a carpet of separate meshes"
                )[:300],
                "user_visible": True,
            }
        )


def _bound_positioned_scatter(candidate: dict) -> None:
    """Thin out species the planner says do not belong just anywhere.

    Measured on the village diagnostic: 328 scatter instances in a 90 x 93 m world,
    against a whole-world ceiling of 12,000 that `pcg/scatter.py` already enforces --
    so the budget was never what made that world wrong. What made it wrong was the
    largest species by count being a street lamp: 168 of them at one every 50 square
    metres, sprinkled with no relation to any path, next to 28 trees.

    Scatter places by seeded rejection sampling. For a fern that is correct and for a
    lamp post it is meaningless, and the contract had no way to tell the two apart, so
    `placement_is_incidental` now asks. Only an explicit `false` acts here: absent means
    the planner did not answer, and inferring the answer from the species name would be
    exactly the noun table `_infer_procedural_type` warns against.

    The consequence is a count, not a deletion. A handful of lamps distributed badly
    reads as "there are lamps here"; 168 reads as a lamp farm, which is a worse lie than
    sparseness. So the species survives at `_POSITIONED_CEILING` instances and the
    shortfall is disclosed as user-visible, because somebody asked for a lit street and
    is getting fewer lamps than they asked for.

    This is the honest interim answer, and it is worth being clear that it IS interim.
    The real answer is `routes[]` with frontage, where a lamp is spaced along a street
    because that is what the street is for. Until that exists, a system that cannot place
    a thing properly should place few of it and say so.
    """
    for species in candidate.get("scatter") or ():
        if not isinstance(species, dict):
            continue
        if species.get("placement_is_incidental") is not False:
            continue
        try:
            existing = int(species.get("max_instances") or 0)
        except (TypeError, ValueError):
            existing = 0
        ceiling = (
            min(existing, _POSITIONED_CEILING) if existing else _POSITIONED_CEILING
        )
        if existing and existing <= _POSITIONED_CEILING:
            continue
        species["max_instances"] = ceiling
        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": str(species.get("species_id") or "unknown"),
                "reason": (
                    "this belongs somewhere specific, and the scatter sampler can "
                    "only spread instances at random; kept to "
                    f"{ceiling} so it reads as a few of them rather than a field of "
                    "them placed nowhere in particular"
                )[:300],
                "user_visible": True,
            }
        )


def _verbatim_span(prompt: str, *candidates: str) -> str | None:
    """The longest candidate that genuinely occurs in the prompt, as the prompt spells it.

    Matched case-insensitively but returned by SLICING THE ORIGINAL, so the stored
    source_text is verbatim including capitalisation -- the traceability check is a
    substring test against the prompt and a lower-cased copy would fail it.
    """
    haystack = prompt.lower()
    best: str | None = None
    for candidate in candidates:
        text = (candidate or "").strip()
        if len(text) < 3:
            continue
        index = haystack.find(text.lower())
        if index == -1:
            continue
        actual = prompt[index : index + len(text)]
        if best is None or len(actual) > len(best):
            best = actual
    return best


# The general word a specific thing is an instance OF, and the words a prompt is likely
# to use for it. Only categories the spec can already recognise, so this adds no new
# taxonomy: creatures come from `_is_creature`, the rest from the head noun.
_CATEGORY_WORDS: tuple[tuple[frozenset[str], tuple[str, ...]], ...] = (
    (
        frozenset({"tree", "sapling", "shrub", "bush", "fern", "flower", "grass",
                   "plant", "moss", "vine", "hedge", "crop"}),
        ("vegetation", "plants", "plant", "foliage", "greenery", "flora"),
    ),
    (
        frozenset({"house", "cottage", "hut", "cabin", "barn", "shed", "tower",
                   "warehouse", "building", "dwelling", "stall", "workshop"}),
        ("buildings", "building", "houses", "structures", "structure"),
    ),
    (
        frozenset({"man", "woman", "person", "villager", "visitor", "student",
                   "gardener", "farmer", "worker", "mechanic", "guard", "vendor",
                   "child", "adult"}),
        ("people", "person", "villagers", "visitors", "figures", "inhabitants"),
    ),
    (
        frozenset({"cart", "wagon", "forklift", "truck", "car", "van", "boat",
                   "bicycle", "vehicle"}),
        ("vehicles", "vehicle", "machinery", "equipment"),
    ),
    (
        frozenset({"rock", "stone", "boulder", "log", "branch", "leaf", "litter",
                   "debris", "pebble"}),
        ("debris", "ground", "scenery", "detail"),
    ),
)


def _category_words_for(item: dict) -> tuple[str, ...]:
    """The general words this specific thing is an instance of.

    The single largest cause of failed publication in this system's whole history.
    Measured across every stored run:

        requirement_traceability     96 failures, second only to the vision critic
          REQUIREMENT_SOURCE_NOT_TRACEABLE      96
          ENTITY_PRESENCE_REQUIREMENT_MISSING   88

    A requirement's `source_text` must appear VERBATIM in the prompt, which is what stops
    the planner inventing content nobody asked for. But the planner's job is to ELABORATE:
    given "a student watches animals react to changing weather" it authored
    `ent_white_tailed_deer_01`, `ent_cardinal_01`, `ent_blue_jay_01` and
    `ent_white_footed_mouse_01` -- and not one of "white tailed deer", "cardinal" or
    "blue jay" occurs in the prompt, so none could be sourced and the run could not
    publish. Four correct, well-chosen animals, refused for being specific.

    A blue jay IS one of the animals the prompt asked for, and "animals" is a verbatim
    span of it. That is a real provenance chain, not a loophole: the category word must
    still occur in the prompt, so a barbecue nobody mentioned still has nothing to point
    at. What changes is that "animals" can answer for a jay.

    Returned last and short, and `_verbatim_span` prefers the LONGEST match, so a prompt
    that does name the deer still sources the deer.
    """
    words = str(item.get("semantic_type") or "").replace("-", "_").split("_")
    head = words[-1].strip().lower() if words else ""
    out: list[str] = []
    if _is_creature(item):
        out.extend(("animals", "animal", "wildlife", "creatures", "creature"))
    for heads, generals in _CATEGORY_WORDS:
        if head in heads:
            out.extend(generals)
    return tuple(out)


def _nouns_for(item: dict) -> tuple[str, ...]:
    """The words a spec object might be findable by, longest first."""
    semantic = str(item.get("semantic_type") or "").replace("_", " ").strip()
    name = str(item.get("name") or "").strip()
    identifier = str(item.get("entity_id") or "")
    stem = identifier[4:].replace("_", " ").strip() if identifier.startswith("ent_") else ""
    # The head noun too: "wooden kneading table" is often written as "kneading table".
    tails = [" ".join(semantic.split()[-2:]), " ".join(semantic.split()[-1:])]
    # ...and the general word it is an instance of, last: a specific match is always
    # preferred because `_verbatim_span` returns the LONGEST candidate present.
    return tuple(
        value
        for value in (semantic, name, stem, *tails, *_category_words_for(item))
        if value
    )


# Creatures, as the head noun of a semantic type. Everything the curated animal library
# can actually render, plus the common English animals a prompt is likely to name. The
# head noun decides, for the reason established in the curated matcher: English puts the
# thing last, so `village_dog` is a dog and `dog_kennel` is not.
_ANIMAL_SPECIES = frozenset(
    {
        # Livestock, pets and the library's own animals.
        "alpaca", "animal", "bear", "boar", "bull", "calf", "cat", "cattle",
        "chicken", "cow", "creature", "deer", "dog", "donkey", "fish",
        "fox", "goat", "goose", "hare", "hen", "horse", "hound", "husky", "kitten",
        "lamb", "llama", "mouse", "pig", "pony", "puppy", "rabbit", "rat",
        "sheep", "squirrel", "stag", "wolf",
        # Birds by name, not only "bird". Measured on a forest prompt: `ent_cardinal_01`
        # and `ent_blue_jay_01` were not recognised as creatures, so neither could be
        # sourced from the prompt's own word "animals" and the run could not publish.
        # A planner asked for woodland fauna names woodland fauna.
        "bird", "jay", "cardinal", "crow", "raven", "owl", "duck", "sparrow", "robin",
        "finch", "wren", "thrush", "magpie", "starling", "swallow", "heron", "hawk",
        "eagle", "falcon", "gull", "swan", "pigeon", "dove", "woodpecker",
        # Small woodland mammals and the rest of a temperate ecosystem.
        "chipmunk", "vole", "shrew", "badger", "otter", "beaver", "raccoon", "hedgehog",
        "weasel", "stoat", "marten", "lynx", "elk", "moose", "bison", "doe", "fawn",
        "frog", "toad", "newt", "lizard", "snake", "turtle", "tortoise",
        "butterfly", "moth", "bee", "beetle", "ant", "spider", "snail", "worm",
        "insect", "fauna", "wildlife",
    }
)


def _is_creature(entity: dict) -> bool:
    """Whether this entity is an animal, judged on the head noun of its type."""
    words = str(entity.get("semantic_type") or "").replace("-", "_").split("_")
    return bool(words) and words[-1].strip().lower() in _ANIMAL_SPECIES


# Which entities may consume a capability that carries a `qualification`. Only those
# capabilities demand a consumer, and only `animal` and `locomotion` carry one, so this
# covers the whole class the registry can reject rather than guessing at the rest.
_QUALIFIED_CONSUMERS = {
    "animal": _is_creature,
    "locomotion": lambda entity: entity.get("role") == "controlled_agent",
}


def _fit_declared_dimensions(candidate: dict) -> None:
    """Grow the declared world extent until it can hold the declared contents.

    Only ever grows. A small honest declaration is the contract's stated intent -- "a
    museum gallery is 8 m across and a hospital corridor 4 m" -- so a world that already
    fits its contents is left exactly as it is.

    The sizing itself belongs to `pcg.semantic`, which zone geometry and the world
    dimensions already use; asking it here is what makes the declaration agree with them
    instead of being a third opinion. Imported lazily to keep the planner free of a
    module-level dependency on the PCG layer.
    """
    environment = candidate.get("environment")
    if not isinstance(environment, dict):
        return
    declared = environment.get("dimensions_m")
    if not isinstance(declared, dict):
        return
    try:
        from pcg.semantic import content_scaled_dimensions

        width, depth, _ = content_scaled_dimensions(candidate)
    except Exception:  # noqa: BLE001 - a sizing hiccup must not lose the whole spec
        log.warning("could not right-size the declared world extent", exc_info=True)
        return

    for axis, needed in (("width", width), ("depth", depth)):
        # Rounded so the spec hash stays stable: an iterative growth loop would
        # otherwise differ in the last decimal place between runs.
        grown = round(float(needed), 3)
        current = float(declared.get(axis) or 0.0)
        if grown <= current:
            continue
        declared[axis] = grown
        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": f"environment.dimensions_m.{axis}",
                "reason": (
                    f"declared {current:g} m, which cannot hold the contents declared "
                    f"inside it; grown to {grown:g} m so the ground covers the world"
                )[:300],
                "user_visible": False,
            }
        )


def _a_supports_requirement_names_something_that_can(candidate: dict) -> None:
    """A requirement may only ask an entity to support what it could possibly do.

    Measured on the frozen benchmark, `sim_farmyard`:

        requirement: ent_farmhouse  supports  'locomotion'

    A farmhouse that walks. `behaviors.compiler` builds no graph for it -- correctly, a
    building has no locomotion template -- so `requirement_traceability` raised
    REQUIRED_BEHAVIOR_GRAPH_MISSING and the prompt failed. The gate was right and the
    requirement was nonsense.

    `_QUALIFIED_CONSUMERS` already holds who may perform each qualified capability, and
    `_reconcile_capabilities` already uses it to withdraw a capability nothing can
    perform. The same knowledge simply was not applied to REQUIREMENTS, so the spec could
    demand of one entity what it had just refused to declare of the world.

    Redirected before dropped, in that order: a world with a dog and a requirement that
    the farmhouse walks almost certainly meant the dog, and moving the subject keeps the
    user's intent. Only when nothing in the world qualifies is the requirement withdrawn,
    and then it is recorded as an approximation rather than deleted quietly.
    """
    requirements = candidate.get("requirements")
    if not isinstance(requirements, list):
        return
    entities = [e for e in candidate.get("entities") or [] if isinstance(e, dict)]
    by_id = {str(e.get("entity_id") or ""): e for e in entities}

    kept: list[dict] = []
    for requirement in requirements:
        if not isinstance(requirement, dict) or requirement.get("predicate") != "supports":
            kept.append(requirement)
            continue
        subject = str(requirement.get("subject") or "")
        entity = by_id.get(subject)
        if entity is None:
            kept.append(requirement)  # unknown subject is a different gate's business
            continue

        wanted = [
            part.strip()
            for part in str(requirement.get("target") or "").split(",")
            if part.strip()
        ]
        impossible = [
            capability
            for capability in wanted
            if (eligible := _QUALIFIED_CONSUMERS.get(capability)) is not None
            and not eligible(entity)
        ]
        if not impossible:
            kept.append(requirement)
            continue

        # Somebody in this world may be able to do it.
        candidates_for = {
            capability: [
                other
                for other in entities
                if _QUALIFIED_CONSUMERS[capability](other)
            ]
            for capability in impossible
        }
        moved_to = next(
            (
                others[0]["entity_id"]
                for capability, others in candidates_for.items()
                if others
            ),
            None,
        )
        if moved_to is not None:
            candidate.setdefault("approximations", []).append(
                {
                    "requirement_id": str(requirement.get("requirement_id") or ""),
                    "reason": (
                        f"{subject!r} cannot support {', '.join(impossible)}, so the "
                        f"requirement was moved to {moved_to!r}, which can"
                    )[:300],
                    "user_visible": False,
                }
            )
            requirement = {**requirement, "subject": moved_to}
            kept.append(requirement)
            continue

        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": str(requirement.get("requirement_id") or ""),
                "reason": (
                    f"{subject!r} cannot support {', '.join(impossible)} and nothing in "
                    "this world can, so the requirement was withdrawn rather than left "
                    "for a validator to reject"
                )[:300],
                "user_visible": False,
            }
        )

    candidate["requirements"] = kept


def _reconcile_capabilities(candidate: dict) -> None:
    """Give every declared capability a consumer, or stop declaring it.

    The top-level list says what the world does; each entity's list says which thing
    does it. The planner writes both and they drift, and a capability named in the first
    but absent from the second fails `capability_resolution` and `behavior_compilation`
    together -- two mandatory gates, so nothing publishes.

    Attaching is preferred over dropping because the declaration is usually right and
    the omission is the slip: a dog really is an animal, and binding `animal` to it gains
    the idle and eating clips its mesh already carries. Dropping is the fallback for a
    capability nothing in the world could possibly perform, which is a claim the spec
    should not be making.

    Runs after entity reconciliation so it sees the final entity list -- an `animal`
    whose only creature was just dropped has to be dropped too.
    """
    declared = candidate.get("capabilities")
    if not isinstance(declared, list):
        return
    entities = [e for e in candidate.get("entities") or [] if isinstance(e, dict)]

    kept: list[str] = []
    for capability_id in declared:
        eligible = _QUALIFIED_CONSUMERS.get(str(capability_id))
        if eligible is None:
            # No qualification, so the registry never asks who consumes it: an ambient
            # capability like `time_weather` belongs to the world, not to an entity.
            kept.append(capability_id)
            continue
        if any(capability_id in (e.get("capabilities") or []) for e in entities):
            kept.append(capability_id)
            continue

        consumers = [e for e in entities if eligible(e)]
        if not consumers:
            candidate.setdefault("approximations", []).append(
                {
                    "requirement_id": f"capability:{capability_id}",
                    "reason": (
                        f"{capability_id} was declared but nothing in this world can "
                        "perform it, so the declaration was withdrawn rather than left "
                        "for a validator to reject"
                    )[:300],
                    "user_visible": False,
                }
            )
            continue

        # Attach to every eligible entity, not just the first: a world holding a dog and
        # a cow wants both animated, and the qualification is checked per entity anyway.
        for entity in consumers:
            entity.setdefault("capabilities", [])
            if capability_id not in entity["capabilities"]:
                entity["capabilities"].append(capability_id)
        kept.append(capability_id)

    candidate["capabilities"] = kept


def _reconcile_entities_and_requirements(candidate: dict) -> None:
    """Close the gap between what the spec contains and what it claims to require.

    See the module note on `_verbatim_span`: the prompt is the arbiter, so neither
    direction can manufacture something the prompt does not mention.
    """
    prompt = str((candidate.get("request") or {}).get("prompt") or "")
    if not prompt:
        return
    entities = candidate.get("entities") or []
    requirements = candidate.setdefault("requirements", [])

    known = {str(entity.get("entity_id")) for entity in entities}
    known |= {
        str(species.get("species_id")) for species in (candidate.get("scatter") or ())
    }
    known.add("simulation")

    # --- entities nothing requires -----------------------------------------
    covered = {
        str(item.get("subject"))
        for item in requirements
        if item.get("predicate") == "exists"
    }
    grouped = {
        str(relation.get("subject_id")): str(relation.get("target_id"))
        for relation in (candidate.get("spatial_relations") or ())
        if relation.get("relation") == "part_of"
    }
    for entity in entities:
        entity_id = str(entity.get("entity_id") or "")
        if not entity_id or entity_id in covered:
            continue
        # A part of something already covered needs no record of its own.
        cursor, seen = grouped.get(entity_id), set()
        while cursor and cursor not in seen:
            if cursor in covered:
                break
            seen.add(cursor)
            cursor = grouped.get(cursor)
        else:
            cursor = None
        if cursor:
            continue

        span = _verbatim_span(prompt, *_nouns_for(entity))
        if span is None:
            continue  # invented: the gate should and will still object
        semantic = str(entity.get("semantic_type") or "thing").replace("_", " ")
        requirements.append(
            {
                "requirement_id": f"req_{_slug(entity_id)}"[:64],
                "source_text": span[:500],
                "subject": entity_id,
                "predicate": "exists",
                "target": semantic[:160],
                "priority": "required",
                "observable": f"A {semantic} is present in the simulation."[:300],
                "validator": "asset_and_runtime",
            }
        )
        covered.add(entity_id)
        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": entity_id,
                "reason": (
                    f"this was built but nothing required it; the prompt says "
                    f"{span!r}, so the missing requirement was written from that"
                )[:300],
                "user_visible": False,
            }
        )

    # --- requirements about nothing ----------------------------------------
    kept: list[dict] = []
    for item in requirements:
        subject = str(item.get("subject") or "")
        if subject in known:
            kept.append(item)
            continue
        if _verbatim_span(prompt, subject.replace("_", " ").removeprefix("ent ")):
            # The prompt asked for it and the planner promised it, so the world is
            # genuinely incomplete. Left to fail rather than quietly deleted.
            kept.append(item)
            continue
        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": str(item.get("requirement_id") or "unknown"),
                "reason": (
                    "this required something the spec does not contain and the prompt "
                    "never mentions, so it was dropped"
                )[:300],
                "user_visible": False,
            }
        )
    candidate["requirements"] = kept


# Ground that is paved. A world whose BASE surface is one of these has no soil
# anywhere, so a village becomes an industrial slab with cottages on it.
_PAVED_SURFACES = frozenset({"concrete", "stone", "metal", "wood"})


# Ground families that are BARE -- earth with nothing growing on it.
_BARE_GROUND = frozenset({"soil", "sand", "gravel", "dirt"})

# Words that make a scatter species vegetation rather than debris or furniture.
_VEGETATION_WORDS = (
    "grass", "bush", "shrub", "hedge", "tree", "fern", "flower", "plant",
    "weed", "moss", "clover", "reed", "crop", "foliage",
)


def _set_style_anchor(candidate: dict) -> None:
    """Give every generated asset in this world one art direction.

    Measured before this existed: `style_anchor` was absent from all 30 stored
    simulation specs, so each asset's image prompt was its own brief alone. The mechanism
    was already complete on both sides -- `agents/style.py` derives the anchor and
    `backends_gpu` prepends it to every SDXL prompt -- and only the simulation planner
    never wrote the field. A cottage, a cart and a tree therefore arrived in three
    different styles, which no amount of placement or lighting work can make cohere.

    MACHINE-AUTHORED. Written here from the settled environment rather than asked of the
    planner: it is a consequence of the world, not a decision about it, and a model
    inventing its own anchor per run would defeat the purpose of sharing one.
    """
    meta = candidate.get("meta")
    if not isinstance(meta, dict):
        return
    from agents.style import derive_simulation_style_anchor

    anchor = derive_simulation_style_anchor(candidate.get("environment"))
    if anchor:
        meta["style_anchor"] = anchor


def _centre_authored_layout(candidate: dict) -> None:
    """Move authored layout coordinates into the world's own frame.

    The planner draws a plan the way a person sketches one -- from a corner, with the
    first wall at zero and everything positive. The world is CENTRED on the origin. No
    step translated between the two, so authored coordinates were used verbatim as world
    coordinates and everything past the halfway point fell outside the world.

    Measured on a warehouse prompt: a 40x60 m building authored as (0,0)-(40,60) in a
    world spanning z -51.3 to +51.3. Its south wall at z=0 landed on the world's centre
    line and placed; its north wall at z=60 was outside and could not. Seven segments went
    unplaced, `spec_count 28` against `world_count 21`, and four mandatory gates failed.
    The same mistake was in the village -- (0,0)-(15,12) inside a 12x15 m world -- and hurt
    less only because the numbers were small.

    TRANSLATED, never scaled: the planner's distances are what it means, and rescaling a
    building to fit would silently change the thing that was asked for. Recentring is
    exactly the frame correction and nothing else.

    Applied only when the authored cloud is entirely non-negative, which is what "drawn
    from a corner" looks like. A layout that already uses negative coordinates is already
    in the world's frame and is left alone.
    """
    axes: list[tuple[list, int, int]] = []
    for run in candidate.get("linear_structures") or ():
        for key in ("from_m", "to_m"):
            pair = run.get(key)
            if isinstance(pair, list) and len(pair) >= 2:
                axes.append((pair, 0, 1))
    for route in candidate.get("routes") or ():
        points = route.get("points_m")
        if isinstance(points, list):
            for index in range(0, len(points) - 1, 2):
                axes.append((points, index, index + 1))
    for region in candidate.get("regions") or ():
        polygon = region.get("polygon_m")
        if isinstance(polygon, list):
            for index in range(0, len(polygon) - 1, 2):
                axes.append((polygon, index, index + 1))
    if not axes:
        return

    xs = [float(seq[i]) for seq, i, _ in axes]
    zs = [float(seq[j]) for seq, _, j in axes]
    shift_x = (min(xs) + max(xs)) / 2.0
    shift_z = (min(zs) + max(zs)) / 2.0

    # WHERE THE LAYOUT SITS, not what sign its numbers have.
    #
    # The first version aborted whenever any coordinate was negative, on the theory that
    # a signed layout must already be in the world's frame. Measured on a warehouse: its
    # walls ran (0,0)-(40,60) and its striping route ran (-10,-15)-(50,75) -- the same
    # corner-drawn frame with a margin around the building -- and that one negative
    # margin cancelled the correction for everything, leaving the walls exactly as
    # unplaced as before.
    #
    # A layout belongs in the middle of its world. The question is therefore how far its
    # CENTRE is from the origin, which is the same question whichever side of zero the
    # numbers fall on. A metre of slack keeps a layout already centred untouched.
    if abs(shift_x) < 1.0 and abs(shift_z) < 1.0:
        return
    for seq, i, j in axes:
        seq[i] = round(float(seq[i]) - shift_x, 4)
        seq[j] = round(float(seq[j]) - shift_z, 4)
    candidate.setdefault("approximations", []).append(
        {
            "requirement_id": "layout.frame",
            "reason": (
                f"the layout was drawn from a corner; it was moved {shift_x:.1f} m and "
                f"{shift_z:.1f} m so it sits in the middle of the world rather than "
                "running off one edge"
            )[:300],
            "user_visible": False,
        }
    )


def _drop_umbrella_runs(candidate: dict) -> None:
    """Remove a run that is the NAME of the runs beside it rather than a wall of its own.

    Measured on a warehouse prompt: the planner authored four perimeter walls --
    `lin_drywall_walls_north/south/east/west`, each 0.15 m thick and lying on one edge of
    a 40x60 rectangle -- and then `lin_drywall_walls`, 2 m thick, running (0,0) to
    (40,60): the DIAGONAL of that same rectangle. It is the umbrella concept re-emitted
    as geometry, and it cut corner to corner through the building, colliding with the
    north run and both far corners. Seven segments went unplaced, `spec_count 28` against
    `world_count 21`, and four mandatory gates failed.

    The signal is in the ids, which is what makes this safe rather than a guess about
    geometry: a run whose id is a strict PREFIX of two or more other run ids is the thing
    those runs are parts OF. One wall is never the prefix of two others by accident --
    the planner names parts after the whole.

    Dropped rather than repaired: the parts already describe the structure completely, so
    the umbrella adds only the collision.
    """
    runs = candidate.get("linear_structures")
    if not isinstance(runs, list) or len(runs) < 2:
        return
    ids = [str(run.get("structure_id") or "") for run in runs]
    kept: list[dict] = []
    for run, structure_id in zip(runs, ids):
        parts = [
            other
            for other in ids
            if other != structure_id and other.startswith(structure_id + "_")
        ]
        if len(parts) >= 2:
            candidate.setdefault("approximations", []).append(
                {
                    "requirement_id": structure_id,
                    "reason": (
                        f"{structure_id!r} names the run that {len(parts)} others are "
                        "parts of, and was drawn as a wall of its own cutting across "
                        "them; the parts describe the structure, so the whole was dropped"
                    )[:300],
                    "user_visible": False,
                }
            )
            continue
        kept.append(run)
    candidate["linear_structures"] = kept


# Below this the run is a line with a lean, not a diagonal. A perimeter's diagonal has
# real extent on BOTH axes; a wall running mostly east-west with a slight kink does not.
_DIAGONAL_RATIO = 0.25


# How much of a diagonal run's rectangle other boundary runs must lie within before the
# diagonal is judged to be naming that boundary rather than being it. Generous: two walls
# on opposite edges already say "this area is enclosed".
_BOUNDED_OVERLAP = 0.6


def _already_bounded(runs: list, subject: dict, box: tuple) -> bool:
    """Do other enclosure runs already bound this rectangle?

    Two or more boundary runs lying mostly inside the subject's own rectangle mean the
    edges are drawn and the subject is the umbrella over them. One run is not enough: a
    single wall crossing a yard bounds nothing.
    """
    west, north, east, south = box
    width, depth = east - west, south - north
    if width <= 0.0 or depth <= 0.0:
        return False
    # A little slack: an edge run drawn on the boundary can sit a hair outside it.
    margin = 0.05 * max(width, depth)

    neighbours = 0
    for other in runs:
        if other is subject or not isinstance(other, dict):
            continue
        if not names_an_enclosure(other):
            continue
        start, end = other.get("from_m"), other.get("to_m")
        if not (isinstance(start, list) and isinstance(end, list)):
            continue
        if len(start) < 2 or len(end) < 2:
            continue
        try:
            points = [(float(start[0]), float(start[1])), (float(end[0]), float(end[1]))]
        except (TypeError, ValueError):
            continue
        if all(
            west - margin <= x <= east + margin and north - margin <= z <= south + margin
            for x, z in points
        ):
            neighbours += 1

    return neighbours >= 2


def _enclosures_are_perimeters(candidate: dict) -> None:
    """A boundary drawn corner to corner means the rectangle, not the diagonal.

    Measured on the warehouse prompt, after the coordinate frame was fixed and every
    entity finally placed. The single surviving run read, in its own words:

        semantic_type "Drywall Walls", thickness 2.0 m,
        source_text  "Defines the perimeter boundary of the simulation volume."
        from_m [-20, -30]  ->  to_m [20, 30]

    which is the diagonal of the very rectangle it claims to bound. Expanded literally it
    became sixteen 2 m-thick segments marching across the middle of the warehouse,
    slicing the floor in half -- the single most visible thing in the finished world, and
    a wall no one would ever build.

    This is not the planner being incoherent. Drawing a box by its opposite corners is
    how boxes are written down everywhere -- two points, and the rectangle is understood.
    The expander was the only reader that took the two points to mean a LINE.

    So the run is rebuilt as the four edges it described. Rebuilt rather than dropped
    (which is what `_drop_umbrella_runs` does when the parts are already present): here
    there are no parts, and dropping would leave the warehouse with no walls at all.

    A run is only reinterpreted when it BOTH names an enclosure and has real extent on
    both axes. A straight wall stays one wall, whatever it is called.
    """
    runs = candidate.get("linear_structures")
    if not isinstance(runs, list) or not runs:
        return

    rebuilt: list[dict] = []
    for run in runs:
        if not isinstance(run, dict):
            rebuilt.append(run)
            continue
        start, end = run.get("from_m"), run.get("to_m")
        if not (isinstance(start, list) and isinstance(end, list)):
            rebuilt.append(run)
            continue
        if len(start) < 2 or len(end) < 2:
            rebuilt.append(run)
            continue

        structure_id = str(run.get("structure_id") or "")
        if not names_an_enclosure(run):
            rebuilt.append(run)
            continue

        try:
            x0, z0 = float(start[0]), float(start[1])
            x1, z1 = float(end[0]), float(end[1])
        except (TypeError, ValueError):
            rebuilt.append(run)
            continue

        width, depth = abs(x1 - x0), abs(z1 - z0)
        longest = max(width, depth)
        if longest <= 0.0 or min(width, depth) < _DIAGONAL_RATIO * longest:
            rebuilt.append(run)  # a straight wall, drawn as a straight wall
            continue

        west, east = min(x0, x1), max(x0, x1)
        north, south = min(z0, z1), max(z0, z1)

        # Is this rectangle ALREADY bounded by other runs? Measured on the very next
        # warehouse run: the planner authored `lin_drywall_walls` corner to corner AND
        # `lin_wall_north/south/east/west` on the edges. Rebuilding the diagonal gave the
        # warehouse two complete perimeters standing in the same place -- 34 segments
        # where 18 belonged -- and eight of them could not be placed at all.
        #
        # `_drop_umbrella_runs` cannot catch this pair: it keys on ids, and
        # `lin_wall_north` is not named after `lin_drywall_walls`. Only the geometry
        # says they are the same boundary, so the geometry has to be what is asked.
        #
        # When something else already bounds the area the diagonal is the umbrella
        # concept re-emitted, exactly as before, and it is dropped rather than built.
        if _already_bounded(runs, run, (west, north, east, south)):
            candidate.setdefault("approximations", []).append(
                {
                    "requirement_id": structure_id,
                    "reason": (
                        f"{structure_id!r} was drawn corner to corner across an area "
                        "that other runs already bound, so it names the boundary rather "
                        "than being one; the runs on the edges describe it"
                    )[:300],
                    "user_visible": False,
                }
            )
            continue

        edges = (
            ("north", [west, north], [east, north]),
            ("south", [west, south], [east, south]),
            ("west", [west, north], [west, south]),
            ("east", [east, north], [east, south]),
        )
        for side, edge_start, edge_end in edges:
            edge = deepcopy(run)
            edge["structure_id"] = f"{structure_id}_{side}" if structure_id else side
            edge["from_m"] = edge_start
            edge["to_m"] = edge_end
            rebuilt.append(edge)

        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": structure_id,
                "reason": (
                    f"{structure_id!r} described a perimeter but was drawn corner to "
                    f"corner ({[round(x0, 1), round(z0, 1)]} to "
                    f"{[round(x1, 1), round(z1, 1)]}), which as a single run is a wall "
                    "diagonally through the middle; rebuilt as the four edges of that "
                    "rectangle"
                )[:300],
                "user_visible": False,
            }
        )

    candidate["linear_structures"] = rebuilt


# How many of a declared species must actually appear before the world can be said to
# hold it. Eight is few -- it is the difference between "there are oaks here" and "there
# is an oak here", which is the difference the visual critic kept reporting.
_ENOUGH_TO_READ = 8

# A world is not allowed to grow without end: the build budget is finite and so is the
# 90 MB web target. Past this the spec is asking for something v1 does not promise.
_WIDEST_WORLD_M = 220.0


def _a_world_holds_enough_of_what_defines_it(candidate: dict) -> None:
    """Give a world enough ground for the scatter that makes it what it is.

    Measured on the forest prompt, whose every run failed the visual critic with "the
    scene lacks trees, foliage" and "a single stump does not suffice". The spec was not
    wrong about forests:

        world           22 x 16 m      = 3.7 hundred-m2 of ground
        spc_oak_tree    1 per 100 m2   -> about 4 trees
        spc_maple_tree  1 per 100 m2   -> about 4 trees

    One mature oak per 100 m2 is a real forest. Twenty-two metres by sixteen is a large
    room. The density was right and the ground was missing, so the forest came out as
    seven trees and the critic said so three runs running.

    `_fit_declared_dimensions` sizes a world to hold its ENTITIES and never looks at
    scatter -- so a world whose defining content is scattered rather than listed gets no
    room for it at all. This asks the other half of the question: given the densities the
    spec itself declared, is there enough ground for them to be seen?

    Bounded on three sides. It only ever grows, so no world is made too small for what it
    already holds. It never touches a world enclosed by walls, whose size is a fact about
    the building rather than a guess. And it stops at `_WIDEST_WORLD_M`, because a spec
    that wants more ground than v1 can build should fail honestly rather than quietly.
    """
    environment = candidate.get("environment")
    if not isinstance(environment, dict):
        return
    declared = environment.get("dimensions_m")
    if not isinstance(declared, dict):
        return

    from pcg.enclosure import enclosure_extent

    # A walled world is already the size of its walls; scatter belongs inside them.
    runs = candidate.get("linear_structures")
    if isinstance(runs, list) and enclosure_extent(runs) is not None:
        return

    scatter = candidate.get("scatter")
    if not isinstance(scatter, list) or not scatter:
        return

    try:
        width = float(declared.get("width"))
        depth = float(declared.get("depth"))
    except (TypeError, ValueError):
        return
    if width <= 0.0 or depth <= 0.0:
        return

    needed_area = 0.0
    driver = ""
    for species in scatter:
        if not isinstance(species, dict):
            continue
        try:
            density = float(species.get("density_per_100m2") or 0.0)
        except (TypeError, ValueError):
            continue
        if density <= 0.0:
            continue
        wanted = _ENOUGH_TO_READ
        cap = species.get("max_instances")
        if isinstance(cap, int) and cap > 0:
            wanted = min(wanted, cap)  # a species capped at 3 is meant to be rare
        area_for_species = 100.0 * wanted / density
        if area_for_species > needed_area:
            needed_area = area_for_species
            driver = str(species.get("species_id") or "")

    if needed_area <= width * depth:
        return

    # Grow both axes together so the world keeps its shape: a spec that asked for a long
    # thin ravine gets a longer thinner ravine, not a square.
    scale = (needed_area / (width * depth)) ** 0.5
    grown_width = min(round(width * scale, 3), _WIDEST_WORLD_M)
    grown_depth = min(round(depth * scale, 3), _WIDEST_WORLD_M)
    if grown_width <= width and grown_depth <= depth:
        return

    declared["width"] = max(width, grown_width)
    declared["depth"] = max(depth, grown_depth)
    candidate.setdefault("approximations", []).append(
        {
            "requirement_id": "environment.dimensions_m",
            "reason": (
                f"at the declared densities a {width:.0f}x{depth:.0f}m world would have "
                f"held only a handful of {driver or 'its scatter'}, so it was widened to "
                f"{declared['width']:.0f}x{declared['depth']:.0f}m -- enough ground for "
                "the scattered content that defines this place to actually be seen"
            )[:300],
            "user_visible": False,
        }
    )


# What a kind of ground grows: (suffix, semantic_type, form, size_m, per 100 m2, cap,
# clustering). Short on purpose -- this is the cover that makes ground read as ground, not
# a landscaping scheme.
_COVER_KINDS: dict[str, tuple[tuple, ...]] = {
    "grass": (
        ("grass_tuft", "grass tuft", "ground_cover", [0.4, 0.3, 0.4], 90.0, 1400, "random"),
        ("ground_shrub", "low shrub", "bush_cluster", [1.1, 0.8, 1.1], 6.0, 220, "grouped"),
        ("field_stone", "field stone", "irregular_mass", [0.6, 0.4, 0.6], 3.0, 120, "random"),
    ),
    "soil": (
        ("weed_clump", "weed clump", "ground_cover", [0.5, 0.3, 0.5], 40.0, 700, "grouped"),
        ("field_stone", "field stone", "irregular_mass", [0.5, 0.35, 0.5], 6.0, 160, "random"),
    ),
    "sand": (
        ("dune_grass", "dune grass", "ground_cover", [0.5, 0.4, 0.5], 12.0, 300, "grouped"),
        ("desert_rock", "weathered rock", "irregular_mass", [0.8, 0.5, 0.8], 4.0, 120, "random"),
    ),
    "gravel": (
        ("gravel_stone", "loose stone", "irregular_mass", [0.4, 0.25, 0.4], 25.0, 500, "random"),
        ("verge_weed", "verge weed", "ground_cover", [0.4, 0.3, 0.4], 8.0, 200, "grouped"),
    ),
    "snow": (
        ("snow_rock", "snow-covered rock", "irregular_mass", [0.7, 0.45, 0.7], 5.0, 140, "random"),
    ),
    "rock": (
        ("scree_stone", "scree stone", "irregular_mass", [0.5, 0.35, 0.5], 20.0, 400, "random"),
    ),
}

# What the ground has to SAY about itself before anything is planted on it. Ordered:
# the first family whose words appear wins, so "paved_and_soil" is soil rather than
# nothing, and "grass_and_paths" is grass rather than paving.
_COVER_SIGNALS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("grass", ("grass", "lawn", "meadow", "pasture", "turf", "prairie", "savanna")),
    ("snow", ("snow", "ice", "glacier", "tundra")),
    ("sand", ("sand", "beach", "dune", "desert")),
    # "rock" not "rocky": the stored specs say `terrain_surface: "rock"` outright, and a
    # longer word cannot match a shorter one.
    ("rock", ("rock", "scree", "stone", "boulder", "quarry")),
    ("gravel", ("gravel", "shingle", "cinder")),
    ("soil", ("soil", "dirt", "earth", "mud", "loam", "natural_ground", "forest")),
)


# Below this, in its largest dimension, a scattered thing is a scrap. Measured against the
# forest floor: leaf litter is declared 0.1 x 0.15 x 0.1 m and rocks 0.3 x 0.2 x 0.3 m.
_A_SCRAP_M = 0.35


def _small_incidental_scatter_is_procedural(candidate: dict) -> None:
    """Tiny incidental scatter is built, not photographed.

    Measured on the forest floor. `spc_leaf_litter` is 10 cm across, `placement_is_incidental`
    and declared `preferred_source: "either"`, so it went to image-to-3D like everything
    else: one SDXL image, one TRELLIS reconstruction, 1,200 triangles, and a baked-in dark
    texture. 1,143 instances of it came out as BLACK FLAT PANELS strewn over the grass --
    the single most visible defect in the finished render, and the litter is not even
    something the prompt asked about.

    At that size the generator can only lose. Nobody sees the silhouette of a 10 cm scrap,
    the texture is what reads, and a photoreal texture decimated to a few triangles reads
    as a dark smudge. The procedural forms are the opposite trade: clean geometry, the
    planner's own `palette_hex` honoured exactly, ~60 triangles, and no GPU minutes at all.

    Only the small AND incidental are moved. A 12 m canopy tree keeps its silhouette and
    its choice; anything the prompt actually asked for keeps its choice too, because
    `placement_is_incidental` is the planner's own statement that where this goes -- and
    so what it is -- does not matter much.
    """
    scatter = candidate.get("scatter")
    if not isinstance(scatter, list):
        return
    for species in scatter:
        if not isinstance(species, dict):
            continue
        if not species.get("placement_is_incidental"):
            continue
        requirement = species.get("asset")
        if not isinstance(requirement, dict):
            continue
        if str(requirement.get("preferred_source") or "") == "procedural":
            continue
        size = species.get("size_m")
        if not (isinstance(size, list) and len(size) >= 3):
            continue
        try:
            # The MIDDLE dimension, not the largest. A branch is declared
            # 1.0 x 0.05 x 0.05 m: a metre long and five centimetres through, so its
            # largest dimension says "not a scrap" while nothing about it has a
            # silhouette worth reconstructing from a photograph. A fern at
            # 0.5 x 1.5 x 0.5 has a real middle dimension and keeps its choice.
            middle = sorted(float(value) for value in size[:3])[1]
        except (TypeError, ValueError):
            continue
        if middle > _A_SCRAP_M:
            continue
        requirement["preferred_source"] = "procedural"
        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": str(species.get("species_id") or ""),
                "reason": (
                    f"at {middle:.2f} m through this is incidental ground detail, so it is built "
                    "from a procedural form in its declared colours rather than generated "
                    "from an image -- a photoreal texture at this size reads as a dark smudge"
                )[:300],
                "user_visible": False,
            }
        )


def _ground_carries_its_own_cover(candidate: dict) -> None:
    """Outdoor ground is never bare, and the planner almost never says so in the enum.

    Across every spec this system has produced -- 425 outdoor worlds -- 390 (92%) carried
    no `scatter` at all. `scatter` is the field the schema calls "how a place gets the
    hundreds of trees/rocks/debris that make it feel real"; being optional, it was
    skipped, and eight consecutive village runs came out at ten entities on a bare plane.

    The first version of this rule keyed on `terrain_surface` and fired on **nothing**:

        outdoor terrain_surface:  unspecified 347 | none 63 | soil 25 | grass 8

    The planner does say what its ground is -- in the free-text `terrain` field, where
    `grass_and_paths` appears 410 times -- while leaving the enum unspecified. So the
    ground is asked in its own words, across every field that describes it.

    `surfaces.py` deliberately refuses to read that free text, and is right to: resolving
    a RENDERED surface by word-matching would silently miss "machair" and paint the
    ground wrong. The trade differs here. Cover is additive and incidental, the cost of a
    miss is the bare plain this exists to fix, and the cost of a false positive is some
    tufts on a world that already called itself grass.

    Evidence is required in both directions: a world that says nothing about its ground
    grows nothing, and a world that authored its own scatter is left alone entirely.
    """
    environment = candidate.get("environment")
    if not isinstance(environment, dict):
        return
    if str(environment.get("world_kind") or "") not in ("outdoor", "mixed"):
        return

    existing = candidate.get("scatter")
    if isinstance(existing, list) and existing:
        return  # the planner dressed its own world

    # Everything the spec says about its own ground, in one place.
    described = " ".join(
        str(environment.get(field) or "")
        for field in ("terrain", "terrain_surface", "semantic_type")
    ).lower()
    family = next(
        (name for name, words in _COVER_SIGNALS if any(w in described for w in words)),
        None,
    )
    if family is None:
        return  # ground that says nothing about itself grows nothing

    species = [
        {
            "species_id": f"spc_{suffix}",
            "semantic_type": semantic_type,
            "asset": {
                "brief": f"a low-poly {semantic_type}",
                "category": "foliage" if form == "ground_cover" else "prop",
                "requires_animation": False,
                "preferred_source": "either",
                "procedural_type": form,
            },
            "size_m": list(size_m),
            "density_per_100m2": density,
            "clustering": clustering,
            "scale_jitter": 0.35,
            "max_instances": cap,
            "placement_is_incidental": True,
        }
        for suffix, semantic_type, form, size_m, density, cap, clustering in _COVER_KINDS[
            family
        ]
    ]

    candidate["scatter"] = species
    candidate.setdefault("approximations", []).append(
        {
            "requirement_id": "environment.scatter",
            "reason": (
                f"the world describes its ground as {described.strip()[:80]!r} and "
                f"authored no scatter, so it would render as a bare plane; added "
                f"{len(species)} species of {family} cover"
            )[:300],
            "user_visible": False,
        }
    )


# Words by which a world calls itself wooded. Its own description, not the prompt's --
# any prompt that yields a woodland environment is covered, and none that does not.
_WOODED_WORDS = (
    "forest",
    "woodland",
    "woods",
    "copse",
    "grove",
    "jungle",
    "rainforest",
    "taiga",
    "orchard",
)

# Vegetation this tall is canopy rather than undergrowth.
_CANOPY_HEIGHT_M = 3.0


def _a_wood_has_trees(candidate: dict) -> None:
    """A world that calls itself wooded needs more than one tree.

    Measured on the forest run where sizing and ground cover both worked. 740 instances
    were scattered and the world grew to 48x37 m, and it still failed the visual critic,
    because of WHAT was scattered:

        leaf_litter 500 | ferns 120 | rocks 50 | branches 40 | salmonberry 30
        entities: one student, one stump, one nest, one squirrel, one bird -- and
                  `ent_cedar`, a single 10x20 m tree

    A forest ecosystem lesson with one cedar. The floor of a forest was there in full and
    the forest was not, which is why "the scene lacks trees" survived every other fix.

    `_ground_carries_its_own_cover` cannot reach this: it only dresses a world that
    authored NO scatter, and this one authored plenty. The gap it leaves is the canopy --
    the tall growth that a wood is, as opposed to the litter that lies under it.

    So the count is taken across both places a tree can live, entities and scatter, and
    only a wood that is short of trees is given any. A single ornamental tree in a
    courtyard is not affected, because a courtyard does not call itself a wood.
    """
    environment = candidate.get("environment")
    if not isinstance(environment, dict):
        return
    if str(environment.get("world_kind") or "") not in ("outdoor", "mixed"):
        return

    described = " ".join(
        str(environment.get(field) or "")
        for field in ("terrain", "terrain_surface", "semantic_type")
    ).lower()
    if not any(word in described for word in _WOODED_WORDS):
        return

    try:
        width = float((environment.get("dimensions_m") or {}).get("width"))
        depth = float((environment.get("dimensions_m") or {}).get("depth"))
    except (TypeError, ValueError):
        return
    if width <= 0.0 or depth <= 0.0:
        return
    hundreds_of_m2 = width * depth / 100.0

    # Trees already standing, wherever the planner chose to put them.
    canopy = 0
    for entity in candidate.get("entities") or ():
        if not isinstance(entity, dict):
            continue
        size = (entity.get("physical") or {}).get("bbox_m")
        if isinstance(size, list) and len(size) >= 2:
            try:
                if float(size[1]) >= _CANOPY_HEIGHT_M:
                    canopy += 1
            except (TypeError, ValueError):
                pass
    scatter = candidate.get("scatter")
    scatter = scatter if isinstance(scatter, list) else []
    for species in scatter:
        if not isinstance(species, dict):
            continue
        size = species.get("size_m")
        try:
            tall = isinstance(size, list) and len(size) >= 2 and float(size[1]) >= _CANOPY_HEIGHT_M
            density = float(species.get("density_per_100m2") or 0.0)
        except (TypeError, ValueError):
            continue
        if tall:
            canopy += int(density * hundreds_of_m2)

    if canopy >= _ENOUGH_TO_READ:
        return

    # Enough ground to be a wood, at a spacing a mature tree actually stands at.
    density = max(_ENOUGH_TO_READ / max(hundreds_of_m2, 1e-6), 1.0)
    candidate.setdefault("scatter", [])
    candidate["scatter"].append(
        {
            "species_id": "spc_canopy_tree",
            "semantic_type": "canopy tree",
            "asset": {
                "brief": "a low-poly canopy tree with a bare trunk and a broad crown",
                "category": "foliage",
                "requires_animation": False,
                "preferred_source": "either",
                "procedural_type": "foliage_column",
                # Foliage green and bark brown, in that order. The curated library's
                # trees are untextured and its foliage is a stylized mint -- 24 of 30
                # models carry leaf rgb [0.16, 0.79, 0.67] -- which is cohesive but
                # reads as neon rather than as a wood. `_tint_to_palette` moves each
                # material to whichever of these it is nearest in hue, so leaves take
                # the green and the trunk takes the brown.
                "palette_hex": ["#2E7D32", "#5D4037"],
            },
            "size_m": [5.0, 12.0, 5.0],
            "density_per_100m2": round(density, 3),
            # Spread, not thickets. Measured: with `grouped` the sampler reported
            # `shortfall_reason "packing_limit"`, `spacing_m 11.2996`, and placed 3 of 48
            # -- a mature crown is genuinely 11 m across, so clustering them into a few
            # centres leaves room for almost none. A canopy is the trees standing apart
            # across the whole wood, which is what `random` samples.
            "clustering": "random",
            "scale_jitter": 0.3,
            "max_instances": 260,
            "placement_is_incidental": True,
        }
    )
    candidate.setdefault("approximations", []).append(
        {
            "requirement_id": "environment.scatter",
            "reason": (
                f"the world describes itself as wooded but carried only {canopy} tree"
                f"{'' if canopy == 1 else 's'} tall enough to read as canopy, so a "
                "canopy species was added; a wood is the trees, not the litter under them"
            )[:300],
            "user_visible": False,
        }
    )


def _ground_follows_its_vegetation(candidate: dict) -> None:
    """A world carpeted in plants does not stand on bare earth.

    Measured on the village prompt: `terrain_surface` came back `soil`, so the ground
    rendered dark brown, while the same spec asked for boxwood bushes, ornamental grass
    and leaf litter growing out of it. Bare soil under a lawn's worth of greenery is a
    contradiction the planner has no reason to notice and a viewer notices immediately --
    it is the difference between a village and a building site.

    Deliberately general: the rule is "ground follows the vegetation it carries", not
    "villages are green". A quarry with no plants keeps its stone, a beach keeps its
    sand, and a farmyard that genuinely asked for bare earth and grows nothing keeps its
    soil. Only a world that plants things on itself is moved, and only from BARE ground.
    """
    environment = candidate.get("environment")
    if not isinstance(environment, dict):
        return
    if str(environment.get("world_kind") or "") == "indoor":
        return
    surface = str(environment.get("terrain_surface") or "")
    if surface not in _BARE_GROUND:
        return

    planted = 0
    for species in candidate.get("scatter") or ():
        if not isinstance(species, dict):
            continue
        text = " ".join(
            str(species.get(key) or "")
            for key in ("species_id", "semantic_type", "source_text")
        ).lower()
        text += " " + str((species.get("asset") or {}).get("brief") or "").lower()
        if any(word in text for word in _VEGETATION_WORDS):
            planted += 1
    if planted < 2:
        # One planter of herbs does not make a meadow. Two or more species is a world
        # that has decided it is green.
        return

    environment["terrain_surface"] = "grass"
    candidate.setdefault("approximations", []).append(
        {
            "requirement_id": "environment.terrain_surface",
            "reason": (
                f"the ground was {surface!r} while {planted} kinds of plant grow on it; "
                "bare earth under that much greenery reads as a building site, so the "
                "ground was changed to grass"
            )[:300],
            "user_visible": False,
        }
    )


def _unpave_the_whole_world(candidate: dict) -> None:
    """A settlement stands on ground, with its paved parts as regions.

    Measured across five settlement prompts: three chose `stone` and one `concrete` for
    `terrain_surface`, which is the WHOLE world's ground -- so paving one courtyard
    paved everything, and a village lane rendered as a slab. Worked examples in the
    field description moved one prompt of five, which is ADR-0009 again: guidance
    improves the average and never becomes reliable.

    So it is enforced, and only in the one case where it is unambiguous: the spec has
    declared paved `regions`, which means it knows where its paving goes, and a paved
    base as well can only be a mistake. A warehouse with no regions keeps its concrete,
    because there the answer is genuinely concrete.
    """
    environment = candidate.get("environment")
    if not isinstance(environment, dict):
        return
    surface = str(environment.get("terrain_surface") or "")
    if surface not in _PAVED_SURFACES:
        return
    if not (candidate.get("regions") or candidate.get("routes")):
        return
    environment["terrain_surface"] = "soil"
    candidate.setdefault("approximations", []).append(
        {
            "requirement_id": "req_prompt_fidelity",
            "reason": (
                f"the whole world's ground was set to {surface!r} while paved areas were "
                "also described separately; the base ground is soil so the paving reads "
                "as paving rather than as everywhere"
            )[:300],
            "user_visible": True,
        }
    )


# Prefixes the spec's own objects carry. A relation is written with none of them --
# measured over 400 specs, relation ids are `ent_*` or the bare word `simulation` -- so an
# id wearing one of these is the planner pointing at a real thing under the wrong name.
_ID_PREFIXES = ("ent_", "lin_", "rte_", "region_", "route_", "struct_", "scatter_", "zone_")

# The one legitimate non-entity target: the world itself.
_WORLD_TARGETS = frozenset({"simulation"})


def _id_slug(value: str) -> str:
    """An id with any of the spec's prefixes removed, so two spellings can be compared."""
    text = str(value or "").strip().lower()
    for prefix in _ID_PREFIXES:
        if text.startswith(prefix):
            return text[len(prefix) :]
    return text


def _resolve_reference(value: str, candidate: dict) -> str | None:
    """The real id this reference means, or None if the spec contains no such thing.

    Slug comparison, because the mismatch is always the prefix: `struct_perimeter_wall`
    and `lin_perimeter_wall` are the same wall. A run is resolved to one of its SEGMENT
    entities rather than to the run id, because expansion has already turned the run into
    entities by this point and a segment is what a placer can measure a distance to.

    Prefix matching in both directions catches the near-misses the planner produces
    (`central_path` for `central_pathway`); it is only reached after an exact match
    fails, so it cannot override a correct reference.
    """
    slug = _id_slug(value)
    if not slug:
        return None

    entity_ids = [
        str(entity.get("entity_id"))
        for entity in (candidate.get("entities") or ())
        if isinstance(entity, dict) and entity.get("entity_id")
    ]
    species_ids = [
        str(species.get("species_id"))
        for species in (candidate.get("scatter") or ())
        if isinstance(species, dict) and species.get("species_id")
    ]

    for pool in (entity_ids, species_ids):
        for real in pool:
            if _id_slug(real) == slug:
                return real
    # A run's segments are named for the run: `perimeter_wall` -> ent_perimeter_wall_s0.
    for pool in (entity_ids, species_ids):
        for real in pool:
            other = _id_slug(real)
            if other.startswith(slug) or slug.startswith(other):
                return real
    return None


def _normalise_requirements(candidate: dict) -> None:
    """A requirement must name something the spec contains, once.

    Two of the three commonest traceability failures in this system's whole history, and
    both were visible in one live harbour run:

        REQUIREMENT_SUBJECT_UNKNOWN   subject "ent_timber_jetty"
        DUPLICATE_REQUIREMENT_ID      req_timber_jetty, twice

    Across every stored run: REQUIREMENT_SUBJECT_UNKNOWN 53, and it fails the whole run.

    Both come from the same place. `expand_linear_structures` replaces a run with its
    segments, so `ent_timber_jetty` stops being an entity and `ent_timber_jetty_s0`
    starts being one -- while the requirements the planner wrote still name the run. And
    when the planner writes one requirement for the run and another for its first
    segment, it reuses the id, because to the planner they are the same thing.

    So: a subject that no longer exists is redirected to what replaced it, by the same
    `_resolve_reference` that already repairs spatial relations. A duplicate id keeps the
    copy whose subject RESOLVES, which is the useful one -- the run-id copy is the stale
    one by construction. Only a requirement naming nothing at all is dropped, and that is
    recorded rather than silent.

    Runs after expansion, because the segments are what a subject must resolve to.
    """
    requirements = candidate.get("requirements")
    if not isinstance(requirements, list) or not requirements:
        return

    known = {
        str(entity.get("entity_id"))
        for entity in candidate.get("entities") or ()
        if isinstance(entity, dict)
    }
    known |= {
        str(species.get("species_id"))
        for species in candidate.get("scatter") or ()
        if isinstance(species, dict)
    }
    known.add("simulation")

    resolved: list[dict] = []
    for requirement in requirements:
        if not isinstance(requirement, dict):
            continue
        subject = str(requirement.get("subject") or "")
        if subject in known:
            resolved.append(requirement)
            continue
        replacement = _resolve_reference(subject, candidate)
        if replacement is None:
            candidate.setdefault("approximations", []).append(
                {
                    "requirement_id": str(requirement.get("requirement_id") or ""),
                    "reason": (
                        f"the requirement named {subject!r}, which this spec does not "
                        "contain, so it was withdrawn rather than left for a validator "
                        "to reject"
                    )[:300],
                    "user_visible": False,
                }
            )
            continue
        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": str(requirement.get("requirement_id") or ""),
                "reason": (
                    f"{subject!r} became {replacement!r} when its run was expanded into "
                    "segments, so the requirement follows it"
                )[:300],
                "user_visible": False,
            }
        )
        resolved.append({**requirement, "subject": replacement})

    # One id, one requirement. The copy whose subject resolved on its own is kept: a
    # redirected copy came from a stale run id, so it is the duplicate.
    seen: dict[str, dict] = {}
    order: list[str] = []
    for requirement in resolved:
        key = str(requirement.get("requirement_id") or "")
        if key not in seen:
            seen[key] = requirement
            order.append(key)
            continue
        kept = seen[key]
        kept_subject = str(kept.get("subject") or "")
        this_subject = str(requirement.get("subject") or "")
        if kept_subject not in known and this_subject in known:
            seen[key] = requirement  # the surviving entity wins
        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": key,
                "reason": (
                    f"two requirements shared the id {key!r}; the one naming "
                    f"{str(seen[key].get('subject'))!r} was kept"
                )[:300],
                "user_visible": False,
            }
        )

    candidate["requirements"] = [seen[key] for key in order]


def _normalise_spatial_relations(candidate: dict) -> None:
    """Drop relations that name something this spec does not contain.

    Measured on settlement prompts: SPATIAL_TARGET_UNKNOWN seven times and
    SPATIAL_SUBJECT_UNKNOWN four, and each one fails the whole run. The planner writes a
    relation against an entity it then renamed or never created.

    This is the same class as `_normalise_causal_links`, and the same treatment, because
    a relation is a CONSTRAINT rather than content. Dropping it removes an instruction
    that could never be honoured; the entities on either side are untouched, and any
    that genuinely went missing is still caught by requirement traceability, which is
    the gate that exists to notice absent content.

    That is the distinction that makes this safe where dropping a REQUIREMENT would not
    be: a requirement is the record that something was asked for, and deleting one hides
    an omission. A relation is only a wish about arrangement.
    """
    relations = candidate.get("spatial_relations")
    if not isinstance(relations, list):
        return
    known = {
        str(entity.get("entity_id"))
        for entity in (candidate.get("entities") or ())
        if isinstance(entity, dict)
    }
    known |= {
        str(species.get("species_id"))
        for species in (candidate.get("scatter") or ())
        if isinstance(species, dict)
    }
    kept: list[dict] = []
    for relation in relations:
        if not isinstance(relation, dict):
            continue
        subject = str(relation.get("subject_id") or "")
        target = str(relation.get("target_id") or "")
        # Every id is checked, not only `ent_*`. The old exemption treated any other
        # prefix as a zone reference to be resolved later, which let four invented ids
        # through to fail a mandatory gate; the world itself is the one real exception.
        missing = []
        for name, value, key in (
            ("subject", subject, "subject_id"),
            ("target", target, "target_id"),
        ):
            if not value or value in known or value in _WORLD_TARGETS:
                continue
            resolved = _resolve_reference(value, candidate)
            if resolved is None:
                missing.append(name)
                continue
            # Rewrite in place: the reference was meant, only misspelt.
            relation[key] = resolved
            candidate.setdefault("approximations", []).append(
                {
                    "requirement_id": resolved,
                    "reason": (
                        f"a relation named {value!r}, which this world does not contain; "
                        f"it was read as {resolved!r}, the thing of that name it does"
                    )[:300],
                    "user_visible": False,
                }
            )
        if not missing:
            kept.append(relation)
            continue
        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": subject or target or "unknown",
                "reason": (
                    f"a {relation.get('relation')} relation named a {missing[0]} this "
                    "world does not contain, so the arrangement it asked for was "
                    "dropped; the things themselves are unaffected"
                )[:300],
                "user_visible": False,
            }
        )
    candidate["spatial_relations"] = kept


def _normalise_causal_links(candidate: dict) -> None:
    """Drop links that name something this spec does not contain.

    The compiler already refuses an unresolvable link with an error object, and that
    is the right behaviour for a hand-written spec. Coming from the planner it is
    routine: a link is written against an entity the model then renamed or dropped,
    and failing the whole run over it would throw away a world that is otherwise
    fine. So they are removed here and disclosed.

    Removed rather than repaired. Guessing which entity was meant would invent a
    causal claim nobody made, and a wrong cause is worse than a missing one -- the
    visitor would watch the wrong thing happen and believe it.
    """
    links = candidate.get("causal_links")
    if not isinstance(links, list):
        return
    held: dict[str, set[str]] = {
        str(entity.get("entity_id")): set(entity.get("capabilities") or ())
        for entity in candidate.get("entities") or ()
        if isinstance(entity, dict)
    }
    kept: list[dict] = []
    for link in links:
        if not isinstance(link, dict):
            continue
        ends = (link.get("when") or {}, link.get("then") or {})
        if all(
            str(end.get("capability_id")) in held.get(str(end.get("entity_id")), set())
            for end in ends
        ):
            kept.append(link)
            continue
        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": str(link.get("link_id") or "unknown"),
                "reason": (
                    "a causal link named an entity or capability this world does not "
                    "contain, so the connection was dropped rather than guessed: a "
                    "wrong cause is worse than a missing one"
                )[:300],
                "user_visible": True,
            }
        )
    if kept:
        candidate["causal_links"] = kept
    else:
        candidate.pop("causal_links", None)


def _normalise_dialogue(candidate: dict) -> None:
    """Keep a speaker only if somebody wrote them something to say.

    `entity.dialogue` is required when the capability is present, and that rule
    is a conditional the grammar adapter strips, so the planner cannot see it.
    Two rules of the same kind have already cost whole runs.

    Nothing here can invent a line. A guard with no lines is not a guard whose
    dialogue needs filling in -- it is a plain object that was mislabelled, so
    the capability comes off and the entity survives as scenery. The alternative
    is shipping a person who visibly does nothing when you talk to them, which
    reads worse than a person who was never offered a conversation.

    Over-long lines are trimmed rather than rejected: the canonical schema caps a
    line at 200 characters and would throw out the entire spec over one talkative
    sentence, dropping the run to the deterministic fallback.
    """
    for item in candidate.get("entities") or ():
        if not isinstance(item, dict):
            continue
        capabilities = item.get("capabilities")
        if not isinstance(capabilities, list) or "dialogue" not in capabilities:
            # Lines on an entity that is not a speaker would fail validation as
            # surely as a speaker with no lines.
            item.pop("dialogue", None)
            continue
        lines = [
            str(line).strip()[:200]
            for line in (item.get("dialogue") or [])
            if str(line).strip()
        ][:6]
        if lines:
            item["dialogue"] = lines
            continue
        item.pop("dialogue", None)
        capabilities.remove("dialogue")
        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": str(item.get("entity_id") or "unknown"),
                "reason": (
                    "declared as a speaker with no lines written, so it is built "
                    "as a plain object; a person who says nothing when spoken to "
                    "reads worse than one who was never offered a conversation"
                )[:300],
                "user_visible": True,
            }
        )
    # The top-level capability list must not keep advertising dialogue once the
    # last speaker has lost it, or capability_declaration fails on a capability
    # no entity holds.
    still_spoken = any(
        "dialogue" in (item.get("capabilities") or [])
        for item in candidate.get("entities") or ()
        if isinstance(item, dict)
    )
    top_level = candidate.get("capabilities")
    if not still_spoken and isinstance(top_level, list) and "dialogue" in top_level:
        top_level.remove("dialogue")


def _normalise_attachments(candidate: dict) -> None:
    """Supply the attachment rotation the planner is never shown it must give.

    `spatial_relation` requires `local_offset_m` and `local_rotation_y_degrees`
    only when `relation == "attached_to"`, and it says so with an
    `allOf`/`if`/`then`. ollama_simulation_schema() strips conditionals for the
    grammar adapter, so the model cannot see the rule -- the same trap as
    `procedural_type`, and a worse one, because the miss rejects the WHOLE spec
    rather than one field. Observed: "neutral planner output rejected at
    ['spatial_relations', 2]: 'local_rotation_y_degrees' is a required
    property", after which the run fell back to the built-in draft and the
    lineage gate refused to publish it. Any prompt with a door can hit this,
    because a door is attached to a building.

    Rotation defaults to zero: "facing as its parent faces" is what an attached
    thing does unless told otherwise, so this is correct rather than merely
    convenient.

    The offset is harder and is derived rather than zeroed. Zero would bury a
    door in the middle of a house, because placement uses the offset to seat the
    child against a face. Instead the child is set flush along its thinnest
    HORIZONTAL axis, which is the axis a door, window, sign or panel is thin in
    and therefore the face it attaches by. The side is a guess, so it is
    disclosed as user-visible: a door on the wrong wall of the right building is
    a far better answer than the whole spec being rejected and the prompt
    getting a generic fallback world instead.
    """
    by_id = {
        entity.get("entity_id"): entity
        for entity in candidate.get("entities") or ()
        if isinstance(entity, dict)
    }

    def _bbox(entity_id: object) -> list[float] | None:
        entity = by_id.get(entity_id)
        box = ((entity or {}).get("physical") or {}).get("bbox_m")
        if isinstance(box, list) and len(box) >= 3:
            try:
                return [float(box[0]), float(box[1]), float(box[2])]
            except (TypeError, ValueError):
                return None
        return None

    for relation in candidate.get("spatial_relations") or ():
        if not isinstance(relation, dict):
            continue
        if relation.get("relation") != "attached_to":
            continue
        subject_id = relation.get("subject_id")

        if "local_rotation_y_degrees" not in relation:
            relation["local_rotation_y_degrees"] = 0.0
            candidate.setdefault("approximations", []).append(
                {
                    "requirement_id": str(subject_id or "attachment"),
                    "reason": "attachment rotation not specified; aligned with its parent",
                    "user_visible": False,
                }
            )

        if "local_offset_m" in relation:
            continue
        child = _bbox(subject_id)
        parent = _bbox(relation.get("target_id"))
        if child is None or parent is None:
            # Nothing measurable to seat it against. Leaving the field absent
            # lets validation reject the spec, which is right: an invented
            # offset here would be a number with no basis at all.
            continue
        # Axis 0 or 2 only. A thing attached to a building is attached to a
        # wall, not laid on its roof, and Y is the thinnest axis of anything
        # flat on the ground.
        axis = 0 if child[0] <= child[2] else 2
        offset = [0.0, 0.0, 0.0]
        offset[axis] = parent[axis] / 2.0 + child[axis] / 2.0
        relation["local_offset_m"] = [round(value, 4) for value in offset]
        candidate.setdefault("approximations", []).append(
            {
                "requirement_id": str(subject_id or "attachment"),
                "reason": (
                    "attachment position not specified; seated flush against "
                    f"the parent on the {'x' if axis == 0 else 'z'} axis, side chosen "
                    "arbitrarily"
                )[:300],
                "user_visible": True,
            }
        )


def _drop_empty_species(candidate: dict) -> list[str]:
    """Remove scatter species the planner asked for none of.

    Measured: expanded runs emitted `density_per_100m2: 0` for several species.
    The range clamp then lifts 0 to the exclusive minimum, which keeps a species
    that will never place a single instance -- and every kept species costs a
    real asset resolution, i.e. GPU time generating a mesh for something the
    world was never going to show.

    Dropping is safe because a species IS its density: zero of a kind is the
    same statement as not naming the kind.
    """
    species = candidate.get("scatter")
    if not isinstance(species, list):
        return []
    kept, dropped = [], []
    for item in species:
        if not isinstance(item, dict):
            continue
        try:
            density = float(item.get("density_per_100m2") or 0.0)
        except (TypeError, ValueError):
            density = 0.0
        (kept if density > 0.0 else dropped).append(item)
    if dropped:
        candidate["scatter"] = kept
    return [str(item.get("species_id") or "?") for item in dropped]


def _dedupe_unique_arrays(candidate: dict) -> None:
    """Schema-driven dedupe; the implementation is shared with every guided stage."""
    dedupe_unique_arrays(candidate, simulation_schema())


def _normalise_species_ids(candidate: dict) -> None:
    """Coerce invented species ids into the canonical `spc_` form.

    A species id is not free text: it becomes a Godot node name and an asset
    key, so the contract constrains it the same way entity ids are constrained.
    A model asked for ids still writes "Tree Fern" or "tree_fern" often enough
    that rejecting the whole spec over spelling would drop good worlds to the
    deterministic fallback. Slugging is a normalisation, not a weakening: the
    untouched canonical schema still validates the result afterwards.
    """
    seen: set[str] = set()
    for species in candidate.get("scatter") or ():
        if not isinstance(species, dict):
            continue
        raw = str(species.get("species_id") or species.get("semantic_type") or "species")
        slug = re.sub(r"[^a-z0-9]+", "_", raw.lower()).strip("_")
        slug = re.sub(r"^spc_", "", slug) or "species"
        candidate_id = f"spc_{slug}"[:64].rstrip("_")
        # Distinct species must stay distinct, or two kinds collapse into one field.
        suffix = 2
        while candidate_id in seen:
            candidate_id = f"{f'spc_{slug}'[:61].rstrip('_')}_{suffix}"
            suffix += 1
        seen.add(candidate_id)
        species["species_id"] = candidate_id


_MAX_BBOX_M = 200.0
_MIN_BBOX_M = 0.05


def _clamp_entity_bounds(candidate: dict) -> list[dict]:
    """Clamp out-of-range entity footprints instead of discarding the whole spec.

    Validation is all-or-nothing, so ONE bad number dropped the entire plan to the
    deterministic fallback — a generic empty world that looks the same for every
    prompt. A real run died on `entities[2].physical.bbox_m[0] = 500.0` (the model
    sizing a river or the jungle itself as an entity) against a 200 m cap.

    Losing one over-sized object is vastly better than losing the whole plan, so
    the value is clamped and DISCLOSED as an approximation — never silently
    resized. The untouched canonical schema still validates the result.
    """
    clamped: list[dict] = []
    for entity in candidate.get("entities") or ():
        bbox = (entity.get("physical") or {}).get("bbox_m")
        if not isinstance(bbox, list) or len(bbox) != 3:
            continue
        for index, value in enumerate(bbox):
            if not isinstance(value, (int, float)):
                continue
            bounded = min(max(float(value), _MIN_BBOX_M), _MAX_BBOX_M)
            if bounded != float(value):
                bbox[index] = bounded
                clamped.append(
                    {
                        "entity_id": entity.get("entity_id"),
                        "axis": index,
                        "requested_m": float(value),
                        "applied_m": bounded,
                    }
                )
    return clamped


# Smallest step away from an exclusive bound. Only ever applied to a value the
# model already put out of range, so the distortion is bounded by the schema.
def _clamp_out_of_range_numbers(candidate: dict) -> list[dict]:
    """Bound every number the guided grammar could not, against the canonical schema.

    The walk itself lives in `schema_bounds` because it is not specific to this
    contract: adding a second guided stage (the SceneBrief) reproduced exactly
    this failure one file over, which is what a schema-specific "general" fix
    earns you.
    """
    return clamp_to_schema(candidate, simulation_schema())


def _record_range_approximations(candidate: dict, clamped: list[dict]) -> None:
    """Disclose schema-range clamps the same way entity bounds are disclosed."""
    if not clamped:
        return
    requirements = candidate.get("requirements") or []
    if not requirements:
        return
    approximations = candidate.setdefault("approximations", [])
    for item in clamped[:8]:
        approximations.append(
            {
                "requirement_id": requirements[0]["requirement_id"],
                "reason": (
                    f"{item['path']} was planned as {item['requested']:g} and was adjusted "
                    f"to {item['applied']:g}, the closest value this simulation supports"
                )[:300],
                "user_visible": True,
            }
        )


def _record_bound_approximations(candidate: dict, clamped: list[dict]) -> None:
    """Surface clamps in `approximations` so the compromise is user-visible."""
    if not clamped:
        return
    requirements = candidate.get("requirements") or []
    if not requirements:
        return  # nothing to attribute it to; the warning log is the record
    requirement_id = requirements[0].get("requirement_id")
    if not requirement_id:
        return
    entries = candidate.setdefault("approximations", [])
    for item in clamped:
        entries.append(
            {
                "requirement_id": requirement_id,
                "reason": (
                    f"{item['entity_id']} axis {item['axis']} was planned at "
                    f"{item['requested_m']:.1f} m and was clamped to "
                    f"{item['applied_m']:.1f} m by the platform size limit."
                )[:300],
                "user_visible": True,
            }
        )


def _llm_plan(
    prompt: str,
    draft: dict,
    settings,
    *,
    planner_model_id: str,
    planner_base_url: str,
    brief: str | None = None,
) -> dict | None:
    try:
        with httpx.Client(
            base_url=planner_base_url,
            timeout=settings.llm_timeout_seconds,
        ) as client:
            response = client.post(
                "/api/chat",
                json={
                    "model": planner_model_id,
                    "stream": False,
                    "format": ollama_simulation_schema(
                        (draft.get("request") or {}).get("size_profile")
                    ),
                    "think": False,
                    "keep_alive": "30m",
                    "options": {
                        "temperature": 0.2,
                        "seed": draft["meta"]["seed"],
                        # Requested, not assumed. A furnished world is a LOT of JSON: at
                        # the entity floor one spec reached 78,394 characters and was cut
                        # mid-string -- "Unterminated string starting at line 3120" --
                        # so the planner produced nothing usable and the run silently
                        # fell back to the built-in draft, losing scatter, generation and
                        # the model's own authorship in one go.
                        #
                        # The input carries a brief and RAG context before the model
                        # writes a token, so the default window leaves too little room
                        # for the output the floor now demands. Same omission that
                        # truncated the vision critic.
                        # 32768, the window this model actually advertises. 65536 stopped
                        # the truncation and slowed inference enough to blow the timeout
                        # instead, so the larger number bought nothing.
                        "num_ctx": 32768,
                    },
                    "messages": [
                        {
                            "role": "system",
                            "content": (
                                "Create a neutral executable 3D SimulationSpec. "
                                "Do not invent capability IDs outside the schema. "
                                "Capabilities describe WHAT AN ENTITY CAN DO, "
                                "chosen from the fixed list — they are not free "
                                "text and each one maps to a vetted script. A "
                                "creature that moves about on its own is "
                                "[\"animal\", \"locomotion\"]; a door is "
                                "[\"openable\"]. "
                                + capability_guidance() + " "
                                "Never coin a new id such as "
                                "\"wandering_behaviour\" — there is no template "
                                "for it and the build cannot be made. "
                                "Every prompt requirement must have an observable "
                                "RequirementContract. "
                                # The planner wrote requirements ABOUT THE
                                # DOCUMENT -- subject "entities", predicate
                                # "contains_count" -- rather than about the world
                                # the document describes. `subject` and
                                # `predicate` are free-form strings in the schema,
                                # so nothing stopped it, and all 12 entities were
                                # reported as missing a presence requirement.
                                "A requirement is a checkable fact about the "
                                "FINISHED SIMULATION, never a statement about this "
                                "JSON. `subject` is an entity_id from `entities`, "
                                "or the literal \"simulation\" — never a field "
                                "name like \"entities\" or \"scatter\", and never "
                                "a count of them. Give EVERY entity one "
                                "requirement with predicate \"exists\"; give "
                                "ent_controlled_actor one with predicate "
                                "\"exists\" or \"is\"; use predicate \"supports\" "
                                "with a capability id as `target` to require "
                                "behaviour. "
                                # A `supports` requirement is entity-scoped, so the
                                # capability has to be ON that entity. The compiler
                                # assigns entity capabilities first and gives any
                                # leftover spec-level capability a world graph with
                                # entity_id=None, which no entity-scoped requirement
                                # can ever match: a museum run listed
                                # camera_control at spec level, required it of the
                                # actor, and failed traceability with
                                # REQUIRED_BEHAVIOR_GRAPH_MISSING. The deterministic
                                # draft has always paired the two on the actor; the
                                # convention simply was never stated to the model.
                                # Physics was invisible to the planner: a lunar
                                # base and a warehouse produced identical falls.
                                "Set `environment.gravity_mps2` when the place "
                                "is not on Earth: Moon 1.62, Mars 3.72, Earth "
                                "9.81. Underwater scenes use a low value (about "
                                "2) to stand in for buoyancy, which is not "
                                "simulated. Omit it and Earth is assumed. "
                                "If you require a capability of an entity, that "
                                "entity's own `capabilities` must list it. The "
                                "controlled actor needs BOTH \"locomotion\" and "
                                "\"camera_control\": the camera binding belongs to "
                                "the actor's controller, not to the world. "
                                # `entities` are the few objects that matter one by
                                # one; `scatter` is the mass content that makes a
                                # place feel inhabited instead of empty. Without
                                # this instruction the planner lists a handful of
                                # entities on bare ground, which reads the same for
                                # every prompt regardless of the subject.
                                "Use `scatter` for the mass content of the place: "
                                "name the species that would actually fill THIS "
                                "kind of environment (free text, e.g. buttress root "
                                "tree, fern cluster, rusted pipe, coral fan), each "
                                "with a plausible density_per_100m2, clustering, and "
                                "near_tags/avoid_tags. Reserve `entities` for the few "
                                "objects that matter individually. "
                                # A run came back with four species all named
                                # "vegetation": they collapse to one asset, so the
                                # world gets one repeated mesh instead of a mix.
                                # A village's boundary wall came back as 59 loose
                                # scatter panels because there was no way to say
                                # "a wall runs from here to there", and the visitor
                                # walked through every one of them.
                                # 55% of entities carried no relation at all and
                                # `facing` was used 0 times in 531 relations, so
                                # buildings landed wherever a seeded dart fell --
                                # 21 m apart in something called a village.
                                # Paving came back as 2,239 loose slabs because the
                                # only way to say "this ground is paved" was to strew
                                # slab-shaped things over it.
                                "Ground that is MADE of something different -- a "
                                "paved courtyard, a cobbled square, a gravel yard, a "
                                "jetty deck -- goes in `regions` as a polygon with a "
                                "surface family. Never scatter slabs, tiles, cobbles "
                                "or gravel to represent a surface: a region is "
                                "painted onto the ground for free and follows its "
                                "slope, while slabs are hundreds of loose objects "
                                "with no collision. "
                                # Measured on five settlement prompts: `routes` and
                                # `regions` came back 0 every time while
                                # `linear_structures` was used four times. The
                                # difference is that the fence guidance names THINGS
                                # ("boundary walls, fences, hedges") and the route
                                # guidance named an abstraction ("the circulation
                                # spine"). A planner cannot match an abstraction
                                # against a prompt.
                                "If the prompt names anything a visitor WALKS ALONG -- "
                                "a street, lane, path, track, road, alley, corridor, "
                                "quay or walkway -- that is a `route`, and it must "
                                "appear in `routes`. If it names ground MADE of "
                                "something -- cobbles, paving, gravel, a square, a "
                                "plaza, a yard, a courtyard, a deck -- that is a "
                                "`region`, and it must appear in `regions`. Neither is "
                                "an entity and neither is scatter. "
                                "A settlement is a STREET with buildings addressing "
                                "it, not buildings with distances between them. "
                                "Declare the lanes and paths in `routes` as "
                                "centreline points, then give every building, shop or "
                                "stall a `placement.frontage` naming the route it "
                                "fronts onto and how far back it stands. Do not reach "
                                "for `facing` between two buildings: a building faces "
                                "the street. Where along the route each one stands is "
                                "worked out from its measured size, so you only have "
                                "to say WHICH route and HOW FAR BACK. "
                                "Anything whose shape is a LINE goes in "
                                "`linear_structures`, never in scatter: boundary "
                                "walls, fences, hedges, railings, jetties. Give the "
                                "two ends in world metres, the height and the "
                                "thickness, and an `openings` entry for every gate or "
                                "gap — a run that closes around anything with no "
                                "opening seals the visitor out of it and the world is "
                                "rejected for being unreachable. "
                                "Every semantic_type must be SPECIFIC and DISTINCT — "
                                "never a category word like vegetation, debris, "
                                "geology, structure or object. "
                                # The sampler spreads instances at random, which is
                                # right for a fern and meaningless for a lamp post.
                                # A village run asked for street lamps as a species
                                # and got 168 of them one every 50 m2 across the
                                # whole map, beside 28 trees -- a lamp farm, because
                                # nothing had ever asked whether position mattered.
                                "Scatter places instances at RANDOM. Set "
                                "`placement_is_incidental: false` on any species that "
                                "belongs somewhere specific -- a lamp beside a path, a "
                                "bench facing something, a crate against a wall -- and "
                                "true for things that grow or lie wherever there is "
                                "room. Anything that matters one by one belongs in "
                                "`entities` with a spatial_relation instead. "
                                # Species have no entity to measure, so without this
                                # a canopy tree and a fern are generated the same size.
                                "Give every species a size_m [width, height, depth] "
                                "for ONE instance: a canopy tree is not a fern. "
                                # Every procedural asset used to be a box, so a
                                # rainforest rendered as a field of rectangles.
                                # The builder knows forms, not species -- naming
                                # the form is the only way it can be anything else.
                                # The vocabulary covered outdoor nature and left
                                # everything else on semantic_box: a museum came
                                # out as correctly-sized coloured blocks because
                                # no form said "a framed thing on a wall".
                                # Scope, stated first and deliberately. This rule
                                # lived inside the paragraph about species, and
                                # the model read it as applying to scatter only:
                                # a museum run chose open_container and
                                # machine_block correctly for its two species,
                                # then gave semantic_box to its painting, its
                                # bench and even its door -- for which
                                # hinged_door_leaf already existed.
                                "This applies to EVERY procedural asset, in "
                                "`entities` exactly as much as in `scatter`. "
                                "Choose the procedural_type that matches each "
                                "thing's FORM: foliage_column for a trunk under a "
                                "crown, ground_cover for low spreading growth, "
                                "irregular_mass for a lump or boulder, "
                                "fallen_column for something long lying down, "
                                "legged_platform for a surface held up on legs "
                                "(table, desk, bench, bed, counter, stall), "
                                "slender_post for an upright shaft (lamp post, "
                                "sign, column, bollard, mast), "
                                "flat_panel for an upright face meant to be "
                                "looked at (painting, screen, notice board, "
                                "window, banner), "
                                "open_container for walls around a void (crate, "
                                "barrel, bin, planter, trough, tank), "
                                "machine_block for apparatus (appliance, console, "
                                "cabinet, generator, kiosk, industrial machine), "
                                "hinged_door_leaf for a door leaf, "
                                "building_shell for an enclosing structure, "
                                "semantic_box only when none of those fit. A door "
                                "given semantic_box is a box in a doorway. "
                                # Forms fixed the shape and left colour a constant,
                                # so every boulder in every world was the same grey
                                # and an oak, a pine and a dead birch were the same
                                # brown trunk under the same green crown.
                                "Give every procedural asset a `palette_hex`: one to "
                                "three hex colours, structural body first (trunk, "
                                "table top, machine body, building walls), then its "
                                "secondary part (crown, legs, head, roof). Colour "
                                "the thing THIS place actually contains -- a pine is "
                                "not a birch, a moss-covered wall is not a clean "
                                "one. Without it every object of a form comes out "
                                "the same colour. "
                                # Same rule one level up: the ground is synthesised
                                # from a named family, and an unnamed one renders
                                # neutral rather than guessed at.
                                "Set environment.terrain_surface to what the ground "
                                "is MADE OF (grass, soil, sand, stone, concrete, "
                                "snow, wood, metal), which is not the same question "
                                "as `terrain`: a 'misty hillside' is still soil "
                                "underfoot. Use 'unspecified' only when none of them "
                                "genuinely fits -- it renders neutral grey. "
                                # Measured: mist became ninety five-metre boulders
                                # because a species named irregular_mass for fog.
                                "Scatter is SOLID OBJECTS resting on the ground. "
                                "Weather, mist, smoke, light and sound have no "
                                "surface -- describe those in environment.weather, "
                                "never as a scatter species. "
                                # The draft is a safety net, not an answer to copy.
                                "safe_draft is only a fallback shape: replace its "
                                "placeholder values (requested_environment, "
                                "contextual_terrain) with what THIS prompt describes. "
                                # When the expand stage ran, the sizes and
                                # densities have already been reasoned about in
                                # prose; formalising them beats inventing new ones.
                                "If a brief is supplied it is an agreed description "
                                "of this place: take its sizes, densities and named "
                                "kinds as given and express them in the schema. "
                                # The brief's `layout` list exists because the
                                # extract stage previously had only `individual`
                                # and `mass`, so a street had to be filed as an
                                # object or as a scattering and stopped being a
                                # street before this prompt was ever read. Five
                                # settlement briefs produced zero routes and zero
                                # paved areas between them. The mapping is stated
                                # rather than implied because two rounds of
                                # softer wording moved nothing.
                                "The brief's `layout` list maps ONE-TO-ONE onto "
                                "this schema and nowhere else: every `route` "
                                "becomes an entry in `routes`, every `area` "
                                "becomes an entry in `regions`, and every `run` "
                                "becomes an entry in `linear_structures`. Do not "
                                "turn any of them into entities or scatter. "
                                # Measured: a brief describing litter and straw in
                                # detail made the planner ENUMERATE them --
                                # ent_apple_core_01, ent_broken_pottery_01, one
                                # entity per object -- and emit no scatter at all.
                                # A described thing is not automatically an entity.
                                "A brief describes many things individually because "
                                "prose has no other way to describe them. Do NOT copy "
                                "that shape: anything that occurs in QUANTITY (litter, "
                                "straw, cobbles, ferns, crates, rubble) is one scatter "
                                "species with a density, however lovingly the brief "
                                "describes a single one of them. Reserve entities for "
                                "the few things a visitor would walk up to, use, or "
                                "navigate by. A place with no scatter is a bug. "
                                # Four field conventions the model gets wrong on
                                # its own. They are documented in the schema, but
                                # the schema reaches the model only through
                                # Ollama's `format` grammar, which carries
                                # structure and NOT descriptions -- so a
                                # convention that is not repeated here is a
                                # convention the model never sees. Each of these
                                # cost a run: measured, not guessed.
                                #
                                # A door came back as [0.1, 2.1, 1.8] -- 1.8 m
                                # DEEP -- and collided with its own doorstep.
                                "bbox_m is [width_x, height_y, depth_z]: the "
                                "MIDDLE number is always the vertical height. Put "
                                "a thin panel's thickness on the axis it is thin "
                                "along — a door is [0.9, 2.1, 0.1], never "
                                "[0.1, 2.1, 1.8]. "
                                # Offsets were measured from the parent's top,
                                # burying doors 1.45 m underground; then 4.06 m
                                # from a 3 m house, leaving one floating; then
                                # with the sign reversed, putting a stoop inside
                                # the wall.
                                "local_offset_m runs from the TARGET'S CENTRE to "
                                "THIS ENTITY'S CENTRE, +Y up. Never from a top, "
                                "base or corner. It must not exceed the two "
                                "half-extents added together, or the parts come "
                                "apart, and it must point OUT of the parent, away "
                                "from what it is mounted on. To hang a 2.1 m door "
                                "on a 4x3x4 m house: [0, -0.45, -2.0]. "
                                # 12 of 15 requirements failed traceability
                                # because the model wrote citation-style
                                # abbreviations with ellipses.
                                "source_text may be copied VERBATIM from "
                                "`quotable_user_prompt` or from "
                                "`quotable_agreed_description` — those two "
                                "only. NEVER from `not_quotable_safe_draft`, "
                                "and never words you thought of yourself. "
                                # Measured: half of all traceability failures on a
                                # twelve-prompt corpus were one described thing
                                # built as several entities -- "a fence" as four
                                # segments -- where only the first could carry a
                                # verbatim-sourced requirement.
                                "When one thing in the description is BUILT from "
                                "several entities, give exactly one of them the "
                                "`exists` requirement and relate every other to it "
                                "with relation `part_of`. Four fence segments for "
                                "one fence: fence_west carries the requirement "
                                "quoting \"a fence\", and north, east and south are "
                                "`part_of` fence_west. Do NOT invent a requirement "
                                "per segment -- there are no words in the prompt to "
                                "source them from. `part_of` groups only and moves "
                                "nothing. "
                                "source_text is copied VERBATIM from the "
                                "prompt — an exact substring, quotable "
                                "character-for-character. No ellipses, no "
                                "rewording, no joining separated phrases. Take the "
                                "shortest span that carries the requirement. "
                                # Measured: the model wanted to cite "each with a
                                # front door, a stoop, ..." for the stoop, found
                                # the words were not contiguous, and bridged the
                                # gap with an ellipsis -- "each with a ... stoop"
                                # -- which is not a substring of anything. Six
                                # requirements failed that way in one run. The
                                # answer is to quote LESS, not to invent glue.
                                "When the words you want are not next to each "
                                "other in the prompt, do NOT bridge them: quote "
                                "only the contiguous fragment that names the "
                                "thing. For \"each with a front door, a stoop, a "
                                "fence post\", the stoop requirement cites "
                                "\"a stoop\" — never \"each with a ... stoop\". "
                                # "a small village" became
                                # 'suburban_residential_frontage'.
                                "If the prompt names an action the visitor "
                                "performs (explore, roam, wander, visit), add "
                                "a requirement on subject \"simulation\" with "
                                "predicate exactly \"can_explore\". That exact "
                                "string is what is checked. "
                                "Build the whole place, including what the "
                                "prompt IMPLIES: a village has houses even "
                                "though the word \"village\" does not list "
                                "them, a street has buildings along it, a farm "
                                "has a barn. A world missing the things its own "
                                "description takes for granted is wrong, however "
                                "faithfully it quotes. "
                                "Every entity needs its own requirement, and "
                                "every requirement needs a verbatim quote — but "
                                "the quote may come from "
                                "`quotable_agreed_description`, which describes "
                                "these implied things in detail. Cite that for "
                                "them. Only put something in `scatter` when it "
                                "genuinely occurs in QUANTITY. "
                                "A requirement states that something EXISTS or "
                                "WORKS — never how it looks. Colours, "
                                "materials and finishes are appearance: put "
                                "them in the asset brief, never in a "
                                "requirement. \"a white paneled front door\" "
                                "gives a requirement that a front door exists "
                                "and opens, with \"white paneled\" living only "
                                "in the brief. A requirement the assets cannot "
                                "be judged against is a promise the system "
                                "cannot keep. "
                                "ent_controlled_actor.semantic_type must "
                                "CONTAIN the prompt's own word for who the "
                                "visitor is: \"As a dog\" gives dog or "
                                "village_dog, never pedestrian_visitor. "
                                "If the prompt states a time of day or "
                                "weather, environment.time_of_day and "
                                "environment.weather must be exactly that "
                                "word — \"at night\" gives night, not "
                                "late_evening. "
                                "Requirement ids must all be distinct. "
                                "environment.semantic_type must CONTAIN, as a "
                                "literal substring, the user's own noun for the "
                                "place. Find the noun in the prompt first, then "
                                "build the value around it. \"a small village\" "
                                "gives village, small_village or village_lane. "
                                # Emitted twice, from a prompt that says
                                # "village" in its first four words. A validator
                                # checks for the user's word and fails without it,
                                # so the reclassification does not merely read
                                # oddly -- it stops the run.
                                "It must NOT be a reclassification of the place: "
                                "suburban_residential_frontage is wrong for "
                                "\"a small village\" because the word village "
                                "does not appear in it. Prefer the user's plain "
                                "word over the more technical one, always. "
                                "Return JSON only."
                            ),
                        },
                        {
                            "role": "user",
                            "content": json.dumps(
                                {
                                    # Named so the model cannot mistake which
                                    # text `source_text` may quote. It was
                                    # `request`/`brief`, and the planner quoted
                                    # the brief -- "House A white paneled door",
                                    # "Red fire hydrant" -- none of which appear
                                    # in what the user typed, so five
                                    # requirements failed traceability while the
                                    # model was, from its point of view, quoting
                                    # faithfully.
                                    "quotable_user_prompt": prompt,
                                    **(
                                        {"quotable_agreed_description": brief}
                                        if brief
                                        else {}
                                    ),
                                    "not_quotable_safe_draft": draft,
                                },
                                separators=(",", ":"),
                            ),
                        },
                    ],
                },
            )
            response.raise_for_status()
            candidate = json.loads(response.json()["message"]["content"])
    except Exception as exc:
        log.warning("neutral simulation planner unavailable: %s", exc)
        return None

    # Geometry is HOW, not WHAT: correct sizes the model could not have checked.
    #
    # See pcg/dimensions.py for the measured failures this exists to stop. A
    # believable declared size survives untouched; an implausible one is
    # replaced and recorded, so the planner's error rate stays visible instead
    # of being quietly absorbed.
    from pcg.dimensions import correct_bbox

    size_corrections: list[dict] = []
    for entity in candidate.get("entities") or []:
        physical = entity.get("physical") or {}
        corrected, reason = correct_bbox(
            physical.get("bbox_m"),
            str(entity.get("semantic_type") or ""),
            str(entity.get("name") or ""),
            str(entity.get("entity_id") or ""),
        )
        physical["bbox_m"] = corrected
        entity["physical"] = physical
        if reason:
            size_corrections.append(
                {"entity_id": entity.get("entity_id"), "reason": reason}
            )
    if size_corrections:
        log.info("corrected %d implausible entity size(s)", len(size_corrections))

    candidate["meta"] = deepcopy(draft["meta"])
    candidate["request"] = deepcopy(draft["request"])
    # Kept on the spec so verification can check a quote against the same
    # text the planner was allowed to quote from.
    if brief:
        candidate["request"]["source_description"] = str(brief)[:20000]
    candidate["lineage"] = deepcopy(draft["lineage"])
    candidate["lineage"]["planner"] = planner_model_id
    _route_through_generation(candidate)
    _normalise_procedural_assets(candidate)
    _normalise_attachments(candidate)
    _normalise_animation_requirement(candidate)
    _normalise_dialogue(candidate)
    _normalise_causal_links(candidate)
    _bound_scatter_density(candidate)
    _bound_positioned_scatter(candidate)
    # Before the asset and attachment passes, so the segments a run produces are
    # ordinary entities by the time anything else looks at them -- they need forms,
    # palettes and traceability exactly as an authored entity does.
    for record in materialise_layout(candidate, _parsed_brief(brief)):
        candidate.setdefault("approximations", []).append(record)
    # BEFORE expansion, not after. `expand_linear_structures` writes each segment's
    # `placement.anchor_m` from the run's own endpoints, and an anchor is a FACT the
    # placer will not move -- so correcting the frame afterwards leaves every segment
    # anchored to the old coordinates and changes nothing at all. Measured: recentring
    # after expansion left all seven warehouse wall segments exactly as unplaced as
    # before.
    _drop_umbrella_runs(candidate)
    # After the umbrella drop: when the parts are already there the whole is
    # redundant, and only a boundary that survived alone needs rebuilding.
    _enclosures_are_perimeters(candidate)
    _centre_authored_layout(candidate)

    for record in expand_linear_structures(candidate):
        candidate.setdefault("approximations", []).append(record)
    _unpave_the_whole_world(candidate)
    _ground_follows_its_vegetation(candidate)
    # AFTER the ground has settled on what it is: cover follows the final surface.
    _ground_carries_its_own_cover(candidate)
    # After cover, and independent of it: a wood needs its canopy even when the
    # planner scattered a forest floor in full detail.
    _a_wood_has_trees(candidate)
    # Last, so it sees every species any earlier rule added.
    _small_incidental_scatter_is_procedural(candidate)
    _set_style_anchor(candidate)
    # Before relations, so both are judged against the same final entity list.
    _normalise_requirements(candidate)
    _normalise_spatial_relations(candidate)
    _reconcile_entities_and_requirements(candidate)
    # After entity reconciliation: a capability's consumer may have just been dropped.
    _reconcile_capabilities(candidate)
    # After capabilities settle, so it judges requirements against the final
    # entity list and the capabilities that survived.
    _a_supports_requirement_names_something_that_can(candidate)
    _dedupe_unique_arrays(candidate)
    # Before the range clamp, which would otherwise lift a zero density to the
    # exclusive minimum and preserve a species that can never place anything.
    empty = _drop_empty_species(candidate)
    if empty:
        log.warning("dropped %d scatter species with zero density: %s", len(empty), empty)
    _normalise_species_ids(candidate)
    clamped = _clamp_entity_bounds(candidate)
    if clamped:
        _record_bound_approximations(candidate, clamped)
        log.warning(
            "planner bounds clamped for %d entity axis value(s): %s",
            len(clamped),
            ", ".join(
                f"{item['entity_id']}[{item['axis']}] {item['requested_m']:.1f}->"
                f"{item['applied_m']:.1f}m"
                for item in clamped[:5]
            ),
        )
    # The declared extent must be able to hold what was declared inside it.
    #
    # Measured on run_fe54172d97b94f6ca972a87fddf8b5b5: a village declared 12x15 m while
    # holding two 8x6 m dwellings. `_zone_geometry` right-sized past that and placement
    # spread content over 31x39 m, but `build_terrain` reads the DECLARATION, so the
    # ground stayed a 12x15 m lattice and most of the village stood past its own edge.
    #
    # Fixed here, in the planner, rather than in terrain: writing the honest number into
    # the spec once means every later reader agrees without any of them deriving its own
    # extent. Deriving it inside terrain also worked and was reverted -- it made the
    # heightfield a function of the content, so adding one entity during a repair
    # re-seated every entity and broke locality of repair (CLAUDE.md §7).
    #
    # Safe here because it is idempotent and the planner runs once: a localized repair
    # re-runs a node, not this, so the number does not move underneath a built world.
    # BEFORE the fitter, which only ever grows: the walls set the floor, and a world
    # that genuinely needs more room than its walls suggest still gets it.
    # NOT shrinking a walled world to its walls. Tried and measured: the warehouse's
    # perimeter encloses 40x60m, but the spec ALSO carries four free-standing wall
    # entities that need ground of their own, and taking the ground away left four
    # segments unplaced and the four entities missing entirely -- 18/18 gates down to
    # 8/18. `pcg.semantic` already carries the same finding in its own words: "every
    # attempt to size it down broke placement on real specs". The world stays generous;
    # what needed fixing was WHERE scatter lands, which is fixed in the sampler.
    _a_world_holds_enough_of_what_defines_it(candidate)
    _fit_declared_dimensions(candidate)
    # Entity footprints are clamped first, above, because they can say WHICH
    # object was resized. This catches everything else the grammar left
    # unbounded, so a single bad number never costs the whole world again.
    ranged = _clamp_out_of_range_numbers(candidate)
    if ranged:
        _record_range_approximations(candidate, ranged)
        log.warning(
            "planner values clamped to schema range: %s",
            ", ".join(
                f"{item['path']} {item['requested']:g}->{item['applied']:g}"
                for item in ranged[:5]
            ),
        )
    # The declared version must describe what the spec actually uses, not whatever
    # the model happened to pick from the enum: 1.1.0 only when a 1.1 field
    # (scatter) is present, so a consumer reading 1.0.0 can trust that shape.
    candidate["schema_version"] = "1.1.0" if candidate.get("scatter") else "1.0.0"
    try:
        validate_simulation_spec(candidate)
    except jsonschema.ValidationError as exc:
        log.warning("neutral planner output rejected at %s: %s", list(exc.path), exc.message)
        return None
    return candidate


def plan_simulation(
    *,
    prompt: str,
    simulation_id: str,
    seed: int,
    size_profile: str,
    target_platforms: list[str],
    domain_constraints: dict | None,
    settings,
    planner_model_id: str | None = None,
    planner_base_url: str | None = None,
    brief: str | None = None,
) -> tuple[dict, str]:
    """Plan a spec, optionally from an already-expanded description of the place.

    `brief` is the output of the expand stage. It is an input, never a
    requirement: planning from the raw prompt alone remains fully supported, so
    the stage can be disabled, fail, or simply not exist yet.
    """
    draft = _deterministic_draft(
        prompt,
        simulation_id,
        seed,
        size_profile,
        target_platforms,
        domain_constraints,
    )
    validate_simulation_spec(draft)
    if planner_model_id and planner_base_url:
        planned = _llm_plan(
            prompt,
            draft,
            settings,
            planner_model_id=planner_model_id,
            planner_base_url=planner_base_url or settings.llm_base_url,
            brief=brief,
        )
        if planned is not None:
            return planned, "llm_expanded" if brief else "llm"
        # The call was attempted and did not produce a usable spec. `_llm_plan`
        # has already logged why (unreachable endpoint, or output rejected at a
        # schema path), but neither line says what the consequence is, so the
        # two together still read as a warning rather than as "your world is
        # about to be the built-in one".
        log.warning(
            "planner %s produced no usable spec for %s; falling back to the "
            "built-in draft, so the generated world will NOT reflect this "
            "prompt. The lineage gate will refuse to publish it.",
            planner_model_id,
            simulation_id,
        )
    else:
        # Not a failure: nobody asked for a model. This is the silent path that
        # `scripts/brain_only.py` calls the number-one source of "why is the
        # world generic?", because a missing route looks exactly like a working
        # run until someone reads `lineage.planner`.
        log.warning(
            "no planner model supplied for %s (model_id=%r, base_url=%r); "
            "using the built-in draft, which ignores the prompt.",
            simulation_id,
            planner_model_id,
            planner_base_url,
        )
    return draft, "deterministic_fallback"


def apply_localized_edit(spec: dict, instruction: str) -> tuple[dict, list[str], list[str]]:
    """Apply a bounded semantic delta without regenerating unrelated regions."""
    edited = deepcopy(spec)
    lower = instruction.lower().strip()
    changed: list[str] = []
    rejected: list[str] = []

    weather = next(
        (value for value in ("rain", "snow", "fog", "clear") if value in lower),
        None,
    )
    if weather:
        edited["environment"]["weather"] = weather
        changed.append("environment.weather")
    time_of_day = next(
        (value for value in ("night", "day", "dusk") if value in lower),
        None,
    )
    if time_of_day:
        edited["environment"]["time_of_day"] = time_of_day
        changed.append("environment.time_of_day")
    if "medium" in lower or "larger" in lower:
        edited["request"]["size_profile"] = "medium"
        edited["environment"]["dimensions_m"].update(
            {"width": 1000, "depth": 1000, "max_height": 160}
        )
        changed.append("environment.dimensions_m")
    elif "small" in lower or "smaller" in lower:
        edited["request"]["size_profile"] = "small"
        edited["environment"]["dimensions_m"].update(
            {"width": 500, "depth": 500, "max_height": 80}
        )
        changed.append("environment.dimensions_m")

    add_match = re.search(r"\badd\s+(?:a|an|some)\s+([a-z][a-z -]{1,40})", lower)
    if add_match:
        noun = add_match.group(1).split(" near ")[0].split(" beside ")[0].strip()
        new_entity = _entity(
            f"added_{noun}_{len(edited['entities']) + 1}",
            noun.title(),
            noun,
            "user_added",
            brief=f"a 3D model of {noun}, added by a localized user edit",
        )
        edited["entities"].append(new_entity)
        edited["requirements"].append(
            {
                "requirement_id": f"req_edit_{_slug(noun)}_{len(edited['requirements']) + 1}",
                "source_text": instruction,
                "subject": new_entity["entity_id"],
                "predicate": "exists",
                "target": noun,
                "priority": "required",
                "observable": f"The added {noun} is present and correctly placed",
                "tolerance": None,
                "validator": "entity_presence",
                "evidence": [],
            }
        )
        changed.append(f"entities.{new_entity['entity_id']}")

    if not changed:
        rejected.append(
            "The instruction does not map to an installed bounded edit capability"
        )
        return spec, changed, rejected

    edited["request"]["prompt"] = (
        f"{spec['request']['prompt']}\nLocalized edit: {instruction}"
    )[:4000]
    edited["lineage"]["prompt_hash"] = hashlib.sha256(
        edited["request"]["prompt"].encode("utf-8")
    ).hexdigest()
    edited["lineage"]["created_at"] = datetime.now(UTC).isoformat()
    validate_simulation_spec(edited)
    return edited, changed, rejected
