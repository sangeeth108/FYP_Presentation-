"""Decomposition patterns: an archetype -> its interactable parts + sockets.

The brain side of ADR-0008. An LLM must never hand-author socket coordinates
(rule 10 — it selects, it does not engineer geometry). Instead it names an
ARCHETYPE from a fixed menu ("vehicle", "building", "chest", …) and this vetted
library expands that into the exact part/socket layout the project writer
consumes. So "a car" reliably becomes a body with two doors that hinge at the
right edges, every time, deterministically — the LLM chose the kind, the pattern
decided the parts.

`expand()` returns the plain-dict composite shape `write_project(composites=...)`
already accepts (parsed by `project_writer._composite_from_dict`), so the LLM
output flows straight through the deterministic spine with no bespoke geometry.

Adding an affordance to the world is: add a pattern here (data), pointing at a
vetted behaviour template — never new code.
"""

from __future__ import annotations

import random

# A pattern is a list of parts; each part is a socket on the parent's NORMALISED
# bbox (x,z in [-0.5,0.5], y in [0,1]) bound to a behaviour template. Kept as data
# so a new archetype is a new entry, not new code.
PATTERNS: dict[str, list[dict]] = {
    # A vehicle: a door on each side, hinged at the front edge, opening outward.
    # Car doors swing less than a house door.
    "vehicle": [
        {"part_id": "door_l", "template_id": "door_hinged",
         "offset": (-0.5, 0.0, 0.15), "facing_deg": 90.0, "params": {"open_angle_deg": -70.0}},
        {"part_id": "door_r", "template_id": "door_hinged",
         "offset": (0.5, 0.0, 0.15), "facing_deg": -90.0, "params": {"open_angle_deg": -70.0}},
    ],
    # A building: a front door, dead centre on the front face, full 90deg swing.
    "building": [
        {"part_id": "front_door", "template_id": "door_hinged",
         "offset": (0.0, 0.0, 0.5), "facing_deg": 0.0, "params": {"open_angle_deg": -90.0}},
    ],
    # A cabinet/wardrobe: a pair of front doors meeting in the middle.
    "cabinet": [
        {"part_id": "door_l", "template_id": "door_hinged",
         "offset": (-0.5, 0.0, 0.5), "facing_deg": 0.0, "params": {"open_angle_deg": -110.0}},
        {"part_id": "door_r", "template_id": "door_hinged",
         "offset": (0.5, 0.0, 0.5), "facing_deg": 0.0, "params": {"open_angle_deg": 110.0}},
    ],
    # A chest/crate: a single lid, hinged at the back, plus loot at the top.
    "chest": [
        {"part_id": "lid", "template_id": "door_hinged",
         "offset": (0.0, 1.0, -0.5), "facing_deg": 0.0, "hinge": "y",
         "params": {"open_angle_deg": -100.0}},
        {"part_id": "loot", "template_id": "pickup_collectible",
         "offset": (0.0, 0.6, 0.0), "facing_deg": 0.0},
    ],
    # A gate/door in a wall: one hinged leaf.
    "gate": [
        {"part_id": "leaf", "template_id": "door_hinged",
         "offset": (0.0, 0.0, 0.0), "facing_deg": 0.0, "params": {"open_angle_deg": -95.0}},
    ],
}

# Words the planner (or a prompt) might use -> the archetype above. First match
# wins, so order the more specific words first if any overlap.
_ARCHETYPE_WORDS: dict[str, str] = {
    "car": "vehicle", "truck": "vehicle", "van": "vehicle", "jeep": "vehicle",
    "bus": "vehicle", "vehicle": "vehicle", "cart": "vehicle", "wagon": "vehicle",
    "carriage": "vehicle", "tank": "vehicle", "buggy": "vehicle",
    "house": "building", "cottage": "building", "hut": "building", "cabin": "building",
    "building": "building", "shack": "building", "home": "building", "shop": "building",
    "store": "building", "tavern": "building", "barn": "building", "temple": "building",
    "cabinet": "cabinet", "wardrobe": "cabinet", "cupboard": "cabinet", "locker": "cabinet",
    "chest": "chest", "crate": "chest", "coffer": "chest", "trunk": "chest", "box": "chest",
    "gate": "gate", "gateway": "gate", "portcullis": "gate", "doorway": "gate",
}


def known_archetypes() -> frozenset[str]:
    """The fixed menu the planner may choose from (rule 10)."""
    return frozenset(PATTERNS)


def classify_archetype(text: str) -> str | None:
    """Map a free-text object name/brief to an archetype, or None if we own no
    decomposition for it (then it stays a plain, non-interactive prop)."""
    if not text:
        return None
    words = text.lower().replace("-", " ").split()
    for w in words:
        hit = _ARCHETYPE_WORDS.get(w)
        if hit is not None:
            return hit
    return None


def expand(obj: dict) -> dict | None:
    """Expand a chosen archetype into the composite dict the writer consumes.

    `obj` = {object_id, archetype (or archetype omitted -> classify from name/brief),
    bbox:[w,h,d], origin:[x,y,z], yaw_deg?, parent_mesh_rel?}. Returns None when no
    pattern matches — the caller then treats it as an ordinary prop, never a crash.
    Deterministic: the same object always expands to the same parts.
    """
    archetype = obj.get("archetype") or classify_archetype(
        obj.get("name", "") or obj.get("brief", "")
    )
    pattern = PATTERNS.get(archetype) if archetype else None
    if not pattern:
        return None

    parts = [
        {
            "part_id": p["part_id"],
            "template_id": p["template_id"],
            "socket": {
                "name": p["part_id"],
                "offset": list(p["offset"]),
                "facing_deg": p.get("facing_deg", 0.0),
                "hinge": p.get("hinge", "y"),
            },
            "params": dict(p.get("params", {})),
        }
        for p in pattern
    ]
    composite = {
        "object_id": obj["object_id"],
        "archetype": archetype,
        "bbox": list(obj["bbox"]),
        "origin": list(obj.get("origin", (0.0, 0.0, 0.0))),
        "yaw_deg": float(obj.get("yaw_deg", 0.0)),
        "parts": parts,
    }
    if obj.get("parent_mesh_rel"):
        composite["parent_mesh_rel"] = obj["parent_mesh_rel"]
    return composite


def expand_all(objects: list[dict]) -> list[dict]:
    """Expand every object that has a known archetype; drop the rest (plain props).
    The single call the worker makes before write_project(composites=...)."""
    out: list[dict] = []
    for obj in objects or []:
        composite = expand(obj)
        if composite is not None:
            out.append(composite)
    return out


# Clearance kept between an object's footprint and its room's walls, so a car
# never spawns clipping into geometry (and the affordance oracle can swing its
# doors).
_ROOM_MARGIN = 1.5


def place_objects(objects: list[dict], rooms: list[dict], seed: int) -> list[dict]:
    """Give each authored object a world origin + yaw, deterministically (rule 14).

    Spreads objects across rooms (one per room, cycled), centred on a room whose
    footprint it FITS with clearance; an object too big for any room is dropped
    rather than placed clipping through walls. Returns authored objects each with
    `origin`/`yaw_deg` added — ready for `expand_all`. Placement is derived from
    the seed, never stored, so a rebuild reproduces it.
    """
    if not objects or not rooms:
        return []
    rng = random.Random((seed & 0x7FFFFFFF) ^ 0x0B1EC7)  # salt distinct from other placers
    order = list(rooms)
    rng.shuffle(order)
    placed: list[dict] = []
    for i, obj in enumerate(objects):
        bbox = obj.get("bbox") or [1.0, 1.0, 1.0]
        w, d = float(bbox[0]), float(bbox[2])
        room = _first_fitting_room(order, i, w, d)
        if room is None:
            continue  # too big for any room — drop, don't clip
        out = dict(obj)
        out["origin"] = [
            room["x"] + room["width"] / 2.0,
            room.get("elevation", 0.0),
            room["z"] + room["depth"] / 2.0,
        ]
        out["yaw_deg"] = float(rng.choice([0.0, 90.0, 180.0, 270.0]))
        placed.append(out)
    return placed


def _first_fitting_room(rooms: list[dict], start: int, w: float, d: float) -> dict | None:
    """The next room (from `start`, cycling) whose footprint fits w×d with margin."""
    n = len(rooms)
    for k in range(n):
        room = rooms[(start + k) % n]
        if (room["width"] - w >= _ROOM_MARGIN) and (room["depth"] - d >= _ROOM_MARGIN):
            return room
    return None
