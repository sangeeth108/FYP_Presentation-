"""Stage 2 -- extract: prose becomes a structured SceneBrief.

The stage exists to make one decision explicit that the planner was previously
making as a by-product of filling a large schema: **which things exist
individually, and which exist in quantity**. Getting it wrong is not a cosmetic
problem. Measured on ten prompts, a rich prose brief handed straight to the
planner caused it to enumerate what it should have abstracted --
`ent_apple_core_01`, `ent_broken_pottery_01`, eight numbered market stalls --
and four of ten worlds ended up with no mass content at all
(`docs/DEFECTS_AND_DECISIONS.md` #18).

Asking that question on its own, against a small schema, is a different task
from writing a SimulationSpec. The brief has two lists and forces a reason for
every individual thing, because it is hard to justify an eighth market stall and
easy to justify the fountain.

Unlike `expand` this IS guided JSON, and the schema is deliberately tiny: the
reasoning already happened upstream, so all that is wanted here is a faithful
reading of it.

Fail-soft, like every stage before the spec: a missing model, a timeout or a
brief that will not validate returns None, and planning proceeds from whatever
it already had.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import httpx
import jsonschema

from agents.schema_bounds import clamp_to_schema, dedupe_unique_arrays

log = logging.getLogger(__name__)
_SCHEMA_PATH = Path(__file__).resolve().parents[3] / "contracts" / "scene_brief.schema.json"


@lru_cache(maxsize=1)
def scene_brief_schema() -> dict:
    return json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))


def ollama_brief_schema() -> dict:
    """The brief schema in the grammar adapter's supported subset.

    Same treatment as the SimulationSpec view: the adapter rejects string-length
    bounds while building its grammar. The untouched schema still validates the
    result, so this can never weaken the contract.
    """
    from copy import deepcopy

    def normalize(node: object) -> object:
        if isinstance(node, list):
            return [normalize(value) for value in node]
        if not isinstance(node, dict):
            return node
        return {
            key: normalize(value)
            for key, value in node.items()
            if key not in {"$schema", "$id", "minLength", "maxLength"}
        }

    view = normalize(deepcopy(scene_brief_schema()))
    if not isinstance(view, dict):
        raise TypeError("SceneBrief schema must be an object")
    return view


_SYSTEM = (
    "Read the description and record what is in this place.\n\n"
    "Before either list: anything whose shape is a LINE or an AREA goes in "
    "`layout`, not in `individual` and not in `mass`. Streets, lanes, paths and "
    "quays are `route`. Cobbles, paving, gravel, squares, plazas, yards and decks "
    "are `area`. Walls, fences, hedges, railings and jetties are `run`. A street "
    "forced into `individual` becomes one object and forced into `mass` becomes a "
    "scattering of fragments; either way the place loses its street.\n\n"
    "The only judgement that matters here: put a thing in `individual` if a "
    "visitor would walk up to it, use it, or navigate by it, and in `mass` if it "
    "occurs in quantity. A description names things one at a time because prose "
    "has no other way to; do not copy that shape. Straw, litter, cobbles, ferns, "
    "crates, rubble and shards are `mass` however carefully the description "
    "dwells on a single one of them. Eight numbered copies of one kind are "
    "`mass`, not eight individuals.\n\n"
    "Every entry in `individual` needs a reason it is placed once. If the reason "
    "is only that the description mentioned it, it belongs in `mass`.\n\n"
    "Every kind needs its own specific name, different from all the others: six "
    "entries called `debris` become six copies of one mesh. Say what the debris "
    "IS -- shattered ceiling tile, rusted rail clip, waterlogged newspaper.\n\n"
    "`mass` should rarely be empty: most of any real place is its mass content. "
    "Densities are per 10 m x 10 m patch — ground cover that touches runs into "
    "the hundreds, mature trees are single digits. Sizes are of ONE instance, in "
    "metres.\n\n"
    # Measured, and consistent across every run examined: the extractor writes
    # [width, DEPTH, height] and the middle number silently becomes the height
    # everything downstream builds from. A fence post came out [0.1, 0.1, 1.8]
    # -- 0.1 m tall and 1.8 m long, so it rendered as a plank lying on the
    # ground. An oak came out [0.4, 0.4, 8] and lay on its side. Two houses
    # described in the same brief as "3 metres to the roof peak" came out
    # [12, 8, 3]: eight metres tall. The schema cannot say this, because the
    # grammar carries structure and not descriptions.
    "`size_m` is [width_x, HEIGHT_y, depth_z] and the MIDDLE number is always "
    "the vertical height — not the depth. A 1.8 m fence post 0.1 m square is "
    "[0.1, 1.8, 0.1]; an 8 m tree with a 0.4 m trunk is [0.4, 8, 0.4]; a house "
    "12 m wide, 8 m deep and 3 m to the roof is [12, 3, 8]. Check each entry: if "
    "the middle number is not how TALL the thing stands, the numbers are in the "
    "wrong order. Return JSON only."
)


@dataclass(frozen=True)
class Extraction:
    brief: dict
    model_id: str
    duration_ms: int

    def as_stage_payload(self) -> dict:
        return {
            "brief": self.brief,
            "model_id": self.model_id,
            "duration_ms": self.duration_ms,
            "individual_count": len(self.brief.get("individual") or []),
            "mass_count": len(self.brief.get("mass") or []),
        }


def extract_brief(
    description: str,
    *,
    settings,
    model_id: str | None,
    base_url: str | None,
    seed: int = 0,
) -> Extraction | None:
    """Read an expanded description into a SceneBrief, or None to proceed without one."""
    if not model_id or not base_url or not (description or "").strip():
        return None

    started = time.monotonic()
    try:
        with httpx.Client(
            base_url=base_url, timeout=settings.llm_timeout_seconds
        ) as client:
            response = client.post(
                "/api/chat",
                json={
                    "model": model_id,
                    "stream": False,
                    "format": ollama_brief_schema(),
                    "think": False,
                    "keep_alive": "30m",
                    # Low: this is a faithful reading, not an act of imagination.
                    "options": {"temperature": 0.1, "seed": seed},
                    "messages": [
                        {"role": "system", "content": _SYSTEM},
                        {"role": "user", "content": description.strip()},
                    ],
                },
            )
            response.raise_for_status()
            brief = json.loads(response.json()["message"]["content"])
    except Exception as exc:
        log.warning("scene brief extraction unavailable: %s", exc)
        return None

    # The same repair the SimulationSpec gets, for the same reason: a grammar
    # cannot enforce a numeric range, and rejecting the brief over one costs the
    # whole stage. Measured before this was applied -- three of ten briefs were
    # thrown away for `per_100m2: 10000` against a 5000 cap and `width: 4`
    # against an 8 m floor, both of which are accurate readings of dense ground
    # cover and a narrow corridor.
    dedupe_unique_arrays(brief, scene_brief_schema())
    clamped = clamp_to_schema(brief, scene_brief_schema())
    if clamped:
        log.warning(
            "scene brief values clamped to schema range: %s",
            ", ".join(
                f"{item['path']} {item['requested']:g}->{item['applied']:g}"
                for item in clamped[:5]
            ),
        )

    try:
        jsonschema.validate(brief, scene_brief_schema())
    except jsonschema.ValidationError as exc:
        log.warning("scene brief rejected at %s: %s", list(exc.path), exc.message)
        return None

    return Extraction(
        brief=brief,
        model_id=model_id,
        duration_ms=int((time.monotonic() - started) * 1000),
    )


def brief_as_planner_input(extraction: Extraction) -> str:
    """Compact JSON for the planner: the agreed reading, not the prose."""
    return json.dumps(extraction.brief, separators=(",", ":"), sort_keys=True)
