"""Stage 1 -- expand: a short prompt becomes a concrete description.

Why this stage exists at all. Until now the planner did everything in one
guided-JSON call: intake, design, sizing, density and capability selection, all
in a single pass with no room to think before it had to be precise. The measured
cost is recorded in `docs/DEFECTS_AND_DECISIONS.md` #6 -- a Mars base asked for
10,000 scatter instances per 100 m2 against a cap of 200, and ten of ten species
omitted their size, because nobody ever asked "how many boulders fit in a
hundred square metres?" as a separate question.

So this stage asks the questions in prose first, where the model can reason,
and the planner then formalises an answer it has already worked out. That is the
conceptualization step in 3D-GPT and the reasoning half of Holodeck's pipeline;
here it is one cheap call in front of an expensive one.

Deliberately NOT guided JSON. Constraining this output to a schema would
reintroduce exactly the problem it exists to solve: the value is in unbounded
reasoning about a place, and the structure comes later.

Deliberately fail-soft. An expansion is an improvement, not a dependency: if the
model is unavailable, slow, or returns nothing usable, planning proceeds from
the raw prompt exactly as it did before. A world that is merely as good as
yesterday's beats no world at all.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass

import httpx

log = logging.getLogger(__name__)

# Long enough to be concrete, short enough that the planner's context is still
# mostly schema. Measured: 27B expansions land around 200-400 words unprompted.
_MAX_DESCRIPTION_CHARS = 4000
# Below this the model has said nothing useful (a refusal, an echo of the
# prompt, an empty string) and the raw prompt is the better input.
_MIN_DESCRIPTION_CHARS = 120

_SYSTEM = (
    "You are describing a real place so that a 3D world can be built from it. "
    "Write plain prose, not JSON, not a list of headings.\n\n"
    "Cover, in whatever order reads naturally:\n"
    "- What this place actually is, specifically. Name the region, era or type "
    "rather than a category.\n"
    "- The few objects that matter individually, and roughly how big each is in "
    "metres.\n"
    "- The mass content that fills the space -- the trees, rocks, litter, "
    "machinery, coral, whatever this place is made of. Name real kinds, not "
    "'vegetation' or 'debris'. Say how big ONE of each is, and how densely they "
    "occur in a way a person could check: 'a mature tree every eight metres or "
    "so', 'ferns carpeting most of the ground between them'.\n"
    "- The ground itself, the light, the weather, the time of day.\n"
    "- How large the whole place is, in metres, and why that size suits it.\n\n"
    "Be concrete and physically plausible. Densities and sizes must be ones you "
    "would defend if measured: a 30 m rainforest tree cannot occur ten times in "
    "a 10 m square. Describe only what the request implies -- invent nothing "
    "the request rules out, and do not add a story, characters or objectives."
)


@dataclass(frozen=True)
class Expansion:
    """The description plus what it costs to say where it came from."""

    description: str
    model_id: str
    duration_ms: int

    def as_stage_payload(self) -> dict:
        return {
            "description": self.description,
            "model_id": self.model_id,
            "duration_ms": self.duration_ms,
            "characters": len(self.description),
        }


def expand_prompt(
    prompt: str,
    *,
    settings,
    model_id: str | None,
    base_url: str | None,
    seed: int = 0,
) -> Expansion | None:
    """Turn a short prompt into a concrete description, or None to proceed without one."""
    if not model_id or not base_url or not prompt.strip():
        return None

    started = time.monotonic()
    try:
        with httpx.Client(
            base_url=base_url, timeout=settings.llm_timeout_seconds
        ) as client:
            response = client.post(
                "/api/chat",
                json={
                    "model": model_id,
                    "stream": False,
                    "think": False,
                    "keep_alive": "30m",
                    "options": {
                        # Warmer than planning (0.2): this stage is meant to
                        # imagine a place, and the seed keeps it reproducible.
                        "temperature": 0.7,
                        "seed": seed,
                    },
                    "messages": [
                        {"role": "system", "content": _SYSTEM},
                        {"role": "user", "content": prompt.strip()},
                    ],
                },
            )
            response.raise_for_status()
            description = str(response.json()["message"]["content"]).strip()
    except Exception as exc:
        # Never fatal: planning falls back to the raw prompt.
        log.warning("prompt expansion unavailable, planning from the raw prompt: %s", exc)
        return None

    if len(description) < _MIN_DESCRIPTION_CHARS:
        log.warning(
            "prompt expansion too short to be useful (%d chars); using the raw prompt",
            len(description),
        )
        return None

    return Expansion(
        description=description[:_MAX_DESCRIPTION_CHARS],
        model_id=model_id,
        duration_ms=int((time.monotonic() - started) * 1000),
    )
