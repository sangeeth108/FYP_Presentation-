"""Serendib simulation orchestration API.

Run (dev):   uvicorn main:app --reload
Run (prod):  handled by the container (alembic upgrade head && uvicorn ...)
             — see infra/docker/brain.Dockerfile
"""

from __future__ import annotations

from pathlib import Path

from api import (
    edits,
    engine,
    events,
    feedback,
    games,
    health,
    jobs,
    learning,
    privacy,
    registries,
    simulations,
)
from core.config import get_settings
from core.observability import configure_request_controls
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles


def create_app() -> FastAPI:
    settings = get_settings()
    settings.validate_production()
    app = FastAPI(
        title="Serendib Simulation API",
        version="1.0.0",
        description=(
            "Natural language to verified deterministic browser and desktop simulations."
        ),
    )
    app.description = (
        "Natural language to verified, deterministic browser and desktop "
        "3D simulations."
    )
    configure_request_controls(app)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(health.router)
    app.include_router(games.router, prefix="/api/v1")
    app.include_router(jobs.router, prefix="/api/v1")
    app.include_router(events.router, prefix="/api/v1")
    app.include_router(edits.router, prefix="/api/v1")
    app.include_router(privacy.router, prefix="/api/v1")
    app.include_router(feedback.router, prefix="/api/v1")
    app.include_router(simulations.router, prefix="/api/v1")
    app.include_router(registries.router, prefix="/api/v1")
    app.include_router(engine.router, prefix="/api/v1")
    app.include_router(learning.router, prefix="/api/v1")

    # Published web builds (P1 local serving; R2 + signed URLs replace this in P3).
    if settings.promptplay_env != "production":
        artifacts_dir = Path(settings.artifacts_dir).resolve()
        artifacts_dir.mkdir(parents=True, exist_ok=True)
        app.mount(
            "/artifacts",
            StaticFiles(directory=str(artifacts_dir), html=True),
            name="artifacts",
        )
    return app


app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
