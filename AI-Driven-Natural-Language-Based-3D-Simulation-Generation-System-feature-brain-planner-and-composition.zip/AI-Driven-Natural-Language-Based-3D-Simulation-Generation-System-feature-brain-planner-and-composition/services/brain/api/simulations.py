"""Canonical neutral simulation API."""

from __future__ import annotations

import hashlib

from core.audit import record_audit
from core.ids import new_resource_id, new_simulation_id
from core.models import (
    CapabilityGap,
    GenerationRun,
    Simulation,
    SimulationArtifact,
    SimulationSpecRecord,
    StageArtifact,
    ValidationEvidence,
    WorldPlanRecord,
)
from core.quotas import QuotaExceeded, reserve_generation_slot
from core.schemas import (
    ArtifactInfo,
    CreateSimulationRequest,
    CreateSimulationResponse,
    SimulationEditRequest,
    SimulationReportResponse,
    SimulationResponse,
    SimulationRunResponse,
    StageEditRequest,
    StageListResponse,
    StagePayloadResponse,
    StageSummaryResponse,
)
from core.security import (
    Principal,
    current_principal,
    ensure_generation_age_eligible,
    ensure_principal_records,
    tenant_db,
)
from core.validation_contract import MANDATORY_VALIDATION_LAYERS
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from worker.simulation_tasks import run_simulation_generation

router = APIRouter(tags=["simulations"])


def _owned_simulation(
    db: Session, simulation_id: str, principal: Principal
) -> Simulation:
    simulation = (
        db.query(Simulation)
        .filter_by(id=simulation_id, tenant_id=principal.tenant_id)
        .one_or_none()
    )
    if simulation is None:
        raise HTTPException(status_code=404, detail="simulation not found")
    return simulation


def _size_profile(body: CreateSimulationRequest) -> str:
    if body.size_profile != "auto":
        return body.size_profile
    lower = body.prompt.lower()
    return "medium" if any(word in lower for word in ("medium", "large", "sprawling")) else "small"


@router.post(
    "/simulations", status_code=202, response_model=CreateSimulationResponse
)
def create_simulation(
    body: CreateSimulationRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> CreateSimulationResponse:
    ensure_principal_records(db, principal)
    ensure_generation_age_eligible(db, principal)
    prompt = body.prompt.strip()
    simulation_id = new_simulation_id(prompt[:48])
    run_id = new_resource_id("run")
    seed = body.seed
    if seed is None:
        # Masked to 31 bits: `seed` is a signed 32-bit INTEGER column, and 8 hex
        # digits are a 32-bit UNSIGNED value that overflows it for roughly half of
        # all prompts (anything hashing to >= 0x80000000), which failed simulation
        # creation with DataError: integer out of range. Determinism only needs a
        # stable per-prompt value, and the seeded PCG derives its RNG from
        # str(seed), so masking cannot change reproducibility semantics.
        seed = int(hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:8], 16) & 0x7FFFFFFF
    targets = list(dict.fromkeys(body.target_platforms))
    simulation = Simulation(
        id=simulation_id,
        tenant_id=principal.tenant_id,
        owner_id=principal.user_id,
        title=prompt[:120],
        prompt=prompt,
        size_profile=_size_profile(body),
        target_platforms=targets,
        seed=seed,
        status="queued",
        current_run_id=run_id,
        residency_region="local",
        retention_class="standard",
    )
    run = GenerationRun(
        id=run_id,
        simulation_id=simulation_id,
        tenant_id=principal.tenant_id,
        owner_id=principal.user_id,
        state="queued",
        stage="intake",
        detail={
            "domain_constraints": body.domain_constraints,
            "training_rights_attested": body.training_rights_attested,
        },
    )
    # The run references the simulation by scalar ID rather than an ORM
    # relationship. Flush the parent explicitly so PostgreSQL never chooses an
    # invalid child-first insert order. SQLite hid this unless FK enforcement
    # was enabled in the test connection.
    db.add(simulation)
    db.flush()
    db.add(run)
    db.flush()
    try:
        reserve_generation_slot(db, principal.tenant_id, run_id)
    except QuotaExceeded as exc:
        db.rollback()
        raise HTTPException(
            status_code=429,
            detail={"code": exc.code, "message": exc.message},
            headers={"Retry-After": str(exc.retry_after_seconds)},
        ) from exc
    record_audit(
        db,
        principal,
        "simulation.created",
        "simulation",
        simulation_id,
        {"run_id": run_id, "size_profile": simulation.size_profile, "targets": targets},
    )
    db.commit()
    run_simulation_generation.delay(run_id)
    return CreateSimulationResponse(simulation_id=simulation_id, run_id=run_id)


@router.get("/runs/{run_id}", response_model=SimulationRunResponse)
def get_run(
    run_id: str,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> SimulationRunResponse:
    run = (
        db.query(GenerationRun)
        .filter_by(id=run_id, tenant_id=principal.tenant_id)
        .one_or_none()
    )
    if run is None:
        raise HTTPException(status_code=404, detail="run not found")
    return SimulationRunResponse(
        run_id=run.id,
        simulation_id=run.simulation_id,
        state=run.state,
        stage=run.stage,
        detail=run.detail or {},
        repair_attempts=run.repair_attempts,
        max_repair_attempts=run.max_repair_attempts,
    )


def _owned_run(db: Session, run_id: str, principal: Principal) -> GenerationRun:
    """The run, or 404 — never leak another tenant's run through the inspector."""
    run = (
        db.query(GenerationRun)
        .filter_by(id=run_id, tenant_id=principal.tenant_id)
        .one_or_none()
    )
    if run is None:
        raise HTTPException(status_code=404, detail="run not found")
    return run


@router.get("/runs/{run_id}/stages", response_model=StageListResponse)
def list_run_stages(
    run_id: str,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> StageListResponse:
    """The stage rail: what ran, what it concluded, how long it took.

    Summaries only. The full payload is a separate request so opening a run does
    not pull every scene graph and asset manifest it produced.
    """
    _owned_run(db, run_id, principal)
    rows = (
        db.query(StageArtifact)
        .filter_by(run_id=run_id)
        .order_by(StageArtifact.ordinal, StageArtifact.created_at)
        .all()
    )
    return StageListResponse(
        run_id=run_id,
        stages=[
            StageSummaryResponse(
                stage=row.stage,
                ordinal=row.ordinal,
                status=row.status,
                summary=row.summary or {},
                errors=row.errors or [],
                model_id=row.model_id,
                duration_ms=row.duration_ms,
                edited=row.edited,
            )
            for row in rows
        ],
    )


@router.get("/runs/{run_id}/stages/{stage}", response_model=StagePayloadResponse)
def get_run_stage(
    run_id: str,
    stage: str,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> StagePayloadResponse:
    """One stage's full output — the JSON the inspector shows and lets you edit."""
    _owned_run(db, run_id, principal)
    row = (
        db.query(StageArtifact)
        .filter_by(run_id=run_id, stage=stage)
        .one_or_none()
    )
    if row is None:
        raise HTTPException(status_code=404, detail=f"stage '{stage}' has not run")
    return StagePayloadResponse(
        stage=row.stage,
        ordinal=row.ordinal,
        status=row.status,
        payload=row.payload or {},
        summary=row.summary or {},
        errors=row.errors or [],
        model_id=row.model_id,
        duration_ms=row.duration_ms,
        edited=row.edited,
    )


@router.put("/runs/{run_id}/stages/{stage}", response_model=StagePayloadResponse)
def edit_run_stage(
    run_id: str,
    stage: str,
    body: StageEditRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> StagePayloadResponse:
    """Replace a stage's payload with a corrected one.

    This is the inspector's control point: fix the scene spec by hand and re-run
    the rest, which is how the brain is tested apart from the 3D pipeline. The
    override is flagged `edited` so evidence — and any future training signal —
    can distinguish a human-corrected target from a model-authored one. The edit
    is NOT re-validated here: it is validated by the same gates as any other spec
    when the pipeline next consumes it, so this endpoint cannot smuggle an invalid
    spec past validation.
    """
    _owned_run(db, run_id, principal)
    row = (
        db.query(StageArtifact)
        .filter_by(run_id=run_id, stage=stage)
        .one_or_none()
    )
    if row is None:
        raise HTTPException(status_code=404, detail=f"stage '{stage}' has not run")
    row.payload = body.payload
    row.edited = True
    db.flush()
    record_audit(
        db,
        principal,
        "simulation.stage_edited",
        "stage_artifact",
        row.id,
        {"run_id": run_id, "stage": stage},
    )
    return StagePayloadResponse(
        stage=row.stage,
        ordinal=row.ordinal,
        status=row.status,
        payload=row.payload or {},
        summary=row.summary or {},
        errors=row.errors or [],
        model_id=row.model_id,
        duration_ms=row.duration_ms,
        edited=row.edited,
    )


@router.get("/simulations/{simulation_id}", response_model=SimulationResponse)
def get_simulation(
    simulation_id: str,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> SimulationResponse:
    simulation = _owned_simulation(db, simulation_id, principal)
    spec = (
        db.get(SimulationSpecRecord, simulation.current_spec_id)
        if simulation.current_spec_id
        else None
    )
    run = db.get(GenerationRun, simulation.current_run_id) if simulation.current_run_id else None
    release_ready = False
    if run is not None and run.state == "completed":
        mandatory_evidence = (
            db.query(ValidationEvidence)
            .filter_by(run_id=run.id, mandatory=True)
            .all()
        )
        statuses = {item.layer: item.status for item in mandatory_evidence}
        release_ready = all(
            statuses.get(layer) == "PASS" for layer in MANDATORY_VALIDATION_LAYERS
        )
    # Compatibility builds can exist as internal diagnostic evidence even when
    # the canonical run failed. Never expose those unfinished artifacts through
    # the public simulation API: release requires both the terminal state and
    # every mandatory validator to have passed.
    artifacts = (
        db.query(SimulationArtifact).filter_by(run_id=run.id).all()
        if release_ready and run is not None
        else []
    )
    world_plan = (
        db.get(WorldPlanRecord, run.world_plan_id)
        if run and run.world_plan_id
        else None
    )
    return SimulationResponse(
        simulation_id=simulation.id,
        title=simulation.title,
        prompt=simulation.prompt,
        size_profile=simulation.size_profile,
        target_platforms=simulation.target_platforms,
        status=simulation.status,
        current_run_id=simulation.current_run_id,
        spec=spec.body if spec else None,
        world_plan=world_plan.body if world_plan else None,
        artifacts=[ArtifactInfo(kind=item.kind, url=item.uri) for item in artifacts],
        approximations=(run.detail or {}).get("approximations", []) if run else [],
    )


@router.post(
    "/simulations/{simulation_id}/edits",
    status_code=202,
    response_model=CreateSimulationResponse,
)
def edit_simulation(
    simulation_id: str,
    body: SimulationEditRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> CreateSimulationResponse:
    simulation = _owned_simulation(db, simulation_id, principal)
    ensure_generation_age_eligible(db, principal)
    if not simulation.current_spec_id:
        raise HTTPException(status_code=409, detail="simulation has no compiled specification")
    run_id = new_resource_id("run")
    run = GenerationRun(
        id=run_id,
        simulation_id=simulation.id,
        tenant_id=simulation.tenant_id,
        owner_id=principal.user_id,
        state="queued",
        stage="edit_intake",
        detail={
            "edit_instruction": body.instruction,
            "base_spec_id": simulation.current_spec_id,
        },
    )
    db.add(run)
    db.flush()
    try:
        reserve_generation_slot(db, principal.tenant_id, run_id)
    except QuotaExceeded as exc:
        db.rollback()
        raise HTTPException(
            status_code=429,
            detail={"code": exc.code, "message": exc.message},
            headers={"Retry-After": str(exc.retry_after_seconds)},
        ) from exc
    simulation.current_run_id = run_id
    simulation.status = "queued"
    record_audit(
        db,
        principal,
        "simulation.edit_requested",
        "simulation",
        simulation.id,
        {"run_id": run_id},
    )
    db.commit()
    run_simulation_generation.delay(run_id)
    return CreateSimulationResponse(simulation_id=simulation.id, run_id=run_id)


@router.post(
    "/simulations/{simulation_id}/revalidate",
    status_code=202,
    response_model=CreateSimulationResponse,
)
def revalidate_simulation(
    simulation_id: str,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> CreateSimulationResponse:
    """Rebuild an immutable spec in a new run after runtime/validator changes."""
    simulation = _owned_simulation(db, simulation_id, principal)
    ensure_generation_age_eligible(db, principal)
    if not simulation.current_spec_id:
        raise HTTPException(status_code=409, detail="simulation has no compiled specification")
    previous = (
        db.get(GenerationRun, simulation.current_run_id)
        if simulation.current_run_id
        else None
    )
    if previous is not None and not (
        previous.state == "completed" or previous.state.startswith("failed")
    ):
        raise HTTPException(status_code=409, detail="simulation run is still active")

    run_id = new_resource_id("run")
    previous_detail = dict(previous.detail or {}) if previous else {}
    run = GenerationRun(
        id=run_id,
        simulation_id=simulation.id,
        spec_id=simulation.current_spec_id,
        tenant_id=simulation.tenant_id,
        owner_id=principal.user_id,
        state="queued_build",
        stage="asset_resolution",
        detail={
            "domain_constraints": previous_detail.get("domain_constraints", {}),
            "training_rights_attested": bool(
                previous_detail.get("training_rights_attested")
            ),
            "revalidation_of": previous.id if previous else None,
        },
        model_routes=dict(previous.model_routes or {}) if previous else {},
        max_repair_attempts=previous.max_repair_attempts if previous else 3,
    )
    db.add(run)
    db.flush()
    try:
        reserve_generation_slot(db, principal.tenant_id, run_id)
    except QuotaExceeded as exc:
        db.rollback()
        raise HTTPException(
            status_code=429,
            detail={"code": exc.code, "message": exc.message},
            headers={"Retry-After": str(exc.retry_after_seconds)},
        ) from exc
    simulation.current_run_id = run_id
    simulation.status = "queued"
    record_audit(
        db,
        principal,
        "simulation.revalidation_requested",
        "simulation",
        simulation.id,
        {"run_id": run_id, "previous_run_id": previous.id if previous else None},
    )
    db.commit()
    run_simulation_generation.delay(run_id)
    return CreateSimulationResponse(simulation_id=simulation.id, run_id=run_id)


@router.get(
    "/simulations/{simulation_id}/report",
    response_model=SimulationReportResponse,
)
def get_simulation_report(
    simulation_id: str,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> SimulationReportResponse:
    simulation = _owned_simulation(db, simulation_id, principal)
    spec = (
        db.get(SimulationSpecRecord, simulation.current_spec_id)
        if simulation.current_spec_id
        else None
    )
    run = db.get(GenerationRun, simulation.current_run_id) if simulation.current_run_id else None
    world_plan = (
        db.get(WorldPlanRecord, run.world_plan_id)
        if run and run.world_plan_id
        else None
    )
    evidence = (
        db.query(ValidationEvidence)
        .filter_by(run_id=simulation.current_run_id)
        .order_by(ValidationEvidence.created_at)
        .all()
        if simulation.current_run_id
        else []
    )
    gaps = (
        db.query(CapabilityGap)
        .filter_by(run_id=simulation.current_run_id)
        .all()
        if simulation.current_run_id
        else []
    )
    return SimulationReportResponse(
        simulation_id=simulation.id,
        run_id=simulation.current_run_id,
        requirements=(spec.body.get("requirements", []) if spec else []),
        world_plan_hash=world_plan.plan_hash if world_plan else None,
        validation=[
            {
                "layer": item.layer,
                "status": item.status,
                "mandatory": item.mandatory,
                "validator": item.validator,
                "evidence": item.evidence,
                "errors": item.errors,
            }
            for item in evidence
        ],
        approximations=(run.detail or {}).get("approximations", []) if run else [],
        capability_gaps=[
            {
                "capability_id": gap.capability_id,
                "status": gap.status,
                "detail": gap.detail,
            }
            for gap in gaps
        ],
    )
