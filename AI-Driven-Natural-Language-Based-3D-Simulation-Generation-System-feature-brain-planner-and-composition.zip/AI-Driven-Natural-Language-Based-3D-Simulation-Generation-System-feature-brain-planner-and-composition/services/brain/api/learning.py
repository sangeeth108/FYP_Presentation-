"""Administrative gates for consent-qualified datasets and model releases."""

from __future__ import annotations

from datetime import UTC, datetime

from core.audit import record_audit
from core.config import get_settings
from core.ids import new_resource_id
from core.models import (
    ContentRight,
    DatasetVersion,
    ModelDeployment,
    ModelEvaluation,
    ModelVersion,
    ResearchExclusion,
    TrainingEligibility,
    TrainingRun,
)
from core.schemas import (
    CanaryAdvanceRequest,
    ContentRightsReviewRequest,
    DatasetBuildRequest,
    ModelCandidateRequest,
    ModelEvaluationAttestationRequest,
    ModelPromotionRequest,
    ResearchExclusionRequest,
    TrainingCandidateRequest,
    TrainingEligibilityReviewRequest,
)
from core.security import Principal, require_roles, tenant_db
from fastapi import APIRouter, Depends, HTTPException
from learning.datasets import (
    DatasetBuildError,
    build_dataset_version,
    prompt_family_fingerprint,
    prompt_fingerprint,
)
from learning.eligibility import evaluate_eligibility
from learning.lifecycle import (
    LifecycleError,
    advance_canary,
    approve_training_candidate,
    create_training_candidate,
    promote_model,
    register_model_candidate,
    register_model_evaluation,
)
from sqlalchemy.orm import Session
from worker.learning_tasks import execute_governed_training

router = APIRouter(tags=["learning-administration"])
_ADMIN_ROLES = ("org_admin", "reviewer", "platform_admin")


def _same_tenant_or_platform(principal: Principal, tenant_id: str | None) -> None:
    if tenant_id not in {None, principal.tenant_id} and "platform_admin" not in principal.roles:
        raise HTTPException(status_code=403, detail="cross-tenant administration denied")
    if tenant_id is None and "platform_admin" not in principal.roles:
        raise HTTPException(status_code=403, detail="global learning requires platform admin")


@router.put("/admin/training-eligibility/{eligibility_id}/review")
def review_eligibility(
    eligibility_id: str,
    body: TrainingEligibilityReviewRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(require_roles(*_ADMIN_ROLES)),
) -> dict:
    row = db.get(TrainingEligibility, eligibility_id)
    if row is None:
        raise HTTPException(status_code=404, detail="eligibility record not found")
    _same_tenant_or_platform(principal, row.tenant_id)
    row.moderation_status = body.moderation_status
    row.quality_status = body.quality_status
    evaluate_eligibility(db, row)
    record_audit(
        db,
        principal,
        "training_eligibility.reviewed",
        "training_eligibility",
        row.id,
        {"status": row.status, "exclusion_reason": row.exclusion_reason},
    )
    db.commit()
    return {
        "eligibility_id": row.id,
        "status": row.status,
        "exclusion_reason": row.exclusion_reason,
    }


@router.put("/admin/content-rights/{right_id}/review")
def review_content_rights(
    right_id: str,
    body: ContentRightsReviewRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(require_roles(*_ADMIN_ROLES)),
) -> dict:
    right = db.get(ContentRight, right_id)
    if right is None:
        raise HTTPException(status_code=404, detail="content-right record not found")
    _same_tenant_or_platform(principal, right.tenant_id)
    right.training_allowed = body.approved
    right.rights_basis = body.rights_basis
    right.licence_id = body.licence_id
    right.verified_at = datetime.now(UTC) if body.approved else None
    affected = (
        db.query(TrainingEligibility).filter_by(content_right_id=right.id).all()
    )
    for eligibility in affected:
        evaluate_eligibility(db, eligibility)
    record_audit(
        db,
        principal,
        "content_right.reviewed",
        "content_right",
        right.id,
        {"approved": body.approved, "affected_records": len(affected)},
    )
    db.commit()
    return {
        "content_right_id": right.id,
        "approved": right.training_allowed,
        "verified_at": right.verified_at,
        "eligibility_records_rechecked": len(affected),
    }


@router.post("/admin/learning/research-exclusions", status_code=201)
def create_research_exclusion(
    body: ResearchExclusionRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(require_roles("reviewer", "platform_admin")),
) -> dict:
    if "platform_admin" not in principal.roles:
        raise HTTPException(status_code=403, detail="research exclusions require platform admin")
    fingerprints = {
        prompt_fingerprint(body.prompt),
        prompt_family_fingerprint(body.prompt),
    }
    ids = []
    for fingerprint in fingerprints:
        existing = (
            db.query(ResearchExclusion).filter_by(fingerprint=fingerprint).one_or_none()
        )
        if existing is None:
            existing = ResearchExclusion(
                id=new_resource_id("research_exclusion"),
                fingerprint=fingerprint,
                exclusion_type=body.exclusion_type,
                purpose=body.purpose,
                study_id=body.study_id,
            )
            db.add(existing)
        ids.append(existing.id)
    record_audit(
        db,
        principal,
        "research.exclusion_registered",
        "research_exclusion",
        ids[0],
        {"count": len(ids), "type": body.exclusion_type, "study_id": body.study_id},
    )
    db.commit()
    return {"exclusion_ids": ids, "raw_prompt_stored": False}


@router.post("/admin/learning/datasets", status_code=201)
def build_dataset(
    body: DatasetBuildRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(require_roles(*_ADMIN_ROLES)),
) -> dict:
    tenant_id = None if body.scope == "global" else principal.tenant_id
    if body.scope == "global" and "platform_admin" not in principal.roles:
        raise HTTPException(status_code=403, detail="global datasets require platform admin")
    try:
        dataset = build_dataset_version(
            db,
            scope=body.scope,
            target=body.target,
            tenant_id=tenant_id,
        )
    except DatasetBuildError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    record_audit(
        db,
        principal,
        "dataset.frozen",
        "dataset_version",
        dataset.id,
        {
            "scope": dataset.scope,
            "target": dataset.target,
            "item_count": dataset.item_count,
            "manifest_hash": dataset.manifest_hash,
        },
    )
    db.commit()
    return {
        "dataset_version_id": dataset.id,
        "status": dataset.status,
        "target": dataset.target,
        "item_count": dataset.item_count,
        "manifest_hash": dataset.manifest_hash,
    }


@router.post("/admin/learning/training-runs", status_code=202)
def create_training_run(
    body: TrainingCandidateRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(require_roles(*_ADMIN_ROLES)),
) -> dict:
    settings = get_settings()
    if settings.promptplay_env == "production" and not settings.production_training_enabled:
        raise HTTPException(status_code=503, detail="production training is disabled")
    dataset = db.get(DatasetVersion, body.dataset_version_id)
    if dataset is None:
        raise HTTPException(status_code=404, detail="dataset not found")
    _same_tenant_or_platform(principal, dataset.tenant_id)
    if dataset.scope == "tenant_private" and not settings.enterprise_adapter_kms_key_id:
        raise HTTPException(
            status_code=503,
            detail="enterprise adapter encryption key is not configured",
        )
    try:
        run = create_training_candidate(
            db,
            dataset=dataset,
            target=dataset.target,
            base_model=body.base_model,
            config=body.config,
            monthly_window=body.monthly_window,
        )
    except LifecycleError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    record_audit(
        db,
        principal,
        "training.candidate_created",
        "training_run",
        run.id,
        {"dataset_version_id": dataset.id, "target": run.target},
    )
    db.commit()
    return {"training_run_id": run.id, "state": run.state}


@router.post("/admin/learning/training-runs/{run_id}/approve")
def approve_training_run(
    run_id: str,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(require_roles("reviewer", "platform_admin")),
) -> dict:
    run = db.get(TrainingRun, run_id)
    if run is None:
        raise HTTPException(status_code=404, detail="training run not found")
    _same_tenant_or_platform(principal, run.tenant_id)
    try:
        approve_training_candidate(run, approved_by=principal.user_id)
    except LifecycleError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    record_audit(
        db,
        principal,
        "training.candidate_approved",
        "training_run",
        run.id,
    )
    db.commit()
    return {"training_run_id": run.id, "state": run.state}


@router.post("/admin/learning/training-runs/{run_id}/execute", status_code=202)
def execute_training_run(
    run_id: str,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(require_roles("reviewer", "platform_admin")),
) -> dict:
    settings = get_settings()
    if not settings.training_runner_enabled:
        raise HTTPException(status_code=503, detail="the governed training runner is disabled")
    if settings.promptplay_env == "production" and not settings.production_training_enabled:
        raise HTTPException(status_code=503, detail="production training is disabled")
    run = db.get(TrainingRun, run_id)
    if run is None:
        raise HTTPException(status_code=404, detail="training run not found")
    _same_tenant_or_platform(principal, run.tenant_id)
    if run.state != "APPROVED" or run.approved_at is None:
        raise HTTPException(status_code=409, detail="training run lacks model-owner approval")
    run.state = "QUEUED"
    record_audit(
        db,
        principal,
        "training.execution_queued",
        "training_run",
        run.id,
        {"target": run.target},
    )
    db.commit()
    execute_governed_training.delay(run.id)
    return {"training_run_id": run.id, "state": "QUEUED"}


@router.post("/admin/learning/models", status_code=201)
def create_model_candidate(
    body: ModelCandidateRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(require_roles("reviewer", "platform_admin")),
) -> dict:
    training_run = db.get(TrainingRun, body.training_run_id)
    if training_run is None:
        raise HTTPException(status_code=404, detail="training run not found")
    _same_tenant_or_platform(principal, training_run.tenant_id)
    try:
        model = register_model_candidate(
            db,
            training_run=training_run,
            name=body.name,
            licence_id=body.licence_id,
            model_card=body.model_card,
        )
    except LifecycleError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    record_audit(db, principal, "model.candidate_registered", "model_version", model.id)
    db.commit()
    return {"model_version_id": model.id, "state": model.state, "digest": model.digest}


@router.post("/admin/learning/models/{model_id}/evaluations", status_code=201)
def create_model_evaluation(
    model_id: str,
    body: ModelEvaluationAttestationRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(require_roles("reviewer", "platform_admin")),
) -> dict:
    model = db.get(ModelVersion, model_id)
    if model is None:
        raise HTTPException(status_code=404, detail="model not found")
    _same_tenant_or_platform(principal, model.tenant_id)
    signing_key = get_settings().model_evaluation_signing_key
    if len(signing_key) < 32:
        raise HTTPException(status_code=503, detail="evaluation verifier is not configured")
    try:
        evaluation = register_model_evaluation(
            db,
            model=model,
            evaluator=body.evaluator,
            evaluator_version=body.evaluator_version,
            benchmark_digest=body.benchmark_digest,
            artifact_digest=body.artifact_digest,
            metrics=body.metrics,
            signature=body.signature,
            signing_key=signing_key,
        )
    except LifecycleError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    record_audit(
        db,
        principal,
        "model.evaluation_verified",
        "model_evaluation",
        evaluation.id,
        {"model_version_id": model.id, "benchmark_digest": body.benchmark_digest},
    )
    db.commit()
    return {"evaluation_id": evaluation.id, "verified": evaluation.verified}


@router.post("/admin/learning/models/{model_id}/promote")
def promote_model_version(
    model_id: str,
    body: ModelPromotionRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(require_roles("reviewer", "platform_admin")),
) -> dict:
    settings = get_settings()
    if (
        body.target_state == "PRODUCTION"
        and settings.promptplay_env == "production"
        and not settings.production_training_enabled
    ):
        raise HTTPException(status_code=503, detail="production model promotion is disabled")
    model = db.get(ModelVersion, model_id)
    if model is None:
        raise HTTPException(status_code=404, detail="model not found")
    _same_tenant_or_platform(principal, model.tenant_id)
    evaluation = None
    if body.evaluation_id:
        evaluation = db.get(ModelEvaluation, body.evaluation_id)
        if evaluation is None:
            raise HTTPException(status_code=404, detail="evaluation not found")
        _same_tenant_or_platform(principal, evaluation.tenant_id)
    try:
        promote_model(
            db,
            model=model,
            target_state=body.target_state,
            evaluation=evaluation,
        )
    except LifecycleError as exc:
        db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    record_audit(
        db,
        principal,
        "model.state_changed",
        "model_version",
        model.id,
        {"state": model.state},
    )
    db.commit()
    return {"model_version_id": model.id, "state": model.state}


@router.post("/admin/learning/deployments/{deployment_id}/advance")
def advance_model_canary(
    deployment_id: str,
    body: CanaryAdvanceRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(require_roles("reviewer", "platform_admin")),
) -> dict:
    deployment = db.get(ModelDeployment, deployment_id)
    if deployment is None:
        raise HTTPException(status_code=404, detail="deployment not found")
    _same_tenant_or_platform(principal, deployment.tenant_id)
    model = db.get(ModelVersion, deployment.model_version_id)
    evaluation = db.get(ModelEvaluation, body.evaluation_id)
    if model is None or evaluation is None:
        raise HTTPException(status_code=404, detail="model evaluation not found")
    _same_tenant_or_platform(principal, evaluation.tenant_id)
    try:
        advance_canary(deployment, model=model, evaluation=evaluation)
    except LifecycleError as exc:
        db.commit()  # persist automatic rollback evidence
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    record_audit(
        db,
        principal,
        "model.canary_advanced",
        "model_deployment",
        deployment.id,
        {"traffic_percent": deployment.traffic_percent},
    )
    db.commit()
    return {
        "deployment_id": deployment.id,
        "traffic_percent": deployment.traffic_percent,
        "state": deployment.state,
    }
