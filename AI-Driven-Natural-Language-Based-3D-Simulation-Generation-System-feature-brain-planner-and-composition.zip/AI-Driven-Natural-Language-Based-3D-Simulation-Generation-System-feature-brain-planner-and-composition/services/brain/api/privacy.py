"""Consent, guardian approval, and data-subject rights APIs."""

from __future__ import annotations

from datetime import UTC, datetime

from core.audit import record_audit
from core.ids import new_resource_id
from core.models import (
    AgeAssurance,
    ConsentRecord,
    DataSubjectRequest,
    GuardianRelationship,
    Membership,
    Tenant,
    User,
)
from core.schemas import (
    AgeAssuranceReviewRequest,
    ConsentStatusItem,
    DataSubjectRequestResponse,
    GuardianRelationshipCreate,
    GuardianRelationshipResponse,
    TrainingConsentStatus,
    TrainingConsentUpdate,
)
from core.security import (
    Principal,
    current_principal,
    ensure_principal_records,
    require_roles,
    tenant_db,
)
from fastapi import APIRouter, Depends, HTTPException
from learning.eligibility import TEEN_BANDS, reevaluate_owner_resources
from sqlalchemy.orm import Session

router = APIRouter(tags=["privacy"])

_SCOPES = ("global", "tenant_private")
_CATEGORIES = ("prompt_spec", "telemetry", "assets")


@router.put("/admin/users/{user_id}/age-assurance")
def review_age_assurance(
    user_id: str,
    body: AgeAssuranceReviewRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(require_roles("reviewer", "platform_admin")),
) -> dict:
    user = db.get(User, user_id)
    membership = (
        db.query(Membership)
        .filter_by(
            tenant_id=principal.tenant_id,
            user_id=user_id,
            status="active",
        )
        .first()
    )
    if user is None or (
        membership is None and "platform_admin" not in principal.roles
    ):
        raise HTTPException(status_code=404, detail="user not found")
    assurance = AgeAssurance(
        id=new_resource_id("age_assurance"),
        tenant_id=principal.tenant_id,
        user_id=user_id,
        age_band=body.age_band,
        provider=body.provider,
        evidence_ref=body.evidence_reference,
        expires_at=body.expires_at,
    )
    db.add(assurance)
    user.age_band = body.age_band
    if body.age_band == "under_13":
        user.status = "blocked_under_13"
    elif user.status == "blocked_under_13":
        user.status = "active"
    record_audit(
        db,
        principal,
        "age_assurance.reviewed",
        "user",
        user_id,
        {"age_band": body.age_band, "provider": body.provider},
    )
    db.commit()
    return {
        "age_assurance_id": assurance.id,
        "user_id": user_id,
        "age_band": body.age_band,
        "account_status": user.status,
    }


def _latest(
    db: Session,
    *,
    subject_user_id: str,
    tenant_id: str,
    scope: str,
    category: str,
    kind: str,
) -> ConsentRecord | None:
    return (
        db.query(ConsentRecord)
        .filter_by(
            subject_user_id=subject_user_id,
            tenant_id=tenant_id,
            scope=scope,
            data_category=category,
            consent_kind=kind,
        )
        .order_by(ConsentRecord.created_at.desc(), ConsentRecord.id.desc())
        .first()
    )


def _status(db: Session, user: User, tenant_id: str) -> TrainingConsentStatus:
    guardian_required = user.age_band in TEEN_BANDS
    choices = []
    for scope in _SCOPES:
        for category in _CATEGORIES:
            own = _latest(
                db,
                subject_user_id=user.id,
                tenant_id=tenant_id,
                scope=scope,
                category=category,
                kind="subject",
            )
            guardian = _latest(
                db,
                subject_user_id=user.id,
                tenant_id=tenant_id,
                scope=scope,
                category=category,
                kind="guardian",
            )
            own_granted = bool(own and own.granted and own.withdrawn_at is None)
            guardian_granted = (
                bool(guardian and guardian.granted and guardian.withdrawn_at is None)
                if guardian_required
                else None
            )
            choices.append(
                ConsentStatusItem(
                    scope=scope,
                    data_category=category,
                    subject_granted=own_granted,
                    guardian_granted=guardian_granted,
                    effective=own_granted
                    and (not guardian_required or bool(guardian_granted)),
                )
            )
    return TrainingConsentStatus(
        user_id=user.id,
        age_band=user.age_band,
        guardian_required=guardian_required,
        choices=choices,
    )


@router.get("/privacy/training-consent", response_model=TrainingConsentStatus)
def get_training_consent(
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> TrainingConsentStatus:
    ensure_principal_records(db, principal)
    user = db.get(User, principal.user_id)
    return _status(db, user, principal.tenant_id)


@router.put("/privacy/training-consent", response_model=TrainingConsentStatus)
def update_training_consent(
    body: TrainingConsentUpdate,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> TrainingConsentStatus:
    ensure_principal_records(db, principal)
    user = db.get(User, principal.user_id)
    if user.age_band in {"unknown", "under_13"}:
        raise HTTPException(status_code=409, detail="verified age eligibility is required")
    now = datetime.now(UTC)
    seen: set[tuple[str, str]] = set()
    for choice in body.choices:
        key = (choice.scope, choice.data_category)
        if key in seen:
            raise HTTPException(status_code=422, detail=f"duplicate consent choice: {key}")
        seen.add(key)
        db.add(
            ConsentRecord(
                id=new_resource_id("consent"),
                tenant_id=principal.tenant_id,
                subject_user_id=principal.user_id,
                actor_user_id=principal.user_id,
                consent_kind="subject",
                scope=choice.scope,
                data_category=choice.data_category,
                granted=choice.granted,
                disclosure_version=body.disclosure_version,
                locale=body.locale,
                withdrawn_at=None if choice.granted else now,
            )
        )
    record_audit(
        db,
        principal,
        "training_consent.updated",
        "user",
        principal.user_id,
        {"choices": len(body.choices), "disclosure_version": body.disclosure_version},
    )
    db.flush()
    reevaluate_owner_resources(db, principal.user_id, principal.tenant_id)
    withdrawal_requested = any(not choice.granted for choice in body.choices)
    db.commit()
    if withdrawal_requested:
        from worker.learning_tasks import purge_user_training_data

        purge_user_training_data.delay(
            principal.user_id,
            principal.tenant_id,
            False,
            "subject_consent_withdrawn",
        )
    return _status(db, user, principal.tenant_id)


@router.post(
    "/privacy/guardian-relationships",
    status_code=202,
    response_model=GuardianRelationshipResponse,
)
def create_guardian_relationship(
    body: GuardianRelationshipCreate,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> GuardianRelationshipResponse:
    ensure_principal_records(db, principal)
    guardian = db.get(User, principal.user_id)
    minor = db.get(User, body.minor_user_id)
    if guardian.age_band != "adult":
        raise HTTPException(status_code=403, detail="guardian must be age-assured as an adult")
    if minor is None or minor.age_band not in TEEN_BANDS:
        raise HTTPException(status_code=404, detail="eligible teen account not found")
    minor_membership = (
        db.query(Membership)
        .filter_by(
            tenant_id=principal.tenant_id,
            user_id=minor.id,
            status="active",
        )
        .first()
    )
    if minor_membership is None:
        raise HTTPException(status_code=404, detail="eligible teen account not found")
    existing = (
        db.query(GuardianRelationship)
        .filter_by(
            tenant_id=principal.tenant_id,
            minor_user_id=minor.id,
            guardian_user_id=guardian.id,
        )
        .one_or_none()
    )
    if existing:
        return GuardianRelationshipResponse(
            relationship_id=existing.id, status=existing.status
        )
    relationship = GuardianRelationship(
        id=new_resource_id("guardian"),
        tenant_id=principal.tenant_id,
        minor_user_id=minor.id,
        guardian_user_id=guardian.id,
        status="pending",
        verification_ref=body.verification_reference,
    )
    db.add(relationship)
    record_audit(
        db,
        principal,
        "guardian_relationship.requested",
        "guardian_relationship",
        relationship.id,
    )
    db.commit()
    return GuardianRelationshipResponse(
        relationship_id=relationship.id, status=relationship.status
    )


@router.post(
    "/admin/guardian-relationships/{relationship_id}/verify",
    response_model=GuardianRelationshipResponse,
)
def verify_guardian_relationship(
    relationship_id: str,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(require_roles("reviewer", "platform_admin")),
) -> GuardianRelationshipResponse:
    ensure_principal_records(db, principal)
    relationship = db.get(GuardianRelationship, relationship_id)
    if relationship is None:
        raise HTTPException(status_code=404, detail="guardian relationship not found")
    relationship.status = "verified"
    relationship.verified_at = datetime.now(UTC)
    record_audit(
        db,
        principal,
        "guardian_relationship.verified",
        "guardian_relationship",
        relationship.id,
    )
    db.commit()
    return GuardianRelationshipResponse(
        relationship_id=relationship.id, status=relationship.status
    )


@router.put(
    "/privacy/guardians/{minor_user_id}/training-consent",
    response_model=TrainingConsentStatus,
)
def update_guardian_training_consent(
    minor_user_id: str,
    body: TrainingConsentUpdate,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> TrainingConsentStatus:
    ensure_principal_records(db, principal)
    relationship = (
        db.query(GuardianRelationship)
        .filter_by(
            tenant_id=principal.tenant_id,
            minor_user_id=minor_user_id,
            guardian_user_id=principal.user_id,
            status="verified",
        )
        .filter(GuardianRelationship.revoked_at.is_(None))
        .one_or_none()
    )
    if relationship is None:
        raise HTTPException(status_code=403, detail="verified guardianship is required")
    minor = db.get(User, minor_user_id)
    if minor is None or minor.age_band not in TEEN_BANDS:
        raise HTTPException(status_code=404, detail="teen account not found")
    now = datetime.now(UTC)
    for choice in body.choices:
        db.add(
            ConsentRecord(
                id=new_resource_id("consent"),
                tenant_id=principal.tenant_id,
                subject_user_id=minor_user_id,
                actor_user_id=principal.user_id,
                consent_kind="guardian",
                scope=choice.scope,
                data_category=choice.data_category,
                granted=choice.granted,
                disclosure_version=body.disclosure_version,
                locale=body.locale,
                guardian_relationship_id=relationship.id,
                withdrawn_at=None if choice.granted else now,
            )
        )
    record_audit(
        db,
        principal,
        "guardian_training_consent.updated",
        "user",
        minor_user_id,
        {"choices": len(body.choices)},
    )
    db.flush()
    reevaluate_owner_resources(db, minor_user_id, principal.tenant_id)
    withdrawal_requested = any(not choice.granted for choice in body.choices)
    db.commit()
    if withdrawal_requested:
        from worker.learning_tasks import purge_user_training_data

        purge_user_training_data.delay(
            minor_user_id,
            principal.tenant_id,
            False,
            "guardian_consent_withdrawn",
        )
    return _status(db, minor, principal.tenant_id)


def _create_data_request(
    request_type: str, db: Session, principal: Principal
) -> DataSubjectRequestResponse:
    ensure_principal_records(db, principal)
    request = DataSubjectRequest(
        id=new_resource_id("privacy_request"),
        tenant_id=principal.tenant_id,
        owner_id=principal.user_id,
        request_type=request_type,
        state="queued",
        detail={"scope": "all_user_owned_data"},
    )
    db.add(request)
    record_audit(
        db,
        principal,
        f"privacy.{request_type}.requested",
        "data_subject_request",
        request.id,
    )
    db.commit()
    return DataSubjectRequestResponse(
        request_id=request.id, request_type=request_type, state=request.state
    )


@router.post("/privacy/export", status_code=202, response_model=DataSubjectRequestResponse)
def request_export(
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> DataSubjectRequestResponse:
    response = _create_data_request("export", db, principal)
    from worker.privacy_tasks import process_data_subject_request

    process_data_subject_request.delay(response.request_id)
    return response


@router.post("/privacy/delete", status_code=202, response_model=DataSubjectRequestResponse)
def request_delete(
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> DataSubjectRequestResponse:
    response = _create_data_request("delete", db, principal)
    from core.models import Spec, TrainingEligibility

    db.query(Spec).filter_by(
        tenant_id=principal.tenant_id, owner_id=principal.user_id
    ).update({"training_eligible": False})
    db.query(TrainingEligibility).filter_by(
        tenant_id=principal.tenant_id, owner_id=principal.user_id
    ).update(
        {
            "status": "ineligible",
            "deleted": True,
            "exclusion_reason": "deletion_requested",
        }
    )
    db.commit()
    from celery import chain
    from worker.learning_tasks import purge_all_user_training_data
    from worker.privacy_tasks import process_data_subject_request

    chain(
        purge_all_user_training_data.s(
            principal.user_id,
            True,
            "user_deletion_requested",
            response.request_id,
        ),
        process_data_subject_request.si(response.request_id),
    ).delay()
    return response


@router.get(
    "/privacy/requests/{request_id}", response_model=DataSubjectRequestResponse
)
def get_data_request(
    request_id: str,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> DataSubjectRequestResponse:
    request = (
        db.query(DataSubjectRequest)
        .filter_by(
            id=request_id,
            tenant_id=principal.tenant_id,
            owner_id=principal.user_id,
        )
        .one_or_none()
    )
    if request is None:
        raise HTTPException(status_code=404, detail="privacy request not found")
    return DataSubjectRequestResponse(
        request_id=request.id,
        request_type=request.request_type,
        state=request.state,
        result=request.result,
    )


@router.put("/admin/tenants/{tenant_id}/training-policy")
def update_tenant_training_policy(
    tenant_id: str,
    body: dict,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(require_roles("org_admin", "platform_admin")),
) -> dict:
    if principal.tenant_id != tenant_id and "platform_admin" not in principal.roles:
        raise HTTPException(status_code=403, detail="cross-tenant administration denied")
    policy = body.get("policy")
    if policy not in {"disabled", "global", "private", "hybrid"}:
        raise HTTPException(status_code=422, detail="invalid training policy")
    tenant = db.get(Tenant, tenant_id)
    if tenant is None:
        raise HTTPException(status_code=404, detail="tenant not found")
    tenant.training_policy = policy
    record_audit(
        db,
        principal,
        "tenant.training_policy.updated",
        "tenant",
        tenant_id,
        {"policy": policy},
    )
    db.commit()
    return {"tenant_id": tenant_id, "policy": policy}
