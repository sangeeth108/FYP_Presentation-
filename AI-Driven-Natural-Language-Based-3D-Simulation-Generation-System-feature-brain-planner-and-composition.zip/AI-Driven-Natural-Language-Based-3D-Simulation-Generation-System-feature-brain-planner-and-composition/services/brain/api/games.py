"""Deprecated game API adapter.

`/simulations` is the only generation pipeline. This adapter translates the
old game-shaped request and returns the canonical simulation/run identifiers in
the historical field names so existing clients can migrate without bypassing
the neutral contracts or verification gates.
"""

from __future__ import annotations

from core.schemas import (
    CreateGameRequest,
    CreateGameResponse,
    CreateSimulationRequest,
)
from core.security import Principal, current_principal, tenant_db
from fastapi import APIRouter, Depends, Response
from sqlalchemy.orm import Session

from api.simulations import create_simulation

router = APIRouter(tags=["games-compatibility"])


@router.post(
    "/games",
    status_code=202,
    response_model=CreateGameResponse,
    deprecated=True,
)
def create_game(
    body: CreateGameRequest,
    response: Response,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> CreateGameResponse:
    options = body.options
    canonical = create_simulation(
        CreateSimulationRequest(
            prompt=body.prompt,
            seed=body.seed,
            size_profile="auto",
            target_platforms=["web", "desktop"],
            domain_constraints={
                "compatibility_source": "games_v1",
                "legacy_genre_hint": options.genre if options else None,
                "legacy_camera_hint": options.camera if options else None,
            },
        ),
        db=db,
        principal=principal,
    )
    response.headers["Deprecation"] = "true"
    response.headers["Sunset"] = "Tue, 20 Jul 2027 00:00:00 GMT"
    response.headers["Link"] = '</api/v1/simulations>; rel="successor-version"'
    return CreateGameResponse(
        game_id=canonical.simulation_id,
        job_id=canonical.run_id,
    )
