"""Live job progress over Server-Sent Events (docs/API_DOCUMENTATION.md).

`GET /api/v1/jobs/{id}/events` streams the job's state transitions as they
land in the DB, so the browser sees real phases (PLANNING -> ... ->
VALIDATING -> DEPLOYED) instead of client-side polling. Works with the
real async Celery worker (state evolves over time) and degrades cleanly
in eager mode (already terminal -> one event, then close).

SSE (not WebSocket) is deliberate: progress is one-directional, EventSource
auto-reconnects, and it rides plain HTTP through the Cloudflare tunnel with
no upgrade handshake. A worker-published Redis pub/sub relay can replace the
DB poll later without changing this wire format.
"""

from __future__ import annotations

import json
import time
from collections.abc import Iterator

from core import db as db_module
from core.models import GenerationRun, Job, JobState
from core.security import Principal, current_principal
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse

router = APIRouter(tags=["jobs"])

_TERMINAL = {JobState.DEPLOYED.value, JobState.FAILED.value}
_RUN_TERMINAL = {
    "completed",
    "failed_requirements",
    "failed_capability",
    "failed_build",
    "failed_validation",
    "failed_export",
}
_RUN_TO_JOB = {
    "queued": "QUEUED",
    "planning": "PLANNING",
    "compiling": "BUILDING_LEVEL",
    "building": "ASSEMBLING",
    "completed": "DEPLOYED",
}
POLL_SECONDS = 0.5
MAX_STREAM_SECONDS = 300  # a real export + validation can take a couple minutes


def _event(payload: dict) -> str:
    return f"data: {json.dumps(payload)}\n\n"


def _stream(job_id: str, tenant_id: str) -> Iterator[str]:
    started = time.monotonic()
    last_signature: tuple | None = None
    while True:
        with db_module.session_scope() as session:
            job = (
                session.query(Job)
                .filter(Job.id == job_id, Job.tenant_id == tenant_id)
                .one_or_none()
            )
            if job is None:
                run = (
                    session.query(GenerationRun)
                    .filter_by(id=job_id, tenant_id=tenant_id)
                    .one_or_none()
                )
                if run is None:
                    yield _event({"error": "not_found", "job_id": job_id})
                    return
                state = _RUN_TO_JOB.get(
                    run.state,
                    "FAILED" if run.state in _RUN_TERMINAL else "BUILDING_LEVEL",
                )
                detail = {
                    **dict(run.detail or {}),
                    "canonical_state": run.state,
                    "canonical_stage": run.stage,
                    "deprecated_adapter": True,
                }
            else:
                state = job.state
                detail = dict(job.detail or {})

        signature = (state, json.dumps(detail, sort_keys=True))
        if signature != last_signature:
            last_signature = signature
            yield _event({"state": state, "detail": detail, "terminal": state in _TERMINAL})

        if state in _TERMINAL:
            return
        if time.monotonic() - started > MAX_STREAM_SECONDS:
            yield _event({"state": state, "detail": detail, "terminal": False, "timeout": True})
            return
        time.sleep(POLL_SECONDS)


@router.get("/jobs/{job_id}/events")
def job_events(
    job_id: str,
    principal: Principal = Depends(current_principal),
) -> StreamingResponse:
    return StreamingResponse(
        _stream(job_id, principal.tenant_id),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",  # disable proxy buffering (Caddy/CF)
            "Connection": "keep-alive",
        },
    )
