"""Serendib Engine downloads.

A generated project is engine-native and editable, which is only useful to
someone who has the engine. This endpoint is the other half of the download
button: the project, and the thing that opens it.

Served from `engine/serendib/build-manifest.json`, which the build script
writes with a SHA-256 for every artifact it produced. Reading the manifest
rather than scanning a directory is deliberate: a binary nobody can trace to a
build is not something to offer for download, and an unhashed one cannot be
checked after transfer.

When the engine has not been built the endpoint says so explicitly rather than
returning an empty list. "No builds yet" and "the build machine is down" are
different answers and the interface should not merge them into a blank space.
"""

from __future__ import annotations

from pathlib import Path

from core.config import get_settings
from fastapi import APIRouter

router = APIRouter(tags=["engine"])

_REPO = Path(__file__).resolve().parents[3]
_MANIFEST = _REPO / "engine" / "serendib" / "build-manifest.json"

# Which produced artifact belongs on a download page, matched on the filename
# SCons produced rather than on its extension. Extension alone is not enough:
# the editor, the Windows export template and both console stubs are all
# `.exe`, so a suffix rule offered a 68 MB export template labelled "Serendib
# Engine editor" and a user would have downloaded the wrong thing and found it
# would not open their project.
#
# Everything absent from this list is a build intermediate (raw .wasm, the
# unwrapped .js, console stubs that exist to attach a terminal to the GUI
# binary) and stays out of the response. A download page is not a build
# directory listing.
def published_name(built_name: str) -> str:
    """The filename a build is OFFERED under, from the one SCons produced.

    SCons hardcodes the `godot` prefix, so the editor is built as
    `godot.windows.editor.x86_64.exe` no matter how thoroughly the binary is
    branded -- and a download called "godot" is the first thing a user sees,
    before any splash screen or About dialog. The bytes are identical; this is the
    label on the box.

    Derived by rule rather than tabulated so that an artifact added to the build
    needs no second edit here, and so a manifest written before this existed still
    resolves. `engine/serendib/build_scripts/build_serendib.py` applies the same
    rule when it publishes, and a test asserts the two agree -- if they drift, the
    download page lists names that 404.
    """
    if built_name.startswith("godot."):
        return "serendib." + built_name[len("godot.") :]
    return built_name


_PUBLISHED: tuple[tuple[str, str, str, str], ...] = (
    (
        "godot.windows.editor.x86_64.exe",
        "editor",
        "Serendib Engine editor",
        "Windows",
    ),
    (
        "godot.web.template_release.wasm32.nothreads.zip",
        "export_template_web",
        "Web export template",
        "Browser",
    ),
    (
        "godot.windows.template_release.x86_64.exe",
        "export_template_windows",
        "Windows export template",
        "Windows",
    ),
)


def _classify(name: str) -> tuple[str, str, str] | None:
    for filename, kind, label, platform in _PUBLISHED:
        if name == filename:
            return kind, label, platform
    return None


@router.get("/engine/downloads")
def engine_downloads() -> dict:
    """List the Serendib Engine builds available to download."""
    import json

    settings = get_settings()
    if not _MANIFEST.is_file():
        return {
            "available": False,
            "reason": "not_built",
            "detail": (
                "Serendib Engine has not been built from the pinned upstream "
                "tag yet. Generated projects remain fully editable in any "
                "compatible engine build in the meantime."
            ),
            "upstream_tag": None,
            "builds": [],
        }

    manifest = json.loads(_MANIFEST.read_text(encoding="utf-8"))
    builds = []
    for artifact in manifest.get("artifacts", []):
        classified = _classify(artifact["name"])
        if classified is None:
            continue
        kind, label, platform = classified
        builds.append(
            {
                "kind": kind,
                "label": label,
                "platform": platform,
                # The name it is OFFERED under, not the name SCons produced. The
                # manifest keeps the built name and its hash so an artifact stays
                # traceable to the build that made it; a user downloading an editor
                # called "godot" would reasonably conclude the rebrand had not
                # happened.
                "filename": published_name(artifact["name"]),
                "bytes": artifact["bytes"],
                "sha256": artifact["sha256"],
                # Served from the same artifact route the generated builds use,
                # so there is one delivery path to secure and one to cache.
                "url": f"/artifacts/engine/{published_name(artifact['name'])}",
            }
        )
    return {
        "available": bool(builds),
        "reason": None if builds else "no_publishable_artifacts",
        "detail": None,
        "upstream_tag": manifest.get("upstream_tag"),
        "built_at": manifest.get("built_at"),
        # The rebrand is a legal requirement, not decoration, so the credit
        # travels with the download rather than living only in the About box.
        "attribution": (
            "Serendib Engine is based on Godot Engine, used under the MIT "
            "licence. Not affiliated with or endorsed by the Godot project."
        ),
        "environment": settings.promptplay_env,
        "builds": builds,
    }
