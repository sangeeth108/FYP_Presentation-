"""Public capability/model discovery without secret-bearing provider details."""

from __future__ import annotations

from capabilities.registry import capability_index, load_packs
from core.audit import record_audit
from core.ids import new_resource_id
from core.models import ModelRouteOverride
from core.schemas import ModelRouteOverrideRequest
from core.security import Principal, ensure_principal_records, require_roles, tenant_db
from fastapi import APIRouter, Depends, HTTPException
from model_router.registry import model_catalog
from sqlalchemy.orm import Session

router = APIRouter(tags=["registries"])


@router.get("/capabilities")
def get_capabilities() -> dict:
    return {
        "packs": [
            {
                "pack_id": pack["pack_id"],
                "version": pack["version"],
                "platforms": pack["platforms"],
            }
            for pack in load_packs()
        ],
        "capabilities": list(capability_index().values()),
    }


@router.get("/models")
def get_models() -> dict:
    return {"models": [model.public_dict() for model in model_catalog()]}


@router.put("/models/routes/{role}")
def put_model_route(
    role: str,
    body: ModelRouteOverrideRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(
        require_roles("organisation_admin", "platform_admin")
    ),
) -> dict:
    ensure_principal_records(db, principal)
    if role not in {"planner", "critic", "vision"}:
        raise HTTPException(status_code=422, detail="unsupported model role")
    if body.scope == "global" and "platform_admin" not in principal.roles:
        raise HTTPException(status_code=403, detail="global routes require platform admin")
    selected = next(
        (model for model in model_catalog() if model.model_id == body.model_id),
        None,
    )
    if selected is None or role not in selected.roles:
        raise HTTPException(status_code=422, detail="model does not support this role")
    if body.enabled and not selected.available:
        raise HTTPException(status_code=409, detail="model is not currently available")
    tenant_id = principal.tenant_id if body.scope == "tenant" else None
    route = (
        db.query(ModelRouteOverride)
        .filter_by(tenant_id=tenant_id, role=role)
        .one_or_none()
    )
    if route is None:
        route = ModelRouteOverride(
            id=new_resource_id("model_route"),
            tenant_id=tenant_id,
            role=role,
            model_id=body.model_id,
            enabled=body.enabled,
            created_by=principal.user_id,
        )
        db.add(route)
    else:
        route.model_id = body.model_id
        route.enabled = body.enabled
    record_audit(
        db,
        principal,
        "model.route_updated",
        "model_route",
        route.id,
        {"role": role, "scope": body.scope, "enabled": body.enabled},
    )
    db.commit()
    return {
        "route_id": route.id,
        "role": route.role,
        "model_id": route.model_id,
        "scope": body.scope,
        "enabled": route.enabled,
    }
