"""Job status endpoint."""

from __future__ import annotations

from core.models import GenerationRun, Job, SimulationArtifact
from core.schemas import JobStatusResponse
from core.security import Principal, current_principal, tenant_db
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

router = APIRouter(tags=["jobs"])

_CANONICAL_TO_LEGACY = {
    "queued": "QUEUED",
    "planning": "PLANNING",
    "compiling": "BUILDING_LEVEL",
    "building": "ASSEMBLING",
    "completed": "DEPLOYED",
    "failed_requirements": "FAILED",
    "failed_capability": "FAILED",
    "failed_build": "FAILED",
    "failed_validation": "FAILED",
    "failed_export": "FAILED",
}


@router.get("/jobs/{job_id}", response_model=JobStatusResponse)
def get_job(
    job_id: str,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> JobStatusResponse:
    job = (
        db.query(Job)
        .filter(Job.id == job_id, Job.tenant_id == principal.tenant_id)
        .one_or_none()
    )
    if job is None:
        run = (
            db.query(GenerationRun)
            .filter_by(id=job_id, tenant_id=principal.tenant_id)
            .one_or_none()
        )
        if run is None:
            raise HTTPException(status_code=404, detail=f"job '{job_id}' not found")
        artifacts = (
            db.query(SimulationArtifact).filter_by(run_id=run.id).all()
        )
        return JobStatusResponse(
            game_id=run.simulation_id,
            state=_CANONICAL_TO_LEGACY.get(run.state, "FAILED"),
            detail={
                **dict(run.detail or {}),
                "canonical_state": run.state,
                "canonical_stage": run.stage,
                "deprecated_adapter": True,
            },
            phases=[{"stage": run.stage, "state": run.state}],
            artifacts=[
                {"kind": item.kind, "url": item.uri}
                for item in artifacts
            ],
        )
    return JobStatusResponse(
        game_id=job.game_id,
        state=job.state,
        detail=job.detail or {},
        phases=[],  # populated once the S0-S8 pipeline exists (P1/P2)
        artifacts=[],
    )
