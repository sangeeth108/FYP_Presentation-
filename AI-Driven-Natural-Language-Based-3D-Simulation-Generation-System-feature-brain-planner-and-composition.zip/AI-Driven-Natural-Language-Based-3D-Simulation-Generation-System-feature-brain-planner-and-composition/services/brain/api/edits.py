"""Serendib Assist edit API (P3 AI-dock): plain-language edit -> validated spec.

The in-editor dock sends the game's current spec + an instruction ("make the
skeletons faster", "darker crypt"); this applies a bounded, registry-checked edit
and returns the new spec plus what changed. Stateless on purpose — the dock holds
the downloaded project, so no game must be looked up — and it never runs code:
edits only adjust allow-listed spec fields, then the same deterministic pipeline
re-exports (§10 rule 10, §14).

`valid` reports whether the edited spec still matches the frozen schema; the dock
should only re-export a valid spec.
"""

from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

import jsonschema
from agents.editor import llm_edit, plan_edit
from core.config import get_settings
from core.schemas import EditPreviewRequest, EditPreviewResponse
from core.security import (
    Principal,
    current_principal,
    ensure_generation_age_eligible,
    tenant_db,
)
from fastapi import APIRouter, Depends, HTTPException

router = APIRouter(tags=["edits"])

_SCHEMA_PATH = Path(__file__).resolve().parents[3] / "contracts" / "game_spec.schema.json"


@lru_cache(maxsize=1)
def _schema() -> dict:
    return json.loads(_SCHEMA_PATH.read_text(encoding="utf-8"))


@router.post("/edits/preview", response_model=EditPreviewResponse)
def preview_edit(body: EditPreviewRequest) -> EditPreviewResponse:
    # LLM edit when enabled (understands free phrasing), else the deterministic
    # keyword floor. Both go through the same bounded apply_ops, so either way the
    # result is in-contract; a dead model silently falls back.
    settings = get_settings()
    result = None
    if settings.llm_enabled:
        result = llm_edit(body.spec, body.instruction, settings)
    if result is None:
        result = plan_edit(body.spec, body.instruction)
    try:
        jsonschema.validate(result.spec, _schema())
        valid = True
    except jsonschema.ValidationError:
        # Edits are bounded, so this should not happen; if it ever does, the dock
        # is told the result is not safe to re-export rather than shipping it.
        valid = False
    return EditPreviewResponse(
        changed=result.changed,
        rejected=result.rejected,
        valid=valid,
        spec=result.spec,
    )


@router.post("/games/{game_id}/reexport", status_code=202)
def reexport_from_edit(
    game_id: str,
    body: dict,
    db=Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> dict:
    """One-click re-export: build a NEW shareable game from an edited spec.

    The dock POSTs the edited spec; we validate it (never trust an edit any more
    than a plan), stash it on a fresh job, and enqueue the SAME deterministic
    build pipeline (S3->S8), which skips the planner and uses the given spec.
    """
    ensure_generation_age_eligible(db, principal)
    from core.ids import new_job_id
    from core.models import Game, Job, JobState, Simulation
    from knowledge.registries import unknown_ids
    from worker.tasks import run_generation_job

    spec = body.get("spec")
    if not isinstance(spec, dict):
        raise HTTPException(status_code=422, detail="body.spec (object) is required")
    try:
        jsonschema.validate(spec, _schema())
    except jsonschema.ValidationError as exc:
        raise HTTPException(
            status_code=422,
            detail=f"edited spec is not in contract: {exc.message[:200]}",
        ) from exc

    # "In contract" is the schema AND the registry. A schema-valid spec can still
    # name a template we never built ("ai_teleporting_boss" is just a string), and
    # the pipeline's own allowlist gate does catch it — but minutes later, as a
    # FAILED job, after this endpoint already answered 202. The caller is waiting
    # for an answer now, so answer now: same machine-readable error object (§13),
    # returned instead of promised. The pipeline gate stays as defence in depth.
    invented = unknown_ids(spec)
    if invented:
        raise HTTPException(status_code=422, detail=invented[0])

    game = (
        db.query(Game)
        .filter(Game.id == game_id, Game.tenant_id == principal.tenant_id)
        .one_or_none()
    )
    if game is None:
        simulation = (
            db.query(Simulation)
            .filter_by(id=game_id, tenant_id=principal.tenant_id)
            .one_or_none()
        )
        if simulation is not None:
            raise HTTPException(
                status_code=410,
                detail={
                    "code": "LEGACY_REEXPORT_RETIRED",
                    "message": (
                        "Legacy game-spec re-export cannot mutate a canonical "
                        "simulation. Use /simulations/{id}/edits with a natural-"
                        "language instruction."
                    ),
                    "successor": f"/api/v1/simulations/{game_id}/edits",
                },
            )
        raise HTTPException(status_code=404, detail=f"unknown game {game_id}")

    job_id = new_job_id()
    db.add(
        Job(
            id=job_id,
            game_id=game_id,
            state=JobState.QUEUED.value,
            detail={"note": "reexport", "reexport_spec": spec},
            tenant_id=principal.tenant_id,
            owner_id=principal.user_id,
            residency_region=game.residency_region,
            retention_class=game.retention_class,
        )
    )
    db.commit()
    run_generation_job.delay(job_id)
    return {"game_id": game_id, "job_id": job_id}
