"""User feedback intake, quarantined from training by default."""

from __future__ import annotations

import json
from datetime import UTC, datetime

from core.audit import record_audit
from core.ids import new_resource_id
from core.models import (
    ContentRight,
    FeedbackEvent,
    Simulation,
    TrainingEligibility,
    UsageEvent,
)
from core.schemas import (
    FeedbackRequest,
    FeedbackResponse,
    UsageEventRequest,
    UsageEventResponse,
)
from core.security import Principal, current_principal, ensure_principal_records, tenant_db
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

router = APIRouter(tags=["feedback"])


@router.post("/feedback", status_code=202, response_model=FeedbackResponse)
def create_feedback(
    body: FeedbackRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> FeedbackResponse:
    ensure_principal_records(db, principal)
    target = body.learning_target or (
        "asset_ranker"
        if body.kind == "asset_choice"
        else "placement_ranker"
        if body.kind == "placement_correction"
        else None
    )
    if body.simulation_id:
        simulation = (
            db.query(Simulation)
            .filter_by(
                id=body.simulation_id,
                tenant_id=principal.tenant_id,
            )
            .one_or_none()
        )
        if simulation is None:
            raise HTTPException(status_code=404, detail="simulation not found")
    feedback = FeedbackEvent(
        id=new_resource_id("feedback"),
        tenant_id=principal.tenant_id,
        owner_id=principal.user_id,
        simulation_id=body.simulation_id,
        kind=body.kind,
        rating=body.rating,
        payload={
            **body.payload,
            **({"_learning_target": target} if target else {}),
        },
    )
    right = ContentRight(
        id=new_resource_id("right"),
        tenant_id=principal.tenant_id,
        owner_id=principal.user_id,
        resource_type="feedback",
        resource_id=feedback.id,
        rights_basis="user_attestation" if body.rights_attested else "unverified",
        training_allowed=body.rights_attested,
        # An attestation is evidence for a reviewer, not verification itself.
        verified_at=None,
    )
    db.add(feedback)
    db.add(right)
    for scope in ("global", "tenant_private"):
        category = (
            "assets"
            if target == "asset_ranker"
            else "telemetry"
            if target == "placement_ranker"
            else "prompt_spec"
        )
        db.add(
            TrainingEligibility(
                id=new_resource_id("eligibility"),
                tenant_id=principal.tenant_id,
                owner_id=principal.user_id,
                resource_type="feedback",
                resource_id=feedback.id,
                training_scope=scope,
                data_category=category,
                data_source="production_user",
                status="quarantined",
                content_right_id=right.id,
                moderation_status="pending",
                quality_status="pending",
                exclusion_reason="awaiting_moderation_and_quality",
            )
        )
    record_audit(
        db,
        principal,
        "feedback.created",
        "feedback",
        feedback.id,
        {"kind": body.kind},
    )
    db.commit()
    return FeedbackResponse(
        feedback_id=feedback.id,
        training_status="quarantined",
    )


@router.post("/usage-events", status_code=202, response_model=UsageEventResponse)
def create_usage_event(
    body: UsageEventRequest,
    db: Session = Depends(tenant_db),
    principal: Principal = Depends(current_principal),
) -> UsageEventResponse:
    ensure_principal_records(db, principal)
    simulation = (
        db.query(Simulation)
        .filter_by(id=body.simulation_id, tenant_id=principal.tenant_id)
        .one_or_none()
    )
    if simulation is None:
        raise HTTPException(status_code=404, detail="simulation not found")
    if len(json.dumps(body.payload, separators=(",", ":")).encode("utf-8")) > 16_384:
        raise HTTPException(status_code=413, detail="usage-event payload is too large")
    event = UsageEvent(
        id=new_resource_id("usage"),
        tenant_id=principal.tenant_id,
        owner_id=principal.user_id,
        simulation_id=simulation.id,
        event_type=body.event_type,
        payload=body.payload,
    )
    right = ContentRight(
        id=new_resource_id("right"),
        tenant_id=principal.tenant_id,
        owner_id=principal.user_id,
        resource_type="usage_event",
        resource_id=event.id,
        rights_basis="first_party_simulation_telemetry",
        training_allowed=True,
        verified_at=datetime.now(UTC),
    )
    db.add_all([event, right])
    for scope in ("global", "tenant_private"):
        db.add(
            TrainingEligibility(
                id=new_resource_id("eligibility"),
                tenant_id=principal.tenant_id,
                owner_id=principal.user_id,
                resource_type="usage_event",
                resource_id=event.id,
                training_scope=scope,
                data_category="telemetry",
                data_source="production_user",
                status="quarantined",
                content_right_id=right.id,
                moderation_status="pending",
                quality_status="pending",
                exclusion_reason="awaiting_moderation_and_quality",
            )
        )
    db.commit()
    return UsageEventResponse(
        usage_event_id=event.id,
        training_status="quarantined",
    )
