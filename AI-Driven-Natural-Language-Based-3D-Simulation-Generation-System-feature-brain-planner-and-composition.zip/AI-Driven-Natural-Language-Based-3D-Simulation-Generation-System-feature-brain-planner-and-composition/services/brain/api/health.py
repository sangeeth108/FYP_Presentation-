"""Liveness endpoint."""

from __future__ import annotations

from capabilities.registry import capability_index
from core import db
from core.config import get_settings
from core.observability import prometheus_text
from fastapi import APIRouter, HTTPException, Response
from sqlalchemy import text

router = APIRouter(tags=["health"])


@router.get("/healthz")
def healthz() -> dict[str, str]:
    return {"status": "ok"}


@router.get("/readyz")
def readyz() -> dict:
    checks: dict[str, str] = {}
    try:
        with db.session_scope() as session:
            session.execute(text("SELECT 1"))
        checks["database"] = "ok"
    except Exception as exc:
        checks["database"] = f"error:{type(exc).__name__}"
    try:
        checks["capability_registry"] = (
            "ok" if capability_index() else "error:empty"
        )
    except Exception as exc:
        checks["capability_registry"] = f"error:{type(exc).__name__}"
    settings = get_settings()
    if settings.promptplay_env == "production":
        try:
            import redis

            client = redis.Redis.from_url(
                settings.redis_url,
                socket_connect_timeout=1,
                socket_timeout=1,
            )
            client.ping()
            checks["redis"] = "ok"
        except Exception as exc:
            checks["redis"] = f"error:{type(exc).__name__}"
    else:
        checks["redis"] = "not_required"
    if any(value.startswith("error") for value in checks.values()):
        raise HTTPException(status_code=503, detail={"checks": checks})
    return {"status": "ready", "checks": checks}


@router.get("/metrics", include_in_schema=False)
def metrics() -> Response:
    return Response(
        content=prometheus_text(),
        media_type="text/plain; version=0.0.4",
    )
