"""Validated asset metadata used by the neutral simulation compiler."""

