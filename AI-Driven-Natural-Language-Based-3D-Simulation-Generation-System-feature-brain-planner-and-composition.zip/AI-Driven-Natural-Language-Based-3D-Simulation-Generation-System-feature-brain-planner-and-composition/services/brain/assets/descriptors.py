"""Build schema-bound AssetDescriptors from asset-farm lineage.

The asset farm owns retrieval and generation. This module turns its output into
the geometry/capability contract consumed by semantic PCG. Missing measurements
remain explicitly unverified; declared planner dimensions never masquerade as
imported dimensions.
"""

from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from pathlib import Path

import jsonschema

_REPO = Path(__file__).resolve().parents[3]
_SCHEMA = _REPO / "contracts" / "asset_descriptor.schema.json"
# Mirrors the asset farm's species fallback so an undeclared species is the same
# size wherever it is handled.
_DEFAULT_SPECIES_SIZE_M = (1.0, 1.5, 1.0)


# How far a normalised mesh may exceed its declared box on any axis before it has
# stopped being the thing that was declared. Set between the only two cases that have
# been measured, and the margin is stated because two points is thin:
#
#   T-posed character, must be ALLOWED: declared [0.7, 1.8, 0.7] imported
#       [1.09, 1.02, 0.20] scales to [1.92, 1.8, 0.35] -- worst overshoot 2.74x, because
#       outstretched arms legitimately span far wider than a declared shoulder width.
#   Flat-lying window, must be REFUSED: declared [1.0, 1.0, 0.1] imported
#       [1.5, 0.14, 1.43] scales to [10.84, 1.0, 10.32] -- worst overshoot 103x.
#
# The asymmetry is what makes a permissive threshold acceptable: a false positive costs
# one generated mesh and degrades to a correctly-sized procedural one, while a false
# negative puts a ten-metre window in a room and fails the whole world's layout.
_MAX_AXIS_OVERSHOOT = 4.0
# The same factor, downward. A mesh may be up to four times larger or four times SMALLER
# than its declared box on any axis; past that it has stopped being the thing declared.
#
# Undershoot was deliberately not judged, on the reasoning that a small mesh "leaves a
# gap, which reads as a modelling choice". A rendered village disproved it: two dwellings
# declared [8, 4, 6] m normalised to [1.9, 4.0, 0.4] m and shipped as 0.4 m-thin white
# slabs standing in a field. A house 6 m deep arriving 0.4 m deep is a billboard, not a
# gap.
#
# It is safe to judge here precisely BECAUSE normalisation matches height: the vertical
# axis always agrees, so an undershoot on x or z means the mesh's FOOTPRINT aspect is
# wrong rather than that it is merely small. The T-posed character that motivated the
# original asymmetry still survives -- [0.7, 1.8, 0.7] importing as [1.92, 1.8, 0.35]
# undershoots by 0.5, comfortably inside this.
_MIN_AXIS_UNDERSHOOT = 1.0 / _MAX_AXIS_OVERSHOOT


def implausible_proportions(
    declared: list[float], world_dimensions: list[float]
) -> tuple[bool, float, int]:
    """Whether a normalised mesh has stopped being the thing that was declared.

    Returns (implausible, worst ratio, which axis). Judged AFTER normalisation, because
    that is the size the world actually gets: an import may be any size at all, and only
    the scaled result has to be plausible.

    Both directions are judged, by the same factor. One many times larger overlaps its
    neighbours; one many times smaller is a billboard where a building was asked for.
    The returned ratio is the axis furthest from its declaration in either direction, so
    a caller reporting it still names the worst offender.
    """
    worst = 1.0
    deviation = 1.0
    axis = 0
    for index in range(min(len(declared), len(world_dimensions))):
        allowed = float(declared[index])
        if allowed <= 0.0:
            continue
        ratio = float(world_dimensions[index]) / allowed
        # How far from correct, regardless of direction, so one comparison ranks both.
        off = ratio if ratio >= 1.0 else 1.0 / max(ratio, 1e-9)
        if off > deviation:
            deviation, worst, axis = off, ratio, index
    implausible = worst > _MAX_AXIS_OVERSHOOT or worst < _MIN_AXIS_UNDERSHOOT
    return implausible, worst, axis


def normalised_dimensions(
    declared: list[float], imported: list[float]
) -> list[float]:
    """What an imported mesh becomes once scaled -- the same arithmetic as below.

    Exposed so a caller can ask "what WOULD this become?" before committing to it.
    """
    scale = _uniform_scale(declared, imported)
    return [max(0.001, float(value) * scale) for value in imported]


def _uniform_scale(declared: list[float], imported: list[float]) -> float:
    """The single factor bringing an imported mesh to its declared size.

    Height governs. Both boxes are Y-up -- the descriptor records that
    explicitly -- so the vertical axis is the one pairing that is guaranteed to
    mean the same thing in each. Nothing else is: an asset's widest axis need
    not correspond to the declared box's widest axis.

    Matching the LONGEST dimension of each assumed it did, and a T-posed
    character is the counter-example that reaches production. Measured on a live
    run: a visitor declared [0.7, 1.8, 0.7] imported as [1.09, 1.02, 0.20] --
    1.09 m of outstretched arms against 1.02 m of height. Scaling by longest to
    longest matched the ARM SPAN to the declared HEIGHT and produced a person
    1.8 m wide, 1.68 m tall and 0.33 m deep: a cardboard cut-out, at a scale no
    downstream stage could detect as wrong because every dimension was
    internally consistent.

    Falls back to longest-to-longest only when the vertical axis carries no
    usable information, which is the case for a flat asset such as a rug or a
    decal where height is legitimately near zero.
    """
    if len(declared) >= 2 and len(imported) >= 2:
        declared_height = float(declared[1])
        imported_height = float(imported[1])
        # A hair's breadth of height is noise, not a proportion to match on;
        # dividing by it would explode the scale.
        if declared_height > 0.01 and imported_height > 0.01:
            return declared_height / imported_height
    return max(declared) / max(imported)


@lru_cache(maxsize=1)
def asset_descriptor_schema() -> dict:
    return json.loads(_SCHEMA.read_text(encoding="utf-8"))


def validate_asset_descriptor(descriptor: dict) -> None:
    jsonschema.validate(descriptor, asset_descriptor_schema())


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _manifest_label(entity: dict, controlled_id: str, legacy_spec: dict) -> str:
    if entity["entity_id"] == controlled_id:
        return "player:main"
    source_id = entity["entity_id"][4:]
    object_ids = {
        item["object_id"] for item in legacy_spec.get("entities", {}).get("objects", [])
    }
    return f"object:{source_id}" if source_id in object_ids else f"prop:{source_id}"


def descriptors_from_manifest(
    simulation_spec: dict,
    legacy_spec: dict,
    manifest: dict[str, dict],
) -> tuple[dict[str, dict], list[dict]]:
    """Map legacy resolution labels back to canonical entities.

    Returns descriptors keyed by entity id and machine-readable errors. Only an
    asset with independently measured QA bounds receives ``MEASURED`` status.
    """
    entities = simulation_spec["entities"]
    controlled = next(
        (item for item in entities if item["role"] == "controlled_agent"),
        entities[0],
    )
    descriptors: dict[str, dict] = {}
    errors: list[dict] = []
    for entity in entities:
        label = _manifest_label(entity, controlled["entity_id"], legacy_spec)
        entry = manifest.get(label)
        declared = [float(value) for value in entity["physical"]["bbox_m"]]
        if not entry or entry.get("tier") == "unresolved":
            errors.append(
                {
                    "code": "ASSET_UNRESOLVED",
                    "entity_id": entity["entity_id"],
                    "asset_ref": label,
                }
            )
            continue
        qa = entry.get("qa") or {}
        imported = qa.get("bbox_dimensions")
        path = Path(entry.get("path") or "")
        if (
            not qa.get("passed")
            or not isinstance(imported, list)
            or len(imported) != 3
            or any(float(value) <= 0 for value in imported)
            or not path.is_file()
        ):
            errors.append(
                {
                    "code": "ASSET_MEASUREMENT_UNAVAILABLE",
                    "entity_id": entity["entity_id"],
                    "asset_ref": label,
                }
            )
            continue

        imported = [float(value) for value in imported]
        uniform_scale = _uniform_scale(declared, imported)
        world_dimensions = [max(0.001, value * uniform_scale) for value in imported]
        imported_center = [
            float(value) for value in qa.get("bbox_center") or [0.0, 0.0, 0.0]
        ]
        visual_offset = [-value * uniform_scale for value in imported_center]
        caps = qa.get("capabilities") or {}
        descriptor = {
            "schema_version": "1.0.0",
            "entity_id": entity["entity_id"],
            "asset_ref": label,
            "semantic_tags": sorted(
                {
                    entity["semantic_type"],
                    entity["role"],
                    entity["asset"]["category"],
                    *entity["capabilities"],
                }
            ),
            "source": {
                "tier": entry["tier"],
                "component": entry.get("component", "unknown"),
                "uri": str(path),
                "ai_generated": entry["tier"] in {"generated", "cache"},
            },
            "licence": {
                "identifier": entry.get("component", "unknown"),
                "commercial_use_verified": entry["tier"]
                in {"generated", "cache", "curated", "procedural"},
            },
            "content_hash": _sha256_file(path),
            "measurement": {
                "status": "MEASURED",
                "method": qa.get("measurement_method", "gltf_scene_aabb_v1"),
                "coordinate_system": "glTF right-handed Y-up",
                "units": "metres",
            },
            "imported_dimensions_m": imported,
            "world_dimensions_m": world_dimensions,
            "normalization_scale": [uniform_scale] * 3,
            "orientation": {"up_axis": "Y", "forward_axis": "-Z"},
            "pivot": {
                "mode": "center",
                "offset_m": visual_offset,
            },
            "collision": {
                "shape": "capsule"
                if entity["asset"]["category"] == "character"
                else "box",
                "validated": bool(qa.get("passed")),
            },
            "interaction": {
                "anchors": [],
                "clearance_m": 1.5 if entity["capabilities"] else 0.25,
            },
            "animation": {
                "rigged": bool(caps.get("rigged")),
                "clips": [
                    f"clip_{index + 1}"
                    for index in range(int(caps.get("animations", 0)))
                ],
                "locomotion_compatible": bool(caps.get("animated")),
            },
            "lods": [
                {
                    "level": 0,
                    "triangle_count": int(qa.get("tri_count") or 0),
                }
            ],
            "training_rights": {"status": "unverified"},
        }
        validate_asset_descriptor(descriptor)
        descriptors[entity["entity_id"]] = descriptor
    return descriptors, errors


def descriptors_from_simulation_manifest(
    simulation_spec: dict,
    manifest: dict[str, dict],
) -> tuple[dict[str, dict], list[dict]]:
    """Create canonical descriptors from a neutral entity-keyed asset manifest."""
    descriptors: dict[str, dict] = {}
    errors: list[dict] = []
    for entity in simulation_spec["entities"]:
        entity_id = entity["entity_id"]
        entry = manifest.get(entity_id)
        asset_ref = f"entity:{entity_id}"
        if not entry or entry.get("tier") == "unresolved":
            errors.append(
                {
                    "code": "ASSET_UNRESOLVED",
                    "entity_id": entity_id,
                    "asset_ref": asset_ref,
                }
            )
            continue
        qa = entry.get("qa") or {}
        imported = qa.get("bbox_dimensions")
        path = Path(entry.get("path") or "")
        if (
            not qa.get("passed")
            or not isinstance(imported, list)
            or len(imported) != 3
            or any(float(value) <= 0 for value in imported)
            or not path.is_file()
        ):
            errors.append(
                {
                    "code": "ASSET_MEASUREMENT_UNAVAILABLE",
                    "entity_id": entity_id,
                    "asset_ref": asset_ref,
                }
            )
            continue

        declared = [float(value) for value in entity["physical"]["bbox_m"]]
        imported = [float(value) for value in imported]
        uniform_scale = _uniform_scale(declared, imported)
        world_dimensions = [max(0.001, value * uniform_scale) for value in imported]
        imported_center = [
            float(value) for value in qa.get("bbox_center") or [0.0, 0.0, 0.0]
        ]
        visual_offset = [-value * uniform_scale for value in imported_center]
        caps = qa.get("capabilities") or {}
        descriptor = {
            "schema_version": "1.0.0",
            "entity_id": entity_id,
            "asset_ref": asset_ref,
            "semantic_tags": sorted(
                {
                    entity["semantic_type"],
                    entity["role"],
                    entity["asset"]["category"],
                    *entity["capabilities"],
                }
            ),
            "source": {
                "tier": entry["tier"],
                "component": entry.get("component", "unknown"),
                "uri": str(path),
                "ai_generated": entry["tier"] in {"generated", "cache"},
            },
            "licence": {
                "identifier": entry.get("component", "unknown"),
                "commercial_use_verified": entry["tier"]
                in {"generated", "cache", "curated", "procedural"},
            },
            "content_hash": _sha256_file(path),
            "measurement": {
                "status": "MEASURED",
                "method": qa.get("measurement_method", "gltf_scene_aabb_v1"),
                "coordinate_system": "glTF right-handed Y-up",
                "units": "metres",
            },
            "imported_dimensions_m": imported,
            "world_dimensions_m": world_dimensions,
            "normalization_scale": [uniform_scale] * 3,
            "orientation": {"up_axis": "Y", "forward_axis": "-Z"},
            "pivot": {"mode": "center", "offset_m": visual_offset},
            "collision": {
                "shape": "capsule"
                if entity["asset"]["category"] == "character"
                else "box",
                "validated": True,
            },
            "interaction": {
                "anchors": [],
                "clearance_m": 1.5 if entity["capabilities"] else 0.25,
            },
            "animation": {
                "rigged": bool(caps.get("rigged")),
                "clips": [
                    f"clip_{index + 1}"
                    for index in range(int(caps.get("animations", 0)))
                ],
                "locomotion_compatible": bool(caps.get("animated")),
            },
            "lods": [{"level": 0, "triangle_count": int(qa.get("tri_count") or 0)}],
            "training_rights": {"status": "unverified"},
        }
        validate_asset_descriptor(descriptor)
        descriptors[entity_id] = descriptor

    # Scatter species are assets too. Without a descriptor the instancer falls
    # back to the planner's declared `size_m`, so `footprint_measured` is always
    # false and spacing is a guess; measuring here lets Poisson-disk use the real
    # canopy width and lets the writer instance the actual mesh.
    for species in simulation_spec.get("scatter") or ():
        species_id = species["species_id"]
        entry = manifest.get(species_id)
        qa = (entry or {}).get("qa") or {}
        imported = qa.get("bbox_dimensions")
        path = Path((entry or {}).get("path") or "")
        if (
            not entry
            or entry.get("tier") == "unresolved"
            or not qa.get("passed")
            or not isinstance(imported, list)
            or len(imported) != 3
            or any(float(value) <= 0 for value in imported)
            or not path.is_file()
        ):
            # Advisory, not fatal: decoration must never sink a simulation whose
            # entities are all sound. The writer draws a correctly sized
            # placeholder instead, and this error says why it is a placeholder.
            errors.append(
                {
                    "code": "SCATTER_ASSET_UNRESOLVED",
                    "entity_id": species_id,
                    "asset_ref": f"scatter:{species_id}",
                    "severity": "advisory",
                }
            )
            continue

        declared = [
            float(value) for value in (species.get("size_m") or _DEFAULT_SPECIES_SIZE_M)
        ]
        imported = [float(value) for value in imported]
        uniform_scale = _uniform_scale(declared, imported)
        world_dimensions = [max(0.001, value * uniform_scale) for value in imported]
        imported_center = [
            float(value) for value in qa.get("bbox_center") or [0.0, 0.0, 0.0]
        ]
        descriptor = {
            "schema_version": "1.0.0",
            "entity_id": species_id,
            "asset_ref": f"scatter:{species_id}",
            "semantic_tags": sorted(
                {
                    str(species.get("semantic_type") or "scatter"),
                    "scatter_species",
                }
            ),
            "source": {
                "tier": entry["tier"],
                "component": entry.get("component", "unknown"),
                "uri": str(path),
                "ai_generated": entry["tier"] in {"generated", "cache"},
            },
            "licence": {
                "identifier": entry.get("component", "unknown"),
                "commercial_use_verified": entry["tier"]
                in {"generated", "cache", "curated", "procedural"},
            },
            "content_hash": _sha256_file(path),
            "measurement": {
                "status": "MEASURED",
                "method": qa.get("measurement_method", "gltf_scene_aabb_v1"),
                "coordinate_system": "glTF right-handed Y-up",
                "units": "metres",
            },
            "imported_dimensions_m": imported,
            "world_dimensions_m": world_dimensions,
            "normalization_scale": [uniform_scale] * 3,
            "orientation": {"up_axis": "Y", "forward_axis": "-Z"},
            "pivot": {
                "mode": "center",
                "offset_m": [-value * uniform_scale for value in imported_center],
            },
            # Scatter is instanced geometry with no collision body and no
            # behaviour; it decorates a world, it does not act in one.
            "collision": {"shape": "box", "validated": True},
            "interaction": {"anchors": [], "clearance_m": 0.25},
            "animation": {"rigged": False, "clips": [], "locomotion_compatible": False},
            "lods": [{"level": 0, "triangle_count": int(qa.get("tri_count") or 0)}],
            "training_rights": {"status": "unverified"},
        }
        validate_asset_descriptor(descriptor)
        descriptors[species_id] = descriptor
    return descriptors, errors
