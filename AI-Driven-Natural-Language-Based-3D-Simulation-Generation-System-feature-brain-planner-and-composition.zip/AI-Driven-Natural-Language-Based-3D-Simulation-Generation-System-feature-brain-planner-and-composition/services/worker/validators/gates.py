"""The 8-gate validation stack (docs/VALIDATION_PLAN.md), run in order.

Implemented for real: 1 (schema), 2 (constraints), 3 (asset QA), 4
(import/export), 5 (static playability — grid BFS solvers), 6 (dynamic bot),
8 (lineage). Recorded as an honest skip until its tier exists: 7 (LLM critic
— opt-in, advisory). Every failure carries the documented error shape:
{code, gate, path, message, hint, failure_class}.

A gate is SKIPPED only when the thing it judges did not run (no build, no bot,
no asset farm) — never as a stand-in for "not built yet". A gate that reports
PASS without checking anything is worse than no gate: gate 6 recorded SKIPPED
on every job for weeks while claiming games were playtested.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from godot_client.project_writer import _locked_door_placement
from godot_client.walls import CELL, covered_cells, floor_rects

RAMP_STEP = 1.6  # max walkable elevation change between adjacent cells (ramp rise 1.5)


@dataclass(frozen=True)
class ValidationError:
    code: str
    gate: int
    path: str
    message: str
    hint: str
    failure_class: str  # schema | asset | build | logic | quality
    # Numbers the repair loop needs to fix this deterministically. An error that
    # only a human can read is only half machine-readable: the repairer should
    # never have to parse `message` back into integers.
    data: dict | None = None

    def to_dict(self) -> dict:
        return asdict(self)


def run_gates(
    spec: dict,
    plan: dict,
    schema: dict | None = None,
    build_result: dict | None = None,
    bot_verdict: str | None = None,
    asset_manifest: dict[str, dict] | None = None,
    affordance_verdict: str | None = None,
) -> dict:
    """Run all gates in order; returns {verdict, gates: [...], errors: [...]}."""
    gates: list[dict] = []
    errors: list[ValidationError] = []

    def record(number: int, name: str, gate_errors: list[ValidationError] | None) -> None:
        if gate_errors is None:
            gates.append({"gate": number, "name": name, "verdict": "SKIPPED"})
        else:
            gates.append(
                {"gate": number, "name": name, "verdict": "PASS" if not gate_errors else "FAIL"}
            )
            errors.extend(gate_errors)

    record(1, "schema", _gate1_schema(spec, schema) if schema is not None else None)
    record(2, "constraints", _gate2_constraints(spec, plan))
    record(3, "asset_qa", _gate3_asset_qa(asset_manifest) if asset_manifest else None)
    record(4, "import_export", _gate4_export(spec, build_result) if build_result else None)
    record(5, "static_playability", _gate5_playability(plan, spec))
    record(
        6,
        "dynamic_playtest",
        _gate6_dynamic(bot_verdict, affordance_verdict)
        if (bot_verdict is not None or affordance_verdict is not None)
        else None,
    )
    record(7, "quality_critic", None)  # opt-in LLM critic (advisory)
    record(8, "lineage", _gate8_lineage(spec, require_build=build_result is not None))

    return {
        "verdict": "PASS" if not errors else "FAIL",
        "gates": gates,
        "errors": [e.to_dict() for e in errors],
    }


def _gate1_schema(spec: dict, schema: dict) -> list[ValidationError]:
    import jsonschema

    try:
        jsonschema.validate(spec, schema)
        return []
    except jsonschema.ValidationError as exc:
        return [
            ValidationError(
                code="SPEC_SCHEMA_VIOLATION",
                gate=1,
                path="$." + ".".join(str(p) for p in exc.absolute_path),
                message=exc.message[:300],
                hint="The planner must emit a spec valid against the frozen v2 schema.",
                failure_class="schema",
            )
        ]


def _gate3_asset_qa(manifest: dict[str, dict]) -> list[ValidationError]:
    """Gate 3 — asset QA (docs/VALIDATION_PLAN.md).

    The policy is explicit: a QA failure gets one regen attempt then a curated
    substitute, and **never blocks**. So this gate does NOT re-run QA and does not
    fail a game for an ugly asset — the resolver already fell back, which is the
    designed outcome, not an error.

    What it does is verify the resolver's *promise* independently: **nothing
    ships un-gated**. A shipped asset whose own QA report says it failed is a
    contradiction — a resolver bug, not an asset problem — and a shipped asset
    whose file is missing is a broken reference. A gate that only ever agrees
    with the thing it is checking is theatre; these are the two ways the S5
    contract can actually be violated, and both are worth blocking on.

    SKIPPED (None upstream) when no farm ran at all.
    """
    errors: list[ValidationError] = []
    for label, entry in sorted(manifest.items()):
        tier = entry.get("tier")
        if tier not in ("generated", "cache", "curated"):
            continue  # unresolved: nothing shipped, the writer used its default

        path = entry.get("path") or ""
        if not path or not Path(path).is_file():
            errors.append(
                ValidationError(
                    code="ASSET_FILE_MISSING",
                    gate=3,
                    path=f"$.assets['{label}']",
                    message=f"{label} resolved to '{path or '(empty)'}' which is not a file",
                    hint="The farm recorded an asset the build cannot reference; re-resolve it.",
                    failure_class="asset",
                    data={"label": label, "tier": tier, "path": path},
                )
            )
            continue

        qa = entry.get("qa")
        if qa is not None and not qa.get("passed", True):
            codes = [e.get("code") for e in qa.get("errors", [])]
            errors.append(
                ValidationError(
                    code="ASSET_SHIPPED_WITHOUT_PASSING_QA",
                    gate=3,
                    path=f"$.assets['{label}']",
                    message=(
                        f"{label} shipped from tier '{tier}' but its QA report failed: "
                        f"{','.join(str(c) for c in codes)}"
                    ),
                    hint=(
                        "The resolver must fall back to curated when QA fails — this is a "
                        "resolver bug, not an asset problem."
                    ),
                    failure_class="asset",
                    data={"label": label, "tier": tier, "qa_errors": codes},
                )
            )
    return errors


def _gate2_constraints(spec: dict, plan: dict) -> list[ValidationError]:
    """Deterministic cross-field rules the schema alone cannot express."""
    errors: list[ValidationError] = []
    camera = spec["meta"]["camera"]
    controller = spec["player"].get("controller_template_id", "")
    expected = {
        "third_person": "controller_third_person",
        "top_down_3d": "controller_topdown_3d",
        "isometric_3d": "controller_isometric_3d",
    }[camera]
    if controller != expected:
        errors.append(
            ValidationError(
                code="CAMERA_CONTROLLER_MISMATCH",
                gate=2,
                path="$.player.controller_template_id",
                message=f"camera '{camera}' requires '{expected}', got '{controller}'",
                hint="The spec builder must keep camera and controller in lockstep.",
                failure_class="schema",
            )
        )

    total_enemies = sum(e["count"] for e in spec["entities"]["enemies"])
    if total_enemies > spec["budgets"].get("max_enemies", 25):
        errors.append(
            ValidationError(
                code="ENEMY_BUDGET_EXCEEDED",
                gate=2,
                path="$.entities.enemies",
                message=f"{total_enemies} enemies > budget {spec['budgets']['max_enemies']}",
                hint="Lower enemy counts or raise budgets.max_enemies (≤25).",
                failure_class="schema",
            )
        )
    if len(spec["entities"]["props"]) > spec["budgets"].get("max_props", 200):
        errors.append(
            ValidationError(
                code="PROP_BUDGET_EXCEEDED",
                gate=2,
                path="$.entities.props",
                message=f"{len(spec['entities']['props'])} props > budget",
                hint="Reduce props or raise budgets.max_props (≤200).",
                failure_class="schema",
            )
        )

    planned = plan["zones"]
    if len(planned) != spec["world"]["zone_graph"]["zone_count"]:
        errors.append(
            ValidationError(
                code="PLAN_SPEC_ZONE_DRIFT",
                gate=2,
                path="$.world.zone_graph.zone_count",
                message=f"plan has {len(planned)} zones, spec says "
                f"{spec['world']['zone_graph']['zone_count']}",
                hint="The level plan must be regenerated from this exact spec.",
                failure_class="logic",
            )
        )
    return errors


def _gate4_export(spec: dict, build_result: dict) -> list[ValidationError]:
    errors: list[ValidationError] = []
    budget_mb = spec["budgets"].get("max_web_build_mb", 90)
    size_mb = build_result["total_bytes"] / 1024 / 1024
    if size_mb > budget_mb:
        errors.append(
            ValidationError(
                code="BUILD_OVER_BUDGET",
                gate=4,
                path="$.budgets.max_web_build_mb",
                message=f"web build {size_mb:.1f} MB > budget {budget_mb} MB",
                hint="Reduce kit models/props or raise the budget (hard cap 90).",
                failure_class="build",
            )
        )
    names = {p.name for p in build_result["files"]}
    if "index.html" not in names or not any(n.endswith(".wasm") for n in names):
        errors.append(
            ValidationError(
                code="BUILD_INCOMPLETE",
                gate=4,
                path="$",
                message=f"export missing core files (got: {sorted(names)[:5]}...)",
                hint="Inspect the godot export log; verify the Web preset.",
                failure_class="build",
            )
        )
    return errors


def _walkable_graph(plan: dict) -> dict[tuple[int, int], float]:
    return covered_cells(floor_rects(plan))


def _cell_of(x: float, z: float) -> tuple[int, int]:
    return (int(x // CELL), int(z // CELL))


def _reachable(
    cells: dict[tuple[int, int], float],
    start: tuple[int, int],
    blocked: set[tuple[int, int]],
) -> set[tuple[int, int]]:
    if start not in cells:
        return set()
    seen = {start}
    frontier = [start]
    while frontier:
        i, j = frontier.pop()
        here = cells[(i, j)]
        for n in ((i + 1, j), (i - 1, j), (i, j + 1), (i, j - 1)):
            if n in seen or n in blocked or n not in cells:
                continue
            if abs(cells[n] - here) > RAMP_STEP:
                continue  # cliff: ramps bridge at most one tier step
            seen.add(n)
            frontier.append(n)
    return seen


def collect_quest_of(spec: dict) -> dict | None:
    """The collect_n objective + the props that satisfy it, or None.

    Shared by the validator and the project writer so they can never disagree
    about what the quest is (the writer builds it; this gate proves it winnable).
    """
    objective = next(
        (o for o in spec.get("objectives", []) if o.get("objective_template_id") == "collect_n"),
        None,
    )
    if objective is None:
        return None
    prop_ids = [
        p["prop_id"]
        for p in spec.get("entities", {}).get("props", [])
        if p.get("interactable_template_id") == "pickup_supply"
    ]
    params = objective.get("params", {})
    return {
        "objective_id": objective["objective_id"],
        "required_count": int(params.get("required_count", 0)),
        "prop_ids": prop_ids,
        "label": str(params.get("label", "Collectibles")),
    }


def _gate5_playability(plan: dict, spec: dict | None = None) -> list[ValidationError]:
    """Grid BFS solvers: key reachable with the door shut; exit reachable after."""
    kinds = {z["zone_id"]: z["kind"] for z in plan["zones"]}
    rooms = {r["zone_id"]: r for r in plan["rooms"]}

    def center_cell(zone_id: str) -> tuple[int, int]:
        r = rooms[zone_id]
        return _cell_of(r["x"] + r["width"] / 2, r["z"] + r["depth"] / 2)

    entry = next(zid for zid, k in kinds.items() if k == "entry")
    key = next((zid for zid, k in kinds.items() if k == "key"), None)
    exit_id = next(zid for zid, k in kinds.items() if k == "exit")

    cells = _walkable_graph(plan)
    door = _locked_door_placement(plan, rooms, exit_id)
    blocked: set[tuple[int, int]] = set()
    if door is not None:
        axis, dx, dz, _ = door
        span = int(2.4 / CELL)
        for offset in range(-span, span + 1):
            if axis == "x":  # door plane spans z at fixed x
                blocked.add(_cell_of(dx, dz + offset * CELL))
                blocked.add(_cell_of(dx - CELL, dz + offset * CELL))
            else:  # spans x at fixed z
                blocked.add(_cell_of(dx + offset * CELL, dz))
                blocked.add(_cell_of(dx + offset * CELL, dz - CELL))

    errors: list[ValidationError] = []
    reachable_shut = _reachable(cells, center_cell(entry), blocked)
    if key is not None and center_cell(key) not in reachable_shut:
        errors.append(
            ValidationError(
                code="KEY_UNREACHABLE",
                gate=5,
                path="$.objectives[0]",
                message=f"no walkable path entry '{entry}' -> key zone '{key}' with the door shut",
                hint="Zone graph edge missing/blocked, or a ramp failed to bridge tiers.",
                failure_class="logic",
            )
        )
    reachable_open = _reachable(cells, center_cell(entry), set())
    if center_cell(exit_id) not in reachable_open:
        errors.append(
            ValidationError(
                code="EXIT_UNREACHABLE",
                gate=5,
                path="$.objectives[-1]",
                message=(
                    f"no walkable path entry '{entry}' -> exit '{exit_id}' "
                    "even with the door open"
                ),
                hint="Check the locked corridor's geometry and ramp insertion.",
                failure_class="logic",
            )
        )

    quest = collect_quest_of(spec) if spec else None
    if quest:
        # The pickups ARE the key: they unlock the exit door, so every one the
        # player needs must be gatherable with the door still shut, and there
        # must be at least as many placed as the quest demands. A quest that
        # asks for more relics than exist builds perfectly and can never be won.
        placed = [
            e
            for e in plan["entities"]
            if e["kind"] == "prop" and e["source_id"] in set(quest["prop_ids"])
        ]
        required = quest["required_count"]
        if required < 1 or len(placed) < required:
            errors.append(
                ValidationError(
                    code="COLLECT_QUEST_IMPOSSIBLE",
                    gate=5,
                    path="$.objectives[?(@.objective_template_id=='collect_n')].params.required_count",
                    message=(
                        f"collect_n needs {required} pickup(s) but only {len(placed)} "
                        "pickup_supply prop(s) are placed in the level"
                    ),
                    hint="Author at least required_count props with interactable_template_id "
                    "'pickup_supply', and keep required_count >= 1.",
                    failure_class="logic",
                    data={"required": required, "placed": len(placed)},
                )
            )
        else:
            stranded = [
                e["entity_id"]
                for e in placed
                if _cell_of(e["x"], e["z"]) not in reachable_shut
            ]
            # Only the required_count cheapest-to-reach must be gatherable, but any
            # stranded pickup is still a bug worth reporting when it breaks the count.
            if len(placed) - len(stranded) < required:
                errors.append(
                    ValidationError(
                        code="PICKUPS_UNREACHABLE",
                        gate=5,
                        path="$.entities.props",
                        message=(
                            f"only {len(placed) - len(stranded)} of {len(placed)} pickups are "
                            f"reachable with the door shut, but {required} are required "
                            f"(stranded: {', '.join(stranded[:5])})"
                        ),
                        hint="Pickups behind the locked door cannot be collected before it opens.",
                        failure_class="logic",
                    )
                )
    return errors


def _gate6_dynamic(
    bot_verdict: str | None, affordance_verdict: str | None
) -> list[ValidationError]:
    """Gate 6 = dynamic playtest: the win-path bot AND the affordance oracle.

    Both play the built game headlessly by reading state; either failing fails the
    gate. Each is judged only when its verdict was produced (a missing engine
    leaves its verdict None -> that check is simply absent, never a false FAIL)."""
    errors: list[ValidationError] = []
    if bot_verdict is not None:
        errors += _gate6_bot(bot_verdict)
    if affordance_verdict is not None:
        errors += _gate6_affordances(affordance_verdict)
    return errors


def _gate6_bot(bot_verdict: str) -> list[ValidationError]:
    if bot_verdict.startswith("GREEDYBOT_OK"):
        return []
    return [
        ValidationError(
            code="BOT_DID_NOT_COMPLETE",
            gate=6,
            path="$",
            message=f"playtest bot verdict: {bot_verdict[:200]}",
            hint="Run the bot locally with diagnostics to identify the blocker.",
            failure_class="logic",
        )
    ]


def _gate6_affordances(affordance_verdict: str) -> list[ValidationError]:
    """A composed affordance (car door, house door, lever) that never opens fails
    HERE, not in front of a player (ADR-0008). AFFORDANCE_OK passes."""
    if affordance_verdict.startswith("AFFORDANCE_OK"):
        return []
    return [
        ValidationError(
            code="AFFORDANCE_DID_NOT_WORK",
            gate=6,
            path="$",
            message=f"affordance oracle verdict: {affordance_verdict[:200]}",
            hint="A composite object's interactable part did not open; check its "
            "socket/template binding, then re-run the affordance check.",
            failure_class="logic",
        )
    ]


def _gate8_lineage(spec: dict, require_build: bool = True) -> list[ValidationError]:
    lineage = spec.get("lineage", {})
    required = ("prompt", "build_hash") if require_build else ("prompt",)
    missing = [field for field in required if not lineage.get(field)]
    if spec["meta"].get("seed") is None:
        missing.append("meta.seed")
    if not missing:
        return []
    return [
        ValidationError(
            code="LINEAGE_INCOMPLETE",
            gate=8,
            path="$.lineage",
            message=f"missing lineage fields: {', '.join(missing)}",
            hint="DEPLOYED is blocked until reproducibility data is complete.",
            failure_class="build",
        )
    ]


def report_to_json(report: dict) -> str:
    return json.dumps(report, sort_keys=True, separators=(",", ":"))
