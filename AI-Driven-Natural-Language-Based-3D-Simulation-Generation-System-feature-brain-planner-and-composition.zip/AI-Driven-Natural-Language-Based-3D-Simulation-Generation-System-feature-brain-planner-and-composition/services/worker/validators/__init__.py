"""The 8-gate validation stack (docs/VALIDATION_PLAN.md). Cheapest first;
every verdict is machine-readable; strings-only errors are banned."""

from validators.gates import ValidationError, run_gates

__all__ = ["ValidationError", "run_gates"]
