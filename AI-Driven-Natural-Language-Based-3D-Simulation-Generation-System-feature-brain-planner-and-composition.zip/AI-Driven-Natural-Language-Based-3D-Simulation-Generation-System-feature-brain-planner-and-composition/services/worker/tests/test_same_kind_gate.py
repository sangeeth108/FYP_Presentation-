"""The library may only answer with the same KIND of thing.

Measured on a forest run, once the category fix let the library be searched properly:

    spc_canopy_tree -> tree_oak.glb    0.819   right
    red fox         -> Fox.glb         0.697   right
    ent_squirrel    -> Cow.glb         ~0.65   a cow
    ent_bird        -> Horse.glb       ~0.65   a horse
    spc_ferns       -> wall-side.glb   ~0.70   a wall, scattered as undergrowth

A fox at 0.697 and a cow-for-a-squirrel at 0.65 are nearly the same number and opposite
answers, so no threshold separates them -- raise the bar and the fox is lost, lower it and
a horse stands in for a bird. The words separate them.

Refusing is safe by design: the caller falls through to the rest of the S5 ladder
(generation, then a procedural form), so a refused match never leaves an entity with
nothing -- it only stops the library answering a question it cannot.
"""

import pytest
from asset_farm.curated_match import CONFIDENT_SCORE, names_the_same_kind

# Every one of these was a REAL match in a measured run.
RIGHT = [
    ("canopy tree", "kenney-nature/models/tree_oak.glb a low-poly oak tree"),
    ("oak tree", "kenney-nature/models/tree_oak.glb an oak tree"),
    ("red fox", "quaternius/animals/Fox.glb a fox"),
    ("white-tailed deer", "quaternius/animals/Deer.glb a deer"),
    ("rocks", "kenney-nature/models/rock_largeA.glb a large rock"),
    ("field stone", "kenney-nature/models/rock_largeA.glb a large rock"),
    ("rotting log", "kenney-nature/models/log.glb a log"),
    ("chestnut stump", "kenney-nature/models/log.glb a log"),
    ("berry shrub", "kenney-nature/models/plant_bush.glb a bush"),
    ("visitor", "quaternius/characters/Man.glb an ordinary man"),
]

WRONG = [
    ("squirrel", "quaternius/animals/Cow.glb a cow"),
    ("bird", "quaternius/animals/Horse.glb a horse"),
    ("ferns", "kenney-town/models/wall-side.glb a wall side"),
    ("leaf litter", "kenney-town/models/roof.glb a roof"),
    ("stump", "kenney-town/models/roof-point.glb a roof point"),
    ("village dog", "quaternius/animals/Cow.glb a cow"),
    ("track lighting", "kenney-survival/models/torch.glb a burning torch"),
]


@pytest.mark.parametrize(("asked", "offered"), RIGHT)
def test_a_right_match_is_kept(asked: str, offered: str) -> None:
    assert names_the_same_kind(asked, offered)


@pytest.mark.parametrize(("asked", "offered"), WRONG)
def test_a_wrong_match_is_refused(asked: str, offered: str) -> None:
    assert not names_the_same_kind(asked, offered)


def test_a_shared_material_is_not_a_shared_kind() -> None:
    """The modifier must not outvote the head. English is head-final."""
    assert not names_the_same_kind("wooden barrel", "crate_wooden.glb a wooden crate")
    assert not names_the_same_kind("stone wall", "rock_largeA.glb a large rock")
    # ...but a material that IS the head still counts, which is why "field stone" works.
    assert names_the_same_kind("field stone", "rock_largeA.glb a large rock")


def test_singular_and_plural_are_the_same_kind() -> None:
    assert names_the_same_kind("rocks", "rock_largeA.glb a large rock")
    assert names_the_same_kind("branch", "kenney-nature/models/branches.glb branches")


def test_a_confident_embedding_needs_no_word_agreement() -> None:
    """A word list can never hold every synonymy an embedder knows.

    "a spellcaster" matches "a robed mage" at 1.0 and shares not one word with it. Above
    `CONFIDENT_SCORE` the vector is trusted on its own; below it the words must agree.
    """
    assert not names_the_same_kind("a spellcaster", "characters/B.glb a robed mage")
    assert CONFIDENT_SCORE == 0.85


def test_the_cache_cannot_serve_a_wrong_kind_either() -> None:
    """The cache remembers answers, including the wrong ones.

    Measured immediately after the gate shipped -- the matcher stopped offering a Cow for
    a squirrel, and the cache served one anyway because it is consulted before the matcher:

        ent_stump -> cabin-roof-point.glb   tier "cache"
        ent_cedar -> structure-canvas.glb   tier "cache"
    """
    from asset_farm.brief import AssetBrief
    from asset_farm.resolver import _cache_entry_names_the_same_kind as same_kind

    stump = AssetBrief(brief="a weathered chestnut stump", category="prop")
    assert not same_kind(stump, "/repo/content/kits/kenney-town/models/cabin-roof-point.glb")
    assert same_kind(stump, "/repo/content/kits/kenney-nature/models/log.glb")

    # A generated mesh is named by its brief hash: no words, so nothing to disagree with.
    # This must never reject a generated asset for being unnamed.
    assert same_kind(stump, "/repo/artifacts/asset_cache/9f2c1ab4e7d0.glb")


def test_the_keyword_tier_obeys_the_same_rule() -> None:
    """A rule enforced on one of two paths into the same decision is not enforced.

    The embedding tier stopped offering a wrong kind; the lexical tier beside it did not,
    and it is consulted for every brief. Measured on the next run, reported as
    `tier: curated` because that is what it was:

        ent_stump -> roof-point.glb   44 tris   a roof point, for a tree stump
    """
    from asset_farm.pipeline import _agreeing

    library = {
        "kenney-town/models/roof-point.glb": "a roof point",
        "kenney-nature/models/log.glb": "a log",
    }
    refused = _agreeing(
        ("kenney-town/models/roof-point.glb", 0.6), library, "a weathered stump", "stump"
    )
    assert refused is None

    kept = _agreeing(
        ("kenney-nature/models/log.glb", 0.6), library, "a weathered stump", "stump"
    )
    assert kept is not None

    assert _agreeing(None, library, "anything", None) is None


def test_a_generic_word_is_not_a_shared_kind() -> None:
    """Words that name no thing occur in every vocabulary and identify nothing.

    Measured: `ent_stump` declared its `semantic_type` as "observation_point" and was
    answered with `roof-point.glb` -- a roof point, for a hollowed tree stump -- because
    both phrases contain "point". The visual critic then failed the scene for having no
    recognisable observation point, which was exactly right.
    """
    stump = "observation_point a large hollowed stump of a Douglas Fir tree"
    assert not names_the_same_kind(stump, "kenney-town/models/roof-point.glb a roof point")
    # The real thing it should reach is still reachable, via the stump/log family.
    assert names_the_same_kind(stump, "kenney-nature/models/log.glb a log")

    # "detailed" and "large" are decoration in a library filename, not identity.
    assert names_the_same_kind("rocks", "kenney-nature/models/rock_detailed.glb a rock")


def test_variety_is_for_people_not_for_species() -> None:
    """An animal may repeat; it may not become a different animal.

    The anti-duplicate rule exists because "two identical people is a fault" -- a station
    guard and a tea vendor as two copies of Man.glb. Applied to every character, it pushed
    animals off their own species. Measured across two runs of the same prompt:

        ent_deer -> Deer.glb   then   ent_deer -> Cow.glb
        ent_bird -> Wolf.glb   then   ent_bird -> Horse.glb

    and the visual critic failed the scene with "does not match the description of a
    realistic deer model".
    """
    import inspect

    from asset_farm import pipeline

    source = inspect.getsource(pipeline.resolve_simulation_assets)
    # The exclusion must be intersected with the ordinary human bodies, not applied to
    # every character. Guards the specific line whose absence caused the swap.
    assert "ORDINARY_HUMAN_MODELS" in source
    assert "reserved = used_characters & set(ORDINARY_HUMAN_MODELS)" in source


def test_a_shared_habitat_is_not_a_shared_kind() -> None:
    """WHERE a thing lives identifies nothing.

    Measured: `ent_bird` asked for "a small forest bird, brown and grey plumage" and was
    answered with Wolf.glb, described as "a grey wolf, a wild snarling predator of the
    forest, a dire beast". The two share the word "forest" and nothing else. A bird is not
    a wolf that lives nearby.
    """
    bird = "bird a small forest bird, brown and grey plumage"
    wolf = (
        "quaternius/animals/Wolf.glb a grey wolf, a wild snarling predator of the "
        "forest, a dire beast"
    )
    assert not names_the_same_kind(bird, wolf)
    assert not names_the_same_kind(bird, "quaternius/animals/Deer.glb a deer")

    # A real species word still carries, habitat or not.
    assert names_the_same_kind("village dog", "quaternius/animals/Husky.glb a husky dog")
    assert names_the_same_kind("deer", "quaternius/animals/Deer.glb a deer")


def test_an_animal_is_never_answered_by_a_person() -> None:
    """Measured after tiny scatter moved to procedural, which freed the character shelf:

        ent_bird     -> Woman.glb    1908 tris
        ent_squirrel -> Farmer.glb   5476 tris

    Worse than the wrong quadrupeds before them -- a wolf is at least an animal.
    `default_character_model` reads the brief lexically and `_unused_human` then spreads
    unmatched PEOPLE across the ordinary bodies; neither asked whether this was a person.
    """
    import inspect

    from asset_farm import pipeline

    source = inspect.getsource(pipeline.resolve_simulation_assets)
    # The animal branch must come BEFORE the human spreading, or a bird reaches Woman.
    animal_at = source.index("_names_an_animal(")
    human_at = source.index("_unused_human(")
    assert animal_at < human_at
    assert "DEFAULT_ANIMAL_MODEL" in source

    assert pipeline._names_an_animal("bird a small forest bird capable of flying")
    assert pipeline._names_an_animal("squirrel a small forest squirrel")
    assert not pipeline._names_an_animal("visitor a museum visitor in a coat")
