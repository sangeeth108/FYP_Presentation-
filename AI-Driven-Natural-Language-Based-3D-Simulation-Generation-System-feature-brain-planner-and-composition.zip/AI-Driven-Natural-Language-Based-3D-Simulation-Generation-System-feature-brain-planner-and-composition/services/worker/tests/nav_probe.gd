extends SceneTree

## Headless navigation probe (test asset, not shipped): loads main.tscn,
## waits for the nav map to sync, then asks NavigationServer3D for a real
## path near every enemy and from the player spawn. Prints NAVPROBE_OK or
## NAVPROBE_FAIL and exits accordingly. Run:
##   godot --headless --path <project> --script res://nav_probe.gd

var _frames := 0


func _initialize() -> void:
	var scene := (load("res://main.tscn") as PackedScene).instantiate()
	root.add_child(scene)


func _process(_delta: float) -> bool:
	_frames += 1
	if _frames < 10:
		return false

	var map: RID = root.find_world_3d().navigation_map
	var total := 0
	var ok := 0
	for enemy in get_nodes_in_group("enemies"):
		total += 1
		var from: Vector3 = enemy.global_position
		var path := NavigationServer3D.map_get_path(map, from, from + Vector3(2, 0, 0), true)
		if path.size() >= 2:
			ok += 1

	var spawn := root.get_node_or_null("World/PlayerSpawn")
	var spawn_ok := false
	if spawn != null:
		var p := NavigationServer3D.map_get_path(
			map, spawn.global_position, spawn.global_position + Vector3(2, 0, 0), true
		)
		spawn_ok = p.size() >= 2

	if total > 0 and ok == total and spawn_ok:
		print("NAVPROBE_OK enemies=%d" % total)
		quit(0)
	else:
		print("NAVPROBE_FAIL enemies=%d ok=%d spawn_ok=%s" % [total, ok, spawn_ok])
		quit(1)
	return true
