"""Generated character sound: a dog should bark, not rattle like a skeleton.

The curated tier answers "what does this MODEL FAMILY sound like"; this answers
"what does THIS character sound like", from the identity the planner wrote. Both
hang off the same activities the vetted AI template performs (ADR-0004), and the
curated set is always underneath — the build never gets quieter for trying.
"""

import json
from pathlib import Path

import pytest
from asset_farm.backends import MockAudioBackend, MockBackend
from asset_farm.brief import AssetBrief
from asset_farm.pipeline import resolve_spec_assets, shippable_sounds
from asset_farm.qa_audio import qa_audio
from asset_farm.resolver import resolve_asset
from asset_farm.sound_brief import ACTIVITY_PHRASE, activity_sound_brief, activity_sound_briefs
from godot_client.asset_kit import SOUND_SETS
from godot_client.project_writer import write_project
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan

REPO = Path(__file__).resolve().parents[3]
KIT = REPO / "content" / "kits"  # curated root (one folder per pack)
SFX = REPO / "content" / "kits" / "catsfx"
LEDGER = str(REPO / "docs" / "licensing_ledger.csv")
GOLDEN_SPEC = REPO / "contracts" / "examples" / "golden_game.spec.json"

DOG = "a snarling low-poly village dog"


@pytest.fixture(scope="module")
def spec():
    s = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    for enemy in s["entities"]["enemies"]:
        enemy["asset_brief"] = {"brief": DOG, "category": "character"}
    return s


@pytest.fixture(scope="module")
def golden_plan(spec):
    return to_level_plan(run_pcg(spec))


# --- briefs derived from WHO the character is -----------------------------


def test_the_character_is_the_subject_of_its_own_sounds():
    brief = activity_sound_brief(DOG, "attack")
    assert brief.brief.startswith(DOG)
    assert "attacking" in brief.brief
    assert brief.category == "audio_sfx"


def test_every_activity_the_ai_performs_can_be_described():
    # If the AI template grows an activity, the generate tier must not lag the
    # curated tier — this pins the two together.
    for family in SOUND_SETS.values():
        assert set(family) == set(ACTIVITY_PHRASE)
    assert set(activity_sound_briefs(DOG)) == set(ACTIVITY_PHRASE)


def test_the_same_character_and_activity_always_hash_the_same():
    # Determinism is what makes the cache work: rebuild the game, don't re-spend
    # minutes of GPU on a sound we already made (rule 14).
    assert activity_sound_brief(DOG, "hit").hash() == activity_sound_brief(DOG, "hit").hash()


def test_different_characters_and_activities_do_not_collide():
    hashes = {activity_sound_brief(DOG, a).hash() for a in ACTIVITY_PHRASE}
    assert len(hashes) == len(ACTIVITY_PHRASE)
    assert activity_sound_brief("a stone golem", "attack").hash() != (
        activity_sound_brief(DOG, "attack").hash()
    )


def test_style_directives_survive_a_rambling_character_description():
    # A brief is capped at 200 chars; the subject must be clamped so the "one-shot,
    # dry, no music" instructions cannot be truncated away — without them the
    # generator returns a music bed, which is useless as a game cue.
    brief = activity_sound_brief("a dog " + "extremely " * 40 + "large", "attack")
    assert len(brief.brief) <= 200
    assert "no music" in brief.brief
    assert "one-shot" in brief.brief


def test_an_unknown_activity_is_refused():
    with pytest.raises(ValueError, match="unknown activity"):
        activity_sound_brief(DOG, "sneeze")


# --- generation + gating ---------------------------------------------------


def test_a_generated_clip_is_real_audio_that_passes_the_gate(tmp_path):
    made = MockAudioBackend().generate(activity_sound_brief(DOG, "attack"), tmp_path)
    assert qa_audio(made.path, AssetBrief("x" * 5, "audio_sfx")).passed


def test_sound_resolves_through_the_same_tree_as_a_mesh(tmp_path):
    resolved = resolve_asset(
        activity_sound_brief(DOG, "death"), None, backend=MockAudioBackend(),
        work_dir=tmp_path / "w", ledger_path=LEDGER,
    )
    assert resolved.tier == "generated"
    assert resolved.qa is not None and resolved.qa.passed  # judged by qa_audio
    assert resolved.component == "stable-audio-open"


def test_a_clip_that_flunks_qa_falls_back_to_the_curated_one(tmp_path):
    curated = MockAudioBackend(seconds=0.3).generate(
        activity_sound_brief(DOG, "attack"), tmp_path / "curated"
    ).path

    class TooLong:  # 30s is fine for a loop, far too long for a one-shot
        component = "stable-audio-open"

        def generate(self, brief, out_dir):
            return MockAudioBackend(seconds=30.0).generate(brief, out_dir)

    resolved = resolve_asset(
        activity_sound_brief(DOG, "attack"), curated, backend=TooLong(),
        work_dir=tmp_path / "w", ledger_path=LEDGER,
    )
    assert resolved.tier == "curated"
    assert resolved.path == curated
    assert any("failed QA" in n for n in resolved.notes)


def test_a_crashing_sound_generator_never_costs_the_build(tmp_path):
    curated = MockAudioBackend(seconds=0.3).generate(
        activity_sound_brief(DOG, "attack"), tmp_path / "curated"
    ).path

    class Boom:
        component = "stable-audio-open"

        def generate(self, brief, out_dir):
            raise RuntimeError("gpu on fire")

    resolved = resolve_asset(
        activity_sound_brief(DOG, "attack"), curated, backend=Boom(),
        work_dir=tmp_path / "w", ledger_path=LEDGER,
    )
    assert resolved.tier == "curated"


# --- the pipeline ----------------------------------------------------------


@pytest.mark.skipif(not (KIT.is_dir() and SFX.is_dir()), reason="kits not present")
def test_no_audio_backend_means_no_sound_resolution_at_all(spec, tmp_path):
    manifest = resolve_spec_assets(
        spec, kit_dir=KIT, sfx_dir=SFX, cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=None, audio_backend=None, ledger_path=LEDGER,
    )
    assert not [k for k in manifest if k.startswith("sound:")]
    assert shippable_sounds(manifest) == {}


@pytest.mark.skipif(not (KIT.is_dir() and SFX.is_dir()), reason="kits not present")
def test_each_character_gets_a_clip_for_each_activity(spec, tmp_path):
    manifest = resolve_spec_assets(
        spec, kit_dir=KIT, sfx_dir=SFX, cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=None, audio_backend=MockAudioBackend(), ledger_path=LEDGER,
    )
    sounds = shippable_sounds(manifest)
    assert sounds
    for activities in sounds.values():
        assert set(activities) == set(ACTIVITY_PHRASE)

    # Lineage records the curated clip each generated one displaced (§11).
    entry = next(v for k, v in manifest.items() if k.startswith("sound:"))
    assert entry["fallback"] is not None


# --- the writer ------------------------------------------------------------


@pytest.mark.skipif(not (KIT.is_dir() and SFX.is_dir()), reason="kits not present")
def test_the_characters_own_voice_beats_the_family_set(spec, golden_plan, tmp_path):
    manifest = resolve_spec_assets(
        spec, kit_dir=KIT, sfx_dir=SFX, cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=None, audio_backend=MockAudioBackend(), ledger_path=LEDGER,
    )
    sounds = shippable_sounds(manifest)
    out = tmp_path / "proj"
    write_project(
        golden_plan, "T", out, templates_dir=REPO / "engine" / "templates",
        kit_dir=KIT, sfx_dir=SFX, asset_sounds=sounds,
        enemy_configs={e["enemy_id"]: e.get("stats", {}) for e in spec["entities"]["enemies"]},
    )
    scene = (out / "main.tscn").read_text(encoding="utf-8")

    # Every generated clip is referenced and shipped...
    generated_names = {p.name for acts in sounds.values() for p in acts.values()}
    for name in generated_names:
        assert f'path="res://sfx/{name}"' in scene
        assert (out / "sfx" / name).is_file()
    # ...and the curated skeleton set it replaced is NOT dragged along.
    assert "swish_1.wav" not in scene


@pytest.mark.skipif(not (KIT.is_dir() and SFX.is_dir()), reason="kits not present")
def test_a_partly_generated_character_still_sounds_complete(spec, golden_plan, tmp_path):
    # Only the death clip was produced; the rest must fall back to curated, or a
    # half-working generator would leave a silent attack.
    manifest = resolve_spec_assets(
        spec, kit_dir=KIT, sfx_dir=SFX, cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=None, audio_backend=MockAudioBackend(), ledger_path=LEDGER,
    )
    sounds = shippable_sounds(manifest)
    label = next(iter(sounds))
    only_death = {label: {"death": sounds[label]["death"]}}

    out = tmp_path / "proj"
    write_project(
        golden_plan, "T", out, templates_dir=REPO / "engine" / "templates",
        kit_dir=KIT, sfx_dir=SFX, asset_sounds=only_death,
        enemy_configs={e["enemy_id"]: e.get("stats", {}) for e in spec["entities"]["enemies"]},
    )
    scene = (out / "main.tscn").read_text(encoding="utf-8")
    assert f'ExtResource("k_{only_death[label]["death"].stem}")' in scene  # generated death
    assert "swish_1.wav" in scene  # curated attack still there
    for activity in ACTIVITY_PHRASE:
        assert f"sfx_{activity} = Array[AudioStream]([" in scene


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_generated_sound_works_even_with_no_curated_kit(spec, golden_plan, tmp_path):
    manifest = resolve_spec_assets(
        spec, kit_dir=KIT, sfx_dir=None, cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=None, audio_backend=MockAudioBackend(), ledger_path=LEDGER,
    )
    out = tmp_path / "proj"
    write_project(
        golden_plan, "T", out, templates_dir=REPO / "engine" / "templates",
        kit_dir=KIT, sfx_dir=None, asset_sounds=shippable_sounds(manifest),
        enemy_configs={e["enemy_id"]: e.get("stats", {}) for e in spec["entities"]["enemies"]},
    )
    scene = (out / "main.tscn").read_text(encoding="utf-8")
    assert "sfx_attack = Array[AudioStream]([" in scene
    # The players must exist for the banks to play through.
    assert '[node name="Sfx" type="AudioStreamPlayer3D"' in scene


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_a_mesh_backend_is_never_asked_for_sound(spec, tmp_path):
    # backend and audio_backend are separate; handing the mesh farm an audio brief
    # would produce a GLB that fails qa_audio and wastes minutes of GPU.
    manifest = resolve_spec_assets(
        spec, kit_dir=KIT, sfx_dir=SFX if SFX.is_dir() else None,
        cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=MockBackend(), audio_backend=None, ledger_path=LEDGER,
    )
    assert not [k for k in manifest if k.startswith("sound:")]
