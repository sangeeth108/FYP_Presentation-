"""The Hunyuan3D-2.1 shape backend and its licence position.

The swap from TripoSR is measured rather than aesthetic: TripoSR shipped grey
blobs (mean saturation 5/255) at ~120k triangles of slivers. These tests pin the
contract the backend must honour and the licence boundary it sits on, neither of
which requires the model to be installed.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from asset_farm.backends_gpu import GenerationBackendError
from asset_farm.backends_hunyuan import PRIMARY_COMPONENT, Hunyuan3DBackend
from asset_farm.brief import AssetBrief
from asset_farm.license_guard import is_product_safe, is_research_safe
from asset_farm.registry import select_backend


class _Cfg:
    asset_gen_enabled = True
    asset_gen_backend = "hunyuan"
    hunyuan3d_checkpoint_dir = ""
    hunyuan3d_package_dir = ""
    comfyui_base_url = ""
    vision_enabled = False
    vision_base_url = ""
    vision_model = ""
    vision_timeout_seconds = 1.0


def test_the_registry_can_select_it():
    backend = select_backend(_Cfg())
    assert isinstance(backend, Hunyuan3DBackend)
    assert backend.component == PRIMARY_COMPONENT


def test_an_unknown_backend_name_still_degrades_to_curated():
    class Bad(_Cfg):
        asset_gen_backend = "nonexistent"

    assert select_backend(Bad()) is None


def test_characters_are_refused_because_generated_meshes_have_no_rig(tmp_path):
    """A rig-less character is a statue; characters must stay curated."""
    backend = Hunyuan3DBackend(checkpoint_dir=str(tmp_path))
    with pytest.raises(GenerationBackendError, match="does not generate"):
        backend.generate(AssetBrief("a village elder", "character"), tmp_path)


def test_a_missing_checkpoint_fails_loudly_rather_than_silently(tmp_path):
    backend = Hunyuan3DBackend(checkpoint_dir=str(tmp_path / "absent"))
    with pytest.raises(GenerationBackendError, match="missing|not configured"):
        backend.generate(AssetBrief("a mossy boulder", "prop"), tmp_path)


def test_an_unconfigured_checkpoint_is_reported_not_guessed(tmp_path):
    backend = Hunyuan3DBackend(checkpoint_dir="")
    with pytest.raises(GenerationBackendError, match="not configured"):
        backend.generate(AssetBrief("a mossy boulder", "prop"), tmp_path)


def test_unloading_without_a_loaded_model_is_harmless():
    from asset_farm.backends_hunyuan import unload_models

    assert unload_models() is False


def test_the_licence_boundary_is_research_not_product():
    """The quarantine that bars it from a product does not bind research.

    Applying the product licence rule to research work is a recorded mistake of
    this project: it excluded the best available geometry model for no reason.
    The boundary is scoped rather than removed, so a future commercial path
    still refuses it.
    """
    assert is_research_safe("hunyuan3d-2.1") is True
    assert is_product_safe("hunyuan3d-2.1") is False


def test_an_unrecorded_component_is_refused_on_both_paths():
    """"We did not check" is not a licence."""
    assert is_research_safe("some-unrecorded-model") is False
    assert is_product_safe("some-unrecorded-model") is False


def test_the_ledger_records_what_was_actually_measured():
    import csv

    root = Path(__file__).resolve().parents[3]
    with (root / "docs" / "licensing_ledger.csv").open(encoding="utf-8", newline="") as f:
        row = next(r for r in csv.DictReader(f) if r["component"] == "hunyuan3d-2.1")
    # The schema allows only "product" or "research_only"; this row said
    # "research", which failed scripts/check_licenses.py. Hunyuan3D-2.1 is
    # research-only (UK/EU/Korea excluded for commercial use), so the value
    # was right in intent and wrong in spelling.
    assert row["product_path"] == "research_only"
    assert row["verified_date"]
    notes = row[list(row)[-1]] or ""
    # The absence of colour is the honest caveat and must stay recorded.
    assert "NO vertex colour" in notes
