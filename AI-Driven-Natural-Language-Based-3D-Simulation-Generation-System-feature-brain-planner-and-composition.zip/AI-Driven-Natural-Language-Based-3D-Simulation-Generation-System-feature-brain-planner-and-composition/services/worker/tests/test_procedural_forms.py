"""Procedural FORMS: the planner names a shape, this module builds it.

Every procedural asset used to be a coloured box, so a rainforest rendered as a
field of rectangles. The fix is deliberately a vocabulary of forms rather than a
lookup from species name to geometry: a list of nouns is a ceiling (see
DEFECTS_AND_DECISIONS #15), and "teak" would work where "dipterocarp" would not.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from asset_farm.procedural import _SUPPORTED, resolve_procedural_asset

FORMS = ("foliage_column", "ground_cover", "irregular_mass", "fallen_column")


def _build(tmp_path, form: str, dimensions: list[float], semantic: str = "thing") -> dict:
    entity = {
        "entity_id": f"ent_{semantic}",
        "semantic_type": semantic,
        "physical": {"bbox_m": dimensions},
        "asset": {"brief": semantic, "procedural_type": form},
    }
    return resolve_procedural_asset(entity, tmp_path)


@pytest.mark.parametrize(
    ("form", "dimensions"),
    [
        ("foliage_column", [3.0, 25.0, 3.0]),
        ("ground_cover", [1.5, 0.8, 1.5]),
        ("irregular_mass", [1.5, 0.9, 1.2]),
        ("fallen_column", [4.0, 0.8, 0.8]),
    ],
)
def test_a_form_measures_exactly_what_was_declared(tmp_path, form, dimensions):
    """The descriptor normalises by declared-over-imported, so proportions matter.

    The first version produced a tree 13.75 m deep for a species declared 3 m
    across and stood a log on its end; both survived because only the assembly's
    overall extent was checked, never each builder's arithmetic.
    """
    entry = _build(tmp_path, form, dimensions)
    assert entry["tier"] == "procedural", entry.get("notes")
    measured = entry["qa"]["bbox_dimensions"]
    for axis in range(3):
        assert measured[axis] == pytest.approx(dimensions[axis], abs=0.02)


def test_a_tree_is_not_a_box(tmp_path):
    """The whole point: form must be distinguishable from the fallback block."""
    tree = _build(tmp_path, "foliage_column", [3.0, 12.0, 3.0])
    box = _build(tmp_path, "semantic_box", [3.0, 12.0, 3.0])
    assert tree["qa"]["tri_count"] > box["qa"]["tri_count"] * 4
    assert tree["brief_hash"] != box["brief_hash"]


@pytest.mark.parametrize("form", FORMS)
def test_forms_stay_inside_the_instancing_budget(tmp_path, form):
    """A field holds thousands of these; a detailed mesh would be unaffordable."""
    entry = _build(tmp_path, form, [2.0, 4.0, 2.0])
    assert entry["qa"]["tri_count"] <= 400


@pytest.mark.parametrize("form", FORMS)
def test_the_same_species_always_yields_the_same_mesh(tmp_path, form):
    """Rule 14: jitter is seeded from the contract, never from wall-clock chance."""
    first = _build(tmp_path / "a", form, [2.0, 3.0, 2.0])
    second = _build(tmp_path / "b", form, [2.0, 3.0, 2.0])
    assert first["brief_hash"] == second["brief_hash"]
    assert (
        first["qa"]["bbox_dimensions"] == second["qa"]["bbox_dimensions"]
    )


def test_forms_carry_no_vocabulary_of_species(tmp_path):
    """An unknown noun must build exactly as well as a familiar one.

    Guards the design decision itself: if someone later adds a name lookup, a
    made-up species will start differing from a real one and this will fail.
    """
    known = _build(tmp_path / "k", "foliage_column", [3.0, 9.0, 3.0], "oak_tree")
    unknown = _build(tmp_path / "u", "foliage_column", [3.0, 9.0, 3.0], "zzyzx_frond")
    assert known["qa"]["bbox_dimensions"] == unknown["qa"]["bbox_dimensions"]
    assert known["qa"]["tri_count"] == unknown["qa"]["tri_count"]


def test_an_unsupported_form_is_reported_not_guessed(tmp_path):
    entry = _build(tmp_path, "spaceship", [1.0, 1.0, 1.0])
    assert entry["tier"] == "unresolved"
    assert "unsupported procedural type" in entry["notes"][0]


def test_the_schema_enum_and_the_builders_agree():
    """A form the contract offers but nobody built would fail at generation time."""
    import json
    from pathlib import Path

    schema = json.loads(
        (Path(__file__).resolve().parents[3] / "contracts" / "simulation_spec.schema.json")
        .read_text(encoding="utf-8")
    )
    declared = set(
        schema["$defs"]["asset_requirement"]["properties"]["procedural_type"]["enum"]
    )
    assert declared == set(_SUPPORTED)


# --- the planner names the colours (ADR-0015) --------------------------------


def _build_with_palette(tmp_path, form, dimensions, palette=None, semantic="thing"):
    entity = {
        "entity_id": f"ent_{semantic}",
        "semantic_type": semantic,
        "physical": {"bbox_m": dimensions},
        "asset": {
            "brief": semantic,
            "procedural_type": form,
            **({"palette_hex": palette} if palette is not None else {}),
        },
    }
    return resolve_procedural_asset(entity, tmp_path)


def test_two_trees_of_different_colours_are_two_different_meshes(tmp_path):
    """The whole point: an oak and a dead birch stop being the same object.

    Forms fixed the SHAPE and left colour a baked-in constant, so every species
    landing on `foliage_column` came out as one brown trunk under one green crown.
    """
    pine = _build_with_palette(
        tmp_path, "foliage_column", [3.0, 7.0, 3.0], ["#3d2f22", "#2f4f34"]
    )
    birch = _build_with_palette(
        tmp_path, "foliage_column", [3.0, 7.0, 3.0], ["#d8d2c4", "#c9b45a"]
    )
    assert pine["tier"] == birch["tier"] == "procedural"
    assert pine["brief_hash"] != birch["brief_hash"]
    assert Path(pine["path"]).read_bytes() != Path(birch["path"]).read_bytes()


def test_the_palette_is_part_of_the_cache_key_not_a_note_beside_it(tmp_path):
    """The procedural cache is content-addressed and shared across games.

    A red postbox and a green one must not collide on one file. This is the same
    reason NOISE_VERSION is inside the contract dict rather than beside it.
    """
    plain = _build_with_palette(tmp_path, "open_container", [0.8, 1.0, 0.8])
    red = _build_with_palette(
        tmp_path, "open_container", [0.8, 1.0, 0.8], ["#8f2320"]
    )
    assert plain["brief_hash"] != red["brief_hash"]
    assert Path(plain["path"]) != Path(red["path"])


def test_an_absent_palette_hashes_exactly_as_it_did_before(tmp_path):
    """Everything already generated must keep resolving.

    The palette only enters the digest when it is present, so the millions of
    already-cached meshes keep their filenames. Two builds of the same formless
    contract must agree, and a malformed colour must degrade to the same file
    rather than to a third one.
    """
    first = _build_with_palette(tmp_path, "irregular_mass", [1.2, 0.9, 1.1])
    again = _build_with_palette(tmp_path, "irregular_mass", [1.2, 0.9, 1.1])
    assert first["brief_hash"] == again["brief_hash"]

    # A spec can reach this module from a preserved artefact or a hand-written
    # fixture, where the contract's pattern was never enforced. Failing a whole
    # world over a colour would be the wrong trade.
    junk = _build_with_palette(
        tmp_path, "irregular_mass", [1.2, 0.9, 1.1], ["not-a-colour"]
    )
    assert junk["tier"] == "procedural"
    assert junk["brief_hash"] == first["brief_hash"]


def test_fewer_colours_than_the_form_uses_is_legal(tmp_path):
    """One colour on a tree repaints the trunk and leaves the crown green.

    Requiring a colour per piece would push the planner into inventing accents it
    has no opinion about, and an invented accent is worse than a default one.
    """
    trunk_only = _build_with_palette(
        tmp_path, "foliage_column", [3.0, 7.0, 3.0], ["#3d2f22"]
    )
    both = _build_with_palette(
        tmp_path, "foliage_column", [3.0, 7.0, 3.0], ["#3d2f22", "#2f4f34"]
    )
    plain = _build_with_palette(tmp_path, "foliage_column", [3.0, 7.0, 3.0])
    assert trunk_only["tier"] == "procedural"
    assert len({trunk_only["brief_hash"], both["brief_hash"], plain["brief_hash"]}) == 3


def test_a_repainted_door_does_not_keep_orange_planks(tmp_path):
    """The plank highlight is derived from the leaf, not chosen separately.

    A door has four colours and only three slots, because the highlight is the
    leaf catching light rather than an independent decision. Left as a constant it
    stayed orange under blue paint, which reads as a rendering fault.
    """
    from asset_farm.procedural import _lighten

    blue = [40, 70, 130, 255]
    highlight = _lighten(blue, 151.0 / 116.0)
    assert highlight[3] == 255
    # Brighter than its base on every channel, and still recognisably the colour.
    assert all(highlight[axis] > blue[axis] for axis in range(3))
    assert highlight[2] > highlight[0]  # still blue, not turned grey

    # And nothing overflows a channel a bright base already fills.
    white = _lighten([250, 250, 250, 255], 151.0 / 116.0)
    assert white[:3] == [255, 255, 255]


def test_every_form_accepts_a_palette(tmp_path):
    """A form the planner can name but not colour would be a silent trap.

    The guidance tells it to give every procedural asset a palette, so any form
    that ignored the argument would produce a spec that validates and a mesh that
    quietly disagrees with it.
    """
    for form in sorted(_SUPPORTED):
        entry = _build_with_palette(
            tmp_path, form, [1.4, 2.1, 1.2], ["#7a3b2e", "#2f4f34", "#c9b45a"]
        )
        assert entry["tier"] == "procedural", (form, entry.get("notes"))
        bare = _build_with_palette(tmp_path, form, [1.4, 2.1, 1.2])
        assert entry["brief_hash"] != bare["brief_hash"], form
        assert Path(entry["path"]).read_bytes() != Path(bare["path"]).read_bytes(), form
