"""No hole in the world: every corridor's floor is continuous, room to room.

The bot found this the expensive way. A ramp can sit in the MIDDLE of a long
corridor leg, and the writer laid only the approach and the ramp — so the floor
STOPPED at the ramp's top, leaving a 4.5-unit gap between the ramp and the room
it climbed to. The key and exit rooms were unreachable; a player walking the
corridor fell out of the world. It builds and it renders and it is broken.

Walking the corridor polyline in Python catches that in milliseconds, without a
bot, an export, or a GPU.
"""

import re

import pytest
from godot_client.project_writer import write_project
from godot_client.walls import ramp_geometry

STEP = 0.25  # sample the polyline this finely — finer than any slab we emit


def _slabs(scene: str) -> list[tuple[float, float, float, float, float]]:
    """(x0, x1, z0, z1, top_y) for every floor slab in the scene, ramps included."""
    sizes = dict(
        re.findall(
            r'\[sub_resource type="BoxMesh" id="Mesh(\w+)"\]\nsize = Vector3\(([^)]*)\)',
            scene,
        )
    )
    out = []
    for name, transform in re.findall(
        r'\[node name="(\w+)" type="StaticBody3D"[^\]]*\]\ntransform = Transform3D\(([^)]*)\)',
        scene,
    ):
        if name not in sizes or name.startswith("Wall") or name == "Walls":
            continue
        w, h, d = (float(v) for v in sizes[name].split(","))
        n = [float(v) for v in transform.split(",")]
        cx, cy, cz = n[9], n[10], n[11]
        if name.endswith("Ramp"):  # a rotated slab: use its axis-aligned footprint
            span = max(w, d)
            if w >= d:
                out.append((cx - span / 2, cx + span / 2, cz - d / 2, cz + d / 2, cy + 1.0))
            else:
                out.append((cx - w / 2, cx + w / 2, cz - span / 2, cz + span / 2, cy + 1.0))
            continue
        out.append((cx - w / 2, cx + w / 2, cz - d / 2, cz + d / 2, cy + h / 2))
    return out


def _covered(x: float, z: float, slabs) -> bool:
    return any(
        x0 - 1e-6 <= x <= x1 + 1e-6 and z0 - 1e-6 <= z <= z1 + 1e-6
        for x0, x1, z0, z1, _y in slabs
    )


def _walk(plan: dict, tmp_path) -> list[tuple[str, float, float]]:
    """Sample every corridor polyline; return the points standing over nothing."""
    write_project(plan, "T", tmp_path)
    slabs = _slabs((tmp_path / "main.tscn").read_text(encoding="utf-8"))
    rooms = {r["zone_id"]: r for r in plan["rooms"]}
    for r in rooms.values():  # rooms are floor too
        slabs.append((r["x"], r["x"] + r["width"], r["z"], r["z"] + r["depth"], r["elevation"]))

    holes = []
    for corridor in plan["corridors"]:
        pts = corridor["points"]
        for k in range(len(pts) - 1):
            (ax, az), (bx, bz) = pts[k], pts[k + 1]
            steps = max(int((abs(bx - ax) + abs(bz - az)) / STEP), 1)
            for s in range(steps + 1):
                t = s / steps
                x, z = ax + (bx - ax) * t, az + (bz - az) * t
                if not _covered(x, z, slabs):
                    holes.append((f"{corridor['a']}->{corridor['b']}", round(x, 2), round(z, 2)))
    return holes


def _plan(rooms, corridors):
    return {
        "level_plan_version": "1.0.0", "seed": 0, "algorithm": "room_corridor",
        "zones": [{"zone_id": r["zone_id"], "kind": k, "tier": 0}
                  for r, k in zip(rooms, ["entry"] + ["exit"] * (len(rooms) - 1), strict=True)],
        "rooms": rooms, "corridors": corridors, "entities": [],
    }


# A ramp stranded in the MIDDLE of a long leg — the exact shape that holed dung_04.
# z01 contains the corridor's end point (14, 4), as the real PCG always guarantees.
MID_LEG_RAMP = _plan(
    [
        {"zone_id": "z00", "x": 0.0, "z": 18.0, "width": 8.0, "depth": 8.0, "elevation": 0.0},
        {"zone_id": "z01", "x": 10.0, "z": 0.0, "width": 8.0, "depth": 8.0, "elevation": 1.5},
    ],
    [{"a": "z00", "b": "z01", "kind": "open", "width": 2.0,
      "points": [[4.0, 22.0], [14.0, 22.0], [14.0, 4.0]]}],
)

L_SHAPED = _plan(
    [
        {"zone_id": "z00", "x": 0.0, "z": 0.0, "width": 8.0, "depth": 8.0, "elevation": 0.0},
        {"zone_id": "z01", "x": 12.0, "z": 12.0, "width": 8.0, "depth": 8.0, "elevation": 1.5},
    ],
    [{"a": "z00", "b": "z01", "kind": "open", "width": 2.0,
      "points": [[4.0, 4.0], [16.0, 4.0], [16.0, 16.0]]}],
)


@pytest.mark.parametrize(("name", "plan"), [("mid-leg ramp", MID_LEG_RAMP), ("L-shaped", L_SHAPED)])
def test_corridor_floor_has_no_holes(name, plan, tmp_path):
    holes = _walk(plan, tmp_path)
    assert not holes, (
        f"{name}: corridor floor is missing under {len(holes)} points, e.g. {holes[:3]}"
    )


def test_the_ramp_actually_reaches_both_ends():
    """A ramp whose foot floats outside the corridor is a ramp to nowhere."""
    for plan in (MID_LEG_RAMP, L_SHAPED):
        for corridor in plan["corridors"]:
            geom = ramp_geometry(plan, corridor)
            assert geom is not None
            axis = 0 if geom["axis"] == "x" else 1
            run = abs(geom["top"][axis] - geom["foot"][axis])
            assert run > 2.0, f"ramp run collapsed to {run}"


@pytest.mark.parametrize(("name", "plan"), [("mid-leg ramp", MID_LEG_RAMP), ("L-shaped", L_SHAPED)])
def test_navmesh_connects_the_tiers(name, plan):
    """Every room lands on ONE navmesh component. This is the check that would
    have caught the tier-islanding without a bot, an export, or a GPU — the
    navmesh and the writer must agree on the floor, or NavigationServer can never
    path across the ramp and the bot strands in a corridor."""
    from godot_client.navmesh import _eroded, _ramp_cells
    from godot_client.walls import CELL, covered_cells, floor_rects

    floor = covered_cells(floor_rects(plan))
    ramps = {c: e for c, e in _ramp_cells(plan).items() if c in floor}
    merged = dict(floor)
    merged.update(ramps)
    kept = _eroded(merged, frozenset(ramps))

    comp: dict[tuple[int, int], int] = {}
    n = 0
    for c in kept:
        if c in comp:
            continue
        n += 1
        stack = [c]
        comp[c] = n
        while stack:
            i, j = stack.pop()
            for q in ((i + 1, j), (i - 1, j), (i, j + 1), (i, j - 1)):
                if q in kept and q not in comp:
                    comp[q] = n
                    stack.append(q)

    def cell(x: float, z: float) -> tuple[int, int]:
        return (int(x // CELL), int(z // CELL))

    rooms = {
        r["zone_id"]: comp.get(cell(r["x"] + r["width"] / 2, r["z"] + r["depth"] / 2), "OFF")
        for r in plan["rooms"]
    }
    assert len(set(rooms.values())) == 1, f"{name}: rooms on separate nav islands: {rooms}"
