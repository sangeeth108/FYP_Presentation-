"""S5 wiring: resolve_spec_assets over a real spec, provenance recorded.

With no backend this is a no-op on shipped output (curated wins) that records
where every asset came from. A real backend replaces curated with generated
assets wherever they pass QA — and the manifest shows which.
"""

import json
from pathlib import Path

from asset_farm.backends import MockBackend
from asset_farm.pipeline import resolution_summary, resolve_spec_assets

REPO = Path(__file__).resolve().parents[3]
KIT = REPO / "content" / "kits"  # curated root (one folder per pack)
GOLDEN = json.loads(
    (REPO / "contracts" / "examples" / "golden_game.spec.json").read_text(encoding="utf-8")
)


def test_curated_only_run_records_every_non_functional_asset(tmp_path):
    manifest = resolve_spec_assets(
        GOLDEN, kit_dir=KIT if KIT.is_dir() else None, cache_dir=tmp_path / "cache"
    )
    # Doors are functional nodes, not models — skipped, never "unresolved".
    assert not any(e["tier"] == "unresolved" for e in manifest.values()), manifest
    door_ids = {"prop:door_main", "prop:door_locked"}
    assert not (door_ids & set(manifest)), "functional doors must not be in the asset manifest"


def test_no_backend_keeps_output_curated(tmp_path):
    manifest = resolve_spec_assets(
        GOLDEN, kit_dir=KIT if KIT.is_dir() else None, cache_dir=tmp_path / "cache"
    )
    summary = resolution_summary(manifest)
    assert summary.get("generated", 0) == 0  # nothing generated without a backend
    assert summary.get("curated", 0) > 0  # the kit still supplies the models


def test_a_licensed_backend_generates_and_the_manifest_shows_it(tmp_path):
    ledger = tmp_path / "ledger.csv"
    ledger.write_text(
        "component,kind,version,license,license_url,territory_restrictions,"
        "commercial_ok,product_path,verified_date,verified_by,notes\n"
        "trellis-2,model,x,MIT,url,none,yes,product,2026-07-14,web,ok\n",
        encoding="utf-8",
    )
    manifest = resolve_spec_assets(
        GOLDEN,
        kit_dir=KIT if KIT.is_dir() else None,
        cache_dir=tmp_path / "cache",
        work_dir=tmp_path / "work",
        backend=MockBackend("trellis-2"),
        ledger_path=str(ledger),
    )
    summary = resolution_summary(manifest)
    assert summary.get("generated", 0) > 0, "a licensed backend should produce assets"
    # Every generated asset carries its QA report and the producing component.
    gen = [e for e in manifest.values() if e["tier"] == "generated"]
    assert all(e["component"] == "trellis-2" and e["qa"]["passed"] for e in gen)


def test_lineage_manifest_is_json_serializable(tmp_path):
    manifest = resolve_spec_assets(
        GOLDEN, kit_dir=KIT if KIT.is_dir() else None, cache_dir=tmp_path / "cache"
    )
    json.dumps(manifest)  # must round-trip into the lineage record
