"""Generated projects and browser shells cannot regress to inherited branding."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from godot_client.project_writer import write_project
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO / "engine" / "serendib"))
from verify_branding import verify_project, verify_web  # noqa: E402


def test_generated_project_has_serendib_icon_splash_and_settings(tmp_path):
    spec = json.loads(
        (REPO / "contracts" / "examples" / "golden_game.spec.json").read_text(
            encoding="utf-8"
        )
    )
    write_project(to_level_plan(run_pcg(spec)), "Village Study", tmp_path)
    assert verify_project(tmp_path) == []


def test_visible_inherited_browser_brand_is_rejected(tmp_path):
    (tmp_path / "index.html").write_text(
        "<html><head><meta data-serendib-brand='1'></head>"
        "<body>Godot Engine loading</body></html>",
        encoding="utf-8",
    )
    assert verify_web(tmp_path) == [
        "browser shell contains visible inherited engine branding"
    ]


def test_engine_api_names_inside_script_are_not_treated_as_visible_brand(tmp_path):
    (tmp_path / "index.html").write_text(
        "<html><head><meta data-serendib-brand='1'></head>"
        "<body>Serendib loading<script>const GodotEngineAPI = {};</script></body></html>",
        encoding="utf-8",
    )
    assert verify_web(tmp_path) == []

