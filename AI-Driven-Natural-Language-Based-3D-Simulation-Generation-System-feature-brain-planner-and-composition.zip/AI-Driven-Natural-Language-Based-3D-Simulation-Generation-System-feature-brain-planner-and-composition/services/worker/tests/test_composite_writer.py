"""Materialising a CompositeObject into scene text (ADR-0008, phase 2).

The point of this layer: a vehicle door (or a house door) becomes a SEPARATE,
script-bound, interactable node at its socket — never baked into the body. These
pin that the emitted scene actually contains those nodes, correctly parented,
bound to the door template, with an InteractZone, and carrying the brief's params
— for a car and a house with the same code.
"""

import json
from pathlib import Path

import pytest
from godot_client.composite_writer import composite_blocks
from godot_client.composition import AffordancePart, CompositeObject, Socket
from godot_client.project_writer import write_project
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan

REPO = Path(__file__).resolve().parents[3]
TEMPLATES = REPO / "engine" / "templates"
GOLDEN = REPO / "contracts" / "examples" / "golden_game.spec.json"


def _car() -> CompositeObject:
    return CompositeObject(
        object_id="car01",
        bbox=(2.0, 1.2, 4.0),
        parts=(
            AffordancePart("door_l", "door_hinged", Socket("sL", (-0.5, 0.0, 0.1), 90.0),
                           params={"open_angle_deg": -70.0}),
            AffordancePart("door_r", "door_hinged", Socket("sR", (0.5, 0.0, 0.1), -90.0),
                           params={"open_angle_deg": -70.0}),
        ),
    )


def test_each_door_is_a_separate_scripted_node_with_an_interact_zone():
    subs, nodes, _ = composite_blocks(_car(), origin=(5.0, 0.0, 5.0), door_ext_id="3_door")
    # two doors, each its OWN StaticBody child of the object holder, bound to the
    # door template, each with its own InteractZone — the whole point.
    assert nodes.count('script = ExtResource("3_door")') == 2
    assert '[node name="ObjectCar01_DoorL" type="StaticBody3D" parent="ObjectCar01"]' in nodes
    assert '[node name="ObjectCar01_DoorR" type="StaticBody3D" parent="ObjectCar01"]' in nodes
    assert nodes.count('[node name="InteractZone" type="Area3D"') == 2
    # a car door opens less than a house door — the brief's param survives
    assert nodes.count("open_angle_deg = -70") == 2


def test_the_holder_carries_the_world_placement_and_parts_are_local():
    # The object holder is placed in the world; parts hang under it (so the object
    # moves/rotates as a unit and each hinge stays exact).
    _, nodes, _ = composite_blocks(_car(), origin=(5.0, 0.0, 5.0))
    assert '[node name="ObjectCar01" type="Node3D" parent="."]' in nodes
    assert "5, 0, 5)" in nodes  # holder origin at (5,0,5)
    # the left door's LOCAL x is -1.0 (half the 2.0 width), not 4.0 (world) — it is
    # positioned relative to the holder.
    assert "-1, 0" in nodes


def test_subresources_are_unique_per_door():
    subs, _, _ = composite_blocks(_car())
    # distinct mesh/shape/zone ids per door, or Godot collapses them
    for suffix in ("DoorL", "DoorR"):
        assert f'id="MeshObjectCar01_{suffix}"' in subs
        assert f'id="ShapeObjectCar01_{suffix}"' in subs
        assert f'id="ZoneObjectCar01_{suffix}"' in subs


def test_a_locked_door_emits_an_unlock_connection():
    house = CompositeObject(
        object_id="cottage",
        bbox=(6.0, 3.0, 6.0),
        parts=(AffordancePart("front", "door_hinged_lockable",
                              Socket("front_door", (0.0, 0.0, 0.5)),
                              params={"locked": True, "unlocked_by_objective": "find_key"}),),
    )
    _, nodes, conns = composite_blocks(house)
    assert "locked = true" in nodes
    assert 'from="find_key"' in conns
    assert 'to="ObjectCottage/ObjectCottage_Front"' in conns


def test_a_point_affordance_is_a_pickup_not_a_door():
    obj = CompositeObject(
        object_id="crate",
        bbox=(1.0, 1.0, 1.0),
        parts=(AffordancePart("loot", "pickup_collectible", Socket("top", (0.0, 1.0, 0.0))),),
    )
    subs, nodes, _ = composite_blocks(obj, pickup_ext_id="9_pickup")
    assert 'script = ExtResource("9_pickup")' in nodes
    assert 'groups=["pickup"]' in nodes
    assert "3_door" not in nodes  # not a door


def test_the_body_mesh_can_be_instanced_under_the_holder():
    _, nodes, _ = composite_blocks(_car(), origin=(0, 0, 0), parent_mesh_ext_id="k_car")
    assert 'instance=ExtResource("k_car")' in nodes
    assert 'parent="ObjectCar01"' in nodes


def test_a_generated_body_is_scaled_up_to_the_object_footprint():
    # A body normalised small must grow to fill the door layout, not sit inside it.
    _, nodes, _ = composite_blocks(_car(), parent_mesh_ext_id="gen_body", body_scale=2.5)
    body_line = next(ln for ln in nodes.splitlines() if "ObjectCar01Body" in ln)
    xform = nodes.split("ObjectCar01Body", 1)[1]
    assert "Transform3D(2.5, 0, 0, 0, 2.5, 0, 0, 0, 2.5" in xform  # uniform scale
    assert "instance=ExtResource" in body_line


def test_a_part_with_its_own_mesh_replaces_the_box_but_keeps_collision():
    # Phase 4c: a door panel mesh is the VISUAL; the box collision + InteractZone
    # stay, because physics/reachability must not depend on a generated hull.
    subs, nodes, _ = composite_blocks(
        _car(), part_mesh_exts={"door_l": ("gen_panel", 1.33)},
    )
    # the left door instances its panel (not the box MeshInstance)...
    assert '[node name="ObjectCar01_DoorLPanel" parent="ObjectCar01/ObjectCar01_DoorL" ' in nodes
    assert 'instance=ExtResource("gen_panel")' in nodes
    assert '[node name="ObjectCar01_DoorLMesh"' not in nodes  # box visual gone for door_l
    # ...but its box collision + interact zone remain (vetted physics)
    assert '[node name="ObjectCar01_DoorLShape" type="CollisionShape3D"' in nodes
    assert 'id="ShapeObjectCar01_DoorL"' in subs
    # the RIGHT door had no panel -> keeps the box visual
    assert '[node name="ObjectCar01_DoorRMesh"' in nodes


# --- integration: composites reach a real written project -----------------


@pytest.mark.skipif(not TEMPLATES.is_dir(), reason="engine/templates not present")
def test_write_project_materialises_a_composite_into_main_tscn(tmp_path):
    # The whole point of phase 2b: a composite in the plan becomes real, separate,
    # script-bound door nodes in the shipped scene (headless-load-clean, verified
    # manually with Godot 4.7 — here we pin the structure).
    plan = to_level_plan(run_pcg(json.loads(GOLDEN.read_text(encoding="utf-8"))))
    entry = plan["rooms"][0]
    car = {
        "object_id": "car01",
        "bbox": [2.0, 1.2, 4.0],
        "origin": [entry["x"] + entry["width"] / 2, entry["elevation"],
                   entry["z"] + entry["depth"] / 2],
        "parts": [
            {"part_id": "door_l", "template_id": "door_hinged",
             "socket": {"offset": [-0.5, 0.0, 0.1], "facing_deg": 90.0},
             "params": {"open_angle_deg": -70.0}},
            {"part_id": "door_r", "template_id": "door_hinged",
             "socket": {"offset": [0.5, 0.0, 0.1], "facing_deg": -90.0},
             "params": {"open_angle_deg": -70.0}},
        ],
    }
    write_project(plan, "CompositeProof", tmp_path, templates_dir=TEMPLATES, composites=[car])
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    assert '[node name="ObjectCar01" type="Node3D"' in scene
    assert '[node name="ObjectCar01_DoorL" type="StaticBody3D" parent="ObjectCar01"]' in scene
    assert scene.count("open_angle_deg = -70") == 2  # both car doors
    assert scene.startswith("[gd_scene load_steps=")  # valid, load_steps recomputed


def test_composites_without_templates_are_rejected(tmp_path):
    # Composites reuse the door/pickup templates; without them the scene would
    # reference undefined ext_resources, so fail loud (rule 13), not ship broken.
    from godot_client.project_writer import ProjectWriterError

    plan = to_level_plan(run_pcg(json.loads(GOLDEN.read_text(encoding="utf-8"))))
    car = {"object_id": "c", "bbox": [1, 1, 1],
           "parts": [{"part_id": "d", "template_id": "door_hinged",
                      "socket": {"offset": [0, 0, 0.5]}}]}
    with pytest.raises(ProjectWriterError):
        write_project(plan, "T", tmp_path, templates_dir=None, composites=[car])


@pytest.mark.skipif(not TEMPLATES.is_dir(), reason="engine/templates not present")
def test_object_body_is_resolved_and_instanced_under_the_doors(tmp_path):
    # Phase 4a: the farm resolves an object's brief to a BODY mesh; tasks threads it
    # as parent_mesh_rel; the writer instances it under the holder, beside the doors.
    from agents.composition_patterns import expand
    from asset_farm.backends import MockBackend
    from asset_farm.pipeline import resolve_spec_assets, shippable_models

    spec = {
        "meta": {"game_id": "car_body_test"},
        "player": {},
        "entities": {"enemies": [], "props": [], "objects": [
            {"object_id": "car01", "archetype": "vehicle", "bbox": [2.0, 1.2, 4.0],
             "brief": "a boxy rusted sedan, low-poly"},
        ]},
    }
    manifest = resolve_spec_assets(
        spec, kit_dir=None, cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=MockBackend(), embed_base_url=None,
    )
    assert manifest["object:car01"]["tier"] == "generated"  # a body was produced
    body_path = shippable_models(manifest)["object:car01"]

    plan = to_level_plan(run_pcg(json.loads(GOLDEN.read_text(encoding="utf-8"))))
    car = expand({"object_id": "car01", "archetype": "vehicle", "bbox": [2.0, 1.2, 4.0],
                  "origin": [plan["rooms"][0]["x"], 0.0, plan["rooms"][0]["z"]]})
    car["parent_mesh_rel"] = str(body_path)  # what tasks.py threads in (absolute)
    # A real kit_dir is present but does NOT contain the generated body — the writer
    # must route it to res://assets and scale it, not steal it into res://kit.
    kit_dir = tmp_path / "kit_dir"
    kit_dir.mkdir()
    write_project(plan, "BodyProof", tmp_path / "proj", templates_dir=TEMPLATES,
                  kit_dir=kit_dir, composites=[car])
    scene = (tmp_path / "proj" / "main.tscn").read_text(encoding="utf-8")
    # the body shell is instanced under the holder, from res://assets (generated),
    # scaled up to the object's 4.0m footprint (4.0/1.5 ~= 2.667), never left at 1.0.
    assert '[node name="ObjectCar01Body" parent="ObjectCar01"' in scene
    assert 'path="res://assets/' in scene  # generated body, not stolen into res://kit
    body_xform = scene.split("ObjectCar01Body", 1)[1].split("transform = ", 1)[1]
    assert body_xform.startswith("Transform3D(2.66")  # scaled to the footprint
    assert (tmp_path / "proj" / "assets").exists()  # the generated GLB was copied in


@pytest.mark.skipif(not TEMPLATES.is_dir(), reason="engine/templates not present")
def test_brain_archetype_expands_and_materialises_end_to_end(tmp_path):
    # The full ADR-0008 brain->spine shape: the planner picks an archetype
    # ("vehicle"), the deterministic pattern library expands it to parts+sockets,
    # and write_project materialises real DoorHinged nodes from that dict — no
    # bespoke geometry authored anywhere between the menu choice and the scene.
    from agents.composition_patterns import expand

    plan = to_level_plan(run_pcg(json.loads(GOLDEN.read_text(encoding="utf-8"))))
    entry = plan["rooms"][0]
    composite = expand({
        "object_id": "car01", "archetype": "vehicle", "bbox": [2.0, 1.2, 4.0],
        "origin": [entry["x"] + entry["width"] / 2, entry["elevation"],
                   entry["z"] + entry["depth"] / 2],
    })
    assert composite is not None  # a vehicle is a known archetype
    write_project(plan, "ArchetypeProof", tmp_path, templates_dir=TEMPLATES,
                  composites=[composite])
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    # the car's two side doors, script-bound, materialised from the expanded
    # pattern (plus the exit LockedDoor already in the golden game -> 3 total).
    assert '[node name="ObjectCar01_DoorL" type="StaticBody3D"' in scene
    assert '[node name="ObjectCar01_DoorR" type="StaticBody3D"' in scene
    assert scene.count('script = ExtResource("3_door")') == 3
