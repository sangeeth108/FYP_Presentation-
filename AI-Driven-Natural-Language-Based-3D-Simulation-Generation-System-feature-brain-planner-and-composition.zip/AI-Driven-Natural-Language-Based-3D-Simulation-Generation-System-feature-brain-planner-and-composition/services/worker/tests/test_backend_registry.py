"""Backend selection: config -> backend, with disabled as the safe default.

The registry is the single switch that decides whether a job generates. These
lock in that OFF means None (curated), and that a bad config name degrades to
None rather than crashing a job.
"""

from asset_farm.backends import MockBackend
from asset_farm.registry import select_backend


class Cfg:
    def __init__(self, enabled=False, backend="mock", url="http://localhost:8188"):
        self.asset_gen_enabled = enabled
        self.asset_gen_backend = backend
        self.comfyui_base_url = url


def test_disabled_selects_no_backend():
    assert select_backend(Cfg(enabled=False)) is None


def test_mock_backend_when_enabled():
    b = select_backend(Cfg(enabled=True, backend="mock"))
    assert isinstance(b, MockBackend)


def test_unknown_backend_name_degrades_to_none_not_a_crash():
    assert select_backend(Cfg(enabled=True, backend="typo-backend")) is None


def test_gpu_backend_is_importable_and_declares_a_licensed_component():
    # Selecting "gpu" must not require the heavy runtime just to construct it —
    # the import is lazy and the object declares its ledger component.
    b = select_backend(Cfg(enabled=True, backend="gpu"))
    assert b is not None
    assert b.component == "trellis-2"  # what the manifest attributes; license-verified


def test_local_backend_requires_the_configured_vision_gate():
    cfg = Cfg(enabled=True, backend="local")
    cfg.vision_enabled = True
    cfg.vision_base_url = "http://vision.internal:11434"
    cfg.vision_model = "qualified-vision:1"
    cfg.vision_timeout_seconds = 45.0
    backend = select_backend(cfg)
    assert backend is not None
    assert backend.require_concept_vision is True
    assert backend.concept_vision_base_url == cfg.vision_base_url
    assert backend.concept_vision_model == cfg.vision_model
    assert backend.concept_vision_timeout_seconds == 45.0


# --- GPU backend command construction (no GPU needed) ---
def test_wsl_path_translation():
    from pathlib import PureWindowsPath

    from asset_farm.backends_gpu import _to_wsl_path

    assert _to_wsl_path(PureWindowsPath(r"D:\asset-farm\x.png")) == "/mnt/d/asset-farm/x.png"
    assert _to_wsl_path(PureWindowsPath(r"C:\a\b.glb")) == "/mnt/c/a/b.glb"


def test_trellis_command_is_a_wsl_invocation():
    from pathlib import PureWindowsPath

    from asset_farm.backends_gpu import GpuAssetBackend

    b = GpuAssetBackend()
    cmd = b._trellis_command(PureWindowsPath(r"D:\img.png"), PureWindowsPath(r"D:\out.glb"))
    assert cmd[:5] == ["wsl", "-d", "Ubuntu-24.04", "-u", "root"]
    assert cmd[5:7] == ["--", "bash"] and cmd[7] == "-c"  # -c, NOT -lc (Windows-PATH trap)
    inner = cmd[-1]
    assert "/root/miniconda3/envs/trellis/bin/python" in inner  # absolute, no conda activate
    assert "/mnt/d/img.png" in inner and "/mnt/d/out.glb" in inner
    assert "trellis_cli.py" in inner


def test_native_linux_skips_wsl():
    from pathlib import PurePosixPath

    from asset_farm.backends_gpu import GpuAssetBackend

    b = GpuAssetBackend(trellis_wsl_distro="")
    cmd = b._trellis_command(PurePosixPath("/tmp/i.png"), PurePosixPath("/tmp/o.glb"))
    assert cmd[0] == "bash"  # no wsl wrapper on a native-Linux box


# --- sound generation is its own switch ------------------------------------
# Stable Audio and TRELLIS cannot be co-resident in 32 GB, so the two are
# enabled, sequenced and failed independently.


class AudioCfg:
    def __init__(self, enabled=False, backend="mock"):
        self.audio_gen_enabled = enabled
        self.audio_gen_backend = backend
        self.comfyui_base_url = "http://localhost:8188"


def test_audio_disabled_selects_no_backend():
    from asset_farm.registry import select_audio_backend

    assert select_audio_backend(AudioCfg(enabled=False)) is None


def test_audio_mock_is_selected_when_enabled():
    from asset_farm.backends import MockAudioBackend
    from asset_farm.registry import select_audio_backend

    assert isinstance(select_audio_backend(AudioCfg(enabled=True)), MockAudioBackend)


def test_an_unknown_audio_backend_degrades_to_curated_not_a_crash():
    from asset_farm.registry import select_audio_backend

    assert select_audio_backend(AudioCfg(enabled=True, backend="typo")) is None


def test_the_two_switches_are_independent():
    from asset_farm.registry import select_audio_backend

    # Mesh generation off, sound generation on: a perfectly valid combination
    # (the curated models are animated; only the voice is unique).
    class Both:
        asset_gen_enabled = False
        asset_gen_backend = "mock"
        audio_gen_enabled = True
        audio_gen_backend = "mock"
        comfyui_base_url = ""

    assert select_backend(Both()) is None
    assert select_audio_backend(Both()) is not None


def test_the_stable_audio_workflow_carries_the_brief_and_a_stable_seed():
    from asset_farm.backends_audio import _seed, _workflow
    from asset_farm.brief import AssetBrief

    brief = AssetBrief("a snarling dog, attacking. one-shot, dry, no music", "audio_sfx")
    wf = _workflow(brief.brief, seed=_seed(brief), seconds=4.0)["prompt"]
    assert wf["6"]["inputs"]["text"] == brief.brief  # the brief IS the prompt
    assert wf["5"]["inputs"]["seconds"] == 4.0
    assert wf["3"]["inputs"]["seed"] == _seed(brief) == _seed(brief)  # reproducible


def test_the_sound_backend_refuses_a_mesh_brief(tmp_path):
    import pytest
    from asset_farm.backends_audio import AudioBackendError, StableAudioBackend
    from asset_farm.brief import AssetBrief

    # It refuses BEFORE any HTTP call, so a mis-wired caller fails loudly and
    # instantly rather than after a 300s timeout against an audio graph.
    with pytest.raises(AudioBackendError, match="makes sound"):
        StableAudioBackend().generate(AssetBrief("a barrel", "prop"), tmp_path)
