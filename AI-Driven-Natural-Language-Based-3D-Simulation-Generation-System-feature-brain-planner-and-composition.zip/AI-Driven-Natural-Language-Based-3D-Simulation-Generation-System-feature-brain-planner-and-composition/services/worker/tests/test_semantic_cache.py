"""Semantic cache tier: reuse a cached asset for a SIMILAR brief, not just an
identical one — TRELLIS generation costs minutes, so this is a real saving.

Tested without Ollama: a fake embedder maps briefs to fixed vectors, so the whole
cosine/threshold/store path is exercised deterministically. The property that
matters: a dead embedder degrades exactly to the exact-match-only behaviour.
"""

import json

import httpx
import pytest
from asset_farm.backends import MockBackend, _minimal_glb
from asset_farm.brief import AssetBrief
from asset_farm.cache import AssetCache
from asset_farm.resolver import resolve_asset

LEDGER = (
    "component,kind,version,license,license_url,territory_restrictions,"
    "commercial_ok,product_path,verified_date,verified_by,notes\n"
    "trellis-2,model,x,MIT,url,none,yes,product,2026-07-14,web,ok\n"
)


@pytest.fixture
def ledger(tmp_path) -> str:
    p = tmp_path / "ledger.csv"
    p.write_text(LEDGER, encoding="utf-8")
    return str(p)


def _curated(tmp_path):
    p = tmp_path / "curated.glb"
    p.write_bytes(_minimal_glb(500))
    return p


# A fake bge-m3: near-duplicate briefs get near-identical vectors, distinct ones
# get orthogonal vectors. Lets us drive the 0.92 threshold deterministically.
def _fake_embedder(vectors: dict[str, list[float]]) -> httpx.MockTransport:
    def handler(request: httpx.Request) -> httpx.Response:
        text = json.loads(request.content)["input"][0]
        return httpx.Response(200, json={"embeddings": [vectors[text]]})

    return httpx.MockTransport(handler)


def test_embed_and_cosine_roundtrip():
    from asset_farm.semantic import cosine, embed

    t = _fake_embedder({"a torch": [1.0, 0.0]})
    v = embed("a torch", "http://mock", transport=t)
    assert v == [1.0, 0.0]
    assert cosine([1.0, 0.0], [1.0, 0.0]) == pytest.approx(1.0)
    assert cosine([1.0, 0.0], [0.0, 1.0]) == pytest.approx(0.0)


def test_nearest_respects_the_floor(tmp_path):
    cache = AssetCache(tmp_path / "c")
    src = tmp_path / "x.glb"
    src.write_bytes(_minimal_glb(400))
    cache.put("h1", src, "trellis-2", 400, embedding=[1.0, 0.0])
    assert cache.nearest([0.99, 0.14], floor=0.92) is not None  # ~0.99 cosine
    assert cache.nearest([0.2, 0.98], floor=0.92) is None  # far -> no reuse


def test_similar_brief_hits_the_semantic_tier_instead_of_regenerating(
    tmp_path, ledger, monkeypatch
):
    # Two briefs the fake embedder deems ~identical.
    a = AssetBrief("a cracked stone sarcophagus", "prop", 2000)
    b = AssetBrief("a cracked stone coffin", "prop", 2000)  # different hash, close meaning
    vecs = {a.brief: [1.0, 0.0], b.brief: [0.999, 0.0447]}  # cosine ~0.999

    import asset_farm.semantic as sem

    monkeypatch.setattr(sem, "embed", lambda text, url, transport=None: vecs[text])

    cache = AssetCache(tmp_path / "c")
    # First brief generates + caches (with its embedding).
    r1 = resolve_asset(a, _curated(tmp_path), backend=MockBackend("trellis-2"), cache=cache,
                       work_dir=tmp_path / "w", ledger_path=ledger, embed_base_url="http://mock")
    assert r1.tier == "generated"

    # Second, similar brief reuses it WITHOUT generating — a backend that would
    # error proves no generation happened.
    class Boom:
        component = "trellis-2"

        def generate(self, *a, **k):
            raise AssertionError("must not regenerate — semantic tier should hit")

    r2 = resolve_asset(b, _curated(tmp_path), backend=Boom(), cache=cache,
                       work_dir=tmp_path / "w", ledger_path=ledger, embed_base_url="http://mock")
    assert r2.tier == "cache"
    assert r2.path == r1.path
    assert any("semantic cache hit" in n for n in r2.notes)


def test_dead_embedder_falls_back_to_generation(tmp_path, ledger, monkeypatch):
    import asset_farm.semantic as sem

    monkeypatch.setattr(sem, "embed", lambda text, url, transport=None: None)  # embedder down
    brief = AssetBrief("a mossy idol", "prop", 2000)
    cache = AssetCache(tmp_path / "c")
    r = resolve_asset(brief, _curated(tmp_path), backend=MockBackend("trellis-2"), cache=cache,
                      work_dir=tmp_path / "w", ledger_path=ledger, embed_base_url="http://mock")
    assert r.tier == "generated"  # no semantic tier, but generation still works
    assert any("embedder unavailable" in n for n in r.notes)


def test_no_embed_url_behaves_exactly_like_exact_match_only(tmp_path, ledger):
    brief = AssetBrief("a plain crate", "prop", 2000)
    cache = AssetCache(tmp_path / "c")
    r = resolve_asset(brief, _curated(tmp_path), backend=MockBackend("trellis-2"), cache=cache,
                      work_dir=tmp_path / "w", ledger_path=ledger)  # no embed_base_url
    assert r.tier == "generated"
    assert not any("semantic" in n for n in r.notes)
