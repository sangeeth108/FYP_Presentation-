"""The settlement forms build, and build the size they were asked for.

Measured on run_5246669909ea46da8687ab8f4fa040e3, which PUBLISHED 17/18 gates and still
looked like grey boxes: tiers were curated 1, cache 7, procedural 12, generated 0. Every
procedural asset that was not a wall segment came out `semantic_box`, so a well, a cart,
a haystack and a fence were the same cube at different sizes.

These are silhouette classes, not object names -- the existing rule in `procedural.py`.
"""

import pytest

from asset_farm.procedural import _SUPPORTED, resolve_procedural_asset

SETTLEMENT_FORMS = {
    "conifer_tree": [2.0, 6.0, 2.0],
    "bush_cluster": [1.2, 0.9, 1.2],
    "fence_section": [2.5, 1.1, 0.2],
    "round_well": [1.6, 1.8, 1.6],
    "wheeled_cart": [2.2, 1.4, 1.2],
    "barrel_round": [0.8, 1.1, 0.8],
    "arch_gateway": [3.0, 3.2, 0.6],
    "round_tower": [3.0, 7.0, 3.0],
    "haystack_cone": [2.4, 2.2, 2.4],
    "market_stall": [2.4, 2.4, 1.6],
}


def _entity(form: str, dimensions: list[float]) -> dict:
    return {
        "entity_id": f"ent_{form}",
        "semantic_type": form,
        "physical": {"bbox_m": dimensions},
        "asset": {
            "brief": form,
            "category": "prop",
            "procedural_type": form,
            "palette_hex": ["#8a6a44", "#4a6b3a"],
        },
    }


@pytest.mark.parametrize("form,dimensions", sorted(SETTLEMENT_FORMS.items()))
def test_the_form_builds_at_its_declared_size(form, dimensions, tmp_path):
    """Bounds must BE the declaration: the descriptor normalises by
    declared-over-imported and the instancer spaces by the result, so a mesh whose real
    proportions differ from its declared ones distorts spacing everywhere downstream."""
    resolved = resolve_procedural_asset(_entity(form, dimensions), tmp_path)
    assert resolved["tier"] == "procedural"
    measured = resolved["qa"]["bbox_dimensions"]
    for axis in range(3):
        assert measured[axis] == pytest.approx(dimensions[axis], rel=0.02)


@pytest.mark.parametrize("form,dimensions", sorted(SETTLEMENT_FORMS.items()))
def test_the_form_is_real_geometry_not_an_empty_hull(form, dimensions, tmp_path):
    resolved = resolve_procedural_asset(_entity(form, dimensions), tmp_path)
    assert resolved["qa"]["tri_count"] > 12, "a bare box would be 12 triangles"


def test_every_settlement_form_is_in_the_supported_vocabulary():
    assert set(SETTLEMENT_FORMS) <= _SUPPORTED


def test_the_contract_offers_every_form_the_builder_supports():
    """A form the builder knows but the schema forbids is unreachable, and a form the
    schema offers but the builder lacks is a KeyError mid-run."""
    import json
    from pathlib import Path

    schema = json.loads(
        (Path(__file__).resolve().parents[3] / "contracts" / "simulation_spec.schema.json")
        .read_text(encoding="utf-8")
    )
    enum = set(
        schema["$defs"]["asset_requirement"]["properties"]["procedural_type"]["enum"]
    )
    assert enum == _SUPPORTED


def test_a_fence_is_seen_through_rather_than_being_a_wall(tmp_path):
    """A fence and a solid box of the same size must not be the same mesh. The gaps are
    the whole point -- forcing a fence to `semantic_box` turned it into a wall."""
    dimensions = SETTLEMENT_FORMS["fence_section"]
    fence = resolve_procedural_asset(_entity("fence_section", dimensions), tmp_path)
    box_entity = _entity("fence_section", dimensions)
    box_entity["asset"]["procedural_type"] = "semantic_box"
    box = resolve_procedural_asset(box_entity, tmp_path)
    assert fence["qa"]["tri_count"] > box["qa"]["tri_count"]
