import pytest
"""Worker test setup: make godot_client and the brain's pcg package importable.

The worker consumes the brain's level-plan JSON; the integration test
regenerates one live from the golden spec, so services/brain joins the
path (source layout — no install required, matches the brain's own flat
package convention).
"""

import sys
from pathlib import Path

_here = Path(__file__).resolve()
sys.path.insert(0, str(_here.parents[1]))  # services/worker  -> godot_client
sys.path.insert(0, str(_here.parents[2] / "brain"))  # services/brain -> pcg

