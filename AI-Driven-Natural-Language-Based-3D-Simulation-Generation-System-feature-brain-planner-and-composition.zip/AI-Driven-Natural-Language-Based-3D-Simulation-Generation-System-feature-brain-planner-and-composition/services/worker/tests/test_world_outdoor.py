"""Outdoor world materialisation (village/field): open ground + a mountain ring.

Outdoor reuses the SAME room/corridor plan + navmesh as indoor — only the look
changes. These pin that outdoor emits a ground plane and a bordering mountain
ring, that room WALLS are gone, and that the floors/navmesh survive (so the bot
still routes). The real-engine load is checked separately; here it's structure.
"""

import json
import os
from pathlib import Path

import pytest
from godot_client.project_writer import write_project
from godot_client.world_outdoor import outdoor_blocks
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan

REPO = Path(__file__).resolve().parents[3]
TEMPLATES = REPO / "engine" / "templates"
KIT = REPO / "content" / "kits"
GOLDEN = REPO / "contracts" / "examples" / "golden_game.spec.json"


@pytest.fixture(scope="module")
def plan():
    return to_level_plan(run_pcg(json.loads(GOLDEN.read_text(encoding="utf-8"))))


def test_outdoor_emits_ground_and_a_mountain_ring(plan):
    subs, nodes = outdoor_blocks(plan)
    assert '[node name="Terrain" type="Node3D"' in nodes
    assert '[node name="Ground" type="StaticBody3D" parent="Terrain"]' in nodes
    # a bordering ring on all four sides
    for side in ("MountainN", "MountainS", "MountainW", "MountainE"):
        assert f'[node name="{side}" type="StaticBody3D" parent="Terrain"]' in nodes
    # ground + mountains carry collision (a bounded, standable playfield)
    assert nodes.count("CollisionShape3D") >= 5


def test_ground_covers_the_whole_footprint_with_margin(plan):
    subs, _ = outdoor_blocks(plan)
    # the ground box is larger than the level bounds (margin on every side)
    rooms = plan["rooms"]
    span_x = max(r["x"] + r["width"] for r in rooms) - min(r["x"] for r in rooms)
    import re

    ground = subs.split("MeshGround", 1)[1]
    gx = float(re.search(r"Vector3\(([\d.-]+),", ground).group(1))
    assert gx > span_x  # ground wider than the rooms it holds


@pytest.mark.skipif(not TEMPLATES.is_dir(), reason="engine/templates not present")
def test_write_project_outdoor_drops_walls_keeps_floors(plan, tmp_path):
    write_project(plan, "OutdoorProof", tmp_path, templates_dir=TEMPLATES, world_kind="outdoor")
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    assert '[node name="Terrain"' in scene  # outdoor terrain present
    assert '[node name="Ground"' in scene
    assert 'name="Walls"' not in scene  # room walls dropped in outdoor mode
    assert '[node name="Player"' in scene  # entities still placed
    assert "NavigationRegion" in scene or "navigation" in scene.lower()  # navmesh kept


@pytest.mark.skipif(not TEMPLATES.is_dir(), reason="engine/templates not present")
def test_indoor_still_has_walls_and_no_terrain(plan, tmp_path):
    write_project(plan, "IndoorProof", tmp_path, templates_dir=TEMPLATES, world_kind="indoor")
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    assert 'name="Walls"' in scene  # indoor keeps its walls
    assert '[node name="Terrain"' not in scene  # no outdoor terrain


def test_surfaces_are_procedurally_textured_not_flat():
    # Texturing (indoor + outdoor): floor/wall materials carry a seamless noise
    # texture + triplanar mapping, so surfaces read as stone/grass, not flat colour.
    # No external files, no GPU — Godot generates the NoiseTexture2D at load.
    from godot_client.lighting import LIGHTING_PRESETS, environment_blocks

    subs, _ = environment_blocks(next(iter(LIGHTING_PRESETS.values())))
    assert '[sub_resource type="FastNoiseLite"' in subs
    assert '[sub_resource type="NoiseTexture2D"' in subs and "seamless = true" in subs
    assert subs.count("uv1_triplanar = true") == 2  # both MatFloor and MatWall
    assert 'albedo_texture = SubResource("SurfaceTex")' in subs


def test_outdoor_navmesh_is_one_region_over_the_ground(plan):
    # The whole point of the fix: one continuous walkable surface, not room islands.
    from godot_client.world_outdoor import outdoor_navmesh_blocks

    sub, node = outdoor_navmesh_blocks(plan)
    assert "NavigationMesh" in sub and "NavigationRegion3D" in node
    assert sub.count("PackedInt32Array") >= 1  # a walkable region exists


@pytest.mark.skipif(
    not os.environ.get("GODOT_BIN"), reason="outdoor playability needs GODOT_BIN (local only)"
)
def test_a_flat_outdoor_world_is_bot_playable(tmp_path):
    # The real proof: with walls dropped + one ground navmesh, a FLAT outdoor world
    # is still winnable end to end (indoor multi-tier -> outdoor must flatten).
    from bots.runner import run_greedy_bot

    spec = json.loads(GOLDEN.read_text(encoding="utf-8"))
    spec["world"]["zone_graph"]["verticality_tiers"] = 1  # outdoor is flat (as tasks.py forces)
    flat = to_level_plan(run_pcg(spec))
    write_project(flat, "OutdoorPlay", tmp_path, templates_dir=TEMPLATES,
                  kit_dir=KIT if KIT.is_dir() else None, world_kind="outdoor")
    verdict = run_greedy_bot(os.environ["GODOT_BIN"], tmp_path)
    assert verdict is not None and verdict.startswith("GREEDYBOT_OK"), verdict
