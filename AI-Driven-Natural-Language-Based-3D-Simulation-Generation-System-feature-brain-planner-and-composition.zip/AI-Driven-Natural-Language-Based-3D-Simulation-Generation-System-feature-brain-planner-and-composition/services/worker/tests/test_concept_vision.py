import json

import pytest
from asset_farm import concept_vision
from asset_farm.backends_gpu import GenerationBackendError


class _Response:
    def __init__(self, verdict):
        self.verdict = verdict

    def raise_for_status(self):
        return None

    def json(self):
        return {"message": {"content": json.dumps(self.verdict)}}


class _Client:
    verdict = {"status": "PASS", "reasons": []}
    posted = None

    def __init__(self, **_kwargs):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return None

    def post(self, path, json):
        type(self).posted = (path, json)
        return _Response(type(self).verdict)


def test_concept_vision_is_schema_bound_and_disables_thinking(tmp_path, monkeypatch):
    image = tmp_path / "concept.png"
    image.write_bytes(b"png bytes")
    _Client.verdict = {"status": "PASS", "reasons": []}
    monkeypatch.setattr(concept_vision.httpx, "Client", _Client)

    verdict = concept_vision.validate_concept_image(
        image_path=image,
        asset_brief="one isolated door leaf, no wall",
        base_url="http://vision",
        model="vision:1",
        timeout_seconds=10,
    )

    assert verdict["status"] == "PASS"
    assert _Client.posted[0] == "/api/chat"
    assert _Client.posted[1]["think"] is False
    assert _Client.posted[1]["format"] == concept_vision._SCHEMA


def test_concept_vision_failure_blocks_generation(tmp_path, monkeypatch):
    image = tmp_path / "concept.png"
    image.write_bytes(b"png bytes")
    _Client.verdict = {"status": "FAIL", "reasons": ["wall is visibly attached"]}
    monkeypatch.setattr(concept_vision.httpx, "Client", _Client)

    with pytest.raises(GenerationBackendError, match="wall is visibly attached"):
        concept_vision.validate_concept_image(
            image_path=image,
            asset_brief="one isolated door leaf, no wall",
            base_url="http://vision",
            model="vision:1",
            timeout_seconds=10,
        )


def test_concept_vision_rejects_contradictory_verdict(tmp_path, monkeypatch):
    image = tmp_path / "concept.png"
    image.write_bytes(b"png bytes")
    _Client.verdict = {"status": "PASS", "reasons": ["not actually a pass"]}
    monkeypatch.setattr(concept_vision.httpx, "Client", _Client)

    with pytest.raises(GenerationBackendError, match="contradictory"):
        concept_vision.validate_concept_image(
            image_path=image,
            asset_brief="door",
            base_url="http://vision",
            model="vision:1",
            timeout_seconds=10,
        )
