"""A scatter species must be able to see the curated model it needs.

Measured on a forest run: 13 of 15 assets went to single-image mesh generation, including
`spc_oak_tree`, `spc_red_fox` and `spc_white_tailed_deer` -- while `tree-large.glb`,
`Fox.glb` and `Deer.glb` sat unused in a 1,201-model library. Two faults combined:

  * `kenney-castle` declared its whole pack `building_module`, so its trees and boulders
    were filed as architecture;
  * `_resolve_scatter_species` discarded the category the species declared and searched
    the library's "prop" shelf for everything.

A forest asking for oaks could reach snow-decorated holiday trees and potted houseplants,
and nothing else. That is where the shattered dark crowns came from, and most of the
build's running time.
"""

from pathlib import Path

import pytest
from asset_farm.pipeline import _names_an_animal, _SCATTER_LIBRARY_CATEGORY
from godot_client.asset_kit import model_category

KITS = Path(__file__).resolve().parents[3] / "content" / "kits"


def _reachable(term: str, category: str) -> list[str]:
    """Models a species searching `category` could actually find."""
    return [
        rel
        for path in KITS.rglob("*.glb")
        for rel in [str(path.relative_to(KITS)).replace("\\", "/")]
        if term in rel.lower() and model_category(rel) == category
    ]


@pytest.mark.parametrize(
    "term", ["tree", "rock", "log"]
)
def test_growing_things_are_scenery_not_architecture(term: str) -> None:
    """A tree in a castle pack is still a tree."""
    assert _reachable(term, "prop"), f"no {term} reachable by a foliage species"


def test_a_stone_wall_is_still_a_wall() -> None:
    """"stone" and "rock" name a MATERIAL as often as a thing.

    Checking nature before architecture filed `wall-window-stone` and `stairs-stone` as
    scenery, which would let a scatter species carpet a field with staircases.
    """
    assert model_category("kenney-castle/models/wall-corner.glb") == "building_module"
    for rel in ("kenney-town/models/wall-window-stone.glb",
                "kenney-town/models/stairs-stone.glb"):
        if (KITS / rel).exists():
            assert model_category(rel) == "building_module", rel


def test_ordinary_props_did_not_move() -> None:
    """The first attempt swept 42 carts, lanterns and market stalls into architecture."""
    for rel in ("kenney-town/models/cart.glb", "kenney-town/models/lantern.glb"):
        if (KITS / rel).exists():
            assert model_category(rel) == "prop", rel


def test_the_declared_category_chooses_the_shelf() -> None:
    assert _SCATTER_LIBRARY_CATEGORY["foliage"] == "prop"
    assert _SCATTER_LIBRARY_CATEGORY["structure"] == "building_module"
    assert _SCATTER_LIBRARY_CATEGORY["prop"] == "prop"


def test_animals_are_looked_for_where_the_library_keeps_them() -> None:
    """Rigged animals live under `character`; the scatter enum has no word for them."""
    for name in ("red fox", "white-tailed deer", "blue jay", "field mouse"):
        assert _names_an_animal(name), name
    for name in ("oak tree", "fern", "leaf litter", "catwalk grating"):
        assert not _names_an_animal(name), name

    assert _reachable("fox", "character"), "Fox.glb unreachable by an animal species"
    assert _reachable("deer", "character"), "Deer.glb unreachable by an animal species"
