"""Deterministic surface synthesis: what a named family renders as, and what an
unnamed one honestly degrades to.

The property under test is not "it looks nice" -- it is that the ground stops
being untextured default white, that the same spec always produces the same
grain, and that a surface nobody chose is reported rather than guessed.
"""

from __future__ import annotations

from godot_client.surfaces import (
    DEFAULT_FAMILY,
    GROUND_MATERIAL_ID,
    PATH_MATERIAL_ID,
    SURFACE_FAMILIES,
    noise_seed,
    resolve_ground_family,
    surface_sub_resources,
)


def test_a_named_family_is_used_without_an_approximation():
    family, reason = resolve_ground_family({"terrain_surface": "grass"})
    assert family == "grass"
    assert reason is None


def test_declaring_unspecified_is_a_decision_but_still_an_approximation():
    """The field is required now, with `unspecified` as the honest way out.

    Choosing it is a decision the planner made, unlike skipping the field --
    but the ground still renders neutral grey, which the player sees, so it is
    still recorded rather than passed off as the requested surface.
    """
    family, reason = resolve_ground_family(
        {"terrain": "a misty hillside", "terrain_surface": "unspecified"}
    )
    assert family == DEFAULT_FAMILY
    assert reason is not None
    assert "declared" in reason and "misty hillside" in reason


def test_an_unnamed_surface_degrades_neutrally_and_says_so():
    """Honest degradation: neutral pixels plus a reason, never a guess."""
    family, reason = resolve_ground_family({"terrain": "windswept machair"})
    assert family == DEFAULT_FAMILY
    assert reason is not None
    # The reason has to name the terrain, or nobody can act on it.
    assert "machair" in reason


def test_free_text_terrain_never_selects_a_family():
    """The whole point of the closed enum: `terrain` must not drive rendering.

    A word-matching implementation would pass this prompt ("grassy") and fail on
    a synonym it had not been taught. Reading only the enum is what makes the
    fallback rate measurable instead of invisible.
    """
    family, reason = resolve_ground_family({"terrain": "grassy meadow"})
    assert family == DEFAULT_FAMILY
    assert reason is not None


def test_an_unknown_family_name_falls_back_and_names_itself():
    family, reason = resolve_ground_family({"terrain_surface": "lava"})
    assert family == DEFAULT_FAMILY
    assert "lava" in reason


def test_noise_seed_is_stable_for_a_spec_and_differs_between_specs():
    a = {"meta": {"seed": 7, "simulation_id": "sim_alpha"}}
    b = {"meta": {"seed": 7, "simulation_id": "sim_beta"}}
    c = {"meta": {"seed": 8, "simulation_id": "sim_alpha"}}
    assert noise_seed(a) == noise_seed(dict(a))  # reproducible (rule 14)
    assert noise_seed(a) != noise_seed(b)  # two worlds do not share one grain
    assert noise_seed(a) != noise_seed(c)
    assert 0 <= noise_seed(a) <= 0x7FFFFFFF  # a seed Godot will accept


def test_the_ground_material_carries_a_triplanar_noise_texture():
    """Triplanar is load-bearing: a BoxMesh ground has no UVs to sample."""
    block = surface_sub_resources(1234, "sand")

    assert f'[sub_resource type="StandardMaterial3D" id="{GROUND_MATERIAL_ID}"]' in block
    assert "uv1_triplanar = true" in block
    assert 'albedo_texture = SubResource("SurfaceNoiseTex")' in block
    assert "seamless = true" in block
    assert "seed = 1234" in block
    # The ramp keeps the noise a modulation. Without it the raw black-to-white
    # range multiplied the tint and the ground read as camouflage.
    assert 'color_ramp = SubResource("SurfaceRamp")' in block
    assert '[sub_resource type="Gradient" id="SurfaceRamp"]' in block
    # Tinted by the family, not left grey.
    sand = SURFACE_FAMILIES["sand"]
    assert f"albedo_color = Color({sand.albedo[0]:g}, " in block


def test_paths_get_their_own_family_so_they_stay_legible():
    block = surface_sub_resources(1, "grass")
    assert f'[sub_resource type="StandardMaterial3D" id="{PATH_MATERIAL_ID}"]' in block
    # A path over grass must not be the same colour as the grass.
    assert SURFACE_FAMILIES["path"].albedo != SURFACE_FAMILIES["grass"].albedo


def test_synthesis_is_deterministic_for_one_seed_and_family():
    assert surface_sub_resources(99, "stone") == surface_sub_resources(99, "stone")
    assert surface_sub_resources(99, "stone") != surface_sub_resources(100, "stone")


def test_every_family_declares_a_usable_material():
    """A family that cannot be rendered is worse than one that does not exist."""
    for name, family in SURFACE_FAMILIES.items():
        assert family.name == name
        assert len(family.albedo) == 3
        assert all(0.0 <= channel <= 1.0 for channel in family.albedo), name
        assert 0.0 <= family.roughness <= 1.0, name
        assert family.uv_scale > 0.0, name
        assert family.noise_frequency > 0.0, name
