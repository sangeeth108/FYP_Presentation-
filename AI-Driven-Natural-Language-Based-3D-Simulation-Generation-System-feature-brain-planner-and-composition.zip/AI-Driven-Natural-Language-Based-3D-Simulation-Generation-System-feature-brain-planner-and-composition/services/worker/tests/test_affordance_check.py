"""The affordance correctness oracle (ADR-0008 phase 2c).

Proves a composed affordance OPENS, not just that it exists. Needs a real Godot
(GODOT_BIN), so it is skipped in CI and runs on the box that has the engine. A
positive run (a composite car's doors open) AND a negative run (a deliberately
broken door template makes the oracle FAIL) — because an oracle that only ever
says OK is theatre.
"""

import json
import os
from pathlib import Path

import pytest
from bots.runner import run_affordance_check
from godot_client.project_writer import write_project
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan

REPO = Path(__file__).resolve().parents[3]
TEMPLATES = REPO / "engine" / "templates"
GOLDEN = REPO / "contracts" / "examples" / "golden_game.spec.json"

pytestmark = pytest.mark.skipif(
    not os.environ.get("GODOT_BIN"), reason="affordance oracle needs GODOT_BIN (local only)"
)


def _project_with_car(tmp_path: Path) -> Path:
    plan = to_level_plan(run_pcg(json.loads(GOLDEN.read_text(encoding="utf-8"))))
    entry = plan["rooms"][0]
    car = {
        "object_id": "car01",
        "bbox": [2.0, 1.2, 4.0],
        "origin": [entry["x"] + entry["width"] / 2, entry["elevation"],
                   entry["z"] + entry["depth"] / 2],
        "parts": [
            {"part_id": "door_l", "template_id": "door_hinged",
             "socket": {"offset": [-0.5, 0.0, 0.1], "facing_deg": 90.0},
             "params": {"open_angle_deg": -70.0}},
            {"part_id": "door_r", "template_id": "door_hinged",
             "socket": {"offset": [0.5, 0.0, 0.1], "facing_deg": -90.0},
             "params": {"open_angle_deg": -70.0}},
        ],
    }
    write_project(plan, "AffordanceProof", tmp_path, templates_dir=TEMPLATES, composites=[car])
    return tmp_path


def test_composite_doors_actually_open(tmp_path):
    project = _project_with_car(tmp_path)
    verdict = run_affordance_check(os.environ["GODOT_BIN"], project)
    assert verdict is not None, "the oracle could not run"
    assert verdict.startswith("AFFORDANCE_OK"), verdict


def test_a_broken_door_makes_the_oracle_fail(tmp_path):
    # Not theatre: replace the vetted door template with a stub whose _try_open is
    # a no-op. The doors are still FOUND (they keep the signal + method) but never
    # swing, so the oracle must report AFFORDANCE_FAIL.
    project = _project_with_car(tmp_path)
    stub = (
        "extends StaticBody3D\n"
        "class_name DoorHinged\n"
        "signal door_opened\n"
        "signal door_unlocked\n"
        "signal locked_interaction\n"
        "@export var locked: bool = false\n"
        "@export var unlocked_by_objective: String = ''\n"
        "@export var open_angle_deg: float = -90.0\n"
        "func _try_open() -> void:\n\tpass\n"  # broken: never opens
        "func unlock() -> void:\n\tlocked = false\n"
    )
    (project / "templates" / "interactables" / "door_hinged.gd").write_text(stub, encoding="utf-8")
    verdict = run_affordance_check(os.environ["GODOT_BIN"], project)
    assert verdict is not None
    assert verdict.startswith("AFFORDANCE_FAIL"), verdict
