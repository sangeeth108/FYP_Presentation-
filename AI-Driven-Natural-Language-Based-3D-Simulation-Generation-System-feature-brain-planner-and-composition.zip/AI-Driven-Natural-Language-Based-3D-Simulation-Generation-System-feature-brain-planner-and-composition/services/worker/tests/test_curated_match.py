"""The curated tier (S5: cache >= 0.92 -> **curated >= 0.85** -> generate).

The middle tier of the resolution tree, and the one that was missing: enemy
models were handed out by placement index, so "a hulking armoured brute" and "a
nimble hooded scout" got whichever skeleton the rotation reached. The brief was
ignored for the one decision the player actually sees.

Matching before generating is the cheap RIGHT answer, not a fallback: a curated
model is instant, licence-clear, rigged and animated, where a generated one costs
GPU minutes and arrives as a statue.

No GPU and no Ollama here — `embed` is faked, so these pin the decision logic
(floor, tie-break, category scoping, degradation), not bge-m3's opinions.
"""

import json
from pathlib import Path

import pytest
from asset_farm import curated_match
from asset_farm.curated_match import (
    CURATED_FLOORS,
    DEFAULT_CURATED_FLOOR,
    best_curated,
    curated_floor,
    keyword_best,
)
from asset_farm.pipeline import resolve_spec_assets, shippable_models
from godot_client.asset_kit import (
    ENEMY_MODELS,
    MODEL_DESCRIPTIONS,
    model_category,
    prop_model,
)

REPO = Path(__file__).resolve().parents[3]
KIT = REPO / "content" / "kits"  # curated root (one folder per pack)
GOLDEN_SPEC = REPO / "contracts" / "examples" / "golden_game.spec.json"

LIB = {"characters/A.glb": "an armoured warrior", "characters/B.glb": "a robed mage"}


@pytest.fixture(autouse=True)
def _clear_cache():
    curated_match._library_vectors.cache_clear()
    yield
    curated_match._library_vectors.cache_clear()


def _fake_embed(scores: dict[str, list[float]]):
    """Map exact text -> vector, so cosine is fully under the test's control."""

    def embed(text, base_url, transport=None):
        return scores.get(text)

    return embed


# --- the library itself ----------------------------------------------------


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_every_described_model_exists_and_every_used_model_is_described():
    # A description pointing at a missing file matches a brief and then ships
    # nothing; an undescribed model is unreachable by any brief.
    for rel in MODEL_DESCRIPTIONS:
        assert (KIT / rel).is_file(), rel
    for rel in ENEMY_MODELS:
        assert rel in MODEL_DESCRIPTIONS, rel
    assert prop_model(None) in MODEL_DESCRIPTIONS  # the generic prop


# --- the decision ----------------------------------------------------------


def test_the_brief_picks_the_model_it_describes(monkeypatch):
    monkeypatch.setattr(
        curated_match,
        "embed",
        _fake_embed({
            "a hulking armoured brute": [1.0, 0.0],
            "an armoured warrior": [1.0, 0.0],  # cosine 1.0
            "a robed mage": [0.0, 1.0],  # cosine 0.0
        }),
    )
    assert best_curated("a hulking armoured brute", LIB, "http://mock") == ("characters/A.glb", 1.0)


def test_below_the_floor_the_library_does_not_contain_it(monkeypatch):
    # Inventing a match is how a wizard ships as a barrel. Better to say no and
    # let the generate tier (or the default) answer.
    monkeypatch.setattr(
        curated_match,
        "embed",
        _fake_embed({
            "a crystalline golem": [1.0, 0.0],
            # 0.8 cleared the old 0.85 floor by failing it; against the measured
            # character floor of 0.64 it would pass, so the fixture is retuned to
            # keep testing "nothing is close enough" rather than "0.85 exactly".
            "an armoured warrior": [0.55, 0.84],  # cosine ~0.55 < 0.64
            "a robed mage": [0.0, 1.0],
        }),
    )
    assert best_curated("a crystalline golem", LIB, "http://mock") is None


def test_the_floors_are_the_measured_values_not_the_spec_document_value():
    """0.85 came from the pipeline spec and was never measured against bge-m3.

    Across the planner's own briefs, the highest score ANY real brief achieved was
    0.775 and the median was 0.59, so the tier could not fire and the report was
    describing a tier that cannot fire.

    Calibrated per category, because a rejection costs different things. A character
    that does not match falls back to a blue capsule, so a plausible body beats no
    body; a prop falls back to a procedural form with a planned palette, which
    already looks right, so only a confident match should override it.
    """
    assert CURATED_FLOORS == {"character": 0.64, "prop": 0.70}
    assert curated_floor("character") == 0.64
    assert curated_floor("prop") == 0.70
    # An uncalibrated category has no evidence behind it, so it needs more
    # convincing rather than less.
    assert curated_floor("vehicle") == DEFAULT_CURATED_FLOOR == 0.70
    assert curated_floor(None) == 0.70


def test_the_subject_is_embedded_rather_than_the_boilerplate():
    """A brief is mostly plumbing, and the plumbing dominates the vector.

    Measured on real specs: "an animated, rigged dog suitable as the controlled
    simulation agent" matched **Alpaca** at 0.566, while the bare subject "dog"
    matched Husky at 0.651. Two more cases went the same way, a museum visitor
    matching Skeleton_Rogue on the brief and Man on the subject.

    Also pins the phrasing, which is not decoration: a bare noun scores lower than
    the same noun in a phrase ("dog" 0.623, "a dog" 0.651) because the library's
    descriptions are phrases, and `museum_visitor` is not a word bge-m3 has seen.
    """
    from asset_farm.curated_match import _query_text

    boilerplate = "an animated, rigged dog suitable as the controlled simulation agent"
    assert _query_text(boilerplate, "dog") == "a dog"
    assert _query_text(boilerplate, "museum_visitor") == "a museum visitor"
    # No subject: the brief is still better than nothing, so every existing caller
    # keeps working.
    assert _query_text(boilerplate, None) == boilerplate
    assert _query_text(boilerplate, "   ") == boilerplate


def test_the_best_match_wins_not_the_first(monkeypatch):
    monkeypatch.setattr(
        curated_match,
        "embed",
        _fake_embed({
            "a spellcaster": [0.0, 1.0],
            "an armoured warrior": [0.52, 0.85],  # ~0.85, just over
            "a robed mage": [0.0, 1.0],  # 1.0
        }),
    )
    rel, score = best_curated("a spellcaster", LIB, "http://mock")
    assert rel == "characters/B.glb" and score == pytest.approx(1.0)


def test_no_embedder_means_no_opinion_not_a_crash():
    # The house rule: a missing embedder costs variety, never a build.
    assert best_curated("a brute", LIB, None) is None
    assert best_curated("a brute", LIB, "") is None


def test_an_unreachable_embedder_degrades(monkeypatch):
    monkeypatch.setattr(curated_match, "embed", lambda *a, **k: None)
    assert best_curated("a brute", LIB, "http://down") is None


def test_an_empty_library_or_brief_matches_nothing(monkeypatch):
    monkeypatch.setattr(curated_match, "embed", _fake_embed({"x": [1.0]}))
    assert best_curated("x", {}, "http://mock") is None
    assert best_curated("", LIB, "http://mock") is None


# --- the embedder-free keyword tier ---------------------------------------
# The tier that makes "as a dog" a dog when bge-m3 is offline. No monkeypatch:
# these run the real lexical logic against the real curated library, because a
# capsule-instead-of-dog was a SILENT failure and the point is that it can never
# happen again just because an embedder is down.

CHAR_LIB_KEY = "character"


def _char_library() -> dict[str, str]:
    return {
        rel: text
        for rel, text in MODEL_DESCRIPTIONS.items()
        if model_category(rel) == CHAR_LIB_KEY and (KIT / rel).is_file()
    }


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
@pytest.mark.parametrize(
    "brief, expected",
    [
        ("a dog", "Husky.glb"),  # both dogs tie -> deterministic lexicographic pick
        ("a small brown dog exploring a village", "Husky.glb"),  # kind beats colour
        ("a grey wolf", "Wolf.glb"),
        ("a red fox", "Fox.glb"),
        ("a fluffy alpaca", "Alpaca.glb"),
        ("a playful shiba inu puppy", "ShibaInu.glb"),
        ("a white horse", "WhiteHorse.glb"),  # colour refines WITHIN the kind
        ("a brown horse", "Horse.glb"),
        ("a robed wizard", "Skeleton_Mage.glb"),
        ("a skeletal warrior", "Skeleton_Warrior.glb"),
    ],
)
def test_keyword_tier_resolves_a_stated_identity_without_an_embedder(brief, expected):
    hit = keyword_best(brief, _char_library())
    assert hit is not None, f"{brief!r} should resolve to a model we own"
    assert Path(hit[0]).name == expected


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_the_kind_noun_beats_a_rarer_colour():
    # THE regression: "brown" is rarer than "dog" in this small library, so plain
    # IDF picks a brown HORSE for a brown DOG. Appearance down-weighting fixes it.
    lib = _char_library()
    assert Path(keyword_best("a brown dog", lib)[0]).name in {"Husky.glb", "ShibaInu.glb"}


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_keyword_tier_invents_nothing_for_an_unowned_kind():
    # We do not own a golem; the keyword tier must decline so generate/default
    # answers instead of shipping the nearest animal as a golem.
    assert keyword_best("a crystalline golem robot", _char_library()) is None
    assert keyword_best("a mannequin knight guard, scalemail accents", _char_library()) is None


def test_keyword_tier_is_deterministic_and_degrades_cleanly():
    assert keyword_best("", LIB) is None
    assert keyword_best("a mage", {}) is None
    assert keyword_best("a robed mage", LIB) == keyword_best("a robed mage", LIB)


def test_a_shared_appearance_word_alone_is_not_an_identity():
    # "gold" is the only overlap, and it describes look not kind: no match. This is
    # what stops a marrow bone becoming a gold chest, or a golden apple a knight.
    lib = {"characters/A.glb": "a golden armoured knight", "characters/B.glb": "a robed mage"}
    assert keyword_best("a golden apple", lib) is None
    # but a real kind word still lands, colour and all
    assert keyword_best("a golden knight", lib) == ("characters/A.glb", pytest.approx(1.0))


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_an_unmatched_character_never_becomes_a_capsule(tmp_path):
    # "a goat" — we own no goat, and generation can't rig a character. The player
    # must still be a REAL farm body (a neutral animal here), never a capsule.
    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    spec["player"]["asset_brief"] = {
        "brief": "a fluffy white mountain goat with curved amber horns", "category": "character",
    }
    manifest = resolve_spec_assets(
        spec, kit_dir=KIT, cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=None, embed_base_url=None,
    )
    worn = shippable_models(manifest)
    assert "player:main" in worn  # a body was resolved, not None -> not a capsule
    assert worn["player:main"].name == "Deer.glb"  # nearest KIND: an animal, not a skeleton


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_a_matched_character_still_wins_over_the_default(tmp_path):
    # The default only fills a gap: "a dog" must still resolve to a real dog.
    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    spec["player"]["asset_brief"] = {"brief": "a scruffy brown dog", "category": "character"}
    manifest = resolve_spec_assets(
        spec, kit_dir=KIT, cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=None, embed_base_url=None,
    )
    assert shippable_models(manifest)["player:main"].name in {"Husky.glb", "ShibaInu.glb"}


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_the_player_gets_a_real_body_with_no_embedder(tmp_path):
    # End to end, the thing the user saw fail: "as a dog" with generation OFF and
    # no embedder must still put a dog GLB on the Player, not a capsule.
    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    spec["player"]["asset_brief"] = {"brief": "a small brown dog", "category": "character"}
    manifest = resolve_spec_assets(
        spec, kit_dir=KIT, cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=None, embed_base_url=None,  # no generator, no embedder
    )
    assert "player:main" in manifest
    assert manifest["player:main"]["curated_rel"] is not None
    worn = shippable_models(manifest)
    assert worn["player:main"].name in {"Husky.glb", "ShibaInu.glb"}


# --- the pipeline ----------------------------------------------------------


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_without_an_embedder_the_index_cycle_still_decides(tmp_path):
    # Byte-for-byte today's behaviour: the semantic tier is additive.
    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    manifest = resolve_spec_assets(
        spec, kit_dir=KIT, cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=None, embed_base_url=None,
    )
    enemies = [v for k, v in manifest.items() if k.startswith("enemy:")]
    assert enemies
    for idx, entry in enumerate(enemies):
        assert entry["curated_rel"] == ENEMY_MODELS[idx % len(ENEMY_MODELS)]


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_the_brief_overrides_the_index_cycle_and_reaches_the_writer(tmp_path, monkeypatch):
    # The whole point: the planner said "brute", so the game must show the
    # Warrior — not whatever the rotation landed on — and that pick has to
    # survive all the way to what the writer instances.
    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    for enemy in spec["entities"]["enemies"]:
        enemy["asset_brief"] = {"brief": "a hulking armoured brute", "category": "character"}

    warrior_desc = MODEL_DESCRIPTIONS["kaykit/characters/Skeleton_Warrior.glb"]

    def embed(text, base_url, transport=None):
        if text == "a hulking armoured brute" or text == warrior_desc:
            return [1.0, 0.0]
        return [0.0, 1.0]  # every other description is orthogonal

    monkeypatch.setattr(curated_match, "embed", embed)
    manifest = resolve_spec_assets(
        spec, kit_dir=KIT, cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=None, embed_base_url="http://mock",
    )
    enemy = next(v for k, v in manifest.items() if k.startswith("enemy:"))
    assert enemy["curated_rel"] == "kaykit/characters/Skeleton_Warrior.glb"
    assert enemy["tier"] == "curated"

    worn = shippable_models(manifest)
    assert worn[next(k for k in manifest if k.startswith("enemy:"))].name == "Skeleton_Warrior.glb"


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_a_character_can_never_match_a_prop(tmp_path, monkeypatch):
    # The floor guards quality; scoping guards category. Without it a "chest"
    # brief could dress an enemy as a barrel, which no score should permit.
    monkeypatch.setattr(curated_match, "embed", lambda *a, **k: [1.0, 0.0])  # everything matches
    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    manifest = resolve_spec_assets(
        spec, kit_dir=KIT, cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=None, embed_base_url="http://mock",
    )
    for label, entry in manifest.items():
        if label.startswith("enemy:"):
            assert model_category(entry["curated_rel"]) == "character"
        elif label.startswith("prop:"):
            assert model_category(entry["curated_rel"]) == "prop"


# --- the calibration itself, checkable against the real model ---------------


def _embedder_available() -> bool:
    """Can the embedder actually ANSWER, not merely is the model listed.

    The first version asked `/api/tags` whether bge-m3 existed. It does exist while
    the same Ollama is busy serving a 27B planner through a corpus run -- and then
    `embed()` times out, returns None, and `best_curated` correctly returns None
    because a missing embedder must cost variety and never a build. The test read
    that as a calibration failure.

    So the guard does what the test does: one real embed. A flaky test in the suite
    is worse than no test, and the flakiness here was mine, not the model's.
    """
    from asset_farm.semantic import embed

    try:
        return embed("a dog", "http://localhost:11434") is not None
    except Exception:
        return False


@pytest.mark.skipif(
    not _embedder_available(),
    reason="needs bge-m3 on a local Ollama; the calibration is recorded in ADR-0019",
)
def test_the_measured_floors_still_separate_what_we_own_from_what_we_do_not():
    """The numbers in `CURATED_FLOORS` are measurements, so they can go stale.

    A model update, or a change to the library's descriptions, moves them. Skipped
    when no embedder is present rather than deleted, because a calibration nothing
    can re-check is a number nobody can trust -- and this is the only test in the
    file that talks to the real model.

    The separations this pins are the ones the floors were chosen from:
      prop       positives 0.758-0.914   negatives 0.539-0.646
      character  positives 0.651-0.806   negatives 0.516-0.657
    """
    from godot_client.asset_kit import MODEL_DESCRIPTIONS, model_category

    library = dict(MODEL_DESCRIPTIONS)

    def pick(subject: str, category: str):
        scoped = {
            rel: text
            for rel, text in library.items()
            if model_category(rel) == category
        }
        return best_curated(
            "unused brief",
            scoped,
            "http://localhost:11434",
            subject=subject,
            category=category,
        )

    def owned(subject: str, category: str):
        """A pick that must resolve, skipping if the embedder stopped answering.

        None is ambiguous here: it means either "the library does not contain this"
        -- the thing under test -- or "the embedder did not reply", which is the
        documented degradation and says nothing about calibration. The two are
        distinguished by asking the embedder directly rather than by inferring.
        """
        result = pick(subject, category)
        if result is None and not _embedder_available():
            pytest.skip("embedder stopped answering mid-test; calibration not exercised")
        return result

    # Things we own must resolve, and to the right body -- the failure that started
    # this was a dog resolving to an alpaca.
    dog = owned("dog", "character")
    assert dog is not None, "a dog is in the library and must resolve"
    assert "ShibaInu" in dog[0] or "Husky" in dog[0], dog
    visitor = owned("museum_visitor", "character")
    assert visitor is not None, visitor
    assert "Man" in visitor[0] or "Woman" in visitor[0], visitor
    barrel = owned("wooden_barrel", "prop")
    assert barrel is not None, barrel
    assert "barrel" in barrel[0], barrel
    # `polished_concrete_floor` was briefly a positive here and is NOT one now, which is
    # the library becoming more honest rather than worse. Pack descriptions gained a
    # style qualifier -- the survival kit's floor reads "a rustic camp floor" -- and a
    # rustic camp floor genuinely is not polished concrete, so it is refused and the
    # brief reaches the procedural surface instead. Recorded rather than deleted because
    # the swing shows what the style qualifiers actually did.

    # A KNOWN false positive, recorded rather than asserted away: `framed_artwork`
    # matches `kenney-survival/structure-canvas.glb` at 0.753, a canvas SHELTER, on the
    # word "canvas". It clears the 0.70 prop floor, and raising that floor is not the
    # fix -- a detached house matches its building at 0.744 and would be lost. The real
    # remedy is a better description for that model, which is a curation task.

    # Things we do not own must be refused, so the procedural form with its planned
    # palette is used instead of a banner standing in for a painting.
    #
    # These have the opposite hazard to the positives: an embedder that stopped
    # answering returns None for everything, and every one of them would pass
    # VACUOUSLY. So the embedder is re-checked afterwards, and a run where it died
    # is skipped rather than recorded as a pass -- a green test that proved nothing
    # is the failure mode this file has already been bitten by once.
    # RETUNED when the library went from 29 models to 1,034 (eight vendored CC0 packs).
    # The old negatives were "things we do not own", and two of them we now do:
    #
    #     polished_concrete_floor -> kenney-survival/floor.glb        0.821  correct
    #     track_lighting          -> kenney-holiday/lights-colored    0.811  defensible
    #
    # so they stopped being negatives by being bought, not by the floors slipping. These
    # three are genuinely absent from every vendored pack, and all three are still
    # refused -- which is what shows the measured floors still separate owned from
    # unowned at this library size.
    refused = [
        pick("magnetic_resonance_scanner", "prop"),
        pick("hydroelectric_turbine", "prop"),
        pick("pipe_organ", "prop"),
    ]
    if not _embedder_available():
        pytest.skip("embedder stopped answering mid-test; rejections prove nothing")
    assert refused == [None, None, None], refused
