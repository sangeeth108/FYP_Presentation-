"""A cached mesh must still be an answer to the brief that fetched it.

The asset cache is keyed on a brief HASH, and a hash says nothing about rigging. When
Phase A's mesh generator produced an unrigged dog, it was written to the cache under
`f33cb98b1217b2a3` -- and from then on every run resolved the controlled actor from cache
as a statue, silently beating the curated Husky and its 24 clips that sat right there as
the fallback. The unit tests started failing on
`ANIMATED_ENTITY_ASSET_INCOMPATIBLE`, which is the gate noticing a dog that cannot walk.

QA asks "is this a usable mesh". It does not ask "is this the KIND of thing requested",
and a rig cannot be added afterwards, so the check belongs at the cache boundary.
"""

import pytest

from asset_farm.brief import AssetBrief
from asset_farm.resolver import _cache_entry_satisfies


class _Report:
    def __init__(self, capabilities):
        self.capabilities = capabilities
        self.passed = True


def test_an_unrigged_mesh_cannot_answer_a_character_brief():
    brief = AssetBrief(brief="a dog", category="character", tri_budget=8000)
    report = _Report({"rigged": False, "animations": 0})
    assert not _cache_entry_satisfies(brief, report)


def test_a_rigged_mesh_answers_a_character_brief():
    brief = AssetBrief(brief="a dog", category="character", tri_budget=8000)
    report = _Report({"rigged": True, "animations": 24})
    assert _cache_entry_satisfies(brief, report)


@pytest.mark.parametrize("category", ["prop", "building_module", "foliage"])
def test_scenery_is_not_asked_for_a_skeleton(category):
    """Only characters need one -- demanding it everywhere would reject every cached
    barrel and make the cache useless."""
    brief = AssetBrief(brief="a wooden barrel", category=category, tri_budget=2000)
    assert _cache_entry_satisfies(brief, _Report({"rigged": False}))


def test_a_report_without_capabilities_is_refused_for_a_character():
    """Absent evidence is not evidence of a rig. An older cache entry predating
    capability measurement must be re-resolved rather than assumed animated."""
    brief = AssetBrief(brief="a dog", category="character", tri_budget=8000)
    assert not _cache_entry_satisfies(brief, _Report({}))


# --- superseded generators -------------------------------------------------


class _Entry:
    def __init__(self, component):
        self.component = component
        self.path = "irrelevant.glb"


def test_an_asset_from_a_replaced_generator_is_not_served():
    """The highest-impact defect of the day, and the quietest.

    The cache is consulted BEFORE the curated library and before generation, so a blob
    from a generator the project has replaced outranks every better answer that has since
    become available -- permanently, and while reporting `tier: cache`, which reads as
    success.

    Measured on run_43472534e4a94d049e2d9ae768f277f6, which published 17/18 and looked
    exactly like the runs before it: 424 of 428 cached assets came from `triposr`, and of
    eighteen resolved assets ZERO used the 1,034-model library vendored the same day.
    Re-resolving the identical spec with this rule in place took that from 0 to 10 real
    models -- houses, a gate, doorways.
    """
    from asset_farm.resolver import _cache_entry_is_current

    assert not _cache_entry_is_current(_Entry("triposr"))


def test_assets_from_current_generators_are_still_served():
    """The cache must keep doing its job -- this is a precedence rule, not a purge."""
    from asset_farm.resolver import _cache_entry_is_current

    for component in ("trellis-2", "serendib-procedural-geometry", "kaykit"):
        assert _cache_entry_is_current(_Entry(component)), component


def test_an_entry_with_no_component_recorded_is_still_served():
    """Absence is not evidence of a superseded generator; only a NAMED one is refused,
    so an old entry without provenance is not thrown away on suspicion."""
    from asset_farm.resolver import _cache_entry_is_current

    assert _cache_entry_is_current(_Entry(None))
