"""Surface grain on procedural meshes.

The property that matters most is the first one: texturing must MODULATE the
palette colour, not replace it. A tree whose trunk and crown collapse to one
colour is a worse asset than the flat one it replaced.
"""

from __future__ import annotations

import json
import struct
from pathlib import Path

import pytest
from asset_farm.procedural import resolve_procedural_asset
from asset_farm.surface_texture import (
    TILES_PER_METRE,
    box_projection_uv,
    noise_texture,
)


def _gltf(path: Path) -> dict:
    raw = path.read_bytes()
    json_length = struct.unpack("<I", raw[12:16])[0]
    return json.loads(raw[20 : 20 + json_length])


def _entity(procedural_type: str, bbox, semantic="thing") -> dict:
    return {
        "semantic_type": semantic,
        "physical": {"bbox_m": list(bbox)},
        "asset": {"procedural_type": procedural_type, "brief": f"a {semantic}"},
    }


# --- the noise tile itself ---
def test_noise_is_deterministic_for_a_seed():
    assert noise_texture(11).tobytes() == noise_texture(11).tobytes()
    assert noise_texture(11).tobytes() != noise_texture(12).tobytes()


def test_noise_tile_wraps_without_a_seam():
    """A tile that does not wrap draws a grid over every surface that repeats it."""
    import numpy as np

    pixels = np.asarray(noise_texture(5).convert("L"), dtype=float)
    # The step from the last column back to the first must be no worse than a
    # typical step inside the tile, which is what "seamless" means in practice.
    interior = np.abs(np.diff(pixels, axis=1)).mean()
    wrap = np.abs(pixels[:, -1] - pixels[:, 0]).mean()
    assert wrap <= interior * 2.5, f"seam: wrap {wrap:.2f} vs interior {interior:.2f}"


def test_noise_only_modulates_and_never_blacks_out_a_colour():
    """It multiplies the palette tint, so it must stay in the upper range."""
    import numpy as np

    pixels = np.asarray(noise_texture(3).convert("L"), dtype=float) / 255.0
    assert pixels.min() >= 0.70, "too dark: the palette colour would be lost"
    assert pixels.max() <= 1.0
    assert pixels.std() > 0.01, "no variation at all is just flat colour again"


# --- UV derivation ---
def test_box_projection_gives_every_vertex_a_uv():
    import numpy as np
    import trimesh

    mesh = trimesh.creation.box(extents=[2.0, 1.0, 3.0])
    uv = box_projection_uv(mesh)
    assert uv.shape == (len(mesh.vertices), 2)
    # A 3 m box at 1.5 tiles/m must span multiple tiles, or there is no grain.
    assert np.ptp(uv[:, 0]) >= 1.0 or np.ptp(uv[:, 1]) >= 1.0


def test_every_face_projects_from_one_axis(tmp_path):
    """The chevron bug, pinned.

    Deriving the projection per vertex on a shared-vertex mesh let the three
    corners of a triangle pick three different axes, so the texture swept across
    the face. On an icosphere boulder 44 of 80 faces disagreed and every rock
    rendered with a chevron pattern radiating from its centre. Nothing but a
    picture showed it, so this test stands in for the picture.
    """
    import numpy as np
    import trimesh
    from asset_farm.surface_texture import apply_surface_texture

    mesh = trimesh.creation.icosphere(subdivisions=1, radius=0.5)
    mesh.visual = trimesh.visual.TextureVisuals(
        material=trimesh.visual.material.PBRMaterial(baseColorFactor=[120, 120, 110, 255])
    )
    (textured,) = apply_surface_texture(trimesh, [mesh], seed=1)

    axes = np.argmax(np.abs(np.asarray(textured.vertex_normals)), axis=1)
    disagreeing = sum(1 for face in textured.faces if len({*axes[face]}) > 1)
    assert disagreeing == 0, f"{disagreeing} faces span two projection axes"


def test_uv_scale_is_physical_so_a_big_object_gets_more_tiles():
    import numpy as np
    import trimesh

    small = box_projection_uv(trimesh.creation.box(extents=[1.0, 1.0, 1.0]))
    large = box_projection_uv(trimesh.creation.box(extents=[8.0, 8.0, 8.0]))
    assert np.ptp(large[:, 0]) > np.ptp(small[:, 0]) * 4
    assert TILES_PER_METRE > 0


# --- what actually reaches the GLB ---
def test_a_textured_piece_keeps_the_palette_colour_it_was_assigned(tmp_path):
    """The load-bearing property: glTF multiplies factor by texture.

    A building shell assigns two colours -- walls and a roof. Both must survive
    as distinct baseColorFactors with the grain applied on top.
    """
    result = resolve_procedural_asset(
        _entity("building_shell", [8.0, 6.0, 12.0], "drying_shed"), tmp_path
    )
    assert result["tier"] == "procedural"
    gltf = _gltf(Path(result["path"]))

    materials = gltf["materials"]
    assert len(materials) >= 2, "the wall/roof distinction was flattened"
    factors = set()
    for material in materials:
        pbr = material["pbrMetallicRoughness"]
        assert "baseColorTexture" in pbr, "a piece shipped without grain"
        factors.add(tuple(round(value, 3) for value in pbr["baseColorFactor"]))
    assert len(factors) >= 2, "every piece ended up the same colour"


def test_textured_meshes_carry_uvs(tmp_path):
    result = resolve_procedural_asset(_entity("irregular_mass", [1.0, 1.0, 1.0]), tmp_path)
    gltf = _gltf(Path(result["path"]))
    for mesh in gltf["meshes"]:
        for primitive in mesh["primitives"]:
            assert "TEXCOORD_0" in primitive["attributes"]


def test_the_image_is_embedded_once_however_many_pieces_use_it(tmp_path):
    """Nine wall pieces must not mean nine copies of the pixels (90 MB budget)."""
    result = resolve_procedural_asset(
        _entity("building_shell", [6.0, 4.0, 6.0], "house"), tmp_path
    )
    gltf = _gltf(Path(result["path"]))
    buffer_views = {image.get("bufferView") for image in gltf.get("images", [])}
    assert len(buffer_views) == 1


def test_texturing_does_not_disturb_the_measured_bounds(tmp_path):
    """The descriptor normalises by declared-over-imported, so a shifted bound
    would move every instance of this asset in the world."""
    result = resolve_procedural_asset(
        _entity("foliage_column", [4.0, 9.0, 4.0], "albizia"), tmp_path
    )
    measured = result["qa"]["bbox_dimensions"]
    assert measured == pytest.approx([4.0, 9.0, 4.0], abs=1e-3)


def test_generation_stays_deterministic(tmp_path):
    first = resolve_procedural_asset(_entity("ground_cover", [0.4, 0.2, 0.4]), tmp_path / "a")
    second = resolve_procedural_asset(_entity("ground_cover", [0.4, 0.2, 0.4]), tmp_path / "b")
    assert Path(first["path"]).read_bytes() == Path(second["path"]).read_bytes()
    assert first["brief_hash"] == second["brief_hash"]


def test_the_surface_rule_is_part_of_the_cache_key(tmp_path):
    """A rule change has to move the filename, or flat meshes are reused forever.

    This is the failure the descriptor-cache investigation was mistaken about but
    which is real here: procedural GLBs ARE content-addressed and reused by path.
    """
    from asset_farm import procedural

    entity = _entity("semantic_box", [1.0, 1.0, 1.0])
    before = resolve_procedural_asset(entity, tmp_path)["brief_hash"]
    original = procedural.NOISE_VERSION
    try:
        procedural.NOISE_VERSION = "value_noise_box_uv_v2"
        after = resolve_procedural_asset(entity, tmp_path)["brief_hash"]
    finally:
        procedural.NOISE_VERSION = original
    assert before != after
