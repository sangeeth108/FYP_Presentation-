"""A house must not be able to match a banner.

Regression for run_fc7e6f68fcd9448287dcb5bd94f7b057, where both dwellings resolved to
`kaykit/props/banner_red.gltf.glb` and shipped as flat red cloth panels normalised to
1.88 x 4.0 x 0.39 m -- the giant pale sheets in the render.

The chain: the planner declares a house as `structure`; `_SIMULATION_CATEGORY` maps that
to `building_module`; `semantic_pick` then collapsed everything non-character to "prop"
and searched the ten-object prop library, in which nothing is a building. A wrong answer
was guaranteed -- the floor only decides HOW wrong.
"""

from godot_client.asset_kit import (
    MANIFEST_CATEGORIES,
    MODEL_DESCRIPTIONS,
    model_category,
)


def test_a_banner_is_not_architecture():
    assert model_category("kaykit/props/banner_red.gltf.glb") == "prop"


def test_a_vendored_building_pack_is_architecture():
    # Superseded the three-prop `STRUCTURE_MODELS` hack: the castle and city packs
    # declare `building_module` in their own kit.json, so a house has 120 real buildings
    # to match instead of three props reclassified by hand.
    architecture = [r for r in MODEL_DESCRIPTIONS if model_category(r) == "building_module"]
    assert len(architecture) > 50
    assert any("castle" in r or "city" in r for r in architecture)


def test_characters_are_unaffected():
    assert model_category("quaternius/animals/Husky.glb") == "character"
    assert model_category("kaykit/characters/Skeleton_Warrior.glb") == "character"


def test_the_three_categories_partition_the_library():
    # Every model lands in exactly one bucket, and each bucket is non-empty -- so no
    # category can silently become an empty search that falls through to a default.
    seen = {model_category(rel) for rel in MODEL_DESCRIPTIONS}
    assert seen == {"character", "prop", "building_module"}


def test_every_declared_category_is_one_the_pipeline_understands():
    # A pack inventing a category would make its models unreachable: the candidate
    # filter compares equality, so "buildings" would match nothing and fail silently.
    assert set(MANIFEST_CATEGORIES.values()) <= {"character", "prop", "building_module"}


def test_a_house_brief_cannot_reach_the_prop_library():
    """The library a `building_module` searches contains no banner, barrel or chest.

    This is the actual guarantee: not that the house matches something good -- the kit
    owns no house, so it should match nothing and fall to a procedural building shell --
    but that it cannot match something absurd.
    """
    architecture = {
        rel: text
        for rel, text in MODEL_DESCRIPTIONS.items()
        if model_category(rel) == "building_module"
    }
    assert architecture, "the architecture category must not be empty"
    # Not "contains no banner" -- the castle pack legitimately has banners on its
    # walls. The guarantee is behavioural: the architecture a house searches is
    # dominated by buildings, so the nearest match cannot be a decoration.
    assert not any("barrel" in text.lower() for text in architecture.values())
    buildings = [
        text for text in architecture.values()
        if any(word in text for word in ("wall", "building", "tower", "roof", "house", "gate"))
    ]
    assert len(buildings) > 20, "architecture must actually be architecture"
