"""Atmospheric dressing: corner torches that furnish a room without breaking it.

Dressing exists to make a level READ as a real space, not grey boxes. The hard
rule: it must never change whether a game is playable — no collision, no navmesh
effect, no gate impact. These pin that it appears, that it is deduped (no size
blowup), and above all that it adds NO collision (the bot-wins proof is in the
build; here we assert the structural guarantee).
"""

import json
from pathlib import Path

import pytest
from godot_client.project_writer import TORCH_MIN_ROOM_SIDE, write_project
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan

REPO = Path(__file__).resolve().parents[3]
KIT = REPO / "content" / "kits"
GOLDEN = REPO / "contracts" / "examples" / "golden_game.spec.json"


@pytest.fixture(scope="module")
def plan():
    return to_level_plan(run_pcg(json.loads(GOLDEN.read_text(encoding="utf-8"))))


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_rooms_get_corner_torches(plan, tmp_path):
    write_project(plan, "T", tmp_path, templates_dir=REPO / "engine" / "templates", kit_dir=KIT)
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    assert '[node name="Dressing" type="Node3D"' in scene
    n = scene.count('parent="Dressing"')
    assert n > 0 and n % 4 == 0  # four corners per dressed room


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_torches_never_add_collision(plan, tmp_path):
    # THE safety rule: dressing must not block the player/bot or alter navmesh.
    # Torch instances hang under Dressing; none may carry a collision shape.
    write_project(plan, "T", tmp_path, templates_dir=REPO / "engine" / "templates", kit_dir=KIT)
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    assert 'parent="Dressing"' in scene
    # no CollisionShape is ever parented under Dressing or a torch — that is what
    # guarantees a torch can never block the player or alter the navmesh.
    for line in scene.splitlines():
        if "CollisionShape3D" in line:
            assert "Dressing" not in line and "Torch_" not in line


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_the_torch_model_is_shipped_once_not_per_torch(plan, tmp_path):
    # 20 torches must share ONE ext_resource + ONE copied GLB, or the 90MB
    # budget dies by a thousand torches.
    write_project(plan, "T", tmp_path, templates_dir=REPO / "engine" / "templates", kit_dir=KIT)
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    torch_ext = scene.count('path="res://kit/torch_lit.gltf.glb"')
    assert torch_ext == 1  # one ext_resource, instanced N times
    assert (tmp_path / "kit" / "torch_lit.gltf.glb").is_file()


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_torch_positions_are_inset_inside_their_room(plan, tmp_path):
    # A torch sitting ON a wall would clip; it must be inset into the floor.
    import re

    write_project(plan, "T", tmp_path, templates_dir=REPO / "engine" / "templates", kit_dir=KIT)
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    rooms = {r["zone_id"]: r for r in plan["rooms"]}
    xs = [r["x"] for r in rooms.values()]
    # every torch x lies within some room's [x, x+width] (not outside the map)
    block = scene.split('[node name="Dressing"', 1)[1]
    pat = r"Transform3D\([^)]*?,\s*([\d.-]+),\s*[\d.-]+,\s*[\d.-]+\)"
    torch_x = [float(m) for m in re.findall(pat, block)]
    assert torch_x  # found some
    assert min(torch_x) >= min(xs) - 1  # none stranded outside the world


def test_no_kit_means_no_dressing(plan, tmp_path):
    # Dressing is a kit feature; the box-only build must be unchanged.
    write_project(plan, "T", tmp_path, templates_dir=REPO / "engine" / "templates")
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    assert "Dressing" not in scene
    assert "torch_lit" not in scene


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_tiny_rooms_are_skipped(tmp_path):
    # A room smaller than the threshold gets no corner torches (would crowd it).
    plan = {
        "level_plan_version": "1.0.0", "seed": 0, "algorithm": "room_corridor",
        "zones": [{"zone_id": "z00", "kind": "entry", "tier": 0},
                  {"zone_id": "z01", "kind": "exit", "tier": 0}],
        "rooms": [
            {"zone_id": "z00", "x": 0.0, "z": 0.0, "width": 2.0, "depth": 2.0, "elevation": 0.0},
            {"zone_id": "z01", "x": 10.0, "z": 0.0, "width": 8.0, "depth": 8.0, "elevation": 0.0},
        ],
        "corridors": [{"a": "z00", "b": "z01", "kind": "open", "width": 2.0,
                       "points": [[1.0, 1.0], [14.0, 1.0]]}],
        "entities": [],
    }
    assert min(2.0, 2.0) < TORCH_MIN_ROOM_SIDE  # the tiny room is below threshold
    write_project(plan, "T", tmp_path, templates_dir=REPO / "engine" / "templates", kit_dir=KIT)
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    # only the 8x8 room is dressed -> exactly 4 torches, not 8
    assert scene.count('parent="Dressing"') == 4
