extends SceneTree

## Headless animation+audio probe (test asset, not shipped): loads main.tscn and
## checks that enemies really bind their model's AnimationPlayer and drive BOTH
## animation and sound from the activity they perform (patrol / hit / death).
## Prints ANIMPROBE_OK or ANIMPROBE_FAIL and exits accordingly. Run:
##   godot --headless --path <project> --import
##   godot --headless --path <project> --script res://anim_probe.gd
##
## Why this exists: the unit suite cannot see time-based visual behaviour. This
## probe caught two bugs a green suite missed — the attack clip force-replayed
## every physics frame (frozen on frame 0), and the hit flinch overwritten by
## locomotion on the next tick (visible for under one frame). See ADR-0004.
## Expects a project built with BOTH the model kit and the sfx kit.

var _failures: Array[String] = []


func _check(ok: bool, label: String, detail: String = "") -> void:
	print(("  ok   " if ok else "  FAIL ") + label + ("" if detail == "" else "  -> " + detail))
	if not ok:
		_failures.append(label)


func _init() -> void:
	var scene := (load("res://main.tscn") as PackedScene).instantiate()
	root.add_child(scene)
	await process_frame
	await create_timer(1.0).timeout

	var enemies := root.get_tree().get_nodes_in_group("enemies")
	print("ANIMPROBE enemies=", enemies.size())
	if enemies.is_empty():
		print("ANIMPROBE_FAIL no enemies in the scene")
		quit(1)
		return

	# Every enemy wearing a kit model must have found its clips.
	var bound := 0
	for e in enemies:
		if e.get("_anim") != null:
			bound += 1
	_check(bound == enemies.size(), "every enemy bound an AnimationPlayer",
		"%d/%d" % [bound, enemies.size()])

	var e = enemies[0]
	var anim: AnimationPlayer = e.get("_anim")
	var sfx: AudioStreamPlayer3D = e.get("_sfx")
	var steps: AudioStreamPlayer3D = e.get("_sfx_steps")
	_check(sfx != null and steps != null, "audio players present")
	_check(not e.get("_anim_for").is_empty(), "activities resolved to real clips",
		str(e.get("_anim_for")))
	_check(not e.sfx_attack.is_empty() and not e.sfx_hit.is_empty()
		and not e.sfx_death.is_empty() and not e.sfx_step.is_empty(),
		"sound banks wired from the model's set",
		"attack=%d hit=%d death=%d step=%d" % [e.sfx_attack.size(), e.sfx_hit.size(),
			e.sfx_death.size(), e.sfx_step.size()])

	# Patrolling: the walk clip plays, and the walking itself makes footsteps.
	_check(anim.is_playing() and anim.current_animation == e.get("_anim_for")["patrol"],
		"patrol plays the walk clip", anim.current_animation)
	var heard_step := false
	for i in 90:
		await physics_frame
		if steps.playing:
			heard_step = true
			break
	_check(heard_step, "walking produces footsteps")

	# A flinch must SURVIVE the physics ticks that follow, not last one frame.
	e.take_damage(1)
	await physics_frame
	var hit_clip: String = e.get("_anim_for")["hit"]
	_check(anim.current_animation == hit_clip, "damage plays the hit clip", anim.current_animation)
	_check(sfx.playing, "damage plays an impact sound",
		sfx.stream.resource_path.get_file() if sfx.stream else "none")
	for i in 4:
		await physics_frame
	_check(anim.current_animation == hit_clip, "the flinch is not stomped by locomotion",
		anim.current_animation)

	# ...then locomotion takes the model back.
	await create_timer(1.5).timeout
	_check(anim.current_animation != hit_clip, "locomotion resumes after the flinch",
		anim.current_animation)

	# Death: the model's death clip + the sound its FAMILY implies (bones, here).
	var died := [false]
	e.died.connect(func(): died[0] = true)
	e.take_damage(999)
	await physics_frame
	_check(died[0], "death emits immediately, without waiting on animation")
	_check(anim.current_animation == e.get("_anim_for")["death"], "death plays the death clip",
		anim.current_animation)
	_check(sfx.playing, "death plays a sound",
		sfx.stream.resource_path.get_file() if sfx.stream else "none")

	if _failures.is_empty():
		print("ANIMPROBE_OK enemies=", enemies.size())
		quit(0)
	else:
		print("ANIMPROBE_FAIL ", _failures)
		quit(1)
