import math
import re

import pytest
from godot_client.project_writer import write_project
from godot_client.walls import RAMP_RUN, covered_cells, floor_rects, wall_runs


def _plan(rooms, corridors):
    return {
        "level_plan_version": "1.0.0",
        "seed": 0,
        "algorithm": "room_corridor",
        "zones": [
            {"zone_id": r["zone_id"], "kind": kind, "tier": 0}
            for r, kind in zip(rooms, ["entry"] + ["exit"] * (len(rooms) - 1), strict=True)
        ],
        "rooms": rooms,
        "corridors": corridors,
        "entities": [],
    }


SINGLE_ROOM = _plan(
    [{"zone_id": "z00", "x": 0.0, "z": 0.0, "width": 6.0, "depth": 6.0, "elevation": 0.0}], []
)

TWO_ROOMS = _plan(
    [
        {"zone_id": "z00", "x": 0.0, "z": 0.0, "width": 6.0, "depth": 6.0, "elevation": 0.0},
        {"zone_id": "z01", "x": 10.0, "z": 0.0, "width": 6.0, "depth": 6.0, "elevation": 0.0},
    ],
    [{"a": "z00", "b": "z01", "kind": "open", "width": 2.0, "points": [[3.0, 3.0], [13.0, 3.0]]}],
)

TWO_TIERS = _plan(
    [
        {"zone_id": "z00", "x": 0.0, "z": 0.0, "width": 6.0, "depth": 6.0, "elevation": 0.0},
        {"zone_id": "z01", "x": 10.0, "z": 0.0, "width": 6.0, "depth": 6.0, "elevation": 1.5},
    ],
    [{"a": "z00", "b": "z01", "kind": "locked", "width": 2.0, "points": [[3.0, 3.0], [13.0, 3.0]]}],
)


def test_single_room_gets_four_merged_perimeter_walls():
    runs = wall_runs(SINGLE_ROOM)
    assert len(runs) == 4
    assert all(r.length == 6.0 for r in runs)
    assert all(r.elevation == 0.0 for r in runs)


def test_corridor_mouth_stays_open():
    runs = wall_runs(TWO_ROOMS)
    # Room z00's right edge (x=6) must be split by the corridor gap into two 2-unit runs.
    right_edge = sorted(
        (r.z, r.length) for r in runs if r.axis == "z" and r.x == 6.0
    )
    assert right_edge == [(0.0, 2.0), (4.0, 2.0)]


def test_floor_cells_are_one_connected_component():
    cells = covered_cells(floor_rects(TWO_ROOMS))
    start = next(iter(cells))
    seen = {start}
    frontier = [start]
    while frontier:
        i, j = frontier.pop()
        for n in ((i + 1, j), (i - 1, j), (i, j + 1), (i, j - 1)):
            if n in cells and n not in seen:
                seen.add(n)
                frontier.append(n)
    assert seen == set(cells)


def test_walls_are_emitted_into_the_scene(tmp_path):
    write_project(TWO_ROOMS, "T", tmp_path)
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    assert '[node name="Walls" type="StaticBody3D" parent="."]' in scene
    wall_nodes = re.findall(r'\[node name="(Wall_\d+)" type="MeshInstance3D"', scene)
    assert len(wall_nodes) == len(wall_runs(TWO_ROOMS))


def test_tier_crossing_corridor_becomes_a_walkable_ramp(tmp_path):
    """The slope is the thing that matters, so assert the slope.

    A ramp that merely *exists* is not enough: spanning only the room gap put
    the 1.5 rise on a 36.9-degree face, which a walking capsule climbs so
    marginally that the playtest bot spent 142s of its 150s budget on one ramp
    and timed out on the run before. The climb now starts RAMP_EXTRA_RUN back
    inside the lower room, which buys a gentle slope without moving any room.
    """
    write_project(TWO_TIERS, "T", tmp_path)
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    ramp = re.search(r'\[node name="CorridorZ00Z01_Seg1Ramp" type="StaticBody3D"[^\[]+', scene)
    assert ramp is not None
    transform = ramp.group(0)
    assert "Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1" not in transform  # rotated basis

    # basis is written row-major as (c, -s, 0, s, c, 0, 0, 0, 1): recover the pitch.
    nums = [float(n) for n in re.search(r"Transform3D\(([^)]*)\)", transform).group(1).split(",")]
    slope_deg = abs(math.degrees(math.atan2(nums[3], nums[0])))
    assert 0.0 < slope_deg <= 25.0, f"ramp pitched {slope_deg:.1f}deg — too steep to walk"

    # The run is FIXED (RAMP_RUN back from where the corridor enters the upper
    # room at x=10), never derived from whichever segment happened to cross a
    # room edge — that derivation produced a 56° ramp and a 23-unit ramp on
    # L-shaped corridors, which failed 7 of the 20 MID-DEMO prompts.
    origin_x = nums[9]
    assert origin_x == pytest.approx((10.0 - RAMP_RUN + 10.0) / 2)
    ramp_size = re.search(
        r'\[sub_resource type="BoxMesh" id="MeshCorridorZ00Z01_Seg1Ramp"\]\n'
        r"size = Vector3\(([^)]*)\)",
        scene,
    )
    hyp = max(float(n) for n in ramp_size.group(1).split(","))
    assert hyp == pytest.approx(math.hypot(RAMP_RUN, 1.5), abs=0.01)  # rise 1.5 over the fixed run
    # A flat approach piece precedes the ramp at the lower elevation.
    assert '[node name="CorridorZ00Z01_Seg1" type="StaticBody3D"' in scene
