"""Audio QA gate: a produced WAV is validated the same way a mesh GLB is.

Real WAVs are written with stdlib `wave`, so the gate parses genuine audio, not a
stub. The property that matters: a broken or out-of-window clip FAILs with a
machine-readable error, so the resolver can fall back to curated.
"""

import wave
from pathlib import Path

from asset_farm.brief import AssetBrief
from asset_farm.qa_audio import qa_audio


def _wav(path: Path, seconds: float, rate: int = 44100) -> Path:
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(b"\x00\x00" * int(seconds * rate))
    return path


def test_sfx_within_the_window_passes(tmp_path):
    brief = AssetBrief("a heavy stone door slam", "audio_sfx")
    report = qa_audio(_wav(tmp_path / "s.wav", 1.5), brief)
    assert report.passed
    assert 1.4 < report.duration_s < 1.6


def test_sfx_too_long_fails(tmp_path):
    brief = AssetBrief("an endless drone", "audio_sfx")  # sfx window is <= 8s
    report = qa_audio(_wav(tmp_path / "s.wav", 20.0), brief)
    assert not report.passed
    assert "AUDIO_DURATION_OUT_OF_RANGE" in [e.code for e in report.errors]


def test_loop_window_is_wider_than_sfx(tmp_path):
    # 20s fails as an sfx but passes as a loop.
    twenty = _wav(tmp_path / "l.wav", 20.0)
    assert not qa_audio(twenty, AssetBrief("ambient hum", "audio_sfx")).passed
    assert qa_audio(twenty, AssetBrief("ambient hum", "audio_loop")).passed


def test_missing_file_fails(tmp_path):
    report = qa_audio(tmp_path / "nope.wav", AssetBrief("a click", "audio_sfx"))
    assert not report.passed
    assert "AUDIO_EMPTY" in [e.code for e in report.errors]


def test_non_wav_fails(tmp_path):
    junk = tmp_path / "x.wav"
    junk.write_bytes(b"this is not a wav")
    report = qa_audio(junk, AssetBrief("a click", "audio_sfx"))
    assert not report.passed
    assert "AUDIO_MALFORMED" in [e.code for e in report.errors]
