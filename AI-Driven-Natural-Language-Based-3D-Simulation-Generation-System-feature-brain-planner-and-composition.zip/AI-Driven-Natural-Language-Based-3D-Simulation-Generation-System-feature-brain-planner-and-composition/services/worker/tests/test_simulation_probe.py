from __future__ import annotations

import json

from godot_client.simulation_probe import (
    PROBE_PREFIX,
    _parse,
    compare_platform_traces,
)


def test_probe_parser_requires_machine_readable_verdict():
    payload = {"status": "PASS", "errors": [], "trace": [{"entity_id": "ent_dog"}]}
    result = _parse([PROBE_PREFIX + json.dumps(payload)], source="test", returncode=0)
    assert result["status"] == "PASS"
    assert result["evidence"]["state_trace"] == payload

    missing = _parse(["ordinary engine output"], source="test", returncode=0)
    assert missing["status"] == "UNAVAILABLE"
    assert missing["errors"][0]["code"] == "RUNTIME_PROBE_OUTPUT_MISSING"


def test_platform_parity_compares_actual_state_traces():
    trace = {"status": "PASS", "errors": [], "trace": [{"entity_id": "ent_dog"}]}
    desktop = {"status": "PASS", "errors": [], "evidence": {"state_trace": trace}}
    web = {"status": "PASS", "errors": [], "evidence": {"state_trace": trace}}
    assert compare_platform_traces(desktop, web)["status"] == "PASS"

    web["evidence"]["state_trace"] = {**trace, "trace": []}
    mismatch = compare_platform_traces(desktop, web)
    assert mismatch["status"] == "FAIL"
    assert mismatch["errors"][0]["code"] == "DESKTOP_WEB_STATE_TRACE_MISMATCH"


def test_platform_parity_ignores_only_dynamic_physics_position_drift():
    desktop_trace = {
        "status": "PASS",
        "errors": [],
        "trace": [
            {
                "entity_id": "ent_cow",
                "dynamic": True,
                "position_m": [1.0, 0.5, 2.0],
                "capabilities": {"locomotion": {"state": "moving"}},
            },
            {
                "entity_id": "ent_house",
                "dynamic": False,
                "position_m": [5.0, 3.0, 8.0],
                "capabilities": {},
            },
        ],
    }
    web_trace = json.loads(json.dumps(desktop_trace))
    web_trace["trace"][0]["position_m"] = [4.0, 0.5, 7.0]
    desktop = {"status": "PASS", "errors": [], "evidence": {"state_trace": desktop_trace}}
    web = {"status": "PASS", "errors": [], "evidence": {"state_trace": web_trace}}
    assert compare_platform_traces(desktop, web)["status"] == "PASS"

    web_trace["trace"][1]["position_m"] = [6.0, 3.0, 8.0]
    assert compare_platform_traces(desktop, web)["status"] == "FAIL"
