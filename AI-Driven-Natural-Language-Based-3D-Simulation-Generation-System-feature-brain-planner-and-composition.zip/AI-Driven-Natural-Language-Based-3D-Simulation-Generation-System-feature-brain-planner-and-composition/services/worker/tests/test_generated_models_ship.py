"""Generated assets must reach the GAME, not just the lineage record.

The farm could already generate + QA-gate a model and write it to disk, but
`write_project` had no parameter that could accept one: every game shipped the
curated kit regardless. These tests pin the seam shut, and pin the policy that
decides what a game is allowed to wear.
"""

import json
from pathlib import Path

import pytest
from asset_farm.backends import MockBackend
from asset_farm.brief import AssetBrief
from asset_farm.pipeline import resolve_spec_assets, shippable_models
from asset_farm.qa_gate import mesh_capabilities
from godot_client.project_writer import write_project
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan

REPO = Path(__file__).resolve().parents[3]
KIT = REPO / "content" / "kits"  # curated root (one folder per pack)
SKELETON = KIT / "kaykit" / "characters" / "Skeleton_Minion.glb"
GOLDEN_SPEC = REPO / "contracts" / "examples" / "golden_game.spec.json"


@pytest.fixture(scope="module")
def spec():
    return json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))


@pytest.fixture(scope="module")
def golden_plan(spec):
    return to_level_plan(run_pcg(spec))


# --- mesh capabilities: what a model can DO -------------------------------


@pytest.mark.skipif(not SKELETON.is_file(), reason="kit not present")
def test_a_curated_character_reports_its_rig_and_clips():
    caps = mesh_capabilities(SKELETON)
    assert caps["rigged"] and caps["animated"]
    assert caps["animations"] > 50  # KayKit skeletons ship ~95
    assert caps["skins"] >= 1


def test_a_generated_mesh_is_not_a_character_until_it_is_rigged(tmp_path):
    made = MockBackend().generate(AssetBrief("a scruffy village dog", "character"), tmp_path)
    caps = mesh_capabilities(made.path)
    assert caps["animations"] == 0 and caps["skins"] == 0
    assert not caps["animated"]


def test_an_unreadable_mesh_degrades_instead_of_raising(tmp_path):
    junk = tmp_path / "x.glb"
    junk.write_bytes(b"not a glb at all")
    assert mesh_capabilities(junk) == {
        "animations": 0,
        "skins": 0,
        "rigged": False,
        "animated": False,
    }


# --- the shipping policy --------------------------------------------------


def _manifest(tier, path, fallback=None, requires_animation=True):
    return {
        "tier": tier,
        "path": str(path),
        "notes": [],
        "fallback": str(fallback) if fallback is not None else None,
        "requires_animation": requires_animation,
    }


def test_a_generated_prop_displacing_a_static_prop_ships(tmp_path):
    made = MockBackend().generate(AssetBrief("a mossy barrel", "prop"), tmp_path)
    static_curated = KIT / "kaykit" / "props" / "chest.glb"
    ship = shippable_models({"prop:barrel_01": _manifest("generated", made.path, static_curated)})
    assert ship == {"prop:barrel_01": made.path}


@pytest.mark.skipif(not SKELETON.is_file(), reason="kit not present")
def test_a_static_mesh_never_displaces_an_animated_one(tmp_path):
    # The trade: right species but dead, vs wrong species but alive. Take alive.
    made = MockBackend().generate(AssetBrief("a scruffy village dog", "character"), tmp_path)
    manifest = {"enemy:dog": _manifest("generated", made.path, SKELETON)}
    assert shippable_models(manifest) == {}
    note = manifest["enemy:dog"]["notes"][-1]
    assert "not rigged/animated" in note
    assert "skins=0" in note and "clips=0" in note  # lineage says WHY, not just that


def test_a_generated_body_ships_when_it_displaces_nothing_animated(tmp_path):
    # The player's stand-in is a bare capsule that never animated: a static
    # generated body loses no motion, so uniqueness wins. No special-casing.
    made = MockBackend().generate(AssetBrief("a scruffy village dog", "character"), tmp_path)
    assert shippable_models({"player:main": _manifest("generated", made.path, None)}) == {
        "player:main": made.path
    }


@pytest.mark.skipif(not SKELETON.is_file(), reason="kit not present")
def test_a_rigged_animated_character_ships_the_moment_one_exists():
    # Forward-compatibility: the rule is written against capability, not against
    # today's limits. A rigged+animated generated character needs no code change.
    manifest = {"enemy:dog": _manifest("generated", SKELETON, SKELETON)}
    assert shippable_models(manifest) == {"enemy:dog": SKELETON}


def test_cached_assets_ship_too_because_the_cache_holds_generated_work(tmp_path):
    made = MockBackend().generate(AssetBrief("a crate", "prop"), tmp_path)
    assert shippable_models({"prop:c": _manifest("cache", made.path, None)})


@pytest.mark.skipif(not SKELETON.is_file(), reason="kit not present")
def test_curated_picks_ship_too_because_the_writers_default_is_not_authoritative():
    # This USED to return {} on the reasoning that "the writer already instances
    # kit models". That stopped being true when the curated tier became semantic:
    # the writer's default is an index cycle, so the farm's pick must reach it or
    # a brief-matched model would be silently discarded.
    assert shippable_models({"enemy:brute": _manifest("curated", SKELETON, SKELETON)}) == {
        "enemy:brute": SKELETON
    }


def test_an_unresolved_asset_wears_nothing(tmp_path):
    assert shippable_models({"prop:c": _manifest("unresolved", tmp_path / "x.glb", None)}) == {}


def test_sound_entries_are_not_treated_as_bodies(tmp_path):
    made = MockBackend().generate(AssetBrief("a crate", "prop"), tmp_path)
    assert shippable_models({"sound:enemy:dog:attack": _manifest("generated", made.path)}) == {}


def test_a_vanished_file_is_held_and_says_so(tmp_path):
    manifest = {"prop:c": _manifest("generated", tmp_path / "gone.glb", None)}
    assert shippable_models(manifest) == {}
    assert "missing" in manifest["prop:c"]["notes"][-1]


@pytest.mark.skipif(not SKELETON.is_file(), reason="kit not present")
def test_the_manifest_records_what_the_generated_asset_displaced(spec, tmp_path):
    # Lineage must say what you would have seen instead (§11).
    manifest = resolve_spec_assets(
        spec, kit_dir=KIT, cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=MockBackend(),
    )
    enemy = next(v for k, v in manifest.items() if k.startswith("enemy:"))
    assert enemy["fallback"] is not None
    assert Path(enemy["fallback"]).is_file()


# --- the writer seam ------------------------------------------------------


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_the_farms_models_are_instanced_and_copied_in(spec, golden_plan, tmp_path):
    work = tmp_path / "farm"
    manifest = resolve_spec_assets(
        spec, kit_dir=KIT, cache_dir=work / "cache", work_dir=work / "work",
        backend=MockBackend(),
    )
    ship = shippable_models(manifest)
    assert ship, "the mock backend should have produced shippable props"

    out = tmp_path / "proj"
    write_project(
        golden_plan, "T", out,
        templates_dir=REPO / "engine" / "templates",
        kit_dir=KIT,
        asset_models=ship,
        prop_configs={
            p["prop_id"]: p.get("interactable_template_id") for p in spec["entities"]["props"]
        },
    )
    scene = (out / "main.tscn").read_text(encoding="utf-8")
    assert '[ext_resource type="PackedScene" path="res://assets/' in scene

    copied = {p.name for p in (out / "assets").glob("*.glb")}
    assert copied, "generated models must be copied into the project"
    # Content-addressed: entities sharing a brief share ONE file, not N copies.
    assert len(copied) < len(ship)
    for name in copied:
        assert f'path="res://assets/{name}"' in scene


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_a_door_never_wears_a_generated_model(spec, golden_plan, tmp_path):
    # Doors are FUNCTIONAL (the swinging LockedDoor slab); a mesh there would be a
    # floating duplicate. The pipeline skips them, but the writer must not rely on
    # that: hand it a door model explicitly and it must still refuse.
    door_ids = [
        p["prop_id"]
        for p in spec["entities"]["props"]
        if p.get("interactable_template_id", "").startswith("door_hinged")
    ]
    if not door_ids:
        pytest.skip("golden spec has no door prop")
    made = MockBackend().generate(AssetBrief("a door", "prop"), tmp_path / "gen")

    out = tmp_path / "proj"
    write_project(
        golden_plan, "T", out,
        templates_dir=REPO / "engine" / "templates",
        kit_dir=KIT,
        asset_models={f"prop:{door_ids[0]}": made.path},
        prop_configs={
            p["prop_id"]: p.get("interactable_template_id") for p in spec["entities"]["props"]
        },
    )
    scene = (out / "main.tscn").read_text(encoding="utf-8")
    assert f"res://assets/{made.path.name}" not in scene
    assert not (out / "assets").exists()


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_without_farm_models_the_build_is_exactly_the_curated_one(golden_plan, tmp_path):
    a, b = tmp_path / "a", tmp_path / "b"
    for out in (a, b):
        write_project(
            golden_plan, "T", out, templates_dir=REPO / "engine" / "templates", kit_dir=KIT
        )
    write_project(
        golden_plan, "T", b, templates_dir=REPO / "engine" / "templates", kit_dir=KIT,
        asset_models={},
    )
    assert (a / "main.tscn").read_text() == (b / "main.tscn").read_text()
    assert not (b / "assets").exists()


@pytest.mark.skipif(not SKELETON.is_file(), reason="kit not present")
def test_a_static_character_ships_as_itself_not_as_a_skeleton(tmp_path):
    """The open-vocabulary case: a visitor that never animates stays a visitor.

    The library's only humanoid is a rigged skeleton, so before this every
    unmatched character looked like it was displacing motion and shipped as a
    skeleton — in a jungle, in a museum, everywhere.
    """
    made = MockBackend().generate(AssetBrief("a jungle field researcher", "character"), tmp_path)
    manifest = {
        "ent_visitor": _manifest("generated", made.path, SKELETON, requires_animation=False)
    }
    assert shippable_models(manifest) == {"ent_visitor": made.path}
    assert "substitution" not in manifest["ent_visitor"]


@pytest.mark.skipif(not SKELETON.is_file(), reason="kit not present")
def test_a_body_swap_is_recorded_as_a_machine_readable_substitution(tmp_path):
    """"Why am I looking at a skeleton?" must be answerable outside the logs."""
    made = MockBackend().generate(AssetBrief("a scruffy village dog", "character"), tmp_path)
    manifest = {"enemy:dog": _manifest("generated", made.path, SKELETON)}
    assert shippable_models(manifest) == {}

    substitution = manifest["enemy:dog"]["substitution"]
    assert substitution["code"] == "GENERATED_BODY_NOT_RIGGED"
    assert substitution["user_visible"] is True
    assert substitution["shipped"] == str(SKELETON)
    assert substitution["instead_of"] == str(made.path)
