"""A curated model's own material can be as wrong as a generated one's.

`metallicFactor` defaults to 1.0 in glTF 2.0 when absent, and these scenes have a flat
background colour, no sky and no reflection probe -- so a fully metallic surface has
nothing to reflect and renders BLACK. The correction originally fired only on the absent
case, which left the whole curated library untouched, because a pack author writes the
value out. Measured on `kenney-nature/models/tree_oak.glb`:

    leafsGreen  baseColor=[0.16,0.79,0.67]  metallicFactor=1  roughness=1
    woodBark    baseColor=[0.89,0.51,0.34]  metallicFactor=1  roughness=1

Every tree in the forest render carried a harsh black flank because of it.
"""

import json
import struct
from pathlib import Path

from godot_client.simulation_project_writer import _copy_asset

KITS = Path(__file__).resolve().parents[3] / "content" / "kits"


def _materials(glb: Path) -> list[dict]:
    raw = glb.read_bytes()
    length = struct.unpack("<I", raw[12:16])[0]
    return json.loads(raw[20 : 20 + length]).get("materials") or []


def test_an_explicit_metallic_one_is_corrected(tmp_path: Path) -> None:
    source = KITS / "kenney-nature/models/tree_oak.glb"
    assert source.is_file(), "the nature pack is not vendored"
    # The source really does declare it; this test is worthless if that changes silently.
    assert all(
        m["pbrMetallicRoughness"].get("metallicFactor") == 1 for m in _materials(source)
    )

    out = tmp_path / "tree.glb"
    _copy_asset(source, out)

    materials = _materials(out)
    assert materials
    for material in materials:
        assert material["pbrMetallicRoughness"]["metallicFactor"] == 0.0
    # The artist's COLOURS are not ours to change -- only the lighting response.
    colours = [m["pbrMetallicRoughness"]["baseColorFactor"] for m in materials]
    assert [round(c, 2) for c in colours[0]] == [0.16, 0.79, 0.67, 1]


def test_a_material_with_a_metallic_texture_is_left_alone(tmp_path: Path) -> None:
    """A map, not this factor, decides what is metal when one was authored."""
    document = {
        "asset": {"version": "2.0"},
        "materials": [
            {
                "name": "brass",
                "pbrMetallicRoughness": {
                    "metallicFactor": 1.0,
                    "roughnessFactor": 0.3,
                    "metallicRoughnessTexture": {"index": 0},
                },
            }
        ],
    }
    body = json.dumps(document, separators=(",", ":")).encode()
    body += b" " * ((4 - len(body) % 4) % 4)
    glb = (
        b"glTF"
        + struct.pack("<I", 2)
        + struct.pack("<I", 20 + len(body))
        + struct.pack("<I", len(body))
        + b"JSON"
        + body
    )
    source = tmp_path / "brass.glb"
    source.write_bytes(glb)
    out = tmp_path / "copied.glb"
    _copy_asset(source, out)

    kept = _materials(out)[0]["pbrMetallicRoughness"]
    assert kept["metallicFactor"] == 1.0
