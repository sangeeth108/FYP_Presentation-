"""Composable interactive objects — socket snapping (ADR-0008).

The production reason this exists: a vehicle door (or a house door, or a lid) is a
SEPARATE part bound to a behaviour template, and it must land at the exact hinge
point on its parent so it opens correctly — a "door near the body" cannot. These
pin the deterministic geometry that guarantees it, with no Godot and no GPU. The
generalisation is the point: the same asserts hold whether the parent is a house
or a car, because the machinery never names either.
"""


import pytest
from godot_client.composition import (
    AFFORDANCE_TEMPLATES,
    AffordancePart,
    CompositeObject,
    Socket,
    part_world_transform,
    resolve_parts,
)


def test_a_socket_snaps_to_the_right_side_of_the_parent():
    # A car 2.0 wide x 4.0 deep, at the origin. Left door at the left edge, on the
    # ground, a little forward -> world x = -1.0 (half of 2.0), z = +0.4.
    bbox = (2.0, 1.2, 4.0)
    left_door = Socket(name="door_L", offset=(-0.5, 0.0, 0.1), facing_deg=90.0)
    x, y, z, yaw = part_world_transform((0.0, 0.0, 0.0), 0.0, bbox, left_door)
    assert x == pytest.approx(-1.0)
    assert y == pytest.approx(0.0)  # on the ground (base)
    assert z == pytest.approx(0.4)
    assert yaw == pytest.approx(90.0)  # faces outward (left)


def test_rotating_the_parent_carries_the_socket_around():
    # Rotate the whole car 90 deg; the left-side door must move to what is now the
    # world -Z side and keep facing outward. This is why baking the door in fails
    # and a socket does not: the hinge tracks the parent exactly.
    bbox = (2.0, 1.2, 4.0)
    left_door = Socket(name="door_L", offset=(-0.5, 0.0, 0.0), facing_deg=90.0)
    x, y, z, yaw = part_world_transform((0.0, 0.0, 0.0), 90.0, bbox, left_door)
    # local (-1.0, 0, 0) rotated by +90 about Y -> (x= -1*cos90 + 0 = 0, z = -(-1)*sin90 = +1.0)
    assert x == pytest.approx(0.0, abs=1e-9)
    assert z == pytest.approx(1.0)
    assert yaw == pytest.approx(180.0)  # parent yaw + socket facing


def test_socket_translates_with_the_parent_origin():
    bbox = (2.0, 2.0, 2.0)
    top = Socket(name="lid", offset=(0.0, 1.0, 0.0))  # top-centre
    x, y, z, _ = part_world_transform((10.0, 5.0, -3.0), 0.0, bbox, top)
    assert (x, y, z) == pytest.approx((10.0, 5.0 + 2.0, -3.0))  # y = base + full height


def test_out_of_range_offset_is_rejected():
    with pytest.raises(ValueError):
        AffordancePart("d", "door_hinged", Socket("s", offset=(0.9, 0.0, 0.0)))  # x > 0.5
    with pytest.raises(ValueError):
        AffordancePart("d", "door_hinged", Socket("s", offset=(0.0, -0.2, 0.0)))  # y < 0


def test_unknown_template_is_rejected():
    with pytest.raises(ValueError):
        AffordancePart("d", "teleporter", Socket("s", offset=(0.0, 0.0, 0.0)))


def test_known_affordances_cover_hinged_and_point():
    assert AFFORDANCE_TEMPLATES["door_hinged"] == "hinged"
    assert AFFORDANCE_TEMPLATES["pickup_collectible"] == "point"


def test_resolve_parts_is_order_stable_and_defaults_the_open_angle():
    car = CompositeObject(
        object_id="car01",
        bbox=(2.0, 1.2, 4.0),
        parts=(
            AffordancePart("door_L", "door_hinged", Socket("sL", (-0.5, 0.0, 0.1), 90.0)),
            AffordancePart("door_R", "door_hinged", Socket("sR", (0.5, 0.0, 0.1), -90.0),
                           params={"open_angle_deg": -70.0}),  # a car door opens less
        ),
    )
    placed = resolve_parts(car, parent_origin=(5.0, 0.0, 5.0), parent_yaw_deg=0.0)
    assert [p.part_id for p in placed] == ["door_L", "door_R"]  # declaration order
    # left door defaulted the swing; right door kept the brief's override
    assert placed[0].params["open_angle_deg"] == pytest.approx(-90.0)
    assert placed[1].params["open_angle_deg"] == pytest.approx(-70.0)
    # the two doors are on opposite sides of the car
    assert placed[0].x == pytest.approx(4.0)  # 5.0 + (-1.0)
    assert placed[1].x == pytest.approx(6.0)  # 5.0 + (+1.0)
    assert all(p.hinge == "y" for p in placed)


def test_the_same_machinery_serves_a_house_door():
    # No special-casing: a house is just a bigger bbox with a front-centre door.
    house = CompositeObject(
        object_id="cottage",
        bbox=(6.0, 3.0, 6.0),
        parts=(AffordancePart("front", "door_hinged_lockable",
                              Socket("front_door", (0.0, 0.0, 0.5)),
                              params={"locked": True, "unlocked_by_objective": "find_key"}),),
    )
    placed = resolve_parts(house, parent_origin=(0.0, 0.0, 0.0))
    assert placed[0].z == pytest.approx(3.0)  # front edge = +half depth
    assert placed[0].params["locked"] is True
    assert placed[0].params["unlocked_by_objective"] == "find_key"
