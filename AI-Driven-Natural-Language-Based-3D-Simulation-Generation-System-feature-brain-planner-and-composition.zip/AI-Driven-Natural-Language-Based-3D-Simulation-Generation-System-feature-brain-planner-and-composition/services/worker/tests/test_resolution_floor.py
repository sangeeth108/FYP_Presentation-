"""No entity may resolve to nothing.

The curated tier is meant to guarantee playability: a failure should degrade
the LOOK of a world, never its existence. There was no floor under it. A farm
prompt's tractor (`vehicle`, which mesh generation excludes and the kit has no
model for) and its chickens (an animal asked for as mass content, matching no
procedural form) both fell through every tier to `unresolved`, the mandatory
asset gate failed, and a world that was otherwise complete could not be built.

These tests come first deliberately. The branch they cover runs ONLY when every
other tier has already declined, so it is invisible to every ordinary test --
which is exactly how a previous attempt at this floor shipped a NameError that
crashed every run for a day. A guard nobody has watched fail is not a guard.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest
from asset_farm.brief import AssetBrief


@pytest.fixture
def forced_failure(monkeypatch):
    """Make every upstream tier decline, so only the floor can answer."""
    import asset_farm.pipeline as pipeline

    def _always_fails(*args, **kwargs):
        raise RuntimeError("no curated model and no generation path for this kind")

    monkeypatch.setattr(pipeline, "resolve_asset", _always_fails)
    return pipeline


def test_a_kind_nothing_can_build_still_resolves(forced_failure):
    """The tractor case: no mesh, no generator, no procedural form."""
    brief = AssetBrief(brief="a red farm tractor", category="prop", tri_budget=2000)
    with tempfile.TemporaryDirectory() as work_dir:
        entry = forced_failure._resolve_one(
            brief, None, None, None, Path(work_dir), None
        )
        # Asserted INSIDE the block: the file lives in the temporary directory
        # and vanishes with it.
        assert entry["tier"] != "unresolved", (
            "every tier declined and nothing took over; the run would fail the "
            "mandatory asset gate for a world that is otherwise complete"
        )
        assert Path(entry["path"]).is_file(), "the floor must produce a real file"


def test_the_floor_says_it_is_a_stand_in(forced_failure):
    """A box shipped as a tractor must never read as a real asset."""
    brief = AssetBrief(brief="a red farm tractor", category="prop", tri_budget=2000)
    with tempfile.TemporaryDirectory() as work_dir:
        entry = forced_failure._resolve_one(
            brief, None, None, None, Path(work_dir), None
        )
    notes = " ".join(entry.get("notes") or []).lower()  # notes outlive the dir
    assert notes, "the substitution must be recorded"
    assert "box" in notes or "stand-in" in notes or "no curated" in notes, (
        f"notes should say what happened and why; got {entry.get('notes')!r}"
    )


def test_the_floor_never_raises_even_with_nowhere_to_write(forced_failure):
    """A failing fallback must degrade, not explode."""
    brief = AssetBrief(brief="a red farm tractor", category="prop", tri_budget=2000)
    entry = forced_failure._resolve_one(brief, None, None, None, None, None)
    assert entry["tier"] == "unresolved", "with no output directory there is no floor"
    assert entry.get("notes"), "and it must still explain itself"


def test_ordinary_resolution_is_untouched():
    """The floor must not shadow a tier that would have succeeded."""
    import asset_farm.pipeline as pipeline
    import inspect

    source = inspect.getsource(pipeline._resolve_one)
    assert source.index("resolve_asset(") < source.index("except Exception"), (
        "the floor must sit in the failure path, never ahead of resolution"
    )
