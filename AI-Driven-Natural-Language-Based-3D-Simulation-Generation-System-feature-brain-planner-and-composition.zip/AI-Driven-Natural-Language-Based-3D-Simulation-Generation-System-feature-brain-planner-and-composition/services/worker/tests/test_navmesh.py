import json
import re
from pathlib import Path

import pytest
from godot_client.navmesh import navmesh_arrays
from godot_client.project_writer import write_project
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan

TWO_ROOMS = {
    "level_plan_version": "1.0.0",
    "seed": 0,
    "algorithm": "room_corridor",
    "zones": [
        {"zone_id": "z00", "kind": "entry", "tier": 0},
        {"zone_id": "z01", "kind": "exit", "tier": 0},
    ],
    "rooms": [
        {"zone_id": "z00", "x": 0.0, "z": 0.0, "width": 6.0, "depth": 6.0, "elevation": 0.0},
        {"zone_id": "z01", "x": 10.0, "z": 0.0, "width": 6.0, "depth": 6.0, "elevation": 0.0},
    ],
    "corridors": [
        {"a": "z00", "b": "z01", "kind": "open", "width": 2.0, "points": [[3.0, 3.0], [13.0, 3.0]]}
    ],
    "entities": [],
}

REPO = Path(__file__).resolve().parents[3]
GOLDEN_SPEC = REPO / "contracts" / "examples" / "golden_game.spec.json"
TEMPLATES_DIR = REPO / "engine" / "templates"


def test_navmesh_polygons_are_valid_and_connected():
    vertices, polygons = navmesh_arrays(TWO_ROOMS)
    assert polygons
    vertex_count = len(vertices) // 3
    for poly in polygons:
        assert len(poly) >= 4
        assert all(0 <= idx < vertex_count for idx in poly)

    # Polygon adjacency via exact shared edges must form one component
    # (TWO_ROOMS is a single-elevation connected floor).
    edge_owners: dict[frozenset, list[int]] = {}
    for p_idx, poly in enumerate(polygons):
        for k in range(len(poly)):
            edge = frozenset((poly[k], poly[(k + 1) % len(poly)]))
            edge_owners.setdefault(edge, []).append(p_idx)
    neighbors: dict[int, set[int]] = {i: set() for i in range(len(polygons))}
    for owners in edge_owners.values():
        for a in owners:
            for b in owners:
                if a != b:
                    neighbors[a].add(b)
    seen = {0}
    frontier = [0]
    while frontier:
        for n in neighbors[frontier.pop()]:
            if n not in seen:
                seen.add(n)
                frontier.append(n)
    assert seen == set(range(len(polygons)))


@pytest.fixture(scope="module")
def enemy_scene(tmp_path_factory):
    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    plan = to_level_plan(run_pcg(spec))
    out = tmp_path_factory.mktemp("proj")
    write_project(
        plan, "T", out, templates_dir=TEMPLATES_DIR,
        player_config=spec["player"],
        enemy_configs={e["enemy_id"]: e.get("stats", {}) for e in spec["entities"]["enemies"]},
    )
    return plan, (out / "main.tscn").read_text(encoding="utf-8")


def test_enemies_are_bodies_with_ai_and_stats(enemy_scene):
    plan, scene = enemy_scene
    enemy_ids = [e["entity_id"] for e in plan["entities"] if e["kind"] == "enemy"]
    assert enemy_ids
    for entity_id in enemy_ids:
        name = re.escape(
            "".join(p.capitalize() for p in entity_id.split("_")[:-1])
            + "_"
            + entity_id.split("_")[-1]
        )
        block = re.search(rf'\[node name="{name}" type="CharacterBody3D"[^\[]+', scene)
        assert block is not None, entity_id
        assert 'script = ExtResource("4_ai")' in block.group(0)
        assert "health = 5" in block.group(0)
        assert "damage = 1" in block.group(0)
        assert "speed = 3" in block.group(0)
    assert scene.count('type="NavigationAgent3D"') == len(enemy_ids)


def test_navigation_region_is_emitted(enemy_scene):
    _, scene = enemy_scene
    assert '[node name="NavigationRegion" type="NavigationRegion3D"' in scene
    assert '[sub_resource type="NavigationMesh" id="NavMesh"]' in scene
    assert "PackedVector3Array(" in scene
