"""A generated mesh has no skeleton, so it must never stand in for a character.

`LocalGenBackend` has always refused character briefs. `GpuAssetBackend` did not, and
enabling it (Phase A) therefore made the controlled actor WORSE: measured on
run_8d4f6ab30b454210b313467b033f626d, the dog came back `rigged: false, animations: 0`,
failed the mandatory `asset_animation_compatibility` gate and took the run down -- where
the local backend's refusal had let the ladder fall through to the curated Husky and its
24 clips.

A better mesh generator is still not a rigger.
"""

import pytest

from asset_farm.backends import AssetBrief
from asset_farm.backends_gpu import GenerationBackendError, GpuAssetBackend


@pytest.mark.parametrize("category", ["character"])
def test_a_character_brief_is_refused_before_any_gpu_work(category, tmp_path):
    backend = GpuAssetBackend()
    brief = AssetBrief(brief="a dog", category=category, tri_budget=8000)
    with pytest.raises(GenerationBackendError) as raised:
        backend.generate(brief, tmp_path)
    assert "does not generate" in str(raised.value)


@pytest.mark.parametrize("category", ["prop", "building_module", "foliage"])
def test_the_categories_it_can_actually_make_are_not_refused(category):
    # Not a generation test -- just that the guard lets them through to the real work.
    assert category in GpuAssetBackend._MESH_CATEGORIES


def test_both_backends_refuse_the_same_categories():
    """The two backends must not disagree about what generation can produce, or which
    one is configured decides whether a dog can walk."""
    from asset_farm.backends_local import _MESH_CATEGORIES as local_categories

    assert GpuAssetBackend._MESH_CATEGORIES == local_categories
