"""Gate 3 — asset QA (docs/VALIDATION_PLAN.md).

It was `record(3, "asset_qa", None)` — SKIPPED on every job, with a comment
saying the farm would arrive in P3. P3 arrived: qa_mesh and qa_audio judge every
produced asset and their reports sit in the manifest. A gate that reports nothing
while the thing it judges runs is the same dishonesty gate 6 had for weeks.

The policy is the interesting part: "1 regen attempt -> curated substitute
(never blocks)". So this gate must NOT fail a game for a QA failure — the
resolver already fell back, which is the design working. What it verifies is the
resolver's *promise*: that nothing ships un-gated. A gate that only ever agrees
with the component it checks is theatre.
"""

import json
from pathlib import Path

import pytest
from validators.gates import run_gates

REPO = Path(__file__).resolve().parents[3]
GOLDEN_SPEC = REPO / "contracts" / "examples" / "golden_game.spec.json"
SCHEMA = json.loads((REPO / "contracts" / "game_spec.schema.json").read_text(encoding="utf-8"))


@pytest.fixture(scope="module")
def spec_and_plan():
    from pcg.pipeline import run_pcg
    from pcg.serialize import to_level_plan

    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    return spec, to_level_plan(run_pcg(spec))


def _gate(report, number=3):
    return next(g for g in report["gates"] if g["gate"] == number)


def _entry(tier, path, qa=None):
    return {"tier": tier, "path": str(path), "qa": qa, "notes": []}


def _real_file(tmp_path, name="a.glb"):
    p = tmp_path / name
    p.write_bytes(b"GLB")
    return p


# --- the honest skip ------------------------------------------------------


def test_no_farm_means_skipped_not_a_free_pass(spec_and_plan):
    spec, plan = spec_and_plan
    report = run_gates(spec, plan, schema=SCHEMA)
    assert _gate(report)["verdict"] == "SKIPPED"


# --- the policy: a QA failure must NEVER block ----------------------------


def test_a_qa_failure_that_fell_back_to_curated_does_not_block(spec_and_plan, tmp_path):
    """The design working, not an error.

    The generated asset flunked QA, so the resolver shipped the curated one. That
    is exactly "1 regen attempt -> curated substitute (never blocks)". Gate 3
    failing here would block a game for successfully protecting itself.
    """
    spec, plan = spec_and_plan
    manifest = {
        "prop:barrel": {
            "tier": "curated",
            "path": str(_real_file(tmp_path)),
            "qa": None,
            "notes": ["generated asset failed QA: MESH_TOO_MANY_TRIS"],
        }
    }
    report = run_gates(spec, plan, schema=SCHEMA, asset_manifest=manifest)
    assert _gate(report)["verdict"] == "PASS"


def test_a_healthy_farm_run_passes(spec_and_plan, tmp_path):
    spec, plan = spec_and_plan
    manifest = {
        "prop:a": _entry("generated", _real_file(tmp_path, "a.glb"), {"passed": True}),
        "prop:b": _entry("cache", _real_file(tmp_path, "b.glb"), {"passed": True}),
        "enemy:c": _entry("curated", _real_file(tmp_path, "c.glb"), None),
    }
    report = run_gates(spec, plan, schema=SCHEMA, asset_manifest=manifest)
    assert _gate(report)["verdict"] == "PASS"


def test_an_unresolved_asset_does_not_block_because_nothing_shipped(spec_and_plan):
    # The writer used its own default; the brief simply went unhonoured. Ugly,
    # recorded in the manifest notes, but not a broken game.
    spec, plan = spec_and_plan
    manifest = {"prop:x": {"tier": "unresolved", "path": "", "qa": None, "notes": ["boom"]}}
    report = run_gates(spec, plan, schema=SCHEMA, asset_manifest=manifest)
    assert _gate(report)["verdict"] == "PASS"


# --- the two ways the S5 contract can actually be violated ----------------


def test_an_asset_that_shipped_without_passing_qa_is_a_resolver_bug(spec_and_plan, tmp_path):
    """The check worth having.

    The resolver promises nothing ships un-gated. If a `generated` asset's own QA
    report says it failed, the promise is broken — and only an independent gate
    would ever notice.
    """
    spec, plan = spec_and_plan
    manifest = {
        "prop:bad": _entry(
            "generated",
            _real_file(tmp_path),
            {"passed": False, "errors": [{"code": "MESH_TOO_MANY_TRIS"}]},
        )
    }
    report = run_gates(spec, plan, schema=SCHEMA, asset_manifest=manifest)
    assert _gate(report)["verdict"] == "FAIL"
    err = next(e for e in report["errors"] if e["gate"] == 3)
    assert err["code"] == "ASSET_SHIPPED_WITHOUT_PASSING_QA"
    assert err["failure_class"] == "asset"
    assert "MESH_TOO_MANY_TRIS" in err["message"]
    assert err["data"]["qa_errors"] == ["MESH_TOO_MANY_TRIS"]  # machine-readable (§13)


def test_a_shipped_asset_whose_file_vanished_is_caught(spec_and_plan, tmp_path):
    spec, plan = spec_and_plan
    manifest = {"prop:gone": _entry("generated", tmp_path / "never_written.glb", {"passed": True})}
    report = run_gates(spec, plan, schema=SCHEMA, asset_manifest=manifest)
    assert _gate(report)["verdict"] == "FAIL"
    err = next(e for e in report["errors"] if e["gate"] == 3)
    assert err["code"] == "ASSET_FILE_MISSING"
    assert err["data"]["label"] == "prop:gone"


def test_an_empty_path_is_caught_too(spec_and_plan):
    spec, plan = spec_and_plan
    manifest = {"prop:empty": _entry("curated", "", {"passed": True})}
    report = run_gates(spec, plan, schema=SCHEMA, asset_manifest=manifest)
    assert _gate(report)["verdict"] == "FAIL"


def test_gate3_failures_are_reported_per_asset(spec_and_plan, tmp_path):
    spec, plan = spec_and_plan
    manifest = {
        "prop:a": _entry("generated", tmp_path / "no1.glb", {"passed": True}),
        "prop:b": _entry("generated", tmp_path / "no2.glb", {"passed": True}),
        "prop:ok": _entry("generated", _real_file(tmp_path), {"passed": True}),
    }
    report = run_gates(spec, plan, schema=SCHEMA, asset_manifest=manifest)
    gate3_errors = [e for e in report["errors"] if e["gate"] == 3]
    assert len(gate3_errors) == 2  # each broken asset named, not "assets are bad"
    assert {e["data"]["label"] for e in gate3_errors} == {"prop:a", "prop:b"}


def test_a_gate3_failure_blocks_the_whole_verdict(spec_and_plan, tmp_path):
    # FAIL must block DEPLOYED — a game referencing a missing model is broken.
    spec, plan = spec_and_plan
    manifest = {"prop:gone": _entry("generated", tmp_path / "nope.glb", {"passed": True})}
    report = run_gates(spec, plan, schema=SCHEMA, asset_manifest=manifest)
    assert report["verdict"] == "FAIL"


# --- the real farm, end to end -------------------------------------------


def test_a_real_mock_farm_run_passes_gate3(spec_and_plan, tmp_path):
    """Not a hand-built manifest: the actual resolver output."""
    from asset_farm.backends import MockBackend
    from asset_farm.pipeline import resolve_spec_assets

    spec, plan = spec_and_plan
    kit = REPO / "content" / "kits"
    if not kit.is_dir():
        pytest.skip("kit not present")
    manifest = resolve_spec_assets(
        spec, kit_dir=kit, cache_dir=tmp_path / "c", work_dir=tmp_path / "w",
        backend=MockBackend(),
    )
    report = run_gates(spec, plan, schema=SCHEMA, asset_manifest=manifest)
    assert _gate(report)["verdict"] == "PASS", [e for e in report["errors"] if e["gate"] == 3]
