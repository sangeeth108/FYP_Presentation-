from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

from agents.simulation_planner import plan_simulation
from asset_farm.pipeline import resolve_simulation_assets

REPO = Path(__file__).resolve().parents[3]


def _dog_village() -> dict:
    return plan_simulation(
        prompt="as a dog explore the village",
        simulation_id="sim_native_assets_1234abcd",
        seed=42,
        size_profile="small",
        target_platforms=["web", "desktop"],
        domain_constraints={},
        settings=SimpleNamespace(
            llm_enabled=False,
            llm_base_url="",
            llm_timeout_seconds=1,
        ),
    )[0]


def test_neutral_asset_resolution_uses_real_dog_and_measured_functional_structures(tmp_path):
    manifest = resolve_simulation_assets(
        _dog_village(),
        kit_dir=REPO / "content" / "kits",
        cache_dir=tmp_path / "cache",
        work_dir=tmp_path / "work",
    )
    dog = manifest["ent_controlled_actor"]
    assert dog["tier"] == "curated"
    assert dog["qa"]["passed"] is True
    assert dog["qa"]["capabilities"]["rigged"] is True
    assert dog["qa"]["capabilities"]["animated"] is True
    assert "animals" in dog["path"].replace("\\", "/")

    houses_and_doors = [
        entry for entity_id, entry in manifest.items() if entity_id.startswith("ent_house_")
    ]
    assert houses_and_doors
    assert all(entry["tier"] == "procedural" for entry in houses_and_doors)
    assert all(entry["qa"]["passed"] is True for entry in houses_and_doors)
    assert all(entry.get("curated_rel") is None for entry in houses_and_doors)

    square = manifest["ent_village_square"]
    assert square["tier"] == "procedural"
    assert square["qa"]["passed"] is True
    assert square["qa"]["bbox_center"] == [0.0, 0.0, 0.0]


def test_neutral_manifest_is_keyed_by_canonical_entity_id(tmp_path):
    spec = _dog_village()
    manifest = resolve_simulation_assets(
        spec,
        kit_dir=REPO / "content" / "kits",
        cache_dir=tmp_path / "cache",
        work_dir=tmp_path / "work",
    )
    assert set(manifest) == {entity["entity_id"] for entity in spec["entities"]}
    assert all(entry["entity_id"] == entity_id for entity_id, entry in manifest.items())


def test_scatter_species_get_their_own_assets(tmp_path):
    """Scatter species were skipped entirely: only `entities` were resolved.

    A jungle's authored species (trees, ferns, debris) therefore reached placement
    with no mesh at all — thousands of instances of nothing. One species resolves
    ONE asset that is then instanced many times, so this is cheap.
    """
    from asset_farm.pipeline import resolve_simulation_assets

    spec = {
        "meta": {"seed": 1},
        "entities": [],
        "scatter": [
            {
                "species_id": "spec_fern",
                "semantic_type": "fern cluster",
                "size_m": [0.8, 0.6, 0.8],
                "density_per_100m2": 12,
                "asset": {
                    "brief": "dense cluster of green ferns",
                    "category": "environment",
                    "requires_animation": False,
                    "preferred_source": "procedural",
                    "procedural_type": "semantic_box",
                },
            },
            {
                "species_id": "spec_tree",
                "semantic_type": "dipterocarp tree",
                "size_m": [8.0, 25.0, 8.0],
                "density_per_100m2": 4,
                "asset": {
                    "brief": "tall buttress-rooted tropical tree",
                    "category": "environment",
                    "requires_animation": False,
                    "preferred_source": "procedural",
                    "procedural_type": "semantic_box",
                },
            },
        ],
    }
    manifest = resolve_simulation_assets(
        spec, kit_dir=None, cache_dir=tmp_path / "cache", work_dir=tmp_path / "work"
    )

    assert set(manifest) == {"spec_fern", "spec_tree"}
    assert all(entry["tier"] != "unresolved" for entry in manifest.values())
    # Distinct sizes must yield distinct meshes, not one shared box.
    assert manifest["spec_fern"]["path"] != manifest["spec_tree"]["path"]


def test_a_species_without_size_still_resolves(tmp_path):
    """size_m is optional; a missing one must degrade, not fail the build."""
    from asset_farm.pipeline import resolve_simulation_assets

    spec = {
        "meta": {"seed": 1},
        "entities": [],
        "scatter": [
            {
                "species_id": "spec_rubble",
                "semantic_type": "broken masonry",
                "density_per_100m2": 6,
                "asset": {
                    "brief": "scattered broken masonry",
                    "category": "environment",
                    "requires_animation": False,
                    "preferred_source": "procedural",
                    "procedural_type": "semantic_box",
                },
            }
        ],
    }
    manifest = resolve_simulation_assets(
        spec, kit_dir=None, cache_dir=tmp_path / "cache", work_dir=tmp_path / "work"
    )
    assert manifest["spec_rubble"]["tier"] != "unresolved"


def _person(entity_id: str, brief: str) -> dict:
    return {
        "entity_id": entity_id,
        "name": entity_id,
        "capabilities": [],
        "asset": {
            "brief": brief,
            "category": "character",
            "requires_animation": False,
            "preferred_source": "either",
        },
    }


def test_different_people_in_one_world_get_different_bodies(tmp_path):
    """A station guard and a tea vendor shipped as identical twins.

    Measured rather than guessed at: every brief for a person scores far below the
    0.85 curated floor -- 0.548 at best across Man, Woman and Farmer -- and the
    keyword tier only fires when a brief literally contains a library word, so
    "farmer" and "woman" match while "station guard" and "tea vendor" do not.
    Nearly every person therefore arrives via `default_character_model`, which
    returns one fixed body.

    Substituting there overrides no evidence: the default is reached precisely
    because no tier could judge fit, so Man, Woman and Farmer are equally
    unmatched to a station guard.
    """
    spec = {
        "entities": [
            _person("ent_guard", "a station guard in uniform watching the platform edge"),
            _person("ent_vendor", "a tea vendor beside the ticket window pouring chai"),
            _person("ent_porter", "a porter carrying luggage along the platform"),
        ]
    }
    manifest = resolve_simulation_assets(
        spec, kit_dir=REPO / "content" / "kits", cache_dir=tmp_path / "cache"
    )
    bodies = [manifest[e["entity_id"]]["curated_rel"] for e in spec["entities"]]
    assert len(set(bodies)) == 3, bodies
    # Generic before specific: Farmer wears work clothes and a hat, so it is the
    # last ordinary body reached rather than the second.
    assert bodies[0].endswith("Man.glb")
    assert bodies[1].endswith("Woman.glb")
    assert bodies[2].endswith("Farmer.glb")


def test_more_people_than_bodies_repeats_rather_than_inventing(tmp_path):
    """Three ordinary humans are owned. A fourth person has to repeat one.

    Reaching outside the ordinary set would put a skeleton on the platform, which
    this repository already records as a real defect the vision critic caught.
    """
    spec = {
        "entities": [
            _person("ent_a", "a station guard in uniform watching the platform edge"),
            _person("ent_b", "a tea vendor beside the ticket window pouring chai"),
            _person("ent_c", "a porter carrying luggage along the platform"),
            _person("ent_d", "a ticket inspector checking passes near the barrier"),
        ]
    }
    manifest = resolve_simulation_assets(
        spec, kit_dir=REPO / "content" / "kits", cache_dir=tmp_path / "cache"
    )
    bodies = [manifest[e["entity_id"]]["curated_rel"] for e in spec["entities"]]
    assert all("characters/" in body for body in bodies)
    assert not any("Skeleton" in body for body in bodies)
    assert bodies[3] in bodies[:3]


def test_body_assignment_is_stable_across_runs(tmp_path):
    """Rebuilding a world must not reshuffle who is who.

    The first attempt picked from a hash of the brief, which was stable but
    ignored the preference order and dressed a tea vendor as a farmer while the
    plain woman went unused. Taking the first free body in order is stable too,
    with no randomness to seed.
    """
    spec = {
        "entities": [
            _person("ent_a", "a station guard in uniform watching the platform edge"),
            _person("ent_b", "a tea vendor beside the ticket window pouring chai"),
        ]
    }
    first = resolve_simulation_assets(
        spec, kit_dir=REPO / "content" / "kits", cache_dir=tmp_path / "one"
    )
    second = resolve_simulation_assets(
        spec, kit_dir=REPO / "content" / "kits", cache_dir=tmp_path / "two"
    )
    assert [first[e["entity_id"]]["curated_rel"] for e in spec["entities"]] == [
        second[e["entity_id"]]["curated_rel"] for e in spec["entities"]
    ]


def test_an_animal_is_not_handed_a_human_body(tmp_path):
    """The variety rule covers ordinary humans only.

    Wolf is not a substitute for a dog, and a person is not a substitute for
    either, so the animal path is left exactly as it was.
    """
    spec = {
        "entities": [
            _person("ent_guard", "a station guard in uniform watching the platform edge"),
            _person("ent_dog", "a scruffy stray dog asleep on the platform"),
        ]
    }
    manifest = resolve_simulation_assets(
        spec, kit_dir=REPO / "content" / "kits", cache_dir=tmp_path / "cache"
    )
    assert "characters/" in manifest["ent_guard"]["curated_rel"]
    assert "animals/" in manifest["ent_dog"]["curated_rel"]
