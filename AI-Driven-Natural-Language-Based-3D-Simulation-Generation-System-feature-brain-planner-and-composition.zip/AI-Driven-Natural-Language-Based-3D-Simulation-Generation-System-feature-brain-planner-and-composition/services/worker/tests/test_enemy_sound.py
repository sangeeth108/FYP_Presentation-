"""Enemy sound: chosen by the MODEL, triggered by the ACTIVITY.

The contract mirrors the model kit exactly — a sound set is curated data, the
writer wires it onto the vetted AI template, and a missing/partial kit degrades
to silence rather than to a broken build.
"""

import json
from pathlib import Path

import pytest
from asset_farm.brief import AssetBrief
from asset_farm.qa_audio import qa_audio
from godot_client.asset_kit import (
    SOUND_SETS,
    enemy_sounds,
    sound_family,
    sound_files_exist,
)
from godot_client.project_writer import write_project
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan

REPO = Path(__file__).resolve().parents[3]
KIT = REPO / "content" / "kits"  # curated root (one folder per pack)
SFX = REPO / "content" / "kits" / "catsfx"
GOLDEN_SPEC = REPO / "contracts" / "examples" / "golden_game.spec.json"


@pytest.fixture(scope="module")
def golden_plan():
    return to_level_plan(run_pcg(json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))))


def test_the_model_picks_the_sound_set():
    assert sound_family("characters/Skeleton_Minion.glb") == "skeleton"
    assert sound_family("characters/Skeleton_Mage.glb") == "skeleton"


def test_an_unknown_or_generated_model_still_gets_sound_not_silence():
    # A TRELLIS-generated mesh has no family: it must fall back, not go silent.
    assert sound_family("generated/a1b2c3.glb") == "skeleton"
    assert sound_family(None) == "skeleton"
    assert enemy_sounds(None)["attack"]


def test_every_activity_the_ai_performs_has_clips():
    # If the AI template grows an activity, this catches the missing sound set.
    for family, activities in SOUND_SETS.items():
        assert set(activities) == {"attack", "hit", "death", "step"}, family
        for clips in activities.values():
            assert clips, family


def test_a_skeleton_dies_as_bones_not_as_flesh():
    # What you hear must match what you see — the point of model-chosen sound.
    assert all("clack" in c for c in enemy_sounds("characters/Skeleton_Warrior.glb")["death"])


@pytest.mark.skipif(not SFX.is_dir(), reason="sfx kit not present")
def test_every_curated_clip_exists_and_passes_the_same_qa_gate_as_generated_audio():
    assert sound_files_exist(SFX)
    for clips in SOUND_SETS.values():
        for activity, names in clips.items():
            for name in names:
                report = qa_audio(SFX / name, AssetBrief(name, "audio_sfx"))
                assert report.passed, f"{activity}/{name}: {[e.code for e in report.errors]}"


def test_a_missing_clip_means_no_sound_kit_rather_than_a_broken_build(tmp_path):
    # Half a kit is not a kit: one absent file disables audio wholesale.
    partial = tmp_path / "sfx"
    partial.mkdir()
    (partial / "swish_1.wav").write_bytes(b"RIFF")
    assert not sound_files_exist(partial)


@pytest.mark.skipif(not (KIT.is_dir() and SFX.is_dir()), reason="kits not present")
def test_writer_wires_the_banks_and_copies_the_clips(golden_plan, tmp_path):
    write_project(
        golden_plan,
        "T",
        tmp_path,
        templates_dir=REPO / "engine" / "templates",
        kit_dir=KIT,
        sfx_dir=SFX,
    )
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")

    # Typed-array form Godot actually accepts (verified in a headless build).
    assert "sfx_attack = Array[AudioStream]([ExtResource(" in scene
    for activity in ("attack", "hit", "death", "step"):
        assert f"sfx_{activity} = Array[AudioStream]([ExtResource(" in scene
    assert '[ext_resource type="AudioStream" path="res://sfx/swish_1.wav"' in scene

    # Named, editable audio nodes — the downloaded project must be tunable.
    assert '[node name="Sfx" type="AudioStreamPlayer3D"' in scene
    assert '[node name="SfxSteps" type="AudioStreamPlayer3D"' in scene

    # Every clip the USED family references is really shipped. Only the families a
    # game actually wears get copied in — the golden game has no animals, so the
    # animal set's clips must NOT be dragged into its build.
    used = enemy_sounds("kaykit/characters/Skeleton_Minion.glb")
    for name in {n for v in used.values() for n in v}:
        assert (tmp_path / "sfx" / name).is_file(), name
    assert not (tmp_path / "sfx" / "hit_wet_01.wav").is_file()  # animal-only, unused here


@pytest.mark.skipif(not KIT.is_dir(), reason="kit not present")
def test_without_an_sfx_dir_the_build_is_silent_and_clean(golden_plan, tmp_path):
    write_project(
        golden_plan, "T", tmp_path, templates_dir=REPO / "engine" / "templates", kit_dir=KIT
    )
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    assert "sfx_attack" not in scene
    assert "AudioStreamPlayer3D" not in scene
    assert 'type="AudioStream"' not in scene
    assert not (tmp_path / "sfx").exists()


@pytest.mark.skipif(not (KIT.is_dir() and SFX.is_dir()), reason="kits not present")
def test_sound_follows_the_model_actually_worn_not_the_writers_default(golden_plan, tmp_path):
    """A dog must not die to the skeleton's bone-clatter.

    Regression: the writer wore the farm's semantic pick (a Shiba Inu) but read
    its sound family from its OWN index-cycle default (a skeleton), so the dog
    died to `clack`. The farm decides the body; every decision hanging off the
    body — the sound family above all — must read the body that is actually worn.
    Caught by the headless probe, not by any unit test.
    """
    dog = KIT / "quaternius" / "animals" / "ShibaInu.glb"
    if not dog.is_file():
        pytest.skip("animal kit not present")
    plan_enemies = [e for e in golden_plan["entities"] if e["kind"] == "enemy"]
    assert plan_enemies, "golden plan should place enemies"

    out = tmp_path / "proj"
    write_project(
        golden_plan, "T", out,
        templates_dir=REPO / "engine" / "templates",
        kit_dir=KIT, sfx_dir=SFX,
        asset_models={f"enemy:{e['source_id']}": dog for e in plan_enemies},
    )
    scene = (out / "main.tscn").read_text(encoding="utf-8")
    assert "ShibaInu.glb" in scene  # it wears the dog...
    assert "hit_wet_01.wav" in scene  # ...so it dies wet,
    assert "clack_1.wav" not in scene  # NOT as a bag of bones
