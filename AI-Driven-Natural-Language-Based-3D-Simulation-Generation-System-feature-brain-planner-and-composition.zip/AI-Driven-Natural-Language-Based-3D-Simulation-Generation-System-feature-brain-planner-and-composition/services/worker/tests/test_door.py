import json
import re
from pathlib import Path

import pytest
from godot_client.project_writer import write_project
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan

REPO = Path(__file__).resolve().parents[3]
GOLDEN_SPEC = REPO / "contracts" / "examples" / "golden_game.spec.json"
TEMPLATES_DIR = REPO / "engine" / "templates"


@pytest.fixture(scope="module")
def scene(tmp_path_factory):
    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    plan = to_level_plan(run_pcg(spec))
    out = tmp_path_factory.mktemp("proj")
    write_project(plan, "T", out, templates_dir=TEMPLATES_DIR, player_config=spec["player"])
    return plan, (out / "main.tscn").read_text(encoding="utf-8"), out


def test_door_template_is_copied(scene):
    _, _, out = scene
    assert (out / "templates" / "interactables" / "door_hinged.gd").is_file()


def test_key_zone_gates_the_win_zone(scene):
    _, text, _ = scene
    win = re.search(r'\[node name="WinZone"[^\[]+', text).group(0)
    assert 'requires_objective = "reach_key"' in win
    key = re.search(r'\[node name="KeyZone"[^\[]+', text).group(0)
    assert 'objective_id = "reach_key"' in key
    assert "is_win_condition = false" in key


def test_locked_door_exists_on_exit_room_boundary(scene):
    plan, text, _ = scene
    door = re.search(r'\[node name="LockedDoor"[^\[]+', text).group(0)
    assert "locked = true" in door
    assert 'unlocked_by_objective = "reach_key"' in door

    exit_id = next(z["zone_id"] for z in plan["zones"] if z["kind"] == "exit")
    exit_room = next(r for r in plan["rooms"] if r["zone_id"] == exit_id)
    ox, _, oz = (
        float(v)
        for v in re.search(r"Transform3D\([^)]+, ([-\d.]+), ([-\d.]+), ([-\d.]+)\)", door).groups()
    )
    edges = (
        exit_room["x"],
        exit_room["x"] + exit_room["width"],
        exit_room["z"],
        exit_room["z"] + exit_room["depth"],
    )
    # The hinge origin sits on one exit-room edge line (span offset is on the other axis).
    assert any(abs(ox - e) < 1e-6 or abs(oz - e) < 1e-6 for e in edges)


def test_declarative_signal_connections(scene):
    _, text, _ = scene
    assert (
        '[connection signal="objective_completed" from="KeyZone" '
        'to="LockedDoor" method="_on_objective_completed"]' in text
    )
    assert (
        '[connection signal="objective_completed" from="KeyZone" '
        'to="WinZone" method="on_required_objective_completed"]' in text
    )


def test_lose_flow_and_hud_are_wired(scene):
    _, text, out = scene
    assert (out / "templates" / "objectives" / "player_death.gd").is_file()
    assert (out / "templates" / "ui" / "hud_basic.gd").is_file()

    assert '[node name="FailStatePlayerDeath" type="Node" parent="."]' in text
    hud = re.search(r'\[node name="Hud" type="CanvasLayer"[^\[]+', text).group(0)
    assert "max_health = 5" in hud  # golden spec player.health
    assert (
        '[connection signal="died" from="Player" '
        'to="FailStatePlayerDeath" method="_on_player_died"]' in text
    )
    assert (
        '[connection signal="health_changed" from="Player" '
        'to="Hud" method="_on_health_changed"]' in text
    )
    assert (
        '[connection signal="objective_completed" from="KeyZone" '
        'to="Hud" method="on_objective_completed"]' in text
    )
