"""The in-process real generation backend (SDXL -> TripoSR -> GLB).

The GPU stages (SDXL, TripoSR) can't run in CI, so these pin the parts that CAN
be tested deterministically without a GPU: the module imports without torch, the
backend REFUSES the kinds it must never generate (audio, characters — a rig-less
statue is wrong for a character, ADR-0005), and the mesh post-processing
(decimation to budget, Y-up normalisation, GLB export) is correct. The full
SDXL->TripoSR->GLB->QA path is verified live on the GPU box, not here.
"""

import pytest

# The mesh post-processing needs numpy + trimesh; the minimal CI job has neither,
# so skip the whole module cleanly rather than error at collection.
np = pytest.importorskip("numpy")
trimesh = pytest.importorskip("trimesh")

from asset_farm import backends_local  # noqa: E402
from asset_farm.backends_gpu import GenerationBackendError  # noqa: E402
from asset_farm.brief import AssetBrief  # noqa: E402


def test_module_imports_and_constructs_without_the_gpu_stack():
    # A curated-only deploy (and CI) must import + construct this without torch or
    # diffusers loaded: heavy deps are imported lazily inside the methods only.
    assert backends_local.LocalGenBackend().component == "triposr"


def test_it_refuses_audio_and_characters(tmp_path):
    be = backends_local.LocalGenBackend()
    with pytest.raises(GenerationBackendError):
        be.generate(AssetBrief(brief="a barking dog sound", category="audio_sfx"), tmp_path)
    # A character must resolve to a curated RIGGED body, never a generated statue.
    with pytest.raises(GenerationBackendError):
        be.generate(AssetBrief(brief="a scruffy village dog", category="character"), tmp_path)


def test_generatable_categories_are_mesh_only():
    assert frozenset({"prop", "building_module", "foliage"}) == backends_local._MESH_CATEGORIES


def test_seed_is_stable_per_brief():
    b = AssetBrief(brief="a wooden barrel", category="prop")
    assert backends_local._seed(b) == backends_local._seed(b)  # rule 14: reproducible
    other = AssetBrief(brief="a stone well", category="prop")
    assert backends_local._seed(b) != backends_local._seed(other)


def test_explicit_negative_constraints_are_forwarded():
    brief = "one standalone wooden door leaf, no wall and without surrounding building"
    constraints = backends_local._negative_constraints(brief)
    assert "wall" in constraints
    assert "surrounding building" in constraints
    prompt = backends_local._negative_prompt(brief)
    assert "wall" in prompt and "surrounding building" in prompt


def test_subject_gate_counts_only_significant_components():
    alpha = np.zeros((100, 100), dtype=np.float32)
    alpha[10:40, 10:40] = 1.0
    alpha[70:72, 70:72] = 1.0  # insignificant rembg speck
    assert backends_local._significant_foreground_components(alpha) == 1
    alpha[55:85, 55:85] = 1.0
    assert backends_local._significant_foreground_components(alpha) == 2


def test_subject_gate_rejects_blank_or_malformed_alpha():
    assert backends_local._significant_foreground_components(np.zeros((32, 32))) == 0
    assert backends_local._significant_foreground_components(np.zeros((8,))) == 0


def test_generation_retries_rejected_concepts_before_mesh_lifting(tmp_path, monkeypatch):
    backend = backends_local.LocalGenBackend(require_concept_vision=False)
    attempts: list[int] = []
    mesh_inputs: list[str] = []

    def fake_image(_brief, out_path, seed_offset=0):
        attempts.append(seed_offset)
        out_path.write_bytes(b"image")
        return out_path

    def fake_remove(image_path, out_path):
        if image_path.name.endswith("_0.png"):
            raise GenerationBackendError("multiple subjects")
        out_path.write_bytes(b"isolated")
        return out_path

    def fake_mesh(image_path, _brief, out_path):
        mesh_inputs.append(image_path.name)
        out_path.write_bytes(b"glb")
        return out_path

    monkeypatch.setattr(backend, "_sdxl_image", fake_image)
    monkeypatch.setattr(backend, "_remove_background", fake_remove)
    monkeypatch.setattr(backend, "_image_to_mesh", fake_mesh)
    result = backend.generate(AssetBrief(brief="one wooden door", category="prop"), tmp_path)

    assert attempts == [0, 1]
    assert mesh_inputs == [f"{result.path.stem}_candidate_1_nobg.png"]


def test_real_local_generation_fails_closed_without_visual_qualification(tmp_path):
    backend = backends_local.LocalGenBackend()
    with pytest.raises(GenerationBackendError, match="concept vision"):
        backend.generate(AssetBrief(brief="one wooden door", category="prop"), tmp_path)


def test_rejected_vision_candidate_is_never_lifted_to_a_mesh(tmp_path, monkeypatch):
    from asset_farm import concept_vision

    backend = backends_local.LocalGenBackend(
        concept_vision_base_url="http://vision",
        concept_vision_model="vision:1",
    )
    attempts: list[int] = []
    mesh_calls: list[str] = []

    def fake_image(_brief, out_path, seed_offset=0):
        attempts.append(seed_offset)
        out_path.write_bytes(b"image")
        return out_path

    def fake_remove(_image_path, out_path):
        out_path.write_bytes(b"isolated")
        return out_path

    def reject(**_kwargs):
        raise GenerationBackendError("semantic mismatch")

    def fake_mesh(image_path, _brief, out_path):
        mesh_calls.append(image_path.name)
        return out_path

    monkeypatch.setattr(backend, "_sdxl_image", fake_image)
    monkeypatch.setattr(backend, "_remove_background", fake_remove)
    monkeypatch.setattr(backend, "_image_to_mesh", fake_mesh)
    monkeypatch.setattr(concept_vision, "validate_concept_image", reject)

    with pytest.raises(GenerationBackendError, match="semantic mismatch"):
        backend.generate(AssetBrief(brief="one wooden door", category="prop"), tmp_path)
    assert attempts == [0, 1, 2]
    assert mesh_calls == []


# --- mesh post-processing (pure numpy/trimesh, no GPU) ---------------------


def _ico(subdiv: int):
    m = trimesh.creation.icosphere(subdivisions=subdiv)
    verts = np.asarray(m.vertices, dtype=np.float64)
    faces = np.asarray(m.faces, dtype=np.int64)
    colors = np.tile(np.array([200, 100, 50], np.uint8), (len(verts), 1))
    return verts, faces, colors


def test_decimation_lands_at_or_under_budget():
    verts, faces, colors = _ico(4)  # ~20480 faces
    assert len(faces) > 2000
    v, f, c = backends_local._decimate(verts, faces, colors, tri_budget=2000)
    assert len(f) <= 2000  # the contract QA enforces
    assert len(f) > 0
    assert c is not None and len(c) == len(v)  # colours carried onto the new verts


def test_decimation_is_a_noop_under_budget():
    verts, faces, colors = _ico(1)  # ~320 faces, already under budget
    v, f, c = backends_local._decimate(verts, faces, colors, tri_budget=2000)
    assert len(f) == len(faces)  # untouched


def test_normalise_puts_the_base_on_the_ground_and_scales_sanely():
    verts = np.array([[0, 0, 0], [10, 20, 30], [-5, -5, -5]], dtype=np.float64)
    v = backends_local._normalise_for_godot(verts)
    # base sits on y=0 (Godot is Y-up); tallest dimension ~1.5 m
    assert v[:, 1].min() == pytest.approx(0.0, abs=1e-6)
    extent = (v.max(axis=0) - v.min(axis=0)).max()
    assert extent == pytest.approx(1.5, abs=1e-6)
    # centred in X/Z
    assert (v[:, 0].min() + v[:, 0].max()) == pytest.approx(0.0, abs=1e-6)
    assert (v[:, 2].min() + v[:, 2].max()) == pytest.approx(0.0, abs=1e-6)


def test_export_writes_a_loadable_vertex_coloured_glb(tmp_path):
    verts, faces, colors = _ico(2)
    out = tmp_path / "m.glb"
    backends_local._export_glb(verts, faces, colors, out)
    assert out.is_file() and out.stat().st_size > 0
    loaded = trimesh.load(out)
    geoms = list(loaded.geometry.values()) if hasattr(loaded, "geometry") else [loaded]
    assert sum(len(g.faces) for g in geoms) == len(faces)
