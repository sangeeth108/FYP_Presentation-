from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess

import pytest
from godot_client.project_writer import ProjectWriterError
from godot_client.simulation_project_writer import _local_transform, write_simulation_project


def test_parent_world_transform_round_trips_with_godot_yaw_convention():
    parent = {
        "entity_id": "parent",
        "transform": {"position_m": [10.0, 3.0, 20.0], "rotation_y_degrees": 90.0},
    }
    child = {
        "entity_id": "child",
        "parent_id": "parent",
        "transform": {"position_m": [6.0, 1.1, 20.0], "rotation_y_degrees": 90.0},
    }
    local_position, local_yaw = _local_transform(child, {"parent": parent, "child": child})
    assert local_position == pytest.approx([0.0, -1.9, -4.0])
    assert local_yaw == pytest.approx(0.0)


def _fixture(asset_path):
    asset_path.write_bytes(b"glTF-binary-test-fixture")
    digest = hashlib.sha256(asset_path.read_bytes()).hexdigest()
    spec = {
        "meta": {
            "simulation_id": "sim_native_writer",
            "title": "Village process study",
        },
        "entities": [
            {
                "entity_id": "ent_controlled_actor",
                "role": "controlled_agent",
                "physical": {"mass_kg": 20.0},
                "capabilities": ["locomotion", "animal"],
            },
            {
                "entity_id": "ent_village_door",
                "role": "functional_object",
                "physical": {"mass_kg": 0.0},
                "capabilities": ["openable"],
            },
        ],
        "agents": [
            {
                "entity_id": "ent_controlled_actor",
                "controller": "user",
                "behaviour": {"mode": "direct_control"},
            }
        ],
    }
    graph = {
        "graph_id": "behavior:ent_village_door:openable",
        "entity_id": "ent_village_door",
        "capability_id": "openable",
        "pack_id": "serendib.core_runtime",
        "pack_version": "1.0.0",
        "runtime_binding": "door_hinged",
        "initial_state": "closed",
        "states": [
            {
                "state_id": "closed",
                "observable_properties": {
                    "open": False,
                    "collision_enabled": True,
                },
            },
            {
                "state_id": "open",
                "observable_properties": {
                    "open": True,
                    "collision_enabled": False,
                },
            },
        ],
        "transitions": [
            {
                "transition_id": "open",
                "from_state": "closed",
                "to_state": "open",
                "trigger": "interact",
                "guard": {"kind": "always", "parameters": {}},
                "effects": [],
                "duration_ms": 0,
            }
        ],
        "probes": [
            {
                "probe_id": "probe_open",
                "triggers": ["interact"],
                "expected_state": "open",
                "expected_properties": {
                    "open": True,
                    "collision_enabled": False,
                },
                "requirement_ids": ["req_door"],
            }
        ],
        "deterministic": True,
    }
    plan = {
        "schema_version": "1.0.0",
        "simulation_id": "sim_native_writer",
        "seed": 11,
        "world_bounds": {"min": [-50, 0, -50], "max": [50, 20, 50]},
        "zones": [
            {
                "zone_id": "main",
                "semantic_type": "village",
                "bounds": {"min": [-45, 0, -45], "max": [45, 20, 45]},
                "connected_to": [],
            }
        ],
        "entities": [
            {
                "entity_id": "ent_controlled_actor",
                "semantic_type": "dog",
                "zone_id": "main",
                "asset_ref": "player:main",
                "measurement_status": "MEASURED",
                "dimensions_m": [0.8, 1.2, 1.4],
                "transform": {
                    "position_m": [2.0, 0.6, 3.0],
                    "rotation_y_degrees": 0.0,
                    "scale": [1.0, 1.0, 1.0],
                },
                "world_aabb": {"min": [1.6, 0, 2.3], "max": [2.4, 1.2, 3.7]},
                "support": {
                    "type": "terrain",
                    "target_id": None,
                    "contact_y_m": 0,
                },
                "interaction_clearance_m": 1.5,
                "dynamic": True,
                "parent_id": None,
            },
            {
                "entity_id": "ent_village_door",
                "semantic_type": "door",
                "zone_id": "main",
                "asset_ref": "prop:village_door",
                "measurement_status": "MEASURED",
                "dimensions_m": [1.0, 2.0, 0.2],
                "transform": {
                    "position_m": [10.0, 1.0, 8.0],
                    "rotation_y_degrees": 90.0,
                    "scale": [1.0, 1.0, 1.0],
                },
                "world_aabb": {"min": [9.5, 0, 7.9], "max": [10.5, 2, 8.1]},
                "support": {
                    "type": "terrain",
                    "target_id": None,
                    "contact_y_m": 0,
                },
                "interaction_clearance_m": 1.5,
                "dynamic": False,
                "parent_id": None,
            },
        ],
        "behaviours": [graph],
        "relationships": [],
        "navigation": {"regions": ["main"], "required_reachability": []},
        "constraint_summary": {
            "hard_constraints": [],
            "soft_relaxations": [],
            "unplaced_entities": [],
        },
    }
    descriptors = {}
    for entity_id, shape in (
        ("ent_controlled_actor", "capsule"),
        ("ent_village_door", "box"),
    ):
        descriptors[entity_id] = {
            "entity_id": entity_id,
            "content_hash": digest,
            "source": {"uri": str(asset_path)},
            "measurement": {"status": "MEASURED"},
            "collision": {"shape": shape},
            "normalization_scale": [1.0, 1.0, 1.0],
        }
    return spec, plan, descriptors


def test_native_writer_consumes_world_plan_transforms_and_behavior_data(tmp_path):
    spec, plan, descriptors = _fixture(tmp_path / "model.glb")
    output = tmp_path / "project"
    write_simulation_project(spec, plan, descriptors, output)
    scene = (output / "main.tscn").read_text(encoding="utf-8")
    project = (output / "project.godot").read_text(encoding="utf-8")

    assert 'metadata/entity_id = "ent_controlled_actor"' in scene
    assert 'metadata/role = "controlled_agent"' in scene
    assert "2, 0.6, 3" in scene
    assert 'metadata/entity_id = "ent_village_door"' in scene
    assert 'metadata/role = "functional_object"' in scene
    assert '"capability_id":"openable"' in scene.replace('\\"', '"')
    assert '[node name="VisualPivot" type="Node3D" parent="EntVillageDoor"]' in scene
    assert 'parent="EntVillageDoor/VisualPivot"' in scene
    assert "CastleGate" not in scene
    assert "WinZone" not in scene
    assert 'config/name="Village process study"' in project
    assert 'renderer/rendering_method="gl_compatibility"' in project
    assert (output / "runtime" / "simulation_runtime.gd").is_file()
    assert (output / "world_plan.json").is_file()
    assert len(list((output / "assets").glob("*.glb"))) == 1

    defined = set(
        re.findall(r'\[sub_resource type="[^"]+" id="([^"]+)"\]', scene)
    )
    referenced = set(re.findall(r'SubResource\("([^"]+)"\)', scene))
    assert referenced <= defined
    load_steps = int(re.search(r"load_steps=(\d+)", scene).group(1))
    assert load_steps == (
        scene.count("[ext_resource ") + scene.count("[sub_resource ") + 1
    )


def test_the_ground_is_synthesised_rather_than_left_untextured(tmp_path):
    """The ground carried no material at all and drew as default white.

    It is the largest surface in every frame, so it is the one that decided
    whether a world looked built or unfinished.
    """
    spec, plan, descriptors = _fixture(tmp_path / "ground.glb")
    spec["environment"] = {"terrain": "village lane", "terrain_surface": "soil"}
    output = tmp_path / "project"
    write_simulation_project(spec, plan, descriptors, output)
    scene = (output / "main.tscn").read_text(encoding="utf-8")

    # The mesh references a material, and that material is noise-textured rather
    # than a flat colour.
    assert 'material = SubResource("SurfaceGround")' in scene
    assert '[sub_resource type="StandardMaterial3D" id="SurfaceGround"]' in scene
    assert '[sub_resource type="NoiseTexture2D" id="SurfaceNoiseTex"]' in scene
    assert "uv1_triplanar = true" in scene

    # The scene stays internally consistent: every SubResource resolves, and
    # load_steps still counts what is actually there.
    defined = set(re.findall(r'\[sub_resource type="[^"]+" id="([^"]+)"\]', scene))
    referenced = set(re.findall(r'SubResource\("([^"]+)"\)', scene))
    assert referenced <= defined
    load_steps = int(re.search(r"load_steps=(\d+)", scene).group(1))
    assert load_steps == scene.count("[ext_resource ") + scene.count("[sub_resource ") + 1


def test_a_named_surface_family_changes_what_the_ground_looks_like(tmp_path):
    spec, plan, descriptors = _fixture(tmp_path / "family.glb")
    scenes = {}
    for family in ("snow", "soil"):
        spec["environment"] = {"terrain": "a place", "terrain_surface": family}
        output = tmp_path / family
        write_simulation_project(spec, plan, descriptors, output)
        scenes[family] = (output / "main.tscn").read_text(encoding="utf-8")
    assert scenes["snow"] != scenes["soil"], "the named family must reach the render"


def test_native_writer_is_byte_stable(tmp_path):
    spec, plan, descriptors = _fixture(tmp_path / "stable.glb")
    first, second = tmp_path / "first", tmp_path / "second"
    write_simulation_project(spec, plan, descriptors, first)
    write_simulation_project(spec, plan, descriptors, second)
    for filename in ("project.godot", "main.tscn", "world_plan.json"):
        assert (first / filename).read_bytes() == (second / filename).read_bytes()


def test_native_writer_rejects_changed_or_unmeasured_assets(tmp_path):
    spec, plan, descriptors = _fixture(tmp_path / "unsafe.glb")
    descriptors["ent_village_door"]["measurement"]["status"] = "UNAVAILABLE"
    with pytest.raises(ProjectWriterError) as error:
        write_simulation_project(spec, plan, descriptors, tmp_path / "unmeasured")
    assert error.value.code == "world_plan_asset_not_measured"

    descriptors["ent_village_door"]["measurement"]["status"] = "MEASURED"
    (tmp_path / "unsafe.glb").write_bytes(b"changed-after-measurement")
    with pytest.raises(ProjectWriterError) as error:
        write_simulation_project(spec, plan, descriptors, tmp_path / "changed")
    assert error.value.code == "world_plan_asset_hash_mismatch"


def test_native_writer_never_accepts_model_generated_runtime_code(tmp_path):
    spec, plan, descriptors = _fixture(tmp_path / "code.glb")
    plan["behaviours"][0]["runtime_binding"] = "res://uploaded/evil.gd"
    output = tmp_path / "code_project"
    write_simulation_project(spec, plan, descriptors, output)
    scene = (output / "main.tscn").read_text(encoding="utf-8")
    assert "evil.gd" not in scene
    runtime = json.loads((output / "world_plan.json").read_text(encoding="utf-8"))
    assert runtime["behaviours"][0]["runtime_binding"] == "res://uploaded/evil.gd"
    # The exact set, not a subset. An added script must be a reviewed decision
    # rather than something that arrived with a feature: this list is the whole
    # of what can execute in a generated project. `xr_runtime.gd` was added
    # deliberately when immersive delivery was implemented, and ships in every
    # project because the flat and immersive builds are one artifact.
    # `idle_pose.gd` was added when dialogue landed: only the player controller
    # and the agent script animated anything, so every other rigged body stood
    # in its exported bind pose. It plays one clip found by name and does nothing
    # else, and is attached only to rigged entities neither of those two drive.
    # `terrain_field.gd` was added when the ground stopped being a flat slab. It
    # reads the planned heightfield out of world_plan.json -- the same lineage file
    # the scatter fields read -- and builds the ground mesh plus its collider from
    # it. It generates nothing: a second noise implementation here would decide
    # where the ground is while Python decided where every prop sits, and the first
    # divergence would leave the whole world floating or buried.
    assert set(path.name for path in (output / "runtime").iterdir()) == {
        "simulation_runtime.gd",
        "simulation_controller.gd",
        "simulation_agent.gd",
        "capability_state_machine.gd",
        "scatter_field.gd",
        "xr_runtime.gd",
        "idle_pose.gd",
        "terrain_field.gd",
    }


def test_native_writer_compiles_scheduled_agents_to_reviewed_navigation_runtime(tmp_path):
    spec, plan, descriptors = _fixture(tmp_path / "agent.glb")
    spec["entities"].append(
        {
            "entity_id": "ent_village_cow",
            "role": "village_resident",
            "physical": {"mass_kg": 120.0},
            "capabilities": ["locomotion", "animal"],
        }
    )
    spec["agents"].append(
        {
            "entity_id": "ent_village_cow",
            "controller": "schedule",
            "behaviour": {"mode": "village_wander"},
        }
    )
    resident = json.loads(json.dumps(plan["entities"][0]))
    resident.update(
        {
            "entity_id": "ent_village_cow",
            "semantic_type": "cow",
            "asset_ref": "test:cow",
            "transform": {
                "position_m": [-5.0, 0.6, -5.0],
                "rotation_y_degrees": 0.0,
                "scale": [1.0, 1.0, 1.0],
            },
            "world_aabb": {"min": [-5.4, 0, -5.7], "max": [-4.6, 1.2, -4.3]},
        }
    )
    plan["entities"].append(resident)
    descriptors["ent_village_cow"] = {
        **descriptors["ent_controlled_actor"],
        "entity_id": "ent_village_cow",
    }
    output = tmp_path / "scheduled"
    write_simulation_project(spec, plan, descriptors, output)
    scene = (output / "main.tscn").read_text(encoding="utf-8")
    assert '[node name="EntVillageCow" type="CharacterBody3D"' in scene
    assert 'script = ExtResource("4_agent")' in scene
    assert (
        '[node name="NavigationAgent3D" type="NavigationAgent3D" '
        'parent="EntVillageCow"]' in scene
    )


def _with_scatter(tmp_path, *, measured_species: bool):
    """The fixture plus one scatter species, measured or not."""
    spec, plan, descriptors = _fixture(tmp_path / "model.glb")
    spec["scatter"] = [
        {
            "species_id": "spc_fern",
            "semantic_type": "understorey_tree_fern",
            "asset": {"brief": "tree fern"},
            "density_per_100m2": 4.0,
            "size_m": [1.4, 2.2, 1.4],
        }
    ]
    plan["schema_version"] = "1.1.0"
    plan["scatter"] = {
        "instances": [
            {
                "species_id": "spc_fern",
                "position_m": [1.0, 0.0, 2.0],
                "yaw_degrees": 45.0,
                "scale": 1.1,
            },
            {
                "species_id": "spc_fern",
                "position_m": [4.0, 0.0, 6.0],
                "yaw_degrees": 300.0,
                "scale": 0.9,
            },
        ],
        "species": [{"species_id": "spc_fern", "placed_instances": 2}],
    }
    if measured_species:
        species_asset = tmp_path / "fern.glb"
        species_asset.write_bytes(b"glTF-binary-fern-fixture")
        descriptors["spc_fern"] = {
            "entity_id": "spc_fern",
            "content_hash": hashlib.sha256(species_asset.read_bytes()).hexdigest(),
            "source": {"uri": str(species_asset)},
            "measurement": {"status": "MEASURED"},
            "collision": {"shape": "box"},
            "normalization_scale": [2.5, 2.5, 2.5],
        }
    return spec, plan, descriptors


def test_world_plan_1_1_0_with_scatter_still_compiles(tmp_path):
    """A plan carrying scatter used to be rejected outright as an unknown version."""
    spec, plan, descriptors = _with_scatter(tmp_path, measured_species=False)
    write_simulation_project(spec, plan, descriptors, tmp_path / "project")


def test_scatter_species_becomes_one_multimesh_field(tmp_path):
    spec, plan, descriptors = _with_scatter(tmp_path, measured_species=True)
    output = tmp_path / "project"
    write_simulation_project(spec, plan, descriptors, output)
    scene = (output / "main.tscn").read_text(encoding="utf-8")

    assert '[node name="Scatter" type="Node3D" parent="."]' in scene
    # One field per species, not one node per instance.
    assert scene.count('type="MultiMeshInstance3D"') == 1
    assert 'species_id = "spc_fern"' in scene
    assert 'script = ExtResource("5_scatter")' in scene
    assert "metadata/planned_instances = 2" in scene
    # A measured species instances its real asset at its measured scale.
    assert "source_scene = ExtResource(" in scene
    assert "asset_scale = 2.5" in scene
    assert "fallback_mesh" not in scene
    assert (output / "runtime" / "scatter_field.gd").is_file()


def test_unresolved_species_draws_a_correctly_sized_placeholder(tmp_path):
    """Decoration degrades to a visible box rather than vanishing silently."""
    spec, plan, descriptors = _with_scatter(tmp_path, measured_species=False)
    output = tmp_path / "project"
    write_simulation_project(spec, plan, descriptors, output)
    scene = (output / "main.tscn").read_text(encoding="utf-8")

    assert 'fallback_mesh = SubResource("SpeciesMesh0")' in scene
    assert "source_scene" not in scene
    assert '[sub_resource type="BoxMesh" id="SpeciesMesh0"]\nsize = Vector3(1.4, 2.2, 1.4)' in scene


def test_scatter_transforms_come_from_the_plan_not_the_scene(tmp_path):
    """Transforms stay in world_plan.json so the field is data, not baked nodes."""
    spec, plan, descriptors = _with_scatter(tmp_path, measured_species=True)
    output = tmp_path / "project"
    write_simulation_project(spec, plan, descriptors, output)
    scene = (output / "main.tscn").read_text(encoding="utf-8")
    shipped_plan = json.loads((output / "world_plan.json").read_text(encoding="utf-8"))

    assert len(shipped_plan["scatter"]["instances"]) == 2
    assert "300" not in scene  # no per-instance yaw leaked into the scene text


def test_scatter_field_emission_is_deterministic(tmp_path):
    spec, plan, descriptors = _with_scatter(tmp_path, measured_species=True)
    first = tmp_path / "a"
    second = tmp_path / "b"
    write_simulation_project(spec, plan, descriptors, first)
    write_simulation_project(spec, plan, descriptors, second)
    assert (first / "main.tscn").read_text(encoding="utf-8") == (
        second / "main.tscn"
    ).read_text(encoding="utf-8")


# --- What only a running engine can prove ------------------------------------


_SCATTER_BASE_PROBE = """extends SceneTree
func _initialize() -> void:
	var root: Node = load("res://main.tscn").instantiate()
	get_root().add_child(root)
	var cam := Camera3D.new()
	get_root().add_child(cam)
	cam.look_at_from_position(Vector3(0, 40, 60), Vector3.ZERO, Vector3.UP)
	cam.current = true
	for i in range(10):
		await process_frame
	var field := root.get_node("Scatter/ScatterSpcFern")
	var mm: MultiMesh = field.multimesh
	if mm.buffer.size() < 12:
		print("PROBE_FAIL empty_buffer count=", mm.instance_count)
		quit(1)
		return
	# Lowest point of EVERY instance, in world space, with per-instance scale
	# applied -- the instancer jitters scale, so a fixed offset would not do.
	var lowest := 1e9
	var highest := -1e9
	for i in mm.instance_count:
		var t: Transform3D = mm.get_instance_transform(i)
		var base: float = t.origin.y + mm.mesh.get_aabb().position.y * t.basis.get_scale().y
		lowest = minf(lowest, base)
		highest = maxf(highest, base)
	print("PROBE count=%d lowest_base=%.4f highest_base=%.4f" % [
		mm.instance_count, lowest, highest])
	quit(0)
"""


@pytest.mark.skipif(
    not os.environ.get("GODOT_BIN"),
    reason="engine-verified scatter needs GODOT_BIN and a real renderer (local only)",
)
def test_scatter_instances_stand_on_the_ground_not_buried_in_it(tmp_path):
    """A regression only a rendered frame can catch.

    The plan gives a point ON the ground, but a BoxMesh is modelled centred on
    its origin, so placing instances at the planned point buried half of every
    one of them -- a 25 m tree showed 12.5 m and ferns read as flat slabs. The
    transforms were exactly what the plan said, which is why every unit test
    passed and the world was still wrong.

    Headless cannot verify this: Godot's dummy renderer never allocates the
    MultiMesh buffer, so `get_instance_transform` returns identity for every
    index (confirmed against a hand-built MultiMesh with known values). This
    test therefore needs a real rendering driver.
    """
    spec, plan, descriptors = _with_scatter(tmp_path, measured_species=False)
    output = tmp_path / "project"
    write_simulation_project(spec, plan, descriptors, output)
    (output / "probe.gd").write_text(_SCATTER_BASE_PROBE, encoding="utf-8")

    result = subprocess.run(
        [
            os.environ["GODOT_BIN"], "--path", str(output),
            "--rendering-driver", "opengl3", "--resolution", "320x200",
            "--script", "probe.gd",
        ],
        capture_output=True, text=True, timeout=180,
    )
    line = next(
        (item for item in result.stdout.splitlines() if item.startswith("PROBE ")), None
    )
    assert line, f"probe produced no reading:\n{result.stdout}\n{result.stderr}"

    values = dict(
        part.split("=") for part in line.removeprefix("PROBE ").split()
    )
    assert int(values["count"]) == 2
    # Every instance's lowest point must land on the ground plane, whatever its
    # jittered scale — not merely the first one.
    assert float(values["lowest_base"]) == pytest.approx(0.0, abs=1e-3), line
    assert float(values["highest_base"]) == pytest.approx(0.0, abs=1e-3), line


def test_world_gravity_reaches_the_engine(tmp_path):
    """A place off Earth must fall like it.

    Nothing carried gravity, so `get_gravity()` returned Godot's 9.8 for every
    world and a lunar base was physically a warehouse. The number has to land in
    project.godot, because that is what the controller and the agent read.
    """
    spec, plan, descriptors = _fixture(tmp_path / "moon.glb")
    spec.setdefault("environment", {})["gravity_mps2"] = 1.62
    output = tmp_path / "moon_project"
    write_simulation_project(spec, plan, descriptors, output)
    project = (output / "project.godot").read_text(encoding="utf-8")
    assert "3d/default_gravity=1.62" in project


def test_gravity_defaults_to_earth_and_is_clamped(tmp_path):
    """Absent is Earth; absurd is refused rather than obeyed.

    Zero gravity means a player who never lands and 300 means one who cannot
    jump, and both are worse failures than being wrong about the Moon.
    """
    spec, plan, descriptors = _fixture(tmp_path / "earth.glb")
    spec.setdefault("environment", {}).pop("gravity_mps2", None)
    write_simulation_project(spec, plan, descriptors, tmp_path / "default_project")
    assert "3d/default_gravity=9.81" in (
        (tmp_path / "default_project" / "project.godot").read_text(encoding="utf-8")
    )

    spec.setdefault("environment", {})["gravity_mps2"] = 900.0
    write_simulation_project(spec, plan, descriptors, tmp_path / "clamped_project")
    assert "3d/default_gravity=30" in (
        (tmp_path / "clamped_project" / "project.godot").read_text(encoding="utf-8")
    )


def test_a_speaker_gets_a_dialogue_label_in_the_scene_tree(tmp_path):
    """The label is authored into the scene, not conjured at load.

    Whoever opens the downloaded project should find a DialogueLine node they can
    restyle or reposition. A label created by the runtime script exists only while
    the game runs and is invisible in the editor, which is the opposite of what an
    editable export is for.

    It also has to be off at rest: a speaker standing there with its first line
    already floating above its head has started the conversation for the visitor.
    """
    spec, plan, descriptors = _fixture(tmp_path / "model.glb")
    door = next(
        entity for entity in spec["entities"] if entity["entity_id"] == "ent_village_door"
    )
    door["capabilities"] = ["dialogue"]
    door["dialogue"] = ["Mind the platform edge."]
    graph = plan["behaviours"][0]
    graph["capability_id"] = "dialogue"
    graph["runtime_binding"] = "dialogue_lines"
    graph["initial_state"] = "idle"
    graph["states"] = [
        {
            "state_id": "idle",
            "observable_properties": {"speaking": False, "line": "", "line_index": -1},
        },
        {
            "state_id": "speaking_0",
            "observable_properties": {
                "speaking": True,
                "line": "Mind the platform edge.",
                "line_index": 0,
            },
        },
    ]
    graph["transitions"] = [
        {
            "transition_id": "idle__talk__speaking_0",
            "from_state": "idle",
            "to_state": "speaking_0",
            "trigger": "talk",
            "guard": {"kind": "always", "parameters": {}},
            "effects": [],
            "duration_ms": 0,
        }
    ]
    graph["probes"] = [
        {
            "probe_id": "probe_talk",
            "triggers": ["talk"],
            "expected_state": "speaking_0",
            "expected_properties": {"speaking": True, "line": "Mind the platform edge."},
            "requirement_ids": [],
        }
    ]

    output = tmp_path / "project"
    write_simulation_project(spec, plan, descriptors, output)
    scene = (output / "main.tscn").read_text(encoding="utf-8")

    assert '[node name="DialogueLine" type="Label3D" parent="EntVillageDoor"]' in scene
    label = scene.split('[node name="DialogueLine"')[1].split("[node ")[0]
    assert "visible = false" in label
    assert "billboard = 1" in label
    # The line text belongs in the behaviour graph, which is where a probe can
    # assert it -- not baked into the label, where the two could disagree.
    assert 'text = "Mind' not in label
    assert "Mind the platform edge." in scene.replace('\\"', '"')

    load_steps = int(re.search(r"load_steps=(\d+)", scene).group(1))
    assert load_steps == (
        scene.count("[ext_resource ") + scene.count("[sub_resource ") + 1
    )


def test_a_rigged_bystander_is_given_something_to_play(tmp_path):
    """A rigged model with nothing playing renders in its exported bind pose.

    Only two things animate in a generated world: the player's controller and an
    autonomous agent's script. Everything else was a body with a rigged model
    attached and nothing driving it, which went unnoticed while the only people
    in a world were walking agents. A dialogue speaker is the first entity whose
    whole purpose is to stand still and look alive at the same time -- confirmed
    in a shipped project, where both railway speakers instanced a GLB carrying
    `HumanArmature|Man_Idle` and no script played it.

    The clip is found at load by name, not named here, because the asset
    descriptor records synthetic clip names (`clip_1`) rather than the real ones.
    """
    spec, plan, descriptors = _fixture(tmp_path / "model.glb")
    descriptors["ent_village_door"]["animation"] = {
        "rigged": True,
        "clips": ["clip_1"],
        "locomotion_compatible": True,
    }
    output = tmp_path / "project"
    write_simulation_project(spec, plan, descriptors, output)
    scene = (output / "main.tscn").read_text(encoding="utf-8")

    assert '[node name="IdlePose" type="Node3D" parent="EntVillageDoor"]' in scene
    assert (output / "runtime" / "idle_pose.gd").is_file()
    # The controlled actor drives its own clips; a second script fighting it for
    # the same AnimationPlayer would stutter between walk and idle.
    assert 'parent="EntControlledActor"]\nscript = ExtResource("7_idle")' not in scene

    load_steps = int(re.search(r"load_steps=(\d+)", scene).group(1))
    assert load_steps == (
        scene.count("[ext_resource ") + scene.count("[sub_resource ") + 1
    )


def test_an_unrigged_body_is_left_alone(tmp_path):
    """Nothing to play means nothing attached.

    Falling back to "play whatever clip is first" would put a standing figure
    into a death or a punch animation because of export order.
    """
    spec, plan, descriptors = _fixture(tmp_path / "model.glb")
    for descriptor in descriptors.values():
        descriptor["animation"] = {
            "rigged": False,
            "clips": [],
            "locomotion_compatible": False,
        }
    output = tmp_path / "project"
    write_simulation_project(spec, plan, descriptors, output)
    scene = (output / "main.tscn").read_text(encoding="utf-8")
    assert "IdlePose" not in scene


def _with_relief(plan: dict) -> dict:
    """Give a plan a small heightfield, the way the planner now does."""
    plan["terrain"] = {
        "width_m": 24.0,
        "depth_m": 24.0,
        "grid": 9,
        "amplitude_m": 1.2,
        # A ramp rising along +Z. Deliberately not a modular pattern: the first
        # version of this fixture happened to be exactly zero at both points the
        # path test sampled, so the test read a flat field and passed the old
        # constant back to itself.
        "heights_m": [
            round(row * 0.15 - 0.6, 4) for row in range(9) for _column in range(9)
        ],
    }
    return plan


def test_a_planned_heightfield_reaches_the_ground_node(tmp_path):
    """Relief in the plan has to reach the scene, or every body floats.

    Placement now seats entities on the field, so a flat BoxMesh under a plan with
    relief would leave buildings hanging in the air or buried -- which is why the
    writer change lands with the placement change rather than after it.

    The node moves to y=0 because planned heights are absolute, measured from the
    world origin. The flat slab still sits at -0.25 to put its TOP at zero.
    """
    spec, plan, descriptors = _fixture(tmp_path / "model.glb")
    output = tmp_path / "project"
    write_simulation_project(spec, _with_relief(plan), descriptors, output)
    scene = (output / "main.tscn").read_text(encoding="utf-8")

    ground = scene.split('[node name="Ground"')[1].split("[node ")[0]
    assert "position = Vector3(0, 0, 0)" in ground
    assert 'script = ExtResource("8_terrain")' in ground
    assert (output / "runtime" / "terrain_field.gd").is_file()
    # The field itself travels in the plan, not duplicated into the scene: the
    # runtime reads world_plan.json, which is also the lineage record.
    written = json.loads((output / "world_plan.json").read_text(encoding="utf-8"))
    assert written["terrain"]["grid"] == 9
    assert len(written["terrain"]["heights_m"]) == 81

    load_steps = int(re.search(r"load_steps=(\d+)", scene).group(1))
    assert load_steps == (
        scene.count("[ext_resource ") + scene.count("[sub_resource ") + 1
    )


def test_a_flat_world_keeps_the_slab_it_always_had(tmp_path):
    """Indoor worlds, built surfaces and pre-terrain plans must not change at all.

    A concrete yard with hills in it is a fault, and a plan preserved through a
    repair may carry no terrain block. Both take the path the writer has always
    taken, which is what keeps the byte-stability test meaningful.
    """
    spec, plan, descriptors = _fixture(tmp_path / "model.glb")
    assert "terrain" not in plan
    output = tmp_path / "project"
    write_simulation_project(spec, plan, descriptors, output)
    scene = (output / "main.tscn").read_text(encoding="utf-8")

    ground = scene.split('[node name="Ground"')[1].split("[node ")[0]
    assert "position = Vector3(0, -0.25, 0)" in ground
    assert "8_terrain" not in ground
    # Still shipped, because it costs nothing and finds no terrain block to act on.
    assert (output / "runtime" / "terrain_field.gd").is_file()


def test_a_zero_amplitude_field_is_treated_as_flat(tmp_path):
    """`amplitude_m: 0` is what an indoor world's field looks like.

    It carries a grid of zeros rather than being absent, so the writer must read
    the amplitude rather than merely check for the block's presence.
    """
    spec, plan, descriptors = _fixture(tmp_path / "model.glb")
    plan["terrain"] = {
        "width_m": 24.0,
        "depth_m": 24.0,
        "grid": 9,
        "amplitude_m": 0.0,
        "heights_m": [0.0] * 81,
    }
    output = tmp_path / "project"
    write_simulation_project(spec, plan, descriptors, output)
    ground = (output / "main.tscn").read_text(encoding="utf-8").split(
        '[node name="Ground"'
    )[1].split("[node ")[0]
    assert "position = Vector3(0, -0.25, 0)" in ground
    assert "8_terrain" not in ground


def test_paths_lie_on_the_ground_rather_than_at_a_fixed_height(tmp_path):
    """Path segments were pinned to y=0.03, three centimetres above a plane.

    Over relief that floats a path across every dip and buries it in every rise, and
    a path is a wide visible ribbon -- it is the first thing that would look wrong.
    Each segment now sits at the mean of its endpoints' ground heights and pitches to
    the fall between them, which is exact for a straight run between two points.
    """
    spec, plan, descriptors = _fixture(tmp_path / "model.glb")
    plan = _with_relief(plan)
    # Deliberately asymmetric. A run between mirrored points has a midpoint mean of
    # exactly zero, so it lands on 0.03 and looks identical to the old constant --
    # the first version of this test proved nothing for that reason.
    plan["navigation"]["paths"] = [
        {
            "path_id": "path_main",
            "width_m": 1.5,
            "status": "CONNECTED",
            "points_m": [[-9.0, 0.0, -9.0], [9.0, 0.0, -3.0]],
        }
    ]
    output = tmp_path / "project"
    write_simulation_project(spec, plan, descriptors, output)
    scene = (output / "main.tscn").read_text(encoding="utf-8")

    segment = scene.split('[node name="PathSegment1"')[1].split("[node ")[0]
    position = re.search(r"position = Vector3\(([^)]+)\)", segment).group(1)
    height = float(position.split(",")[1])
    # The ramp is row * 0.15 - 0.6, and the endpoints land on rows 1 and 3, so the
    # segment sits at the mean of -0.45 and -0.15, three centimetres clear.
    assert height == pytest.approx(-0.27, abs=1e-3)
    rotation = re.search(r"rotation_degrees = Vector3\(([^)]+)\)", segment).group(1)
    pitch = float(rotation.split(",")[0])
    assert pitch != pytest.approx(0.0), "a segment across relief has to tilt"
    assert pitch < 0.0, "the far end is higher, so it tips backwards"


def test_a_flat_world_keeps_its_paths_where_they_were(tmp_path):
    """No field means the old constant, so nothing changes for a flat world."""
    spec, plan, descriptors = _fixture(tmp_path / "model.glb")
    plan["navigation"]["paths"] = [
        {
            "path_id": "path_main",
            "width_m": 1.5,
            "status": "CONNECTED",
            "points_m": [[-4.0, 0.0, 0.0], [4.0, 0.0, 0.0]],
        }
    ]
    output = tmp_path / "project"
    write_simulation_project(spec, plan, descriptors, output)
    segment = (output / "main.tscn").read_text(encoding="utf-8").split(
        '[node name="PathSegment1"'
    )[1].split("[node ")[0]
    assert "position = Vector3(0, 0.03, 0)" in segment
    assert "rotation_degrees = Vector3(0, " in segment


def test_wall_segments_become_solid_nodes_that_share_one_mesh(tmp_path):
    """A run's segments have to reach the scene, and reach it as obstacles.

    The village's boundary wall was 59 scatter panels, which the writer emits as a
    MultiMeshInstance3D with no collision body -- the dog walked through all of
    them. `linear_structures` materialises a run into spec entities precisely so
    this path applies: a StaticBody3D with a CollisionShape3D each, in the
    navigation-source group so the navmesh is carved around them.

    Sharing one mesh is the other half. Sixteen segments of one wall are sixteen
    nodes and must be one asset on disk, or a long wall costs sixteen models.
    """
    spec, plan, descriptors = _fixture(tmp_path / "wall.glb")

    for index in range(3):
        entity_id = f"ent_boundary_wall_s{index}"
        spec["entities"].append(
            {
                "entity_id": entity_id,
                "role": "scenery",
                "physical": {"mass_kg": 0.0},
                "capabilities": [],
            }
        )
        plan["entities"].append(
            {
                "entity_id": entity_id,
                "semantic_type": "dry_stone_boundary_wall",
                "zone_id": "main",
                # The same ref for every segment: one wall, one mesh.
                "asset_ref": "linear:lin_boundary_wall",
                "measurement_status": "MEASURED",
                "dimensions_m": [3.55, 1.8, 0.5],
                "transform": {
                    "position_m": [-20.0 + index * 3.56, 0.9, -20.0],
                    "rotation_y_degrees": 0.0,
                    "scale": [1.0, 1.0, 1.0],
                },
                "world_aabb": {
                    "min": [-21.8 + index * 3.56, 0.0, -20.25],
                    "max": [-18.2 + index * 3.56, 1.8, -19.75],
                },
                "support": {"type": "terrain", "target_id": None, "contact_y_m": 0},
                "interaction_clearance_m": 0.25,
                "dynamic": False,
                "parent_id": None,
            }
        )
        descriptors[entity_id] = {
            "entity_id": entity_id,
            "content_hash": descriptors["ent_village_door"]["content_hash"],
            "source": {"uri": descriptors["ent_village_door"]["source"]["uri"]},
            "measurement": {"status": "MEASURED"},
            "collision": {"shape": "box"},
            "normalization_scale": [1.0, 1.0, 1.0],
        }

    output = tmp_path / "project"
    write_simulation_project(spec, plan, descriptors, output)
    scene = (output / "main.tscn").read_text(encoding="utf-8")

    for index in range(3):
        name = f"EntBoundaryWallS{index}"
        assert f'[node name="{name}" type="StaticBody3D"' in scene, name
        # Solid, and visible to the navmesh baker -- a wall the navmesh ignores is
        # a wall agents path straight through.
        assert f'[node name="CollisionShape3D" type="CollisionShape3D" parent="{name}"]' in scene
        assert "serendib_navigation_source" in scene

    # One wall, one file. The segments share a content hash, so the writer must not
    # copy the same mesh once per segment.
    assert len(list((output / "assets").glob("*.glb"))) == 1
