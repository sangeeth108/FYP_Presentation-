"""Asset farm S5: the deterministic resolution tree, tested without a GPU.

The mock backend produces a real, QA-parseable GLB, so these exercise the true
resolver -> QA -> cache -> license path, not a stub. The property that matters
most is the last one: the build NEVER blocks — every failure mode falls through
to the curated asset.
"""

import json
from pathlib import Path

import pytest
from asset_farm.backends import MockBackend, _minimal_glb
from asset_farm.brief import AssetBrief
from asset_farm.cache import AssetCache
from asset_farm.license_guard import LicenseError, assert_product_safe, is_product_safe
from asset_farm.qa_gate import qa_mesh
from asset_farm.resolver import ResolutionError, resolve_asset

# --- a fixture ledger, so tests don't depend on the live one being verified ---
LEDGER_HEADER = (
    "component,kind,version,license,license_url,territory_restrictions,"
    "commercial_ok,product_path,verified_date,verified_by,notes\n"
)


@pytest.fixture
def ledger(tmp_path) -> str:
    rows = [
        "trellis-2,model,2,MIT,url,none,yes,product,2026-07-14,web,ok",
        "stable-audio-open,model,1,SAO,url,none,conditional,product,2026-07-14,web,under-threshold",
        "flux1-dev,model,1,noncomm,url,none,no,research_only,2026-07-14,web,quarantined",
        "hunyuan3d-2.1,model,1,noncomm,url,UK/EU/Korea excluded,no,research_only,"
        "2026-07-14,web,quarantined",
        "unverified-model,model,1,MIT,url,none,yes,product,,web,NO DATE",
    ]
    p = tmp_path / "ledger.csv"
    p.write_text(LEDGER_HEADER + "\n".join(rows) + "\n", encoding="utf-8")
    return str(p)


def _curated(tmp_path) -> Path:
    p = tmp_path / "curated.glb"
    p.write_bytes(_minimal_glb(500))
    return p


# --- brief hashing ---
def test_brief_hash_is_stable_and_content_addressed():
    a = AssetBrief("a cracked marble sarcophagus", "prop", 2000)
    b = AssetBrief("a cracked marble sarcophagus", "prop", 2000)
    c = AssetBrief("a cracked marble sarcophagus", "prop", 3000)  # different budget
    assert a.hash() == b.hash()
    assert a.hash() != c.hash()
    assert len(a.hash()) == 16


def test_default_tri_budget_by_category():
    assert AssetBrief("x-ray", "character").effective_tri_budget == 8000
    assert AssetBrief("a rock", "prop").effective_tri_budget == 2000
    assert AssetBrief("a rock", "prop", 750).effective_tri_budget == 750  # explicit wins


# --- license guard against the REAL ledger (§12 enforcement) ---
def test_quarantined_models_are_refused_by_the_real_ledger():
    with pytest.raises(LicenseError):
        assert_product_safe("flux1-dev")  # non-commercial
    with pytest.raises(LicenseError):
        assert_product_safe("hunyuan3d-2.1")  # non-commercial + territory
    with pytest.raises(LicenseError):
        assert_product_safe("a-model-not-in-the-ledger")


def test_unverified_model_is_refused(ledger):
    # A product-path row with no verified_date must not ship (§12).
    with pytest.raises(LicenseError) as exc:
        assert_product_safe("unverified-model", ledger)
    assert "verif" in exc.value.reason.lower()


def test_conditional_commercial_is_allowed(ledger):
    assert is_product_safe("stable-audio-open", ledger)  # ships under a threshold


# --- QA gate ---
def test_qa_passes_within_budget(tmp_path):
    brief = AssetBrief("a small crate", "prop", 2000)
    res = MockBackend().generate(brief, tmp_path)
    report = qa_mesh(res.path, brief)
    assert report.passed
    assert report.tri_count == 1600  # 0.8 * 2000, re-measured independently
    assert report.bbox_dimensions == (1.0, 1.0, 0.0)
    assert report.measurement_method == "gltf_active_scene_aabb_v1"


def test_qa_fails_over_budget(tmp_path):
    brief = AssetBrief("a boss", "character", 500)
    res = MockBackend(tri_fraction=6.0).generate(brief, tmp_path)  # ~3000 tris
    report = qa_mesh(res.path, brief)
    assert not report.passed
    assert "TRI_BUDGET_EXCEEDED" in [e.code for e in report.errors]


def test_qa_rejects_a_non_glb(tmp_path):
    junk = tmp_path / "x.glb"
    junk.write_bytes(b"this is not a glb")
    report = qa_mesh(junk, AssetBrief("a rock", "prop"))
    assert not report.passed
    assert "ASSET_MALFORMED" in [e.code for e in report.errors]


# --- the resolution tree ---
def test_generate_tier_wins_when_licensed_and_within_budget(tmp_path, ledger):
    brief = AssetBrief("a torchlit sarcophagus", "prop", 2000)
    cache = AssetCache(tmp_path / "cache")
    r = resolve_asset(brief, _curated(tmp_path), backend=MockBackend("trellis-2"),
                      cache=cache, work_dir=tmp_path / "work", ledger_path=ledger)
    assert r.tier == "generated"
    assert r.component == "trellis-2"
    assert r.qa.passed


def test_cache_tier_wins_on_the_second_resolve(tmp_path, ledger):
    brief = AssetBrief("a torchlit sarcophagus", "prop", 2000)
    cache = AssetCache(tmp_path / "cache")
    first = resolve_asset(brief, _curated(tmp_path), backend=MockBackend("trellis-2"),
                          cache=cache, work_dir=tmp_path / "work", ledger_path=ledger)
    assert first.tier == "generated"
    second = resolve_asset(brief, _curated(tmp_path), backend=MockBackend("trellis-2"),
                           cache=cache, work_dir=tmp_path / "work", ledger_path=ledger)
    assert second.tier == "cache"  # no regeneration
    assert second.path == first.path


def test_legacy_cache_entry_cannot_bypass_current_qa_profile(tmp_path):
    cache = AssetCache(tmp_path / "cache")
    asset = cache.root / "legacy.glb"
    asset.write_bytes(b"old generated asset")
    (cache.root / "legacy.json").write_text(
        json.dumps({"filename": asset.name, "component": "triposr", "tri_count": 10}),
        encoding="utf-8",
    )
    assert cache.get("legacy") is None


def test_unlicensed_backend_falls_back_to_curated(tmp_path, ledger):
    brief = AssetBrief("a forbidden relic", "prop", 2000)
    curated = _curated(tmp_path)
    r = resolve_asset(brief, curated, backend=MockBackend("flux1-dev"),  # quarantined
                      cache=AssetCache(tmp_path / "c"), work_dir=tmp_path / "w", ledger_path=ledger)
    assert r.tier == "curated"
    assert r.path == curated
    assert any("skipped" in n for n in r.notes)


def test_over_budget_generation_falls_back_to_curated(tmp_path, ledger):
    brief = AssetBrief("an over-detailed idol", "prop", 500)
    curated = _curated(tmp_path)
    r = resolve_asset(brief, curated, backend=MockBackend("trellis-2", tri_fraction=10.0),
                      cache=AssetCache(tmp_path / "c"), work_dir=tmp_path / "w", ledger_path=ledger)
    assert r.tier == "curated"
    assert any("failed QA" in n for n in r.notes)


def test_crashing_backend_falls_back_to_curated(tmp_path, ledger):
    class Boom:
        component = "trellis-2"

        def generate(self, brief, out_dir):
            raise RuntimeError("CUDA out of memory")

    curated = _curated(tmp_path)
    r = resolve_asset(AssetBrief("a doomed prop", "prop"), curated, backend=Boom(),
                      cache=AssetCache(tmp_path / "c"), work_dir=tmp_path / "w", ledger_path=ledger)
    assert r.tier == "curated"
    assert any("generation failed" in n for n in r.notes)


def test_no_backend_uses_curated_directly(tmp_path):
    curated = _curated(tmp_path)
    r = resolve_asset(AssetBrief("a plain barrel", "prop"), curated)
    assert r.tier == "curated"
    assert r.qa is not None
    assert r.qa.passed
    assert r.qa.bbox_dimensions == (1.0, 1.0, 0.0)


def test_no_asset_and_no_fallback_raises(tmp_path):
    with pytest.raises(ResolutionError) as exc:
        resolve_asset(AssetBrief("a ghost", "prop"), None)
    assert exc.value.code == "NO_ASSET"


# --- the cache stores FILES, never derived measurements ---
def _glb_with_bounds(dims, tri_count: int = 100) -> bytes:
    """A valid GLB whose active-scene AABB is exactly `dims`.

    _minimal_glb is fixed at (1, 1, 0), where height and longest axis coincide —
    it cannot tell the two normalisation rules apart. This one can.
    """
    import struct

    positions = struct.pack("<9f", 0, 0, 0, dims[0], 0, 0, 0, dims[1], dims[2])
    indices = struct.pack(f"<{3 * tri_count}H", *([0, 1, 2] * tri_count))
    bin_chunk = positions + indices
    while len(bin_chunk) % 4:
        bin_chunk += b"\x00"
    gltf = {
        "asset": {"version": "2.0", "generator": "promptplay-test"},
        "buffers": [{"byteLength": len(bin_chunk)}],
        "bufferViews": [
            {"buffer": 0, "byteOffset": 0, "byteLength": len(positions), "target": 34962},
            {
                "buffer": 0,
                "byteOffset": len(positions),
                "byteLength": len(indices),
                "target": 34963,
            },
        ],
        "accessors": [
            {
                "bufferView": 0,
                "componentType": 5126,
                "count": 3,
                "type": "VEC3",
                "min": [0, 0, 0],
                "max": list(dims),
            },
            {"bufferView": 1, "componentType": 5123, "count": 3 * tri_count, "type": "SCALAR"},
        ],
        "meshes": [{"primitives": [{"attributes": {"POSITION": 0}, "indices": 1}]}],
        "nodes": [{"mesh": 0}],
        "scenes": [{"nodes": [0]}],
        "scene": 0,
    }
    json_chunk = json.dumps(gltf, separators=(",", ":")).encode("utf-8")
    while len(json_chunk) % 4:
        json_chunk += b" "
    header = struct.pack("<4sII", b"glTF", 2, 12 + 8 + len(json_chunk) + 8 + len(bin_chunk))
    return (
        header
        + struct.pack("<I4s", len(json_chunk), b"JSON")
        + json_chunk
        + struct.pack("<I4s", len(bin_chunk), b"BIN\x00")
        + bin_chunk
    )


def test_a_cache_hit_is_re_measured_so_rule_changes_reach_cached_assets(tmp_path):
    """A cache hit must re-derive geometry, not replay a stored measurement.

    The cache is keyed by brief_hash and stores the FILE plus licence/tri-count
    metadata — never `world_dimensions_m`, `normalization_scale` or anything else
    computed from the declared size. So changing the normalisation rule (7a1e3ed:
    height, not longest axis) reaches assets already cached, and the cache needs
    no rule-version stamp in its key.

    Pinned because the opposite was believed: a pre-fix lineage row read back
    from `asset_descriptors` looked like a stale cache entry. It was simply an
    old record — descriptors are per-run, recomputed every time.

    Uses the T-pose proportions that forced 7a1e3ed, the one shape where the two
    rules visibly disagree. The CATEGORY is `prop`, not `character`, because
    normalisation is category-independent and a character served from cache must now
    carry a rig (`resolver._cache_entry_satisfies`) -- this stub is a bare box, so as a
    character it would be refused and the cache tier never exercised. The rig rule has
    its own tests in `test_cache_rig_guard.py`; the shape is what matters here.
    """
    from assets.descriptors import descriptors_from_simulation_manifest

    declared = [0.7, 1.8, 0.7]
    imported = (1.09, 1.02, 0.20)
    entity_id = "ent_visitor"
    spec = {
        "entities": [
            {
                "entity_id": entity_id,
                "semantic_type": "visitor",
                "role": "ambient_agent",
                "capabilities": [],
                "asset": {"category": "prop"},
                "physical": {"bbox_m": declared},
            }
        ]
    }

    asset = tmp_path / "visitor.glb"
    asset.write_bytes(_glb_with_bounds(imported))
    brief = AssetBrief("a village visitor standing", "prop", 8000)

    def descriptor(resolved):
        descriptors, errors = descriptors_from_simulation_manifest(
            spec, {entity_id: resolved.to_dict()}
        )
        assert not errors, errors
        return descriptors[entity_id]

    fresh = resolve_asset(brief, curated_fallback=asset)
    cache = AssetCache(tmp_path / "cache")
    cache.put(brief.hash(), asset, "trellis-2", 100)
    cached = resolve_asset(brief, curated_fallback=asset, cache=cache)

    assert fresh.tier == "curated" and cached.tier == "cache"
    # The cached entry was measured again on the way out, not trusted.
    assert cached.qa.bbox_dimensions == imported

    # Identical geometry either way — the tier does not change the numbers.
    for field in ("imported_dimensions_m", "world_dimensions_m", "normalization_scale"):
        assert descriptor(cached)[field] == descriptor(fresh)[field], field

    # And the numbers are the CURRENT rule's: declared height honoured. The old
    # longest-to-longest rule gave 1.68 m of height and is what a stale
    # descriptor would still report.
    world = descriptor(cached)["world_dimensions_m"]
    assert world[1] == pytest.approx(1.8, rel=0.01)
    legacy_scale = max(declared) / max(imported)
    assert imported[1] * legacy_scale == pytest.approx(1.684, abs=0.001)


def test_the_live_farm_models_are_license_verified_and_product_safe():
    """The §12 gate is CLOSED: the four farm models are web-verified and cleared
    for the product path against the real ledger. This guards against a
    regression — if someone blanks a verified_date or flips a license, the guard
    (and this test) refuses generation again.
    """
    for model in ("trellis-2", "sdxl", "flux1-schnell", "stable-audio-open"):
        assert is_product_safe(model), f"{model} is no longer product-safe in the live ledger"


def test_the_quarantined_models_stay_quarantined_in_the_live_ledger():
    for model in ("flux1-dev", "hunyuan3d-2.1"):
        assert not is_product_safe(model), f"{model} must remain research-only (§12/§14)"


@pytest.mark.parametrize(
    ("form", "semantic_type", "bbox"),
    [
        ("legged_platform", "workbench", [1.8, 0.9, 0.8]),
        ("slender_post", "lamp_post", [0.4, 4.0, 0.4]),
        ("flat_panel", "framed_painting", [1.4, 1.0, 0.06]),
        ("open_container", "supply_crate", [0.9, 0.7, 0.9]),
        ("machine_block", "generator", [1.6, 1.4, 1.0]),
    ],
)
def test_indoor_forms_build_to_their_declared_bounds(tmp_path, form, semantic_type, bbox):
    """The forms added for interiors, each measured against what it claimed.

    The vocabulary covered outdoor nature -- trunks, ground cover, lumps, logs
    -- so a museum, a factory and a ward all resolved to `semantic_box` and
    rendered as correctly-sized coloured blocks. Every form here has to fill its
    declared box exactly, because the descriptor normalises by
    declared-over-measured and the sampler spaces by the result.
    """
    from asset_farm.procedural import resolve_procedural_asset

    entity = {
        "semantic_type": semantic_type,
        "physical": {"bbox_m": bbox},
        "asset": {"procedural_type": form, "brief": semantic_type},
    }
    result = resolve_procedural_asset(entity, tmp_path)
    assert result["tier"] == "procedural", result.get("notes")
    measured = result["qa"]["bbox_dimensions"]
    assert measured == pytest.approx(bbox, abs=1e-3)


def test_a_form_is_more_than_one_box(tmp_path):
    """A silhouette needs parts, or it is a box with a different name.

    `legged_platform` exists because a box the size of a table reads as a
    crate: what says "table" is the gap underneath, which only exists if the
    top and the legs are separate pieces.
    """
    from asset_farm.procedural import resolve_procedural_asset

    entity = {
        "semantic_type": "workbench",
        "physical": {"bbox_m": [1.8, 0.9, 0.8]},
        "asset": {"procedural_type": "legged_platform", "brief": "workbench"},
    }
    result = resolve_procedural_asset(entity, tmp_path)
    # A single box is 12 triangles. A slab on four legs is five of them.
    assert result["qa"]["tri_count"] >= 48
