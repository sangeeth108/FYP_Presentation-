import json
import re
from pathlib import Path

import pytest
from godot_client.project_writer import ProjectWriterError, pascal_case, write_project
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan

GOLDEN_SPEC = (
    Path(__file__).resolve().parents[3] / "contracts" / "examples" / "golden_game.spec.json"
)


@pytest.fixture(scope="module")
def golden_plan():
    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    return to_level_plan(run_pcg(spec))


def test_pascal_case_naming():
    assert pascal_case("castle_guard_shambler_01") == "CastleGuardShambler_01"
    assert pascal_case("z00") == "Z00"
    assert pascal_case("lever_gatehouse") == "LeverGatehouse"


def test_writes_valid_project_files(golden_plan, tmp_path):
    written = write_project(golden_plan, "Castle Gate Trial", tmp_path)
    assert {p.name for p in written} == {
        "project.godot",
        "main.tscn",
        "serendib_icon.svg",
        "serendib_splash.png",
    }

    project = (tmp_path / "project.godot").read_text(encoding="utf-8")
    assert 'renderer/rendering_method="gl_compatibility"' in project
    assert 'run/main_scene="res://main.tscn"' in project
    assert 'config/name="Castle Gate Trial"' in project
    assert 'config/icon="res://branding/serendib_icon.svg"' in project
    assert 'boot_splash/image="res://branding/serendib_splash.png"' in project
    assert 'PackedStringArray("4.6", "GL Compatibility")' in project


def test_scene_structure_matches_plan(golden_plan, tmp_path):
    write_project(golden_plan, "T", tmp_path)
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")

    node_names = re.findall(r'\[node name="([^"]+)"', scene)
    assert len(node_names) == len(set(node_names)), "node names must be unique"
    assert "Node3D_" not in scene  # the editability promise

    for room in golden_plan["rooms"]:
        assert f"Room{pascal_case(room['zone_id'])}" in node_names
    for entity in golden_plan["entities"]:
        assert pascal_case(entity["entity_id"]) in node_names
    assert "PlayerSpawn" in node_names
    assert "PreviewCamera" in node_names

    # Every SubResource reference must be defined, and load_steps must match.
    defined = set(re.findall(r'\[sub_resource type="[^"]+" id="([^"]+)"\]', scene))
    referenced = set(re.findall(r'SubResource\("([^"]+)"\)', scene))
    assert referenced <= defined
    load_steps = int(re.search(r"load_steps=(\d+)", scene).group(1))
    assert load_steps == len(defined) + 1


def test_output_is_byte_stable(golden_plan, tmp_path):
    a_dir, b_dir = tmp_path / "a", tmp_path / "b"
    write_project(golden_plan, "T", a_dir)
    write_project(golden_plan, "T", b_dir)
    assert (a_dir / "main.tscn").read_bytes() == (b_dir / "main.tscn").read_bytes()
    assert (a_dir / "project.godot").read_bytes() == (b_dir / "project.godot").read_bytes()


def test_entity_markers_sit_at_plan_positions(golden_plan, tmp_path):
    write_project(golden_plan, "T", tmp_path)
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    entity = golden_plan["entities"][0]
    block = re.search(
        rf'\[node name="{pascal_case(entity["entity_id"])}"[^\[]+', scene
    ).group(0)
    assert f"{entity['x']:g}, {entity['elevation']:g}, {entity['z']:g}" in block


def test_unsupported_plan_version_is_machine_readable(tmp_path):
    with pytest.raises(ProjectWriterError) as exc:
        write_project({"level_plan_version": "9.9.9"}, "T", tmp_path)
    err = exc.value.to_dict()
    assert err["code"] == "level_plan_version_unsupported"
    assert err["hint"]
