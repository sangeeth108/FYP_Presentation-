"""The 8-gate validation stack: passes good games, catches specific breaks."""

import json
from pathlib import Path

import pytest
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan
from validators.gates import run_gates

REPO = Path(__file__).resolve().parents[3]
GOLDEN_SPEC = json.loads(
    (REPO / "contracts" / "examples" / "golden_game.spec.json").read_text(encoding="utf-8")
)
SCHEMA = json.loads((REPO / "contracts" / "game_spec.schema.json").read_text(encoding="utf-8"))


@pytest.fixture()
def spec():
    s = json.loads(json.dumps(GOLDEN_SPEC))  # deep copy
    s["lineage"] = {"prompt": "golden", "build_hash": "deadbeef"}
    return s


@pytest.fixture()
def plan(spec):
    return to_level_plan(run_pcg(spec))


def _codes(report):
    return {e["code"] for e in report["errors"]}


def test_good_game_passes_all_active_gates(spec, plan):
    report = run_gates(spec, plan, schema=SCHEMA, build_result=None)
    assert report["verdict"] == "PASS", report["errors"]
    verdicts = {g["gate"]: g["verdict"] for g in report["gates"]}
    assert verdicts[1] == "PASS"
    assert verdicts[2] == "PASS"
    assert verdicts[3] == "SKIPPED"  # asset QA is P3
    assert verdicts[4] == "SKIPPED"  # no build supplied
    assert verdicts[5] == "PASS"
    assert verdicts[8] == "PASS"


def test_gate2_catches_camera_controller_mismatch(spec, plan):
    spec["player"]["controller_template_id"] = "controller_topdown_3d"  # camera is third_person
    report = run_gates(spec, plan, schema=SCHEMA)
    assert report["verdict"] == "FAIL"
    assert "CAMERA_CONTROLLER_MISMATCH" in _codes(report)


def test_gate2_catches_budget_violations(spec, plan):
    spec["entities"]["enemies"][0]["count"] = 25
    spec["budgets"]["max_enemies"] = 5
    report = run_gates(spec, plan, schema=SCHEMA)
    assert "ENEMY_BUDGET_EXCEEDED" in _codes(report)


def test_gate4_catches_oversized_builds(spec, plan, tmp_path):
    fake_index = tmp_path / "index.html"
    fake_index.write_text("x")
    fake_wasm = tmp_path / "index.wasm"
    fake_wasm.write_bytes(b"\0")
    build = {"total_bytes": 95 * 1024 * 1024, "files": [fake_index, fake_wasm]}
    report = run_gates(spec, plan, schema=SCHEMA, build_result=build)
    assert "BUILD_OVER_BUDGET" in _codes(report)


def test_gate5_catches_unreachable_exit(spec, plan):
    # Sever the level: push the exit room far away with no corridor to it.
    broken = json.loads(json.dumps(plan))
    exit_id = next(z["zone_id"] for z in broken["zones"] if z["kind"] == "exit")
    for room in broken["rooms"]:
        if room["zone_id"] == exit_id:
            room["x"] += 500.0
    broken["corridors"] = [c for c in broken["corridors"] if exit_id not in (c["a"], c["b"])]
    report = run_gates(spec, broken, schema=SCHEMA)
    assert report["verdict"] == "FAIL"
    codes = _codes(report)
    assert "EXIT_UNREACHABLE" in codes
    error = next(e for e in report["errors"] if e["code"] == "EXIT_UNREACHABLE")
    assert error["failure_class"] == "logic"
    assert error["gate"] == 5
    assert error["hint"]


def test_gate6_reads_bot_verdicts(spec, plan):
    ok = run_gates(spec, plan, schema=SCHEMA, bot_verdict="GREEDYBOT_OK time=9.1s")
    assert {g["gate"]: g["verdict"] for g in ok["gates"]}[6] == "PASS"
    bad = run_gates(spec, plan, schema=SCHEMA, bot_verdict="GREEDYBOT_STUCK pos=(1,2)")
    assert "BOT_DID_NOT_COMPLETE" in _codes(bad)


def test_gate6_reads_affordance_verdicts(spec, plan):
    # ADR-0008: gate 6 is dynamic playtest = win-path bot AND affordance oracle.
    ok = run_gates(spec, plan, schema=SCHEMA, affordance_verdict="AFFORDANCE_OK doors=3")
    assert {g["gate"]: g["verdict"] for g in ok["gates"]}[6] == "PASS"
    bad = run_gates(spec, plan, schema=SCHEMA,
                    affordance_verdict="AFFORDANCE_FAIL door_l never opened")
    assert "AFFORDANCE_DID_NOT_WORK" in _codes(bad)
    # a broken affordance fails the gate even when the win-path bot is happy
    both = run_gates(spec, plan, schema=SCHEMA, bot_verdict="GREEDYBOT_OK time=9s",
                     affordance_verdict="AFFORDANCE_FAIL x")
    assert {g["gate"]: g["verdict"] for g in both["gates"]}[6] == "FAIL"


def test_gate6_skipped_when_neither_playtest_ran(spec, plan):
    report = run_gates(spec, plan, schema=SCHEMA)  # no bot, no affordance
    assert {g["gate"]: g["verdict"] for g in report["gates"]}[6] == "SKIPPED"


def test_gate1_accepts_composite_objects_and_rejects_malformed(spec, plan):
    # entities.objects is additive + optional (ADR-0008 phase 3b-2): a valid one
    # passes gate 1, a malformed one (missing bbox/brief) is caught by the schema.
    good = json.loads(json.dumps(spec))
    good["entities"]["objects"] = [
        {"object_id": "car01", "archetype": "vehicle", "bbox": [2.0, 1.5, 4.0],
         "brief": "a rusty pickup truck, low-poly"}
    ]
    assert {g["gate"]: g["verdict"] for g in run_gates(good, plan, schema=SCHEMA)["gates"]}[1] \
        == "PASS"
    bad = json.loads(json.dumps(spec))
    bad["entities"]["objects"] = [{"object_id": "x", "archetype": "vehicle"}]  # no bbox/brief
    assert {g["gate"]: g["verdict"] for g in run_gates(bad, plan, schema=SCHEMA)["gates"]}[1] \
        == "FAIL"


def test_gate8_requires_lineage(spec, plan):
    spec["lineage"] = {}
    report = run_gates(spec, plan, schema=SCHEMA)
    assert "LINEAGE_INCOMPLETE" in _codes(report)