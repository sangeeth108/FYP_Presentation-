"""The two category vocabularies must stay reconciled.

A spec `category` says what a thing IS IN THE WORLD (vehicle, machine,
structure). An AssetBrief category says what PRODUCTION PATH it needs (tri
budget, rigging, whether generation will touch it). They are deliberately
different -- a vehicle and a structure differ in the world and build
identically.

What was not deliberate: the bridge used `.get(category, "prop")`, so a spec
category nobody had mapped silently became a barrel. A farm prompt's tractor
resolved to nothing partly because `vehicle` is excluded from mesh generation,
and nothing anywhere said so out loud.

These tests fail when someone adds to one vocabulary without the other, which
is the only way the two can drift.
"""

from __future__ import annotations

import json
from pathlib import Path

from asset_farm.brief import CATEGORIES
from asset_farm.pipeline import _SIMULATION_CATEGORY

_REPO = Path(__file__).resolve().parents[3]
_SCHEMA = _REPO / "contracts" / "simulation_spec.schema.json"


def _spec_categories() -> set[str]:
    schema = json.loads(_SCHEMA.read_text(encoding="utf-8"))
    return set(schema["$defs"]["asset_requirement"]["properties"]["category"]["enum"])


def test_every_spec_category_has_a_production_path():
    """A category the schema permits must be buildable, not silently a prop."""
    unmapped = _spec_categories() - set(_SIMULATION_CATEGORY)
    assert not unmapped, (
        f"spec allows {sorted(unmapped)} with no entry in _SIMULATION_CATEGORY; "
        "add one, or remove it from the schema"
    )


def test_the_bridge_never_invents_an_asset_category():
    """Every mapped value must be one AssetBrief actually accepts."""
    unknown = set(_SIMULATION_CATEGORY.values()) - set(CATEGORIES)
    assert not unknown, (
        f"_SIMULATION_CATEGORY produces {sorted(unknown)}, which AssetBrief "
        f"rejects; it allows {sorted(CATEGORIES)}"
    )


def test_the_bridge_maps_nothing_the_schema_does_not_allow():
    """A stale entry is a signal the schema changed and this did not."""
    stale = set(_SIMULATION_CATEGORY) - _spec_categories()
    assert not stale, (
        f"_SIMULATION_CATEGORY maps {sorted(stale)}, which the schema no longer "
        "permits"
    )


def test_the_content_designer_grammar_stays_inside_the_asset_vocabulary():
    """A third list of categories lives in the content designer's grammar.

    It is a deliberate SUBSET -- the mesh-producing categories only, because a
    mesh brief can never be audio or a texture -- but nothing tied it to the
    vocabulary it subsets, so it could drift silently like the other two did.
    """
    import re
    from pathlib import Path

    from asset_farm.brief import CATEGORIES

    source = (
        Path(__file__).resolve().parents[3]
        / "services" / "brain" / "agents" / "content_designer.py"
    ).read_text(encoding="utf-8")
    match = re.search(r'"enum": \[((?:\s*"[a-z_]+",?)+)\]', source)
    assert match, "the content designer's category enum moved or changed shape"
    declared = set(re.findall(r'"([a-z_]+)"', match.group(1)))
    assert declared <= set(CATEGORIES), (
        f"content designer offers {sorted(declared - set(CATEGORIES))}, "
        f"which AssetBrief rejects"
    )
