"""collect_n: the second win condition, and the first real choice the brain has.

The spatial spine (entry -> ... -> locked door -> exit) is unchanged; the collect
quest simply REPLACES the key zone as what unlocks the door. So every existing
reachability guarantee still holds and only the GOAL differs: "gather 5 relics"
instead of "walk into the key room".

The dangerous failure here is a quest that builds perfectly and cannot be won —
asking for more relics than exist, or hiding them behind the very door they open.
Gate 5 must refuse both.
"""

import copy
import json
from pathlib import Path

import pytest
from godot_client.project_writer import write_project
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan
from validators.gates import collect_quest_of, run_gates

REPO = Path(__file__).resolve().parents[3]
TEMPLATES = REPO / "engine" / "templates"
SCHEMA = json.loads((REPO / "contracts" / "game_spec.schema.json").read_text(encoding="utf-8"))
BASE = json.loads(
    (REPO / "contracts" / "examples" / "golden_game.spec.json").read_text(encoding="utf-8")
)


def _relic_hunt(count: int = 5, required: int = 3) -> dict:
    spec = copy.deepcopy(BASE)
    spec["objectives"] = [
        {
            "objective_id": "collect_relics",
            "objective_template_id": "collect_n",
            "params": {"required_count": required, "label": "Relics"},
            "is_win_condition": False,
        },
        BASE["objectives"][-1],
    ]
    spec["entities"]["props"] = spec["entities"]["props"][:5] + [
        {
            "prop_id": f"relic_{i}",
            "interactable_template_id": "pickup_supply",
            "placement_tags": ["loot"],
            "asset_brief": {
                "brief": "a glowing relic shard",
                "category": "prop",
                "tri_budget": 600,
            },
        }
        for i in range(count)
    ]
    return spec


def test_quest_replaces_the_key_zone_and_reuses_the_door_wiring(tmp_path):
    spec = _relic_hunt()
    plan = to_level_plan(run_pcg(spec))
    write_project(
        plan,
        "Relic Hunt",
        tmp_path,
        templates_dir=TEMPLATES,
        collect_quest=collect_quest_of(spec),
    )
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")

    assert '[node name="CollectQuest"' in scene
    assert '[node name="KeyZone"' not in scene  # the relics ARE the key
    # The door and win zone are gated on the quest, not on reach_key...
    assert 'unlocked_by_objective = "collect_relics"' in scene
    assert 'requires_objective = "collect_relics"' in scene
    # ...and the locked door itself still exists (the spine is untouched).
    assert '[node name="LockedDoor"' in scene

    # Every pickup is a scripted Area3D wired to the quest.
    assert scene.count('script = ExtResource("9_pickup")') == 5
    assert scene.count('signal="collected"') == 5
    assert 'signal="progress_changed"' in scene  # HUD counter
    assert 'collect_label = "Relics"' in scene

    copied = {p.name for p in (tmp_path / "templates").rglob("*.gd")}
    assert {"collect_n.gd", "pickup_collectible.gd"} <= copied


def test_reach_zone_games_are_completely_unchanged(tmp_path):
    """No collect quest -> the classic key chain, byte for byte."""
    plan = to_level_plan(run_pcg(BASE))
    write_project(plan, "Golden", tmp_path, templates_dir=TEMPLATES, collect_quest=None)
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    assert '[node name="KeyZone"' in scene
    assert '[node name="CollectQuest"' not in scene
    assert 'unlocked_by_objective = "reach_key"' in scene
    assert "collect_label" not in scene


@pytest.mark.parametrize(
    ("count", "required"),
    [(0, 3), (2, 3), (5, 0)],  # no relics / too few relics / a quest demanding nothing
)
def test_gate5_refuses_an_unwinnable_quest(count, required):
    """It would build and run perfectly — and the door would never open."""
    spec = _relic_hunt(count=count, required=required)
    plan = to_level_plan(run_pcg(spec))
    report = run_gates(spec, plan, schema=SCHEMA, build_result=None)
    assert report["verdict"] == "FAIL"
    assert "COLLECT_QUEST_IMPOSSIBLE" in [e["code"] for e in report["errors"]]


def test_gate5_passes_a_properly_authored_relic_hunt():
    spec = _relic_hunt(count=5, required=3)
    plan = to_level_plan(run_pcg(spec))
    report = run_gates(spec, plan, schema=SCHEMA, build_result=None)
    assert report["verdict"] == "PASS", [e["code"] for e in report["errors"]]
    placed = [e for e in plan["entities"] if e["source_id"].startswith("relic_")]
    assert len(placed) >= 3
