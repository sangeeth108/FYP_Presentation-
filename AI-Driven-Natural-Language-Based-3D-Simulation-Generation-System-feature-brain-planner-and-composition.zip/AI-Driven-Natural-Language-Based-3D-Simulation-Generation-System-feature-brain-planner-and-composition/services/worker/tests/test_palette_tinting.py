"""An untextured curated model's flat colours may follow the planner's palette.

The vendored nature pack's foliage is a stylized mint -- measured, 24 of 30 tree models
carry leaf rgb [0.16, 0.79, 0.67]. Cohesive, and not what a temperate forest looks like;
once the wrong `metallicFactor = 1` was corrected and the colour was no longer muted, a
wood of neon-cyan trees came out.

Tinting is lossless exactly where it is applied: a model with no images has one
`baseColorFactor` per material and no texture to fight.
"""

import json
import struct
from pathlib import Path

from godot_client.simulation_project_writer import (
    _copy_asset,
    _linear_to_srgb,
    _palette_tag,
)

KITS = Path(__file__).resolve().parents[3] / "content" / "kits"
FOREST = ["#2E7D32", "#5D4037"]  # foliage green, bark brown


def _materials(glb: Path) -> list[dict]:
    raw = glb.read_bytes()
    length = struct.unpack("<I", raw[12:16])[0]
    return json.loads(raw[20 : 20 + length]).get("materials") or []


def test_each_material_keeps_its_role(tmp_path: Path) -> None:
    """Leaves take the green and bark takes the brown, by nearest hue."""
    source = KITS / "kenney-nature/models/tree_oak.glb"
    assert source.is_file()
    out = tmp_path / "tree.glb"
    _copy_asset(source, out, palette=FOREST)

    by_name = {m["name"]: m["pbrMetallicRoughness"]["baseColorFactor"] for m in _materials(out)}
    # `baseColorFactor` is LINEAR (glTF 2.0) and a hex colour is sRGB. Writing the sRGB
    # number straight in made every tint about six times too bright: #2E7D32, a deep
    # forest green, rendered as pastel mint.
    leaves = [round(_linear_to_srgb(c) * 255) for c in by_name["leafsGreen"][:3]]
    bark = [round(_linear_to_srgb(c) * 255) for c in by_name["woodBark"][:3]]
    assert leaves == [46, 125, 50]  # #2E7D32
    assert bark == [93, 64, 55]  # #5D4037
    # Not flattened to one colour: the material split the artist made survives.
    assert leaves != bark


def test_no_palette_leaves_the_colours_alone(tmp_path: Path) -> None:
    source = KITS / "kenney-nature/models/tree_oak.glb"
    out = tmp_path / "plain.glb"
    _copy_asset(source, out)
    leaves = _materials(out)[0]["pbrMetallicRoughness"]["baseColorFactor"]
    assert [round(c, 2) for c in leaves[:3]] == [0.16, 0.79, 0.67]


def test_the_transfer_function_round_trips() -> None:
    from godot_client.simulation_project_writer import _srgb_to_linear

    for value in (0.0, 0.02, 0.18, 0.5, 1.0):
        assert abs(_linear_to_srgb(_srgb_to_linear(value)) - value) < 1e-9
    # A mid grey is much darker in linear space; this is the factor that was missing.
    assert _srgb_to_linear(0.18) < 0.04


def test_a_textured_model_is_never_repainted(tmp_path: Path) -> None:
    """A texture was authored deliberately; it is not ours to override."""
    document = {
        "asset": {"version": "2.0"},
        "images": [{"uri": "wood.png"}],
        "textures": [{"source": 0}],
        "materials": [
            {
                "name": "painted",
                "pbrMetallicRoughness": {
                    "baseColorFactor": [0.9, 0.9, 0.9, 1],
                    "baseColorTexture": {"index": 0},
                },
            }
        ],
    }
    body = json.dumps(document, separators=(",", ":")).encode()
    body += b" " * ((4 - len(body) % 4) % 4)
    source = tmp_path / "textured.glb"
    source.write_bytes(
        b"glTF"
        + struct.pack("<I", 2)
        + struct.pack("<I", 20 + len(body))
        + struct.pack("<I", len(body))
        + b"JSON"
        + body
    )
    out = tmp_path / "copied.glb"
    _copy_asset(source, out, palette=FOREST)
    kept = _materials(out)[0]["pbrMetallicRoughness"]["baseColorFactor"]
    assert [round(c, 2) for c in kept[:3]] == [0.9, 0.9, 0.9]


def test_the_palette_is_part_of_the_filename() -> None:
    """Two entities sharing a model but asking for different colours must not collide."""
    assert _palette_tag(None) == ""
    assert _palette_tag([]) == ""
    green, blue = _palette_tag(FOREST), _palette_tag(["#0000FF"])
    assert green and blue and green != blue
    assert _palette_tag(FOREST) == green  # stable across calls
