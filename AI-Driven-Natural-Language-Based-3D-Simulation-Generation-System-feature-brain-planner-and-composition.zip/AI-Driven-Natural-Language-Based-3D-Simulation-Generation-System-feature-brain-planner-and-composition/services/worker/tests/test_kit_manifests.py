"""A pack describes itself, so the library grows by adding files.

`MODEL_DESCRIPTIONS` was a hand-written dict of 29 entries, and that is exactly why it
stayed 29: adding a pack meant editing source. Measured consequence -- the library owned
no building at all, so a village's dwellings resolved to `banner_red`, a hanging cloth
banner, and shipped as flat panels.
"""

import json

import pytest

from godot_client.asset_kit import (
    KITS_DIR,
    MANIFEST_CATEGORIES,
    MODEL_DESCRIPTIONS,
    MODEL_PROVENANCE,
    _load_pack_manifests,
    model_category,
)

VALID_CATEGORIES = {"character", "prop", "building_module"}


def test_the_vendored_packs_are_loaded():
    assert len(MODEL_DESCRIPTIONS) > 500, "the vendored packs should dominate the library"
    assert MODEL_PROVENANCE, "a vendored model must record where it came from"


def test_every_vendored_model_declares_a_permissive_licence():
    """Rule 12: nothing enters the product path without a logged licence."""
    licences = {entry["licence"] for entry in MODEL_PROVENANCE.values()}
    assert licences, "no provenance recorded"
    for licence in licences:
        assert licence in {"CC0-1.0", "MIT", "Apache-2.0"}, licence


def test_every_declared_category_is_one_the_pipeline_understands():
    # The candidate filter compares equality, so an invented category would match
    # nothing and the models would be silently unreachable.
    assert set(MANIFEST_CATEGORIES.values()) <= VALID_CATEGORIES


def test_buildings_and_weapons_both_exist_now():
    """The two gaps that produced visible defects: no building, and no gun."""
    architecture = [r for r in MODEL_DESCRIPTIONS if model_category(r) == "building_module"]
    guns = [r for r, t in MODEL_DESCRIPTIONS.items() if t.startswith("a gun")]
    assert len(architecture) > 50
    assert len(guns) >= 10


def test_a_manifest_entry_wins_over_the_hand_written_dict(tmp_path):
    pack = tmp_path / "demo-pack"
    (pack / "models").mkdir(parents=True)
    (pack / "models" / "thing.glb").write_bytes(b"glTF-stub")
    (pack / "kit.json").write_text(
        json.dumps(
            {
                "pack": "demo-pack",
                "licence": "CC0-1.0",
                "models": {"models/thing.glb": {"description": "a demo thing", "category": "prop"}},
            }
        ),
        encoding="utf-8",
    )
    found = _load_pack_manifests(tmp_path)
    assert found["demo-pack/models/thing.glb"] == "a demo thing"


def test_a_manifest_listing_a_model_nobody_vendored_is_ignored(tmp_path):
    """Otherwise the matcher could choose it and the resolver would fail on a missing
    path -- a broken run instead of a merely absent model."""
    pack = tmp_path / "ghost-pack"
    (pack / "models").mkdir(parents=True)
    (pack / "kit.json").write_text(
        json.dumps(
            {
                "pack": "ghost-pack",
                "licence": "CC0-1.0",
                "models": {"models/absent.glb": {"description": "a model nobody shipped"}},
            }
        ),
        encoding="utf-8",
    )
    assert _load_pack_manifests(tmp_path) == {}


def test_a_broken_manifest_does_not_stop_the_worker(tmp_path):
    """Dropping in a bad pack must not take the whole asset farm down."""
    pack = tmp_path / "broken-pack"
    pack.mkdir(parents=True)
    (pack / "kit.json").write_text("{ this is not json", encoding="utf-8")
    assert _load_pack_manifests(tmp_path) == {}


def test_every_vendored_file_on_disk_is_actually_described():
    """A model nobody described is invisible to the matcher -- shipped weight that can
    never be chosen."""
    for manifest_path in KITS_DIR.glob("*/kit.json"):
        pack = manifest_path.parent
        described = set(json.loads(manifest_path.read_text(encoding="utf-8"))["models"])
        on_disk = {
            f"models/{path.name}" for path in (pack / "models").glob("*.glb")
        }
        assert on_disk - described == set(), f"{pack.name} has undescribed models"


@pytest.mark.parametrize("licence_file", sorted(KITS_DIR.glob("*/LICENSE.txt")))
def test_each_vendored_pack_keeps_its_licence_text(licence_file):
    text = licence_file.read_text(encoding="utf-8", errors="replace").lower()
    assert "cc0" in text or "creative commons zero" in text or "public domain" in text
