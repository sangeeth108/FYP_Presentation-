import json
import os
import re
from pathlib import Path

import pytest
from godot_client.exporter import SERENDIB_HEAD_INCLUDE, export_web, write_export_preset
from godot_client.project_writer import ProjectWriterError, write_project
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan

REPO = Path(__file__).resolve().parents[3]
GOLDEN_SPEC = REPO / "contracts" / "examples" / "golden_game.spec.json"
TEMPLATES_DIR = REPO / "engine" / "templates"
MAX_WEB_BUILD_BYTES = 90 * 1024 * 1024


def test_web_preset_carries_serendib_browser_branding(tmp_path):
    preset = write_export_preset(tmp_path).read_text(encoding="utf-8")
    assert "data-serendib-brand" in preset
    assert "Serendib Engine" in preset
    assert "#25a99a" in preset
    assert SERENDIB_HEAD_INCLUDE.startswith("<meta")


@pytest.fixture(scope="module")
def golden_plan():
    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    return to_level_plan(run_pcg(spec))


def test_template_attachment_adds_win_zone(golden_plan, tmp_path):
    written = write_project(golden_plan, "T", tmp_path, templates_dir=TEMPLATES_DIR)
    assert (tmp_path / "templates" / "objectives" / "reach_zone.gd").is_file()

    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    assert 'path="res://templates/objectives/reach_zone.gd"' in scene
    assert '[node name="WinZone" type="Area3D"' in scene
    # load_steps must still be exact with the ext_resource + extra shape.
    defined = set(re.findall(r'\[sub_resource type="[^"]+" id="([^"]+)"\]', scene))
    ext_count = scene.count('[ext_resource type="Script"')
    load_steps = int(re.search(r"load_steps=(\d+)", scene).group(1))
    assert load_steps == len(defined) + ext_count + 1
    assert any(p.name == "reach_zone.gd" for p in written)


def test_player_is_emitted_with_controller_and_input_map(golden_plan, tmp_path):
    write_project(
        golden_plan, "T", tmp_path, templates_dir=TEMPLATES_DIR,
        player_config={"move_speed": 4, "health": 5},
    )
    assert (tmp_path / "templates" / "controllers" / "controller_third_person.gd").is_file()

    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    assert '[node name="Player" type="CharacterBody3D" parent="." groups=["player"]]' in scene
    assert 'path="res://templates/controllers/controller_third_person.gd"' in scene
    assert "move_speed = 4" in scene
    assert "health = 5" in scene
    assert '[node name="PlayerCamera" type="Camera3D" parent="Player/SpringArm3D"]' in scene
    # Only the player camera may be current.
    preview = re.search(r'\[node name="PreviewCamera"[^\[]+', scene).group(0)
    assert "current = true" not in preview

    project = (tmp_path / "project.godot").read_text(encoding="utf-8")
    for action in (
        "move_forward", "move_back", "move_left", "move_right", "jump", "sprint", "interact"
    ):
        assert f"{action}={{" in project


def test_camera_rig_follows_controller_template(golden_plan, tmp_path):
    cases = {
        "controller_third_person": 'parent="Player/SpringArm3D"',
        "controller_topdown_3d": "0.422618",  # -65° pitch basis row value
        "controller_isometric_3d": "0.707107",  # 45° yaw basis row value
    }
    for controller_id, marker in cases.items():
        out = tmp_path / controller_id
        write_project(
            golden_plan, "T", out, templates_dir=TEMPLATES_DIR,
            player_config={"controller_template_id": controller_id, "health": 5},
        )
        scene = (out / "main.tscn").read_text(encoding="utf-8")
        camera = re.search(r'\[node name="PlayerCamera"[^\[]+', scene).group(0)
        assert marker in camera or marker in scene.split('name="PlayerCamera"')[0], controller_id
        assert re.search(r'\[node name="Player" type="CharacterBody3D"[^\[]+', scene)
        assert f'templates/controllers/{controller_id}.gd' in scene
        assert (out / "templates" / "controllers" / f"{controller_id}.gd").is_file()
        if controller_id != "controller_third_person":
            assert "SpringArm3D" not in scene
            assert marker in camera


def test_lighting_presets_change_the_scene(golden_plan, tmp_path):
    write_project(golden_plan, "T", tmp_path / "moon", lighting_preset="moonlit_night")
    moon = (tmp_path / "moon" / "main.tscn").read_text(encoding="utf-8")
    assert "fog_enabled = true" in moon
    assert "background_color = Color(0.05, 0.07, 0.15, 1)" in moon
    assert 'material_override = SubResource("MatFloor")' in moon
    assert 'material_override = SubResource("MatWall")' in moon

    write_project(golden_plan, "T", tmp_path / "sun", lighting_preset="sunny_bright")
    sun = (tmp_path / "sun" / "main.tscn").read_text(encoding="utf-8")
    assert "fog_enabled" not in sun
    assert "light_energy = 1.3" in sun
    assert moon != sun


def test_unknown_lighting_preset_is_machine_readable(golden_plan, tmp_path):
    with pytest.raises(ProjectWriterError) as exc:
        write_project(golden_plan, "T", tmp_path, lighting_preset="disco_rave")
    assert exc.value.code == "lighting_preset_unknown"


def test_unknown_controller_is_machine_readable(golden_plan, tmp_path):
    with pytest.raises(ProjectWriterError) as exc:
        write_project(
            golden_plan, "T", tmp_path, templates_dir=TEMPLATES_DIR,
            player_config={"controller_template_id": "controller_vr"},
        )
    assert exc.value.code == "controller_unknown"


def test_without_templates_preview_camera_is_current(golden_plan, tmp_path):
    write_project(golden_plan, "T", tmp_path)
    scene = (tmp_path / "main.tscn").read_text(encoding="utf-8")
    preview = re.search(r'\[node name="PreviewCamera"[^\[]+', scene).group(0)
    assert "current = true" in preview
    assert "[node name=\"Player\"" not in scene


def test_missing_template_dir_is_machine_readable(golden_plan, tmp_path):
    with pytest.raises(ProjectWriterError) as exc:
        write_project(golden_plan, "T", tmp_path, templates_dir=tmp_path / "nope")
    assert exc.value.code == "template_missing"


def test_export_preset_has_web_compatibility_flags(tmp_path):
    write_export_preset(tmp_path)
    preset = (tmp_path / "export_presets.cfg").read_text(encoding="utf-8")
    assert "variant/thread_support=false" in preset
    assert "vram_texture_compression/for_desktop=false" in preset
    assert "vram_texture_compression/for_mobile=false" in preset
    assert 'export_path="build/index.html"' in preset


def test_export_preset_can_include_a_matching_desktop_artifact(tmp_path):
    write_export_preset(tmp_path, desktop_platform="Windows Desktop")
    preset = (tmp_path / "export_presets.cfg").read_text(encoding="utf-8")
    assert 'name="Desktop"' in preset
    assert 'platform="Windows Desktop"' in preset
    assert 'export_path="build/desktop/serendib_simulation.exe"' in preset


@pytest.mark.skipif(
    not os.environ.get("GODOT_BIN"), reason="live export needs GODOT_BIN (local only)"
)
def test_live_end_to_end_spec_to_web_build(golden_plan, tmp_path):
    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    write_project(
        golden_plan, "Castle Gate Trial (generated)", tmp_path, TEMPLATES_DIR,
        player_config=spec["player"],
    )
    result = export_web(tmp_path, Path(os.environ["GODOT_BIN"]))
    names = {p.name for p in result["files"]}
    assert "index.html" in names
    assert any(n.endswith(".wasm") for n in names)
    assert any(n.endswith(".pck") for n in names)
    assert 0 < result["total_bytes"] <= MAX_WEB_BUILD_BYTES


def test_a_missing_template_is_an_environment_fault_not_a_world_defect(tmp_path, monkeypatch):
    """The host lacking a template must not read as a defect in the simulation.

    A run whose world was sound but whose machine had no desktop templates
    reported `serendib_desktop_export_failed`, which sends someone to debug the
    generated world instead of installing a template. The run is unreleasable
    either way; only the diagnosis changes.
    """
    import subprocess as _sp

    from godot_client import exporter as ex

    engine_output = (
        'Project export for preset "Desktop" failed due to configuration errors:\n'
        "No export template found at the expected path:\n"
        "C:/templates/4.7.stable/windows_debug_x86_64.exe\n"
        "No export template found at the expected path:\n"
        "C:/templates/4.7.stable/windows_release_x86_64.exe\n"
    )

    def fake_run(*args, **kwargs):
        return _sp.CompletedProcess(args=args, returncode=1, stdout="", stderr=engine_output)

    monkeypatch.setattr(ex.subprocess, "run", fake_run)

    with pytest.raises(ProjectWriterError) as excinfo:
        ex.export_desktop(tmp_path, Path("godot"))

    error = excinfo.value
    assert error.code == "desktop_export_template_not_installed"
    assert "windows_debug_x86_64.exe" in error.path
    assert "windows_release_x86_64.exe" in error.path
    assert "not evaluated" in error.message


def test_a_genuine_export_failure_still_reports_as_one(tmp_path, monkeypatch):
    """Only the missing-template case is reclassified; real failures are untouched."""
    import subprocess as _sp

    from godot_client import exporter as ex

    def fake_run(*args, **kwargs):
        return _sp.CompletedProcess(
            args=args, returncode=1, stdout="", stderr="Scene failed to load: main.tscn"
        )

    monkeypatch.setattr(ex.subprocess, "run", fake_run)

    with pytest.raises(ProjectWriterError) as excinfo:
        ex.export_desktop(tmp_path, Path("godot"))
    assert excinfo.value.code == "serendib_desktop_export_failed"
