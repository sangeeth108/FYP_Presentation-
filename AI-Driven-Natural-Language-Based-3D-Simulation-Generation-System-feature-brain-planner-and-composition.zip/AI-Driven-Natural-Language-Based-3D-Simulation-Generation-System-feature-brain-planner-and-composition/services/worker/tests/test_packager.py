import json
import zipfile
from pathlib import Path

import pytest
from godot_client.exporter import write_export_preset
from godot_client.packager import package_project
from godot_client.project_writer import write_project
from pcg.pipeline import run_pcg
from pcg.serialize import to_level_plan

REPO = Path(__file__).resolve().parents[3]
GOLDEN_SPEC = REPO / "contracts" / "examples" / "golden_game.spec.json"
TEMPLATES_DIR = REPO / "engine" / "templates"


@pytest.fixture(scope="module")
def project(tmp_path_factory):
    spec = json.loads(GOLDEN_SPEC.read_text(encoding="utf-8"))
    plan = to_level_plan(run_pcg(spec))
    out = tmp_path_factory.mktemp("proj")
    write_project(plan, "Castle Gate Trial", out, templates_dir=TEMPLATES_DIR)
    write_export_preset(out)
    (out / "build").mkdir()
    (out / "build" / "index.wasm").write_bytes(b"\x00" * 64)  # must be excluded
    (out / ".godot").mkdir()
    (out / ".godot" / "cache.bin").write_bytes(b"\x00")  # must be excluded
    return out


def test_zip_contains_sources_and_readme_but_no_build(project, tmp_path):
    zip_path = package_project(project, tmp_path / "project.zip", "Castle Gate Trial")
    names = set(zipfile.ZipFile(zip_path).namelist())
    assert {"README.md", "project.godot", "main.tscn", "export_presets.cfg"} <= names
    assert "templates/objectives/reach_zone.gd" in names
    assert "templates/controllers/controller_third_person.gd" in names
    assert not any(n.startswith(("build/", ".godot/")) for n in names)

    readme = zipfile.ZipFile(zip_path).read("README.md").decode()
    assert "Castle Gate Trial" in readme
    assert "project.godot" in readme


def test_zip_is_byte_stable(project, tmp_path):
    a = package_project(project, tmp_path / "a.zip", "T")
    b = package_project(project, tmp_path / "b.zip", "T")
    assert a.read_bytes() == b.read_bytes()


def test_unzipped_project_round_trips(project, tmp_path):
    zip_path = package_project(project, tmp_path / "project.zip", "T")
    dest = tmp_path / "unzipped"
    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(dest)
    # The downloaded project must be openable: config + scene intact.
    assert (dest / "project.godot").read_text(encoding="utf-8").startswith(";")
    scene = (dest / "main.tscn").read_text(encoding="utf-8")
    assert scene.startswith("[gd_scene")
    assert 'name="Player"' in scene
