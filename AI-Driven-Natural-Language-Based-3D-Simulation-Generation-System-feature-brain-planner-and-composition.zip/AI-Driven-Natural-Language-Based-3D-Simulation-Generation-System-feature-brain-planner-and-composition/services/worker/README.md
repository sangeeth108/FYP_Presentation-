# services/worker — GPU pull-worker (RTX 5090)

**What this is:** the daemon on the GPU workstation that does all heavy work. It **pulls** jobs from the cloud queue over an outbound-only tunnel (Cloudflare Tunnel/Tailscale) and streams progress back. It never opens an inbound port.

**Layout:**

| Folder | Purpose | Owner |
|---|---|---|
| `llm_gateway/` | vLLM/Ollama client, guided decoding (xgrammar) calls, model mode scheduler (plan → assets → validation VRAM time-slicing) | M2 |
| `asset_farm/` | Asset resolution decision tree (cache → curated → generate → QA → fallback); SDXL → TRELLIS.2 → Blender-headless pipelines; Stable Audio SFX; style anchors | M4 |
| `godot_client/` | Project writer (spec → scenes/scripts/presets), headless Serendib import/export driver | M3 |
| `bots/` | Playtest bots (GreedyObjectiveBot, ChaosBot) reading state via debug singleton — never vision | M4 |
| `validators/` | Gates 3–7 of the validation stack (asset QA, import/export, static playability solvers, dynamic, quality) | M4 |
| `tests/` | Unit tests with recorded fixtures (no GPU in CI) | All |

**When updated:** pipeline changes → `docs/GENERATION_PIPELINE.md`; new models → `docs/licensing_ledger.csv` **before first use**.

**Status:** placeholder. First real task is P1 (godot_client project writer + export); llm_gateway lands in P2; asset_farm in P3.

**Common mistakes to avoid:**
- Assuming model co-residency — 32 GB VRAM forces sequencing; OOM = scheduling bug.
- Generating an asset when a cache/curated hit exists — check first (cost + coherence).
- Vision-based bot checks — state-reading only (GlitchBench justification).
- Skipping the budget gate — every mesh capped (tris/textures), every build ≤90 MB.
