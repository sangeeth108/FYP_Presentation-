"""P3 surface synthesis: deterministic triplanar materials, no texture files.

Everything the native writer owns rendered as flat colour. The ground -- the
largest surface on screen -- carried no material at all and drew as default
white; paths were one brown constant. Nothing had a surface.

This synthesises a StandardMaterial3D whose albedo is a seamless FastNoiseLite
tinted by a vetted palette colour, projected triplanar. Triplanar matters: the
ground is a BoxMesh and the procedural forms carry no TEXCOORD_0, so anything
depending on UVs would sample nothing. Godot builds the noise at load, so this
costs no texture files, no GPU time in the farm, and no bytes against the 90 MB
web budget.

`lighting.py` already uses exactly this technique for the deprecated writer's
dungeon floors and walls. This is that idea as a reusable module the native
simulation writer can share.

Rule 15 applied to surfaces: the planner NAMES a family from a closed set
(ambiguity up), and this module alone decides what a name looks like
(determinism down). There is deliberately NO mapping from the open-vocabulary
`environment.terrain` string to a colour -- that is the noun-ceiling mistake
`procedural.py` documents, where "teak" resolves and "dipterocarp" does not. A
surface nobody named gets the neutral default and an approximation record
saying so, rather than a guess presented as the requested surface.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass

# The synthesis tier's own version. Bump when the generated material changes, so
# a render can be traced to the rule that produced it.
SYNTHESIS_VERSION = "triplanar_noise_v1"


@dataclass(frozen=True)
class SurfaceFamily:
    """One vetted surface: a tint, how rough it is, and how big its grain reads.

    `uv_scale` is in world metres per noise tile. Ground wants a large tile so a
    200 m field does not shimmer into moire; a path wants a smaller one because
    it is looked at from three metres away.
    """

    name: str
    albedo: tuple[float, float, float]
    roughness: float
    uv_scale: float
    noise_frequency: float
    metallic: float = 0.0


# The closed set. Small on purpose: every entry is a surface someone chose, and
# adding one is a deliberate act, not a reaction to a prompt that used a new noun.
SURFACE_FAMILIES: dict[str, SurfaceFamily] = {
    "grass": SurfaceFamily("grass", (0.29, 0.42, 0.21), 0.97, 0.09, 0.055),
    "soil": SurfaceFamily("soil", (0.36, 0.28, 0.18), 0.96, 0.11, 0.05),
    "sand": SurfaceFamily("sand", (0.76, 0.68, 0.47), 0.94, 0.13, 0.07),
    "stone": SurfaceFamily("stone", (0.45, 0.45, 0.43), 0.90, 0.07, 0.045),
    "concrete": SurfaceFamily("concrete", (0.55, 0.55, 0.53), 0.88, 0.06, 0.04),
    "snow": SurfaceFamily("snow", (0.86, 0.89, 0.93), 0.80, 0.10, 0.06),
    "wood": SurfaceFamily("wood", (0.45, 0.31, 0.18), 0.85, 0.08, 0.05),
    "metal": SurfaceFamily("metal", (0.38, 0.40, 0.44), 0.45, 0.05, 0.04, metallic=0.65),
    # Trodden earth, distinct from open soil so a path still reads as a path.
    "path": SurfaceFamily("path", (0.38, 0.30, 0.20), 0.95, 0.06, 0.06),
    # What an unnamed surface gets. Deliberately unremarkable: it must not
    # flatter a world into looking deliberate when nothing chose it.
    "unspecified": SurfaceFamily("unspecified", (0.42, 0.43, 0.40), 0.93, 0.09, 0.05),
}

DEFAULT_FAMILY = "unspecified"
GROUND_MATERIAL_ID = "SurfaceGround"
PATH_MATERIAL_ID = "SurfacePath"
_NOISE_ID = "SurfaceNoise"
_NOISE_TEXTURE_ID = "SurfaceNoiseTex"
_RAMP_ID = "SurfaceRamp"
# Raw FastNoiseLite spans black to white, and multiplying a tint by that made the
# ground read as mottled camouflage rather than soil -- visible immediately in a
# render, invisible in the .tscn. The ramp compresses it to a modulation, which
# is the same restraint `asset_farm/surface_texture.py` applies to baked grain.
_RAMP_FLOOR = 0.82


def resolve_ground_family(environment: dict) -> tuple[str, str | None]:
    """Which family the ground uses, and why if it is not what was asked for.

    Reads only `environment.terrain_surface`, the closed enum the planner fills.
    The free-text `environment.terrain` is NOT consulted: matching words in it
    would resolve "grassy meadow" and silently miss "machair", which is the
    ceiling this module exists to avoid.

    Returns `(family, approximation_reason)`. The reason is None when the
    planner named a family this module knows.
    """
    named = environment.get("terrain_surface")
    terrain = str(environment.get("terrain") or "").strip()
    detail = f" for terrain {terrain!r}" if terrain else ""

    if named == DEFAULT_FAMILY:
        # A decision, not an omission -- but the ground still renders neutral,
        # and that is user-visible, so it is still an approximation.
        return DEFAULT_FAMILY, (
            f"the ground was declared {DEFAULT_FAMILY}{detail}, so it renders "
            f"neutral rather than as a named surface"
        )
    if named in SURFACE_FAMILIES:
        return named, None
    if named:
        return (
            DEFAULT_FAMILY,
            f"terrain surface {named!r} is not a synthesised family; "
            f"the neutral default was used instead",
        )
    return (
        DEFAULT_FAMILY,
        f"no terrain surface was named{detail}; the neutral default was used",
    )


def noise_seed(spec: dict) -> int:
    """A stable 31-bit noise seed for one simulation (rule 14: seed everything).

    Derived from the spec's own seed and id so re-running a spec reproduces the
    same grain, and two different worlds do not share one.
    """
    meta = spec.get("meta") or {}
    material = f"{meta.get('seed', 0)}:{meta.get('simulation_id', '')}"
    digest = hashlib.sha256(material.encode("utf-8")).hexdigest()
    return int(digest[:8], 16) & 0x7FFFFFFF


def _color(rgb: tuple[float, float, float]) -> str:
    return f"Color({rgb[0]:g}, {rgb[1]:g}, {rgb[2]:g}, 1)"


def family_albedo(name: str) -> tuple[float, float, float]:
    """The vetted tint for a family name, falling back to the neutral default.

    Exposed so the writer can build the ground's region palette without keeping a
    second table. Rule 15 holds either way: the planner names a family and this
    module remains the only place that decides what a name looks like.
    """
    family = SURFACE_FAMILIES.get(name) or SURFACE_FAMILIES[DEFAULT_FAMILY]
    return family.albedo


def _material_block(
    resource_id: str, family: SurfaceFamily, *, vertex_tinted: bool = False
) -> str:
    # With regions, the tint moves from the material to the mesh: every ground
    # vertex carries its own family colour and the material multiplies by it, so
    # one surface holds several materials without a shader, a splat texture, or
    # anything GL Compatibility cannot draw.
    #
    # Only when regions actually painted something. Turning it on unconditionally
    # would be the ADR-0010 defect again: a flat world's ground is a BoxMesh with
    # no COLOR array, vertex colour defaults to white, and every such world would
    # go back to drawing default white.
    return (
        f'[sub_resource type="StandardMaterial3D" id="{resource_id}"]\n'
        + ("vertex_color_use_as_albedo = true\n" if vertex_tinted else "")
        + (
            "albedo_color = Color(1, 1, 1, 1)\n"
            if vertex_tinted
            else f"albedo_color = {_color(family.albedo)}\n"
        )
        + f'albedo_texture = SubResource("{_NOISE_TEXTURE_ID}")\n'
        "uv1_triplanar = true\n"
        f"uv1_scale = Vector3({family.uv_scale:g}, {family.uv_scale:g}, {family.uv_scale:g})\n"
        f"roughness = {family.roughness:g}\n"
        + (f"metallic = {family.metallic:g}\n" if family.metallic else "")
        + "\n"
    )


def surface_sub_resources(
    seed: int,
    ground_family: str,
    *,
    include_path: bool = True,
    vertex_tinted_ground: bool = False,
) -> str:
    """The .tscn sub-resource block: one shared noise, then one material each.

    The noise texture is shared by every material so the whole world reads as one
    surface treatment at different tints -- the same reason the asset farm shares
    a style anchor across a game's generated meshes.
    """
    family = SURFACE_FAMILIES.get(ground_family) or SURFACE_FAMILIES[DEFAULT_FAMILY]
    blocks = [
        f'[sub_resource type="FastNoiseLite" id="{_NOISE_ID}"]\n'
        "noise_type = 0\n"
        f"seed = {int(seed)}\n"
        f"frequency = {family.noise_frequency:g}\n"
        "fractal_octaves = 4\n\n",
        f'[sub_resource type="Gradient" id="{_RAMP_ID}"]\n'
        "offsets = PackedFloat32Array(0, 1)\n"
        f"colors = PackedColorArray({_RAMP_FLOOR:g}, {_RAMP_FLOOR:g}, "
        f"{_RAMP_FLOOR:g}, 1, 1, 1, 1, 1)\n\n",
        f'[sub_resource type="NoiseTexture2D" id="{_NOISE_TEXTURE_ID}"]\n'
        "seamless = true\n"
        "width = 256\n"
        "height = 256\n"
        f'color_ramp = SubResource("{_RAMP_ID}")\n'
        f'noise = SubResource("{_NOISE_ID}")\n\n',
        _material_block(
            GROUND_MATERIAL_ID, family, vertex_tinted=vertex_tinted_ground
        ),
    ]
    if include_path:
        blocks.append(_material_block(PATH_MATERIAL_ID, SURFACE_FAMILIES["path"]))
    return "".join(blocks)


def synthesis_record(ground_family: str, seed: int) -> dict:
    """What was synthesised, for the lineage record."""
    return {
        "version": SYNTHESIS_VERSION,
        "technique": "triplanar_noise",
        "ground_family": ground_family,
        "noise_seed": int(seed),
    }
