"""Wall generation: floor rasterization -> merged perimeter wall runs.

Rooms and corridor slabs are rasterized onto a 0.5-unit cell grid; a wall
run is emitted on every edge between a floor cell and the void. Because
corridor slabs overlap the rooms they connect, doorway gaps appear
automatically — no special-case geometry. Collinear edges merge into runs
so the scene stays lean.

Pure Python (unit-testable without Godot). Deterministic: iteration is in
sorted cell order. v0 limits: walls are elevation-blind between two floors
of different tiers (no cliff rails), and ramp corridors keep walls at
their base elevation.
"""

from __future__ import annotations

from dataclasses import dataclass

CELL = 0.5
# The horizontal run of every tier-crossing ramp. Lives here because BOTH the
# project writer (which builds the slab) and the navmesh (which must put walkable
# polygons on it) need the identical span — if they disagree, the ramp exists in
# the world but not in the navmesh, and the tiers silently become islands.
RAMP_RUN = 4.0
# Taller than one tier step (4.0) so tier-crossing ramps stay contained
# between their side walls instead of poking over them near the top.
WALL_HEIGHT = 5.0
WALL_THICKNESS = 0.2


@dataclass(frozen=True)
class WallRun:
    axis: str  # "x": run extends along x | "z": run extends along z
    x: float  # start corner (world units)
    z: float
    length: float
    elevation: float  # floor top the wall stands on


def _corridor_rects(
    corridor: dict, elevation: float
) -> list[tuple[float, float, float, float, float]]:
    """(x0, z0, w, d, elevation) per corridor segment — mirrors the slab geometry."""
    width = corridor["width"]
    rects = []
    points = corridor["points"]
    for i in range(len(points) - 1):
        (ax, az), (bx, bz) = points[i], points[i + 1]
        w = abs(bx - ax) + width
        d = abs(bz - az) + width
        x0 = min(ax, bx) - width / 2
        z0 = min(az, bz) - width / 2
        rects.append((x0, z0, w, d, elevation))
    return rects


def floor_rects(plan: dict) -> list[tuple[float, float, float, float, float]]:
    """All floor rectangles (corridors first, rooms last so room elevation wins)."""
    rooms = {r["zone_id"]: r for r in plan["rooms"]}
    rects: list[tuple[float, float, float, float, float]] = []
    for corridor in plan["corridors"]:
        base = rooms[corridor["a"]]["elevation"]
        rects.extend(_corridor_rects(corridor, base))
    for r in plan["rooms"]:
        rects.append((r["x"], r["z"], r["width"], r["depth"], r["elevation"]))
    return rects


def covered_cells(
    rects: list[tuple[float, float, float, float, float]],
) -> dict[tuple[int, int], float]:
    """Map of grid cell -> floor elevation (later rects override earlier)."""
    cells: dict[tuple[int, int], float] = {}
    for x0, z0, w, d, elevation in rects:
        i0, i1 = round(x0 / CELL), round((x0 + w) / CELL)
        j0, j1 = round(z0 / CELL), round((z0 + d) / CELL)
        for i in range(i0, i1):
            for j in range(j0, j1):
                cells[(i, j)] = elevation
    return cells


def wall_runs(plan: dict) -> list[WallRun]:
    """Merged wall runs on every floor/void boundary."""
    cells = covered_cells(floor_rects(plan))

    # edges[(axis, fixed_index, elevation)] = set of run indices along the edge line
    edges: dict[tuple[str, int, float], set[int]] = {}

    def add(axis: str, fixed: int, run: int, elevation: float) -> None:
        edges.setdefault((axis, fixed, elevation), set()).add(run)

    for (i, j), elevation in cells.items():
        if (i, j - 1) not in cells:
            add("x", j, i, elevation)  # wall line at z = j*CELL, spanning cell i
        if (i, j + 1) not in cells:
            add("x", j + 1, i, elevation)
        if (i - 1, j) not in cells:
            add("z", i, j, elevation)  # wall line at x = i*CELL, spanning cell j
        if (i + 1, j) not in cells:
            add("z", i + 1, j, elevation)

    runs: list[WallRun] = []
    for (axis, fixed, elevation), indices in sorted(edges.items()):
        ordered = sorted(indices)
        start = prev = ordered[0]
        spans = []
        for idx in ordered[1:]:
            if idx == prev + 1:
                prev = idx
                continue
            spans.append((start, prev))
            start = prev = idx
        spans.append((start, prev))
        for lo, hi in spans:
            length = (hi - lo + 1) * CELL
            if axis == "x":
                runs.append(WallRun("x", lo * CELL, fixed * CELL, length, elevation))
            else:
                runs.append(WallRun("z", fixed * CELL, lo * CELL, length, elevation))
    return runs


def ramp_geometry(plan: dict, corridor: dict) -> dict | None:
    """Where a tier-crossing corridor's ramp actually goes. None if it is flat.

    THE one source of truth, used by the project writer (which builds the slab)
    and the navmesh (which must put walkable polygons on it). If those two ever
    disagree, the ramp exists in the world but not in the navmesh, and the tiers
    silently become separate navigation islands.

    Two failures shaped this:
      * deriving the run from where the corridor crosses a room edge — which an
        L-shaped corridor often never does — gave a 1.5 rise over a 1.0 run: a
        56-degree face, unclimbable (Godot's floor limit is 45);
      * forcing the full run onto the leg touching the upper room — which can be
        1.0 long — made the slab overshoot the corridor and its foot FLOAT in the
        void outside any room, unreachable by anyone.

    So the ramp goes on the last leg that can actually hold a full RAMP_RUN, and
    the legs beyond it are raised to the upper elevation.
    """
    rooms = {r["zone_id"]: r for r in plan["rooms"]}
    e_a = rooms[corridor["a"]]["elevation"]
    e_b = rooms[corridor["b"]]["elevation"]
    if abs(e_a - e_b) < 1e-6:
        return None

    points = corridor["points"]
    upper_is_b = e_b > e_a
    upper_room = rooms[corridor["b"] if upper_is_b else corridor["a"]]
    order = list(range(len(points) - 1))  # legs from the LOWER room to the UPPER
    if not upper_is_b:
        order.reverse()

    def leg_length(k: int) -> float:
        (ax, az), (bx, bz) = points[k], points[k + 1]
        return abs(bx - ax) + abs(bz - az)

    long_enough = [k for k in reversed(order) if leg_length(k) >= RAMP_RUN]
    ramp_leg = long_enough[0] if long_enough else max(order, key=leg_length)

    # Orient the chosen leg from the lower side toward the upper room.
    a, b = points[ramp_leg], points[ramp_leg + 1]
    forward_along_points = order.index(ramp_leg) == 0 or upper_is_b
    # NOTE: this condition reduces to plain `upper_is_b` (both branches of the
    # inner conditional collapse into the `or`), which would make
    # `forward_along_points` dead. Left as-is deliberately: simplifying ramp
    # orientation belongs in its own reviewed change, not a lint pass.
    p_from, p_to = (
        (a, b) if (upper_is_b if forward_along_points else False) or upper_is_b else (b, a)
    )
    (fx, fz), (tx, tz) = p_from, p_to

    axis = "x" if fx != tx else "z"
    f_c, t_c = (fx, tx) if axis == "x" else (fz, tz)
    forward = t_c > f_c

    # The top is where the corridor enters the upper room, when that lies on this
    # leg; otherwise the leg's own far end (an inner corner).
    if axis == "x":
        edge = upper_room["x"] if forward else upper_room["x"] + upper_room["width"]
    else:
        edge = upper_room["z"] if forward else upper_room["z"] + upper_room["depth"]
    top = edge if min(f_c, t_c) <= edge <= max(f_c, t_c) else t_c

    foot = top - (RAMP_RUN if forward else -RAMP_RUN)
    foot = min(max(foot, min(f_c, t_c)), max(f_c, t_c))  # never leave the corridor

    return {
        "axis": axis,
        "foot": (foot, fz) if axis == "x" else (fx, foot),
        "top": (top, fz) if axis == "x" else (fx, top),
        "e_lo": min(e_a, e_b),
        "e_hi": max(e_a, e_b),
        "width": corridor["width"],
        "ramp_leg": ramp_leg,
        "order": order,  # legs after ramp_leg in this order sit at e_hi
    }
