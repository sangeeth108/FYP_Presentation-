"""Canonical WorldPlan -> editable Serendib project compiler.

Unlike the deprecated game writer, this compiler consumes measured canonical
transforms and data-only behavior graphs directly. It never accepts generated
scripts. The runtime interpreter and probe harness are fixed reviewed templates.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import shutil
from pathlib import Path

from godot_client.project_writer import (
    ProjectWriterError,
    _input_map_section,
    pascal_case,
)
from godot_client.surfaces import (
    GROUND_MATERIAL_ID,
    PATH_MATERIAL_ID,
    family_albedo,
    noise_seed,
    resolve_ground_family,
    surface_sub_resources,
)

_REPO = Path(__file__).resolve().parents[3]
_BRANDING = _REPO / "engine" / "serendib" / "branding"
_RUNTIME = _REPO / "engine" / "templates" / "simulation"
_ASSIST = _REPO / "engine" / "serendib" / "assist"
_REQUIRED_RUNTIME = (
    "simulation_runtime.gd",
    "simulation_controller.gd",
    "simulation_agent.gd",
    "capability_state_machine.gd",
    "scatter_field.gd",
    # Immersive delivery ships in the SAME project as the flat build: the script
    # builds an XR rig at load only if an interface initialises, and disables
    # itself otherwise. Shipping it unconditionally is what makes "one artifact,
    # two delivery modes" true rather than aspirational.
    "xr_runtime.gd",
    # Attached to any rigged entity the other two scripts do not drive, so a
    # standing figure is not stuck in its exported bind pose.
    "idle_pose.gd",
    # Builds the planned heightfield into the ground mesh and its collider. Ships
    # unconditionally: a flat world simply finds no terrain block and leaves the
    # authored slab alone.
    "terrain_field.gd",
)
# WorldPlan 1.1.0 adds `scatter`; 1.0.0 (N-1) stays compilable because a plan
# only declares 1.1.0 when it actually carries scatter.
_SUPPORTED_PLAN_VERSIONS = ("1.1.0", "1.0.0")
# A species with no declared size still has to draw something; mirrors the asset
# farm's fallback so a placeholder is the same size in both halves of the system.
_DEFAULT_SPECIES_SIZE_M = (1.0, 1.5, 1.0)
_SAFE_ENTITY = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,79}$")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _q(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def _number(value: float) -> str:
    return f"{float(value):.6f}".rstrip("0").rstrip(".") or "0"


def _vector(values: list[float]) -> str:
    return "Vector3(" + ", ".join(_number(value) for value in values) + ")"


def _ground_height(terrain: dict | None, x: float, z: float) -> float:
    """Ground height at a world position, read from the plan's shipped field.

    The same bilinear rule as `pcg.terrain.Terrain.height_at`, because anything laid
    on the ground has to agree with the ground: sampling differently here would show
    up as a path hovering half a cell above its own surface. Duplicated rather than
    imported because the writer runs in the worker and the field is plan data, not
    a shared object.

    No field, or a flat one, gives zero -- which is what every pre-terrain plan and
    every indoor world means.
    """
    if not terrain or float(terrain.get("amplitude_m") or 0.0) <= 0.0:
        return 0.0
    grid = int(terrain.get("grid") or 0)
    heights = terrain.get("heights_m") or []
    width = float(terrain.get("width_m") or 0.0)
    depth = float(terrain.get("depth_m") or 0.0)
    if grid < 2 or width <= 0.0 or depth <= 0.0 or len(heights) != grid * grid:
        return 0.0
    u = min(max((x + width / 2.0) / width, 0.0), 1.0) * (grid - 1)
    v = min(max((z + depth / 2.0) / depth, 0.0), 1.0) * (grid - 1)
    x0, z0 = int(u), int(v)
    x1, z1 = min(x0 + 1, grid - 1), min(z0 + 1, grid - 1)
    tx, tz = u - x0, v - z0
    top = heights[z0 * grid + x0] + (heights[z0 * grid + x1] - heights[z0 * grid + x0]) * tx
    bottom = heights[z1 * grid + x0] + (heights[z1 * grid + x1] - heights[z1 * grid + x0]) * tx
    return float(top + (bottom - top) * tz)


def _transform(position: list[float], yaw_degrees: float) -> str:
    angle = math.radians(float(yaw_degrees))
    cosine, sine = math.cos(angle), math.sin(angle)
    values = [
        cosine,
        0.0,
        sine,
        0.0,
        1.0,
        0.0,
        -sine,
        0.0,
        cosine,
        *position,
    ]
    return "Transform3D(" + ", ".join(_number(value) for value in values) + ")"


_EARTH_GRAVITY_MPS2 = 9.81


def _gravity_of(spec: dict) -> float:
    """Gravity for this world, defaulting to Earth when the spec omits it.

    Clamped to the contract's range rather than trusted: the field is a number
    the planner supplies, and a world at 0 has a player who never lands while
    one at 300 has a player who cannot jump. Both are worse than being wrong
    about the Moon.
    """
    environment = spec.get("environment") or {}
    value = environment.get("gravity_mps2")
    if not isinstance(value, (int, float)):
        return _EARTH_GRAVITY_MPS2
    return max(0.0, min(30.0, float(value)))


def _safe_name(entity_id: str) -> str:
    if not _SAFE_ENTITY.fullmatch(entity_id):
        raise ProjectWriterError(
            code="world_plan_entity_id_unsafe",
            path=f"entities.{entity_id}",
            message="entity id cannot become an editable scene node name",
            hint="use schema-safe alphanumeric semantic entity ids",
        )
    name = pascal_case(entity_id.replace("-", "_"))
    if not name:
        raise ProjectWriterError(
            code="world_plan_entity_name_empty",
            path=f"entities.{entity_id}",
            message="entity id produced an empty scene node name",
            hint="provide a semantic entity id",
        )
    return name


def _validate_inputs(
    spec: dict,
    plan: dict,
    descriptors: dict[str, dict],
) -> dict[str, dict]:
    if plan.get("schema_version") not in _SUPPORTED_PLAN_VERSIONS:
        raise ProjectWriterError(
            code="world_plan_version_unsupported",
            path="schema_version",
            message="only canonical WorldPlan "
            + " and ".join(_SUPPORTED_PLAN_VERSIONS)
            + " are supported",
            hint="recompile the simulation with the matching Serendib brain",
        )
    if plan.get("simulation_id") != spec.get("meta", {}).get("simulation_id"):
        raise ProjectWriterError(
            code="world_plan_simulation_mismatch",
            path="simulation_id",
            message="WorldPlan and SimulationSpec belong to different simulations",
            hint="compile artifacts from one immutable generation run",
        )
    spec_entities = {item["entity_id"]: item for item in spec.get("entities", [])}
    plan_ids = [item.get("entity_id") for item in plan.get("entities", [])]
    if len(plan_ids) != len(set(plan_ids)):
        raise ProjectWriterError(
            code="world_plan_duplicate_entity",
            path="entities",
            message="WorldPlan entity ids are not unique",
            hint="rerun semantic placement",
        )
    for placed in plan.get("entities", []):
        entity_id = placed.get("entity_id")
        _safe_name(str(entity_id))
        if entity_id not in spec_entities:
            raise ProjectWriterError(
                code="world_plan_unknown_entity",
                path=f"entities.{entity_id}",
                message="WorldPlan contains an entity absent from SimulationSpec",
                hint="rerun planning and compilation from one spec version",
            )
        descriptor = descriptors.get(entity_id)
        if descriptor is None or descriptor.get("measurement", {}).get("status") != "MEASURED":
            raise ProjectWriterError(
                code="world_plan_asset_not_measured",
                path=f"asset_descriptors.{entity_id}",
                message="native compilation requires a measured asset descriptor",
                hint="resolve, import and measure the glTF asset before placement",
            )
        source = Path(descriptor.get("source", {}).get("uri") or "")
        if not source.is_file():
            raise ProjectWriterError(
                code="world_plan_asset_missing",
                path=f"asset_descriptors.{entity_id}.source.uri",
                message="the measured asset file is unavailable",
                hint="restore the content-addressed asset or resolve it again",
            )
        if descriptor.get("content_hash") != _sha256(source):
            raise ProjectWriterError(
                code="world_plan_asset_hash_mismatch",
                path=f"asset_descriptors.{entity_id}.content_hash",
                message="asset bytes changed after measurement",
                hint="quarantine the asset and rebuild its descriptor",
            )
        if placed.get("measurement_status") != "MEASURED":
            raise ProjectWriterError(
                code="world_plan_placement_not_measured",
                path=f"entities.{entity_id}.measurement_status",
                message="WorldPlan transform was not solved from measured geometry",
                hint="rerun semantic placement with the verified descriptor",
            )
    if plan.get("constraint_summary", {}).get("unplaced_entities"):
        raise ProjectWriterError(
            code="world_plan_contains_unplaced_entities",
            path="constraint_summary.unplaced_entities",
            message="a world with unsolved hard placement constraints cannot compile",
            hint="repair the smallest failed placement region",
        )
    return spec_entities


def _topological_entities(entities: list[dict]) -> list[dict]:
    by_id = {item["entity_id"]: item for item in entities}
    result: list[dict] = []
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(entity_id: str) -> None:
        if entity_id in visited:
            return
        if entity_id in visiting:
            raise ProjectWriterError(
                code="world_plan_parent_cycle",
                path=f"entities.{entity_id}.parent_id",
                message="composite entity hierarchy contains a cycle",
                hint="repair composite local transforms",
            )
        visiting.add(entity_id)
        entity = by_id[entity_id]
        parent_id = entity.get("parent_id")
        if parent_id is not None:
            if parent_id not in by_id:
                raise ProjectWriterError(
                    code="world_plan_parent_missing",
                    path=f"entities.{entity_id}.parent_id",
                    message="composite parent is absent from the WorldPlan",
                    hint="place the complete composite hierarchy",
                )
            visit(parent_id)
        visiting.remove(entity_id)
        visited.add(entity_id)
        result.append(entity)

    for item in entities:
        visit(item["entity_id"])
    return result


def _local_transform(entity: dict, by_id: dict[str, dict]) -> tuple[list[float], float]:
    transform = entity["transform"]
    position = [float(value) for value in transform["position_m"]]
    yaw = float(transform["rotation_y_degrees"])
    parent_id = entity.get("parent_id")
    if parent_id is None:
        return position, yaw
    parent = by_id[parent_id]["transform"]
    parent_position = [float(value) for value in parent["position_m"]]
    parent_yaw = float(parent["rotation_y_degrees"])
    delta_x = position[0] - parent_position[0]
    delta_z = position[2] - parent_position[2]
    angle = math.radians(parent_yaw)
    local = [
        math.cos(angle) * delta_x - math.sin(angle) * delta_z,
        position[1] - parent_position[1],
        math.sin(angle) * delta_x + math.cos(angle) * delta_z,
    ]
    return local, yaw - parent_yaw


def _palette_tag(palette: list[str] | None) -> str:
    """A short, stable suffix identifying a palette, or "" when there is none.

    Keeps existing filenames byte-identical when nothing was tinted, so a spec that asks
    for no colours produces exactly the project it produced before.
    """
    if not palette:
        return ""
    digest = hashlib.sha256("|".join(palette).encode("utf-8")).hexdigest()
    return f"_{digest[:8]}"


def _srgb_to_linear(channel: float) -> float:
    """sRGB 0..1 -> linear 0..1, the glTF 2.0 transfer function."""
    if channel <= 0.04045:
        return channel / 12.92
    return ((channel + 0.055) / 1.055) ** 2.4


def _linear_to_srgb(channel: float) -> float:
    """The inverse, for reading a model's existing factor back as a colour."""
    if channel <= 0.0031308:
        return channel * 12.92
    return 1.055 * (channel ** (1 / 2.4)) - 0.055


def _hue(rgb: tuple[float, float, float]) -> float:
    """Hue in turns (0..1). Enough to tell a leaf from a trunk."""
    import colorsys

    return colorsys.rgb_to_hsv(*rgb)[0]


def _tint_to_palette(document: dict, palette: list[str]) -> bool:
    """Move an UNTEXTURED model's flat colours onto the palette the spec declared.

    Only for models carrying no images at all, which is where it is lossless: there is no
    texture to fight, just one `baseColorFactor` per material. Measured on the vendored
    nature pack, whose foliage is a stylized mint --

        24 of 30 tree models: leaf rgb = [0.16, 0.79, 0.67]

    -- cohesive, and not what a temperate forest looks like. Removing the wrong
    `metallicFactor = 1` unmuted it and a wood of neon-cyan trees came out.

    Each material keeps its ROLE: the palette colour nearest in hue wins, so leaves take
    the green and bark takes the brown rather than every surface flattening to one colour.
    The artist's geometry, shading and material split are untouched; only the hue moves,
    and only when the planner asked for a palette.
    """
    if document.get("images") or document.get("textures"):
        return False  # a texture was authored; not ours to repaint
    wanted: list[tuple[float, list[float]]] = []
    for entry in palette:
        text = str(entry).lstrip("#")
        if len(text) != 6:
            continue
        try:
            srgb = [int(text[i : i + 2], 16) / 255.0 for i in (0, 2, 4)]
        except ValueError:
            continue
        # A hex colour is sRGB; `baseColorFactor` is LINEAR. Writing the sRGB number
        # straight in made every tint about six times too bright -- #2E7D32, a deep
        # forest green, rendered as pastel mint. Hue is unchanged by the transfer
        # function, so it is measured on the sRGB values and applied to the linear ones.
        rgb = [_srgb_to_linear(c) for c in srgb]
        wanted.append((_hue(tuple(srgb)), rgb))
    if not wanted:
        return False

    touched = False
    for material in document.get("materials") or ():
        pbr = material.setdefault("pbrMetallicRoughness", {})
        if pbr.get("baseColorTexture") is not None:
            continue
        current = pbr.get("baseColorFactor")
        if not current or len(current) < 3:
            continue
        here = _hue(tuple(_linear_to_srgb(float(c)) for c in current[:3]))
        # Nearest hue on the colour wheel, which is circular.
        _, rgb = min(
            wanted, key=lambda item: min(abs(item[0] - here), 1.0 - abs(item[0] - here))
        )
        alpha = float(current[3]) if len(current) > 3 else 1.0
        pbr["baseColorFactor"] = [*rgb, alpha]
        touched = True
    return touched


def _copy_asset(
    source: Path, destination: Path, palette: list[str] | None = None
) -> None:
    """Copy a model into the project, correcting metallicFactor on the way.

    glTF 2.0 defaults `metallicFactor` to **1.0** when the field is absent, i.e. fully
    metallic. A metal surface shows only what it reflects, and these scenes use a flat
    background colour with no sky and no reflection probe -- so there is nothing to
    reflect and the mesh renders BLACK.

    Measured: 51 of 51 generated materials in the asset cache omit the field, and the
    rendered village came back with black buildings while its textures were present and
    correct. TRELLIS emits an albedo texture, not a metal workflow, so 1.0 was never
    the intended value -- it is the spec default arriving by silence.

    Written on COPY rather than in the cache, so a shared cache file is never mutated and
    the correction reaches assets generated before this existed.
    """
    import json
    import struct

    raw = source.read_bytes()
    try:
        if raw[:4] != b"glTF":
            raise ValueError("not a GLB")
        json_length = struct.unpack("<I", raw[12:16])[0]
        header, body = raw[:20], raw[20:]
        document = json.loads(body[:json_length])
        touched = False
        for material in document.get("materials") or ():
            pbr = material.setdefault("pbrMetallicRoughness", {})
            metallic = pbr.get("metallicFactor")
            # Absent OR explicitly 1.0, which are the same claim made two ways.
            #
            # Correcting only the absent case left the curated library untouched, because
            # a pack author writes the value out. Measured on `tree_oak.glb`:
            #
            #     leafsGreen  baseColor=[0.16,0.79,0.67]  metallicFactor=1  roughness=1
            #     woodBark    baseColor=[0.89,0.51,0.34]  metallicFactor=1  roughness=1
            #
            # Fully metallic, and these scenes have a flat background colour, no sky and
            # no reflection probe -- so there is nothing to reflect and every unlit face
            # renders black. That is the harsh black flank on each tree in the render.
            #
            # A material carrying a metallic-roughness TEXTURE is left alone: it was
            # authored deliberately and the map, not this factor, decides what is metal.
            if metallic is None or (
                float(metallic) >= 1.0 and pbr.get("metallicRoughnessTexture") is None
            ):
                pbr["metallicFactor"] = 0.0
                touched = True
            if pbr.get("roughnessFactor") is None:
                # Matte by default. A generated asset has no gloss map, and a shiny
                # untextured surface reads as plastic.
                pbr["roughnessFactor"] = 0.9
                touched = True
        if palette and _tint_to_palette(document, list(palette)):
            touched = True
        if not touched:
            raise ValueError("nothing to correct")
        encoded = json.dumps(document, separators=(",", ":")).encode("utf-8")
        encoded += b" " * ((4 - len(encoded) % 4) % 4)
        rest = body[json_length:]
        total = 12 + 8 + len(encoded) + len(rest)
        destination.write_bytes(
            header[:8]
            + struct.pack("<I", total)
            + struct.pack("<I", len(encoded))
            + b"JSON"
            + encoded
            + rest
        )
        return
    except Exception:  # noqa: BLE001 - a copy must never fail over a material tweak
        pass
    shutil.copyfile(source, destination)


def write_simulation_project(
    spec: dict,
    plan: dict,
    descriptors: dict[str, dict],
    out_dir: Path,
) -> list[Path]:
    """Compile a canonical measured plan into a deterministic editable project."""
    spec_entities = _validate_inputs(spec, plan, descriptors)
    # What the planner asked each thing to LOOK like. Used only to tint untextured
    # curated models, where a flat `baseColorFactor` is the whole appearance -- see
    # `_tint_to_palette`. Entities and species share one lookup because both are copied
    # through `_copy_asset`.
    palette_by_id: dict[str, list[str]] = {}
    for item in list(spec_entities or ()) + list(spec.get("scatter") or ()):
        if not isinstance(item, dict):
            continue
        key = str(item.get("entity_id") or item.get("species_id") or "")
        colours = (item.get("asset") or {}).get("palette_hex")
        if key and isinstance(colours, list) and colours:
            palette_by_id[key] = [str(c) for c in colours]
    for filename in _REQUIRED_RUNTIME:
        if not (_RUNTIME / filename).is_file():
            raise ProjectWriterError(
                code="serendib_runtime_template_missing",
                path=str(_RUNTIME / filename),
                message="a reviewed simulation runtime template is missing",
                hint="restore the signed Serendib capability runtime",
            )
    out_dir.mkdir(parents=True, exist_ok=True)
    assets_dir = out_dir / "assets"
    assets_dir.mkdir(exist_ok=True)
    runtime_dir = out_dir / "runtime"
    runtime_dir.mkdir(exist_ok=True)
    branding_dir = out_dir / "branding"
    branding_dir.mkdir(exist_ok=True)
    assist_dir = out_dir / "addons" / "serendib_assist"
    assist_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "validation_views").mkdir(exist_ok=True)

    written: list[Path] = []
    asset_ext: dict[str, tuple[str, str]] = {}
    ext_blocks = [
        '[ext_resource type="Script" path="res://runtime/simulation_runtime.gd" id="1_runtime"]\n',
        '[ext_resource type="Script" '
        'path="res://runtime/simulation_controller.gd" id="2_controller"]\n',
        '[ext_resource type="Script" '
        'path="res://runtime/capability_state_machine.gd" id="3_capability"]\n',
        '[ext_resource type="Script" path="res://runtime/simulation_agent.gd" id="4_agent"]\n',
        '[ext_resource type="Script" path="res://runtime/scatter_field.gd" id="5_scatter"]\n',
        '[ext_resource type="Script" path="res://runtime/xr_runtime.gd" id="6_xr"]\n',
        '[ext_resource type="Script" path="res://runtime/idle_pose.gd" id="7_idle"]\n',
        '[ext_resource type="Script" path="res://runtime/terrain_field.gd" id="8_terrain"]\n',
    ]
    for index, entity in enumerate(
        sorted(plan["entities"], key=lambda item: item["entity_id"]), start=10
    ):
        entity_id = entity["entity_id"]
        descriptor = descriptors[entity_id]
        source = Path(descriptor["source"]["uri"])
        suffix = source.suffix.lower()
        palette = palette_by_id.get(entity_id)
        # The palette is part of the file's identity: two entities sharing one model but
        # asking for different colours must not collide on `content_hash` alone, where
        # whichever was written first would silently supply the other's appearance.
        filename = f"{descriptor['content_hash']}{_palette_tag(palette)}{suffix}"
        destination = assets_dir / filename
        if not destination.exists():
            _copy_asset(source, destination, palette=palette)
            written.append(destination)
        ext_id = f"{index}_asset"
        asset_ext[entity_id] = (ext_id, filename)
        ext_blocks.append(
            f'[ext_resource type="PackedScene" path="res://assets/{filename}" id="{ext_id}"]\n'
        )

    world_min = plan["world_bounds"]["min"]
    world_max = plan["world_bounds"]["max"]
    width = float(world_max[0]) - float(world_min[0])
    depth = float(world_max[2]) - float(world_min[2])
    # Surface synthesis (P3). The ground had no material at all and drew as
    # default white -- the biggest flat area in every frame. Triplanar noise
    # needs no UVs, which a BoxMesh does not have.
    # The fallback reason is recorded by the pipeline, which owns the spec's
    # approximation list; the compiler only needs to know what to draw.
    ground_family, _ = resolve_ground_family(spec.get("environment") or {})
    # A planned field with relief in it. Absent, or flat, means the ground stays
    # exactly the slab it has always been -- indoor worlds, built surfaces, and
    # any plan written before terrain existed.
    terrain_block = plan.get("terrain") or {}
    has_relief = float(terrain_block.get("amplitude_m") or 0.0) > 0.0
    # Declared ground surfaces, painted onto the height lattice by the planner.
    #
    # A world can have regions and no relief -- a courtyard on flat ground is the
    # commonest case of all -- and the flat ground is a BoxMesh with no per-vertex
    # anything. So the terrain script is attached whenever EITHER is present: it
    # rebuilds the ground as a real lattice, which a flat field makes flat.
    surface_grid = [int(value) for value in (terrain_block.get("surface_grid") or ())]
    surface_families = [str(name) for name in (terrain_block.get("surface_families") or ())]
    has_regions = any(surface_grid) and len(surface_families) > 1
    builds_ground = has_relief or has_regions
    # The BoxMesh keeps covering the world; the displaced mesh covers the FIELD,
    # because that is the extent the heights are indexed over.
    ground_width = float(terrain_block.get("width_m") or width) if builds_ground else width
    ground_depth = float(terrain_block.get("depth_m") or depth) if builds_ground else depth
    surface_seed = noise_seed(spec)
    sub_blocks = [
        surface_sub_resources(
            surface_seed, ground_family, vertex_tinted_ground=has_regions
        ),
        '[sub_resource type="BoxMesh" id="GroundMesh"]\n'
        f"size = Vector3({_number(ground_width)}, 0.5, {_number(ground_depth)})\n"
        f'material = SubResource("{GROUND_MATERIAL_ID}")\n\n',
        '[sub_resource type="BoxShape3D" id="GroundShape"]\n'
        f"size = Vector3({_number(ground_width)}, 0.5, {_number(ground_depth)})\n\n",
        '[sub_resource type="NavigationMesh" id="WorldNavigation"]\n'
        "agent_radius = 0.5\n"
        "agent_height = 1.8\n"
        "agent_max_climb = 0.5\n"
        "agent_max_slope = 45.0\n"
        "geometry_parsed_geometry_type = 1\n\n",
        "geometry_source_geometry_mode = 1\n"
        'geometry_source_group_name = &"serendib_navigation_source"\n\n',
        '[sub_resource type="Environment" id="WorldEnvironment"]\n'
        "background_mode = 1\n"
        "background_color = Color(0.33, 0.48, 0.55, 1)\n"
        "ambient_light_source = 3\n"
        "ambient_light_color = Color(0.72, 0.82, 0.82, 1)\n"
        # Ambient at 0.8 plus an unshadowed sun at full strength put roughly 1.8x light
        # on every surface, so a light-grey building saturated to pure white and its
        # texture stopped being visible at all. Seen in the validation views of
        # run_95907322647b41fdbfae6ab6f782e5c9: the Kenney models carried textures
        # (`tex=1`) and still rendered as blank white slabs -- which is what "white
        # banners everywhere" actually was, an exposure fault rather than a missing mesh.
        #
        # 0.35 is fill: enough that shadowed faces stay readable, little enough that the
        # sun does the modelling.
        "ambient_light_energy = 0.35\n\n",
    ]
    shape_ids: dict[str, str] = {}
    for index, entity in enumerate(plan["entities"]):
        entity_id = entity["entity_id"]
        shape_id = f"EntityShape{index}"
        shape_ids[entity_id] = shape_id
        dimensions = entity["dimensions_m"]
        descriptor = descriptors[entity_id]
        if descriptor["collision"]["shape"] == "capsule":
            radius = min(float(dimensions[0]), float(dimensions[2])) / 2.0
            height = max(float(dimensions[1]), radius * 2.0)
            sub_blocks.append(
                f'[sub_resource type="CapsuleShape3D" id="{shape_id}"]\n'
                f"radius = {_number(radius)}\n"
                f"height = {_number(height)}\n\n"
            )
        else:
            sub_blocks.append(
                f'[sub_resource type="BoxShape3D" id="{shape_id}"]\n'
                f"size = {_vector(dimensions)}\n\n"
            )

    path_nodes: list[str] = []
    navigation_paths = [
        item
        for item in plan.get("navigation", {}).get("paths", [])
        if item.get("status") == "CONNECTED"
    ]
    # The path material is synthesised alongside the ground, so a trodden path
    # reads as worn earth rather than a flat brown ribbon.
    segment_index = 0
    for path in navigation_paths:
        for start, end in zip(
            path["points_m"], path["points_m"][1:], strict=False
        ):
            delta_x = float(end[0]) - float(start[0])
            delta_z = float(end[2]) - float(start[2])
            length = math.hypot(delta_x, delta_z)
            if length <= 1e-6:
                continue
            segment_index += 1
            mesh_id = f"PathMesh{segment_index}"
            sub_blocks.append(
                f'[sub_resource type="BoxMesh" id="{mesh_id}"]\n'
                f"size = Vector3({_number(path['width_m'])}, 0.06, {_number(length)})\n"
                f'material = SubResource("{PATH_MATERIAL_ID}")\n\n'
            )
            # Sit on the ground, and pitch to the fall along the run. y=0.03 was
            # three centimetres above a plane; over relief a path floated across
            # every dip and vanished into every rise. Exact for a straight segment,
            # which is what this is: a quad between two points.
            start_y = _ground_height(terrain_block, float(start[0]), float(start[2]))
            end_y = _ground_height(terrain_block, float(end[0]), float(end[2]))
            midpoint = [
                (float(start[0]) + float(end[0])) / 2.0,
                (start_y + end_y) / 2.0 + 0.03,
                (float(start[2]) + float(end[2])) / 2.0,
            ]
            yaw = math.degrees(math.atan2(-delta_x, delta_z))
            # start minus end, not negated: the mesh runs along its own +Z so a
            # segment whose far end is higher tips backwards, and writing it this way
            # round keeps a level segment at 0 instead of -0.
            pitch = math.degrees(math.atan2(start_y - end_y, length))
            path_nodes.append(
                f'[node name="PathSegment{segment_index}" type="MeshInstance3D" parent="Paths"]\n'
                f'mesh = SubResource("{mesh_id}")\n'
                f"position = {_vector(midpoint)}\n"
                f"rotation_degrees = Vector3({_number(pitch)}, {_number(yaw)}, 0)\n"
                f"metadata/path_id = {_q(path['path_id'])}\n\n"
            )

    graphs_by_entity: dict[str, list[dict]] = {}
    for graph in plan.get("behaviours", []):
        entity_id = graph.get("entity_id")
        if entity_id is not None:
            # The registry binding is lineage, not a path the runtime may load.
            # Only the state-machine data reaches the reviewed interpreter.
            runtime_graph = {
                key: value
                for key, value in graph.items()
                if key != "runtime_binding"
            }
            graphs_by_entity.setdefault(entity_id, []).append(runtime_graph)

    by_id = {item["entity_id"]: item for item in plan["entities"]}
    agents_by_id = {
        item["entity_id"]: item for item in spec.get("agents", [])
    }
    path_by_id: dict[str, str] = {}
    entity_nodes: list[str] = []
    for placed in _topological_entities(plan["entities"]):
        entity_id = placed["entity_id"]
        authored = spec_entities[entity_id]
        parent_id = placed.get("parent_id")
        parent_path = path_by_id[parent_id] if parent_id else "."
        name = _safe_name(entity_id)
        path = name if parent_path == "." else f"{parent_path}/{name}"
        path_by_id[entity_id] = path
        local_position, local_yaw = _local_transform(placed, by_id)
        agent = agents_by_id.get(entity_id)
        user_controlled = bool(agent and agent.get("controller") == "user") or (
            authored["role"] == "controlled_agent"
        )
        autonomous = bool(
            agent and agent.get("controller") in {"behaviour_tree", "utility_ai", "schedule"}
        )
        node_type = (
            "CharacterBody3D"
            if user_controlled or autonomous
            else "RigidBody3D"
            if placed["dynamic"]
            else "StaticBody3D"
        )
        script = (
            '\nscript = ExtResource("2_controller")'
            if user_controlled
            else '\nscript = ExtResource("4_agent")'
            if autonomous
            else ""
        )
        if node_type == "RigidBody3D":
            script += f"\nmass = {_number(max(0.1, authored['physical']['mass_kg']))}"
        groups = ["serendib_entity"]
        if node_type == "StaticBody3D" and "openable" not in authored.get(
            "capabilities", []
        ):
            groups.append("serendib_navigation_source")
        group_literal = ", ".join(_q(group) for group in groups)
        entity_nodes.append(
            f'[node name="{name}" type="{node_type}" parent="{parent_path}" '
            f"groups=[{group_literal}]]\n"
            f"transform = {_transform(local_position, local_yaw)}"
            f"{script}\n"
            f"metadata/entity_id = {_q(entity_id)}\n"
            f"metadata/semantic_type = {_q(placed['semantic_type'])}\n"
            f"metadata/role = {_q(authored['role'])}\n\n"
            f'[node name="CollisionShape3D" type="CollisionShape3D" parent="{path}"]\n'
            f'shape = SubResource("{shape_ids[entity_id]}")\n\n'
        )
        ext_id, _ = asset_ext[entity_id]
        scale = descriptors[entity_id]["normalization_scale"]
        visual_offset = descriptors[entity_id].get("pivot", {}).get(
            "offset_m", [0.0, -float(placed["dimensions_m"][1]) / 2.0, 0.0]
        )
        if "openable" in authored.get("capabilities", []):
            hinge_x = -float(placed["dimensions_m"][0]) / 2.0
            entity_nodes.append(
                f'[node name="VisualPivot" type="Node3D" parent="{path}"]\n'
                f"position = Vector3({_number(hinge_x)}, 0, 0)\n\n"
                f'[node name="Visual" parent="{path}/VisualPivot" '
                f'instance=ExtResource("{ext_id}")]\n'
                f"position = Vector3({_number(-hinge_x + float(visual_offset[0]))}, "
                f"{_number(float(visual_offset[1]))}, {_number(float(visual_offset[2]))})\n"
                f"scale = {_vector(scale)}\n\n"
            )
        else:
            entity_nodes.append(
                f'[node name="Visual" parent="{path}" instance=ExtResource("{ext_id}")]\n'
                f"position = {_vector([float(value) for value in visual_offset])}\n"
                f"scale = {_vector(scale)}\n\n"
            )
        graphs = graphs_by_entity.get(entity_id, [])
        if graphs:
            graph_json = json.dumps(
                graphs, sort_keys=True, separators=(",", ":"), ensure_ascii=False
            )
            entity_nodes.append(
                f'[node name="Capabilities" type="Node3D" parent="{path}"]\n'
                'script = ExtResource("3_capability")\n'
                f"graphs_json = {_q(graph_json)}\n\n"
            )
        rigged = bool(
            descriptors[entity_id].get("animation", {}).get("rigged")
        )
        if rigged and not user_controlled and not autonomous:
            # A rigged model with nothing playing on it renders in whatever pose
            # it was exported in -- arms out, for the Quaternius humans. The
            # player's controller and an autonomous agent's script already drive
            # their own clips; nothing drove anybody else, which went unnoticed
            # while the only people in a world were walking agents. A dialogue
            # speaker is the first entity whose whole purpose is to stand still
            # and be lifelike at the same time.
            #
            # A child node rather than a script on the body, so it is obvious and
            # removable in the editor of a downloaded project.
            entity_nodes.append(
                f'[node name="IdlePose" type="Node3D" parent="{path}"]\n'
                'script = ExtResource("7_idle")\n\n'
            )
        if "dialogue" in authored.get("capabilities", []):
            # Sits above the speaker's head and billboards, so a line is legible
            # from wherever the visitor happens to be standing when they talk.
            # Authored here rather than created by the runtime script: whoever
            # opens the downloaded project should find a DialogueLine node they
            # can restyle, not a label that appears out of nowhere at load.
            label_y = float(placed["dimensions_m"][1]) / 2.0 + 0.35
            entity_nodes.append(
                f'[node name="DialogueLine" type="Label3D" parent="{path}"]\n'
                f"position = Vector3(0, {_number(label_y)}, 0)\n"
                "billboard = 1\n"
                "no_depth_test = true\n"
                "font_size = 48\n"
                "outline_size = 16\n"
                "pixel_size = 0.005\n"
                "visible = false\n\n"
            )
        if autonomous:
            navigation_anchor_y = -float(placed["dimensions_m"][1]) / 2.0
            entity_nodes.append(
                f'[node name="NavigationAgent3D" type="NavigationAgent3D" parent="{path}"]\n'
                f"position = Vector3(0, {_number(navigation_anchor_y)}, 0)\n"
                "path_desired_distance = 0.65\n"
                "target_desired_distance = 0.6\n"
                "avoidance_enabled = false\n\n"
            )
        if user_controlled:
            entity_nodes.append(
                f'[node name="SpringArm3D" type="SpringArm3D" parent="{path}"]\n'
                "position = Vector3(0, 1.2, 0)\n"
                "spring_length = 4.0\n\n"
                f'[node name="Camera3D" type="Camera3D" parent="{path}/SpringArm3D"]\n'
                "position = Vector3(0, 0, 4)\n"
                "current = true\n\n"
            )

    zone_nodes = []
    for zone in plan.get("zones", []):
        minimum, maximum = zone["bounds"]["min"], zone["bounds"]["max"]
        center = [
            (float(minimum[0]) + float(maximum[0])) / 2.0,
            0.0,
            (float(minimum[2]) + float(maximum[2])) / 2.0,
        ]
        zone_nodes.append(
            f'[node name="Zone{_safe_name(zone["zone_id"])}" type="Marker3D" parent="Zones"]\n'
            f"position = {_vector(center)}\n"
            f"metadata/zone_id = {_q(zone['zone_id'])}\n"
            f"metadata/semantic_type = {_q(zone['semantic_type'])}\n\n"
        )

    # --- Scatter fields ----------------------------------------------------
    # The instancer plans thousands of placements; without this block they stay
    # data in world_plan.json and the player walks through an empty world. One
    # MultiMeshInstance3D per species keeps that to one draw call each.
    scatter_nodes: list[str] = []
    counted: dict[str, int] = {}
    for instance in plan.get("scatter", {}).get("instances", []):
        species_id = str(instance.get("species_id") or "")
        counted[species_id] = counted.get(species_id, 0) + 1
    if counted:
        species_by_id = {
            str(item["species_id"]): item for item in spec.get("scatter") or ()
        }
        # Entity ext ids start at 10; continue past them so ids stay unique.
        first_species_ext = 10 + len(plan["entities"])
        for offset, species_id in enumerate(sorted(counted)):
            species = species_by_id.get(species_id, {})
            source_line = ""
            asset_scale = 1.0
            descriptor = descriptors.get(species_id) or {}
            if descriptor.get("measurement", {}).get("status") == "MEASURED":
                source = Path(descriptor.get("source", {}).get("uri") or "")
                if source.is_file():
                    palette = palette_by_id.get(species_id)
                    filename = (
                        f"{descriptor['content_hash']}{_palette_tag(palette)}"
                        f"{source.suffix.lower()}"
                    )
                    destination = assets_dir / filename
                    if not destination.exists():
                        _copy_asset(source, destination, palette=palette)
                        written.append(destination)
                    ext_id = f"{first_species_ext + offset}_species"
                    ext_blocks.append(
                        f'[ext_resource type="PackedScene" '
                        f'path="res://assets/{filename}" id="{ext_id}"]\n'
                    )
                    source_line = f'source_scene = ExtResource("{ext_id}")\n'
                    normalization = descriptor.get("normalization_scale") or [1.0]
                    asset_scale = float(normalization[0])
            if not source_line:
                # No resolved asset: draw a correctly sized placeholder rather
                # than nothing, so a missing species is visible instead of silent.
                size = [
                    float(value)
                    for value in (species.get("size_m") or _DEFAULT_SPECIES_SIZE_M)
                ]
                mesh_id = f"SpeciesMesh{offset}"
                sub_blocks.append(
                    f'[sub_resource type="BoxMesh" id="{mesh_id}"]\n'
                    f"size = {_vector(size)}\n\n"
                )
                source_line = f'fallback_mesh = SubResource("{mesh_id}")\n'
            scatter_nodes.append(
                f'[node name="Scatter{_safe_name(species_id)}" '
                f'type="MultiMeshInstance3D" parent="Scatter"]\n'
                'script = ExtResource("5_scatter")\n'
                f"species_id = {_q(species_id)}\n"
                + source_line
                + f"asset_scale = {_number(asset_scale)}\n"
                f"metadata/planned_instances = {counted[species_id]}\n\n"
            )

    resources = "".join(ext_blocks) + "\n" + "".join(sub_blocks)
    load_steps = (
        resources.count("[ext_resource ")
        + resources.count("[sub_resource ")
        + 1
    )
    scene = (
        f"[gd_scene load_steps={load_steps} format=3]\n\n"
        + resources
        + '[node name="SerendibSimulation" type="Node3D"]\n'
        'script = ExtResource("1_runtime")\n\n'
        # Present in every generated project, flat or immersive. It finds the
        # user-controlled body itself and stands down when no XR interface
        # initialises, so a browser without a headset pays one _ready() for it.
        '[node name="XRRuntime" type="Node" parent="."]\n'
        'script = ExtResource("6_xr")\n\n'
        '[node name="WorldEnvironment" type="WorldEnvironment" parent="."]\n'
        'environment = SubResource("WorldEnvironment")\n\n'
        '[node name="Sun" type="DirectionalLight3D" parent="."]\n'
        "rotation_degrees = Vector3(-55, -30, 0)\n"
        "light_energy = 1.1\n"
        # Shadows ON. Without them nothing meets the ground: a bush, a barrel and a
        # house all float in the same flat light and the eye reads the scene as cut-out
        # shapes laid on a plane rather than objects standing in a place. The game_spec
        # path has had `shadow_enabled = true` all along; this writer never matched it.
        "shadow_enabled = true\n"
        # Normal bias, not depth bias: a low-poly wall lit at a grazing angle
        # self-shadows into stripes otherwise.
        "shadow_normal_bias = 1.5\n\n"
        '[node name="Ground" type="StaticBody3D" parent="." '
        'groups=["serendib_navigation_source"]]\n'
        # Planned heights are absolute, measured from the world origin, so a
        # displaced ground must not add half a slab of its own. The flat slab still
        # sits at -0.25 to put its TOP at zero, which is where every y in a
        # pre-terrain plan was measured from.
        + (
            "position = Vector3(0, 0, 0)\n"
            'script = ExtResource("8_terrain")\n'
            # The palette the painted grid indexes into. Resolved here rather than in
            # the plan because what a family name LOOKS like is this side's decision
            # (rule 15) -- the plan carries names, the scene carries colours. Entry 0
            # is the world's own ground, so an unpainted vertex keeps exactly the tint
            # it has today.
            + (
                "surface_palette = PackedColorArray("
                + ", ".join(
                    f"{value:g}"
                    for name in ([ground_family] + surface_families[1:])
                    for value in (*family_albedo(name), 1.0)
                )
                + ")\n"
                if has_regions
                else ""
            )
            + "\n"
            if builds_ground
            else "position = Vector3(0, -0.25, 0)\n\n"
        )
        + '[node name="MeshInstance3D" type="MeshInstance3D" parent="Ground"]\n'
        'mesh = SubResource("GroundMesh")\n\n'
        '[node name="CollisionShape3D" type="CollisionShape3D" parent="Ground"]\n'
        'shape = SubResource("GroundShape")\n\n'
        '[node name="Navigation" type="NavigationRegion3D" parent="."]\n'
        'navigation_mesh = SubResource("WorldNavigation")\n\n'
        '[node name="Zones" type="Node3D" parent="."]\n\n'
        + "".join(zone_nodes)
        + '[node name="Paths" type="Node3D" parent="."]\n\n'
        + "".join(path_nodes)
        + '[node name="Scatter" type="Node3D" parent="."]\n\n'
        + "".join(scatter_nodes)
        + "".join(entity_nodes)
    )
    title = str(spec["meta"]["title"]).replace('"', "'")[:120]
    project = (
        "; Generated by Serendib from a canonical WorldPlan.\n"
        "config_version=5\n\n"
        "[application]\n\n"
        f"config/name={_q(title)}\n"
        'run/main_scene="res://main.tscn"\n'
        'config/features=PackedStringArray("4.6", "GL Compatibility")\n'
        'config/icon="res://branding/serendib_icon.svg"\n'
        'boot_splash/image="res://branding/serendib_splash.png"\n'
        "boot_splash/bg_color=Color(0.027, 0.039, 0.078, 1)\n"
        "boot_splash/fullsize=true\n\n"
        "[display]\n\n"
        "window/size/viewport_width=960\n"
        "window/size/viewport_height=540\n\n"
        + _input_map_section()
        + '\n[editor_plugins]\n\nenabled=PackedStringArray("res://addons/serendib_assist/plugin.cfg")\n'
        + "\n[physics]\n\n"
        # Everything fell at Earth gravity whatever the prompt said, because the
        # writer never set this and Godot's default is 9.8. A lunar base and a
        # warehouse were physically identical worlds. The controller and the
        # agent both read `get_gravity()`, so setting the project value is
        # enough to make jumps, falls and settling behave like the place.
        f"3d/default_gravity={_number(_gravity_of(spec))}\n"
        + "\n[rendering]\n\n"
        'renderer/rendering_method="gl_compatibility"\n'
        'renderer/rendering_method.mobile="gl_compatibility"\n'
    )
    for filename, body in (
        ("project.godot", project),
        ("main.tscn", scene),
        ("simulation_spec.json", json.dumps(spec, indent=2, sort_keys=True) + "\n"),
        ("world_plan.json", json.dumps(plan, indent=2, sort_keys=True) + "\n"),
    ):
        path = out_dir / filename
        path.write_text(body, encoding="utf-8", newline="\n")
        written.append(path)
    for filename in _REQUIRED_RUNTIME:
        destination = runtime_dir / filename
        shutil.copyfile(_RUNTIME / filename, destination)
        written.append(destination)
    for source_name, destination_name in (
        ("icon.svg", "serendib_icon.svg"),
        ("splash.png", "serendib_splash.png"),
    ):
        source = _BRANDING / source_name
        if not source.is_file():
            raise ProjectWriterError(
                code="serendib_branding_missing",
                path=str(source),
                message="required Serendib branding asset is missing",
                hint="restore the Serendib branding bundle",
            )
        destination = branding_dir / destination_name
        shutil.copyfile(source, destination)
        written.append(destination)
    for filename in ("plugin.cfg", "serendib_assist.gd", "assist_dock.gd"):
        source = _ASSIST / filename
        if not source.is_file():
            raise ProjectWriterError(
                code="serendib_assist_missing",
                path=str(source),
                message="required Serendib Assist plugin file is missing",
                hint="restore the reviewed Serendib Assist bundle",
            )
        destination = assist_dir / filename
        shutil.copyfile(source, destination)
        written.append(destination)
    return written
