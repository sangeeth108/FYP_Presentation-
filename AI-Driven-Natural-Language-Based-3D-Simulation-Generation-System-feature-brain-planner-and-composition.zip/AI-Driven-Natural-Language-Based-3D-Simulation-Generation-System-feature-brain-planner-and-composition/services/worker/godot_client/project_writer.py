"""Project writer (S6 step 1): level-plan JSON -> Serendib 4.6 project on disk.

Consumes the level plan emitted by the brain (``pcg/serialize.py``,
``level_plan_version`` 1.0.0) and writes a minimal, valid, *editable*
Godot project:

- ``project.godot`` — GL Compatibility renderer (WebGL2 constraint), main
  scene wired, PascalCase title;
- ``main.tscn`` — every room floor as a named ``StaticBody3D`` with mesh +
  collision (``RoomZ00`` / ``RoomZ00Mesh`` / ``RoomZ00Shape``), corridor
  floor segments (``CorridorZ00Z01_Seg1``), one ``Marker3D`` per placed
  entity (``CastleGuardShambler_01``) at its (x, elevation, z), a
  ``PlayerSpawn`` marker in the entry room, plus sun light, environment,
  and an angled ``PreviewCamera`` so the scene renders standalone.

Node naming is PascalCase with meaningful names (never ``Node3D_17``) —
the editability promise depends on it. Output is byte-stable: identical
plans produce identical projects (hashable for lineage).

v0 limits (later GridMap materialization work): floors only — no walls,
no ramps; corridors between different tiers sit at the lower elevation.
Template scripts (controllers/AI) attach in the next S6 step from
``engine/templates/``.
"""

from __future__ import annotations

import math
import shutil
from pathlib import Path

from godot_client.asset_kit import (
    FUNCTIONAL_PROPS,
    enemy_model,
    enemy_sounds,
    kit_files_exist,
    prop_model,
    sound_files_exist,
)
from godot_client.composite_writer import composite_blocks
from godot_client.composition import AffordancePart, CompositeObject, Socket
from godot_client.lighting import LIGHTING_PRESETS, environment_blocks
from godot_client.navmesh import navmesh_tscn_blocks
from godot_client.walls import (
    WALL_HEIGHT,
    WALL_THICKNESS,
    ramp_geometry,
    wall_runs,
)
from godot_client.world_outdoor import outdoor_blocks, outdoor_navmesh_blocks

_REPO_ROOT = Path(__file__).resolve().parents[3]
_SERENDIB_BRANDING = _REPO_ROOT / "engine" / "serendib" / "branding"

def _kit_ext_id(model_path: str) -> str:
    return "k_" + Path(model_path).name.split(".")[0].lower()


def _yaw_basis(quarter_turns: int) -> str:
    """Exact 90-degree yaw bases (row-major), for deterministic prop variety."""
    return {
        0: "1, 0, 0, 0, 1, 0, 0, 0, 1",
        1: "0, 0, 1, 0, 1, 0, -1, 0, 0",
        2: "-1, 0, 0, 0, 1, 0, 0, 0, -1",
        3: "0, 0, -1, 0, 1, 0, 1, 0, 0",
    }[quarter_turns % 4]

SUPPORTED_PLAN_VERSION = "1.0.0"
FLOOR_THICKNESS = 0.5
# Enemy audio is positional: it fades out past this radius so a room of 25
# enemies doesn't wall of sound. Footsteps sit under the strikes.
ENEMY_AUDIO_MAX_DISTANCE = 20.0
ENEMY_STEP_VOLUME_DB = -8.0
# Atmospheric dressing: a lit torch inset into each room corner so a level reads
# as a real furnished space, not grey boxes. Purely visual (the instanced kit
# GLB carries no collision), so it never touches navmesh, collision or the gates
# — dressing must never change whether a game is playable. Only when the kit is
# present; skipped for tiny rooms where corner torches would crowd the floor.
# A generated object body is normalised to this longest dimension (metres) by
# backends_local._normalise_for_godot; the composite writer scales it up to the
# object's bbox so the shell fills its door layout. Keep in sync with that module.
GENERATED_BODY_SIZE_M = 1.5
# A generated door PANEL (Phase 4c) is scaled to this height — matches
# composite_writer.DOOR_HEIGHT (the box slab it replaces).
DOOR_HEIGHT_M = 2.0

TORCH_MODEL = "kaykit/props/torch_lit.gltf.glb"
TORCH_CORNER_INSET = 0.8  # metres in from the wall, clear of the perimeter
TORCH_MIN_ROOM_SIDE = 4.0  # rooms smaller than this get none
REACH_ZONE_TEMPLATE = Path("objectives") / "reach_zone.gd"
CONTROLLER_TEMPLATE = Path("controllers") / "controller_third_person.gd"
TOPDOWN_TEMPLATE = Path("controllers") / "controller_topdown_3d.gd"
ISOMETRIC_TEMPLATE = Path("controllers") / "controller_isometric_3d.gd"
DOOR_TEMPLATE = Path("interactables") / "door_hinged.gd"
AI_TEMPLATE = Path("ai") / "ai_patrol_chase.gd"
DEATH_TEMPLATE = Path("objectives") / "player_death.gd"
HUD_TEMPLATE = Path("ui") / "hud_basic.gd"
PICKUP_TEMPLATE = Path("interactables") / "pickup_collectible.gd"
COLLECT_TEMPLATE = Path("objectives") / "collect_n.gd"
# The horizontal run every tier-crossing ramp gets, measured back from where the
# corridor enters the UPPER room. Fixed on purpose: deriving it from whichever
# corridor segment happened to cross a room edge produced 56-degree ramps (a 1.5
# rise over a 1.0 run — unclimbable, Godot's floor limit is 45) and 23-unit
# ramps, which is what failed 7 of the 20 MID-DEMO prompts. A 1.5 rise over 4.0
# is 20.6 degrees, always. The slab overlaps the lower room's floor, but its
# underside never reaches head height over that run, so nothing can wedge under.
RAMP_EXTRA_RUN = 2.0  # kept for the wall tests: run = ROOM_GAP + this

# Spec player.controller_template_id -> scene script ext_resource id.
CONTROLLER_EXT_IDS = {
    "controller_third_person": "2_controller",
    "controller_topdown_3d": "7_topdown",
    "controller_isometric_3d": "8_iso",
}


def _camera_rig(controller_id: str) -> str:
    """Camera nodes matching the controller (basis rows precomputed;
    .tscn Transform3D is ROW-major)."""
    if controller_id == "controller_topdown_3d":
        # Fixed overhead follow cam: pitch -65 deg, looks at the player.
        return (
            '[node name="PlayerCamera" type="Camera3D" parent="Player"]\n'
            "transform = Transform3D(1, 0, 0, 0, 0.422618, 0.906308, "
            "0, -0.906308, 0.422618, 0, 12, 5.6)\n"
            "current = true\n\n"
        )
    if controller_id == "controller_isometric_3d":
        # Classic iso: yaw 45 deg, pitch -35 deg, distance ~13.
        return (
            '[node name="PlayerCamera" type="Camera3D" parent="Player"]\n'
            "transform = Transform3D(0.707107, -0.40558, 0.579228, 0, 0.819152, 0.573576, "
            "-0.707107, -0.40558, 0.579228, 7.52996, 8.45649, 7.52996)\n"
            "current = true\n\n"
        )
    return (  # third person: mouse-look spring arm
        '[node name="SpringArm3D" type="SpringArm3D" parent="Player"]\n'
        "transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.5, 0)\n"
        "spring_length = 4.0\n\n"
        '[node name="PlayerCamera" type="Camera3D" parent="Player/SpringArm3D"]\n'
        "transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 4)\n"
        "current = true\n\n"
    )
KEY_OBJECTIVE_ID = "reach_key"
DOOR_HEIGHT = 2.5
DOOR_SPAN_PAD = 0.4

# Physical keycodes for the default input map (WASD + Space/Shift/E).
_INPUT_ACTIONS = {
    "move_forward": 87,  # W
    "move_back": 83,  # S
    "move_left": 65,  # A
    "move_right": 68,  # D
    "jump": 32,  # Space
    "sprint": 4194325,  # Shift
    "interact": 69,  # E
}


def _key_event(physical_keycode: int) -> str:
    return (
        'Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"",'
        '"device":-1,"window_id":0,"alt_pressed":false,"shift_pressed":false,'
        '"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":0,'
        f'"physical_keycode":{physical_keycode},"key_label":0,"unicode":0,'
        '"location":0,"echo":false,"script":null)'
    )


def _input_map_section() -> str:
    lines = ["[input]", ""]
    for action, keycode in _INPUT_ACTIONS.items():
        lines.append(f"{action}={{")
        lines.append('"deadzone": 0.5,')
        lines.append(f'"events": [{_key_event(keycode)}]')
        lines.append("}")
    return "\n".join(lines) + "\n"


class ProjectWriterError(ValueError):
    """Machine-readable failure (mirrors the brain's PCGError shape)."""

    def __init__(self, code: str, path: str, message: str, hint: str) -> None:
        super().__init__(message)
        self.code = code
        self.path = path
        self.message = message
        self.hint = hint

    def to_dict(self) -> dict:
        return {
            "code": self.code,
            "path": self.path,
            "message": self.message,
            "hint": self.hint,
        }


def pascal_case(identifier: str) -> str:
    """snake_case -> PascalCase, keeping a trailing numeric suffix.

    castle_guard_02 -> CastleGuard_02
    """
    parts = identifier.split("_")
    suffix = ""
    if parts and parts[-1].isdigit():
        suffix = f"_{parts[-1]}"
        parts = parts[:-1]
    return "".join(p.capitalize() for p in parts if p) + suffix


def _transform(x: float, y: float, z: float) -> str:
    return f"Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, {x:g}, {y:g}, {z:g})"


def _room_center(room: dict, y_offset: float = 0.0) -> str:
    """Transform at a room's horizontal centre, `y_offset` above its floor —
    where the spawn marker and the win/key zones all sit."""
    return _transform(
        room["x"] + room["width"] / 2,
        room["elevation"] + y_offset,
        room["z"] + room["depth"] / 2,
    )


def _floor_block(
    name: str, cx: float, cz: float, width: float, depth: float, top_y: float
) -> tuple[str, str]:
    """Return (sub_resources, nodes) text for one named floor slab."""
    cy = top_y - FLOOR_THICKNESS / 2
    subs = (
        f'[sub_resource type="BoxMesh" id="Mesh{name}"]\n'
        f"size = Vector3({width:g}, {FLOOR_THICKNESS:g}, {depth:g})\n\n"
        f'[sub_resource type="BoxShape3D" id="Shape{name}"]\n'
        f"size = Vector3({width:g}, {FLOOR_THICKNESS:g}, {depth:g})\n\n"
    )
    nodes = (
        f'[node name="{name}" type="StaticBody3D" parent="."]\n'
        f"transform = {_transform(cx, cy, cz)}\n\n"
        f'[node name="{name}Mesh" type="MeshInstance3D" parent="{name}"]\n'
        f'mesh = SubResource("Mesh{name}")\n'
        'material_override = SubResource("MatFloor")\n\n'
        f'[node name="{name}Shape" type="CollisionShape3D" parent="{name}"]\n'
        f'shape = SubResource("Shape{name}")\n\n'
    )
    return subs, nodes


def _ramp_block(
    name: str,
    p_from: tuple[float, float],
    p_to: tuple[float, float],
    width: float,
    e_from: float,
    e_to: float,
) -> tuple[str, str]:
    """A sloped floor slab connecting two elevations along an axis-aligned segment."""
    (ax, az), (bx, bz) = p_from, p_to
    rise = e_to - e_from
    cx, cz = (ax + bx) / 2, (az + bz) / 2
    cy = (e_from + e_to) / 2 - FLOOR_THICKNESS / 2
    # .tscn Transform3D(...) serializes the basis ROW-major. The local x/z
    # axis (as a column) must be (c, s, 0) / (0, s, c) so the slab surface
    # rises along the travel direction — written as rows, the sine terms
    # sit transposed. (Getting this backwards flips the slope; found by
    # the walk-probe bot wedging at the ramp foot.)
    if abs(bx - ax) >= abs(bz - az):  # runs along x
        h = bx - ax
        hyp = math.hypot(h, rise)
        c, s = h / hyp, rise / hyp
        basis = f"{c:.6g}, {-s:.6g}, 0, {s:.6g}, {c:.6g}, 0, 0, 0, 1"
        size = (hyp, FLOOR_THICKNESS, width)
    else:  # runs along z
        h = bz - az
        hyp = math.hypot(h, rise)
        c, s = h / hyp, rise / hyp
        basis = f"1, 0, 0, 0, {c:.6g}, {s:.6g}, 0, {-s:.6g}, {c:.6g}"
        size = (width, FLOOR_THICKNESS, hyp)
    subs = (
        f'[sub_resource type="BoxMesh" id="Mesh{name}"]\n'
        f"size = Vector3({size[0]:.6g}, {size[1]:g}, {size[2]:.6g})\n\n"
        f'[sub_resource type="BoxShape3D" id="Shape{name}"]\n'
        f"size = Vector3({size[0]:.6g}, {size[1]:g}, {size[2]:.6g})\n\n"
    )
    nodes = (
        f'[node name="{name}" type="StaticBody3D" parent="."]\n'
        f"transform = Transform3D({basis}, {cx:g}, {cy:g}, {cz:g})\n\n"
        f'[node name="{name}Mesh" type="MeshInstance3D" parent="{name}"]\n'
        f'mesh = SubResource("Mesh{name}")\n'
        'material_override = SubResource("MatFloor")\n\n'
        f'[node name="{name}Shape" type="CollisionShape3D" parent="{name}"]\n'
        f'shape = SubResource("Shape{name}")\n\n'
    )
    return subs, nodes


def _locked_door_placement(
    plan: dict, rooms: dict, exit_id: str
) -> tuple[str, float, float, float] | None:
    """(axis, x, z, floor_y) where the locked corridor crosses the exit-room edge."""
    corridor = next((c for c in plan["corridors"] if c["kind"] == "locked"), None)
    if corridor is None or exit_id not in (corridor["a"], corridor["b"]):
        return None
    exit_room = rooms[exit_id]
    if corridor["b"] == exit_id:
        p_from, p_to = corridor["points"][-2], corridor["points"][-1]
    else:
        p_from, p_to = corridor["points"][1], corridor["points"][0]
    # Corridor floors meet the exit-room edge exactly at its elevation
    # (flat corridors run level; tier-crossing ramps top out at the edge).
    floor_y = exit_room["elevation"]
    (fx, fz), (tx, tz) = p_from, p_to
    if fx != tx:
        x_cross = exit_room["x"] if tx > fx else exit_room["x"] + exit_room["width"]
        return ("x", x_cross, fz, floor_y)
    z_cross = exit_room["z"] if tz > fz else exit_room["z"] + exit_room["depth"]
    return ("z", fx, z_cross, floor_y)


def _corridor_segments(
    corridor: dict, elevation: float
) -> list[tuple[str, float, float, float, float]]:
    """Split a 2-3 point axis-aligned polyline into (suffix, cx, cz, w, d) slabs."""
    width = corridor["width"]
    segments = []
    points = corridor["points"]
    for i in range(len(points) - 1):
        (ax, az), (bx, bz) = points[i], points[i + 1]
        cx, cz = (ax + bx) / 2, (az + bz) / 2
        # Pad by the corridor width so elbow segments join cleanly.
        w = abs(bx - ax) + width
        d = abs(bz - az) + width
        segments.append((f"_Seg{i + 1}", cx, cz, w, d))
    return segments


def _composite_from_dict(d: dict) -> tuple[CompositeObject, tuple[float, float, float], float]:
    """Parse a plan/spec composite object into a CompositeObject + world placement.

    Shape (ADR-0008): {object_id, bbox:[w,h,d], origin:[x,y,z], yaw_deg,
    parts:[{part_id, template_id, socket:{name,offset:[x,y,z],facing_deg,hinge},
    params, mesh_rel}]}. Kept lenient — a malformed part raises ProjectWriterError
    with a path, never a bare exception (rule 13)."""
    try:
        parts = tuple(
            AffordancePart(
                part_id=p["part_id"],
                template_id=p["template_id"],
                socket=Socket(
                    name=p["socket"].get("name", p["part_id"]),
                    offset=tuple(p["socket"]["offset"]),
                    facing_deg=float(p["socket"].get("facing_deg", 0.0)),
                    hinge=p["socket"].get("hinge", "y"),
                ),
                mesh_rel=p.get("mesh_rel"),
                params=p.get("params", {}),
            )
            for p in d.get("parts", [])
        )
        obj = CompositeObject(object_id=d["object_id"], bbox=tuple(d["bbox"]), parts=parts)
    except (KeyError, TypeError, ValueError) as exc:
        raise ProjectWriterError(
            code="composite_malformed",
            path=f"composites ({d.get('object_id', '?')})",
            message=f"could not parse composite object: {exc}",
            hint="Each part needs part_id, template_id, socket.offset [x,y,z].",
        ) from exc
    origin = tuple(d.get("origin", (0.0, 0.0, 0.0)))
    return obj, origin, float(d.get("yaw_deg", 0.0))


def write_project(
    plan: dict,
    title: str,
    out_dir: Path,
    templates_dir: Path | None = None,
    player_config: dict | None = None,
    enemy_configs: dict[str, dict] | None = None,
    lighting_preset: str = "overcast_day",
    kit_dir: Path | None = None,
    sfx_dir: Path | None = None,
    prop_configs: dict[str, str | None] | None = None,
    collect_quest: dict | None = None,
    asset_models: dict[str, Path] | None = None,
    asset_sounds: dict[str, dict[str, Path]] | None = None,
    composites: list[dict] | None = None,
    world_kind: str = "indoor",
) -> list[Path]:
    """Write the Godot project for a level plan; returns the written file paths.

    When ``templates_dir`` (the repo's ``engine/templates``) is given, vetted
    template scripts are copied into ``res://templates/``: the reach_zone
    objective attaches to a ``WinZone`` Area3D covering the exit room, and a
    playable ``Player`` (controller_third_person + capsule + SpringArm camera)
    spawns in the entry room with a WASD input map. ``player_config`` carries
    the spec's ``player`` object (``move_speed``, ``health``) onto the node.
    """
    version = plan.get("level_plan_version")
    if version != SUPPORTED_PLAN_VERSION:
        raise ProjectWriterError(
            code="level_plan_version_unsupported",
            path="level_plan_version",
            message=f"level plan version {version!r} != supported {SUPPORTED_PLAN_VERSION!r}",
            hint="Regenerate the plan with the matching brain (pcg/serialize.py).",
        )
    preset = LIGHTING_PRESETS.get(lighting_preset)
    if preset is None:
        raise ProjectWriterError(
            code="lighting_preset_unknown",
            path="world.lighting_preset_id",
            message=f"no vetted lighting preset '{lighting_preset}'",
            hint=f"Known: {', '.join(sorted(LIGHTING_PRESETS))}.",
        )

    ext_blocks: list[str] = []
    connection_blocks: list[str] = []
    template_files: list[tuple[Path, Path]] = []  # (source, project-relative dest)
    use_kit = kit_dir is not None and kit_files_exist(kit_dir)
    use_sfx = sfx_dir is not None and sound_files_exist(sfx_dir)
    kit_models_used: dict[str, str] = {}  # ext_id -> kit-relative model path
    kit_sounds_used: dict[str, str] = {}  # ext_id -> sfx-kit-relative clip name
    generated_models_used: dict[str, Path] = {}  # ext_id -> asset-farm GLB (absolute)
    generated_sounds_used: dict[str, Path] = {}  # ext_id -> asset-farm WAV (absolute)

    def _use_model(rel: str) -> str:
        ext_id = _kit_ext_id(rel)
        kit_models_used[ext_id] = rel
        return ext_id

    def _use_generated(src: Path) -> str:
        # Content-addressed by the farm already (brief_hash.glb), so N entities
        # sharing one brief share one file instead of copying it N times.
        ext_id = _kit_ext_id("gen/" + src.name)
        generated_models_used[ext_id] = src
        return ext_id

    def _entity_model(
        kind: str, source_id: str, kit_rel: str | None
    ) -> tuple[str | None, str | None]:
        """`(ext_id, worn_rel)` — the model an entity wears, and WHICH kit model it
        turned out to be. One place, so props and characters can never drift apart.

        `worn_rel` matters because other decisions hang off the body: the sound
        family is chosen from the model you actually wear, so returning it here is
        what stops a dog dying to the skeleton's bone-clatter. It is None for a
        generated model (not a kit file) and for the primitive stand-in.

        The farm's answer may be a CURATED model (the semantic tier picked a
        better one than this writer's default would) or a GENERATED one, so the
        path decides the route: a file inside the kit ships from res://kit/ and
        stays deduplicated, anything else is copied to res://assets/.
        """
        chosen = (asset_models or {}).get(f"{kind}:{source_id}")
        if chosen is not None and Path(chosen).is_file():
            chosen = Path(chosen)
            if kit_dir is not None:
                try:
                    rel = chosen.relative_to(kit_dir).as_posix()
                    return _use_model(rel), rel
                except ValueError:
                    pass  # not a kit file — it came from the farm
            return _use_generated(chosen), None
        if use_kit and kit_rel is not None:
            return _use_model(kit_rel), kit_rel
        return None, None

    def _use_sound(clip: str) -> str:
        ext_id = _kit_ext_id("sfx/" + clip)
        kit_sounds_used[ext_id] = clip
        return ext_id

    def _use_generated_sound(src: Path) -> str:
        ext_id = _kit_ext_id("gensfx/" + src.name)
        generated_sounds_used[ext_id] = src
        return ext_id

    def _sound_props(kind: str, source_id: str, model_rel: str | None) -> str:
        """The character's sound banks, per activity.

        A clip the farm made for THIS character wins over the curated set its
        model family shares — that is the whole point: a dog should bark, not
        rattle like the skeleton whose sound set it borrowed. Any activity the
        farm didn't produce falls back to that curated bank, so a partial
        generation still leaves a fully-sounding character.
        """
        generated = (asset_sounds or {}).get(f"{kind}:{source_id}", {})
        if not use_sfx and not generated:
            return ""  # nothing to say and nothing to say it with — stay silent
        banks = enemy_sounds(model_rel)
        out = ""
        for activity in ("attack", "hit", "death", "step"):
            made = generated.get(activity)
            if made is not None and Path(made).is_file():
                refs = f'ExtResource("{_use_generated_sound(Path(made))}")'
            elif use_sfx:
                refs = ", ".join(f'ExtResource("{_use_sound(c)}")' for c in banks[activity])
            else:
                continue  # no curated kit and nothing generated for this activity
            out += f"sfx_{activity} = Array[AudioStream]([{refs}])\n"
        return out

    rooms = {r["zone_id"]: r for r in plan["rooms"]}
    zones = {z["zone_id"]: z for z in plan["zones"]}
    entry_id = next(zid for zid, z in zones.items() if z["kind"] == "entry")

    sub_blocks: list[str] = []
    node_blocks: list[str] = []

    for zone_id in sorted(rooms):
        r = rooms[zone_id]
        name = f"Room{pascal_case(zone_id)}"
        subs, nodes = _floor_block(
            name,
            cx=r["x"] + r["width"] / 2,
            cz=r["z"] + r["depth"] / 2,
            width=r["width"],
            depth=r["depth"],
            top_y=r["elevation"],
        )
        sub_blocks.append(subs)
        node_blocks.append(nodes)

    for corridor in plan["corridors"]:
        e_a = rooms[corridor["a"]]["elevation"]
        e_b = rooms[corridor["b"]]["elevation"]
        base = f"Corridor{pascal_case(corridor['a'])}{pascal_case(corridor['b'])}"
        width = corridor["width"]
        segments = _corridor_segments(corridor, min(e_a, e_b))
        if e_a == e_b:
            for suffix, cx, cz, w, d in segments:
                subs, nodes = _floor_block(base + suffix, cx, cz, w, d, e_a)
                sub_blocks.append(subs)
                node_blocks.append(nodes)
            continue

        # Tier-crossing corridor. The ramp's placement is decided by
        # walls.ramp_geometry() — the SAME function the navmesh uses, so the slab
        # and its walkable polygons can never disagree. Legs beyond the ramp sit
        # at the UPPER elevation (the ramp has already done the climbing).
        geom = ramp_geometry(plan, corridor)
        e_lo, e_hi = geom["e_lo"], geom["e_hi"]
        ramp_leg, order = geom["ramp_leg"], geom["order"]
        ramp_start, crossing = geom["foot"], geom["top"]
        beyond = set(order[order.index(ramp_leg) + 1 :])
        pts = corridor["points"]

        for k, (suffix, cx, cz, w, d) in enumerate(segments):
            if k != ramp_leg:
                subs, nodes = _floor_block(
                    base + suffix, cx, cz, w, d, e_hi if k in beyond else e_lo
                )
                sub_blocks.append(subs)
                node_blocks.append(nodes)
                continue

            # The leg reads: lower_end -> foot -> top -> upper_end. All three pieces
            # must be laid, or the corridor has a HOLE. The ramp can sit in the
            # middle of a long leg, and emitting only the approach + the ramp left
            # the floor simply STOPPING at the ramp's top — a gap between the ramp
            # and the room it climbs to, which no one could cross.
            (ax, az), (bx, bz) = pts[k], pts[k + 1]
            along_x = geom["axis"] == "x"
            a_c, b_c = (ax, bx) if along_x else (az, bz)
            foot_c = ramp_start[0] if along_x else ramp_start[1]
            top_c = crossing[0] if along_x else crossing[1]
            climbing = top_c > foot_c
            lower_end = min(a_c, b_c) if climbing else max(a_c, b_c)
            upper_end = max(a_c, b_c) if climbing else min(a_c, b_c)

            def _leg_slab(c0: float, c1: float, top_y: float, node_name: str) -> None:
                length = abs(c1 - c0)
                if length <= 1e-6:
                    return
                if along_x:  # noqa: B023 — read in the same iteration
                    cx2, cz2, w2, d2 = (c0 + c1) / 2, az, length, width  # noqa: B023
                else:
                    cx2, cz2, w2, d2 = ax, (c0 + c1) / 2, width, length  # noqa: B023
                s, n = _floor_block(node_name, cx2, cz2, w2, d2, top_y)
                sub_blocks.append(s)
                node_blocks.append(n)

            # Flat run up to the ramp foot. It must END at the foot: any floor
            # beneath the rising slab recreates the wedge trap.
            _leg_slab(lower_end, foot_c, e_lo, base + suffix)
            subs, nodes = _ramp_block(
                base + suffix + "Ramp", ramp_start, crossing, width, e_lo, e_hi
            )
            sub_blocks.append(subs)
            node_blocks.append(nodes)
            # ...and the flat run BEYOND the top, at the upper elevation.
            _leg_slab(top_c, upper_end, e_hi, base + suffix + "Top")

    # Indoor: wall each room. Outdoor (a village/field): NO room walls — instead an
    # open ground plane + a mountain ring border. The room floors + corridors +
    # navmesh stay identical, so the bot routes the same; only the look changes
    # (walled dungeon -> open outdoor space). Houses come from planner-authored
    # building objects (composites), not from here.
    if world_kind == "outdoor":
        terrain_subs, terrain_nodes = outdoor_blocks(plan)
        sub_blocks.append(terrain_subs)
        node_blocks.append(terrain_nodes)
    else:
        node_blocks.append('[node name="Walls" type="StaticBody3D" parent="."]\n\n')
        for idx, run in enumerate(wall_runs(plan), start=1):
            name = f"Wall_{idx:03d}"
            if run.axis == "x":
                size = (run.length, WALL_HEIGHT, WALL_THICKNESS)
                center = (run.x + run.length / 2, run.elevation + WALL_HEIGHT / 2, run.z)
            else:
                size = (WALL_THICKNESS, WALL_HEIGHT, run.length)
                center = (run.x, run.elevation + WALL_HEIGHT / 2, run.z + run.length / 2)
            sub_blocks.append(
                f'[sub_resource type="BoxMesh" id="Mesh{name}"]\n'
                f"size = Vector3({size[0]:g}, {size[1]:g}, {size[2]:g})\n\n"
                f'[sub_resource type="BoxShape3D" id="Shape{name}"]\n'
                f"size = Vector3({size[0]:g}, {size[1]:g}, {size[2]:g})\n\n"
            )
            node_blocks.append(
                f'[node name="{name}" type="MeshInstance3D" parent="Walls"]\n'
                f"transform = {_transform(*center)}\n"
                f'mesh = SubResource("Mesh{name}")\n'
                'material_override = SubResource("MatWall")\n\n'
                f'[node name="{name}Shape" type="CollisionShape3D" parent="Walls"]\n'
                f"transform = {_transform(*center)}\n"
                f'shape = SubResource("Shape{name}")\n\n'
            )

    # --- atmospheric dressing: corner torches (visual only, never blocks) -----
    if use_kit:
        torch_ext = _use_model(TORCH_MODEL)
        torches: list[str] = []
        for room in rooms.values():
            if min(room["width"], room["depth"]) < TORCH_MIN_ROOM_SIDE:
                continue  # too small — corner torches would crowd the floor
            ins = TORCH_CORNER_INSET
            for cx, cz in (
                (room["x"] + ins, room["z"] + ins),
                (room["x"] + room["width"] - ins, room["z"] + ins),
                (room["x"] + ins, room["z"] + room["depth"] - ins),
                (room["x"] + room["width"] - ins, room["z"] + room["depth"] - ins),
            ):
                n = len(torches) + 1
                torches.append(
                    f'[node name="Torch_{n:03d}" parent="Dressing" '
                    f'instance=ExtResource("{torch_ext}")]\n'
                    f"transform = {_transform(cx, room['elevation'], cz)}\n\n"
                )
        if torches:  # parent node first, then its children (Godot .tscn ordering)
            node_blocks.append('[node name="Dressing" type="Node3D" parent="."]\n\n')
            node_blocks.extend(torches)

    entry = rooms[entry_id]
    node_blocks.append(
        f'[node name="PlayerSpawn" type="Marker3D" parent="."]\n'
        f"transform = {_room_center(entry)}\n\n"
    )

    # Decided BEFORE the entity loop so the pickups it emits and the CollectQuest
    # node emitted later can never disagree about whether a quest exists.
    exit_id = next(zid for zid, z in zones.items() if z["kind"] == "exit")
    key_id = next((zid for zid, z in zones.items() if z["kind"] == "key"), None)
    door = _locked_door_placement(plan, rooms, exit_id)
    lock_chain = key_id is not None and door is not None
    quest = (
        collect_quest
        if (collect_quest and lock_chain and templates_dir is not None)
        else None
    )
    pickup_ids = set(quest["prop_ids"]) if quest else set()
    pickup_nodes: list[str] = []

    enemy_index = 0
    for e in plan["entities"]:
        name = pascal_case(e["entity_id"])
        if e["kind"] == "prop" and e["source_id"] in pickup_ids:
            model = prop_model((prop_configs or {}).get(e["source_id"])) if use_kit else None
            visual = (
                f'[node name="Visual" parent="{name}" '
                f'instance=ExtResource("{_use_model(model)}")]\n\n'
                if model is not None
                else f'[node name="Visual" type="MeshInstance3D" parent="{name}"]\n'
                'mesh = SubResource("MeshKeyBeacon")\n'
                'material_override = SubResource("MatKeyBeacon")\n\n'
            )
            node_blocks.append(
                f'[node name="{name}" type="Area3D" parent="."]\n'
                f"transform = {_transform(e['x'], e['elevation'] + 0.6, e['z'])}\n"
                "collision_layer = 0\n"
                "collision_mask = 2\n"  # the player's layer
                'script = ExtResource("9_pickup")\n'
                f'prop_id = "{e["source_id"]}"\n\n'
                f'[node name="{name}Shape" type="CollisionShape3D" parent="{name}"]\n'
                'shape = SubResource("ShapePickup")\n\n' + visual
            )
            pickup_nodes.append(name)
            continue
        if templates_dir is not None and e["kind"] == "enemy":
            cfg = (enemy_configs or {}).get(e["source_id"], {})
            stat_props = "".join(
                f"{key} = {cfg[key]:g}\n" for key in ("health", "damage", "speed") if key in cfg
            )
            default_rel = enemy_model(enemy_index) if use_kit else None
            enemy_ext_id, enemy_rel = _entity_model("enemy", e["source_id"], default_rel)
            if enemy_ext_id is not None:
                visual = (
                    f'[node name="{name}Visual" parent="{name}" '
                    f'instance=ExtResource("{enemy_ext_id}")]\n\n'
                )
            else:
                visual = (
                    f'[node name="{name}Mesh" type="MeshInstance3D" parent="{name}"]\n'
                    "transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.9, 0)\n"
                    'mesh = SubResource("MeshEnemy")\n'
                    'material_override = SubResource("MatEnemy")\n\n'
                )
            # Audio players are real, named nodes so a player who downloads the
            # project can see and retune them (the "beginning, not an end" promise).
            # They exist iff this character actually has something to play —
            # curated, generated, or a mix of the two.
            sound_props = _sound_props("enemy", e["source_id"], enemy_rel)
            audio_nodes = (
                (
                    f'[node name="Sfx" type="AudioStreamPlayer3D" parent="{name}"]\n'
                    "transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.2, 0)\n"
                    f"max_distance = {ENEMY_AUDIO_MAX_DISTANCE:g}\n\n"
                    f'[node name="SfxSteps" type="AudioStreamPlayer3D" parent="{name}"]\n'
                    f"max_distance = {ENEMY_AUDIO_MAX_DISTANCE:g}\n"
                    f"volume_db = {ENEMY_STEP_VOLUME_DB:g}\n\n"
                )
                if sound_props
                else ""
            )
            node_blocks.append(
                f'[node name="{name}" type="CharacterBody3D" parent="."]\n'
                f"transform = {_transform(e['x'], e['elevation'] + 0.1, e['z'])}\n"
                "collision_layer = 4\n"
                "collision_mask = 1\n"
                'script = ExtResource("4_ai")\n'
                + stat_props
                + sound_props
                + "\n"
                f'[node name="{name}Shape" type="CollisionShape3D" parent="{name}"]\n'
                "transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.9, 0)\n"
                'shape = SubResource("ShapeEnemy")\n\n'
                + visual
                + f'[node name="NavigationAgent3D" type="NavigationAgent3D" parent="{name}"]\n\n'
                + audio_nodes
            )
            enemy_index += 1
            continue

        prop_template = (prop_configs or {}).get(e["source_id"])
        # A door is a FUNCTIONAL node (the swinging LockedDoor slab emitted below),
        # never a model — so it must not wear one even if the farm made it one.
        ext_id = (
            _entity_model("prop", e["source_id"], prop_model(prop_template))[0]
            if e["kind"] == "prop" and prop_template not in FUNCTIONAL_PROPS
            else None
        )
        if ext_id is not None:
            turns = sum(ord(c) for c in e["entity_id"]) % 4  # deterministic variety
            node_blocks.append(
                f'[node name="{name}" parent="." instance=ExtResource("{ext_id}")]\n'
                f"transform = Transform3D({_yaw_basis(turns)}, "
                f"{e['x']:g}, {e['elevation']:g}, {e['z']:g})\n\n"
            )
        else:
            node_blocks.append(
                f'[node name="{name}" type="Marker3D" parent="."]\n'
                f"transform = {_transform(e['x'], e['elevation'], e['z'])}\n\n"
            )

    if templates_dir is not None:
        for template in (
            REACH_ZONE_TEMPLATE,
            CONTROLLER_TEMPLATE,
            TOPDOWN_TEMPLATE,
            ISOMETRIC_TEMPLATE,
            DOOR_TEMPLATE,
            AI_TEMPLATE,
            DEATH_TEMPLATE,
            HUD_TEMPLATE,
            PICKUP_TEMPLATE,
            COLLECT_TEMPLATE,
        ):
            source = templates_dir / template
            if not source.is_file():
                raise ProjectWriterError(
                    code="template_missing",
                    path=str(template),
                    message=f"vetted template not found: {source}",
                    hint="Pass the repo's engine/templates directory as templates_dir.",
                )
            template_files.append((source, Path("templates") / template))

        exit_room = rooms[exit_id]
        # A collect_n quest REPLACES the key zone as what unlocks the exit door:
        # the spatial spine (entry -> ... -> locked door -> exit) is unchanged, so
        # every reachability guarantee still holds — only the GOAL differs
        # ("gather 5 relics" instead of "walk into the key room").
        unlock_id = quest["objective_id"] if quest else KEY_OBJECTIVE_ID
        ext_blocks.append(
            '[ext_resource type="Script" '
            'path="res://templates/objectives/reach_zone.gd" id="1_reachzone"]\n'
            '[ext_resource type="Script" '
            'path="res://templates/controllers/controller_third_person.gd" id="2_controller"]\n'
            '[ext_resource type="Script" '
            'path="res://templates/interactables/door_hinged.gd" id="3_door"]\n'
            '[ext_resource type="Script" '
            'path="res://templates/ai/ai_patrol_chase.gd" id="4_ai"]\n'
            '[ext_resource type="Script" '
            'path="res://templates/objectives/player_death.gd" id="5_death"]\n'
            '[ext_resource type="Script" '
            'path="res://templates/ui/hud_basic.gd" id="6_hud"]\n'
            '[ext_resource type="Script" '
            'path="res://templates/controllers/controller_topdown_3d.gd" id="7_topdown"]\n'
            '[ext_resource type="Script" '
            'path="res://templates/controllers/controller_isometric_3d.gd" id="8_iso"]\n'
            '[ext_resource type="Script" '
            'path="res://templates/interactables/pickup_collectible.gd" id="9_pickup"]\n'
            '[ext_resource type="Script" '
            'path="res://templates/objectives/collect_n.gd" id="10_collect"]\n\n'
        )
        if quest:
            sub_blocks.append(
                '[sub_resource type="BoxShape3D" id="ShapePickup"]\n'
                "size = Vector3(1.8, 2.4, 1.8)\n\n"  # forgiving: walk near it, collect it
            )
        sub_blocks.append(
            '[sub_resource type="BoxShape3D" id="ShapeWinZone"]\n'
            f"size = Vector3({exit_room['width']:g}, 3, {exit_room['depth']:g})\n\n"
            '[sub_resource type="CapsuleShape3D" id="ShapePlayer"]\n'
            "radius = 0.4\nheight = 1.8\n\n"
            '[sub_resource type="CapsuleMesh" id="MeshPlayer"]\n'
            "radius = 0.4\nheight = 1.8\n\n"
            '[sub_resource type="CapsuleShape3D" id="ShapeEnemy"]\n'
            "radius = 0.4\nheight = 1.8\n\n"
            '[sub_resource type="CapsuleMesh" id="MeshEnemy"]\n'
            "radius = 0.4\nheight = 1.8\n\n"
            '[sub_resource type="StandardMaterial3D" id="MatPlayer"]\n'
            "albedo_color = Color(0.2, 0.45, 0.9, 1)\n\n"
            '[sub_resource type="StandardMaterial3D" id="MatEnemy"]\n'
            "albedo_color = Color(0.85, 0.15, 0.15, 1)\n\n"
            '[sub_resource type="StandardMaterial3D" id="MatDoor"]\n'
            "albedo_color = Color(0.55, 0.32, 0.1, 1)\n"
            "emission_enabled = true\n"
            "emission = Color(0.45, 0.25, 0.05, 1)\n"
            "emission_energy_multiplier = 0.6\n\n"
            '[sub_resource type="StandardMaterial3D" id="MatKeyBeacon"]\n'
            "albedo_color = Color(0.2, 0.9, 0.9, 1)\n"
            "emission_enabled = true\n"
            "emission = Color(0.2, 0.9, 0.9, 1)\n"
            "emission_energy_multiplier = 2.0\n\n"
            '[sub_resource type="CylinderMesh" id="MeshKeyBeacon"]\n'
            "top_radius = 0.4\nbottom_radius = 0.4\nheight = 6.0\n\n"
        )
        # Outdoor: one continuous ground navmesh (the bot must cross open space);
        # indoor: the per-room/corridor navmesh.
        if world_kind == "outdoor":
            nav_sub, nav_node = outdoor_navmesh_blocks(plan)
        else:
            nav_sub, nav_node = navmesh_tscn_blocks(plan)
        sub_blocks.append(nav_sub)
        node_blocks.append(nav_node)
        node_blocks.append(
            '[node name="WinZone" type="Area3D" parent="."]\n'
            f"transform = {_room_center(exit_room, 1.5)}\n"
            "collision_layer = 0\n"
            "collision_mask = 2\n"
            'script = ExtResource("1_reachzone")\n'
            + (f'requires_objective = "{unlock_id}"\n' if lock_chain else "")
            + "\n"
            '[node name="WinZoneShape" type="CollisionShape3D" parent="WinZone"]\n'
            'shape = SubResource("ShapeWinZone")\n\n'
        )

        if lock_chain and not quest:  # a collect quest REPLACES the key zone
            key_room = rooms[key_id]
            sub_blocks.append(
                '[sub_resource type="BoxShape3D" id="ShapeKeyZone"]\n'
                f"size = Vector3({key_room['width']:g}, 3, {key_room['depth']:g})\n\n"
            )
            node_blocks.append(
                '[node name="KeyZone" type="Area3D" parent="."]\n'
                f"transform = {_room_center(key_room, 1.5)}\n"
                "collision_layer = 0\n"
                "collision_mask = 2\n"
                'script = ExtResource("1_reachzone")\n'
                f'objective_id = "{KEY_OBJECTIVE_ID}"\n'
                "is_win_condition = false\n\n"
                '[node name="KeyZoneShape" type="CollisionShape3D" parent="KeyZone"]\n'
                'shape = SubResource("ShapeKeyZone")\n\n'
                '[node name="KeyBeacon" type="MeshInstance3D" parent="KeyZone"]\n'
                "transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1.5, 0)\n"
                'mesh = SubResource("MeshKeyBeacon")\n'
                'material_override = SubResource("MatKeyBeacon")\n\n'
                '[node name="KeyBeaconSign" type="Label3D" parent="KeyZone"]\n'
                "transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 5.2, 0)\n"
                'text = "KEY ZONE"\n'
                "billboard = 1\n"
                "font_size = 64\n"
                "modulate = Color(0.4, 1, 1, 1)\n\n"
            )

        if lock_chain:  # the locked door + exit spine exists for BOTH objective types
            axis, dx, dz, floor_y = door
            span = plan["corridors"][0]["width"] + DOOR_SPAN_PAD  # all corridors share width
            if axis == "x":  # corridor runs along x -> door plane spans z
                size = (0.2, DOOR_HEIGHT, span)
                origin = (dx, floor_y, dz - span / 2)
                offset = (0.0, DOOR_HEIGHT / 2, span / 2)
            else:  # corridor runs along z -> door plane spans x
                size = (span, DOOR_HEIGHT, 0.2)
                origin = (dx - span / 2, floor_y, dz)
                offset = (span / 2, DOOR_HEIGHT / 2, 0.0)
            sub_blocks.append(
                '[sub_resource type="BoxMesh" id="MeshLockedDoor"]\n'
                f"size = Vector3({size[0]:g}, {size[1]:g}, {size[2]:g})\n\n"
                '[sub_resource type="BoxShape3D" id="ShapeLockedDoor"]\n'
                f"size = Vector3({size[0]:g}, {size[1]:g}, {size[2]:g})\n\n"
                '[sub_resource type="BoxShape3D" id="ShapeLockedDoorZone"]\n'
                f"size = Vector3({size[0] + 4:g}, {size[1]:g}, {size[2] + 4:g})\n\n"
            )
            node_blocks.append(
                '[node name="LockedDoor" type="StaticBody3D" parent="."]\n'
                f"transform = {_transform(*origin)}\n"
                'script = ExtResource("3_door")\n'
                "locked = true\n"
                f'unlocked_by_objective = "{unlock_id}"\n\n'
                '[node name="LockedDoorMesh" type="MeshInstance3D" parent="LockedDoor"]\n'
                f"transform = {_transform(*offset)}\n"
                'mesh = SubResource("MeshLockedDoor")\n'
                'material_override = SubResource("MatDoor")\n\n'
                '[node name="LockedDoorShape" type="CollisionShape3D" parent="LockedDoor"]\n'
                f"transform = {_transform(*offset)}\n"
                'shape = SubResource("ShapeLockedDoor")\n\n'
                '[node name="InteractZone" type="Area3D" parent="LockedDoor"]\n'
                "collision_layer = 0\n"
                "collision_mask = 2\n\n"
                '[node name="InteractZoneShape" type="CollisionShape3D" '
                'parent="LockedDoor/InteractZone"]\n'
                f"transform = {_transform(*offset)}\n"
                'shape = SubResource("ShapeLockedDoorZone")\n\n'
                '[node name="LockedDoorSign" type="Label3D" parent="LockedDoor"]\n'
                f"transform = {_transform(offset[0], DOOR_HEIGHT + 0.8, offset[2])}\n"
                'text = "EXIT DOOR (E)"\n'
                "billboard = 1\n"
                "font_size = 64\n"
                "modulate = Color(1, 0.85, 0.3, 1)\n\n"
            )
            # Whatever unlocks the door — the KeyZone or the CollectQuest — emits the
            # same objective_completed(id), so the door/win/HUD wiring is identical.
            unlock_node = "CollectQuest" if quest else "KeyZone"
            connection_blocks.append(
                f'[connection signal="objective_completed" from="{unlock_node}" '
                'to="LockedDoor" method="_on_objective_completed"]\n'
                f'[connection signal="objective_completed" from="{unlock_node}" '
                'to="WinZone" method="on_required_objective_completed"]\n'
                f'[connection signal="objective_completed" from="{unlock_node}" '
                'to="Hud" method="on_objective_completed"]\n'
            )

        cfg = player_config or {}
        player_props = "".join(
            f"{prop} = {cfg[key]:g}\n"
            for prop, key in (("move_speed", "move_speed"), ("health", "health"))
            if key in cfg
        )
        px = entry["x"] + entry["width"] / 2
        pz = entry["z"] + entry["depth"] / 2
        controller_id = (player_config or {}).get(
            "controller_template_id", "controller_third_person"
        )
        if controller_id not in CONTROLLER_EXT_IDS:
            raise ProjectWriterError(
                code="controller_unknown",
                path="player.controller_template_id",
                message=f"no vetted controller template for '{controller_id}'",
                hint=f"Known: {', '.join(sorted(CONTROLLER_EXT_IDS))}.",
            )
        # WHO the player is (spec v2.1.0 player.asset_brief, resolved by the farm).
        # There is no curated player model, so with no brief the capsule stands in.
        player_ext_id, _player_rel = _entity_model("player", "main", None)
        player_visual = (
            f'[node name="PlayerVisual" parent="Player" '
            f'instance=ExtResource("{player_ext_id}")]\n\n'
            if player_ext_id is not None
            else '[node name="PlayerMesh" type="MeshInstance3D" parent="Player"]\n'
            "transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.9, 0)\n"
            'mesh = SubResource("MeshPlayer")\n'
            'material_override = SubResource("MatPlayer")\n\n'
        )
        node_blocks.append(
            '[node name="Player" type="CharacterBody3D" parent="." groups=["player"]]\n'
            f"transform = {_transform(px, entry['elevation'] + 1.0, pz)}\n"
            "collision_layer = 2\n"
            "collision_mask = 1\n"
            f'script = ExtResource("{CONTROLLER_EXT_IDS[controller_id]}")\n'
            + player_props
            + "\n"
            '[node name="PlayerShape" type="CollisionShape3D" parent="Player"]\n'
            "transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.9, 0)\n"
            'shape = SubResource("ShapePlayer")\n\n'
            + player_visual
            + _camera_rig(controller_id)
        )

        if quest:
            node_blocks.append(
                '[node name="CollectQuest" type="Node" parent="."]\n'
                'script = ExtResource("10_collect")\n'
                f'objective_id = "{quest["objective_id"]}"\n'
                f"required_count = {quest['required_count']}\n\n"
            )
            for pickup in pickup_nodes:
                connection_blocks.append(
                    f'[connection signal="collected" from="{pickup}" '
                    'to="CollectQuest" method="on_pickup_collected"]\n'
                )
            connection_blocks.append(
                '[connection signal="progress_changed" from="CollectQuest" '
                'to="Hud" method="on_objective_progress"]\n'
            )

        hud_props = (
            f'key_objective_id = "{unlock_id}"\n'
            f'collect_label = "{quest["label"]}"\n'
            f'hint_locked = "Collect {quest["required_count"]} {quest["label"].lower()} '
            'to unlock the exit door."\n'
            if quest
            else ""
        )
        node_blocks.append(
            '[node name="FailStatePlayerDeath" type="Node" parent="."]\n'
            'script = ExtResource("5_death")\n\n'
            '[node name="Hud" type="CanvasLayer" parent="."]\n'
            'script = ExtResource("6_hud")\n'
            f"max_health = {cfg.get('health', 100):g}\n" + hud_props + "\n"
        )
        connection_blocks.append(
            '[connection signal="died" from="Player" '
            'to="FailStatePlayerDeath" method="_on_player_died"]\n'
            '[connection signal="health_changed" from="Player" '
            'to="Hud" method="_on_health_changed"]\n'
        )

    # Composite interactive objects (ADR-0008): a parent holder with affordance
    # PARTS (doors, lids, levers) as separate template-bound nodes at sockets, plus
    # an optional body shell. Emitted BEFORE the model ext-resource loops below so
    # its _use_model/_use_generated bodies are captured (a body added after those
    # loops would dangle). Requires the door/pickup templates.
    if composites:
        if templates_dir is None:
            raise ProjectWriterError(
                code="composites_need_templates",
                path="composites",
                message="composite objects need the interactable templates copied in",
                hint="Pass templates_dir (engine/templates) when using composites.",
            )
        for cdict in composites:
            obj, origin, yaw = _composite_from_dict(cdict)
            # The body shell may be a kit-relative model (curated) or an absolute
            # GLB the farm generated — same split as _entity_model. None -> the
            # object is its affordances alone (doors without a body), still valid.
            parent_mesh = cdict.get("parent_mesh_rel")
            parent_ext = None
            body_scale = 1.0
            if parent_mesh:
                mesh_path = Path(parent_mesh)
                # Decide kit-vs-generated by LOCATION (same as _entity_model): a
                # path UNDER kit_dir is a curated model shipped from res://kit at
                # real scale; anything else is a generated GLB copied to
                # res://assets and scaled up to the object's footprint. (Testing
                # `kit_dir / abspath` is wrong — an absolute path collapses through
                # the join and always "exists", stealing every body into the kit.)
                used_kit = False
                if kit_dir is not None:
                    try:
                        rel = mesh_path.relative_to(kit_dir).as_posix()
                        parent_ext = _use_model(rel)
                        used_kit = True
                    except ValueError:
                        pass
                if not used_kit and mesh_path.is_file():
                    parent_ext = _use_generated(mesh_path)
                    # A generated body is normalised to GENERATED_BODY_SIZE_M (see
                    # backends_local._normalise_for_godot); grow it to the object's
                    # longest footprint dimension so it fills the door layout.
                    longest = max(obj.bbox) if obj.bbox else GENERATED_BODY_SIZE_M
                    body_scale = longest / GENERATED_BODY_SIZE_M
            # Per-part visual meshes (Phase 4c): a part may carry its own panel mesh
            # (a curated/generated door), routed kit-vs-generated by location like
            # the body. A generated panel is normalised small -> scaled to the door
            # height. Absent -> the part keeps the default box slab.
            part_mesh_exts: dict[str, tuple[str, float]] = {}
            for part in cdict.get("parts", []):
                pm = part.get("mesh_rel")
                if not pm:
                    continue
                pm_path = Path(pm)
                if kit_dir is not None:
                    try:
                        rel = pm_path.relative_to(kit_dir).as_posix()
                        part_mesh_exts[part["part_id"]] = (_use_model(rel), 1.0)
                        continue
                    except ValueError:
                        pass
                if pm_path.is_file():
                    scale = DOOR_HEIGHT_M / GENERATED_BODY_SIZE_M
                    part_mesh_exts[part["part_id"]] = (_use_generated(pm_path), scale)
            c_subs, c_nodes, c_conns = composite_blocks(
                obj,
                origin,
                yaw,
                door_ext_id="3_door",
                pickup_ext_id="9_pickup",
                parent_mesh_ext_id=parent_ext,
                body_scale=body_scale,
                part_mesh_exts=part_mesh_exts,
            )
            sub_blocks.append(c_subs)
            node_blocks.append(c_nodes)
            connection_blocks.append(c_conns)

    for ext_id, rel in sorted(kit_models_used.items()):
        ext_blocks.append(
            f'[ext_resource type="PackedScene" path="res://kit/{Path(rel).name}" id="{ext_id}"]\n'
        )
        template_files.append((kit_dir / rel, Path("kit") / Path(rel).name))
    if kit_models_used:
        ext_blocks.append("\n")

    for ext_id, src in sorted(generated_models_used.items(), key=lambda kv: kv[1].name):
        ext_blocks.append(
            f'[ext_resource type="PackedScene" path="res://assets/{src.name}" id="{ext_id}"]\n'
        )
        template_files.append((src, Path("assets") / src.name))
    if generated_models_used:
        ext_blocks.append("\n")

    for ext_id, clip in sorted(kit_sounds_used.items()):
        ext_blocks.append(
            f'[ext_resource type="AudioStream" path="res://sfx/{clip}" id="{ext_id}"]\n'
        )
        template_files.append((sfx_dir / clip, Path("sfx") / clip))
    if kit_sounds_used:
        ext_blocks.append("\n")

    for ext_id, src in sorted(generated_sounds_used.items(), key=lambda kv: kv[1].name):
        ext_blocks.append(
            f'[ext_resource type="AudioStream" path="res://sfx/{src.name}" id="{ext_id}"]\n'
        )
        template_files.append((src, Path("sfx") / src.name))
    if generated_sounds_used:
        ext_blocks.append("\n")

    env_sub, sun_node = environment_blocks(preset)
    xs = [r["x"] for r in rooms.values()] + [r["x"] + r["width"] for r in rooms.values()]
    zs = [r["z"] for r in rooms.values()] + [r["z"] + r["depth"] for r in rooms.values()]
    cx, cz = (min(xs) + max(xs)) / 2, (min(zs) + max(zs)) / 2
    support = (
        '[node name="WorldEnvironment" type="WorldEnvironment" parent="."]\n'
        'environment = SubResource("WorldEnv")\n\n'
        + sun_node
        + '[node name="PreviewCamera" type="Camera3D" parent="."]\n'
        f"transform = Transform3D(1, 0, 0, 0, 0.643, 0.766, 0, -0.766, 0.643, "
        f"{cx:g}, 40, {cz + 30:g})\n"
        + ("" if templates_dir is not None else "current = true\n")
        + "\n"
    )

    resources_text = "".join(ext_blocks) + env_sub + "".join(sub_blocks)
    load_steps = resources_text.count("[ext_resource ") + resources_text.count("[sub_resource ") + 1
    scene_text = (
        f"[gd_scene load_steps={load_steps} format=3]\n\n"
        + resources_text
        + '[node name="World" type="Node3D"]\n\n'
        + "".join(node_blocks)
        + support
        + "".join(connection_blocks)
    )

    project_text = (
        "; Generated by Serendib — editable project based on Godot Engine.\n"
        "config_version=5\n\n"
        "[application]\n\n"
        f'config/name="{title}"\n'
        'run/main_scene="res://main.tscn"\n'
        'config/features=PackedStringArray("4.6", "GL Compatibility")\n'
        'config/icon="res://branding/serendib_icon.svg"\n'
        'boot_splash/image="res://branding/serendib_splash.png"\n'
        "boot_splash/bg_color=Color(0.027, 0.039, 0.078, 1)\n"
        "boot_splash/fullsize=true\n"
        "boot_splash/use_filter=true\n\n"
        + ("" if templates_dir is None else _input_map_section() + "\n")
        + "[rendering]\n\n"
        'renderer/rendering_method="gl_compatibility"\n'
        'renderer/rendering_method.mobile="gl_compatibility"\n'
    )

    out_dir.mkdir(parents=True, exist_ok=True)
    written = []
    for filename, text in (("project.godot", project_text), ("main.tscn", scene_text)):
        path = out_dir / filename
        path.write_text(text, encoding="utf-8", newline="\n")
        written.append(path)
    for source_name, destination_name in (
        ("icon.svg", "serendib_icon.svg"),
        ("splash.png", "serendib_splash.png"),
    ):
        source = _SERENDIB_BRANDING / source_name
        if not source.is_file():
            raise ProjectWriterError(
                code="serendib_branding_missing",
                path=str(source),
                message="required Serendib runtime branding asset is missing",
                hint="restore engine/serendib/branding before compiling projects",
            )
        destination = out_dir / "branding" / destination_name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        written.append(destination)
    for source, rel_dest in template_files:
        dest = out_dir / rel_dest
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
        written.append(dest)
    return written
