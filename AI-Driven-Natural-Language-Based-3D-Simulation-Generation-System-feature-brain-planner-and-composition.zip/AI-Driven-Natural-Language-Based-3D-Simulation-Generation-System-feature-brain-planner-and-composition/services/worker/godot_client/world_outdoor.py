"""Outdoor world materialisation: open ground + a mountain ring, no room walls.

The insight that makes "a village" safe to build: an outdoor world reuses the
SAME room/corridor plan, navmesh, placement and validation as indoor — it is only
MATERIALISED differently. Instead of walling each room, we:

  * lay one big walkable GROUND plane under the whole level (+ a margin),
  * ring it with raised MOUNTAIN blocks (a bounded playfield, so nothing walks
    off the edge — these carry collision, the map's real border),
  * and skip the interior room walls entirely (open space).

The room floors + corridors stay (they are the streets/plazas the navmesh already
routes on, so the bot works unchanged), and the *houses* are the building objects
the planner authors (composite objects, archetype "building" → a generated body)
— they arrive through the normal entity/object path, not from here. So this module
only paints the terrain; the world's contents come from the same pipeline.

Pure text, no Godot, unit-testable. Reuses the writer's floor/wall box idiom.
"""

from __future__ import annotations

GROUND_MARGIN = 8.0  # how far the ground + mountains extend past the rooms
GROUND_THICKNESS = 0.5
MOUNTAIN_HEIGHT = 12.0  # tall enough to read as a boundary range, not a fence
MOUNTAIN_THICKNESS = 6.0


def _bounds(plan: dict) -> tuple[float, float, float, float, float]:
    """(min_x, min_z, max_x, max_z, min_elevation) over all room footprints."""
    rooms = plan.get("rooms", [])
    xs = [r["x"] for r in rooms]
    zs = [r["z"] for r in rooms]
    x2 = [r["x"] + r["width"] for r in rooms]
    z2 = [r["z"] + r["depth"] for r in rooms]
    elevs = [r.get("elevation", 0.0) for r in rooms] or [0.0]
    return min(xs), min(zs), max(x2), max(z2), min(elevs)


def _box(name: str, cx: float, cy: float, cz: float, sx: float, sy: float, sz: float,
         material: str, parent: str = ".", collision: bool = True) -> tuple[str, str]:
    subs = (
        f'[sub_resource type="BoxMesh" id="Mesh{name}"]\n'
        f"size = Vector3({sx:g}, {sy:g}, {sz:g})\n\n"
    )
    node_type = "StaticBody3D" if collision else "Node3D"
    node = (
        f'[node name="{name}" type="{node_type}" parent="{parent}"]\n'
        f"transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, {cx:g}, {cy:g}, {cz:g})\n\n"
        f'[node name="{name}Mesh" type="MeshInstance3D" parent="{parent}/{name}"]\n'
        f'mesh = SubResource("Mesh{name}")\n'
        f'material_override = SubResource("{material}")\n\n'
    )
    if collision:
        subs += (
            f'[sub_resource type="BoxShape3D" id="Shape{name}"]\n'
            f"size = Vector3({sx:g}, {sy:g}, {sz:g})\n\n"
        )
        node += (
            f'[node name="{name}Shape" type="CollisionShape3D" parent="{parent}/{name}"]\n'
            f'shape = SubResource("Shape{name}")\n\n'
        )
    return subs, node


def outdoor_blocks(
    plan: dict, *, ground_material: str = "MatFloor", mountain_material: str = "MatWall"
) -> tuple[str, str]:
    """`(sub_resources, nodes)` for the outdoor terrain: ground plane + mountain ring.

    Sits UNDER the room floors (which stay as the walkable streets). The mountain
    ring is the bounded border. Room walls are NOT emitted by the caller in
    outdoor mode — the space is open.
    """
    min_x, min_z, max_x, max_z, base_y = _bounds(plan)
    gx0, gz0 = min_x - GROUND_MARGIN, min_z - GROUND_MARGIN
    gx1, gz1 = max_x + GROUND_MARGIN, max_z + GROUND_MARGIN
    gw, gd = gx1 - gx0, gz1 - gz0
    cx, cz = (gx0 + gx1) / 2, (gz0 + gz1) / 2

    subs: list[str] = []
    nodes: list[str] = ['[node name="Terrain" type="Node3D" parent="."]\n\n']

    # Ground: a big flat slab just below the room floors, so the whole playfield
    # reads as one continuous outdoor surface.
    g_subs, g_nodes = _box(
        "Ground", cx, base_y - GROUND_THICKNESS / 2, cz, gw, GROUND_THICKNESS, gd,
        ground_material, parent="Terrain",
    )
    subs.append(g_subs)
    nodes.append(g_nodes)

    # Mountain ring: four raised slabs around the ground edge — the border.
    h = MOUNTAIN_HEIGHT
    t = MOUNTAIN_THICKNESS
    my = base_y + h / 2
    ring = [
        ("MountainN", cx, my, gz0 - t / 2, gw + 2 * t, h, t),
        ("MountainS", cx, my, gz1 + t / 2, gw + 2 * t, h, t),
        ("MountainW", gx0 - t / 2, my, cz, t, h, gd),
        ("MountainE", gx1 + t / 2, my, cz, t, h, gd),
    ]
    for name, mx, myy, mz, sx, sy, sz in ring:
        m_subs, m_nodes = _box(name, mx, myy, mz, sx, sy, sz, mountain_material, parent="Terrain")
        subs.append(m_subs)
        nodes.append(m_nodes)

    return "".join(subs), "".join(nodes)


def outdoor_navmesh_blocks(plan: dict) -> tuple[str, str]:
    """A navmesh over the WHOLE outdoor ground, not the room-islands.

    Indoor navmesh is per-room + corridors, connected into islands — correct for
    walled rooms, but in an OPEN world the bot must be able to cross anywhere, so a
    room-island navmesh strands it (it times out reaching the goal). We reuse the
    proven navmesh generator on a synthetic single ground rectangle (flat, tier 0),
    giving one continuous walkable surface the bot can route across freely.
    """
    from godot_client.navmesh import navmesh_tscn_blocks  # noqa: PLC0415

    min_x, min_z, max_x, max_z, base_y = _bounds(plan)
    pad = 2.0
    synthetic = {
        "rooms": [{
            "zone_id": "ground", "x": min_x - pad, "z": min_z - pad,
            "width": (max_x - min_x) + 2 * pad, "depth": (max_z - min_z) + 2 * pad,
            "elevation": base_y,
        }],
        "corridors": [],
        "zones": [{"zone_id": "ground", "kind": "entry", "tier": 0}],
    }
    return navmesh_tscn_blocks(synthetic)
