"""Analytical navmesh: floor cells -> NavigationMesh vertices/polygons.

No baking anywhere (the plan bans web-runtime baking, and headless editor
bakes are fragile): the walkable surface is known exactly from the same
0.5-unit floor rasterization the walls use, so the NavigationMesh is
emitted as explicit geometry — deterministic and build-time.

Each grid row becomes horizontal strips of consecutive same-elevation
cells; strip edges are subdivided at every cell boundary and vertices are
shared through a global corner pool, so every adjacent polygon pair shares
an exact 2-vertex edge (NavigationServer connects polygons only on exact
shared edges).

**Ramps are part of the mesh.** They used to be left out, which made every tier a
separate navigation island: a path could never be found between two floors, and
the playtest bot's whole "commit to a ramp and walk straight across it" apparatus
existed to paper over that hole. It leaked badly — a bot standing in a corridor
would land on a nav sliver with nowhere to path — and cost 7 of the 20 MID-DEMO
prompts. The ramps are now rasterized with interpolated heights, so the level is
ONE connected walkable surface and NavigationServer routes across tiers by itself.
"""

from __future__ import annotations

import math

from godot_client.walls import CELL, covered_cells, floor_rects, ramp_geometry

AGENT_CLEARANCE = 0.0  # cells already stop at walls; agent radius handled by NavigationAgent

# A cell may sit this much above/below its neighbour and still be walkable. A
# 20.6-degree ramp climbs 0.19 per 0.5 cell (0.13 diagonally), so 0.35 accepts a
# ramp and still rejects a 1.5 tier cliff.
MAX_WALKABLE_STEP = 0.35


def _eroded(
    cells: dict[tuple[int, int], float], ramps: frozenset[tuple[int, int]] = frozenset()
) -> dict[tuple[int, int], float]:
    """Shrink the walkable set by one cell (0.5u) from walls and cliff edges.

    NavigationMesh ``agent_radius`` only affects BAKED meshes — hand-authored
    polygons are used as-is, so funnel paths would hug wall corners at zero
    clearance and 0.4-radius bodies snag on them (found by the greedy bot).

    A cell needs all 8 neighbours to EXIST (that is the wall clearance), and, for
    ordinary floor, to sit within one walkable step — that height rule is what
    keeps a 1.5-unit cliff from becoming a walkable edge.

    **A ramp is exempt from the height rule**, because a rising slab is genuinely
    higher than the flat floor running alongside it. Judging ramps by that rule
    ate their feet: the `z00->z01` ramp survived only from height 0.84 upward,
    leaving a 0.84 drop to the tier-0 floor — so the ramp existed, and connected
    to nothing. Every tier stayed an island and the bot stranded in a corridor.
    A cliff between two FLAT floors is still cut, which is the point of the rule.
    """
    keep: dict[tuple[int, int], float] = {}
    for (i, j), elevation in cells.items():
        clear = True
        for di in (-1, 0, 1):
            for dj in (-1, 0, 1):
                key = (i + di, j + dj)
                neighbor = cells.get(key)
                if neighbor is None:
                    clear = False  # a wall/void: keep the agent's shoulders clear
                    break
                on_ramp = (i, j) in ramps or key in ramps
                if not on_ramp and abs(neighbor - elevation) > MAX_WALKABLE_STEP:
                    clear = False  # a cliff between flat floors: not walkable
                    break
            if not clear:
                break
        if clear:
            keep[(i, j)] = elevation
    return keep


def _ramp_cells(plan: dict) -> dict[tuple[int, int], float]:
    """Rasterize every tier-crossing ramp into cells with INTERPOLATED heights.

    Without this the navmesh has no polygons on the ramps at all, so each tier is
    a genuinely separate island and NavigationServer can never path between them.
    Every bot heuristic for "walk straight across the slope" existed only to
    paper over that hole — and it failed on 7 of the 20 MID-DEMO prompts, where a
    bot standing in a corridor found itself on a nav sliver with nowhere to go.

    The span mirrors the project writer exactly: RAMP_RUN back from where the
    corridor enters the upper room. (`test_navmesh_ramp_matches_the_writer`
    fails if the two ever drift.)
    """
    cells: dict[tuple[int, int], float] = {}
    for corridor in plan["corridors"]:
        geom = ramp_geometry(plan, corridor)
        if geom is None:
            continue  # flat corridor: the floor rects already cover it
        e_lo, e_hi = geom["e_lo"], geom["e_hi"]
        (foot_x, foot_z), (top_x, top_z) = geom["foot"], geom["top"]
        half = geom["width"] / 2
        along_x = geom["axis"] == "x"
        foot, top = (foot_x, top_x) if along_x else (foot_z, top_z)
        if abs(top - foot) < 1e-6:
            continue

        if along_x:
            lo_x, hi_x = sorted((foot, top))
            lo_z, hi_z = foot_z - half, foot_z + half
        else:
            lo_z, hi_z = sorted((foot, top))
            lo_x, hi_x = foot_x - half, foot_x + half

        for i in range(math.floor(lo_x / CELL), math.ceil(hi_x / CELL)):
            for j in range(math.floor(lo_z / CELL), math.ceil(hi_z / CELL)):
                centre = (i + 0.5) * CELL if along_x else (j + 0.5) * CELL
                t_frac = (centre - foot) / (top - foot)  # 0 at the foot, 1 at the top
                cells[(i, j)] = e_lo + min(max(t_frac, 0.0), 1.0) * (e_hi - e_lo)

        # Everything past the ramp's TOP stands at the upper elevation — the ramp
        # leg's tail plus every later leg. floor_rects() lays the whole corridor at
        # one elevation, so without this the navmesh reads that floor as 1.5 below
        # where the world built it and erosion cuts it as a cliff, re-islanding the
        # tiers. This MUST mirror the writer's `_leg_slab(top, upper_end, e_hi)`.
        pts = corridor["points"]
        order = geom["order"]
        ramp_leg = geom["ramp_leg"]

        def _raise(x_lo: float, x_hi: float, z_lo: float, z_hi: float) -> None:
            for i in range(math.floor(x_lo / CELL), math.ceil(x_hi / CELL)):
                for j in range(math.floor(z_lo / CELL), math.ceil(z_hi / CELL)):
                    cells[(i, j)] = e_hi  # noqa: B023 — read within this iteration

        (ax, az), (bx, bz) = pts[ramp_leg], pts[ramp_leg + 1]
        # The ramp-leg TAIL: from the top down to the leg's far (upper) end.
        if along_x:
            upper_end = max(ax, bx) if top > foot else min(ax, bx)
            _raise(min(top, upper_end), max(top, upper_end), foot_z - half, foot_z + half)
        else:
            upper_end = max(az, bz) if top > foot else min(az, bz)
            _raise(foot_x - half, foot_x + half, min(top, upper_end), max(top, upper_end))
        for leg in order[order.index(ramp_leg) + 1 :]:  # every later leg, at e_hi
            (lax, laz), (lbx, lbz) = pts[leg], pts[leg + 1]
            _raise(min(lax, lbx) - half, max(lax, lbx) + half,
                   min(laz, lbz) - half, max(laz, lbz) + half)
    return cells


def navmesh_arrays(plan: dict) -> tuple[list[float], list[list[int]]]:
    """Return (flat vertex floats [x,y,z,...], polygons as vertex-index lists)."""
    floor = covered_cells(floor_rects(plan))
    ramps = _ramp_cells(plan)  # the ramps ARE walkable surface — include them
    floor.update(ramps)
    cells = _eroded(floor, frozenset(ramps))

    # A vertex is a CORNER, keyed by grid position alone, and its height is the
    # mean of the cells touching it. Keying by (i, j, elevation) meant a ramp cell
    # and the floor cell beside it produced two different vertices at the same
    # corner, so their polygons shared no edge and Godot treated them as separate
    # islands — which is precisely how the tiers came to be disconnected.
    corners: dict[tuple[int, int], list[float]] = {}
    for (i, j), elevation in cells.items():
        for corner in ((i, j), (i + 1, j), (i, j + 1), (i + 1, j + 1)):
            corners.setdefault(corner, []).append(elevation)
    height_at = {c: sum(e) / len(e) for c, e in corners.items()}

    vertices: list[float] = []
    index_of: dict[tuple[int, int], int] = {}

    def vid(i: int, j: int, _elevation: float = 0.0) -> int:
        key = (i, j)
        if key not in index_of:
            index_of[key] = len(vertices) // 3
            vertices.extend([i * CELL, height_at[key], j * CELL])
        return index_of[key]

    polygons: list[list[int]] = []
    rows: dict[int, list[tuple[int, float]]] = {}
    for (i, j), elevation in cells.items():
        rows.setdefault(j, []).append((i, elevation))

    for j in sorted(rows):
        row = sorted(rows[j])
        start_i, prev_i, elev = row[0][0], row[0][0], row[0][1]
        strips = []
        for i, e in row[1:]:
            if i == prev_i + 1 and e == elev:
                prev_i = i
                continue
            strips.append((start_i, prev_i, elev))
            start_i, prev_i, elev = i, i, e
        strips.append((start_i, prev_i, elev))

        for i0, i1, e in strips:
            # Clockwise seen from +Y (Godot's expected navmesh winding):
            # top edge left->right at z=j, bottom edge right->left at z=j+1,
            # subdivided at every cell boundary for exact edge sharing.
            top = [vid(i, j, e) for i in range(i0, i1 + 2)]
            bottom = [vid(i, j + 1, e) for i in range(i1 + 1, i0 - 1, -1)]
            polygons.append(top + bottom)

    return vertices, polygons


def navmesh_tscn_blocks(plan: dict) -> tuple[str, str]:
    """(sub_resource, node) tscn text for the baked-in navigation region."""
    vertices, polygons = navmesh_arrays(plan)
    verts_text = ", ".join(f"{v:g}" for v in vertices)
    polys_text = ", ".join(
        "PackedInt32Array(" + ", ".join(str(i) for i in poly) + ")" for poly in polygons
    )
    sub = (
        '[sub_resource type="NavigationMesh" id="NavMesh"]\n'
        f"vertices = PackedVector3Array({verts_text})\n"
        f"polygons = [{polys_text}]\n"
        "agent_radius = 0.4\n\n"
    )
    node = (
        '[node name="NavigationRegion" type="NavigationRegion3D" parent="."]\n'
        'navigation_mesh = SubResource("NavMesh")\n\n'
    )
    return sub, node
