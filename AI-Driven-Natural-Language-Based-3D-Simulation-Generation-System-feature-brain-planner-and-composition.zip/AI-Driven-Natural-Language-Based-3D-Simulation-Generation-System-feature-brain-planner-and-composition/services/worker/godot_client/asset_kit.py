"""Curated asset kit (asset resolution tier 2: cache -> CURATED -> generate).

Maps spec entities onto the vetted CC0 kit under content/kits/kaykit
(KayKit Dungeon Remastered + Skeletons packs by Kay Lousberg, CC0 — see
the licensing ledger). Deterministic: template ids map to fixed models,
enemy visuals cycle through the skeleton variants by placement index.
The P3 asset farm slots in ABOVE this as the "generate" tier; this stays
the guaranteed fallback.
"""

from __future__ import annotations

from pathlib import Path

# interactable_template_id -> kit-relative model path
PROP_MODELS: dict[str, str] = {
    "chest_lidded": "kaykit/props/chest.glb",
    "pickup_supply": "kaykit/props/chest_gold.glb",
    "lever_switch": "kaykit/props/torch_mounted.gltf.glb",
    "spawn_site": "kaykit/props/torch_lit.gltf.glb",
    "ladder_climbable": "kaykit/props/stairs_narrow.gltf.glb",
    "gate_sliding": "kaykit/props/wall_gated.gltf.glb",
    "objective_trigger": "kaykit/props/banner_red.gltf.glb",
}
GENERIC_PROP_MODEL = "kaykit/props/barrel_large.gltf.glb"
# door_hinged / door_hinged_lockable keep the functional swinging slab
# (the LockedDoor node) — a static model can't animate the hinge yet.
FUNCTIONAL_PROPS = {"door_hinged", "door_hinged_lockable"}

ENEMY_MODELS: list[str] = [
    "kaykit/characters/Skeleton_Minion.glb",
    "kaykit/characters/Skeleton_Warrior.glb",
    "kaykit/characters/Skeleton_Rogue.glb",
    "kaykit/characters/Skeleton_Mage.glb",
]

# What each curated model actually IS, in the words a brief would use. This is
# what the curated tier matches an asset_brief against (S5: "curated >= 0.85"),
# so a planner that writes "a hulking armoured brute" gets the Warrior rather
# than whatever the placement index happened to land on.
#
# Describe the MODEL, honestly and plainly — not the mood you wish it had. An
# inflated description wins matches it should lose, and the player sees the
# mismatch. Adding a model here is what makes it reachable by description.
_ORIGINAL_MODEL_DESCRIPTIONS: dict[str, str] = {
    # characters
    "kaykit/characters/Skeleton_Minion.glb": (
        "a small plain skeleton, bare bones, unarmoured, a weak basic undead minion"
    ),
    "kaykit/characters/Skeleton_Warrior.glb": (
        "a heavy armoured skeleton warrior in a helmet with a sword and shield, "
        "a big tough armoured brute"
    ),
    "kaykit/characters/Skeleton_Rogue.glb": (
        "a lean hooded skeleton rogue with daggers, a fast agile sneaking scout or thief"
    ),
    "kaykit/characters/Skeleton_Mage.glb": (
        "a robed skeleton mage holding a staff, a spellcaster wizard sorcerer necromancer"
    ),
    # Animals (Quaternius, CC0). Rigged and animated — 24-26 clips each — so the
    # curated tier can answer "as a dog" with something that actually MOVES,
    # where a generated dog would be a statue (ADR-0007 rung 1).
    # Ordinary people (Quaternius, CC0). The library had FOUR rigged humanoids
    # and every one of them was a skeleton, so "an animated, rigged visitor
    # suitable as the controlled simulation agent" scored 0.47-0.57 against all
    # of them -- correctly below the 0.85 floor -- and then took the humanoid
    # DEFAULT, which was Skeleton_Warrior. A prompt about a suburban village put
    # an armoured undead on the pavement, and the vision critic was the only
    # thing that noticed.
    "quaternius/characters/Man.glb": (
        "an ordinary man, a person, a pedestrian villager visitor passer-by "
        "walking about in everyday clothes"
    ),
    "quaternius/characters/Woman.glb": (
        "an ordinary woman, a person, a pedestrian villager visitor passer-by "
        "walking about in everyday clothes"
    ),
    "quaternius/characters/Farmer.glb": (
        "a farmer in work clothes and a hat, a rural villager labourer "
        "smallholder tending the land"
    ),
    "quaternius/animals/ShibaInu.glb": (
        "a small scruffy shiba inu dog, a puppy hound pet with a curled tail and pointed ears"
    ),
    "quaternius/animals/Husky.glb": (
        "a husky sled dog, a large wolfish grey and white hound with a thick coat"
    ),
    "quaternius/animals/Wolf.glb": (
        "a grey wolf, a wild snarling predator of the forest, a dire beast"
    ),
    "quaternius/animals/Fox.glb": "a small red fox, a quick sly bushy-tailed vermin critter",
    "quaternius/animals/Deer.glb": "a gentle deer doe, a skittish forest grazer",
    "quaternius/animals/Stag.glb": "a proud antlered stag, a great horned deer buck",
    "quaternius/animals/Cow.glb": "a spotted dairy cow, a placid farm cattle beast",
    "quaternius/animals/Bull.glb": "an angry charging bull, a heavy horned cattle brute",
    "quaternius/animals/Horse.glb": "a brown horse, a galloping steed mount",
    "quaternius/animals/WhiteHorse.glb": "a white horse, a pale galloping steed mount charger",
    "quaternius/animals/Donkey.glb": "a stubborn donkey mule, a small grey pack ass",
    "quaternius/animals/Alpaca.glb": "a fluffy alpaca llama, a woolly long-necked pack animal",
    # props
    "kaykit/props/chest.glb": (
        "a wooden treasure chest with iron bands, a closed container or coffer"
    ),
    "kaykit/props/chest_gold.glb": "a golden treasure chest full of gold, loot, reward, riches",
    "kaykit/props/barrel_large.gltf.glb": "a large wooden barrel, a cask or keg",
    "kaykit/props/crates_stacked.gltf.glb": "a stack of wooden crates and boxes, storage supplies",
    "kaykit/props/torch_lit.gltf.glb": "a burning torch with flame, fire, light source",
    "kaykit/props/torch_mounted.gltf.glb": (
        "an iron torch bracket mounted on a wall, a sconce, a wall fixture or lever"
    ),
    "kaykit/props/stairs_narrow.gltf.glb": "a narrow stone staircase, steps, a ladder to climb",
    "kaykit/props/wall_gated.gltf.glb": (
        "a barred iron gate set in a stone wall, a portcullis barrier"
    ),
    "kaykit/props/banner_red.gltf.glb": "a hanging red cloth banner or flag on a wall, a marker",
    "kaykit/props/column.gltf.glb": "a tall stone column or pillar, masonry architecture",
}


# --- Sound (curated tier, same contract as models) -------------------------
# A sound set is chosen by the MODEL an enemy wears, so what you hear matches
# what you see: a skeleton dies as bones clattering, never a fleshy thud. The
# clip within the set is chosen by the ACTIVITY the AI is actually performing.
# Adding a family (e.g. an armoured knight -> hit_metal) is a data change here,
# not a code change. Clips are CC0 (Cat Prisbrey souls-like template + Kenney).
SOUND_SETS: dict[str, dict[str, list[str]]] = {
    "skeleton": {
        "attack": ["swish_1.wav", "swish_2.wav", "swish_3.wav"],
        "hit": ["hit_blunt_01.wav", "hit_blunt_02.wav", "hit_blunt_03.wav"],
        "death": ["clack_1.wav", "clack_2.wav", "clack_3.wav"],  # bones collapsing
        "step": ["step_1.wav", "step_2.wav", "step_3.wav", "step_4.wav"],
    },
    # Anything under animals/ (the CC0 Quaternius kit). It exists chiefly so a dog
    # does NOT die to `clack` — bones clattering out of a shiba inu is the exact
    # see/hear mismatch this whole mechanism exists to prevent. A soft body dies
    # wet, not dry.
    #
    # Honest limit: this library holds no bark. These are the best CC0 clips we
    # own for a creature, not the right ones — a real bark comes from generated
    # sound (ADR-0006, AUDIO_GEN_ENABLED), which is per-species by construction.
    "animal": {
        "attack": ["swish_1.wav", "swish_2.wav", "swish_3.wav"],  # a lunge
        "hit": ["hit_blunt_01.wav", "hit_blunt_02.wav", "hit_blunt_03.wav"],
        "death": ["hit_wet_01.wav", "hit_wet_02.wav", "hit_wet_03.wav"],
        "step": ["step_1.wav", "step_2.wav", "step_3.wav", "step_4.wav"],
    },
}
DEFAULT_SOUND_FAMILY = "skeleton"


def sound_family(model_path: str | None) -> str:
    """Which sound family a model belongs to. Unknown/generated meshes fall back
    to the default set rather than being silent.

    Matching is on the path, and the kit folders are named for their family
    (`characters/Skeleton_*`, `animals/*`), so a new kit joins by being filed
    under a folder whose name is its family — no wiring, no registry.
    """
    name = (model_path or "").lower()
    for family in SOUND_SETS:
        if family in name:
            return family
    return DEFAULT_SOUND_FAMILY


def enemy_sounds(model_path: str | None) -> dict[str, list[str]]:
    """activity -> candidate clips for the model this enemy actually wears."""
    return SOUND_SETS[sound_family(model_path)]


def sound_files_exist(sfx_dir: Path) -> bool:
    """True only if every clip every set names is really on disk — a half-copied
    kit must degrade to silence, not to a broken build."""
    return all(
        (sfx_dir / clip).is_file()
        for activities in SOUND_SETS.values()
        for clips in activities.values()
        for clip in clips
    )


# Folders that hold bodies rather than scenery. This is what scopes the curated
# tier's search (a brief for an enemy must never dress it as a barrel, at ANY
# score), and it is a folder convention rather than a path prefix precisely
# because a pack's own name comes first: `kaykit/characters/` and
# `quaternius/animals/` are both characters.
CHARACTER_DIRS = frozenset({"characters", "animals"})


# Architecture the ORIGINAL kit happened to contain. Superseded: the vendored packs
# declare their own category in `kit.json`, and `kenney-castle` / `kenney-city` supply
# 120 real building modules, so a house no longer needs three props reclassified to have
# anything to match.
#
# Kept EMPTY rather than deleted because these three are also `PROP_MODELS` defaults for
# the game_spec path -- reclassifying them made a prop resolve to a `building_module` and
# broke the invariant that a prop resolves to a prop.
STRUCTURE_MODELS: frozenset[str] = frozenset()


def model_category(rel: str) -> str:
    """'character', 'building_module', or 'prop' — which part of the library this is.

    Three values, not two. The planner's vocabulary already distinguishes a structure
    from a prop; collapsing them here is what let a house match a banner.
    """
    declared = MANIFEST_CATEGORIES.get(rel)
    if declared:
        # A pack says what it holds. Folder names are a heuristic and a vendored pack
        # need not use ours -- `kenney-blaster/models/` is weapons, not scenery.
        return declared
    if CHARACTER_DIRS & set(rel.split("/")):
        return "character"
    if rel in STRUCTURE_MODELS:
        return "building_module"
    return "prop"


def prop_model(interactable_template_id: str | None) -> str | None:
    """Kit path for a prop, GENERIC for unknowns, None for functional props."""
    if interactable_template_id in FUNCTIONAL_PROPS:
        return None
    if interactable_template_id in PROP_MODELS:
        return PROP_MODELS[interactable_template_id]
    return GENERIC_PROP_MODEL


def enemy_model(index: int) -> str:
    """Deterministic variety: cycle the skeleton variants by placement index."""
    return ENEMY_MODELS[index % len(ENEMY_MODELS)]


# A stated character we cannot match must NEVER become a bare capsule — it ships a
# real asset-farm body instead. Animal briefs get a neutral quadruped; everything
# else gets a humanoid. (A skeleton is the only humanoid we own today; add a CC0
# human/robot pack, or wire generate+rig, to widen this — see ADR-0007.)
DEFAULT_ANIMAL_MODEL = "quaternius/animals/Deer.glb"
# A person, not a monster. This is what any character brief the library cannot
# match falls back to, so it has to be the most ORDINARY body owned, not the
# most striking one. It was Skeleton_Warrior purely because that was the only
# rigged humanoid vendored.
DEFAULT_HUMANOID_MODEL = "quaternius/characters/Man.glb"
# The ordinary human bodies owned, in preference order, for telling one unmatched
# person in a world apart from the next. Every brief for a person scores far below
# the curated floor (0.548 at best), and the keyword tier only fires on a brief
# that literally says "farmer" or "woman", so nearly every person reaches the
# default -- and one default body makes a station guard and a tea vendor identical
# twins standing a few metres apart.
#
# Deliberately NOT every `characters/` entry: the four skeletons are humanoid too,
# and putting one on a suburban pavement is a defect this file already records.
ORDINARY_HUMAN_MODELS = (
    "quaternius/characters/Man.glb",
    "quaternius/characters/Woman.glb",
    "quaternius/characters/Farmer.glb",
)

_ANIMAL_HINTS = frozenset({
    "animal", "beast", "creature", "critter", "pet", "dog", "puppy", "hound", "cat", "kitten",
    "goat", "sheep", "lamb", "ram", "pig", "boar", "hog", "cow", "bull", "ox", "calf", "cattle",
    "horse", "pony", "foal", "steed", "deer", "stag", "doe", "elk", "moose", "fox", "wolf",
    "bear", "rabbit", "hare", "bunny", "mouse", "rat", "squirrel", "frog", "toad", "lizard",
    "snake", "turtle", "bird", "chicken", "hen", "duck", "goose", "owl", "eagle", "donkey",
    "mule", "llama", "alpaca", "camel", "goatling", "tiger", "lion", "leopard", "panther",
    "cheetah", "monkey", "ape", "gorilla", "elephant", "rhino", "hippo", "giraffe", "zebra",
    "dragon", "wyvern", "paws", "paw", "fur", "furry", "tail", "hooves", "hoof", "horns",
    "horn", "snout", "muzzle", "whiskers", "quadruped", "mount", "fluffy", "scaly", "feathers",
})


def default_character_model(brief_text: str) -> str:
    """A real farm body for a character we could not match to an owned model.

    Animal-ish brief -> a neutral quadruped; anything else -> a humanoid. Chosen so
    the player is a plausible character, never a capsule. Purely lexical + stable.
    """
    words = set((brief_text or "").lower().replace("-", " ").replace(",", " ").split())
    if words & _ANIMAL_HINTS:
        return DEFAULT_ANIMAL_MODEL
    return DEFAULT_HUMANOID_MODEL


def kit_files_exist(kit_dir: Path) -> bool:
    return (kit_dir / GENERIC_PROP_MODEL).is_file() and (kit_dir / ENEMY_MODELS[0]).is_file()


# --- pack manifests -------------------------------------------------------
# Everything above this line is the ORIGINAL hand-written kit. Everything below lets a
# pack describe itself so the library can grow without this file growing with it.

KITS_DIR = Path(__file__).resolve().parents[3] / "content" / "kits"

# Filled by `_load_pack_manifests()` at import: rel -> declared category. Consulted by
# `model_category` before the folder heuristic, so a pack can say what it holds instead
# of being guessed at by directory name.
MANIFEST_CATEGORIES: dict[str, str] = {}

# rel -> {"pack", "licence", "source"}. Kept because rule 12 requires knowing where every
# shipped asset came from, and a ledger nobody can reconstruct is not a ledger.
MODEL_PROVENANCE: dict[str, dict] = {}


def _load_pack_manifests(kits_dir: Path | None = None) -> dict[str, str]:
    """Read every `content/kits/*/kit.json`, returning {rel: description}.

    Deliberately forgiving: a malformed or half-written manifest must not stop the
    worker booting, because the alternative is that dropping in a bad pack takes the
    whole asset farm down. A pack that cannot be read is skipped and reported.

    Only entries whose file actually exists are returned -- a manifest listing a model
    nobody vendored would otherwise be offered to the matcher and chosen, and the
    resolver would then fail on a missing path.
    """
    import json
    import logging

    log = logging.getLogger(__name__)
    root = kits_dir or KITS_DIR
    found: dict[str, str] = {}
    if not root.is_dir():
        return found
    for manifest_path in sorted(root.glob("*/kit.json")):
        pack_dir = manifest_path.parent
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001 - a bad pack must not stop the worker
            log.warning("kit manifest unreadable, pack skipped: %s (%s)", manifest_path, exc)
            continue
        provenance = {
            "pack": str(manifest.get("pack") or pack_dir.name),
            "licence": str(manifest.get("licence") or "UNDECLARED"),
            "source": str(manifest.get("source") or ""),
        }
        for relative, entry in (manifest.get("models") or {}).items():
            if not (pack_dir / relative).is_file():
                log.warning(
                    "kit manifest lists a model that is not vendored: %s/%s",
                    pack_dir.name,
                    relative,
                )
                continue
            rel = f"{pack_dir.name}/{relative}".replace("\\", "/")
            if isinstance(entry, str):
                description, category = entry, None
            else:
                description = str((entry or {}).get("description") or "").strip()
                category = (entry or {}).get("category")
            if not description:
                continue
            found[rel] = description
            if category:
                MANIFEST_CATEGORIES[rel] = str(category)
            MODEL_PROVENANCE[rel] = provenance
    return found


def _merged_descriptions() -> dict[str, str]:
    """The hand-written kit plus every pack manifest, manifest winning on a clash."""
    merged = dict(_ORIGINAL_MODEL_DESCRIPTIONS)
    merged.update(_load_pack_manifests())
    return merged


MODEL_DESCRIPTIONS: dict[str, str] = _merged_descriptions()
