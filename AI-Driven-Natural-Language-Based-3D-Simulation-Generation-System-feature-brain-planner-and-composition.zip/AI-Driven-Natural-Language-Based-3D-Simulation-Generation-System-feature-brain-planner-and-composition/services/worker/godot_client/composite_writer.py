"""Materialise a CompositeObject into Godot scene text (ADR-0008, phase 2).

Turns the deterministic composition (godot_client.composition) into real nodes:
a parent holder placed in the world, and under it each affordance PART as a
separate node bound to its vetted behaviour template — a `DoorHinged` with an
`InteractZone` for a hinged part (house door, vehicle door, gate), a pickup node
for a point part. The part sits at its socket as a CHILD of the parent, so the
whole object can be moved/rotated as a unit and each affordance keeps its exact
hinge (why a separated part opens correctly where a mesh-baked one cannot).

Emits the SAME node shape the project writer already uses for the exit
`LockedDoor` (StaticBody3D + script + slab mesh offset from the hinge + collision
+ InteractZone Area3D), so a composed door behaves identically to the hand-placed
one. Pure text, no Godot, unit-testable. The behaviour lives in the template
(rule 10); this only places and wires.
"""

from __future__ import annotations

import math

from godot_client.composition import AFFORDANCE_TEMPLATES, CompositeObject, resolve_parts

# A generic door slab when the part has no dedicated mesh yet (phase 4 gives it a
# generated/curated panel). Metres. The hinge is the node origin; the slab is
# offset by half its width so it swings around that edge.
DOOR_WIDTH = 1.0
DOOR_HEIGHT = 2.0
DOOR_THICKNESS = 0.12
INTERACT_PAD = 2.0  # how far past the slab the interact zone reaches


def _pascal(identifier: str) -> str:
    return "".join(part.capitalize() for part in identifier.replace("-", "_").split("_") if part)


def _tscn_transform(x: float, y: float, z: float, yaw_deg: float = 0.0) -> str:
    """Godot Transform3D with a yaw (rotation about Y) and origin."""
    t = math.radians(yaw_deg)
    c, s = math.cos(t), math.sin(t)
    # Basis rows for a Y rotation, then origin.
    return (
        f"Transform3D({c:g}, 0, {s:g}, 0, 1, 0, {-s:g}, 0, {c:g}, {x:g}, {y:g}, {z:g})"
    )


def composite_blocks(
    obj: CompositeObject,
    origin: tuple[float, float, float] = (0.0, 0.0, 0.0),
    parent_yaw_deg: float = 0.0,
    *,
    door_ext_id: str = "3_door",
    pickup_ext_id: str = "9_pickup",
    door_material_id: str | None = None,
    parent_mesh_ext_id: str | None = None,
    body_scale: float = 1.0,
    part_mesh_exts: dict[str, tuple[str, float]] | None = None,
) -> tuple[str, str, str]:
    """`(sub_resources, nodes, connections)` scene text for one composite object.

    The parent is a Node3D holder at `origin`/`parent_yaw_deg`; its affordance
    parts hang under it at parent-LOCAL socket transforms (so Godot composes them
    with the parent). `parent_mesh_ext_id`, if given, instances the object's body
    mesh under the holder, uniformly scaled by `body_scale` (a generated body is
    normalised small; this grows it to fill the object's footprint so it sits
    behind the doors, not inside them). Objective-locked doors emit a connection
    stub the caller can point at whatever unlocks them.
    """
    holder = f"Object{_pascal(obj.object_id)}"
    subs: list[str] = []
    nodes: list[str] = [
        f'[node name="{holder}" type="Node3D" parent="."]\n'
        f"transform = {_tscn_transform(origin[0], origin[1], origin[2], parent_yaw_deg)}\n\n"
    ]
    if parent_mesh_ext_id is not None:
        s = body_scale
        body_xform = f"Transform3D({s:g}, 0, 0, 0, {s:g}, 0, 0, 0, {s:g}, 0, 0, 0)"
        nodes.append(
            f'[node name="{holder}Body" parent="{holder}" '
            f'instance=ExtResource("{parent_mesh_ext_id}")]\n'
            f"transform = {body_xform}\n\n"
        )
    connections: list[str] = []
    part_meshes = part_mesh_exts or {}

    # Parent-local transforms: resolve against a zero origin so the holder carries
    # the world placement and each part is positioned relative to it.
    for part, placed in zip(obj.parts, resolve_parts(obj, (0.0, 0.0, 0.0), 0.0), strict=True):
        node = f"{holder}_{_pascal(part.part_id)}"
        kind = AFFORDANCE_TEMPLATES[part.template_id]
        if kind == "hinged":
            subs.append(_door_subs(node))
            nodes.append(
                _door_node(
                    node, holder, placed, part, door_ext_id, door_material_id,
                    part_meshes.get(part.part_id),
                )
            )
            unlock = part.params.get("unlocked_by_objective")
            if unlock:
                connections.append(
                    f'[connection signal="objective_completed" from="{unlock}" '
                    f'to="{holder}/{node}" method="_on_objective_completed"]\n'
                )
        else:  # point affordance (pickup)
            nodes.append(_pickup_node(node, holder, placed, pickup_ext_id))

    return "".join(subs), "".join(nodes), "".join(connections)


def _door_subs(node: str) -> str:
    slab = f"Vector3({DOOR_WIDTH:g}, {DOOR_HEIGHT:g}, {DOOR_THICKNESS:g})"
    zone = (
        f"Vector3({DOOR_WIDTH + INTERACT_PAD:g}, {DOOR_HEIGHT:g}, "
        f"{DOOR_THICKNESS + INTERACT_PAD:g})"
    )
    return (
        f'[sub_resource type="BoxMesh" id="Mesh{node}"]\nsize = {slab}\n\n'
        f'[sub_resource type="BoxShape3D" id="Shape{node}"]\nsize = {slab}\n\n'
        f'[sub_resource type="BoxShape3D" id="Zone{node}"]\nsize = {zone}\n\n'
    )


def _door_node(node, holder, placed, part, door_ext_id, door_material_id, part_mesh=None) -> str:
    # The hinge is the node origin; the slab, collision and zone are offset by half
    # the door width so the door swings around that edge (as door_hinged.gd expects).
    off = (DOOR_WIDTH / 2, DOOR_HEIGHT / 2, 0.0)
    open_angle = part.params.get("open_angle_deg", -90.0)
    locked = "true" if part.params.get("locked") else "false"
    unlocked_by = part.params.get("unlocked_by_objective", "")

    # The VISUAL is either the part's own mesh (a curated/generated door panel) or
    # the default box slab. Either way the COLLISION + InteractZone stay the box —
    # physics/reachability must not depend on a generated mesh's messy hull, and
    # the affordance oracle proved the box swing works (Phase 4c: visual only).
    if part_mesh is not None:
        ext_id, scale = part_mesh
        visual = (
            f'[node name="{node}Panel" parent="{holder}/{node}" '
            f'instance=ExtResource("{ext_id}")]\n'
            f"transform = Transform3D({scale:g}, 0, 0, 0, {scale:g}, 0, 0, 0, {scale:g}, "
            f"{off[0]:g}, {off[1]:g}, {off[2]:g})\n\n"
        )
    else:
        mat = (
            f'material_override = SubResource("{door_material_id}")\n'
            if door_material_id
            else ""
        )
        visual = (
            f'[node name="{node}Mesh" type="MeshInstance3D" parent="{holder}/{node}"]\n'
            f"transform = {_tscn_transform(*off)}\n"
            f'mesh = SubResource("Mesh{node}")\n'
            f"{mat}\n"
        )
    return (
        f'[node name="{node}" type="StaticBody3D" parent="{holder}"]\n'
        f"transform = {_tscn_transform(placed.x, placed.y, placed.z, placed.yaw_deg)}\n"
        f'script = ExtResource("{door_ext_id}")\n'
        f"locked = {locked}\n"
        f"open_angle_deg = {open_angle:g}\n"
        f'unlocked_by_objective = "{unlocked_by}"\n\n'
        + visual
        + f'[node name="{node}Shape" type="CollisionShape3D" parent="{holder}/{node}"]\n'
        f"transform = {_tscn_transform(*off)}\n"
        f'shape = SubResource("Shape{node}")\n\n'
        f'[node name="InteractZone" type="Area3D" parent="{holder}/{node}"]\n'
        "collision_layer = 0\ncollision_mask = 2\n\n"
        f'[node name="InteractZoneShape" type="CollisionShape3D" '
        f'parent="{holder}/{node}/InteractZone"]\n'
        f"transform = {_tscn_transform(*off)}\n"
        f'shape = SubResource("Zone{node}")\n\n'
    )


def _pickup_node(node, holder, placed, pickup_ext_id) -> str:
    return (
        f'[node name="{node}" type="Area3D" parent="{holder}" groups=["pickup"]]\n'
        f"transform = {_tscn_transform(placed.x, placed.y, placed.z, placed.yaw_deg)}\n"
        f'script = ExtResource("{pickup_ext_id}")\n\n'
    )
