"""Runtime-state probes for canonical Serendib desktop and browser artifacts."""

from __future__ import annotations

import base64
import functools
import json
import os
import socket
import struct
import subprocess
import tempfile
import threading
import time
import urllib.request
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

PROBE_PREFIX = "SERENDIB_PROBE_JSON:"
CAPTURE_PREFIX = "SERENDIB_CAPTURE_JSON:"
PROBE_TIMEOUT_SECONDS = 180

# Validation captures render at twice the delivered window size. The capture
# saves the viewport texture verbatim, so this is the image resolution; the
# delivered project keeps its 960x540 web window.
CAPTURE_WIDTH = 1920
CAPTURE_HEIGHT = 1080


class _QuietStaticHandler(SimpleHTTPRequestHandler):
    def log_message(self, _format: str, *_args) -> None:
        return


def _result(status: str, *, errors: list[dict] | None = None, **evidence) -> dict:
    return {"status": status, "errors": errors or [], "evidence": evidence}


def _parse(lines: list[str], *, source: str, returncode: int | None = None) -> dict:
    for line in lines:
        marker = line.find(PROBE_PREFIX)
        if marker < 0:
            continue
        try:
            payload = json.loads(line[marker + len(PROBE_PREFIX) :])
        except json.JSONDecodeError as exc:
            return _result(
                "FAIL",
                errors=[{"code": "RUNTIME_PROBE_JSON_INVALID", "message": str(exc)}],
                source=source,
                returncode=returncode,
            )
        if payload.get("status") not in {"PASS", "FAIL"}:
            return _result(
                "FAIL",
                errors=[{"code": "RUNTIME_PROBE_STATUS_INVALID"}],
                source=source,
                returncode=returncode,
            )
        return _result(
            payload["status"],
            errors=list(payload.get("errors") or []),
            source=source,
            returncode=returncode,
            state_trace=payload,
        )
    return _result(
        "UNAVAILABLE",
        errors=[{"code": "RUNTIME_PROBE_OUTPUT_MISSING"}],
        source=source,
        returncode=returncode,
    )


def run_project_probe(godot_bin: Path, project_dir: Path) -> dict:
    if not godot_bin.is_file() or not (project_dir / "project.godot").is_file():
        return _result(
            "UNAVAILABLE",
            errors=[{"code": "SERENDIB_PROJECT_PROBE_TOOL_UNAVAILABLE"}],
            source="project",
        )
    try:
        import_log = project_dir / ".serendib_import.log"
        imported = subprocess.run(
            [
                str(godot_bin),
                "--headless",
                "--log-file",
                str(import_log),
                "--path",
                str(project_dir),
                "--import",
            ],
            capture_output=True,
            text=True,
            timeout=PROBE_TIMEOUT_SECONDS,
            check=False,
        )
        if imported.returncode != 0:
            return _result(
                "FAIL",
                errors=[
                    {
                        "code": "SERENDIB_PROJECT_IMPORT_FAILED",
                        "message": (imported.stderr or imported.stdout or "")[-1000:],
                    }
                ],
                source="project",
                returncode=imported.returncode,
            )
        probe_log = project_dir / ".serendib_probe.log"
        process = subprocess.run(
            [
                str(godot_bin),
                "--headless",
                "--log-file",
                str(probe_log),
                "--path",
                str(project_dir),
                "--",
                "--serendib-probe",
            ],
            capture_output=True,
            text=True,
            timeout=PROBE_TIMEOUT_SECONDS,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return _result(
            "UNAVAILABLE",
            errors=[{"code": "SERENDIB_PROJECT_PROBE_FAILED", "message": str(exc)}],
            source="project",
        )
    log_lines = (
        probe_log.read_text(encoding="utf-8", errors="replace").splitlines()
        if probe_log.is_file()
        else []
    )
    return _parse(
        [
            *(process.stdout or "").splitlines(),
            *(process.stderr or "").splitlines(),
            *log_lines,
        ],
        source="project",
        returncode=process.returncode,
    )


def capture_canonical_views(godot_bin: Path, project_dir: Path) -> dict:
    if not godot_bin.is_file() or not (project_dir / "project.godot").is_file():
        return _result(
            "UNAVAILABLE",
            errors=[{"code": "SERENDIB_CAPTURE_TOOL_UNAVAILABLE"}],
            source="canonical_views",
        )
    try:
        import_log = project_dir / ".serendib_capture_import.log"
        imported = subprocess.run(
            [
                str(godot_bin),
                "--headless",
                "--log-file",
                str(import_log),
                "--path",
                str(project_dir),
                "--import",
            ],
            capture_output=True,
            text=True,
            timeout=PROBE_TIMEOUT_SECONDS,
            check=False,
        )
        if imported.returncode != 0:
            return _result(
                "FAIL",
                errors=[{"code": "SERENDIB_CAPTURE_IMPORT_FAILED"}],
                source="canonical_views",
                returncode=imported.returncode,
            )
        capture_log = project_dir / ".serendib_capture.log"
        rendering_args = [
            "--rendering-method",
            "gl_compatibility",
            "--rendering-driver",
            "opengl3",
            # Capture at 2x the shipped window size. The GDScript side saves
            # get_viewport().get_texture(), so the window size IS the image
            # size, and the project ships at 960x540 for the web build. That
            # is too coarse for the vision model to judge a small affordance
            # like a door, and too coarse to reproduce in print. Overriding
            # here rather than in project.godot keeps the delivered window
            # unchanged -- this affects validation captures only.
            "--resolution",
            f"{CAPTURE_WIDTH}x{CAPTURE_HEIGHT}",
        ]
        startupinfo = None
        creationflags = 0
        if os.name == "nt":
            # Godot's Windows headless display driver forces the dummy renderer,
            # which has no viewport texture. A hidden native context renders real
            # pixels without presenting a user-facing validation window.
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
            creationflags = subprocess.CREATE_NO_WINDOW
        else:
            rendering_args = ["--display-driver", "headless", *rendering_args]
        process = subprocess.run(
            [
                str(godot_bin),
                *rendering_args,
                "--log-file",
                str(capture_log),
                "--path",
                str(project_dir),
                "--",
                "--serendib-capture",
            ],
            capture_output=True,
            text=True,
            timeout=PROBE_TIMEOUT_SECONDS,
            check=False,
            startupinfo=startupinfo,
            creationflags=creationflags,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return _result(
            "UNAVAILABLE",
            errors=[{"code": "SERENDIB_CAPTURE_FAILED", "message": str(exc)}],
            source="canonical_views",
        )
    log_lines = (
        capture_log.read_text(encoding="utf-8", errors="replace").splitlines()
        if capture_log.is_file()
        else []
    )
    lines = [
        *(process.stdout or "").splitlines(),
        *(process.stderr or "").splitlines(),
        *log_lines,
    ]
    for line in lines:
        marker = line.find(CAPTURE_PREFIX)
        if marker < 0:
            continue
        try:
            payload = json.loads(line[marker + len(CAPTURE_PREFIX) :])
        except json.JSONDecodeError as exc:
            return _result(
                "FAIL",
                errors=[{"code": "CAPTURE_RESULT_INVALID", "message": str(exc)}],
                source="canonical_views",
            )
        paths = [project_dir / value for value in payload.get("files", [])]
        view_manifest = list(payload.get("views") or [])
        if payload.get("status") != "PASS" or not paths or any(
            not path.is_file() or path.stat().st_size < 256 for path in paths
        ):
            return _result(
                "FAIL",
                errors=[{"code": "CANONICAL_RENDER_VIEWS_INVALID"}],
                source="canonical_views",
            )
        return _result(
            "PASS",
            source="canonical_views",
            image_paths=[str(path) for path in paths],
            view_manifest=view_manifest,
            returncode=process.returncode,
        )
    return _result(
        "UNAVAILABLE",
        errors=[{"code": "CAPTURE_RESULT_MISSING"}],
        source="canonical_views",
        returncode=process.returncode,
    )


def run_desktop_probe(executable: Path) -> dict:
    if not executable.is_file():
        return _result(
            "UNAVAILABLE",
            errors=[{"code": "SERENDIB_DESKTOP_ARTIFACT_MISSING"}],
            source="desktop",
        )
    try:
        probe_log = executable.parent / ".serendib_desktop_probe.log"
        process = subprocess.run(
            [
                str(executable),
                "--headless",
                "--log-file",
                str(probe_log),
                "--",
                "--serendib-probe",
            ],
            capture_output=True,
            text=True,
            timeout=PROBE_TIMEOUT_SECONDS,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return _result(
            "UNAVAILABLE",
            errors=[{"code": "SERENDIB_DESKTOP_PROBE_FAILED", "message": str(exc)}],
            source="desktop",
        )
    log_lines = (
        probe_log.read_text(encoding="utf-8", errors="replace").splitlines()
        if probe_log.is_file()
        else []
    )
    return _parse(
        [
            *(process.stdout or "").splitlines(),
            *(process.stderr or "").splitlines(),
            *log_lines,
        ],
        source="desktop",
        returncode=process.returncode,
    )


def run_web_probe(build_dir: Path, browser_executable: Path | None = None) -> dict:
    """Launch the actual Web export and capture its deterministic state trace.

    Playwright is an optional validation-worker dependency. Its absence is
    reported as UNAVAILABLE and therefore blocks a mandatory parity gate.
    """
    if not (build_dir / "index.html").is_file():
        return _result(
            "UNAVAILABLE",
            errors=[{"code": "SERENDIB_WEB_ARTIFACT_MISSING"}],
            source="web",
        )
    if browser_executable is not None and not browser_executable.is_file():
        return _result(
            "UNAVAILABLE",
            errors=[{"code": "CONFIGURED_BROWSER_NOT_FOUND"}],
            source="web",
        )
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        sync_playwright = None

    handler = functools.partial(_QuietStaticHandler, directory=str(build_dir))
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    console_lines: list[str] = []
    try:
        url = f"http://127.0.0.1:{server.server_port}/index.html?serendib_probe=1"
        if sync_playwright is None:
            if browser_executable is None:
                return _result(
                    "UNAVAILABLE",
                    errors=[
                        {
                            "code": "WEB_VALIDATOR_NOT_INSTALLED",
                            "message": "install Playwright or configure a Chromium executable",
                        }
                    ],
                    source="web",
                )
            console_lines = _chromium_dom_probe(browser_executable, url)
        else:
            with sync_playwright() as playwright:
                launch = {"headless": True}
                if browser_executable is not None:
                    launch["executable_path"] = str(browser_executable)
                browser = playwright.chromium.launch(**launch)
                page = browser.new_page()
                page.on("console", lambda message: console_lines.append(message.text))
                page.goto(
                    url,
                    wait_until="load",
                    timeout=PROBE_TIMEOUT_SECONDS * 1000,
                )
                page.wait_for_function(
                    "window.__serendibProbeComplete === true",
                    timeout=PROBE_TIMEOUT_SECONDS * 1000,
                )
                browser.close()
    except Exception as exc:  # Playwright exposes several transport exceptions.
        return _result(
            "UNAVAILABLE",
            errors=[{"code": "SERENDIB_WEB_PROBE_FAILED", "message": str(exc)[:500]}],
            source="web",
        )
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
    return _parse(console_lines, source="web")


def _chromium_dom_probe(browser_executable: Path, url: str) -> list[str]:
    """Probe without Playwright over Chromium's DevTools protocol.

    The reviewed Web runtime writes a base64 JSON verdict onto the root element.
    This is deterministic state evidence, not a screenshot or inferred console log.
    """
    with tempfile.TemporaryDirectory(prefix="serendib-browser-") as profile:
        startupinfo = None
        creationflags = 0
        if os.name == "nt":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
            creationflags = subprocess.CREATE_NO_WINDOW
        process = subprocess.Popen(
            [
                str(browser_executable),
                "--headless=new",
                "--disable-dev-shm-usage",
                "--disable-background-networking",
                "--no-first-run",
                "--enable-unsafe-swiftshader",
                "--use-angle=swiftshader",
                "--remote-allow-origins=*",
                "--remote-debugging-port=0",
                f"--user-data-dir={profile}",
                url,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            startupinfo=startupinfo,
            creationflags=creationflags,
        )
        try:
            port_file = Path(profile) / "DevToolsActivePort"
            deadline = time.monotonic() + PROBE_TIMEOUT_SECONDS
            while not port_file.is_file():
                if process.poll() is not None:
                    raise RuntimeError(
                        "Chromium exited before DevTools was ready: "
                        f"{process.returncode}"
                    )
                if time.monotonic() >= deadline:
                    raise TimeoutError("Chromium DevTools endpoint did not become ready")
                time.sleep(0.1)
            port = int(port_file.read_text(encoding="utf-8").splitlines()[0])
            websocket_url = _page_websocket_url(port, url, deadline)
            sock = _open_websocket(websocket_url)
            try:
                request_id = 0
                while time.monotonic() < deadline:
                    request_id += 1
                    value = _cdp_evaluate(
                        sock,
                        request_id,
                        "window.__serendibProbeComplete === true ? "
                        "document.documentElement.getAttribute('data-serendib-probe') : null",
                    )
                    if isinstance(value, str) and value:
                        payload = base64.b64decode(value, validate=True).decode("utf-8")
                        json.loads(payload)
                        return [PROBE_PREFIX + payload]
                    time.sleep(0.25)
                raise TimeoutError("Web simulation did not publish a probe verdict")
            finally:
                sock.close()
        finally:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)


def _page_websocket_url(port: int, expected_url: str, deadline: float) -> str:
    while time.monotonic() < deadline:
        try:
            endpoint = f"http://127.0.0.1:{port}/json/list"
            with urllib.request.urlopen(endpoint, timeout=2) as response:
                targets = json.load(response)
            pages = [target for target in targets if target.get("type") == "page"]
            expected_base = expected_url.split("?", 1)[0]
            matching = [
                target for target in pages if expected_base in target.get("url", "")
            ]
            target = matching[0] if matching else pages[0] if pages else None
            if target and target.get("webSocketDebuggerUrl"):
                return str(target["webSocketDebuggerUrl"])
        except (OSError, ValueError, json.JSONDecodeError):
            pass
        time.sleep(0.1)
    raise TimeoutError("Chromium page target did not become ready")


def _open_websocket(websocket_url: str) -> socket.socket:
    parsed = urlsplit(websocket_url)
    sock = socket.create_connection((parsed.hostname or "127.0.0.1", parsed.port or 80), timeout=10)
    key = base64.b64encode(os.urandom(16)).decode("ascii")
    request_target = parsed.path + (f"?{parsed.query}" if parsed.query else "")
    request = (
        f"GET {request_target} HTTP/1.1\r\n"
        f"Host: {parsed.hostname}:{parsed.port}\r\n"
        "Upgrade: websocket\r\nConnection: Upgrade\r\n"
        f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n"
    )
    sock.sendall(request.encode("ascii"))
    response = b""
    while b"\r\n\r\n" not in response:
        response += sock.recv(4096)
        if len(response) > 65536:
            raise RuntimeError("oversized Chromium WebSocket handshake")
    if not response.startswith(b"HTTP/1.1 101"):
        raise RuntimeError(
            "Chromium rejected the WebSocket handshake: "
            + response[:1000].decode("utf-8", errors="replace")
        )
    return sock


def _recv_exact(sock: socket.socket, size: int) -> bytes:
    chunks = bytearray()
    while len(chunks) < size:
        chunk = sock.recv(size - len(chunks))
        if not chunk:
            raise ConnectionError("Chromium closed the DevTools socket")
        chunks.extend(chunk)
    return bytes(chunks)


def _send_websocket(sock: socket.socket, payload: bytes, opcode: int = 0x1) -> None:
    mask = os.urandom(4)
    length = len(payload)
    header = bytearray([0x80 | opcode])
    if length < 126:
        header.append(0x80 | length)
    elif length <= 0xFFFF:
        header.append(0x80 | 126)
        header.extend(struct.pack("!H", length))
    else:
        header.append(0x80 | 127)
        header.extend(struct.pack("!Q", length))
    header.extend(mask)
    masked = bytes(byte ^ mask[index % 4] for index, byte in enumerate(payload))
    sock.sendall(bytes(header) + masked)


def _receive_websocket(sock: socket.socket) -> tuple[int, bytes]:
    first, second = _recv_exact(sock, 2)
    opcode = first & 0x0F
    length = second & 0x7F
    if length == 126:
        length = struct.unpack("!H", _recv_exact(sock, 2))[0]
    elif length == 127:
        length = struct.unpack("!Q", _recv_exact(sock, 8))[0]
    mask = _recv_exact(sock, 4) if second & 0x80 else None
    payload = _recv_exact(sock, length)
    if mask is not None:
        payload = bytes(byte ^ mask[index % 4] for index, byte in enumerate(payload))
    return opcode, payload


def _cdp_evaluate(sock: socket.socket, request_id: int, expression: str):
    _send_websocket(
        sock,
        json.dumps(
            {
                "id": request_id,
                "method": "Runtime.evaluate",
                "params": {"expression": expression, "returnByValue": True},
            },
            separators=(",", ":"),
        ).encode("utf-8"),
    )
    while True:
        opcode, payload = _receive_websocket(sock)
        if opcode == 0x8:
            raise ConnectionError("Chromium closed the DevTools WebSocket")
        if opcode == 0x9:
            _send_websocket(sock, payload, opcode=0xA)
            continue
        if opcode != 0x1:
            continue
        message = json.loads(payload)
        if message.get("id") != request_id:
            continue
        if "error" in message:
            raise RuntimeError(str(message["error"]))
        return message.get("result", {}).get("result", {}).get("value")


def compare_platform_traces(desktop: dict, web: dict) -> dict:
    if desktop.get("status") != "PASS" or web.get("status") != "PASS":
        status = "FAIL" if "FAIL" in {desktop.get("status"), web.get("status")} else "UNAVAILABLE"
        return _result(
            status,
            errors=[
                *list(desktop.get("errors") or []),
                *list(web.get("errors") or []),
            ],
            desktop=desktop.get("evidence", {}),
            web=web.get("evidence", {}),
        )
    desktop_trace = desktop.get("evidence", {}).get("state_trace")
    web_trace = web.get("evidence", {}).get("state_trace")
    desktop_logical = _logical_state_trace(desktop_trace)
    web_logical = _logical_state_trace(web_trace)
    if desktop_logical != web_logical:
        return _result(
            "FAIL",
            errors=[{"code": "DESKTOP_WEB_STATE_TRACE_MISMATCH"}],
            desktop_trace=desktop_trace,
            web_trace=web_trace,
            desktop_logical_trace=desktop_logical,
            web_logical_trace=web_logical,
        )
    return _result(
        "PASS",
        desktop_trace=desktop_trace,
        web_trace=web_trace,
        logical_trace=desktop_logical,
    )


def _logical_state_trace(trace: object) -> object:
    """Remove only platform-timing-sensitive transforms from dynamic entities.

    Each platform probe independently verifies that autonomous bodies actually
    move and can navigate. Parity compares their observable semantic state, while
    static entity transforms remain exact.
    """
    if not isinstance(trace, dict):
        return trace
    normalized = {
        "status": trace.get("status"),
        "errors": list(trace.get("errors") or []),
        "trace": [],
    }
    for raw in trace.get("trace") or []:
        if not isinstance(raw, dict):
            normalized["trace"].append(raw)
            continue
        entry = dict(raw)
        if bool(entry.get("dynamic")):
            entry.pop("position_m", None)
        normalized["trace"].append(entry)
    return normalized
