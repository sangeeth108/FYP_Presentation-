"""Headless web export driver (S7 entry): generated project -> WebGL2 build.

Writes the known-good Web export preset (proven by the golden game:
Compatibility renderer, **single-threaded**, VRAM texture compression OFF —
both flags are hard browser-compatibility requirements, see
docs/GOLDEN_GAME_TASKS.md §9) and drives the pinned Godot editor headlessly.

Requires the pinned Serendib 4.6.3-stable binary (path via argument or
`GODOT_BIN`) with matching web export templates installed.
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path

from godot_client.project_writer import ProjectWriterError

EXPORT_TIMEOUT_SECONDS = 300
SERENDIB_HEAD_INCLUDE = (
    "<meta name='theme-color' content='#061a1b' data-serendib-brand='1'>"
    "<meta name='generator' content='Serendib Engine'>"
    "<style>html,body{background:#061a1b;color:#d8f3f0}"
    "#status-progress{background:#25a99a!important}"
    "#status-notice{color:#9bc8c3!important}</style>"
)

WEB_PRESET = """[runnable_presets]

Web="Web"

[preset.0]

name="Web"
platform="Web"
runnable=true
dedicated_server=false
custom_features=""
export_filter="all_resources"
include_filter=""
exclude_filter=""
export_path="build/index.html"
encryption_include_filters=""
encryption_exclude_filters=""
encrypt_pck=false
encrypt_directory=false
script_export_mode=2

[preset.0.options]

custom_template/debug=""
custom_template/release=""
variant/extensions_support=false
variant/thread_support=false
vram_texture_compression/for_desktop=false
vram_texture_compression/for_mobile=false
html/export_icon=true
html/custom_html_shell=""
html/head_include="<meta name='theme-color' content='#061a1b' data-serendib-brand='1'><meta name='generator' content='Serendib Engine'><style>html,body{background:#061a1b;color:#d8f3f0}#status-progress{background:#25a99a!important}#status-notice{color:#9bc8c3!important}</style>"
html/canvas_resize_policy=2
html/focus_canvas_on_start=true
html/experimental_virtual_keyboard=false
progressive_web_app/enabled=false
"""

_DESKTOP_PLATFORMS = {
    "Windows Desktop": ("serendib_simulation.exe", 'binary_format/architecture="x86_64"'),
    "Linux/X11": ("serendib_simulation.x86_64", 'binary_format/architecture="x86_64"'),
    "macOS": ("serendib_simulation.app", 'binary_format/architecture="universal"'),
}


def _desktop_preset(platform: str) -> tuple[str, str]:
    if platform not in _DESKTOP_PLATFORMS:
        raise ProjectWriterError(
            code="desktop_export_platform_unsupported",
            path="desktop_export_platform",
            message=f"unsupported desktop export platform: {platform}",
            hint=f"choose one of {sorted(_DESKTOP_PLATFORMS)}",
        )
    filename, architecture = _DESKTOP_PLATFORMS[platform]
    preset = f'''\n[preset.1]\n\nname="Desktop"\nplatform="{platform}"\nrunnable=false\ndedicated_server=false\ncustom_features=""\nexport_filter="all_resources"\ninclude_filter=""\nexclude_filter=""\nexport_path="build/desktop/{filename}"\nencryption_include_filters=""\nencryption_exclude_filters=""\nencrypt_pck=false\nencrypt_directory=false\nscript_export_mode=2\n\n[preset.1.options]\n\n{architecture}\n'''
    return preset, filename


def write_export_preset(
    project_dir: Path, desktop_platform: str | None = None
) -> Path:
    """Write vetted Web and, when requested, desktop export presets."""
    path = project_dir / "export_presets.cfg"
    body = WEB_PRESET
    if desktop_platform is not None:
        desktop, _filename = _desktop_preset(desktop_platform)
        body += desktop
    path.write_text(body, encoding="utf-8", newline="\n")
    return path


def externalise_inline_scripts(index: Path) -> list[Path]:
    """Move the exported shell's inline boot script into its own file.

    Builds are served under a strict Content-Security-Policy
    (``script-src 'self' 'wasm-unsafe-eval'``) which blocks inline ``<script>``.
    The Godot web shell boots from an inline ``GODOT_CONFIG`` block, so the page
    died before the engine started: "Executing inline script violates the
    following Content Security Policy directive". Writing that block to a sibling
    ``.js`` file keeps the policy strict — no ``'unsafe-inline'`` weakening it and
    no per-build hash to keep in sync — while the shell behaves identically.
    """
    html = index.read_text(encoding="utf-8", errors="replace")
    written: list[Path] = []

    def _extract(match: re.Match) -> str:
        body = match.group(2)
        if not body.strip():
            return match.group(0)  # already an external <script src=...>
        target = index.parent / f"{index.stem}.boot{len(written) + 1}.js"
        target.write_text(body, encoding="utf-8")
        written.append(target)
        return f'<script src="{target.name}"></script>'

    updated = re.sub(
        r"<script([^>]*)>(.*?)</script>",
        _extract,
        html,
        flags=re.IGNORECASE | re.DOTALL,
    )
    if written:
        index.write_text(updated, encoding="utf-8")
    return written


def export_web(project_dir: Path, godot_bin: Path) -> dict:
    """Import + export the project's Web build; returns {build_dir, total_bytes, files}."""
    if not (project_dir / "export_presets.cfg").is_file():
        write_export_preset(project_dir)
    build_dir = project_dir / "build"
    build_dir.mkdir(exist_ok=True)

    for args in (
        ["--headless", "--path", str(project_dir), "--import"],
        ["--headless", "--path", str(project_dir), "--export-release", "Web", "build/index.html"],
    ):
        result = subprocess.run(
            [str(godot_bin), *args],
            capture_output=True,
            text=True,
            timeout=EXPORT_TIMEOUT_SECONDS,
        )
        if result.returncode != 0:
            raise ProjectWriterError(
                code="godot_export_failed",
                path=" ".join(args),
                message=f"godot exited {result.returncode}: {result.stderr[-500:]}",
                hint="Check the pinned editor version and installed web export templates.",
            )

    index = build_dir / "index.html"
    if not index.is_file():
        raise ProjectWriterError(
            code="export_output_missing",
            path=str(index),
            message="export reported success but build/index.html is missing",
            hint="Inspect the godot export log; verify the Web preset name.",
        )
    html = index.read_text(encoding="utf-8", errors="replace")
    non_script = re.sub(
        r"<(?:script|style)\b[^>]*>.*?</(?:script|style)>",
        "",
        html,
        flags=re.IGNORECASE | re.DOTALL,
    )
    visible_text = re.sub(r"<[^>]+>", " ", non_script)
    if "data-serendib-brand" not in html or "Godot Engine" in visible_text:
        raise ProjectWriterError(
            code="serendib_web_branding_failed",
            path=str(index),
            message="exported browser shell failed the visible Serendib branding check",
            hint="verify the Serendib head include and export template patch series",
        )
    externalise_inline_scripts(index)
    files = sorted(p for p in build_dir.iterdir() if p.is_file())
    return {
        "build_dir": build_dir,
        "total_bytes": sum(p.stat().st_size for p in files),
        "files": files,
    }


def _missing_templates(output: str) -> str:
    """The template paths the engine said it could not find, for the error path."""
    found = re.findall(
        r"No export template found at the expected path:\s+(\S+)", output
    )
    return ", ".join(sorted(set(found)))


def export_desktop(
    project_dir: Path,
    godot_bin: Path,
    platform: str = "Windows Desktop",
) -> dict:
    """Export and return the actual desktop artifact from the canonical project."""
    _preset, filename = _desktop_preset(platform)
    write_export_preset(project_dir, desktop_platform=platform)
    output_dir = project_dir / "build" / "desktop"
    output_dir.mkdir(parents=True, exist_ok=True)
    relative_output = f"build/desktop/{filename}"
    result = subprocess.run(
        [
            str(godot_bin),
            "--headless",
            "--path",
            str(project_dir),
            "--export-release",
            "Desktop",
            relative_output,
        ],
        capture_output=True,
        text=True,
        timeout=EXPORT_TIMEOUT_SECONDS,
        check=False,
    )
    if result.returncode != 0:
        # An absent export template is a property of THIS MACHINE, not of the
        # generated world, and the two must not report identically. A run whose
        # simulation is sound but whose host cannot build desktop binaries was
        # reporting `serendib_desktop_export_failed`, which reads as a defect in
        # the world the user just generated. The run stays unreleasable either
        # way -- only the diagnosis changes, and a wrong diagnosis sends someone
        # to debug the wrong thing.
        combined = f"{result.stdout}\n{result.stderr}"
        if "No export template found" in combined:
            raise ProjectWriterError(
                code="desktop_export_template_not_installed",
                path=str(_missing_templates(combined) or relative_output),
                message=(
                    "this machine has no desktop export template for the pinned "
                    "engine version, so a desktop build cannot be produced here; "
                    "the simulation itself was not evaluated for this layer"
                ),
                hint=(
                    "install the desktop export templates for the pinned version "
                    "(editor: Manage Export Templates), then re-run"
                ),
            )
        raise ProjectWriterError(
            code="serendib_desktop_export_failed",
            path=relative_output,
            message=f"Serendib exited {result.returncode}: {result.stderr[-500:]}",
            hint="check the desktop export preset and the project's export settings",
        )
    executable = output_dir / filename
    if not executable.exists():
        raise ProjectWriterError(
            code="desktop_export_output_missing",
            path=str(executable),
            message="desktop export reported success but its artifact is missing",
            hint="verify the selected platform template and output extension",
        )
    files = sorted(path for path in output_dir.rglob("*") if path.is_file())
    return {
        "build_dir": output_dir,
        "executable": executable,
        "total_bytes": sum(path.stat().st_size for path in files),
        "files": files,
        "platform": platform,
    }
