"""Composable interactive objects: snap affordance parts onto a parent's sockets.

The deterministic core of ADR-0008. An object is a static parent mesh plus zero
or more affordance PARTS (a door, a vehicle door, a lid, a lever) — each a
separate node bound to a vetted behaviour template and placed at a named SOCKET
on the parent's normalised bounding box. The mesh never carries behaviour; this
module only computes WHERE each part goes and HOW it is oriented, so the same
machinery works for a house door and a car door with no special-casing.

Why sockets are convention points on the bbox (not detected mesh holes): a
generated mesh is normalised to a known box, so "front-centre, on the ground,
facing out" is deterministic — a car door's hinge is exact by construction, which
is the whole reason a separated part hinges correctly where a mesh-baked door
never could (ADR-0008).

Pure geometry, no Godot, fully seed-free and unit-testable. The project writer
consumes `part_world_transform` to emit the DoorHinged/pickup/... node; the
behaviour (open angle, lock) lives in the template, chosen by the brain (rule 10).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

# Affordance templates this composition layer knows how to bind. Each maps to a
# vetted GDScript template in engine/templates/interactables/ (rule 10 — behaviour
# is never authored, only selected). New affordances join by adding a template +
# a row here, never a new code path.
AFFORDANCE_TEMPLATES = {
    "door_hinged": "hinged",  # house door, vehicle door, gate — swings on a hinge
    "door_hinged_lockable": "hinged",
    "pickup_collectible": "point",  # a grabbable item at a point
}

# A sane default swing per affordance flavour (degrees). The brain may override
# via params; a car door opens less than a house door.
DEFAULT_OPEN_ANGLE_DEG = -90.0


@dataclass(frozen=True)
class Socket:
    """A named anchor on the parent's NORMALISED bounding box.

    `offset` is (x, y, z) where x,z are in [-0.5, 0.5] (centred on the box) and y
    is in [0, 1] (0 = base/ground, 1 = top) — so "on the ground at the front-right
    edge" is (0.5, 0.0, 0.5). `facing_deg` is the yaw the part faces relative to
    the parent. `hinge` names the rotation axis for hinged affordances.
    """

    name: str
    offset: tuple[float, float, float]
    facing_deg: float = 0.0
    hinge: str = "y"  # "y" (vertical, doors) is the only one v1 materialises


@dataclass(frozen=True)
class AffordancePart:
    """One interactable part attached to a socket, bound to a behaviour template."""

    part_id: str
    template_id: str
    socket: Socket
    mesh_rel: str | None = None  # kit-relative mesh, or None (functional/generated)
    params: dict = field(default_factory=dict)  # open_angle_deg, locked, unlocked_by_objective…

    def __post_init__(self) -> None:
        if self.template_id not in AFFORDANCE_TEMPLATES:
            raise ValueError(
                f"unknown affordance template {self.template_id!r}; "
                f"known: {sorted(AFFORDANCE_TEMPLATES)}"
            )
        ox, oy, oz = self.socket.offset
        if not (-0.5 <= ox <= 0.5 and 0.0 <= oy <= 1.0 and -0.5 <= oz <= 0.5):
            raise ValueError(
                f"socket {self.socket.name!r} offset {self.socket.offset} out of range "
                "(x,z in [-0.5,0.5], y in [0,1])"
            )


@dataclass(frozen=True)
class CompositeObject:
    """A static parent (its footprint) plus affordance parts snapped to its sockets."""

    object_id: str
    bbox: tuple[float, float, float]  # parent size (width_x, height_y, depth_z) in metres
    parts: tuple[AffordancePart, ...] = ()


@dataclass(frozen=True)
class PartPlacement:
    """A part resolved to a WORLD transform, ready for the writer to instance."""

    part_id: str
    template_id: str
    x: float
    y: float
    z: float
    yaw_deg: float
    hinge: str
    mesh_rel: str | None
    params: dict


def part_world_transform(
    parent_origin: tuple[float, float, float],
    parent_yaw_deg: float,
    bbox: tuple[float, float, float],
    socket: Socket,
) -> tuple[float, float, float, float]:
    """World `(x, y, z, yaw_deg)` for a socket on a parent at `parent_origin`.

    The socket's normalised offset is scaled by the bbox to a parent-local point,
    rotated by the parent's yaw about the vertical (Y) axis, then translated to the
    parent's world origin. The part's facing is the parent yaw plus the socket's
    facing — so a car door on the left side still faces outward after the car is
    rotated. Deterministic; the hinge sits exactly at this point (ADR-0008).
    """
    bw, bh, bd = bbox
    ox, oy, oz = socket.offset
    # parent-local (Y-up): x,z centred; y measured up from the base
    lx, ly, lz = ox * bw, oy * bh, oz * bd
    theta = math.radians(parent_yaw_deg)
    cos_t, sin_t = math.cos(theta), math.sin(theta)
    # rotate the horizontal offset about Y
    wx = parent_origin[0] + lx * cos_t + lz * sin_t
    wz = parent_origin[2] - lx * sin_t + lz * cos_t
    wy = parent_origin[1] + ly
    return wx, wy, wz, parent_yaw_deg + socket.facing_deg


def resolve_parts(
    obj: CompositeObject,
    parent_origin: tuple[float, float, float],
    parent_yaw_deg: float = 0.0,
) -> list[PartPlacement]:
    """Every affordance part of `obj` resolved to a world PartPlacement.

    Order-stable (parts are emitted in declaration order) so the same composite
    always materialises the same scene. Params carry through, with a sensible
    default open angle for hinged affordances the brain didn't specify.
    """
    placements: list[PartPlacement] = []
    for part in obj.parts:
        x, y, z, yaw = part_world_transform(parent_origin, parent_yaw_deg, obj.bbox, part.socket)
        params = dict(part.params)
        if AFFORDANCE_TEMPLATES[part.template_id] == "hinged":
            params.setdefault("open_angle_deg", DEFAULT_OPEN_ANGLE_DEG)
        placements.append(
            PartPlacement(
                part_id=part.part_id,
                template_id=part.template_id,
                x=x,
                y=y,
                z=z,
                yaw_deg=yaw,
                hinge=part.socket.hinge,
                mesh_rel=part.mesh_rel,
                params=params,
            )
        )
    return placements
