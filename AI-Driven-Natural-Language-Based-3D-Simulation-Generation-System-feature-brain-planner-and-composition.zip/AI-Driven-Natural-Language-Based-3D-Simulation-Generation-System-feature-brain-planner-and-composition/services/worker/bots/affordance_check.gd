extends SceneTree

## AffordanceCheck (Bots, ADR-0008 phase 2c): proves every hinged affordance in a
## generated scene ACTUALLY WORKS — not that it merely exists.
##
## The greedy bot only exercises the exit LockedDoor (it is on the win path);
## composite affordances (a vehicle door, a house door, a chest lid) sit OFF the
## critical path, so nothing proved they open. This does, by reading state (never
## vision): find each DoorHinged node, interact, and assert it swung ~open_angle;
## a LOCKED door must stay shut until unlocked, then open. Prints
## AFFORDANCE_OK / AFFORDANCE_FAIL <reason>, the correctness oracle the ADR
## requires (feeds the repair loop when a composed affordance is wrong).
##
## Run: godot --headless --path <project> --script res://affordance_check.gd

const SETTLE_SECONDS := 2.0  # long enough for the 0.8s open tween to finish
const OPEN_TOLERANCE := 0.15  # radians of slack against the target swing

var _doors: Array = []  # {node, rot0, target, locked, opened}
var _bound := false
var _elapsed := 0.0


func _initialize() -> void:
	var scene := (load("res://main.tscn") as PackedScene).instantiate()
	root.add_child(scene)
	Engine.time_scale = 5.0


func _process(delta: float) -> bool:
	_elapsed += delta
	if not _bound:
		_bind_and_trigger()
		return false
	if _elapsed < SETTLE_SECONDS:
		return false
	return _report()


func _bind_and_trigger() -> void:
	var world := root.get_node_or_null("World")
	if world == null:
		return
	_bound = true
	_find_doors(world)
	if _doors.is_empty():
		print("AFFORDANCE_OK doors=0 (nothing hinged to prove)")
		quit(0)
		return
	for entry in _doors:
		var node: Node = entry["node"]
		node.door_opened.connect(func(): entry["opened"] = true)
		if entry["locked"]:
			# Contract: a locked door must NOT open on interact...
			node._try_open()
			entry["opened_while_locked"] = _has_swung(entry)
			node.unlock()  # ...and MUST open once unlocked.
		node._try_open()


func _find_doors(node: Node) -> void:
	for child in node.get_children():
		# A hinged affordance is any node bound to the door template: it swings on
		# interact and reports door_opened. Read by capability, not by name, so a
		# composite car door and the exit LockedDoor are found the same way.
		if child.has_signal("door_opened") and child.has_method("_try_open"):
			var angle: float = child.open_angle_deg if "open_angle_deg" in child else -90.0
			_doors.append({
				"node": child,
				"rot0": (child as Node3D).rotation.y,
				"target": deg_to_rad(angle),
				"locked": child.locked if "locked" in child else false,
				"opened": false,
				"opened_while_locked": false,
			})
		_find_doors(child)


func _has_swung(entry: Dictionary) -> bool:
	var node: Node3D = entry["node"]
	return absf(node.rotation.y - entry["rot0"]) > OPEN_TOLERANCE


func _report() -> bool:
	var failures: Array = []
	for entry in _doors:
		var node: Node3D = entry["node"]
		var swung: float = node.rotation.y - entry["rot0"]
		if entry["opened_while_locked"]:
			failures.append("%s opened while LOCKED" % node.name)
		elif not entry["opened"]:
			failures.append("%s never emitted door_opened" % node.name)
		elif absf(swung - entry["target"]) > OPEN_TOLERANCE:
			failures.append(
				"%s swung %.2f rad, expected %.2f" % [node.name, swung, entry["target"]]
			)
	if failures.is_empty():
		print("AFFORDANCE_OK doors=%d (all opened correctly)" % _doors.size())
		quit(0)
	else:
		print("AFFORDANCE_FAIL %s" % "; ".join(failures))
		quit(1)
	return true
