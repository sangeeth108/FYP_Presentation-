"""Critical-path waypoints for the walk-probe bot (Bots v1, P1).

Computes the room-center route entry -> key -> exit from the level plan's
corridor graph (BFS, deterministic), inserting a door-front waypoint
(flagged ``interact``) and a door-back waypoint around the locked door.
The GDScript bot (walk_probe.gd) replays these through the REAL player
controller physics — proving the generated game is walkable start-to-win.
"""

from __future__ import annotations

import json
from pathlib import Path

from godot_client.project_writer import _locked_door_placement

DOOR_CLEARANCE = 1.5


def _bfs_path(adjacency: dict[str, list[str]], start: str, goal: str) -> list[str]:
    parents: dict[str, str | None] = {start: None}
    frontier = [start]
    while frontier:
        current = frontier.pop(0)
        if current == goal:
            path = [current]
            while parents[current] is not None:
                current = parents[current]
                path.append(current)
            return list(reversed(path))
        for n in sorted(adjacency.get(current, [])):
            if n not in parents:
                parents[n] = current
                frontier.append(n)
    raise ValueError(f"no path {start} -> {goal}")


def critical_path_waypoints(plan: dict) -> list[dict]:
    """Waypoints [{x, z, interact?}, ...] along entry -> key -> exit."""
    kinds = {z["zone_id"]: z["kind"] for z in plan["zones"]}
    rooms = {r["zone_id"]: r for r in plan["rooms"]}
    entry = next(zid for zid, k in kinds.items() if k == "entry")
    key = next(zid for zid, k in kinds.items() if k == "key")
    exit_id = next(zid for zid, k in kinds.items() if k == "exit")

    adjacency: dict[str, list[str]] = {}
    for c in plan["corridors"]:
        adjacency.setdefault(c["a"], []).append(c["b"])
        adjacency.setdefault(c["b"], []).append(c["a"])

    route = _bfs_path(adjacency, entry, key) + _bfs_path(adjacency, key, exit_id)[1:]

    corridors_by_pair = {frozenset((c["a"], c["b"])): c for c in plan["corridors"]}

    def center(zid: str) -> dict:
        r = rooms[zid]
        return {"x": r["x"] + r["width"] / 2, "z": r["z"] + r["depth"] / 2}

    # Walk corridor polylines between room centers — straight center-to-center
    # lines clip wall corners beside the corridor mouths (walk-bot finding).
    waypoints: list[dict] = [center(route[0])]
    for prev, zid in zip(route, route[1:], strict=False):  # pairwise: lengths differ by 1
        corridor = corridors_by_pair[frozenset((prev, zid))]
        points = corridor["points"] if corridor["a"] == prev else list(reversed(corridor["points"]))
        waypoints.extend({"x": x, "z": z} for x, z in points[1:-1])
        if zid != exit_id:  # the exit leg ends at the door instead (below)
            waypoints.append(center(zid))

    axis, dx, dz, _ = _locked_door_placement(plan, rooms, exit_id)
    exit_room = rooms[exit_id]
    ex, ez = exit_room["x"] + exit_room["width"] / 2, exit_room["z"] + exit_room["depth"] / 2
    if axis == "x":
        toward_exit = 1.0 if ex > dx else -1.0
        front = {"x": dx - toward_exit * DOOR_CLEARANCE, "z": dz, "interact": True}
        back = {"x": dx + toward_exit * DOOR_CLEARANCE, "z": dz}
    else:
        toward_exit = 1.0 if ez > dz else -1.0
        front = {"x": dx, "z": dz - toward_exit * DOOR_CLEARANCE, "interact": True}
        back = {"x": dx, "z": dz + toward_exit * DOOR_CLEARANCE}
    waypoints.extend([front, back, {"x": ex, "z": ez}])
    return waypoints


def write_waypoints(plan: dict, project_dir: Path) -> Path:
    path = project_dir / "bot_waypoints.json"
    path.write_text(json.dumps(critical_path_waypoints(plan)), encoding="utf-8")
    return path
