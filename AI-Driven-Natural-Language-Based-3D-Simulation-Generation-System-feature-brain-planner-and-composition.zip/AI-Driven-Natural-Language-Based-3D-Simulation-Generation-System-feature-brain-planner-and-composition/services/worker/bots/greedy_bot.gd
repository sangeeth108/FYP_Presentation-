extends SceneTree

## GreedyObjectiveBot (Bots v1, P1): completes a generated game headless by
## READING STATE — never vision, no precomputed route.
##   - Objectives are discovered from the scene (KeyZone / LockedDoor /
##     WinZone — writer-contract node names) and picked greedily by state:
##     key not done -> key; door not open -> door (+interact); else win zone.
##   - Movement follows live NavigationServer3D paths, replanned every
##     REPLAN_SECONDS; when the path ends off-target (nav islands are
##     per-tier by design) it walks straight — the ramps carry it across.
##   - Completion signals are the game's own (objective_completed,
##     door_opened). Prints GREEDYBOT_OK / _STUCK / _TIMEOUT.
## Run: godot --headless --path <project> --script res://greedy_bot.gd

const ARRIVE := 1.2  # for the final objective position
const WAYPOINT_ARRIVE := 0.5  # tight: cutting funnel corners wedges the capsule
const INTERACT_RANGE := 2.2
const NAV_ARRIVE := 2.0  # a nav path ending farther than this never got there
const REPLAN_SECONDS := 2.0
const JIGGLE_AFTER_SECONDS := 2.0  # pinned this long -> back off + sidestep
const JIGGLE_SECONDS := 0.8
const STUCK_SECONDS := 20.0  # only after several failed jiggles
const TIMEOUT_SECONDS := 150.0

var _player: CharacterBody3D
var _key_zone: Node3D
var _door: Node3D
var _win_zone: Node3D
var _quest: Node  # CollectQuest, when the game is a collect_n hunt
var _pickups: Array = []  # PickupCollectible nodes, uncollected first
var _ramps: Array = []  # {lower: Vector3, upper: Vector3}
var _ramp_near := Vector3.ZERO  # latched at commit: the end we climb FROM
var _ramp_far := Vector3.ZERO  # latched at commit: the end we climb TO
var _last_crossed := -1  # the ramp we just came off — never immediately re-take it
var _key_done := false
var _quest_done := false
var _door_open := false
var _won := false
var _path: PackedVector3Array = []
var _path_index := 0
var _replan_timer := 0.0
var _elapsed := 0.0
var _stuck_timer := 0.0
var _last_pos := Vector3.INF
var _crossing_ramp := -1  # index into _ramps while committed to a crossing
var _straight_mode := false  # true while physically climbing/descending a ramp
var _jiggle_timer := 0.0  # >0 while executing an unstuck maneuver
var _jiggle_side := 1.0


func _initialize() -> void:
	var scene := (load("res://main.tscn") as PackedScene).instantiate()
	root.add_child(scene)
	Engine.time_scale = 5.0


func _process(delta: float) -> bool:
	_elapsed += delta
	if _player == null:
		_bind_scene()
		return false
	if _won:
		print("GREEDYBOT_OK time=%.1fs" % _elapsed)
		_release_all()
		quit(0)
		return true
	if _elapsed > TIMEOUT_SECONDS:
		print("GREEDYBOT_TIMEOUT objective=%s pos=%s" % [_objective_name(), _player.global_position])
		# A timeout used to print nothing but the position, which says almost
		# nothing about WHY the bot never arrived. The stuck path already dumps
		# this; a timeout deserves the same.
		var t := _current_target()
		if t != null:
			print(
				"  diag: goal=%s ramps=%d crossing=%d straight=%s path_len=%d"
				% [_objective_position(t), _ramps.size(), _crossing_ramp, _straight_mode, _path.size()]
			)
			print(
				"  player: vel=%s on_floor=%s floor_normal=%s"
				% [_player.velocity, _player.is_on_floor(), _player.get_floor_normal()]
			)
		if _quest != null:
			var left := 0
			for p in _pickups:
				if not p.is_collected:
					left += 1
			print("  quest: %d/%d pickups left, done=%s" % [left, _pickups.size(), _quest_done])
		if t != null:
			# Probe where the bot is actually DRIVING (the ramp's far end while
			# crossing), not at the goal — they differ, and only the former
			# explains why it stopped.
			var dir := _travel_target(_objective_position(t)) - _player.global_position
			dir.y = 0.0
			_print_blocker(dir.normalized())
		quit(1)
		return true

	var target := _current_target()
	if target == null:
		print("GREEDYBOT_NO_OBJECTIVE — scene lacks WinZone")
		quit(1)
		return true

	var goal_pos := _objective_position(target)
	var to_goal := goal_pos - _player.global_position
	to_goal.y = 0.0

	# Interact when the door is the objective and we are close enough.
	if target == _door and to_goal.length() < INTERACT_RANGE:
		_release_movement()
		Input.action_press("interact")
		return false
	Input.action_release("interact")

	var travel := _travel_target(goal_pos)
	var to_travel := travel - _player.global_position
	to_travel.y = 0.0

	if _jiggle_timer > 0.0:
		# Unstuck maneuver: back away from the travel direction, biased to a
		# side, then force a fresh plan. Alternating sides escapes corners
		# and wall pockets a straight retry would re-enter.
		_jiggle_timer -= delta
		var away := -to_travel.normalized()
		var side := Vector3(-away.z, 0, away.x) * _jiggle_side
		_drive((away + side).normalized() * 2.0)
		if _jiggle_timer <= 0.0:
			_jiggle_side = -_jiggle_side
			_replan_timer = 0.0
			_stuck_timer = 0.0
		return false

	if _straight_mode:
		_drive(to_travel)  # committed to a ramp: physics carries us across
	else:
		_replan_timer -= delta
		if _replan_timer <= 0.0:
			_replan(travel)
		var waypoint := _next_waypoint(travel)
		var to_wp := waypoint - _player.global_position
		to_wp.y = 0.0
		var arrive := WAYPOINT_ARRIVE if _path_index < _path.size() else ARRIVE
		if to_wp.length() < arrive and _path_index < _path.size():
			_path_index += 1
			return false
		_drive(to_wp)

	if _player.global_position.distance_to(_last_pos) < 0.01 * Engine.time_scale:
		_stuck_timer += delta
		if fmod(_stuck_timer, JIGGLE_AFTER_SECONDS) < delta and _stuck_timer > JIGGLE_AFTER_SECONDS:
			_jiggle_timer = JIGGLE_SECONDS
		if _stuck_timer > STUCK_SECONDS:
			print("GREEDYBOT_STUCK objective=%s pos=%s" % [_objective_name(), _player.global_position])
			print(
				"  diag: goal=%s travel=%s straight=%s ramp=%d ramps=%d path_len=%d path_i=%d"
				% [goal_pos, travel, _straight_mode, _crossing_ramp, _ramps.size(), _path.size(), _path_index]
			)
			if _path.size() > 0:
				var lo := maxi(0, _path_index - 1)
				print("  path near index: %s" % [_path.slice(lo, mini(_path.size(), lo + 3))])
			_print_blocker(to_travel.normalized())
			quit(1)
			return true
	else:
		_stuck_timer = 0.0
	_last_pos = _player.global_position
	return false


func _bind_scene() -> void:
	_player = root.get_node_or_null("World/Player")
	if _player == null:
		return
	_key_zone = root.get_node_or_null("World/KeyZone")
	_door = root.get_node_or_null("World/LockedDoor")
	_win_zone = root.get_node_or_null("World/WinZone")
	if _key_zone != null:
		_key_zone.objective_completed.connect(func(_id): _key_done = true)
	else:
		_key_done = true

	# collect_n games have no KeyZone: the relics ARE the key. Gather them by
	# reading each pickup's own state (never vision), same contract as the rest.
	_quest = root.get_node_or_null("World/CollectQuest")
	if _quest != null:
		_quest.objective_completed.connect(func(_id): _quest_done = true)
		for child in root.get_node("World").get_children():
			if child is Area3D and "is_collected" in child:
				_pickups.append(child)
	else:
		_quest_done = true
	if _door != null:
		_door.door_opened.connect(func(): _door_open = true)
	else:
		_door_open = true
	if _win_zone != null:
		_win_zone.objective_completed.connect(func(_id): _won = true)
	_collect_ramps()


func _collect_ramps() -> void:
	# Ramps are writer-contract nodes: Corridor*Ramp (StaticBody3D + BoxMesh
	# child). Read the slab's long axis + length from the mesh to derive the
	# lower/upper end points — pure state reading.
	var world := root.get_node("World")
	for child in world.get_children():
		if not (child is StaticBody3D and child.name.ends_with("Ramp")):
			continue
		var mesh_node: MeshInstance3D = child.get_node_or_null(String(child.name) + "Mesh")
		if mesh_node == null or not (mesh_node.mesh is BoxMesh):
			continue
		var size: Vector3 = (mesh_node.mesh as BoxMesh).size
		var basis := (child as Node3D).global_transform.basis
		var axis := basis.x * (size.x / 2.0) if size.x >= size.z else basis.z * (size.z / 2.0)
		var center := (child as Node3D).global_position
		# Lift the ends onto the WALKABLE SURFACE (half a slab up the face
		# normal). The raw ends are centre-line points, ~0.23 below the surface
		# the player actually stands on, and every height test downstream — "am I
		# at this end?", "is the goal on another tier?" — then answers wrongly
		# mid-ramp, which is what made the bot ride ramps up and down forever.
		var up_n := basis.y.normalized()
		if up_n.y < 0.0:
			up_n = -up_n  # the slab may be authored flipped; a box is symmetric
		var lift := up_n * (size.y / 2.0)
		var end_a := center + axis + lift
		var end_b := center - axis + lift
		var lower := end_a if end_a.y < end_b.y else end_b
		var upper := end_b if end_a.y < end_b.y else end_a
		_ramps.append({"lower": lower, "upper": upper})


func _current_target() -> Node3D:
	if not _key_done and _key_zone != null:
		return _key_zone
	if not _quest_done and _quest != null:
		var relic := _nearest_uncollected()
		if relic != null:
			return relic
	if not _door_open and _door != null:
		return _door
	return _win_zone


## Greedy: always go for the closest relic still on the floor.
func _nearest_uncollected() -> Node3D:
	var best: Node3D = null
	var best_d := INF
	for pickup in _pickups:
		if pickup.is_collected:
			continue
		var d: float = _player.global_position.distance_squared_to(pickup.global_position)
		if d < best_d:
			best_d = d
			best = pickup
	return best


func _objective_name() -> String:
	var t := _current_target()
	return t.name if t != null else "(none)"


func _objective_position(target: Node3D) -> Vector3:
	var pos := target.global_position
	# The door node's origin is the hinge (inside the wall); aim at the slab.
	if target == _door:
		var mesh := _door.get_node_or_null("LockedDoorMesh") as Node3D
		if mesh != null:
			pos = mesh.global_position

	# Aim at the FLOOR beneath the objective, never at its centre. Every objective
	# floats above its floor by a different amount — a KeyZone by 1.5 (which is
	# EXACTLY one tier height), the door slab by 1.25, a relic by 0.6 — and the
	# tier test compares this y against the player's feet. So the bot read a zone
	# on its OWN floor as "one storey up", committed to the ramp it had just
	# climbed, rode it back down, and looped forever. Ask the world where the
	# floor is rather than guessing each node type's offset.
	var floor_y := _floor_under(pos)
	if not is_nan(floor_y):
		pos.y = floor_y
	return pos


func _floor_under(pos: Vector3) -> float:
	var space := _player.get_world_3d().direct_space_state
	var query := PhysicsRayQueryParameters3D.create(
		pos + Vector3(0.0, 1.0, 0.0), pos - Vector3(0.0, 8.0, 0.0)
	)
	query.collision_mask = 1  # world geometry only
	var hit := space.intersect_ray(query)
	if hit.is_empty():
		return NAN
	return (hit["position"] as Vector3).y


func _travel_target(goal_pos: Vector3) -> Vector3:
	# Route around the per-tier nav islands: commit to the best ramp when
	# the goal sits on another elevation, walk to its near end via nav, then
	# straight across; replan (possibly onto another ramp) once we arrive.
	_straight_mode = false
	var py := _player.global_position.y
	if _crossing_ramp >= 0:
		# near/far are LATCHED when we commit (_ramp_near/_ramp_far), never
		# re-derived from the current height. Deriving them per-frame meant that
		# the instant the player climbed past the ramp's midpoint the "nearest
		# end" flipped to the top, the bot decided the far end was now the
		# BOTTOM, turned around, and walked back down — then flipped again. It
		# oscillated forever and could not cross the halfway point of ANY ramp,
		# which failed every generated game at gate 6.
		var near := _ramp_near
		var far := _ramp_far
		# Arrival is HORIZONTAL: "am I at the far end", not "am I at roughly the
		# right height". Height alone declared arrival mid-climb (the stored ends
		# are centre-line points, ~0.2 below the walkable surface and only 1.5
		# apart), so the bot dropped the ramp halfway up, re-planned, decided it
		# was already on the upper tier and had to descend, and turned around.
		var h_far := Vector2(
			_player.global_position.x - far.x, _player.global_position.z - far.z
		).length()
		if h_far < 0.8 and absf(py - far.y) < 0.4:
			_last_crossed = _crossing_ramp  # do not turn around and walk back down it
			_crossing_ramp = -1  # crossed — greedy replan from the new tier
			return goal_pos
		var h_near := Vector2(
			_player.global_position.x - near.x, _player.global_position.z - near.z
		).length()
		if h_near > 1.2 and absf(py - near.y) < 0.5:
			return near  # approach the ramp foot on this tier (nav-pathable)
		_straight_mode = true
		return far + (far - near).normalized() * 1.2  # commit across the slope
	# Take a ramp whenever the goal is NOT directly walkable — not merely when it
	# sits at another height. Tier-0 rooms are separate navmesh islands (you leave
	# the entry, go UP over tier 1, and come back down to the exit), so a goal at
	# the same elevation can still be unreachable without climbing. Judging by
	# height alone, the bot never even looked for a ramp and walked into a wall.
	if not _nav_reachable(goal_pos) and not _ramps.is_empty():
		_crossing_ramp = _best_ramp(goal_pos)
		if _crossing_ramp >= 0:
			# Latch which end we are climbing FROM, at the moment of commitment.
			var ramp: Dictionary = _ramps[_crossing_ramp]
			var lower: Vector3 = ramp["lower"]
			var upper: Vector3 = ramp["upper"]
			if absf(py - lower.y) <= absf(py - upper.y):
				_ramp_near = lower
				_ramp_far = upper
			else:
				_ramp_near = upper
				_ramp_far = lower
			return _travel_target(goal_pos)
	return goal_pos


## Can we actually WALK there from where we stand? The navmesh is islanded per
## tier (and tier-0 rooms are islands of their own), so "close" and "reachable"
## are different questions — and the bot was answering the wrong one.
func _nav_reachable(target: Vector3) -> bool:
	var map: RID = root.find_world_3d().navigation_map
	var path := NavigationServer3D.map_get_path(map, _player.global_position, target, true)
	if path.is_empty():
		return false
	# map_get_path returns the closest reachable point when the target is off our
	# island, so a path that stops short is a path to nowhere.
	return path[path.size() - 1].distance_to(target) < NAV_ARRIVE


func _best_ramp(goal_pos: Vector3) -> int:
	var py := _player.global_position.y
	var best_reachable := -1
	var best_reachable_cost := INF
	var best_any := -1
	var best_any_cost := INF
	for i in _ramps.size():
		var ramp: Dictionary = _ramps[i]
		var near: Vector3
		var far: Vector3
		if absf(ramp["lower"].y - py) < 0.5:
			near = ramp["lower"]
			far = ramp["upper"]
		elif absf(ramp["upper"].y - py) < 0.5:
			near = ramp["upper"]
			far = ramp["lower"]
		else:
			continue  # neither end on our tier
		if i == _last_crossed:
			# The ramp we just climbed is by definition the closest one, and its
			# far end is back where we came from — so a pure cost pick walks
			# straight back down it, then up, then down, forever. That livelock
			# (not a wall, not a slope) is what timed the bot out on the big
			# multi-tier levels.
			continue
		var cost := _player.global_position.distance_to(near) + far.distance_to(goal_pos)
		if cost < best_any_cost:
			best_any_cost = cost
			best_any = i
		# The nearest ramp is worthless if it sits in a room we cannot walk to.
		# Committing to one and marching at it in a straight line is exactly how
		# the bot ended up pinned against a wall with zero velocity for 150s.
		if cost < best_reachable_cost and _nav_reachable(near):
			best_reachable_cost = cost
			best_reachable = i
	return best_reachable if best_reachable >= 0 else best_any


func _replan(target_pos: Vector3) -> void:
	_replan_timer = REPLAN_SECONDS
	var map: RID = root.find_world_3d().navigation_map
	_path = NavigationServer3D.map_get_path(map, _player.global_position, target_pos, true)
	_path_index = 1  # 0 is our own position


func _next_waypoint(target_pos: Vector3) -> Vector3:
	if _path_index < _path.size():
		return _path[_path_index]
	# Path exhausted short of the goal (tier island edge): straight line —
	# the physical ramps carry us onto the next island, then we replan.
	return target_pos


func _drive(to_target: Vector3) -> void:
	if "mouse_sensitivity" in _player:
		_player.rotation.y = atan2(-to_target.x, -to_target.z)
		Input.action_press("move_forward")
		return
	var yaw := 0.0
	if "camera_yaw_deg" in _player:
		yaw = deg_to_rad(_player.camera_yaw_deg)
	var fwd := Vector3(-sin(yaw), 0, -cos(yaw))
	var rgt := Vector3(cos(yaw), 0, -sin(yaw))
	var dir := to_target.normalized()
	_press_axis("move_right", "move_left", dir.dot(rgt))
	_press_axis("move_back", "move_forward", -dir.dot(fwd))


func _press_axis(positive: String, negative: String, value: float) -> void:
	if value > 0.3:
		Input.action_press(positive)
		Input.action_release(negative)
	elif value < -0.3:
		Input.action_press(negative)
		Input.action_release(positive)
	else:
		Input.action_release(positive)
		Input.action_release(negative)


func _release_movement() -> void:
	for action in ["move_forward", "move_back", "move_left", "move_right"]:
		Input.action_release(action)


func _release_all() -> void:
	_release_movement()
	Input.action_release("interact")


func _print_blocker(direction: Vector3) -> void:
	var space := _player.get_world_3d().direct_space_state
	for height in [0.2, 0.9, 1.6]:
		var origin := _player.global_position + Vector3(0, height, 0)
		var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * 2.0)
		query.exclude = [_player.get_rid()]
		var hit := space.intersect_ray(query)
		if hit:
			print("  blocker h=%.1f -> %s at %s" % [height, hit["collider"].name, hit["position"]])
