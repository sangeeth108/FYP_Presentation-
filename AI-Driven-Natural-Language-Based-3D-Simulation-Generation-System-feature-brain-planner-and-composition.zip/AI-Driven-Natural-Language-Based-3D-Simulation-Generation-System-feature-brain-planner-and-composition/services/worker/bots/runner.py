"""Run a playtest bot against a written Godot project (gate 6).

The bot plays the generated game headlessly by READING STATE (never vision) and
prints a single verdict line: GREEDYBOT_OK / _STUCK / _TIMEOUT / _NO_OBJECTIVE.
That line is what gate 6 judges.

Deliberately fail-soft on infrastructure (no Godot binary, a crash, a hang):
those return None, and gate 6 records SKIPPED rather than failing a game for a
broken toolchain. A bot that actually plays and loses is a different thing — it
returns its verdict and the gate fails the game, which is the entire point.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

BOT_SCRIPT = Path(__file__).resolve().parent / "greedy_bot.gd"
AFFORDANCE_SCRIPT = Path(__file__).resolve().parent / "affordance_check.gd"
# The bot self-limits to 150s of game time; give the process headroom for engine
# start-up and headless physics, then hard-kill so a hung run can't wedge a job.
PROCESS_TIMEOUT_SECONDS = 300
VERDICT_PREFIX = "GREEDYBOT_"
AFFORDANCE_PREFIX = "AFFORDANCE_"


def _run_script(
    godot_bin: str,
    project_dir: Path,
    script: Path,
    verdict_prefix: str,
    timeout_seconds: int,
) -> str | None:
    """Run a headless bot/probe script in the project; return its verdict line,
    or None if it could not run at all (missing binary/script, crash, hang) —
    fail-soft on infrastructure so a broken toolchain SKIPs, never fails a game."""
    if not godot_bin or not script.is_file() or not (project_dir / "project.godot").is_file():
        return None
    try:
        shutil.copy(script, project_dir / script.name)  # must be res://-addressable
    except OSError:
        return None
    try:
        proc = subprocess.run(
            [godot_bin, "--headless", "--path", str(project_dir), "--script", f"res://{script.name}"],
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
    except (subprocess.TimeoutExpired, OSError):
        return None
    for line in (proc.stdout or "").splitlines():
        stripped = line.strip()
        if stripped.startswith(verdict_prefix):
            return stripped
    return None


def run_greedy_bot(
    godot_bin: str,
    project_dir: Path,
    timeout_seconds: int = PROCESS_TIMEOUT_SECONDS,
) -> str | None:
    """Play the project headlessly; returns the bot's verdict line, or None if
    the bot could not be run at all (missing binary/script, crash, hang)."""
    return _run_script(godot_bin, project_dir, BOT_SCRIPT, VERDICT_PREFIX, timeout_seconds)


def run_affordance_check(
    godot_bin: str,
    project_dir: Path,
    timeout_seconds: int = PROCESS_TIMEOUT_SECONDS,
) -> str | None:
    """Prove every hinged affordance opens (ADR-0008 correctness oracle): returns
    AFFORDANCE_OK / AFFORDANCE_FAIL <reason>, or None if it could not run. A
    composed door that exists but never swings fails HERE, not in front of a
    player."""
    return _run_script(
        godot_bin, project_dir, AFFORDANCE_SCRIPT, AFFORDANCE_PREFIX, timeout_seconds
    )
