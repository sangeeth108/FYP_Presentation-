extends SceneTree

## Walk-probe bot (Bots v1): drives the REAL player controller along the
## critical-path waypoints (bot_waypoints.json) by faking input actions —
## rotate to face the waypoint, hold move_forward, press interact at the
## door. State-reading, never vision. Prints WALKBOT_OK when the WinZone
## objective fires, or WALKBOT_STUCK with the blocking position.
## Run: godot --headless --path <project> --script res://walk_probe.gd

const ARRIVE_DISTANCE := 0.9  # tight: corner-cutting corridor elbows wedges fixed-cam runs
const STUCK_SECONDS := 6.0
const STUCK_EPSILON := 0.01
const TIMEOUT_SECONDS := 90.0

var _waypoints: Array = []
var _index := 0
var _player: CharacterBody3D
var _won := false
var _last_pos := Vector3.INF
var _stuck_timer := 0.0
var _elapsed := 0.0
var _interact_hold := 0.0


func _initialize() -> void:
	var scene := (load("res://main.tscn") as PackedScene).instantiate()
	root.add_child(scene)
	var file := FileAccess.open("res://bot_waypoints.json", FileAccess.READ)
	_waypoints = JSON.parse_string(file.get_as_text())
	Engine.time_scale = 5.0


func _process(delta: float) -> bool:
	_elapsed += delta
	if _player == null:
		_player = root.get_node_or_null("World/Player")
		var win_zone := root.get_node_or_null("World/WinZone")
		if win_zone != null:
			win_zone.objective_completed.connect(func(_id): _won = true)
		return false

	if _won:
		print("WALKBOT_OK waypoints=%d time=%.1fs" % [_waypoints.size(), _elapsed])
		_release_movement()
		quit(0)
		return true
	if _elapsed > TIMEOUT_SECONDS:
		print("WALKBOT_TIMEOUT wp=%d pos=%s" % [_index, _player.global_position])
		quit(1)
		return true
	if _index >= _waypoints.size():
		# All waypoints reached but no win signal: WinZone gating failed.
		print("WALKBOT_NO_WIN pos=%s" % _player.global_position)
		quit(1)
		return true

	var wp: Dictionary = _waypoints[_index]
	var is_interact: bool = wp.get("interact", false)
	var target := Vector3(wp["x"], _player.global_position.y, wp["z"])
	var to_target := target - _player.global_position
	to_target.y = 0.0

	if to_target.length() < (0.6 if is_interact else ARRIVE_DISTANCE):
		if is_interact:
			# Stop and hold the interact action so the door's physics-frame
			# polling reliably sees it (and the InteractZone contains us).
			_release_movement()
			Input.action_press("interact")
			_interact_hold += delta
			if _interact_hold < 0.5:
				return false
			_interact_hold = 0.0
		Input.action_release("interact")
		_index += 1
		return false
	Input.action_release("interact")

	if "mouse_sensitivity" in _player:
		# Third-person controller: movement is facing-relative.
		_player.rotation.y = atan2(-to_target.x, -to_target.z)
		Input.action_press("move_forward")
	else:
		# Fixed-camera controllers (top-down / isometric): movement is
		# world/camera-axis input — press directional actions instead.
		var yaw := 0.0
		if "camera_yaw_deg" in _player:
			yaw = deg_to_rad(_player.camera_yaw_deg)
		var fwd := Vector3(-sin(yaw), 0, -cos(yaw))
		var rgt := Vector3(cos(yaw), 0, -sin(yaw))
		var dir := to_target.normalized()
		_press_axis("move_right", "move_left", dir.dot(rgt))
		_press_axis("move_back", "move_forward", -dir.dot(fwd))

	if _player.global_position.distance_to(_last_pos) < STUCK_EPSILON * Engine.time_scale:
		_stuck_timer += delta
		if _stuck_timer > STUCK_SECONDS:
			print("WALKBOT_STUCK wp=%d target=(%s, %s) pos=%s" % [_index, wp["x"], wp["z"], _player.global_position])
			_print_blocker(to_target.normalized())
			quit(1)
			return true
	else:
		_stuck_timer = 0.0
	_last_pos = _player.global_position
	return false


func _release_movement() -> void:
	for action in ["move_forward", "move_back", "move_left", "move_right"]:
		Input.action_release(action)


func _press_axis(positive: String, negative: String, value: float) -> void:
	if value > 0.3:
		Input.action_press(positive)
		Input.action_release(negative)
	elif value < -0.3:
		Input.action_press(negative)
		Input.action_release(positive)
	else:
		Input.action_release(positive)
		Input.action_release(negative)


func _print_blocker(direction: Vector3) -> void:
	var space := _player.get_world_3d().direct_space_state
	for height in [0.2, 0.9, 1.6]:
		var origin := _player.global_position + Vector3(0, height, 0)
		var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * 2.0)
		query.exclude = [_player.get_rid()]
		var hit := space.intersect_ray(query)
		if hit:
			print("WALKBOT_BLOCKER h=%.1f -> %s at %s" % [height, hit["collider"].name, hit["position"]])
		else:
			print("WALKBOT_BLOCKER h=%.1f -> (clear)" % height)
