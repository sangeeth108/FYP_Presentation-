"""The real generation backend: brief -> SDXL image -> TRELLIS mesh -> GLB.

Implements the GenerationBackend protocol against the local GPU stack set up per
docs/ASSET_FARM_SETUP.md:

    1. SDXL (via a ComfyUI HTTP workflow) turns the brief text into a clean,
       single-object concept image on a plain background;
    2. TRELLIS (microsoft/TRELLIS-image-large, MIT) lifts that image to a 3D
       mesh + texture;
    3. Blender headless decimates to the tri budget and exports a web-ready GLB.

Every model here is license-verified for the product path (licensing_ledger.csv,
2026-07-14). This module pulls in heavy clients, so the registry imports it
lazily — a curated-only deployment never needs them installed.

SAFETY: this backend is bounded by the resolver's contract — it may raise on any
failure, and the resolver treats that as "generation failed" and ships the
curated asset. So a backend that is mid-tuning, a model that is missing, or a GPU
that is busy degrades to safe curated output and never breaks a game. That is why
this can land and be validated on the GPU box without risking the pipeline.
"""

from __future__ import annotations

import logging
import shlex
import subprocess
from pathlib import Path

from asset_farm.backends import GenerationResult
from asset_farm.brief import AssetBrief

log = logging.getLogger(__name__)


def _to_wsl_path(p: Path) -> str:
    """Windows path -> WSL mount path: D:\\asset-farm\\x.png -> /mnt/d/asset-farm/x.png.
    A path that is already POSIX (native-Linux box) is returned unchanged."""
    s = str(p)
    if len(s) >= 2 and s[1] == ":":  # drive-letter form
        drive = s[0].lower()
        rest = s[2:].replace("\\", "/").lstrip("/")
        return f"/mnt/{drive}/{rest}"
    return s.replace("\\", "/")

# The ledger components this backend uses. Declared as a tuple so the license
# guard can be run over ALL of them before a job trusts the backend.
COMPONENTS = ("sdxl", "trellis-2", "blender")
PRIMARY_COMPONENT = "trellis-2"  # the mesh generator — what the manifest attributes

# A prompt wrapper that steers SDXL toward a single, centered, plain-background
# object — the input TRELLIS reconstructs best. Deterministic string, no rng here.
SDXL_STYLE_SUFFIX = (
    ", single 3D game asset, centered, plain neutral background, soft studio "
    "lighting, full object visible, no shadows on ground, low-poly stylized"
)


class GpuAssetBackend:
    """Real SDXL -> TRELLIS -> Blender pipeline. Needs the GPU stack installed."""

    component = PRIMARY_COMPONENT

    def __init__(
        self,
        comfyui_base_url: str = "http://localhost:8188",
        blender_bin: str = "blender",
        timeout_seconds: float = 600.0,
        # TRELLIS runs in WSL2 (its CUDA submodules only build under Linux — see
        # ASSET_FARM_SETUP.md). On a native-Linux GPU box set trellis_wsl_distro=""
        # and TRELLIS is invoked directly.
        trellis_wsl_distro: str = "Ubuntu-24.04",
        trellis_dir: str = "/root/TRELLIS",
        trellis_env_bin: str = "/root/miniconda3/envs/trellis/bin",
        trellis_cuda_home: str = "/usr/local/cuda-12.8",
        # Per-game style prefix (spec meta.style_anchor) prepended to every SDXL
        # prompt so a game's generated assets share one art direction.
        style_anchor: str = "",
    ) -> None:
        self.comfyui_base_url = comfyui_base_url
        self.blender_bin = blender_bin
        self.timeout_seconds = timeout_seconds
        self.trellis_wsl_distro = trellis_wsl_distro
        self.trellis_dir = trellis_dir
        self.trellis_env_bin = trellis_env_bin  # the conda env's bin dir
        self.trellis_cuda_home = trellis_cuda_home
        self.style_anchor = style_anchor

    # The same rule `LocalGenBackend` enforces, and for the same reason: image-to-3D
    # produces a static shell with no skeleton. A generated dog is a statue.
    #
    # Measured the moment this backend was switched on
    # (run_8d4f6ab30b454210b313467b033f626d): the controlled actor came back
    # `rigged: false, animations: 0`, failed the mandatory
    # `asset_animation_compatibility` gate, and took the run with it -- where the local
    # backend had refused the brief and let the ladder fall through to the curated Husky
    # with its 24 clips. Enabling a BETTER mesh generator made the dog worse, because
    # nothing here said what it cannot do.
    _MESH_CATEGORIES = frozenset({"prop", "building_module", "foliage"})

    def generate(self, brief: AssetBrief, out_dir: Path) -> GenerationResult:
        if getattr(brief, "is_audio", False):
            raise GenerationBackendError("GpuAssetBackend makes meshes, not audio")
        if brief.category not in self._MESH_CATEGORIES:
            raise GenerationBackendError(
                f"GpuAssetBackend does not generate {brief.category!r} "
                "(rig-less mesh gen is for props/buildings/foliage only)"
            )
        out_dir.mkdir(parents=True, exist_ok=True)
        stem = brief.hash()

        image = self._sdxl_image(brief, out_dir / f"{stem}.png")
        raw_glb = self._trellis_mesh(image, out_dir / f"{stem}_raw.glb")
        final_glb = self._blender_finish(raw_glb, brief, out_dir / f"{stem}.glb")

        # QA (the resolver runs it next) re-measures independently; we don't
        # self-report a tri count we haven't verified.
        return GenerationResult(path=final_glb, component=self.component, tri_count=None)

    # --- stage 1: SDXL concept image via ComfyUI --------------------------
    def _sdxl_image(self, brief: AssetBrief, out_path: Path) -> Path:
        """POST an SDXL text2img workflow to ComfyUI, poll, download the PNG.

        This contract is VERIFIED against ComfyUI on the 5090 (2026-07-14): the
        exact workflow below generated a 1024x1024 image from a Content Designer
        brief. Submit -> poll /history -> download /view."""
        import httpx  # local import: only the gpu path needs it

        # style anchor (per game) + the brief (this asset) + the fixed 3D-asset
        # framing. The anchor first so it conditions the whole game consistently.
        prefix = f"{self.style_anchor}, " if self.style_anchor else ""
        prompt = prefix + brief.brief + SDXL_STYLE_SUFFIX
        try:
            with httpx.Client(base_url=self.comfyui_base_url, timeout=self.timeout_seconds) as c:
                resp = c.post("/prompt", json=_comfy_sdxl_workflow(prompt, seed=_seed(brief)))
                resp.raise_for_status()
                prompt_id = resp.json()["prompt_id"]
                image_bytes = _await_comfy_image(c, prompt_id, self.timeout_seconds)
        except Exception as exc:  # network/model/timeout -> generation failed
            raise GenerationBackendError(f"SDXL stage failed: {exc}") from exc
        out_path.write_bytes(image_bytes)
        return out_path

    # --- stage 2: TRELLIS image -> 3D (in WSL2) --------------------------
    def _trellis_mesh(self, image: Path, out_path: Path) -> Path:
        """Invoke trellis_cli.py inside the WSL2 `trellis` env. The image (from
        ComfyUI on Windows) and the output GLB are handed across via /mnt/... .

        This mirrors the sequence VERIFIED on the 5090 (2026-07-14): it produced a
        QA-passing GLB from the SDXL image."""
        cmd = self._trellis_command(image, out_path)
        self._run(cmd, "TRELLIS")
        if not out_path.is_file():
            raise GenerationBackendError("TRELLIS produced no mesh")
        return out_path

    def _trellis_command(self, image: Path, out_path: Path) -> list[str]:
        """Build the TRELLIS invocation. Split out so it is unit-testable without
        a GPU. WSL when trellis_wsl_distro is set, else a direct call."""
        img = _to_wsl_path(image)
        out = _to_wsl_path(out_path)
        # NOTE: bash -c, NOT -lc. A login shell sources /etc/profile, which under
        # WSL interop injects the Windows PATH — full of spaces ("3D simulation")
        # — and an unquoted `export PATH=...:$PATH` then splits on them and fails
        # (exit 2). Quote the PATH export for the same reason.
        #
        # Use the env's python by ABSOLUTE path and put its bin on PATH, instead
        # of `conda activate`: activation is unreliable in a non-interactive shell
        # (it left python off PATH -> "command not found"). CUDA bin is prepended
        # so nvcc is available for the runtime JIT compiles.
        py = f"{self.trellis_env_bin}/python"
        # Export the TRELLIS runtime env here too, not only in trellis_cli.py:
        # XFORMERS_DISABLED makes DINOv2 avoid the (nonexistent on Blackwell)
        # float32 xformers kernel. Setting it in the command means the backend is
        # correct even against an older deployed wrapper.
        inner = (
            f'export CUDA_HOME={self.trellis_cuda_home} && '
            f'export PATH="{self.trellis_cuda_home}/bin:{self.trellis_env_bin}:$PATH" && '
            f"export XFORMERS_DISABLED=1 ATTN_BACKEND=xformers SPCONV_ALGO=native && "
            f"cd {self.trellis_dir} && "
            f"{py} trellis_cli.py --image {shlex.quote(img)} --out {shlex.quote(out)}"
        )
        if self.trellis_wsl_distro:
            return ["wsl", "-d", self.trellis_wsl_distro, "-u", "root", "--", "bash", "-c", inner]
        return ["bash", "-c", inner]

    # --- stage 3: Blender decimate + GLB export ---------------------------
    def _blender_finish(self, raw_glb: Path, brief: AssetBrief, out_path: Path) -> Path:
        script = Path(__file__).with_name("blender_finish.py")
        cmd = [
            self.blender_bin, "--background", "--python", str(script), "--",
            "--in", str(raw_glb), "--out", str(out_path),
            "--tri-budget", str(brief.effective_tri_budget),
        ]
        self._run(cmd, "Blender")
        if not out_path.is_file():
            raise GenerationBackendError("Blender produced no GLB")
        return out_path

    def _run(self, cmd: list[str], stage: str) -> None:
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                # Explicit, because the default on Windows is cp1252 and every stage
                # here emits UTF-8: Blender writes a byte cp1252 has no mapping for and
                # `subprocess` raised UnicodeDecodeError from its reader thread, which
                # surfaces as a crash rather than as a failed stage. Measured on the
                # first real TRELLIS run: the GLB was produced and the call still blew
                # up decoding the log.
                encoding="utf-8",
                errors="replace",
                timeout=self.timeout_seconds,
                check=False
            )
        except (subprocess.TimeoutExpired, OSError) as exc:
            raise GenerationBackendError(f"{stage} could not run: {exc}") from exc
        if proc.returncode != 0:
            raise GenerationBackendError(f"{stage} exited {proc.returncode}: {proc.stderr[-400:]}")


class GenerationBackendError(RuntimeError):
    """A stage failed. The resolver catches this and ships the curated asset."""


def _seed(brief: AssetBrief) -> int:
    """A stable per-brief seed so the same brief regenerates the same image."""
    return int(brief.hash(), 16) % (2**31)


# --- ComfyUI contract (VERIFIED on the 5090, 2026-07-14) -------------------
SDXL_CHECKPOINT = "sd_xl_base_1.0.safetensors"
SDXL_NEGATIVE = "blurry, multiple objects, cluttered, text, watermark"


def _comfy_sdxl_workflow(prompt: str, seed: int) -> dict:
    """The API-format SDXL text2img graph, with the prompt + seed injected. This
    exact graph generated a real 1024x1024 image in the smoke test."""
    wf = {
        "4": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": SDXL_CHECKPOINT}},
        "5": {"class_type": "EmptyLatentImage",
              "inputs": {"width": 1024, "height": 1024, "batch_size": 1}},
        "6": {"class_type": "CLIPTextEncode", "inputs": {"text": prompt, "clip": ["4", 1]}},
        "7": {"class_type": "CLIPTextEncode", "inputs": {"text": SDXL_NEGATIVE, "clip": ["4", 1]}},
        "3": {"class_type": "KSampler", "inputs": {
            "seed": seed, "steps": 20, "cfg": 7.0, "sampler_name": "euler",
            "scheduler": "normal", "denoise": 1.0, "model": ["4", 0],
            "positive": ["6", 0], "negative": ["7", 0], "latent_image": ["5", 0]}},
        "8": {"class_type": "VAEDecode", "inputs": {"samples": ["3", 0], "vae": ["4", 2]}},
        "9": {"class_type": "SaveImage", "inputs": {"filename_prefix": "farm", "images": ["8", 0]}},
    }
    return {"prompt": wf}


def _await_comfy_image(client, prompt_id: str, timeout_seconds: float) -> bytes:
    """Poll /history/{id} until the SaveImage node reports an image, then download
    it from /view. Raises if the job never completes in time."""
    import time

    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        time.sleep(2.0)
        history = client.get(f"/history/{prompt_id}").json()
        entry = history.get(prompt_id)
        if not entry or not entry.get("outputs"):
            continue
        for out in entry["outputs"].values():
            if "images" in out and out["images"]:
                img = out["images"][0]
                params = {"filename": img["filename"], "type": img.get("type", "output")}
                if img.get("subfolder"):
                    params["subfolder"] = img["subfolder"]
                view = client.get("/view", params=params)
                view.raise_for_status()
                return view.content
    raise GenerationBackendError(f"ComfyUI did not finish prompt {prompt_id} in {timeout_seconds}s")
