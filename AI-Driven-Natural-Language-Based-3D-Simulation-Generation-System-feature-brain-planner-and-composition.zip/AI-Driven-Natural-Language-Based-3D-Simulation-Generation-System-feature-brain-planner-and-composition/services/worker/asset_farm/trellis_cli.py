"""TRELLIS image->3D CLI, run INSIDE the trellis conda env (WSL2).

    python trellis_cli.py --image in.png --out out.glb [--seed 7] [--simplify 0.95]

Deploy this file into the TRELLIS checkout on the GPU box (see
docs/ASSET_FARM_SETUP.md); GpuAssetBackend invokes it as its stage-2 mesh step.
Written against TRELLIS's own example.py API (verified structure, 2026-07-14):
image -> TrellisImageTo3DPipeline.run -> postprocessing_utils.to_glb -> export.

Attention backend is forced to **xformers**, not flash-attn — xformers ships as a
wheel, so this avoids compiling flash-attn (the slowest, most failure-prone
submodule) on Blackwell. SPCONV_ALGO=native skips first-run benchmarking.

Exits non-zero on any failure so the backend treats it as "generation failed"
and the resolver ships the curated asset — the whole chain stays bounded.
"""

from __future__ import annotations

import argparse
import os
import sys

# These MUST be set before importing trellis (they are read at import time).
os.environ.setdefault("ATTN_BACKEND", "xformers")
os.environ.setdefault("SPCONV_ALGO", "native")
# DINOv2 (TRELLIS's image conditioner) runs its attention in float32, and on
# Blackwell (sm_120) xformers has no float32 kernel — it errors "No operator
# found for memory_efficient_attention". XFORMERS_DISABLED makes DINOv2 fall back
# to torch-native attention, which handles float32 on any GPU. TRELLIS's own
# backbone still uses xformers (fp16) via ATTN_BACKEND. Verified: this produced a
# QA-passing GLB (17748 tris) on a 5090, 2026-07-14.
os.environ.setdefault("XFORMERS_DISABLED", "1")


def _patch_torch_hub() -> None:
    """Work around a torch.hub bug that breaks TRELLIS's DINOv2 conditioner load.

    TRELLIS loads DINOv2 via torch.hub.load('facebookresearch/dinov2', ...). On a
    box with no GITHUB_TOKEN, torch.hub._validate_not_a_forked_repo does
    `del headers["Authorization"]` unconditionally -> KeyError: 'Authorization'.
    The fork check is only a nicety; skipping it lets the (public) repo load.
    """
    import torch

    torch.hub._validate_not_a_forked_repo = lambda *a, **k: True


_patch_torch_hub()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--simplify", type=float, default=0.95)
    ap.add_argument("--texture-size", type=int, default=1024)
    ap.add_argument("--model", default="microsoft/TRELLIS-image-large")
    args = ap.parse_args()

    try:
        from PIL import Image
        from trellis.pipelines import TrellisImageTo3DPipeline
        from trellis.utils import postprocessing_utils
    except Exception as exc:  # noqa: BLE001 — any import failure means the env isn't ready
        sys.stderr.write(f"TRELLIS import failed: {exc}\n")
        return 3

    try:
        pipeline = TrellisImageTo3DPipeline.from_pretrained(args.model)
        pipeline.cuda()
        image = Image.open(args.image)
        outputs = pipeline.run(image, seed=args.seed)
        glb = postprocessing_utils.to_glb(
            outputs["gaussian"][0],
            outputs["mesh"][0],
            simplify=args.simplify,
            texture_size=args.texture_size,
        )
        glb.export(args.out)
    except Exception as exc:  # noqa: BLE001 — CUDA OOM, bad image, export failure, ...
        sys.stderr.write(f"TRELLIS inference failed: {exc}\n")
        return 4

    if not os.path.isfile(args.out):
        sys.stderr.write("TRELLIS produced no GLB\n")
        return 5
    sys.stdout.write(f"OK {args.out}\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
