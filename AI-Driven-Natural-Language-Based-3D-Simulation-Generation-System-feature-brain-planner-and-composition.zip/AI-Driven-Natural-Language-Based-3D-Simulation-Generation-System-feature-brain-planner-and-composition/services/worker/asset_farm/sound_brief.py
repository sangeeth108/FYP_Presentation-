"""What a character SOUNDS like, derived from WHO it is.

The planner decides the character ("a scruffy low-poly village dog"). What that
character sounds like *when it strikes, flinches, dies, or takes a step* is a
deterministic function of that identity plus the activity — no second LLM call,
no per-clip authoring, and reproducible from the spec alone (CLAUDE.md rule 15:
ambiguity up, determinism down; rule 14: seed everything).

This is the generate-tier twin of `asset_kit.SOUND_SETS`: that maps a curated
model family to curated clips, this maps a *described* character to briefs a
generator can build. Both answer the same question — what does this thing sound
like doing that? — and both hang off the same activities the vetted AI template
actually performs (ADR-0004).
"""

from __future__ import annotations

from asset_farm.brief import AssetBrief

# The activities the AI template performs. Kept in step with
# asset_kit.SOUND_SETS by a test, so adding an activity cannot silently leave
# either tier behind.
ACTIVITY_PHRASE: dict[str, str] = {
    "attack": "attacking: one short aggressive strike",
    "hit": "hurt: one short pained cry",
    "death": "dying: one short final cry",
    "step": "one single footstep",
}

# Production words matter to text-to-audio models: without them you get a music
# bed or a reverb-soaked cinematic hit, neither of which works as a game one-shot
# fired every few seconds from a positional 3D player.
_STYLE = "single one-shot sound effect, dry, close mic, mono, no music"

# The subject is clamped so the style directives cannot be truncated away by a
# long character description (AssetBrief caps a brief at 200 chars).
MAX_SUBJECT = 90


def activity_sound_brief(character_brief: str, activity: str) -> AssetBrief:
    """The audio brief for one activity of one character.

    Deterministic: the same character + activity always produces the same brief,
    hence the same brief_hash, hence a cache hit rather than a second generation.
    """
    if activity not in ACTIVITY_PHRASE:
        raise ValueError(
            f"unknown activity {activity!r}; known: {sorted(ACTIVITY_PHRASE)}"
        )
    subject = " ".join(character_brief.split())[:MAX_SUBJECT].strip(" ,.;:")
    if len(subject) < 3:
        raise ValueError("character brief is too short to describe a sound")
    text = f"{subject}, {ACTIVITY_PHRASE[activity]}. {_STYLE}"
    return AssetBrief(brief=text[:200], category="audio_sfx")


def activity_sound_briefs(character_brief: str) -> dict[str, AssetBrief]:
    """Every activity brief for one character: activity -> AssetBrief."""
    return {
        activity: activity_sound_brief(character_brief, activity)
        for activity in ACTIVITY_PHRASE
    }
