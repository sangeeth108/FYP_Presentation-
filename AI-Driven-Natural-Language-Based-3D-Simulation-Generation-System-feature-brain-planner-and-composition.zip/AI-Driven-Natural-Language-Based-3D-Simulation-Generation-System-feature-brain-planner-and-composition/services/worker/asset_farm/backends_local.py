"""In-process real generation backend: brief -> SDXL image -> TripoSR mesh -> GLB.

The counterpart to `backends_gpu.GpuAssetBackend`. That one offloads to ComfyUI +
a WSL2 TRELLIS install + Blender; this one runs the whole pipeline **in this
Python process** on the local CUDA GPU, with no compiler, no ComfyUI and no WSL:

    1. SDXL base (diffusers) turns the brief into one centered object on a plain
       background (OpenRAIL++-M, commercial-OK — NOT SDXL-Turbo, which is
       non-commercial);
    2. rembg (u2net) isolates the object;
    3. TripoSR (MIT, vendored under vendor/triposr) lifts it to a vertex-coloured
       mesh — its one custom CUDA op (marching cubes) is swapped for PyMCubes so
       nothing needs compiling;
    4. fast_simplification decimates to the brief's tri budget and the mesh is
       normalised (recentred, Y-up, unit-scaled) and exported as a web GLB.

Why this exists: TRELLIS's CUDA submodules will not build against this box's
toolchain (no MSVC, nvcc 12.9 vs torch cu13.0), so the WSL path is unavailable
here. This backend is the one that actually runs on the 5090 as installed.

SAFETY (same contract as every backend): any failure raises
`GenerationBackendError`, which the resolver treats as "generation failed" and
ships the curated asset. Heavy imports (torch, diffusers, tsr) are done lazily
inside the methods, so the module imports for tests and for curated-only
deployments without a GPU stack. Models load once per process (module singletons)
because a cold load is ~15 s and would otherwise repeat for every asset.

LICENCE (rule 12): components sdxl (OpenRAIL++-M), triposr (MIT), u2net (Apache
via rembg) — all product-path safe; see docs/licensing_ledger.csv. Generated
meshes are STATIC (no rig): correct for props/buildings/foliage, never for
characters (ADR-0005 aliveness — characters stay curated).
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

from asset_farm.backends import GenerationResult
from asset_farm.backends_gpu import GenerationBackendError
from asset_farm.brief import AssetBrief

log = logging.getLogger(__name__)

# Ledger components (rule 12). PRIMARY is what the manifest attributes the mesh to.
COMPONENTS = ("sdxl", "triposr", "u2net")
PRIMARY_COMPONENT = "triposr"

# Steers SDXL to a single, centered, plain-background object — the input TripoSR
# reconstructs cleanest. Appended after the per-game style anchor + the brief.
SDXL_SINGLE_OBJECT_SUFFIX = (
    ", ONE single isolated 3D simulation asset only, exactly one object, centered, "
    "plain flat neutral grey background, full object visible, soft even studio "
    "lighting, no ground shadow, stylized low-poly, no variants and no contact sheet"
)
SDXL_NEGATIVE = (
    "multiple objects, two objects, several items, collection, variations, lineup, "
    "asset sheet, contact sheet, comparison, split screen, grid, collage, scene, "
    "background clutter, text, watermark, realistic photo, blurry, cropped"
)
MAX_CONCEPT_ATTEMPTS = 3
MIN_FOREGROUND_COMPONENT_FRACTION = 0.008
_MODEL_ID_SDXL = "stabilityai/stable-diffusion-xl-base-1.0"
_MODEL_ID_TRIPOSR = "stabilityai/TripoSR"

# One art direction can't rig a character, so generation is mesh-only for these
# kinds; characters must resolve to a curated rigged body, never a statue.
_MESH_CATEGORIES = frozenset({"prop", "building_module", "foliage"})

# A generated body is normalised to this longest dimension (metres); the composite
# writer (project_writer.GENERATED_BODY_SIZE_M) scales it up to the object's bbox.
TARGET_SIZE_M = 1.5

# Cached, lazily-loaded singletons (a cold load is ~15 s).
_sdxl = None
_triposr = None
_rembg_session = None


def _seed(brief: AssetBrief) -> int:
    """Stable per-brief seed: the same brief regenerates the same asset (rule 14)."""
    return int(brief.hash(), 16) % (2**31)


def unload_models() -> bool:
    """Free SDXL + TripoSR from the GPU (the other half of plan->assets sequencing).

    The generators are process singletons that would otherwise stay resident for
    the worker's whole life (~9 GB), starving the NEXT job's LLM planning — which
    is exactly what makes the Content Designer time out and fall back to base
    content (a capsule, no character). Call this once the asset phase is done so
    the next job plans on a clean GPU. Returns True if anything was actually freed.
    """
    global _sdxl, _triposr, _rembg_session
    import gc  # noqa: PLC0415

    freed = _sdxl is not None or _triposr is not None
    _sdxl = None
    _triposr = None
    _rembg_session = None
    gc.collect()
    try:
        import torch  # noqa: PLC0415

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:  # noqa: BLE001 — torch may be absent (curated-only); harmless
        pass
    return freed


class LocalGenBackend:
    """Real, in-process SDXL -> TripoSR -> GLB pipeline on the local CUDA GPU."""

    component = PRIMARY_COMPONENT

    def __init__(
        self,
        device: str = "cuda",
        steps: int = 22,
        image_size: int = 768,
        mc_resolution: int = 256,
        style_anchor: str = "",
        concept_vision_base_url: str = "",
        concept_vision_model: str = "",
        concept_vision_timeout_seconds: float = 180.0,
        require_concept_vision: bool = True,
    ) -> None:
        self.device = device
        self.steps = steps
        self.image_size = image_size
        self.mc_resolution = mc_resolution
        # Per-game art direction (spec meta.style_anchor), prepended to every SDXL
        # prompt so a game's generated assets share one look. Set by the pipeline.
        self.style_anchor = style_anchor
        self.concept_vision_base_url = concept_vision_base_url
        self.concept_vision_model = concept_vision_model
        self.concept_vision_timeout_seconds = concept_vision_timeout_seconds
        self.require_concept_vision = require_concept_vision

    def generate(self, brief: AssetBrief, out_dir: Path) -> GenerationResult:
        if brief.is_audio:
            raise GenerationBackendError("LocalGenBackend makes meshes, not audio")
        if brief.category not in _MESH_CATEGORIES:
            # Characters (and anything else) must not ship as a rig-less statue.
            raise GenerationBackendError(
                f"LocalGenBackend does not generate {brief.category!r} "
                "(rig-less mesh gen is for props/buildings/foliage only)"
            )
        if self.require_concept_vision and not (
            self.concept_vision_base_url and self.concept_vision_model
        ):
            raise GenerationBackendError(
                "LocalGenBackend requires a configured asset concept vision validator"
            )
        out_dir.mkdir(parents=True, exist_ok=True)
        stem = brief.hash()
        try:
            last_subject_error: GenerationBackendError | None = None
            accepted_nobg_path: Path | None = None
            for attempt in range(MAX_CONCEPT_ATTEMPTS):
                image_path = self._sdxl_image(
                    brief, out_dir / f"{stem}_candidate_{attempt}.png", seed_offset=attempt
                )
                try:
                    candidate_nobg_path = self._remove_background(
                        image_path, out_dir / f"{stem}_candidate_{attempt}_nobg.png"
                    )
                    if self.require_concept_vision:
                        from asset_farm.concept_vision import validate_concept_image

                        validate_concept_image(
                            image_path=image_path,
                            asset_brief=brief.brief,
                            base_url=self.concept_vision_base_url,
                            model=self.concept_vision_model,
                            timeout_seconds=self.concept_vision_timeout_seconds,
                        )
                    accepted_nobg_path = candidate_nobg_path
                    break
                except GenerationBackendError as exc:
                    last_subject_error = exc
                    log.warning(
                        "rejecting concept attempt %d/%d for %s: %s",
                        attempt + 1,
                        MAX_CONCEPT_ATTEMPTS,
                        stem,
                        exc,
                    )
            if accepted_nobg_path is None:
                raise last_subject_error or GenerationBackendError(
                    "no valid single-subject concept was produced"
                )
            glb_path = self._image_to_mesh(
                accepted_nobg_path, brief, out_dir / f"{stem}.glb"
            )
        except GenerationBackendError:
            raise
        except Exception as exc:  # any model/CUDA/OOM error -> generation failed
            raise GenerationBackendError(f"local generation failed: {exc}") from exc
        # QA re-measures tris independently; we don't self-report an unverified count.
        return GenerationResult(path=glb_path, component=self.component, tri_count=None)

    # --- stage 1: SDXL text -> single-object image ------------------------
    def _sdxl_image(self, brief: AssetBrief, out_path: Path, seed_offset: int = 0) -> Path:
        import torch  # noqa: PLC0415

        pipe = _load_sdxl(self.device)
        prefix = f"{self.style_anchor}, " if self.style_anchor else ""
        prompt = prefix + brief.brief + SDXL_SINGLE_OBJECT_SUFFIX
        generator = torch.Generator(self.device).manual_seed(_seed(brief) + seed_offset)
        image = pipe(
            prompt=prompt,
            negative_prompt=_negative_prompt(brief.brief),
            num_inference_steps=self.steps,
            guidance_scale=6.0,
            height=self.image_size,
            width=self.image_size,
            generator=generator,
        ).images[0]
        image.save(out_path)
        return out_path

    # --- stage 2: background removal --------------------------------------
    def _remove_background(self, image_path: Path, out_path: Path) -> Path:
        import numpy as np  # noqa: PLC0415
        from PIL import Image  # noqa: PLC0415
        from rembg import remove  # noqa: PLC0415

        session = _load_rembg()
        src = Image.open(image_path).convert("RGB")
        cut = remove(src, session=session)  # RGBA, object isolated
        arr = np.asarray(cut).astype(np.float32) / 255.0
        alpha = arr[:, :, 3:4]
        component_count = _significant_foreground_components(alpha[:, :, 0])
        if component_count != 1:
            raise GenerationBackendError(
                "concept subject gate failed: expected exactly one significant "
                f"foreground component, found {component_count}"
            )
        # Composite on neutral grey — TripoSR expects the object on a plain field.
        composited = arr[:, :, :3] * alpha + 0.5 * (1.0 - alpha)
        Image.fromarray((composited * 255).astype("uint8")).save(out_path)
        return out_path

    # --- stage 3: TripoSR image -> mesh, decimate, normalise, export ------
    def _image_to_mesh(self, image_path: Path, brief: AssetBrief, out_path: Path) -> Path:
        import numpy as np  # noqa: PLC0415
        import torch  # noqa: PLC0415
        from PIL import Image  # noqa: PLC0415

        model = _load_triposr(self.device)
        image = Image.open(image_path).convert("RGB")
        with torch.no_grad():
            codes = model([image], device=self.device)
            meshes = model.extract_mesh(codes, has_vertex_color=True, resolution=self.mc_resolution)
        mesh = meshes[0]

        verts = np.asarray(mesh.vertices, dtype=np.float64)
        faces = np.asarray(mesh.faces, dtype=np.int64)
        colors = _vertex_colors(mesh)
        if len(faces) == 0:
            raise GenerationBackendError("TripoSR produced an empty mesh")

        verts, faces, colors = _decimate(verts, faces, colors, brief.effective_tri_budget)
        verts = _normalise_for_godot(verts)
        _export_glb(verts, faces, colors, out_path)
        if not out_path.is_file() or out_path.stat().st_size == 0:
            raise GenerationBackendError("mesh export wrote no file")
        return out_path


def _negative_constraints(brief_text: str) -> tuple[str, ...]:
    """Extract explicit ``no X``/``without X`` terms for the image negative prompt."""
    found: list[str] = []
    pattern = re.compile(
        r"\b(?:no|without)\s+([a-z0-9][a-z0-9_-]*"
        r"(?:\s+(?!(?:and|or|but|with|no|without)\b)[a-z0-9][a-z0-9_-]*){0,2})",
        re.IGNORECASE,
    )
    for match in pattern.finditer(brief_text):
        phrase = re.split(r"\s+(?:and|or|but|with)\b", match.group(1), maxsplit=1)[0]
        phrase = phrase.strip(" ,.;:")
        if phrase and phrase.lower() not in {item.lower() for item in found}:
            found.append(phrase)
    return tuple(found)


def _negative_prompt(brief_text: str) -> str:
    constraints = _negative_constraints(brief_text)
    return SDXL_NEGATIVE + ((", " + ", ".join(constraints)) if constraints else "")


def _significant_foreground_components(
    alpha, *, min_fraction: float = MIN_FOREGROUND_COMPONENT_FRACTION
) -> int:
    """Count sizeable 8-connected alpha components after background removal."""
    import numpy as np  # noqa: PLC0415

    mask = np.asarray(alpha) >= 0.5
    if mask.ndim != 2 or mask.size == 0:
        return 0
    minimum = max(64, int(mask.size * min_fraction))
    try:
        from scipy import ndimage  # noqa: PLC0415

        labels, count = ndimage.label(mask, structure=np.ones((3, 3), dtype=np.uint8))
        if count == 0:
            return 0
        sizes = np.bincount(labels.ravel())[1:]
        return int(np.count_nonzero(sizes >= minimum))
    except ImportError:
        # Slower fallback for lightweight deployments without scipy.
        remaining = mask.copy()
        height, width = remaining.shape
        significant = 0
        for y, x in zip(*np.nonzero(remaining), strict=False):
            if not remaining[y, x]:
                continue
            stack = [(int(y), int(x))]
            remaining[y, x] = False
            size = 0
            while stack:
                cy, cx = stack.pop()
                size += 1
                for ny in range(max(0, cy - 1), min(height, cy + 2)):
                    for nx in range(max(0, cx - 1), min(width, cx + 2)):
                        if remaining[ny, nx]:
                            remaining[ny, nx] = False
                            stack.append((ny, nx))
            if size >= minimum:
                significant += 1
        return significant


# --- lazy model loaders (module singletons) -------------------------------
def _load_sdxl(device: str):
    global _sdxl
    if _sdxl is None:
        import torch  # noqa: PLC0415
        from diffusers import StableDiffusionXLPipeline  # noqa: PLC0415

        log.info("loading SDXL base (one-time)...")
        _sdxl = StableDiffusionXLPipeline.from_pretrained(
            _MODEL_ID_SDXL, torch_dtype=torch.float16, variant="fp16", use_safetensors=True
        ).to(device)
    return _sdxl


def _load_triposr(device: str):
    global _triposr
    if _triposr is None:
        import sys  # noqa: PLC0415

        # TripoSR's config resolves its components by dotted path ("tsr.models...")
        # via importlib, so the vendored package must be importable as top-level
        # `tsr`. Alias it — then every `tsr.*` submodule resolves to the vendored,
        # PyMCubes-patched copy (MIT). Imported here so the module loads without
        # torch for tests / curated-only deployments.
        import asset_farm.vendor.triposr.tsr as _tsr_pkg  # noqa: PLC0415

        sys.modules.setdefault("tsr", _tsr_pkg)
        from asset_farm.vendor.triposr.tsr.system import TSR  # noqa: PLC0415

        log.info("loading TripoSR (one-time)...")
        model = TSR.from_pretrained(
            _MODEL_ID_TRIPOSR, config_name="config.yaml", weight_name="model.ckpt"
        )
        model.renderer.set_chunk_size(8192)
        model.to(device)
        _triposr = model
    return _triposr


def _load_rembg():
    global _rembg_session
    if _rembg_session is None:
        from rembg import new_session  # noqa: PLC0415

        _rembg_session = new_session("u2net")
    return _rembg_session


# --- mesh helpers ----------------------------------------------------------
def _vertex_colors(mesh):
    """(N,3) uint8 vertex colours if the mesh carries them, else None."""
    import numpy as np  # noqa: PLC0415

    visual = getattr(mesh, "visual", None)
    vc = getattr(visual, "vertex_colors", None)
    if vc is None or len(vc) != len(mesh.vertices):
        return None
    return np.asarray(vc, dtype=np.uint8)[:, :3]


def _decimate(verts, faces, colors, tri_budget: int):
    """Reduce to <= tri_budget triangles, carrying vertex colours by nearest
    ORIGINAL vertex (decimation drops per-vertex attributes).

    fast_simplification's target_reduction is approximate and routinely
    undershoots, so iterate — aim a little under budget and re-reduce whatever it
    leaves over — until the mesh actually fits or we run out of passes. QA counts
    triangles, so landing at/under budget is the contract, not a nicety.
    """
    import numpy as np  # noqa: PLC0415

    if len(faces) <= tri_budget:
        return verts, faces, colors
    import fast_simplification  # noqa: PLC0415

    orig_v, orig_c = verts, colors
    target = max(64, int(tri_budget * 0.92))  # aim under; leave headroom for slop
    cur_v = verts.astype(np.float32)
    cur_f = faces.astype(np.int32)
    for _ in range(6):
        reduction = max(0.05, min(0.98, 1.0 - target / float(len(cur_f))))
        cur_v, cur_f = fast_simplification.simplify(cur_v, cur_f, reduction)
        cur_v = np.asarray(cur_v, dtype=np.float32)
        cur_f = np.asarray(cur_f, dtype=np.int32)
        if len(cur_f) <= tri_budget:
            break

    new_v = cur_v.astype(np.float64)
    new_f = cur_f.astype(np.int64)
    new_colors = None
    if orig_c is not None and len(new_v):
        new_colors = _resample_colors(orig_v, orig_c, new_v)
    return new_v, new_f, new_colors


def _resample_colors(src_verts, src_colors, dst_verts):
    """Nearest-neighbour colour transfer from the original verts to decimated ones."""
    import numpy as np  # noqa: PLC0415

    try:
        from scipy.spatial import cKDTree  # noqa: PLC0415

        _, idx = cKDTree(src_verts).query(dst_verts, k=1)
        return src_colors[idx]
    except Exception:
        # No scipy: brute-force nearest in chunks (small meshes, fine).
        out = np.empty((len(dst_verts), 3), dtype=np.uint8)
        for i, p in enumerate(dst_verts):
            out[i] = src_colors[int(np.argmin(((src_verts - p) ** 2).sum(axis=1)))]
        return out


def _normalise_for_godot(verts):
    """Recentre on the ground, make Y up, and scale so the tallest dimension is
    ~1.5 m — a sane prop size in the same world as the kit models."""
    import numpy as np  # noqa: PLC0415

    # TripoSR is Z-up; Godot is Y-up. Rotate -90 deg about X: (x, y, z) -> (x, z, -y).
    v = np.column_stack([verts[:, 0], verts[:, 2], -verts[:, 1]]).astype(np.float64)
    lo, hi = v.min(axis=0), v.max(axis=0)
    extent = float((hi - lo).max()) or 1.0
    # Normalise to TARGET_SIZE_M longest; the composite writer
    # (GENERATED_BODY_SIZE_M) scales the body up to its object's bbox from here.
    scale = TARGET_SIZE_M / extent
    v *= scale
    lo, hi = v.min(axis=0), v.max(axis=0)
    # Centre in X/Z, sit the base on y=0.
    v[:, 0] -= (lo[0] + hi[0]) / 2.0
    v[:, 2] -= (lo[2] + hi[2]) / 2.0
    v[:, 1] -= lo[1]
    return v


def _export_glb(verts, faces, colors, out_path: Path) -> None:
    import trimesh  # noqa: PLC0415

    mesh = trimesh.Trimesh(vertices=verts, faces=faces, process=False)
    if colors is not None:
        mesh.visual = trimesh.visual.ColorVisuals(mesh=mesh, vertex_colors=colors)
    mesh.export(str(out_path))
