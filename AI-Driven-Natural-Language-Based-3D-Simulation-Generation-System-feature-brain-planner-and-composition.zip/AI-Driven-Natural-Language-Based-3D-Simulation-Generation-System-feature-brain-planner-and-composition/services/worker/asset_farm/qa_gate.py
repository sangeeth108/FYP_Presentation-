"""Asset QA gate (validation gate 3): is a produced asset fit to ship?

Deterministic checks on a candidate GLB — valid container, triangle count within
the brief's budget, a real (non-degenerate, not absurdly large) bounding box,
and a file size that respects the ≤90 MB web build. Emits machine-readable
error objects, never bare strings (§13), so the resolver can decide and the
lineage record can log exactly why an asset was rejected.

The gate re-measures the geometry itself rather than trusting the backend's
self-reported tri count — a backend that lies about its output must still fail.
"""

from __future__ import annotations

import json
import math
import struct
from dataclasses import asdict, dataclass, field
from pathlib import Path

from asset_farm.brief import AssetBrief

# A single web asset that alone blows a big chunk of the 90 MB budget is wrong
# regardless of tris (usually an un-compressed texture baked in).
MAX_ASSET_BYTES = 8_000_000
# Bounding box sanity: a game prop is meters-scale. Anything past this is a units
# bug (cm-vs-m is the classic) that would dwarf the level.
MAX_BBOX_EXTENT = 50.0


@dataclass(frozen=True)
class QAError:
    code: str
    path: str
    message: str
    hint: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class QAReport:
    passed: bool
    tri_count: int | None
    bbox_extent: float | None
    size_bytes: int
    errors: list[QAError]
    bbox_dimensions: tuple[float, float, float] | None = None
    bbox_min: tuple[float, float, float] | None = None
    bbox_max: tuple[float, float, float] | None = None
    bbox_center: tuple[float, float, float] | None = None
    measurement_method: str | None = None
    capabilities: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "passed": self.passed,
            "tri_count": self.tri_count,
            "bbox_extent": self.bbox_extent,
            "bbox_dimensions": (
                list(self.bbox_dimensions) if self.bbox_dimensions is not None else None
            ),
            "bbox_min": list(self.bbox_min) if self.bbox_min is not None else None,
            "bbox_max": list(self.bbox_max) if self.bbox_max is not None else None,
            "bbox_center": (
                list(self.bbox_center) if self.bbox_center is not None else None
            ),
            "measurement_method": self.measurement_method,
            "capabilities": self.capabilities,
            "size_bytes": self.size_bytes,
            "errors": [e.to_dict() for e in self.errors],
        }


def _read_glb(data: bytes) -> dict:
    """Parse a binary glTF into its JSON chunk. Raises ValueError on a bad container."""
    if len(data) < 12 or data[:4] != b"glTF":
        raise ValueError("not a GLB (missing glTF magic)")
    version = struct.unpack_from("<I", data, 4)[0]
    if version != 2:
        raise ValueError(f"unsupported glTF version {version}")
    offset = 12
    json_bytes = None
    while offset < len(data):
        chunk_len, chunk_type = struct.unpack_from("<I4s", data, offset)
        offset += 8
        chunk = data[offset : offset + chunk_len]
        offset += chunk_len
        if chunk_type == b"JSON":
            json_bytes = chunk
            break
    if json_bytes is None:
        raise ValueError("GLB has no JSON chunk")
    return json.loads(json_bytes)


def mesh_capabilities(path: Path) -> dict:
    """What a mesh can DO (not whether it passed QA): is it rigged, and does it
    carry animation clips? Deterministic introspection of the glTF JSON chunk.

    This is what separates a model that can BE a character from one that can only
    be scenery. An unreadable file reports no capability rather than raising —
    "unknown" must degrade to "cannot animate", which is the safe direction.
    """
    try:
        gltf = _read_glb(path.read_bytes())
    except Exception:
        return {"animations": 0, "skins": 0, "rigged": False, "animated": False}
    animations = len(gltf.get("animations", []))
    skins = len(gltf.get("skins", []))
    return {
        "animations": animations,
        "skins": skins,
        "rigged": skins > 0,
        # A character has to be BOTH skinned and carry clips to move like one:
        # clips without a skin can only shunt a rigid prop around.
        "animated": animations > 0 and skins > 0,
    }


def _triangle_count(gltf: dict) -> int:
    """Sum triangles across all mesh primitives (indexed and non-indexed)."""
    accessors = gltf.get("accessors", [])
    total = 0
    for mesh in gltf.get("meshes", []):
        for prim in mesh.get("primitives", []):
            mode = prim.get("mode", 4)  # 4 = TRIANGLES (glTF default)
            if mode != 4:
                continue  # v1 accepts triangle meshes only; strips/fans are rare here
            if "indices" in prim:
                count = accessors[prim["indices"]].get("count", 0)
            else:
                pos = prim.get("attributes", {}).get("POSITION")
                count = accessors[pos].get("count", 0) if pos is not None else 0
            total += count // 3
    return total


def _identity() -> list[list[float]]:
    return [
        [1.0, 0.0, 0.0, 0.0],
        [0.0, 1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0, 0.0],
        [0.0, 0.0, 0.0, 1.0],
    ]


def _matmul(left: list[list[float]], right: list[list[float]]) -> list[list[float]]:
    return [
        [
            sum(left[row][k] * right[k][column] for k in range(4))
            for column in range(4)
        ]
        for row in range(4)
    ]


def _node_matrix(node: dict) -> list[list[float]]:
    """glTF node matrix in row-major form, including TRS when no matrix is authored."""
    if "matrix" in node:
        raw = node["matrix"]
        if not isinstance(raw, list) or len(raw) != 16:
            raise ValueError("node matrix must contain 16 numbers")
        # glTF serializes matrices column-major.
        return [[float(raw[column * 4 + row]) for column in range(4)] for row in range(4)]
    translation = [float(value) for value in node.get("translation", [0.0, 0.0, 0.0])]
    scale = [float(value) for value in node.get("scale", [1.0, 1.0, 1.0])]
    rotation = [float(value) for value in node.get("rotation", [0.0, 0.0, 0.0, 1.0])]
    if len(translation) != 3 or len(scale) != 3 or len(rotation) != 4:
        raise ValueError("invalid node TRS vector")
    x, y, z, w = rotation
    norm = math.sqrt(x * x + y * y + z * z + w * w)
    if norm <= 1e-12:
        raise ValueError("node quaternion has zero length")
    x, y, z, w = (value / norm for value in (x, y, z, w))
    rotation_matrix = [
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w), 0.0],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w), 0.0],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y), 0.0],
        [0.0, 0.0, 0.0, 1.0],
    ]
    scale_matrix = _identity()
    for axis in range(3):
        scale_matrix[axis][axis] = scale[axis]
    translation_matrix = _identity()
    for axis in range(3):
        translation_matrix[axis][3] = translation[axis]
    return _matmul(translation_matrix, _matmul(rotation_matrix, scale_matrix))


def _transform_point(matrix: list[list[float]], point: tuple[float, float, float]) -> list[float]:
    vector = [point[0], point[1], point[2], 1.0]
    return [sum(matrix[row][column] * vector[column] for column in range(4)) for row in range(3)]


def _mesh_local_bounds(gltf: dict, mesh_index: int) -> tuple[list[float], list[float]] | None:
    accessors = gltf.get("accessors", [])
    meshes = gltf.get("meshes", [])
    if mesh_index < 0 or mesh_index >= len(meshes):
        raise ValueError(f"node references missing mesh {mesh_index}")
    lo = [float("inf")] * 3
    hi = [float("-inf")] * 3
    found = False
    for primitive in meshes[mesh_index].get("primitives", []):
        position_accessor = primitive.get("attributes", {}).get("POSITION")
        if position_accessor is None:
            continue
        if position_accessor < 0 or position_accessor >= len(accessors):
            raise ValueError(f"mesh references missing accessor {position_accessor}")
        accessor = accessors[position_accessor]
        minimum, maximum = accessor.get("min"), accessor.get("max")
        if not isinstance(minimum, list) or not isinstance(maximum, list):
            continue
        if len(minimum) != 3 or len(maximum) != 3:
            raise ValueError("POSITION bounds must have three components")
        found = True
        for axis in range(3):
            lo[axis] = min(lo[axis], float(minimum[axis]))
            hi[axis] = max(hi[axis], float(maximum[axis]))
    return (lo, hi) if found else None


def _scene_bounds(gltf: dict) -> tuple[list[float], list[float]] | None:
    """Measure the active glTF scene after node transforms, in imported metres."""
    nodes = gltf.get("nodes", [])
    scenes = gltf.get("scenes", [])
    global_lo = [float("inf")] * 3
    global_hi = [float("-inf")] * 3
    found = False

    if scenes:
        scene_index = int(gltf.get("scene", 0))
        if scene_index < 0 or scene_index >= len(scenes):
            raise ValueError(f"default scene {scene_index} does not exist")
        roots = scenes[scene_index].get("nodes", [])
    else:
        roots = list(range(len(nodes)))

    def visit(node_index: int, parent_matrix: list[list[float]], ancestry: set[int]) -> None:
        nonlocal found
        if node_index in ancestry:
            raise ValueError("node hierarchy contains a cycle")
        if node_index < 0 or node_index >= len(nodes):
            raise ValueError(f"scene references missing node {node_index}")
        node = nodes[node_index]
        world_matrix = _matmul(parent_matrix, _node_matrix(node))
        if "mesh" in node:
            bounds = _mesh_local_bounds(gltf, int(node["mesh"]))
            if bounds is not None:
                local_lo, local_hi = bounds
                for x in (local_lo[0], local_hi[0]):
                    for y in (local_lo[1], local_hi[1]):
                        for z in (local_lo[2], local_hi[2]):
                            point = _transform_point(world_matrix, (x, y, z))
                            for axis in range(3):
                                global_lo[axis] = min(global_lo[axis], point[axis])
                                global_hi[axis] = max(global_hi[axis], point[axis])
                found = True
        next_ancestry = {*ancestry, node_index}
        for child in node.get("children", []):
            visit(int(child), world_matrix, next_ancestry)

    if nodes:
        for root in roots:
            visit(int(root), _identity(), set())
    else:
        # Some exporters omit scenes/nodes. Their meshes still have measurable
        # local accessor bounds, so measure each once at identity.
        for mesh_index in range(len(gltf.get("meshes", []))):
            bounds = _mesh_local_bounds(gltf, mesh_index)
            if bounds is None:
                continue
            local_lo, local_hi = bounds
            for axis in range(3):
                global_lo[axis] = min(global_lo[axis], local_lo[axis])
                global_hi[axis] = max(global_hi[axis], local_hi[axis])
            found = True
    return (global_lo, global_hi) if found else None


def qa_mesh(path: Path, brief: AssetBrief) -> QAReport:
    """Judge a produced mesh asset against its brief. Never raises — a broken
    file is a FAIL with an error object, not an exception the caller must catch."""
    errors: list[QAError] = []
    size = path.stat().st_size if path.is_file() else 0

    if size == 0:
        errors.append(
            QAError(
                "ASSET_EMPTY",
                "$.file",
                "asset file is missing or empty",
                "generation produced nothing — fall back to curated",
            )
        )
        return QAReport(False, None, None, size, errors)

    if size > MAX_ASSET_BYTES:
        errors.append(
            QAError(
                "ASSET_TOO_LARGE",
                "$.file",
                f"{size} bytes exceeds the {MAX_ASSET_BYTES}-byte per-asset ceiling",
                "decimate the mesh or compress textures (KTX2/Basis)",
            )
        )

    try:
        gltf = _read_glb(path.read_bytes())
    except ValueError as exc:
        errors.append(
            QAError("ASSET_MALFORMED", "$.glb", str(exc), "not a valid GLB — fall back to curated")
        )
        return QAReport(False, None, None, size, errors)

    tris = _triangle_count(gltf)
    budget = brief.effective_tri_budget
    if tris == 0:
        errors.append(
            QAError(
                "ASSET_NO_GEOMETRY",
                "$.meshes",
                "no triangles in any mesh",
                "generation yielded an empty mesh",
            )
        )
    elif tris > budget:
        errors.append(
            QAError(
                "TRI_BUDGET_EXCEEDED",
                "$.meshes",
                f"{tris} triangles over the {budget} budget for a {brief.category}",
                "decimate to the budget, or raise tri_budget in the brief",
            )
        )

    try:
        bounds = _scene_bounds(gltf)
    except (TypeError, ValueError, IndexError) as exc:
        errors.append(
            QAError(
                "ASSET_BOUNDS_INVALID",
                "$.scenes",
                str(exc),
                "repair the scene hierarchy and export a valid glTF scene",
            )
        )
        bounds = None
    dimensions = (
        tuple(maximum - minimum for minimum, maximum in zip(*bounds, strict=True))
        if bounds is not None
        else None
    )
    bbox_min = tuple(bounds[0]) if bounds is not None else None
    bbox_max = tuple(bounds[1]) if bounds is not None else None
    bbox_center = (
        tuple((minimum + maximum) / 2.0 for minimum, maximum in zip(*bounds, strict=True))
        if bounds is not None
        else None
    )
    extent = max(dimensions) if dimensions is not None else None
    if extent is None or extent <= 1e-6:
        errors.append(
            QAError(
                "ASSET_BOUNDS_UNAVAILABLE",
                "$.accessors",
                "no non-degenerate POSITION bounds are available",
                "export POSITION accessor min/max values for every mesh",
            )
        )
    if extent is not None and extent > MAX_BBOX_EXTENT:
        errors.append(
            QAError(
                "BBOX_TOO_LARGE",
                "$.accessors",
                f"bounding box extent {extent:.1f} exceeds {MAX_BBOX_EXTENT} (units bug?)",
                "the mesh is likely in cm — rescale to meters",
            )
        )

    capabilities = {
        "animations": len(gltf.get("animations", [])),
        "skins": len(gltf.get("skins", [])),
        "rigged": len(gltf.get("skins", [])) > 0,
        "animated": bool(gltf.get("animations")) and bool(gltf.get("skins")),
    }
    return QAReport(
        not errors,
        tris,
        extent,
        size,
        errors,
        bbox_dimensions=dimensions,
        bbox_min=bbox_min,
        bbox_max=bbox_max,
        bbox_center=bbox_center,
        measurement_method="gltf_active_scene_aabb_v1",
        capabilities=capabilities,
    )
