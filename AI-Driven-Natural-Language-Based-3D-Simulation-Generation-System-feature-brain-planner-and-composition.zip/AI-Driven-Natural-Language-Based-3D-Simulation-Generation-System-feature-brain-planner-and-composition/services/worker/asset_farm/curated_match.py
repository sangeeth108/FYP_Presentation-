"""Curated tier (S5: "cache >= 0.92 -> **curated >= 0.85** -> generate").

The middle tier of the resolution tree, and the one that was missing. The cache
tier already asked "have we made this before?" semantically; the curated tier
must ask the same way — "do we ALREADY OWN something that is this?" — and until
now it did not ask at all. Enemy models were handed out by placement index, so a
planner could write "a hulking armoured brute" and "a nimble hooded scout" and
the game would assign whichever skeleton the rotation reached. The brief was
ignored for the one decision the player actually sees.

Matching before generating is not a fallback, it is the *cheap right answer*: a
curated model is instant, licence-clear, already rigged and already animated,
where a generated one costs GPU minutes and arrives as a statue (ADR-0005). So
the order matters — own it, then make it.

Never a hard dependency (the house rule): with no embedder, or an unreachable
one, this returns None and the caller keeps the deterministic default it uses
today. A missing embedder must cost variety, never a build.
"""

from __future__ import annotations

import logging
import math
import os
import re
from functools import lru_cache

from pathlib import Path

from asset_farm.semantic import cosine, embed

# Part of the cache key: vectors from a different embedder are not interchangeable.
EMBED_MODEL_TAG = "bge-m3"

log = logging.getLogger(__name__)

# MEASURED floors, per category. The old single 0.85 came from the pipeline spec
# document and was never measured against the model that has to clear it: across the
# planner's own briefs, recovered from artifacts/debug, the highest score ANY real
# brief achieved was 0.775 and the median was 0.59. The tier could not fire, and the
# report has been describing a tier that cannot fire.
#
# Calibrated on bge-m3 against this library, with positives phrased the way a subject
# reaches this function and negatives that the library plainly does not contain:
#
#   prop       positives 0.758-0.914   negatives 0.539-0.646   separable, gap +0.112
#   character  positives 0.651-0.806   negatives 0.516-0.657   overlap,   gap -0.006
#
# So props get 0.70, in the middle of a clean gap. Characters get 0.64, which admits
# every genuine positive and accepts ONE documented false positive: "a medieval knight
# in plate armour on horseback" scores 0.657 against Horse, which is not really wrong.
#
# The two differ because a rejection costs different things. A character that does not
# match falls back to a blue capsule or a blind index cycle, so a plausible body beats
# no body. A prop that does not match falls back to a procedural form with a planned
# palette, which is correct-looking, so only a confident match should override it.
#
# Both are far below the cache's 0.92, and that ordering is still right: reusing an
# asset we made for a near-identical brief needs more confidence than picking the
# closest of a handful of vetted models we own outright.
CURATED_FLOORS: dict[str, float] = {"character": 0.64, "prop": 0.70}
# Anything whose category is not calibrated. Deliberately the stricter of the two: an
# uncalibrated category has no evidence behind it, so it should need more convincing.
DEFAULT_CURATED_FLOOR = 0.70

# Above this the embedding is trusted on its own, without word agreement. It is the S5
# number (0.85), and it keeps its original meaning: "the library owns very nearly the
# exact thing asked for". What changed is that scores BELOW it are no longer refused
# outright -- they are admitted when the words agree, which is how a fox at 0.697 gets to
# be a fox while a cow at 0.65 does not get to be a squirrel.
CONFIDENT_SCORE = 0.85


def curated_floor(category: str | None) -> float:
    """The measured floor for a category, or the cautious default."""
    return CURATED_FLOORS.get(category or "", DEFAULT_CURATED_FLOOR)


# Where embedded descriptions are kept between runs. A vector is a pure function of
# its text and the model that embedded it, so it never needs computing twice.
_VECTOR_CACHE = (
    Path(__file__).resolve().parents[3] / "artifacts" / "asset_cache" / "library_vectors"
)


_DISK_CACHE_ENABLED = os.environ.get("PROMPTPLAY_VECTOR_CACHE", "1") != "0"

# The real embedder, captured at import. The disk cache is keyed on the TEXT, which is
# exactly right for production and wrong for a test that stubs `embed`: two tests embed
# the same description with different stub vectors, so the first one's answer would be
# served to the second. Measured -- `test_below_the_floor...` started returning
# `('characters/A.glb', 1.0)` because an earlier test had cached "an armoured warrior"
# under its own fixture.
#
# Disabling the cache outright was the obvious fix and the wrong one: the tests that use
# the REAL embedder then re-embed all 1,034 descriptions and the suite times out. So the
# cache is bypassed only when `embed` is no longer the function this module imported,
# which is precisely the case that is unsafe.
_REAL_EMBED = embed

# Below this, a cached "vector" is a stub or a truncated write, not an embedding.
_MIN_VECTOR_DIMENSIONS = 64


def _cached_embed(text: str, base_url: str) -> list[float] | None:
    """`embed`, but written through a small file keyed by the text.

    Measured: embedding the 895-model prop library took 307 s of one-at-a-time HTTP
    calls, on every fresh worker process. The `lru_cache` below still helps within a
    process; this is what makes the SECOND process cheap, and the worker is restarted
    often enough for that to be the case that matters.
    """
    import hashlib
    import json

    if not _DISK_CACHE_ENABLED or embed is not _REAL_EMBED:
        return embed(text, base_url)
    digest = hashlib.sha256(f"{EMBED_MODEL_TAG}:{text}".encode("utf-8")).hexdigest()
    path = _VECTOR_CACHE / digest[:2] / f"{digest}.json"
    if path.is_file():
        try:
            cached = json.loads(path.read_text(encoding="utf-8"))
            # A real bge-m3 vector is 1024-dimensional. Anything short is not one, and
            # the check is here because the cache was once poisoned by exactly that: a
            # test stubbed `embed` to return `[0.0, 1.0]`, those two numbers were written
            # under real description keys, and every later match against them scored
            # cosine 0.0 -- so "a dog" stopped resolving to the Husky the library owns.
            # Silent wrongness is the worst failure a cache can have, so it is cheap to
            # refuse anything that cannot be an embedding.
            if isinstance(cached, list) and len(cached) >= _MIN_VECTOR_DIMENSIONS:
                return cached
        except Exception:  # noqa: BLE001 - a corrupt entry is re-embedded, not fatal
            pass
    vector = embed(text, base_url)
    if vector is None:
        return None
    try:
        if len(vector) < _MIN_VECTOR_DIMENSIONS:
            return vector  # not an embedding; never persist it
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(vector), encoding="utf-8")
    except OSError:  # a read-only artifacts dir must not stop resolution
        pass
    return vector


@lru_cache(maxsize=8)
def _library_vectors(base_url: str, items: tuple[tuple[str, str], ...]) -> tuple | None:
    """Embed the library once per process, and once per MACHINE via the disk cache."""
    vectors = [_cached_embed(text, base_url) for _rel, text in items]
    if any(v is None for v in vectors):
        return None
    return tuple(vectors)


def _query_text(brief_text: str, subject: str | None) -> str:
    """What actually gets embedded: the subject when there is one.

    A brief is mostly plumbing. "an animated, rigged dog suitable as the controlled
    simulation agent" is nine words of pipeline boilerplate around one word of content,
    and the boilerplate dominates the vector: measured, that brief matched **Alpaca**
    at 0.566 while the bare subject "dog" matched Husky at 0.651. Two more real cases
    went the same way, a museum visitor matching Skeleton_Rogue on the brief and Man on
    the subject.

    The article is not decoration. Measured, a bare noun scores lower than the same
    noun in a phrase ("dog" 0.623, "a dog" 0.651) because the library's descriptions
    are phrases, so the query is shaped like them. Underscores become spaces for the
    same reason -- `museum_visitor` is not a word bge-m3 has seen.

    Falls back to the brief when there is no subject, which keeps every existing
    caller working and is still better than nothing.
    """
    cleaned = (subject or "").strip().replace("_", " ").strip()
    if cleaned:
        return f"a {cleaned}"
    return brief_text


def _subject_variants(subject: str | None) -> tuple[str, ...]:
    """The compound and its head noun, longest first.

    The floors were calibrated on bare nouns -- "dog" matches Husky at 0.651 -- and the
    planner writes compounds. Measured: `village_dog` scored nearer Cow than any dog in
    the library, and a village shipped with a cow as its controlled actor. English puts
    the head noun last, so the final word of a compound is the thing itself and the
    words before it are modifiers.

    Both are scored and the better wins, so a compound that genuinely matches something
    ("white horse") keeps its precision while one that does not falls back to its head.
    """
    cleaned = (subject or "").strip().replace("_", " ").split()
    if not cleaned:
        return ()
    variants = [" ".join(cleaned)]
    if len(cleaned) > 1:
        variants.append(cleaned[-1])
    return tuple(variants)


# Words that mean the same THING, so a match on either is a match on the kind. Kept to
# genuine identity synonyms -- a rock is a boulder, a stump is what a trunk leaves behind
# -- and deliberately not to loose association, which is the mistake this gate exists to
# stop.
_SAME_KIND: tuple[frozenset[str], ...] = (
    frozenset({"tree", "oak", "pine", "birch", "spruce", "fir", "cedar", "conifer", "sapling"}),
    frozenset({"rock", "rocks", "stone", "boulder", "scree", "pebble", "cliff"}),
    frozenset({"log", "trunk", "stump", "branch", "branches", "timber"}),
    frozenset({"bush", "shrub", "hedge", "thicket"}),
    frozenset({"grass", "tuft", "turf", "weed", "reed"}),
    frozenset({"flower", "bloom", "blossom", "tulip", "rose", "daisy", "sunflower"}),
    frozenset({"bird", "jay", "cardinal", "crow", "raven", "owl", "duck", "goose",
               "chicken", "hen", "sparrow", "robin", "finch"}),
    frozenset({"fox", "vulpine"}),
    frozenset({"deer", "stag", "doe", "fawn", "elk", "reindeer"}),
    frozenset({"dog", "hound", "puppy", "husky", "shiba", "canine", "wolf"}),
    frozenset({"cat", "kitten", "feline"}),
    frozenset({"person", "man", "woman", "human", "villager", "visitor", "student",
               "gardener", "farmer", "worker", "mechanic", "guard", "vendor"}),
    frozenset({"barrel", "keg", "cask"}),
    frozenset({"crate", "box", "chest"}),
    frozenset({"cart", "wagon", "trolley"}),
)


# Words that name no THING. They occur in every vocabulary and identify nothing, so a
# match on one is not a match on a kind. Measured: `ent_stump` declared its
# `semantic_type` as "observation_point" and was answered with `roof-point.glb` -- a roof
# point, for a hollowed tree stump -- because both phrases contain "point". The visual
# critic then failed the scene for having no recognisable observation point, correctly.
# WHERE a thing lives or is used. Habitat and setting words appear in briefs and in
# library descriptions alike and identify nothing: measured, `ent_bird` asked for
# "a small forest bird, brown and grey plumage" and was answered with Wolf.glb, described
# as "a grey wolf, a wild snarling predator of the forest, a dire beast" -- the two share
# the word "forest" and nothing else. A bird is not a wolf that lives nearby.
_CONTEXT = frozenset({
    "forest", "woodland", "woods", "jungle", "swamp", "marsh", "desert", "tundra",
    "mountain", "meadow", "field", "garden", "yard", "farm", "village", "town",
    "city", "urban", "rural", "indoor", "outdoor", "interior", "exterior",
    "wild", "domestic", "tame", "medieval", "modern", "ancient", "forestry",
    "warehouse", "kitchen", "garage", "classroom", "museum", "workshop",
})

_GENERIC = frozenset({
    "point", "unit", "area", "zone", "region", "section", "module", "piece", "part",
    "object", "item", "thing", "element", "feature", "spot", "place", "marker",
    "set", "group", "type", "kind", "model", "asset", "entity", "default", "generic",
    "detail", "detailed", "side", "end", "centre", "center", "half", "full",
})


def _kind_words(text: str) -> set[str]:
    """Identity words in a phrase, including its head whatever list that word is on.

    `_APPEARANCE` holds "stone", "wooden", "metal" -- materials, which describe a thing
    far more often than they are one. But English is head-final, so the LAST word is the
    thing: in "field stone" the stone is the object, and filtering it left only "field",
    which agrees with no rock in the library. Taking the head as identity keeps
    "field stone" ~ "a large rock" while still refusing "wooden barrel" ~ "wooden crate",
    where the shared word is the modifier and the heads disagree.
    """
    words = [
        w
        for w in re.split(r"[^a-zA-Z]+", text.lower())
        if len(w) > 2 and w not in _GENERIC and w not in _CONTEXT
    ]
    identity = {w for w in words if w not in _STOP and w not in _APPEARANCE}
    for word in reversed(words):
        if word not in _STOP:
            identity.add(word)  # the head names the thing
            break
    return identity


def names_the_same_kind(asked: str, offered: str) -> bool:
    """Do these two phrases name the same KIND of thing?

    The gate that no threshold can replace. Measured on one forest run, after the
    category fix let the library be searched properly:

        spc_canopy_tree -> tree_oak.glb    0.819   right
        red fox         -> Fox.glb         0.697   right
        ent_squirrel    -> Cow.glb         ~0.65   a cow
        ent_bird        -> Horse.glb       ~0.65   a horse
        spc_ferns       -> wall-side.glb   ~0.70   a wall, scattered as undergrowth

    A fox scores 0.697 and a cow-for-a-squirrel scores 0.65: nearly the same number,
    opposite correctness. Tuning the floor cannot separate them, which is why tuning it
    has failed repeatedly here -- raise it and the fox is lost, lower it and the horse
    stands in for a bird.

    What separates them is words. "red fox" and "Fox" share an identity word; "squirrel"
    and "Cow" share nothing at all. So the embedder proposes and this decides, which is
    rule 15 in one function: ambiguity up, determinism down.

    Rejecting is safe here BY DESIGN: the caller falls through to the rest of the S5
    ladder -- generation, then a procedural form -- so a refused match never leaves an
    entity with nothing. It only stops the library from answering a question it cannot.
    """
    asked_words, offered_words = _kind_words(asked), _kind_words(offered)
    if not asked_words or not offered_words:
        return False
    if asked_words & offered_words:
        return True
    # Singular/plural, which is not a difference in kind ("rocks" vs "rock").
    stems = {w.rstrip("s") for w in asked_words} & {w.rstrip("s") for w in offered_words}
    if stems:
        return True
    return any(
        (asked_words & family) and (offered_words & family) for family in _SAME_KIND
    )


def best_curated(
    brief_text: str,
    candidates: dict[str, str],
    embed_base_url: str | None,
    *,
    subject: str | None = None,
    category: str | None = None,
) -> tuple[str, float] | None:
    """The curated asset this brief describes: `(rel_path, score)` or None.

    `candidates` is {rel_path: description}. None means "the library does not
    contain this" (or there is no embedder) — the caller keeps its default.

    `subject` is the entity's own `semantic_type`, and is what gets embedded when
    supplied; see `_query_text`. `category` selects the measured floor.

    Deterministic tie-break: highest score, then lexicographic path, so the same
    brief always resolves to the same model no matter how the dict was ordered.
    """
    query_text = _query_text(brief_text, subject)
    if not embed_base_url or not candidates or not query_text:
        return None
    floor = curated_floor(category)

    items = tuple(sorted(candidates.items()))
    vectors = _library_vectors(embed_base_url, items)
    if vectors is None:
        log.debug("curated tier skipped — the library could not be embedded")
        return None

    # What the caller actually asked for, in words, for the agreement gate below.
    asked = f"{subject or ''} {brief_text}"

    def _best_for(text: str) -> tuple[str, float] | None:
        vector_query = embed(text, embed_base_url)
        if vector_query is None:
            return None
        found: tuple[str, float] | None = None
        for (rel, description), vector in zip(items, vectors, strict=True):
            score = cosine(vector_query, vector)
            if score < floor:
                continue
            # Two ways to be believed, because neither evidence is sufficient alone.
            #
            # A high score speaks for itself: "a spellcaster" matches "a robed mage" at
            # 1.0 and shares not one word with it, and a word list can never hold every
            # synonymy an embedder knows. Above `CONFIDENT_SCORE` the vector is trusted.
            #
            # Below it the words must agree, because that is exactly the band where a
            # score stops discriminating: `red fox` -> Fox is 0.697 and
            # `squirrel` -> Cow is ~0.65, nearly the same number and opposite answers.
            if score < CONFIDENT_SCORE and not names_the_same_kind(
                asked, f"{rel} {description}"
            ):
                continue
            if found is None or score > found[1]:
                found = (rel, score)
        return found

    # The HEAD NOUN decides, and the compound only fills in when the head finds nothing.
    #
    # Taking the better score across both phrasings was tried and is wrong: `village_dog`
    # scores 0.691 against Cow while its head noun scores 0.651 against Husky, so "best
    # score wins" ships a cow as a village dog -- a higher number for a worse answer.
    # English is head-final, so the last word of a compound IS the thing and the words
    # before it are modifiers; a modifier must not be able to outvote the noun.
    # CHARACTERS ONLY.
    #
    # The character library is nineteen species identified by what they are, so the head
    # noun is the answer: `village_dog` is a dog. The prop library is ten specific
    # objects where the modifier carries the identity -- measured, `track_lighting`
    # reduced to "lighting" matches a burning torch at 0.736, because "lighting" and
    # "light source" are close and a track light is not a torch. So props keep
    # whole-compound matching, where a modifier is information rather than noise.
    variants = _subject_variants(subject) if category == "character" else ()
    if variants:
        head = variants[-1]
        found = _best_for(f"a {head}")
        if found is not None:
            return found
        if len(variants) > 1:
            return _best_for(f"a {variants[0]}")
        return None
    return _best_for(query_text)


# --- embedder-free keyword tier ------------------------------------------
# The curated tier's job is "do we ALREADY OWN something that is this?" — and we
# must be able to answer it when bge-m3 is offline, because owning a rigged dog
# and shipping a blue capsule instead is the worst possible outcome. This is a
# deterministic lexical match: no model, no network, always available. Semantic
# is better when present (it understands "canine" == "dog"); this is the floor
# under it so a stated identity ALWAYS resolves to what we own.

# Words too common to identify a body. Kept short on purpose — real identity
# nouns (dog, wolf, wizard, knight) must survive.
_STOP = frozenset({
    "a", "an", "and", "the", "of", "or", "with", "in", "on", "at", "to", "as",
    "is", "are", "for", "its", "his", "her", "their", "they", "it", "this",
    "that", "these", "those", "small", "large", "big", "tall", "short", "old",
    "young", "little",
})

# How much of the brief's identity must be OWNED for a keyword match to count.
# Measured against only the brief tokens the library could possibly match, so
# activity noise ("explore the village") neither dilutes nor invents a match.
KEYWORD_FLOOR = 0.5

# Appearance words describe HOW a body looks, not WHAT it is. Left at full IDF
# weight, a rare colour hijacks the kind — "a brown dog" scores a brown HORSE
# over a dog, because "brown" is rarer here than "dog". Down-weighted, the kind
# noun dominates and colour only refines within it ("a white horse" -> WhiteHorse,
# not a brown one). This is the single rule that makes "as a dog" a dog.
_APPEARANCE = frozenset({
    "brown", "grey", "gray", "white", "black", "red", "blue", "green", "golden",
    "gold", "silver", "bronze", "dark", "pale", "light", "spotted", "striped",
    "scruffy", "fluffy", "woolly", "thick", "curled", "pointed", "shiny",
    "glowing", "wooden", "stone", "metal", "scaled", "furry", "hairy", "bushy",
})
_APPEARANCE_WEIGHT = 0.15


def _content_tokens(text: str) -> list[str]:
    """Lowercase content words, crudely singularised, stopwords dropped."""
    out: list[str] = []
    for w in re.findall(r"[a-z]+", text.lower()):
        if len(w) < 3 or w in _STOP:
            continue
        if w.endswith("es") and len(w) > 4:
            w = w[:-2]
        elif w.endswith("s") and len(w) > 3:
            w = w[:-1]
        out.append(w)
    return out


def keyword_best(
    brief_text: str, candidates: dict[str, str]
) -> tuple[str, float] | None:
    """The curated asset a brief describes, by lexical overlap — no embedder.

    Distinctive words count more (IDF over the candidate descriptions), so
    "dog" (rare) outweighs "brown" (common). The score is normalised by only the
    brief tokens that exist ANYWHERE in the library: a brief with no owned word
    scores 0 and returns None (we invent nothing), while "a dog exploring the
    village" is judged purely on "dog". Deterministic tie-break: score, then
    path, so the same brief always resolves to the same model.
    """
    if not brief_text or not candidates:
        return None

    items = sorted(candidates.items())
    doc_tokens = {rel: set(_content_tokens(text)) for rel, text in items}
    vocab: set[str] = set().union(*doc_tokens.values()) if doc_tokens else set()

    n = len(items)
    df: dict[str, int] = {}
    for tokens in doc_tokens.values():
        for tok in tokens:
            df[tok] = df.get(tok, 0) + 1
    idf = {tok: math.log((n + 1) / (count + 0.5)) for tok, count in df.items()}

    def weight(tok: str) -> float:
        w = idf.get(tok, 0.0)
        return w * _APPEARANCE_WEIGHT if tok in _APPEARANCE else w

    query = set(_content_tokens(brief_text))
    matchable = query & vocab
    denom = sum(weight(t) for t in matchable)
    if denom <= 0:  # nothing the brief asks for is a word we own
        return None

    best: tuple[str, float] | None = None
    for rel, _text in items:
        shared = query & doc_tokens[rel]
        # A shared APPEARANCE word alone is not an identity: "a marrow bone coated
        # in gold" must not become a gold CHEST on the word "gold". Require at
        # least one kind/noun token in common, or decline.
        if not (shared - _APPEARANCE):
            continue
        score = sum(weight(t) for t in shared) / denom
        if score >= KEYWORD_FLOOR and (best is None or score > best[1]):
            best = (rel, score)
    return best
