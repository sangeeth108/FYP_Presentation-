"""Content-addressed asset cache, keyed by brief_hash.

The same brief always hashes the same (see brief.py), so a prop authored
identically across two games resolves to ONE stored asset — the top tier of the
resolution tree (cache -> curated -> generate). Purely deterministic: the cache
path is a function of the hash, nothing else.

v1 is exact-match (brief_hash). The semantic cache the pipeline doc describes
(embedding similarity ≥0.92) is a later layer that would sit in front of this;
exact-match is the safe, reproducible floor and needs no embedder.
"""

from __future__ import annotations

import json
import shutil
from dataclasses import dataclass
from pathlib import Path

# A generated asset qualified before this profile must not bypass newer gates.
# Old files remain available for audit but are treated as cache misses.
CACHE_QA_PROFILE = "mesh-single-subject-vision-v4"


@dataclass(frozen=True)
class CacheEntry:
    path: Path
    component: str  # the licensed source that produced it
    tri_count: int | None


class AssetCache:
    def __init__(self, root: Path) -> None:
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)

    def _asset_path(self, brief_hash: str, suffix: str) -> Path:
        return self.root / f"{brief_hash}{suffix}"

    def _meta_path(self, brief_hash: str) -> Path:
        return self.root / f"{brief_hash}.json"

    def get(self, brief_hash: str) -> CacheEntry | None:
        meta = self._meta_path(brief_hash)
        if not meta.is_file():
            return None
        record = json.loads(meta.read_text(encoding="utf-8"))
        if record.get("qa_profile") != CACHE_QA_PROFILE:
            return None
        asset = self.root / record["filename"]
        if not asset.is_file():  # meta without its asset is a corrupt entry — miss
            return None
        return CacheEntry(
            path=asset, component=record["component"], tri_count=record.get("tri_count")
        )

    def put(
        self,
        brief_hash: str,
        source: Path,
        component: str,
        tri_count: int | None,
        embedding: list[float] | None = None,
    ) -> CacheEntry:
        dest = self._asset_path(brief_hash, source.suffix)
        if source.resolve() != dest.resolve():
            shutil.copy2(source, dest)
        record = {
            "filename": dest.name,
            "component": component,
            "tri_count": tri_count,
            "qa_profile": CACHE_QA_PROFILE,
        }
        if embedding is not None:  # enables the semantic tier for this entry
            record["embedding"] = embedding
        self._meta_path(brief_hash).write_text(json.dumps(record, indent=2), encoding="utf-8")
        return CacheEntry(path=dest, component=component, tri_count=tri_count)

    def nearest(
        self, query_embedding: list[float], floor: float
    ) -> tuple[CacheEntry, float] | None:
        """Best cached asset whose stored brief embedding is >= floor cosine to
        the query, or None. Scans meta files — the cache stays small because
        generation, not lookup, is the expensive step; an entry with no embedding
        (or a missing asset) is skipped.

        Deterministic tie-break: highest score, then lexicographic filename, so
        the same query always resolves to the same asset.
        """
        from asset_farm.semantic import cosine

        best: tuple[CacheEntry, float] | None = None
        for meta in sorted(self.root.glob("*.json")):
            record = json.loads(meta.read_text(encoding="utf-8"))
            if record.get("qa_profile") != CACHE_QA_PROFILE:
                continue
            emb = record.get("embedding")
            asset = self.root / record.get("filename", "")
            if not emb or not asset.is_file():
                continue
            score = cosine(query_embedding, emb)
            if score >= floor and (best is None or score > best[1]):
                best = (
                    CacheEntry(
                        path=asset,
                        component=record["component"],
                        tri_count=record.get("tri_count"),
                    ),
                    score,
                )
        return best
