"""Backend selection — turn config into a GenerationBackend (or None).

The pipeline calls `select_backend(settings)` instead of hardcoding one, so
enabling real generation is a config flip, not a code change. Disabled -> None ->
the resolver ships curated exactly as today. This is the one place that decides
whether a job generates, and it is deterministic and testable.
"""

from __future__ import annotations

from asset_farm.backends import GenerationBackend, MockAudioBackend, MockBackend


class _Cfg:
    """Duck-typed view of the fields select_backend reads — so it can be tested
    without importing the brain's Settings."""

    asset_gen_enabled: bool
    asset_gen_backend: str
    hunyuan3d_checkpoint_dir: str
    hunyuan3d_package_dir: str
    comfyui_base_url: str
    audio_gen_enabled: bool
    audio_gen_backend: str
    vision_enabled: bool
    vision_base_url: str
    vision_model: str
    vision_timeout_seconds: float


def select_backend(cfg: _Cfg) -> GenerationBackend | None:
    """The configured backend, or None when generation is off / unknown.

    Unknown backend name -> None (curated), never a crash: a typo in config must
    not take a job down, it just means no generation.
    """
    if not getattr(cfg, "asset_gen_enabled", False):
        return None

    name = getattr(cfg, "asset_gen_backend", "mock")
    if name == "mock":
        return MockBackend()
    if name == "local":
        # In-process SDXL -> TripoSR -> GLB on the local CUDA GPU. Imported lazily:
        # it pulls in torch/diffusers/tsr that a curated-only deploy never installs.
        from asset_farm.backends_local import LocalGenBackend

        return LocalGenBackend(
            concept_vision_base_url=getattr(cfg, "vision_base_url", ""),
            concept_vision_model=(
                getattr(cfg, "vision_model", "")
                if getattr(cfg, "vision_enabled", False)
                else ""
            ),
            concept_vision_timeout_seconds=getattr(cfg, "vision_timeout_seconds", 180.0),
            require_concept_vision=True,
        )
    if name == "hunyuan":
        # SDXL concept -> Hunyuan3D-2.1 shape -> GLB, in-process on the local GPU.
        # Lazily imported: it pulls in torch and the shape package that a
        # curated-only deployment never installs.
        from asset_farm.backends_hunyuan import Hunyuan3DBackend

        return Hunyuan3DBackend(
            checkpoint_dir=getattr(cfg, "hunyuan3d_checkpoint_dir", ""),
            package_dir=getattr(cfg, "hunyuan3d_package_dir", ""),
            concept_vision_base_url=getattr(cfg, "vision_base_url", ""),
            concept_vision_model=(
                getattr(cfg, "vision_model", "")
                if getattr(cfg, "vision_enabled", False)
                else ""
            ),
            concept_vision_timeout_seconds=getattr(cfg, "vision_timeout_seconds", 180.0),
            require_concept_vision=False,
        )
    if name == "gpu":
        # Imported lazily: the GPU backend pulls in heavy clients that a
        # curated-only deployment must never need to install.
        from asset_farm.backends_gpu import GpuAssetBackend

        kwargs: dict = {"comfyui_base_url": getattr(cfg, "comfyui_base_url", "")}
        blender = getattr(cfg, "blender_bin", "")
        if blender:  # Blender may not be on the subprocess PATH — take the config path
            kwargs["blender_bin"] = blender
        return GpuAssetBackend(**kwargs)
    return None


def select_audio_backend(cfg: _Cfg) -> GenerationBackend | None:
    """The configured SOUND generator, or None when audio generation is off.

    Separate from select_backend on purpose: Stable Audio and TRELLIS are
    different models that cannot be co-resident in 32 GB (CLAUDE.md §4), so the
    two are enabled, sequenced and failed independently. None -> the curated
    sound sets ship, exactly as they do today.
    """
    if not getattr(cfg, "audio_gen_enabled", False):
        return None

    name = getattr(cfg, "audio_gen_backend", "mock")
    if name == "mock":
        return MockAudioBackend()
    if name == "gpu":
        from asset_farm.backends_audio import StableAudioBackend

        return StableAudioBackend(base_url=getattr(cfg, "comfyui_base_url", ""))
    return None
