"""Asset farm (S5): resolve every asset_brief to a concrete file.

The decision tree is deterministic — cache -> curated -> generate -> QA ->
curated fallback — and the only AI step (generation) sits behind a pluggable
backend, exactly as the LLM sits behind a mockable gateway in the brain. So the
whole spine is testable without a GPU, and the real SDXL -> TRELLIS.2 -> Blender
farm plugs into a proven target later.

"Ambiguity up / determinism down": the brief says WHAT the asset should be; this
seeded, testable code decides WHERE it comes from and whether it is fit to ship.
The build NEVER blocks on generation — a curated asset is always the floor.
"""
