"""bge-m3 embeddings for the semantic cache tier (asset resolution).

TRELLIS generation costs minutes per asset, so reusing a cached asset for a
*similar* brief — not just an identical one — is a real saving. The pipeline
spec's top tier is "cache >= 0.92" (embedding cosine); this provides the embed +
cosine used to find that match.

Same contract as the brain's RAG embedder: bge-m3 via Ollama, and it degrades to
None on ANY failure so the resolver falls back to exact-match/generate — the
semantic tier is never a hard dependency (a dead embedder must not stop the farm).
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

if TYPE_CHECKING:  # httpx is imported inside embed(), not at module scope
    import httpx

EMBED_MODEL = "bge-m3"
EMBED_TIMEOUT = 20.0
# Cosine floor for reusing a cached asset. High on purpose: a prop must be
# genuinely the same thing, not merely thematically near, or games would share
# meshes they shouldn't. Matches the pipeline doc's 0.92.
SIMILARITY_FLOOR = 0.92


def embed(
    text: str, base_url: str, transport: httpx.BaseTransport | None = None
) -> list[float] | None:
    """One bge-m3 embedding via Ollama. None on any failure (caller falls back).

    httpx is imported HERE, not at module scope: the resolver imports this module
    just to read SIMILARITY_FLOOR, and a farm that only ships curated assets must
    not need an HTTP client to do it. Module-level, it made httpx a hard
    dependency of the whole asset farm — the exact opposite of what this module
    promises — and broke CI collection for every test that touches the resolver.
    """
    import httpx

    try:
        with httpx.Client(base_url=base_url, timeout=EMBED_TIMEOUT, transport=transport) as client:
            response = client.post(
                "/api/embed",
                json={"model": EMBED_MODEL, "input": [text], "keep_alive": "30m"},
            )
            response.raise_for_status()
            vectors = response.json()["embeddings"]
        return vectors[0] if vectors else None
    except Exception:
        return None


def cosine(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b, strict=True))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0
