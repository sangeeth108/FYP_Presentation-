"""License guard: no model enters the product path without a clean ledger row.

CLAUDE.md §12/§14 are non-negotiable — the product path is MIT / Apache /
OpenRAIL-commercial only, and FLUX.1[dev] (non-commercial) and Hunyuan3D-2.1
(UK/EU/Korea excluded) are quarantined to research-only. This is the code that
ENFORCES that: a generation backend must declare which ledger component it uses,
and this guard refuses to let its output ship unless that row says commercial_ok
= yes, product_path = product, and (for our territories) no exclusion applies.

A refusal is not a crash — the resolver catches it and falls back to a curated
asset, so an unlicensed backend degrades to safe output instead of shipping a
license violation. But it is LOUD: the refusal names the component and the reason.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

_LEDGER = Path(__file__).resolve().parents[3] / "docs" / "licensing_ledger.csv"

# Territories the product serves. A model excluded in ANY of these cannot be in
# the product path (matches the Hunyuan3D-2.1 quarantine rationale).
SERVED_TERRITORIES = frozenset({"UK", "EU", "Korea"})


class LicenseError(RuntimeError):
    """A component may not enter the product path. Machine-readable."""

    def __init__(self, component: str, reason: str) -> None:
        super().__init__(f"license refusal for {component!r}: {reason}")
        self.component = component
        self.reason = reason


@dataclass(frozen=True)
class LedgerRow:
    component: str
    license: str
    commercial_ok: str  # "yes" | "no" | "conditional" — "conditional" ships under a threshold
    product_path: bool
    territory_restrictions: str
    verified_date: str

    @property
    def excluded_territories(self) -> frozenset[str]:
        raw = (self.territory_restrictions or "none").strip().lower()
        if raw in ("", "none"):
            return frozenset()
        # e.g. "UK/EU/Korea excluded" or "UK, EU, Korea"
        found = set()
        for terr in SERVED_TERRITORIES:
            if terr.lower() in raw:
                found.add(terr)
        return frozenset(found)


@lru_cache(maxsize=1)
def _ledger(path: str | None = None) -> dict[str, LedgerRow]:
    ledger_path = Path(path) if path else _LEDGER
    rows: dict[str, LedgerRow] = {}
    with ledger_path.open(encoding="utf-8", newline="") as f:
        for r in csv.DictReader(f):
            rows[r["component"]] = LedgerRow(
                component=r["component"],
                license=r["license"],
                commercial_ok=r["commercial_ok"].strip().lower(),
                product_path=r["product_path"].strip().lower() == "product",
                territory_restrictions=r.get("territory_restrictions", "none"),
                verified_date=r.get("verified_date", ""),
            )
    return rows


def assert_research_safe(component: str, ledger_path: str | None = None) -> LedgerRow:
    """Raise LicenseError unless `component` may be used for RESEARCH.

    A weaker bar than the product path, and deliberately so. The quarantine that
    keeps Hunyuan3D-2.1 out of a commercial product exists because its licence
    excludes commercial use in several territories; neither clause binds academic
    research, and applying the product rule to research work is a recorded
    mistake of this project (it excluded the best available geometry model for
    no reason).

    What is still enforced: the component must be in the ledger, and it must
    carry a verified date. An unrecorded or unverified model is refused on
    either path, because "we did not check" is not a licence.
    """
    rows = _ledger(ledger_path)
    row = rows.get(component)
    if row is None:
        raise LicenseError(component, "not in the licensing ledger -- verify before use (§12)")
    if not row.verified_date:
        raise LicenseError(
            component, "no verified_date -- re-verify the license against the source"
        )
    return row


def is_research_safe(component: str, ledger_path: str | None = None) -> bool:
    try:
        assert_research_safe(component, ledger_path)
        return True
    except LicenseError:
        return False


def assert_product_safe(component: str, ledger_path: str | None = None) -> LedgerRow:
    """Raise LicenseError unless `component` is cleared for the product path.

    Every reason a model can be barred, checked explicitly rather than trusted:
    absent from the ledger, non-commercial license, research-only quarantine, or
    an exclusion in a territory we serve.
    """
    rows = _ledger(ledger_path)
    row = rows.get(component)
    if row is None:
        raise LicenseError(component, "not in the licensing ledger — verify before use (§12)")
    # product_path is the authoritative human decision; commercial_ok == "no" is a
    # belt-and-suspenders check ("conditional" ships under a revenue threshold, e.g.
    # Stable Audio Open, and is legitimately product-path).
    if row.commercial_ok == "no":
        raise LicenseError(component, f"license {row.license!r} is not commercial")
    if not row.product_path:
        raise LicenseError(component, "quarantined to research-only, not the product path")
    excluded = row.excluded_territories
    if excluded:
        raise LicenseError(component, f"excluded in served territories {sorted(excluded)}")
    if not row.verified_date:
        raise LicenseError(component, "no verified_date — re-verify the license against the source")
    return row


def is_product_safe(component: str, ledger_path: str | None = None) -> bool:
    try:
        assert_product_safe(component, ledger_path)
        return True
    except LicenseError:
        return False
