"""Deterministic measured geometry for capability-critical semantic primitives."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from asset_farm.brief import AssetBrief
from asset_farm.qa_gate import qa_mesh
from asset_farm.surface_texture import NOISE_VERSION, apply_surface_texture

COMPONENT = "serendib-procedural-geometry"
# Forms, not things. A scatter species is procedural by default and every one of
# them was becoming a coloured box, so a rainforest rendered as a field of
# rectangles -- confirmed by looking at one in the engine.
#
# The obvious fix is a lookup from semantic_type to geometry, and it is the
# golden-game mistake again: any list of nouns is a ceiling, and "teak" would
# work while "dipterocarp" would not. So the planner names the FORM instead --
# it knows a teak is a trunk under a crown and a fern is ground cover -- and
# this module only knows how to build forms. Open vocabulary upstream,
# deterministic geometry downstream, which is rule 3.15 applied to meshes.
_SUPPORTED = frozenset(
    {
        "semantic_box",
        "building_shell",
        "hinged_door_leaf",
        "foliage_column",
        "ground_cover",
        "irregular_mass",
        "fallen_column",
        # Added because everything that was not a tree, a boulder, a log or a
        # building became a `semantic_box`: a museum of paintings and
        # sculptures came out as a room of correctly-sized coloured blocks.
        # Each of these is a SILHOUETTE class rather than an object name, so an
        # unfamiliar noun still lands on a shape that reads.
        "legged_platform",
        "slender_post",
        "flat_panel",
        "open_container",
        "machine_block",
        # A settlement needs shapes a museum does not. Measured on the village prompt:
        # twelve of twenty assets were procedural and nearly all `semantic_box`, so a
        # well, a cart, a haystack and a fence all rendered as the same grey cube.
        "conifer_tree",
        "bush_cluster",
        "fence_section",
        "round_well",
        "wheeled_cart",
        "barrel_round",
        "arch_gateway",
        "round_tower",
        "haystack_cone",
        "market_stall",
    }
)


def _hex_to_rgba(value: str) -> list[int] | None:
    """`#a4552f` -> [164, 85, 47, 255]. None for anything that is not one.

    The contract pattern already rejects malformed hex, but a spec can reach this
    module from a preserved artefact or a hand-written fixture, and a builder that
    raised here would fail a whole world over a colour.
    """
    if not isinstance(value, str) or len(value) != 7 or value[0] != "#":
        return None
    try:
        return [int(value[index : index + 2], 16) for index in (1, 3, 5)] + [255]
    except ValueError:
        return None


def _slot(palette: list[list[int]] | None, index: int, default: list[int]) -> list[int]:
    """The planner's colour for this piece of the form, or the form's own.

    Slots are the form's structural order -- trunk before crown, top before legs,
    walls before roof -- which is what the contract's description promises. Giving
    fewer colours than the form uses is legal and common: one colour on a tree
    repaints the trunk and leaves the crown its default green.
    """
    if not palette or index >= len(palette):
        return default
    return palette[index]


def _lighten(rgba: list[int], factor: float) -> list[int]:
    """A brighter relative of a colour, for a highlight that must follow its base.

    A door's plank highlight is not an independent choice -- it is the leaf colour
    catching light. Left as a constant, a repainted blue door kept orange planks.
    """
    return [min(255, int(channel * factor)) for channel in rgba[:3]] + [rgba[3]]


def _color(mesh, rgba: list[int]):
    import trimesh

    material = trimesh.visual.material.PBRMaterial(
        baseColorFactor=rgba,
        metallicFactor=0.0,
        roughnessFactor=0.88,
    )
    mesh.visual = trimesh.visual.TextureVisuals(material=material)
    return mesh


def _translated_box(trimesh, extents, translation, color):
    mesh = _color(trimesh.creation.box(extents=extents), color)
    mesh.apply_translation(translation)
    return mesh


def _semantic_box(trimesh, dimensions: list[float], palette=None):
    return [
        _color(
            trimesh.creation.box(extents=dimensions),
            _slot(palette, 0, [112, 88, 58, 255]),
        )
    ]


def _rng(dimensions: list[float], salt: str):
    """Seeded from the contract, so one species always yields the same mesh."""
    import random

    return random.Random(f"{salt}:{dimensions}")


def _fit_to_bbox(trimesh, pieces: list, dimensions: list[float]) -> list:
    """Scale and centre an assembly so its measured bounds ARE the declared ones.

    Getting each builder's arithmetic exactly right is possible and fragile --
    the first version put a tree's crowns 13.75 m deep for a species declared
    3 m across, and laid a log on its end. Measuring the assembly and fitting it
    is one correction that cannot drift, and it is what the rest of the system
    assumes: the descriptor normalises by declared-over-imported, and the
    instancer spaces by the result, so a mesh whose real proportions differ from
    its declared ones distorts spacing everywhere downstream.

    Rests the assembly on y = 0 so `scatter_field.gd` lifts it correctly.
    """
    combined = trimesh.util.concatenate([piece.copy() for piece in pieces])
    extents = combined.extents
    scale = [
        (float(dimensions[axis]) / float(extents[axis])) if extents[axis] > 1e-9 else 1.0
        for axis in range(3)
    ]
    centre = combined.bounds.mean(axis=0)
    fitted = []
    for piece in pieces:
        mesh = piece.copy()
        mesh.apply_translation(-centre)
        mesh.apply_scale(scale)
        fitted.append(mesh)
    return fitted


def _foliage_column(trimesh, dimensions: list[float], palette=None):
    """A trunk carrying a crown: tree, palm, mast, anything upright and topped.

    Built to fill the declared bbox exactly, so the descriptor measures what the
    planner asked for and the instancer spaces by a real canopy width rather
    than by a box corner.
    """
    width, height, depth = dimensions
    rng = _rng(dimensions, "foliage_column")
    spread = max(width, depth)

    # Trunk thickness follows HEIGHT as well as spread. Taking it from spread
    # alone gave a 12 m tree a 0.48 m trunk, which renders as a wire: a tall
    # tree is thick because it is tall, not because it is wide.
    # 0.022 of height was arithmetically defensible -- a 12 m tree really does
    # carry a ~0.5 m trunk -- and still read as a wire against a compact
    # crown at any distance a player sees it from. A stylised low-poly tree
    # needs a trunk that reads as structure, so this is deliberately heavier
    # than life.
    trunk_radius = max(0.04, spread * 0.075, height * 0.032)
    # The trunk runs up INTO the crown rather than stopping beneath it, so there
    # is no bare stick between the two.
    trunk_height = height * 0.62

    trunk = _color(
        trimesh.creation.cylinder(radius=trunk_radius, height=trunk_height, sections=6),
        _slot(palette, 0, [92, 68, 46, 255]),
    )
    # trimesh builds cylinders along Z. Without this the trunk is created lying
    # down, and because _fit_to_bbox corrects the ASSEMBLY's overall extent the
    # error survived measurement and only showed up as a forest of felled trees
    # in a rendered frame.
    trunk.apply_transform(trimesh.transformations.rotation_matrix(1.5707963, [1, 0, 0]))
    trunk.apply_translation([0.0, trunk_height / 2.0, 0.0])
    pieces = [trunk]

    # Two or three offset crowns read as foliage at distance for very few
    # triangles, which matters when the field holds thousands of instances.
    #
    # The stack is built to reach the declared height exactly. Previously the
    # assembly came out 8.59 m tall for a declared 12 m, so _fit_to_bbox
    # stretched Y alone by 1.4x: the trunk grew longer while its radius did not,
    # which is the second half of why it looked like a wire, and the crowns
    # turned into eggs. Consecutive crowns are also spaced to OVERLAP, because
    # spacing them by their radii left visible gaps between the spheres.
    crowns = 3 if height > 4.0 else 2
    radii = [max(0.05, spread / 2.0 * (1.0 - 0.18 * index)) for index in range(crowns)]
    squash = 0.85
    verticals = [radius * squash for radius in radii]

    offsets = [0.0]
    for index in range(1, crowns):
        offsets.append(
            offsets[-1] + (verticals[index - 1] + verticals[index]) * 0.62
        )
    # Seat the stack so its topmost point is the declared height.
    lift = height - (offsets[-1] + verticals[-1])

    for index, radius in enumerate(radii):
        crown = _color(
            trimesh.creation.icosphere(subdivisions=1, radius=radius),
            _slot(palette, 1, [58, 92, 52, 255]),
        )
        crown.apply_scale([1.0, squash, 1.0])
        crown.apply_translation(
            [
                rng.uniform(-0.06, 0.06) * spread,
                offsets[index] + lift,
                rng.uniform(-0.06, 0.06) * spread,
            ]
        )
        pieces.append(crown)
    return _fit_to_bbox(trimesh, pieces, dimensions)


def _ground_cover(trimesh, dimensions: list[float], palette=None):
    """Low radiating blades: fern, grass tussock, coral fan, litter clump."""
    width, height, depth = dimensions
    rng = _rng(dimensions, "ground_cover")
    spread = max(width, depth)
    pieces = []
    for index in range(5):
        angle = (index / 5.0) * 6.28318 + rng.uniform(-0.3, 0.3)
        blade = _color(
            trimesh.creation.box(
                extents=[max(0.01, spread * 0.16), height, max(0.01, spread * 0.42)]
            ),
            _slot(palette, 0, [66, 104, 54, 255]),
        )
        # Splayed outward from the centre so the clump reads as growth, not a stack.
        blade.apply_transform(
            trimesh.transformations.rotation_matrix(rng.uniform(0.15, 0.42), [1, 0, 0])
        )
        blade.apply_transform(trimesh.transformations.rotation_matrix(angle, [0, 1, 0]))
        blade.apply_translation([0.0, 0.0, 0.0])
        pieces.append(blade)
    return _fit_to_bbox(trimesh, pieces, dimensions)


def _irregular_mass(trimesh, dimensions: list[float], palette=None):
    """A lumpy solid: boulder, rubble, spoil heap, coral head, snow mound."""
    rng = _rng(dimensions, "irregular_mass")
    mesh = trimesh.creation.icosphere(subdivisions=1, radius=0.5)
    # Jitter every vertex so no two species share a silhouette, then fit the box.
    vertices = mesh.vertices.copy()
    for index in range(len(vertices)):
        vertices[index] *= 1.0 + rng.uniform(-0.22, 0.22)
    mesh.vertices = vertices
    return _fit_to_bbox(
        trimesh, [_color(mesh, _slot(palette, 0, [122, 118, 110, 255]))], dimensions
    )


def _fallen_column(trimesh, dimensions: list[float], palette=None):
    """Something long lying down: log, pipe, girder, fallen pillar."""
    width, height, depth = dimensions
    length = max(width, depth)
    radius = max(0.02, min(width, max(height, 0.05)) / 2.0)
    mesh = _color(
        trimesh.creation.cylinder(radius=radius, height=length, sections=7),
        _slot(palette, 0, [96, 74, 52, 255]),
    )
    # A cylinder is built along Z. Rotating about X puts its length on Y, which
    # stood the log on its end; about Y lays it along X where the width is.
    mesh.apply_transform(trimesh.transformations.rotation_matrix(1.5707963, [0, 1, 0]))
    return _fit_to_bbox(trimesh, [mesh], dimensions)


def _upright_cylinder(trimesh, radius: float, height: float, sections: int, colour):
    """A cylinder standing on Y.

    `trimesh.creation.cylinder` builds along Z, which lies a post on its side.
    Every upright form needs the same correction, so it lives here rather than
    being repeated and eventually got wrong in one of them.
    """
    mesh = _color(trimesh.creation.cylinder(radius=radius, height=height, sections=sections), colour)
    mesh.apply_transform(trimesh.transformations.rotation_matrix(1.5707963, [1, 0, 0]))
    return mesh


def _legged_platform(trimesh, dimensions: list[float], palette=None):
    """A horizontal surface held up at its corners.

    Table, desk, bench, workbench, counter, market stall, bed, cot. This is the
    single most common shape a generated world needs and the one that most
    often fell through to a plain box: a box the size of a table reads as a
    crate, because what says "table" is the gap underneath.
    """
    width, height, depth = dimensions
    top_thickness = min(0.12, height * 0.18)
    leg = max(0.04, min(width, depth) * 0.09)
    inset = leg * 1.4
    top_colour = _slot(palette, 0, [138, 105, 70, 255])
    leg_colour = _slot(palette, 1, [92, 70, 48, 255])
    pieces = [
        _translated_box(
            trimesh,
            [width, top_thickness, depth],
            [0.0, height / 2.0 - top_thickness / 2.0, 0.0],
            top_colour,
        )
    ]
    leg_height = height - top_thickness
    for sx in (-1.0, 1.0):
        for sz in (-1.0, 1.0):
            pieces.append(
                _translated_box(
                    trimesh,
                    [leg, leg_height, leg],
                    [
                        sx * (width / 2.0 - inset),
                        -top_thickness / 2.0,
                        sz * (depth / 2.0 - inset),
                    ],
                    leg_colour,
                )
            )
    return _fit_to_bbox(trimesh, pieces, dimensions)


def _slender_post(trimesh, dimensions: list[float], palette=None):
    """A vertical shaft, usually carrying something at the top.

    Lamp post, sign post, bollard, column, pillar, mast, hydrant, totem. The
    head is sized from the declared footprint rather than fixed, so a fat
    column does not sprout a lamp and a thin lamp post is not capped by a slab.
    """
    width, height, depth = dimensions
    shaft_radius = max(0.03, min(width, depth) * 0.22)
    head_radius = max(shaft_radius, min(width, depth) * 0.5)
    head_height = min(height * 0.16, head_radius * 1.6)
    shaft_height = height - head_height
    pieces = [
        _upright_cylinder(
            trimesh, shaft_radius, shaft_height, 8, _slot(palette, 0, [110, 114, 120, 255])
        )
    ]
    pieces[0].apply_translation([0.0, -head_height / 2.0, 0.0])
    # Only crown it when the footprint is genuinely wider than the shaft.
    # Otherwise the form IS the shaft (a bollard, a plain column).
    if head_radius > shaft_radius * 1.35:
        head = _upright_cylinder(
            trimesh, head_radius, head_height, 8, _slot(palette, 1, [214, 208, 186, 255])
        )
        head.apply_translation([0.0, height / 2.0 - head_height / 2.0, 0.0])
        pieces.append(head)
    return _fit_to_bbox(trimesh, pieces, dimensions)


def _flat_panel(trimesh, dimensions: list[float], palette=None):
    """An upright rectangle with a raised border.

    Painting, screen, notice board, sign, window, banner, solar panel. A museum
    of these was a museum of boxes; the frame is what makes it read as a face
    meant to be looked at rather than a slab.
    """
    width, height, depth = dimensions
    thickness = max(0.02, min(depth, min(width, height) * 0.08))
    border = max(0.03, min(width, height) * 0.07)
    # The face is what the form exists to show, so it takes the first slot.
    face_colour = _slot(palette, 0, [226, 222, 212, 255])
    frame_colour = _slot(palette, 1, [92, 70, 48, 255])
    pieces = [
        # The face sits slightly proud of the frame's back so the two do not
        # share a plane; coplanar faces z-fight and read as flicker.
        _translated_box(
            trimesh,
            [max(0.01, width - border * 2.0), max(0.01, height - border * 2.0), thickness * 0.6],
            [0.0, 0.0, thickness * 0.15],
            face_colour,
        ),
        _translated_box(trimesh, [width, border, thickness], [0.0, height / 2.0 - border / 2.0, 0.0], frame_colour),
        _translated_box(trimesh, [width, border, thickness], [0.0, -height / 2.0 + border / 2.0, 0.0], frame_colour),
        _translated_box(trimesh, [border, height, thickness], [-width / 2.0 + border / 2.0, 0.0, 0.0], frame_colour),
        _translated_box(trimesh, [border, height, thickness], [width / 2.0 - border / 2.0, 0.0, 0.0], frame_colour),
    ]
    return _fit_to_bbox(trimesh, pieces, dimensions)


def _open_container(trimesh, dimensions: list[float], palette=None):
    """Walls around a void, open at the top.

    Barrel, crate, bin, drum, planter, trough, tank, basket. Modelled as walls
    rather than a solid because the opening is the whole point: a closed box of
    the same size is a crate lid, and a warehouse of those reads as a stack of
    blocks.
    """
    width, height, depth = dimensions
    wall = max(0.03, min(width, depth) * 0.08)
    body = _slot(palette, 0, [124, 100, 68, 255])
    rim = _slot(palette, 1, [96, 76, 52, 255])
    floor_thickness = max(0.03, height * 0.08)
    pieces = [
        _translated_box(
            trimesh, [width, floor_thickness, depth],
            [0.0, -height / 2.0 + floor_thickness / 2.0, 0.0], rim,
        ),
        _translated_box(trimesh, [width, height, wall], [0.0, 0.0, depth / 2.0 - wall / 2.0], body),
        _translated_box(trimesh, [width, height, wall], [0.0, 0.0, -depth / 2.0 + wall / 2.0], body),
        _translated_box(trimesh, [wall, height, depth], [width / 2.0 - wall / 2.0, 0.0, 0.0], body),
        _translated_box(trimesh, [wall, height, depth], [-width / 2.0 + wall / 2.0, 0.0, 0.0], body),
    ]
    return _fit_to_bbox(trimesh, pieces, dimensions)


def _machine_block(trimesh, dimensions: list[float], palette=None):
    """A body with a smaller mass offset on top.

    Appliance, console, cabinet, generator, kiosk, terminal, industrial
    machine. The offset detail is what distinguishes a machine from a crate at
    a glance, and it is deliberately asymmetric: a centred cap reads as a
    plinth, an offset one reads as apparatus.
    """
    width, height, depth = dimensions
    rng = _rng(dimensions, "machine_block")
    body_height = height * rng.uniform(0.66, 0.78)
    head_height = height - body_height
    head_w = width * rng.uniform(0.4, 0.62)
    head_d = depth * rng.uniform(0.45, 0.7)
    offset_x = (width - head_w) * 0.5 * rng.uniform(-0.7, 0.7)
    offset_z = (depth - head_d) * 0.5 * rng.uniform(-0.7, 0.7)
    pieces = [
        _translated_box(
            trimesh, [width, body_height, depth],
            [0.0, -height / 2.0 + body_height / 2.0, 0.0],
            _slot(palette, 0, [138, 142, 148, 255]),
        ),
        _translated_box(
            trimesh, [head_w, head_height, head_d],
            [offset_x, height / 2.0 - head_height / 2.0, offset_z],
            _slot(palette, 1, [86, 92, 100, 255]),
        ),
    ]
    return _fit_to_bbox(trimesh, pieces, dimensions)


# --- settlement forms -----------------------------------------------------
# Everything below reads at a distance by its OUTLINE. Nobody identifies a well by its
# masonry; they identify it by a low drum with a little roof over it. So each builder
# spends its geometry on the silhouette and almost none on detail.


def _conifer_tree(trimesh, dimensions, palette=None):
    """A trunk under stacked cones. Pine, fir, spruce, cypress.

    `foliage_column` is a broadleaf -- a trunk under one rounded crown -- and a conifer
    built as one is a lollipop. The stacked cones are the whole difference.
    """
    width, height, _ = dimensions
    trunk_colour = _slot(palette, 1, [86, 62, 42, 255])
    needle_colour = _slot(palette, 0, [46, 92, 54, 255])
    trunk = _upright_cylinder(
        trimesh, max(0.04, width * 0.09), height * 0.34, 8, trunk_colour
    )
    trunk.apply_translation([0.0, height * 0.17, 0.0])
    pieces = [trunk]
    tiers = 3
    for index in range(tiers):
        cone = _color(
            trimesh.creation.cone(
                radius=max(0.08, width * (0.52 - 0.13 * index)),
                height=height * 0.38,
                sections=10,
            ),
            _lighten(needle_colour, 1.0 + 0.08 * index),
        )
        cone.apply_transform(
            trimesh.transformations.rotation_matrix(-1.5707963, [1, 0, 0])
        )
        cone.apply_translation([0.0, height * (0.30 + 0.24 * (index / tiers)), 0.0])
        pieces.append(cone)
    return _fit_to_bbox(trimesh, pieces, dimensions)


def _bush_cluster(trimesh, dimensions, palette=None):
    """Several low masses huddled together. Hedge, shrub, bramble, boxwood.

    `ground_cover` radiates blades and reads as grass; a bush is volume.
    """
    width, height, depth = dimensions
    rng = _rng(dimensions, "bush_cluster")
    colour = _slot(palette, 0, [58, 96, 52, 255])
    pieces = []
    for _ in range(4):
        radius = max(0.06, min(width, depth) * rng.uniform(0.24, 0.36))
        blob = _color(
            trimesh.creation.icosphere(subdivisions=1, radius=radius),
            _lighten(colour, rng.uniform(0.86, 1.14)),
        )
        blob.apply_translation(
            [
                rng.uniform(-width * 0.26, width * 0.26),
                radius * 0.7,
                rng.uniform(-depth * 0.26, depth * 0.26),
            ]
        )
        pieces.append(blob)
    return _fit_to_bbox(trimesh, pieces, dimensions)


def _fence_section(trimesh, dimensions, palette=None):
    """Posts carrying horizontal rails, with the gaps left open.

    A fence built as a solid box is a wall. What says "fence" is seeing through it, so
    the rails are thin and the space between them is the point. Tiled along a run by
    `pcg.linear`.
    """
    width, height, depth = dimensions
    post_colour = _slot(palette, 1, [104, 78, 52, 255])
    rail_colour = _slot(palette, 0, [132, 104, 72, 255])
    thickness = max(0.03, depth * 0.5)
    post = max(0.05, width * 0.07)
    pieces = []
    for offset in (-width / 2.0 + post / 2.0, width / 2.0 - post / 2.0):
        pieces.append(
            _translated_box(
                trimesh,
                [post, height, max(post, thickness)],
                [offset, height / 2.0, 0.0],
                post_colour,
            )
        )
    for level in (0.38, 0.74):
        pieces.append(
            _translated_box(
                trimesh,
                [width, max(0.03, height * 0.11), thickness],
                [0.0, height * level, 0.0],
                rail_colour,
            )
        )
    return _fit_to_bbox(trimesh, pieces, dimensions)


def _round_well(trimesh, dimensions, palette=None):
    """A low drum with a little roof on two posts. The village landmark."""
    width, height, _ = dimensions
    stone = _slot(palette, 0, [128, 124, 118, 255])
    timber = _slot(palette, 1, [104, 78, 52, 255])
    drum_h = height * 0.34
    drum = _upright_cylinder(trimesh, width * 0.5, drum_h, 14, stone)
    drum.apply_translation([0.0, drum_h / 2.0, 0.0])
    pieces = [drum]
    for side in (-1.0, 1.0):
        pieces.append(
            _translated_box(
                trimesh,
                [width * 0.09, height * 0.46, width * 0.09],
                [side * width * 0.34, drum_h + height * 0.23, 0.0],
                timber,
            )
        )
    roof = _color(
        trimesh.creation.cone(radius=width * 0.62, height=height * 0.24, sections=12),
        timber,
    )
    roof.apply_transform(trimesh.transformations.rotation_matrix(-1.5707963, [1, 0, 0]))
    roof.apply_translation([0.0, drum_h + height * 0.46, 0.0])
    pieces.append(roof)
    return _fit_to_bbox(trimesh, pieces, dimensions)


def _wheeled_cart(trimesh, dimensions, palette=None):
    """A body slung between two wheels. Cart, barrow, wagon, trolley."""
    width, height, depth = dimensions
    body_colour = _slot(palette, 0, [126, 94, 60, 255])
    wheel_colour = _slot(palette, 1, [78, 58, 40, 255])
    radius = min(height * 0.4, depth * 0.45)
    pieces = [
        _translated_box(
            trimesh,
            [width * 0.92, height * 0.36, depth * 0.72],
            [0.0, radius + height * 0.2, 0.0],
            body_colour,
        )
    ]
    for side in (-1.0, 1.0):
        wheel = _color(
            trimesh.creation.cylinder(
                radius=radius, height=max(0.04, width * 0.08), sections=14
            ),
            wheel_colour,
        )
        wheel.apply_translation([side * width * 0.48, radius, 0.0])
        pieces.append(wheel)
    return _fit_to_bbox(trimesh, pieces, dimensions)


def _barrel_round(trimesh, dimensions, palette=None):
    """A drum with two hoops. Barrel, cask, keg, butt, water butt."""
    width, height, _ = dimensions
    wood = _slot(palette, 0, [122, 84, 50, 255])
    band = _slot(palette, 1, [72, 68, 64, 255])
    body = _upright_cylinder(trimesh, width * 0.46, height, 14, wood)
    body.apply_translation([0.0, height / 2.0, 0.0])
    pieces = [body]
    for level in (0.26, 0.74):
        hoop = _upright_cylinder(
            trimesh, width * 0.5, max(0.03, height * 0.07), 14, band
        )
        hoop.apply_translation([0.0, height * level, 0.0])
        pieces.append(hoop)
    return _fit_to_bbox(trimesh, pieces, dimensions)


def _arch_gateway(trimesh, dimensions, palette=None):
    """Two piers under a lintel, with the opening left open.

    An entrance you can walk through. Built solid it is a wall, which is what a
    `semantic_box` gate always became.
    """
    width, height, depth = dimensions
    stone = _slot(palette, 0, [134, 128, 120, 255])
    pier = max(0.12, width * 0.18)
    pieces = []
    for side in (-1.0, 1.0):
        pieces.append(
            _translated_box(
                trimesh,
                [pier, height * 0.84, depth],
                [side * (width / 2.0 - pier / 2.0), height * 0.42, 0.0],
                stone,
            )
        )
    pieces.append(
        _translated_box(
            trimesh,
            [width, height * 0.16, depth],
            [0.0, height * 0.92, 0.0],
            _lighten(stone, 1.08),
        )
    )
    return _fit_to_bbox(trimesh, pieces, dimensions)


def _round_tower(trimesh, dimensions, palette=None):
    """A drum under a conical cap. Tower, silo, turret, windmill body, dovecote."""
    width, height, _ = dimensions
    wall = _slot(palette, 0, [138, 132, 122, 255])
    roof_colour = _slot(palette, 1, [110, 66, 52, 255])
    shaft_h = height * 0.78
    shaft = _upright_cylinder(trimesh, width * 0.46, shaft_h, 14, wall)
    shaft.apply_translation([0.0, shaft_h / 2.0, 0.0])
    roof = _color(
        trimesh.creation.cone(radius=width * 0.56, height=height * 0.3, sections=14),
        roof_colour,
    )
    roof.apply_transform(trimesh.transformations.rotation_matrix(-1.5707963, [1, 0, 0]))
    roof.apply_translation([0.0, shaft_h, 0.0])
    return _fit_to_bbox(trimesh, [shaft, roof], dimensions)


def _haystack_cone(trimesh, dimensions, palette=None):
    """A heaped cone. Haystack, straw pile, sand heap, spoil heap, compost."""
    width, height, _ = dimensions
    straw = _slot(palette, 0, [186, 156, 84, 255])
    cone = _color(
        trimesh.creation.cone(radius=width * 0.5, height=height, sections=12), straw
    )
    cone.apply_transform(trimesh.transformations.rotation_matrix(-1.5707963, [1, 0, 0]))
    return _fit_to_bbox(trimesh, [cone], dimensions)


def _market_stall(trimesh, dimensions, palette=None):
    """A counter under a canopy on four posts. Stall, kiosk, awning, booth."""
    width, height, depth = dimensions
    timber = _slot(palette, 1, [116, 86, 56, 255])
    canvas = _slot(palette, 0, [176, 88, 72, 255])
    post = max(0.05, min(width, depth) * 0.07)
    pieces = [
        _translated_box(
            trimesh,
            [width * 0.94, max(0.06, height * 0.09), depth * 0.72],
            [0.0, height * 0.42, 0.0],
            timber,
        )
    ]
    for x_side in (-1.0, 1.0):
        for z_side in (-1.0, 1.0):
            pieces.append(
                _translated_box(
                    trimesh,
                    [post, height * 0.86, post],
                    [
                        x_side * (width / 2.0 - post),
                        height * 0.43,
                        z_side * (depth / 2.0 - post),
                    ],
                    timber,
                )
            )
    canopy = _color(
        trimesh.creation.box(extents=[width, max(0.05, height * 0.08), depth]), canvas
    )
    canopy.apply_translation([0.0, height * 0.9, 0.0])
    pieces.append(canopy)
    return _fit_to_bbox(trimesh, pieces, dimensions)


def _building_shell(trimesh, dimensions: list[float], palette=None):
    """Four measured walls, a doorway void, and a roof slab.

    This is a reusable parametric building primitive. The open doorway is real
    geometry so a separately simulated door can rotate without clipping through
    a fake painted door.
    """
    width, height, depth = dimensions
    thickness = min(0.3, width * 0.04, depth * 0.04)
    door_width = min(1.35, width * 0.28)
    roof_height = min(1.6, height * 0.3)
    wall_height = height - roof_height
    wall_center_y = -roof_height / 2.0
    door_height = min(2.35, wall_height * 0.72)
    wall = _slot(palette, 0, [190, 174, 145, 255])
    roof = _slot(palette, 1, [126, 58, 42, 255])
    pieces = [
        _translated_box(
            trimesh,
            [width, wall_height, thickness],
            [0.0, wall_center_y, depth / 2.0 - thickness / 2.0],
            wall,
        ),
        _translated_box(
            trimesh,
            [thickness, wall_height, depth],
            [-(width / 2.0 - thickness / 2.0), wall_center_y, 0.0],
            wall,
        ),
        _translated_box(
            trimesh,
            [thickness, wall_height, depth],
            [width / 2.0 - thickness / 2.0, wall_center_y, 0.0],
            wall,
        ),
    ]
    side_width = (width - door_width) / 2.0
    side_x = door_width / 2.0 + side_width / 2.0
    front_z = -(depth / 2.0 - thickness / 2.0)
    pieces.extend(
        [
            _translated_box(
                trimesh,
                [side_width, wall_height, thickness],
                [-side_x, wall_center_y, front_z],
                wall,
            ),
            _translated_box(
                trimesh,
                [side_width, wall_height, thickness],
                [side_x, wall_center_y, front_z],
                wall,
            ),
        ]
    )
    header_height = wall_height - door_height
    pieces.append(
        _translated_box(
            trimesh,
            [door_width, header_height, thickness],
            [0.0, -height / 2.0 + door_height + header_height / 2.0, front_z],
            wall,
        )
    )
    # Half a millimetre clear of the wall tops. See the note on the underside
    # faces below: coplanar with them, the roofline z-fights.
    eave_y = height / 2.0 - roof_height + 0.0005
    ridge_y = height / 2.0
    vertices = [
        [-width / 2.0, eave_y, -depth / 2.0],
        [width / 2.0, eave_y, -depth / 2.0],
        [0.0, ridge_y, -depth / 2.0],
        [-width / 2.0, eave_y, depth / 2.0],
        [width / 2.0, eave_y, depth / 2.0],
        [0.0, ridge_y, depth / 2.0],
    ]
    # Wound outward. Every one of these eight triangles faced INWARD, so the
    # whole roof prism was inside-out and back-face culling removed all of it
    # from any exterior view: a house showed black holes where the gables should
    # be, and what looked like a roof was the far slopes seen from within. It
    # survived because nothing measures winding -- the bounding box, the
    # triangle count and the watertight check are all identical either way, and
    # only a rendered frame shows it.
    #
    # The underside pair is kept and is the building's CEILING. Deleting it
    # looked like the right fix for the z-fighting below and was not: without it
    # every camera above the eave line, which is every overview the validation
    # probe takes, sees straight into an unlit interior.
    faces = [
        [0, 2, 1], [3, 4, 5],
        [0, 4, 3], [0, 1, 4],
        [0, 5, 2], [0, 3, 5],
        [1, 5, 4], [1, 2, 5],
    ]
    pieces.append(_color(trimesh.Trimesh(vertices=vertices, faces=faces, process=False), roof))
    return pieces


def _hinged_door_leaf(trimesh, dimensions: list[float], palette=None):
    width, height, depth = dimensions
    wood = _slot(palette, 0, [116, 67, 30, 255])
    # Derived, not a slot of its own: the plank highlight is the leaf catching
    # light, so a repainted door must not keep orange planks under blue paint.
    wood_light = _lighten(wood, 151.0 / 116.0)
    metal = _slot(palette, 1, [35, 38, 42, 255])
    handle = _slot(palette, 2, [184, 134, 36, 255])
    # Leave depth inside the declared AABB for readable front-face details.
    pieces = [_color(trimesh.creation.box(extents=[width, height, depth * 0.68]), wood)]
    front_z = -depth * 0.41
    plank_count = 4
    plank_width = width / plank_count
    for index in range(plank_count):
        plank = _translated_box(
            trimesh,
            [plank_width * 0.88, height * 0.94, depth * 0.12],
            [
                -width / 2.0 + plank_width * (index + 0.5),
                0.0,
                front_z,
            ],
            wood_light if index % 2 == 0 else wood,
        )
        pieces.append(plank)
    hinge_radius = min(width, height) * 0.05
    hinge_depth = depth * 0.9
    for y in (-height * 0.32, 0.0, height * 0.32):
        hinge = _color(
            trimesh.creation.cylinder(radius=hinge_radius, height=hinge_depth, sections=12),
            metal,
        )
        hinge.apply_translation([-(width / 2.0 - hinge_radius), y, 0.0])
        pieces.append(hinge)
        pieces.append(
            _translated_box(
                trimesh,
                [width * 0.38, height * 0.045, depth * 0.1],
                [-width * 0.29, y, front_z - depth * 0.01],
                metal,
            )
        )
    knob = _color(
        trimesh.creation.icosphere(subdivisions=2, radius=min(width, height) * 0.055),
        handle,
    )
    knob.apply_translation([width * 0.33, 0.0, front_z - depth * 0.01])
    pieces.append(knob)
    return pieces


def resolve_procedural_asset(entity: dict, output_dir: Path) -> dict:
    """Create a content-addressed GLB selected by an explicit schema contract."""
    requirement = entity.get("asset") or {}
    procedural_type = requirement.get("procedural_type")
    if procedural_type not in _SUPPORTED:
        return {
            "path": ".",
            "tier": "unresolved",
            "component": COMPONENT,
            "brief_hash": "unsupported",
            "qa": None,
            "notes": [f"unsupported procedural type: {procedural_type!r}"],
        }
    dimensions = [float(value) for value in entity["physical"]["bbox_m"]]
    palette_hex = [
        value
        for value in (requirement.get("palette_hex") or ())
        if _hex_to_rgba(value) is not None
    ][:3]
    palette = [_hex_to_rgba(value) for value in palette_hex] or None
    generator_versions = {
        "semantic_box": "semantic_box_v3_nonmetal_pbr",
        "building_shell": "building_shell_v5_outward_roof_lifted_ceiling",
        "hinged_door_leaf": "hinged_door_leaf_v4_detailed_pbr",
        "foliage_column": "foliage_column_v2_filled_crown_structural_trunk",
        "ground_cover": "ground_cover_v1_radiating_blades",
        "irregular_mass": "irregular_mass_v1_jittered_icosphere",
        "fallen_column": "fallen_column_v1_laid_cylinder",
        "legged_platform": "legged_platform_v1_slab_on_four_legs",
        "slender_post": "slender_post_v1_shaft_and_head",
        "flat_panel": "flat_panel_v1_framed_face",
        "open_container": "open_container_v1_walls_open_top",
        "machine_block": "machine_block_v1_body_and_offset_head",
        "conifer_tree": "conifer_tree_v1_stacked_cones",
        "bush_cluster": "bush_cluster_v1_huddled_masses",
        "fence_section": "fence_section_v1_posts_and_rails",
        "round_well": "round_well_v1_drum_and_canopy",
        "wheeled_cart": "wheeled_cart_v1_body_between_wheels",
        "barrel_round": "barrel_round_v1_bellied_drum",
        "arch_gateway": "arch_gateway_v1_piers_and_lintel",
        "round_tower": "round_tower_v1_drum_and_cap",
        "haystack_cone": "haystack_cone_v1_heap",
        "market_stall": "market_stall_v1_counter_under_canopy",
    }
    contract = {
        "generator": generator_versions[procedural_type],
        # Part of the identity of the file, not a note about it: the digest is
        # the cache key and the filename, so a change to the surface rule has to
        # move them or already-generated flat meshes would be reused forever.
        "surface": NOISE_VERSION,
        "semantic_type": entity["semantic_type"],
        "dimensions_m": dimensions,
        # In the key, not beside it. The procedural cache is content-addressed and
        # shared across games, so a red postbox and a green one must not collide on
        # one file -- and every mesh already generated must keep resolving, which an
        # absent palette guarantees by hashing exactly as before.
        **({"palette_hex": palette_hex} if palette_hex else {}),
    }
    digest = hashlib.sha256(
        json.dumps(contract, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"{digest}.glb"
    if not path.is_file():
        import trimesh

        builders = {
            "semantic_box": _semantic_box,
            "building_shell": _building_shell,
            "hinged_door_leaf": _hinged_door_leaf,
            "foliage_column": _foliage_column,
            "ground_cover": _ground_cover,
            "irregular_mass": _irregular_mass,
            "fallen_column": _fallen_column,
            "legged_platform": _legged_platform,
            "slender_post": _slender_post,
            "flat_panel": _flat_panel,
            "open_container": _open_container,
            "machine_block": _machine_block,
            "conifer_tree": _conifer_tree,
            "bush_cluster": _bush_cluster,
            "fence_section": _fence_section,
            "round_well": _round_well,
            "wheeled_cart": _wheeled_cart,
            "barrel_round": _barrel_round,
            "arch_gateway": _arch_gateway,
            "round_tower": _round_tower,
            "haystack_cone": _haystack_cone,
            "market_stall": _market_stall,
        }
        pieces = builders[procedural_type](trimesh, dimensions, palette)
        # Surface grain, applied to FINAL geometry. _fit_to_bbox rescales an
        # assembly non-uniformly, so UVs derived before it would stretch the
        # grain by whatever correction the fit happened to apply. Each piece
        # keeps its palette colour as the tint; the texture only modulates it.
        pieces = apply_surface_texture(trimesh, pieces, int(digest[:8], 16))
        scene = trimesh.Scene()
        for index, piece in enumerate(pieces):
            scene.add_geometry(piece, node_name=f"{procedural_type}_{index}")
        path.write_bytes(scene.export(file_type="glb"))
    brief = AssetBrief(
        brief=requirement["brief"][:200],
        category="building_module" if procedural_type != "hinged_door_leaf" else "prop",
        tri_budget=3000,
    )
    report = qa_mesh(path, brief)
    if not report.passed:
        return {
            "path": ".",
            "tier": "unresolved",
            "component": COMPONENT,
            "brief_hash": digest[:16],
            "qa": report.to_dict(),
            "notes": ["procedural geometry failed deterministic mesh QA"],
        }
    return {
        "path": str(path),
        "tier": "procedural",
        "component": COMPONENT,
        "brief_hash": digest[:16],
        "qa": report.to_dict(),
        "notes": [f"deterministic {procedural_type} geometry"],
    }


def resolve_procedural_box(entity: dict, output_dir: Path) -> dict:
    """Backward-compatible wrapper for older callers/tests."""
    entity = {**entity, "asset": {**entity.get("asset", {}), "procedural_type": "semantic_box"}}
    return resolve_procedural_asset(entity, output_dir)
