"""Deterministic surface grain for procedurally generated meshes.

Procedural forms are the flat tier. Each builder assigns a colour from the vetted
palette and the mesh exports with a bare `baseColorFactor`, so a wall, a trunk
and a boulder are three untextured blocks of colour. Curated (KayKit) and
generated (TRELLIS) assets already carry their own surfaces; this is the tier
that had none.

The grain is a small seamless value-noise image applied as `baseColorTexture`,
with the palette colour left in place as `baseColorFactor`. glTF multiplies the
two, so **the per-piece palette survives** -- a tree keeps a brown trunk under a
green crown -- and the texture only modulates it. That property is what makes
this safe to apply to an already-coloured assembly.

Two things make it work without authored UVs:

- **Box projection, per face.** The primitives trimesh builds carry no
  TEXCOORD_0, so UVs are derived from the dominant axis of the normal. It is the
  mesh-side equivalent of the triplanar projection `godot_client/surfaces.py`
  uses for the ground, and it needs no unwrapping.

  The projection MUST be decided per face, not per vertex. Deriving it per
  vertex on a shared-vertex mesh let the three corners of one triangle choose
  three different axes, so the texture swept across the face: on an icosphere
  boulder 44 of 80 faces disagreed, and the result rendered as a chevron pattern
  radiating from the centre of every rock. Only a picture showed it. Unmerging
  vertices first gives each face its own corners, so all three agree by
  construction and the projection is a clean cube map.
- **Applied after the builder returns**, on final geometry. `_fit_to_bbox`
  rescales an assembly non-uniformly, so UVs computed before it would stretch
  the grain by whatever correction the fit happened to apply.

Seeded from the asset's own content digest, never from the game: the procedural
cache is content-addressed and shared across games, so one contract must always
produce one file (rule 14).
"""

from __future__ import annotations

from functools import lru_cache

# One tile of noise per this many metres. Physical rather than per-object: grain
# is a property of a material, so a 6 m wall shows many tiles and a 0.2 m fern
# shows a fraction of one, which is what really happens.
TILES_PER_METRE = 1.5
_TEXTURE_PIXELS = 64
_LATTICE = 8
# The noise modulates the palette colour; it never replaces it. Staying near the
# top of the range keeps the tint recognisable while giving the surface relief.
# Raised from 0.72 after looking at a render: at that depth the ground read as
# mottled camouflage rather than soil. The grain should be felt, not counted.
_FLOOR = 0.82
NOISE_VERSION = "value_noise_box_uv_v2_per_face"


@lru_cache(maxsize=16)
def noise_texture(seed: int):
    """A seamless greyscale value-noise tile, as an RGB PIL image.

    Periodic on purpose: the lattice wraps, so opposite edges match and the tile
    repeats without a visible seam. Cached because one asset's pieces all share
    one image, and glTF then embeds the pixels once.
    """
    import numpy as np
    from PIL import Image

    rng = np.random.default_rng(seed)
    lattice = rng.random((_LATTICE, _LATTICE))

    coords = np.linspace(0, _LATTICE, _TEXTURE_PIXELS, endpoint=False)
    low = np.floor(coords).astype(int) % _LATTICE
    high = (low + 1) % _LATTICE
    fraction = coords - np.floor(coords)
    # Smoothstep, so the interpolation has no visible lattice grid.
    fraction = fraction * fraction * (3.0 - 2.0 * fraction)

    ty = fraction[:, None]
    tx = fraction[None, :]
    top = lattice[np.ix_(low, low)] * (1 - tx) + lattice[np.ix_(low, high)] * tx
    bottom = lattice[np.ix_(high, low)] * (1 - tx) + lattice[np.ix_(high, high)] * tx
    value = _FLOOR + (1.0 - _FLOOR) * (top * (1 - ty) + bottom * ty)

    grey = (value * 255.0).astype(np.uint8)
    return Image.fromarray(grey, mode="L").convert("RGB")


def box_projection_uv(mesh, tiles_per_metre: float = TILES_PER_METRE):
    """UVs from the dominant axis of the normal: +Y-facing uses X and Z, etc.

    Call `mesh.unmerge_vertices()` first, or corners of one triangle can pick
    different axes and the texture sweeps across the face. `apply_surface_texture`
    does that; this stays a pure function of whatever mesh it is handed.
    """
    import numpy as np

    vertices = np.asarray(mesh.vertices, dtype=np.float64)
    normals = np.asarray(mesh.vertex_normals, dtype=np.float64)
    if len(normals) != len(vertices):  # degenerate mesh — project down one axis
        normals = np.tile([0.0, 1.0, 0.0], (len(vertices), 1))

    dominant = np.argmax(np.abs(normals), axis=1)
    uv = np.zeros((len(vertices), 2), dtype=np.float64)
    for axis, (u_axis, v_axis) in {0: (1, 2), 1: (0, 2), 2: (0, 1)}.items():
        mask = dominant == axis
        if mask.any():
            uv[mask, 0] = vertices[mask, u_axis]
            uv[mask, 1] = vertices[mask, v_axis]
    return uv * float(tiles_per_metre)


def _base_color(piece) -> list:
    """The palette colour the builder already assigned, or opaque white."""
    material = getattr(getattr(piece, "visual", None), "material", None)
    factor = getattr(material, "baseColorFactor", None)
    if factor is None:
        return [255, 255, 255, 255]
    return list(factor)


def apply_surface_texture(trimesh, pieces: list, seed: int) -> list:
    """Give every piece the shared grain, keeping its palette colour as the tint.

    Returns the same pieces, textured in place. A piece whose UVs cannot be
    derived is left exactly as it was: flat colour is a worse surface, never a
    broken one.
    """
    image = noise_texture(seed)
    for piece in pieces:
        colour = _base_color(piece)
        try:
            # Give every face its own corners so all three agree on a projection
            # axis. Triangle count is unchanged, so the tri budget is unaffected.
            piece.unmerge_vertices()
            uv = box_projection_uv(piece)
        except Exception:  # never let decoration break a mesh that was fine
            continue
        piece.visual = trimesh.visual.TextureVisuals(
            uv=uv,
            material=trimesh.visual.material.PBRMaterial(
                baseColorFactor=colour,
                baseColorTexture=image,
                metallicFactor=0.0,
                roughnessFactor=0.88,
            ),
        )
    return pieces
