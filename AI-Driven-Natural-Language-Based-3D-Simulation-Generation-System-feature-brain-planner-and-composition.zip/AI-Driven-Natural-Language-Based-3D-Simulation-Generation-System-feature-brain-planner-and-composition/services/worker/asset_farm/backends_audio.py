"""Stable Audio Open backend — the real sound generator, behind the same seam.

Turns an activity brief ("a snarling village dog, attacking: one short
aggressive strike. single one-shot sound effect, dry, close mic, mono, no
music") into a WAV, via ComfyUI on the GPU box — the same host that already
serves SDXL for the mesh farm.

It is a SEPARATE backend from GpuAssetBackend on purpose: Stable Audio and
TRELLIS are different models that cannot be co-resident in 32 GB (CLAUDE.md §4),
so the worker enables and sequences them independently, and either can be off
while the other runs.

Everything downstream is unchanged: the resolver gates the output with
`qa_audio`, the license guard checks `component` against the ledger, and any
failure — a dead host, a bad graph, a clip that flunks QA — falls back to the
curated sound set. Sound generation can never break a build.

⚠ STATUS: the contract below (checkpoint name + node graph) has NOT yet been
run against a live Stable Audio Open install; `MockAudioBackend` is what the
tests and the verified end-to-end runs use. Treat the workflow constants as the
first thing to check when enabling this for real, exactly as the SDXL graph in
backends_gpu.py had to be smoke-tested before it was trusted.

Licensing (§14): Stable Audio Open is product-path **conditional** — free under
the provider's revenue threshold. The ledger row governs; the license guard
enforces it before a single sample is generated.
"""

from __future__ import annotations

import logging
from pathlib import Path

from asset_farm.backends import GenerationResult
from asset_farm.brief import AssetBrief

log = logging.getLogger(__name__)

COMPONENT = "stable-audio-open"
# ComfyUI's Stable Audio nodes; names mirror the shipped example workflow.
CHECKPOINT = "stable-audio-open-1.0.safetensors"
NEGATIVE = "music, melody, speech, singing, reverb, noise, distortion"
# A game one-shot. Stable Audio generates a fixed-length window and pads with
# silence, so asking for a short window is what keeps clips tight and small —
# and inside qa_audio's 8s ceiling for audio_sfx.
SECONDS = 4.0
STEPS = 50
CFG = 6.0


class AudioBackendError(RuntimeError):
    """Generation failed. The resolver catches this and ships curated."""


class StableAudioBackend:
    """Real Stable Audio Open via ComfyUI. Needs the audio stack installed."""

    component = COMPONENT

    def __init__(
        self,
        base_url: str = "http://localhost:8188",
        timeout_seconds: float = 300.0,
        seconds: float = SECONDS,
    ) -> None:
        self.base_url = base_url or "http://localhost:8188"
        self.timeout_seconds = timeout_seconds
        self.seconds = seconds

    def generate(self, brief: AssetBrief, out_dir: Path) -> GenerationResult:
        if not brief.is_audio:
            raise AudioBackendError(
                f"{COMPONENT} makes sound, not {brief.category!r} — the caller passed "
                "the wrong backend for this brief"
            )
        import httpx  # only the generating path needs an HTTP client

        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / f"{brief.hash()}.wav"
        with httpx.Client(base_url=self.base_url, timeout=self.timeout_seconds) as client:
            response = client.post(
                "/prompt",
                json=_workflow(brief.brief, seed=_seed(brief), seconds=self.seconds),
            )
            response.raise_for_status()
            prompt_id = response.json()["prompt_id"]
            path.write_bytes(_await_audio(client, prompt_id, self.timeout_seconds))
        return GenerationResult(path=path, component=COMPONENT, tri_count=None)


def _seed(brief: AssetBrief) -> int:
    """A stable per-brief seed: the same brief regenerates the same clip (rule 14)."""
    return int(brief.hash(), 16) % (2**31)


def _workflow(prompt: str, seed: int, seconds: float) -> dict:
    """API-format Stable Audio graph with the prompt, seed and length injected."""
    wf = {
        "4": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": CHECKPOINT}},
        "5": {"class_type": "EmptyLatentAudio", "inputs": {"seconds": seconds, "batch_size": 1}},
        "6": {"class_type": "CLIPTextEncode", "inputs": {"text": prompt, "clip": ["4", 1]}},
        "7": {"class_type": "CLIPTextEncode", "inputs": {"text": NEGATIVE, "clip": ["4", 1]}},
        "3": {
            "class_type": "KSampler",
            "inputs": {
                "seed": seed,
                "steps": STEPS,
                "cfg": CFG,
                "sampler_name": "dpmpp_3m_sde_gpu",
                "scheduler": "exponential",
                "denoise": 1.0,
                "model": ["4", 0],
                "positive": ["6", 0],
                "negative": ["7", 0],
                "latent_image": ["5", 0],
            },
        },
        "8": {"class_type": "VAEDecodeAudio", "inputs": {"samples": ["3", 0], "vae": ["4", 2]}},
        "9": {
            "class_type": "SaveAudio",
            "inputs": {"filename_prefix": "farm_sfx", "audio": ["8", 0]},
        },
    }
    return {"prompt": wf}


def _await_audio(client, prompt_id: str, timeout_seconds: float) -> bytes:
    """Poll /history/{id} until the SaveAudio node reports a clip, then download
    it from /view. Raises if the job never completes in time."""
    import time

    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        time.sleep(2.0)
        history = client.get(f"/history/{prompt_id}").json()
        entry = history.get(prompt_id)
        if not entry or not entry.get("outputs"):
            continue
        for out in entry["outputs"].values():
            clips = out.get("audio") or out.get("clips")
            if clips:
                clip = clips[0]
                params = {"filename": clip["filename"], "type": clip.get("type", "output")}
                if clip.get("subfolder"):
                    params["subfolder"] = clip["subfolder"]
                view = client.get("/view", params=params)
                view.raise_for_status()
                return view.content
    raise AudioBackendError(f"ComfyUI did not finish prompt {prompt_id} in {timeout_seconds}s")
