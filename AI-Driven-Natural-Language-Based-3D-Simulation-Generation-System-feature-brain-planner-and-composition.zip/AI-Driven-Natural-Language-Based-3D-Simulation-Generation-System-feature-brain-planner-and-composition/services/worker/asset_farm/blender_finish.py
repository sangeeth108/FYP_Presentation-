"""Blender headless finishing pass: raw TRELLIS GLB -> web-ready GLB.

Run by GpuAssetBackend as:
    blender --background --python blender_finish.py -- \
        --in raw.glb --out final.glb --tri-budget 2000

Decimates to the triangle budget, applies transforms, and re-exports a clean
glTF-binary the web build can load. Pure Blender Python (bpy) — it only runs
inside Blender on the GPU box, never imported by the pipeline, so it needs no
handling on a curated-only deployment.

Deterministic: no randomness; the decimate ratio is a function of the input tri
count and the budget. Fails loudly (non-zero exit) so the backend treats a bad
finish as a generation failure and the resolver ships curated.
"""

from __future__ import annotations

import sys


def _args(argv: list[str]) -> dict:
    # Everything after the "--" Blender passes through to us.
    after = argv[argv.index("--") + 1 :] if "--" in argv else []
    out: dict[str, str] = {}
    key = None
    for tok in after:
        if tok.startswith("--"):
            key = tok[2:]
        elif key is not None:
            out[key] = tok
            key = None
    return out


def main() -> int:
    try:
        import bpy  # only exists inside Blender
    except ImportError:
        sys.stderr.write("blender_finish must run inside Blender (bpy unavailable)\n")
        return 2

    args = _args(sys.argv)
    in_path, out_path = args.get("in"), args.get("out")
    tri_budget = int(args.get("tri-budget", "2000"))
    if not in_path or not out_path:
        sys.stderr.write("need --in and --out\n")
        return 2

    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=in_path)

    meshes = [o for o in bpy.data.objects if o.type == "MESH"]
    total_tris = sum(len(m.data.polygons) for m in meshes)  # tris after triangulation on export
    if total_tris > tri_budget and total_tris > 0:
        ratio = max(0.01, tri_budget / total_tris)
        for obj in meshes:
            mod = obj.modifiers.new(name="Decimate", type="DECIMATE")
            mod.ratio = ratio
            bpy.context.view_layer.objects.active = obj
            bpy.ops.object.modifier_apply(modifier=mod.name)

    # Apply transforms so the exported mesh is at unit scale / origin.
    for obj in meshes:
        obj.select_set(True)
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

    bpy.ops.export_scene.gltf(
        filepath=out_path,
        export_format="GLB",
        export_yup=True,
        export_apply=True,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
