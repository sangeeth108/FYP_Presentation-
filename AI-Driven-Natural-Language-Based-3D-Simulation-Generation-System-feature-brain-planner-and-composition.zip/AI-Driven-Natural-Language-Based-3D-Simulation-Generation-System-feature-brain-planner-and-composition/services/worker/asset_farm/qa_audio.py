"""Audio QA gate (validation gate 3, audio path): is a produced clip fit to ship?

Deterministic checks on a candidate WAV — valid RIFF/WAVE container, a duration
sane for its category (a one-shot SFX is short; a loop is longer), and a size that
respects the web budget. Machine-readable error objects, never bare strings (§13),
mirroring qa_mesh so the resolver and lineage treat audio and meshes identically.

Parses the WAV header itself (stdlib `wave`), so a backend that emits a broken or
mislabeled file fails rather than being trusted.
"""

from __future__ import annotations

import contextlib
import wave
from dataclasses import dataclass
from pathlib import Path

from asset_farm.brief import AssetBrief

# A single web audio clip should be small; anything larger is almost always an
# uncompressed export that would blow the 90 MB build.
MAX_AUDIO_BYTES = 3_000_000
# Sane duration windows per category (seconds).
DURATION_LIMITS: dict[str, tuple[float, float]] = {
    "audio_sfx": (0.05, 8.0),  # a one-shot effect
    "audio_loop": (1.0, 60.0),  # an ambient / music loop
}


@dataclass(frozen=True)
class AudioQAError:
    code: str
    path: str
    message: str
    hint: str

    def to_dict(self) -> dict:
        return {"code": self.code, "path": self.path, "message": self.message, "hint": self.hint}


@dataclass
class AudioQAReport:
    passed: bool
    duration_s: float | None
    size_bytes: int
    errors: list[AudioQAError]

    def to_dict(self) -> dict:
        return {
            "passed": self.passed,
            "duration_s": self.duration_s,
            "size_bytes": self.size_bytes,
            "errors": [e.to_dict() for e in self.errors],
        }


def _duration(path: Path) -> float | None:
    with contextlib.suppress(Exception), wave.open(str(path), "rb") as w:
        frames, rate = w.getnframes(), w.getframerate()
        if rate > 0:
            return frames / rate
    return None


def qa_audio(path: Path, brief: AssetBrief) -> AudioQAReport:
    """Judge a produced audio clip against its brief. Never raises — a broken file
    is a FAIL with an error object, not an exception the caller must catch."""
    errors: list[AudioQAError] = []
    size = path.stat().st_size if path.is_file() else 0

    if size == 0:
        errors.append(AudioQAError("AUDIO_EMPTY", "$.file", "audio file is missing or empty",
                                   "generation produced nothing — fall back to curated"))
        return AudioQAReport(False, None, size, errors)

    if size > MAX_AUDIO_BYTES:
        errors.append(AudioQAError("AUDIO_TOO_LARGE", "$.file",
                                   f"{size} bytes exceeds the {MAX_AUDIO_BYTES}-byte ceiling",
                                   "encode shorter / compressed audio"))

    duration = _duration(path)
    if duration is None:
        errors.append(AudioQAError("AUDIO_MALFORMED", "$.wav", "not a readable WAV file",
                                   "not valid audio — fall back to curated"))
        return AudioQAReport(False, None, size, errors)

    lo, hi = DURATION_LIMITS.get(brief.category, (0.05, 60.0))
    if not (lo <= duration <= hi):
        errors.append(AudioQAError("AUDIO_DURATION_OUT_OF_RANGE", "$.duration",
                                   f"{duration:.2f}s outside [{lo}, {hi}] for a {brief.category}",
                                   "trim or extend the clip to the category window"))

    return AudioQAReport(not errors, round(duration, 3), size, errors)
