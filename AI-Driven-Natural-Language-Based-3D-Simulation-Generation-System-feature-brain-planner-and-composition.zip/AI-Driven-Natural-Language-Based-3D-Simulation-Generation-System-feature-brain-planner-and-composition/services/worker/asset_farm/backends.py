"""Generation backends: the ONE AI step in the asset farm, behind an interface.

A backend turns an AssetBrief into a candidate file and declares which licensed
component produced it. The real farm (SDXL -> TRELLIS.2 -> Blender headless;
Stable Audio Open) implements this protocol on the GPU box; a deterministic mock
implements it for tests and for a GPU-less dev machine. Same shape either way, so
the resolver, the QA gate and the license guard are all testable without a GPU —
exactly how the brain's LLM sits behind a mockable gateway.
"""

from __future__ import annotations

import math
import struct
import wave
from pathlib import Path
from typing import Protocol

from asset_farm.brief import AssetBrief


class GenerationResult:
    """A produced candidate + its provenance. Not yet accepted — QA judges it."""

    def __init__(self, path: Path, component: str, tri_count: int | None = None) -> None:
        self.path = path
        self.component = component  # the ledger component that made it (license-checked)
        self.tri_count = tri_count  # backend's own estimate; QA re-measures independently


class GenerationBackend(Protocol):
    """Produce a candidate asset for a brief into out_dir. May raise on failure —
    the resolver treats any exception as 'generation failed' and falls back."""

    def generate(self, brief: AssetBrief, out_dir: Path) -> GenerationResult: ...


def _minimal_glb(tri_count: int) -> bytes:
    """A valid, tiny binary glTF whose mesh has exactly `tri_count` triangles.

    Real enough for the QA gate to parse and count — the mock produces geometry
    the same pipeline validates, so a test exercises the true QA path, not a stub.
    """
    # One triangle strip degenerated into tri_count triangles sharing 3 verts:
    # QA counts indices/3, so emit 3*tri_count indices over a 3-vertex buffer.
    positions = struct.pack("<9f", 0, 0, 0, 1, 0, 0, 0, 1, 0)  # 3 verts (x,y,z)
    indices = struct.pack(f"<{3 * tri_count}H", *([0, 1, 2] * tri_count))
    bin_chunk = positions + indices
    while len(bin_chunk) % 4:  # glTF chunks are 4-byte aligned
        bin_chunk += b"\x00"

    gltf = {
        "asset": {"version": "2.0", "generator": "promptplay-mock"},
        "buffers": [{"byteLength": len(bin_chunk)}],
        "bufferViews": [
            {"buffer": 0, "byteOffset": 0, "byteLength": len(positions), "target": 34962},
            {
                "buffer": 0,
                "byteOffset": len(positions),
                "byteLength": len(indices),
                "target": 34963,
            },
        ],
        "accessors": [
            {
                "bufferView": 0,
                "componentType": 5126,
                "count": 3,
                "type": "VEC3",
                "min": [0, 0, 0],
                "max": [1, 1, 0],
            },
            {"bufferView": 1, "componentType": 5123, "count": 3 * tri_count, "type": "SCALAR"},
        ],
        "meshes": [{"primitives": [{"attributes": {"POSITION": 0}, "indices": 1}]}],
        "nodes": [{"mesh": 0}],
        "scenes": [{"nodes": [0]}],
        "scene": 0,
    }
    import json

    json_chunk = json.dumps(gltf, separators=(",", ":")).encode("utf-8")
    while len(json_chunk) % 4:
        json_chunk += b" "

    header = struct.pack("<4sII", b"glTF", 2, 12 + 8 + len(json_chunk) + 8 + len(bin_chunk))
    json_hdr = struct.pack("<I4s", len(json_chunk), b"JSON")
    bin_hdr = struct.pack("<I4s", len(bin_chunk), b"BIN\x00")
    return header + json_hdr + json_chunk + bin_hdr + bin_chunk


class MockBackend:
    """Deterministic stand-in for the GPU farm. Produces a valid GLB whose tri
    count tracks the brief's budget, so the resolver + QA path is fully exercised
    without a GPU. Declares `component` so the license guard is exercised too."""

    def __init__(self, component: str = "trellis-2", tri_fraction: float = 0.8) -> None:
        self.component = component
        self.tri_fraction = tri_fraction  # produce this fraction of the budget

    def generate(self, brief: AssetBrief, out_dir: Path) -> GenerationResult:
        out_dir.mkdir(parents=True, exist_ok=True)
        tris = max(1, int(brief.effective_tri_budget * self.tri_fraction))
        path = out_dir / f"{brief.hash()}.glb"
        path.write_bytes(_minimal_glb(tris))
        return GenerationResult(path=path, component=self.component, tri_count=tris)


class MockAudioBackend:
    """Deterministic stand-in for Stable Audio Open. Produces a REAL WAV (stdlib
    `wave`), so qa_audio parses genuine audio and the whole sound path — brief ->
    generate -> gate -> cache -> ship — is exercised with no GPU, exactly as
    MockBackend does for meshes.

    The clip's length is derived from the brief hash, so it is deterministic per
    brief but varies across briefs (rule 14).
    """

    def __init__(self, component: str = "stable-audio-open", seconds: float | None = None) -> None:
        self.component = component
        self.seconds = seconds  # None = derive from the brief, so clips differ

    def generate(self, brief: AssetBrief, out_dir: Path) -> GenerationResult:
        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / f"{brief.hash()}.wav"
        seconds = self.seconds
        if seconds is None:  # 0.3-1.3s, deterministic in the brief
            seconds = 0.3 + (int(brief.hash()[:4], 16) % 1000) / 1000.0
        rate = 44100
        frames = int(seconds * rate)
        with wave.open(str(path), "wb") as out:
            out.setnchannels(1)
            out.setsampwidth(2)
            out.setframerate(rate)
            # A quiet decaying tone: real samples, so a gate that only checked for
            # a RIFF header would not be enough to pass this.
            out.writeframes(
                b"".join(
                    struct.pack(
                        "<h",
                        int(8000 * math.sin(i * 0.05) * math.exp(-3.0 * i / max(frames, 1))),
                    )
                    for i in range(frames)
                )
            )
        return GenerationResult(path=path, component=self.component, tri_count=None)
