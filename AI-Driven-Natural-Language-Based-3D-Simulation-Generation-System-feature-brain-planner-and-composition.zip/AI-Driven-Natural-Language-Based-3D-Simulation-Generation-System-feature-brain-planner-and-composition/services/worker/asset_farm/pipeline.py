"""S5 wiring: resolve every asset_brief in a spec, record provenance.

Sits between the frozen spec and project assembly. For each prop and enemy it
finds the curated fallback the game already uses (asset_kit), then runs the
resolver — cache -> curated -> generate -> QA. Returns a manifest keyed by
brief_hash for the job's lineage record (§11: every artifact needs lineage).

Backend defaults to None, so with no GPU farm configured this is a no-op on the
shipped output (curated wins) that simply *records* what each asset is and where
it came from. When a real backend is passed, unique generated assets replace the
curated ones wherever they pass QA — and the manifest shows exactly which did.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

from godot_client.asset_kit import (
    ENEMY_MODELS,
    FUNCTIONAL_PROPS,
    MODEL_DESCRIPTIONS,
    default_character_model,
    enemy_sounds,
    model_category,
    prop_model,
)

from asset_farm.backends import GenerationBackend
from asset_farm.brief import AssetBrief
from asset_farm.cache import AssetCache
from asset_farm.curated_match import best_curated, curated_floor, keyword_best
from asset_farm.qa_gate import mesh_capabilities
from asset_farm.resolver import ResolvedAsset, resolve_asset
from asset_farm.sound_brief import activity_sound_briefs

log = logging.getLogger(__name__)

# The bridge between two vocabularies that are deliberately different.
#
# A spec `category` says what a thing IS IN THE WORLD -- vehicle, machine,
# structure. An AssetBrief category says what PRODUCTION PATH it needs -- tri
# budget, rigging, whether generation will touch it. A vehicle and a structure
# are different in the world and identical to build, so collapsing the two
# vocabularies would lose real information.
#
# What was wrong was the bridge, not the split: `.get(category, "prop")` meant a
# spec category nobody had mapped silently became a prop. `test_category_bridge`
# asserts this covers every value the schema permits and produces only values
# AssetBrief accepts, so adding to either side without the other fails a test
# rather than a run.
# The bar the library must clear to be used INSTEAD OF generating. CLAUDE.md S5 names it
# "curated (>=0.85)", and 0.85 was the right number while a score was the ONLY evidence:
# it had to be high enough that an approximate match could not claim a brief the
# generator should make.
#
# `names_the_same_kind` changed what the evidence is. A match now has to name the same
# KIND of thing before it is offered at all, which is a different question from how close
# a vector is, and answers the one a score cannot:
#
#     red fox      -> Fox.glb      0.697   right, and refused by a 0.85 bar
#     squirrel     -> Cow.glb      ~0.65   a cow, and admitted by any bar below it
#     canopy tree  -> tree_oak.glb 0.819   right, and refused by a 0.85 bar
#
# Fox at 0.697 and cow-for-squirrel at 0.65 are nearly the same number and opposite
# answers, so no threshold separates them; the words do. With agreement enforced, the
# measured per-category floors (0.64 character, 0.70 prop) are the honest bar -- a match
# that both clears its category's floor and names the same kind IS the thing asked for,
# and generating a second one is waste. Measured on one forest: 13 of 15 assets generated,
# 45 minutes, and `tree_oak.glb`, `Fox.glb` and `Deer.glb` sat unused in the library.
#
# Kept as a constant for the one case agreement cannot cover: no subject and no
# description to compare, where a bare score is still all there is.
PREEMPT_GENERATION_FLOOR = 0.85

_SIMULATION_CATEGORY = {
    "character": "character",
    "prop": "prop",
    "structure": "building_module",
    "vehicle": "building_module",
    "machine": "prop",
    "environment": "building_module",
}


def _agreeing(
    pick: tuple[str, float] | None,
    library: dict[str, str],
    brief_text: str,
    subject: str | None,
) -> tuple[str, float] | None:
    """Hold the KEYWORD tier to the same rule as the embedding tier.

    The embedding tier stopped offering a wrong kind; the lexical tier beside it did not,
    and it is consulted for every brief. Measured on the very next run, reported as
    `tier: curated` because that is exactly what it was:

        ent_stump -> roof-point.glb   44 tris   a roof point, for a tree stump

    "stump" and "roof point" share no identity word -- `names_the_same_kind` refuses that
    pair in a unit test -- and the pair shipped anyway, because it never reached the gate.
    A rule enforced on one of two paths into the same decision is not enforced.
    """
    if pick is None:
        return None
    from asset_farm.curated_match import names_the_same_kind

    offered = f"{pick[0]} {library.get(pick[0], '')}"
    if names_the_same_kind(f"{subject or ''} {brief_text}", offered):
        return pick
    log.info(
        "keyword match %r refused for %r: not the same kind of thing",
        Path(pick[0]).name,
        (subject or brief_text)[:40],
    )
    return None


def resolve_simulation_assets(
    spec: dict,
    *,
    kit_dir: Path | None = None,
    cache_dir: Path | None = None,
    work_dir: Path | None = None,
    backend: GenerationBackend | None = None,
    ledger_path: str | None = None,
    embed_base_url: str | None = None,
    asset_ranker: Any | None = None,
) -> dict[str, dict]:
    """Resolve every neutral ``SimulationSpec`` entity without a game adapter.

    The returned manifest is keyed by canonical entity id. Characters may use a
    measured, animated curated body. Props use a curated model only when the
    semantic matcher identifies one; structures, vehicles and environments are
    never silently represented by a barrel or another unrelated proxy. If no
    compatible real asset exists and generation is unavailable, the entity is
    recorded as unresolved and the mandatory asset gate fails truthfully.
    """
    cache = AssetCache(cache_dir) if cache_dir is not None else None
    manifest: dict[str, dict] = {}
    # Curated bodies already handed to a person in THIS world. A railway prompt
    # put a station guard and a tea vendor a few metres apart as identical copies
    # of Man.glb: both are genuinely closest to "an ordinary man", and the
    # second-best candidate was never looked at.
    used_characters: set[str] = set()
    library = {
        rel: text
        for rel, text in MODEL_DESCRIPTIONS.items()
        if kit_dir is not None and (kit_dir / rel).is_file()
    }

    def curated_path(relative: str | None) -> Path | None:
        if relative is None or kit_dir is None:
            return None
        candidate = kit_dir / relative
        return candidate if candidate.is_file() else None

    def semantic_pick(
        brief_text: str,
        *,
        character: bool,
        requires_animation: bool,
        subject: str | None = None,
        library_category: str | None = None,
    ) -> str | None:
        # The caller's own category, not a boolean. Collapsing everything
        # non-character to "prop" searched a house against ten objects none of which
        # is a building, and `banner_red` won -- see STRUCTURE_MODELS in asset_kit.
        semantic_pick.last_score = 0.0
        category = library_category or ("character" if character else "prop")
        excluded = {
            match.group(1)
            for match in re.finditer(
                r"\b(?:no|without)\s+(?:(?:a|an|any|the|surrounding)\s+)?([a-z]+)",
                brief_text.lower(),
            )
        }
        candidates = {
            rel: description
            for rel, description in library.items()
            if model_category(rel) == category
            and not excluded.intersection(
                re.findall(r"[a-z]+", description.lower())
            )
        }
        # Let the matcher choose among bodies nobody in this world is wearing yet.
        # A railway prompt put a station guard and a tea vendor a few metres apart
        # as identical copies of Man.glb -- both genuinely closest to "an ordinary
        # man" -- while Woman and Farmer sat unused in the same library.
        #
        # Characters only. A waiting room of identical chairs is a set; two
        # identical people is a fault.
        #
        # If nothing still available clears the bar, the full set is tried again,
        # so a second farmer is still a farmer rather than being pushed onto a
        # body that matches nothing. Two people who genuinely match the same
        # description SHOULD share it; what this stops is two people who matched
        # nothing sharing a body by default.
        #
        # This tier used to decide almost nothing for people. The floor was 0.85 and
        # a person's brief scored 0.548 at best, so it never fired and `_unused_human`
        # dressed nearly everyone. Two things changed that (see curated_match): the
        # floors are now measured per category rather than taken from the spec
        # document, and the SUBJECT is embedded instead of the brief -- "an animated,
        # rigged dog suitable as the controlled simulation agent" matched Alpaca at
        # 0.566, while "a dog" matches Husky at 0.651.
        available = candidates
        if character:
            from godot_client.asset_kit import ORDINARY_HUMAN_MODELS

            # PEOPLE only. The rule exists because "two identical people is a fault" --
            # a station guard and a tea vendor as two copies of Man.glb. It was applied
            # to every character, so once one animal took `Deer.glb` the next was pushed
            # off its own species: measured across two runs of the same prompt,
            #
            #     ent_deer -> Deer.glb   then   ent_deer -> Cow.glb
            #     ent_bird -> Wolf.glb   then   ent_bird -> Horse.glb
            #
            # and the visual critic failed the scene with "does not match the description
            # of a realistic deer model", correctly. Ten deer in a forest are ten deer;
            # a cow standing in for a deer is a different animal. Species identity beats
            # variety, so an animal may repeat and a person may not.
            reserved = used_characters & set(ORDINARY_HUMAN_MODELS)
            available = {
                rel: description
                for rel, description in candidates.items()
                if rel not in reserved
            } or candidates
        hit = best_curated(
            brief_text,
            available,
            embed_base_url,
            subject=subject,
            category=category,
        )
        keyword = _agreeing(
            keyword_best(brief_text, available), available, brief_text, subject
        )
        if character and hit is None and keyword is None and available is not candidates:
            hit = best_curated(
                brief_text,
                candidates,
                embed_base_url,
                subject=subject,
                category=category,
            )
            keyword = _agreeing(
                keyword_best(brief_text, candidates), candidates, brief_text, subject
            )
        ranked: dict[str, dict] = {}
        if hit is not None:
            ranked[hit[0]] = {
                "semantic_embedding_score": float(hit[1]),
                "semantic_keyword_score": 0.0,
                "curated": True,
                "requires_animation": requires_animation,
                "character": character,
            }
        if keyword is not None:
            entry = ranked.setdefault(
                keyword[0],
                {
                    "semantic_embedding_score": 0.0,
                    "semantic_keyword_score": 0.0,
                    "curated": True,
                    "requires_animation": requires_animation,
                    "character": character,
                },
            )
            entry["semantic_keyword_score"] = float(keyword[1])
        if not ranked:
            return None
        # How SURE the library is, kept for the caller. This project GENERATES models;
        # the library may only pre-empt that when it owns very nearly the exact thing
        # asked for (CLAUDE.md S5: "curated (>=0.85) -> generate"). The floors below that
        # -- 0.64 character, 0.70 prop -- are for the FALLBACK after generation fails,
        # and using them to pre-empt generation is what starved the generator: measured,
        # a 0.70 "close enough" claimed briefs TRELLIS should have made.
        semantic_pick.last_score = float(hit[1]) if hit is not None else 0.0
        if asset_ranker is None:
            return hit[0] if hit is not None else keyword[0]
        scored = []
        for index, (relative, features) in enumerate(ranked.items()):
            try:
                score = float(asset_ranker.score(features))
            except Exception:
                score = 0.0
            scored.append((score, -index, relative))
        return max(scored)[2]

    for entity in spec.get("entities", []):
        requirement = entity.get("asset") or {}
        brief_text = str(requirement.get("brief") or entity.get("name") or "3D asset")
        if requirement.get("preferred_source") == "procedural":
            from asset_farm.procedural import resolve_procedural_asset

            procedural_root = cache_dir or work_dir
            if procedural_root is None:
                entry = {
                    "path": ".",
                    "tier": "unresolved",
                    "component": "serendib-procedural-geometry",
                    "brief_hash": "unavailable",
                    "qa": None,
                    "notes": ["procedural output directory is unavailable"],
                }
            else:
                entry = resolve_procedural_asset(entity, Path(procedural_root) / "procedural")
            entry["curated_rel"] = None
            entry["entity_id"] = entity["entity_id"]
            entry["requires_animation"] = False
            manifest[entity["entity_id"]] = entry
            continue
        # The existing farm contract is shared with the legacy schema and caps a
        # backend prompt at 200 characters. The full brief remains in the
        # SimulationSpec; only the model-generation prompt is bounded here.
        farm_brief = brief_text[:200]
        neutral_category = str(requirement.get("category") or "prop")
        # Never silently. An unmapped category is a contract gap, and the run
        # deserves to say so rather than quietly building a barrel.
        farm_category = _SIMULATION_CATEGORY.get(neutral_category)
        if farm_category is None:
            log.warning(
                "no asset production path for spec category %r; treating as prop. "
                "Add it to _SIMULATION_CATEGORY.",
                neutral_category,
            )
            farm_category = "prop"
        is_character = farm_category == "character"
        matched_rel = semantic_pick(
            farm_brief,
            character=is_character,
            requires_animation=bool(requirement.get("requires_animation")),
            # The noun, not the plumbing. "an animated, rigged dog suitable as the
            # controlled simulation agent" matched Alpaca; "a dog" matches Husky.
            subject=str(entity.get("semantic_type") or ""),
            # A structure searches the architecture, not the crockery.
            library_category=farm_category,
        )
        chosen_rel = matched_rel
        if is_character and chosen_rel is None:
            chosen_rel = default_character_model(farm_brief)
            # An animal is never answered by a person.
            #
            # `default_character_model` reads the brief lexically and `_unused_human`
            # then spreads unmatched PEOPLE across the ordinary bodies. Measured, a bird
            # and a squirrel came out as `Woman.glb` and `Farmer.glb` -- worse than the
            # wrong quadrupeds before them, because at least a wolf is an animal. The
            # subject says what this is, so it decides which fallback applies.
            if _names_an_animal(f"{entity.get('semantic_type') or ''} {farm_brief}"):
                from godot_client.asset_kit import DEFAULT_ANIMAL_MODEL

                chosen_rel = DEFAULT_ANIMAL_MODEL
            elif chosen_rel in used_characters:
                # Reached only when no tier could judge fit, so there is nothing
                # to override: the default is one fixed body, not a decision.
                chosen_rel = _unused_human(chosen_rel, used_characters, library)
        if is_character and chosen_rel is not None:
            used_characters.add(chosen_rel)
        asset_brief = AssetBrief(
            brief=farm_brief,
            category=farm_category,
            tri_budget=(
                8000
                if is_character
                else 3000
                if farm_category == "building_module"
                else 2000
            ),
        )
        entry = _resolve_one(
            asset_brief,
            curated_path(chosen_rel),
            backend,
            cache,
            work_dir,
            ledger_path,
            embed_base_url,
            palette_hex=requirement.get("palette_hex"),
            # The library may pre-empt generation when it owns the same KIND of thing
            # at or above its category's measured floor. `semantic_pick` only ever
            # returns a match that passed `names_the_same_kind`, so reaching here at all
            # is the agreement evidence; the score still has to clear the floor.
            curated_is_match=(
                matched_rel is not None
                and getattr(semantic_pick, "last_score", 0.0)
                >= curated_floor(farm_category)
            ),
        )
        entry["curated_rel"] = chosen_rel
        entry["entity_id"] = entity["entity_id"]
        entry["requires_animation"] = bool(requirement.get("requires_animation"))
        manifest[entity["entity_id"]] = entry

    # Scatter species were being skipped entirely: only `entities` were resolved,
    # so a jungle's six authored species (trees, ferns, debris) reached placement
    # with no mesh at all. One species resolves ONE asset that is then instanced
    # thousands of times, so this is cheap — and it is what turns a density number
    # into something you can actually see.
    for species in spec.get("scatter", []):
        manifest[species["species_id"]] = _resolve_scatter_species(
            species,
            cache=cache,
            cache_dir=cache_dir,
            work_dir=work_dir,
            backend=backend,
            ledger_path=ledger_path,
            embed_base_url=embed_base_url,
            # curated_path/semantic_pick are closures over this call's kit_dir, so
            # they are handed in rather than re-derived.
            curated_path=curated_path,
            semantic_pick=semantic_pick,
        )
    return manifest


# A species with no declared size still has to produce a mesh; keep it small so a
# missing `size_m` never yields a building-sized shrub.
_FALLBACK_SPECIES_SIZE_M = [1.0, 1.5, 1.0]


def _unused_human(
    default_rel: str,
    used: set[str],
    library: dict[str, str],
) -> str:
    """An ordinary human body nobody in this world is wearing yet.

    Only reached when no tier could judge fit -- the embedding floor now varies by
    category (0.64 characters, 0.70 props, both measured) and a
    person's brief scores about 0.55, while the keyword tier fires only on a brief
    that literally contains a library word. So there is no evidence favouring the
    default over any other ordinary body, and handing every unmatched person the
    same one makes a crowd of identical twins.

    The first free body in preference order, which puts the generic ones ahead of
    the specific: Farmer wears work clothes and a hat, so a tea vendor should reach
    for it only once the plain man and woman are taken. Picking by a hash of the
    brief would scatter more evenly and was tried first, but it ignored that
    ordering and dressed the vendor as a farmer while Woman sat unused.

    No randomness, so nothing needs seeding: the same world always produces the
    same inhabitants.
    """
    from godot_client.asset_kit import ORDINARY_HUMAN_MODELS

    if default_rel not in ORDINARY_HUMAN_MODELS:
        return default_rel  # an animal, or a body outside the ordinary set
    for rel in ORDINARY_HUMAN_MODELS:
        if rel not in used and rel in library:
            return rel
    return default_rel  # more people than bodies; an honest repeat


# `scatter_asset_requirement.category` -> which shelf of the curated library holds it.
# The spec's vocabulary and the library's are not the same, and pretending they are is
# what silently sent every species to the "prop" shelf.
_SCATTER_LIBRARY_CATEGORY = {
    "prop": "prop",
    "foliage": "prop",  # a tree is scenery you place, not architecture
    "structure": "building_module",
    "building_module": "building_module",
    "environment": "building_module",
}

# Enough to tell a fox from a fern. The library keeps animals under `character` because
# they are rigged, and the scatter contract has no word for "animal", so the species has
# to be read for one.
_ANIMAL_WORDS = (
    "fox", "deer", "wolf", "bear", "boar", "rabbit", "hare", "squirrel", "mouse",
    "rat", "bird", "jay", "cardinal", "crow", "owl", "duck", "goose", "chicken",
    "hen", "sheep", "goat", "cow", "cattle", "horse", "pig", "dog", "cat", "fish",
    "frog", "lizard", "snake", "animal", "wildlife", "livestock",
)


def _names_an_animal(text: str) -> bool:
    """Does this species name a living creature? Whole words, so 'catwalk' is not a cat."""
    import re as _re

    return bool(set(_re.split(r"[^a-z]+", text.lower())) & set(_ANIMAL_WORDS))


def _resolve_scatter_species(
    species: dict,
    *,
    cache,
    cache_dir: Path | None,
    work_dir: Path | None,
    backend,
    ledger_path: Path | None,
    embed_base_url: str | None,
    curated_path,
    semantic_pick,
) -> dict:
    """Resolve one scatter species to a single reusable asset."""
    requirement = species.get("asset") or {}
    brief_text = str(requirement.get("brief") or species.get("semantic_type") or "3D asset")
    size = species.get("size_m") or _FALLBACK_SPECIES_SIZE_M

    if requirement.get("preferred_source") == "procedural":
        from asset_farm.procedural import resolve_procedural_asset

        procedural_root = cache_dir or work_dir
        if procedural_root is None:
            entry = {
                "path": ".",
                "tier": "unresolved",
                "component": "serendib-procedural-geometry",
                "brief_hash": "unavailable",
                "qa": None,
                "notes": ["procedural output directory is unavailable"],
            }
        else:
            # The procedural generator is entity-shaped; a species has no entity,
            # so present one built from its declared size.
            entry = resolve_procedural_asset(
                {
                    "entity_id": species["species_id"],
                    "semantic_type": species.get("semantic_type", "scatter"),
                    "asset": requirement,
                    "physical": {"bbox_m": list(size), "dynamic": False, "mass_kg": 0.0},
                },
                Path(procedural_root) / "procedural",
            )
        entry["curated_rel"] = None
        entry["entity_id"] = species["species_id"]
        entry["requires_animation"] = False
        return entry

    farm_brief = brief_text[:200]
    # The category the SPECIES declared, not "prop" for everything.
    #
    # `scatter_asset_requirement` carries a category -- foliage, structure,
    # building_module, prop -- and this resolver discarded it and searched the library's
    # "prop" shelf alone. Combined with `kenney-castle` filing its trees and boulders as
    # `building_module`, that made every curated tree, log and rock invisible to every
    # scatter species. A forest asking for oaks could reach snow-decorated holiday trees
    # and potted houseplants, and nothing else.
    #
    # Measured on one forest run: 13 of 15 assets went to single-image mesh generation,
    # including `spc_oak_tree`, `spc_red_fox` and `spc_white_tailed_deer` -- while
    # `tree-large.glb`, `Fox.glb` and `Deer.glb` sat in the library unused. That is where
    # the shattered dark crowns came from, and most of the build's running time.
    #
    # Animals are the one case the declared category cannot answer: the enum has no word
    # for them, and the library keeps them under `character` because they are rigged. So
    # a species whose own name says animal is looked for there.
    library_category = _SCATTER_LIBRARY_CATEGORY.get(
        str(requirement.get("category") or "prop"), "prop"
    )
    looks_alive = _names_an_animal(
        f"{species.get('semantic_type') or ''} {brief_text}"
    )
    if looks_alive:
        library_category = "character"

    chosen_rel = semantic_pick(
        farm_brief,
        character=looks_alive,
        requires_animation=False,
        subject=str(species.get("semantic_type") or ""),
        library_category=library_category,
    )
    entry = _resolve_one(
        AssetBrief(brief=farm_brief, category="prop", tri_budget=1200),
        curated_path(chosen_rel),
        backend,
        cache,
        work_dir,
        ledger_path,
        embed_base_url,
        palette_hex=requirement.get("palette_hex"),
        # The flag the entity path has always passed and this one never did.
        #
        # Without it `curated_is_match` defaults to False, so a scatter species could
        # never be answered by a library model: the resolver skipped tier 0 and served
        # the cache instead. Measured on a forest whose report LOOKED right --
        # `spc_canopy_tree` recorded `curated_rel: tree_oak.glb`, which is only what the
        # matcher PICKED, while the mesh actually shipped came from cache:
        #
        #     tree_oak.glb        196 triangles   (the library model)
        #     what shipped      1,200 triangles   (a cached generated mesh)
        #
        # Eight of those stood in the render as white shattered crowns. `curated_rel` is
        # the pick, `tier` is the answer, and only the tier tells the truth.
        curated_is_match=(
            chosen_rel is not None
            and getattr(semantic_pick, "last_score", 0.0)
            >= curated_floor(library_category)
        ),
    )
    entry["curated_rel"] = chosen_rel
    entry["entity_id"] = species["species_id"]
    entry["requires_animation"] = False
    return entry


def resolve_spec_assets(
    spec: dict,
    *,
    kit_dir: Path | None = None,
    sfx_dir: Path | None = None,
    cache_dir: Path | None = None,
    work_dir: Path | None = None,
    backend: GenerationBackend | None = None,
    audio_backend: GenerationBackend | None = None,
    ledger_path: str | None = None,
    embed_base_url: str | None = None,
) -> dict[str, dict]:
    """Resolve every prop/enemy/player asset_brief. Returns {label: ResolvedAsset}.

    Meshes and sound take SEPARATE backends on purpose: they are different models
    (TRELLIS vs Stable Audio) that cannot be co-resident in 32 GB, and either can
    be off while the other runs. Pass none and the curated tier ships, exactly as
    before.

    Never raises for a single asset: a brief with no curated fallback and no
    working backend is recorded as unresolved rather than failing the whole job
    (the build still ships the curated kit models it already instances).
    """
    cache = AssetCache(cache_dir) if cache_dir is not None else None
    manifest: dict[str, dict] = {}

    # Condition the whole game's generated assets on one art direction. The
    # backend prepends it to every SDXL prompt; harmless if the backend has no
    # such field (the mock) or the spec has no anchor.
    anchor = spec.get("meta", {}).get("style_anchor", "")
    if backend is not None and anchor and hasattr(backend, "style_anchor"):
        backend.style_anchor = anchor

    def _curated_path(rel: str | None) -> Path | None:
        if rel is None or kit_dir is None:
            return None
        p = kit_dir / rel
        return p if p.is_file() else None

    def _curated_pick(
        brief_text: str,
        default_rel: str | None,
        category: str,
        subject: str | None = None,
    ) -> str | None:
        """The curated model this brief DESCRIBES (S5 "curated >= 0.85"), else the
        deterministic default the writer would have used anyway.

        `category` scopes the library so a character can never match a barrel: the
        floor guards quality, this guards kind.
        """
        if kit_dir is None:
            return default_rel
        library = {
            rel: text
            for rel, text in MODEL_DESCRIPTIONS.items()
            if model_category(rel) == category and (kit_dir / rel).is_file()
        }
        hit = best_curated(
            brief_text,
            library,
            embed_base_url,
            subject=subject,
            category=category,
        )
        if hit is not None:
            rel, score = hit
            log.info("curated tier matched %r -> %s (cosine %.3f)", brief_text[:40], rel, score)
            return rel
        # No embedder, or nothing cleared the cosine floor: fall to the lexical
        # tier so a stated identity still resolves to a model we own. "as a dog"
        # must never ship a capsule just because bge-m3 is offline. Characters
        # only: their default is a capsule (player) or a blind index cycle
        # (enemies), so a keyword hit is pure upside — where props already have a
        # sensible typed default that an elaborate brief ("herb-roasted chicken")
        # would only spuriously override. Props keep semantic-or-default.
        if category == "character":
            kw = keyword_best(brief_text, library)
            if kw is not None:
                rel, score = kw
                log.info(
                    "curated tier matched %r -> %s (keyword %.2f)", brief_text[:40], rel, score
                )
                return rel
        return default_rel

    def _resolve_character_sounds(label: str, character_brief: str, model_rel: str | None) -> None:
        """What this character sounds like DOING each thing it does.

        The curated fallback is the sound set its model family already uses, so a
        failed or absent generator leaves the game sounding exactly as it does
        today — the build never gets quieter for trying.
        """
        if audio_backend is None:
            return  # no generator: the writer's curated banks are already correct
        curated_banks = enemy_sounds(model_rel)
        for activity, sound_brief in activity_sound_briefs(character_brief).items():
            curated_clip = None
            if sfx_dir is not None:
                candidate = sfx_dir / curated_banks[activity][0]
                curated_clip = candidate if candidate.is_file() else None
            manifest[f"sound:{label}:{activity}"] = _resolve_one(
                sound_brief, curated_clip, audio_backend, cache, work_dir,
                ledger_path, embed_base_url,
            )

    entities = spec.get("entities", {})
    for prop in entities.get("props", []):
        brief_obj = prop.get("asset_brief")
        if not brief_obj:
            continue
        # Doors are FUNCTIONAL nodes (the animated LockedDoor), not models — they
        # have no asset by design, so they are skipped, not recorded as a failure.
        if prop.get("interactable_template_id") in FUNCTIONAL_PROPS:
            continue
        default_rel = prop_model(prop.get("interactable_template_id"))
        chosen_rel = _curated_pick(brief_obj["brief"], default_rel, "prop")
        curated = _curated_path(chosen_rel)
        entry = _resolve_one(
            AssetBrief.from_spec(brief_obj), curated, backend, cache, work_dir,
            ledger_path, embed_base_url,
        )
        entry["curated_rel"] = chosen_rel
        manifest[f"prop:{prop['prop_id']}"] = entry

    # The player (schema v2.1.0+). No curated fallback exists: the stand-in is a
    # primitive capsule, not a model — so `fallback=None` and the shipping policy
    # lets any generated body through, correctly, since no motion can be lost.
    player_brief = spec.get("player", {}).get("asset_brief")
    if player_brief:
        # The curated tier can give the player a real body: "a robed wizard" is a
        # model we own, rigged and animated, where a generated one is a statue.
        # No match -> None -> the capsule, and the shipping policy then lets any
        # generated body through because no motion can be lost.
        # Never a bare capsule: if the brief matches no owned body, fall back to a
        # real farm character (an animal for an animal brief, else a humanoid) —
        # a capsule is not an acceptable player. The match still wins when found.
        player_rel = _curated_pick(
            player_brief["brief"], default_character_model(player_brief["brief"]), "character"
        )
        entry = _resolve_one(
            AssetBrief.from_spec(player_brief), _curated_path(player_rel), backend, cache,
            work_dir, ledger_path, embed_base_url,
        )
        entry["curated_rel"] = player_rel
        manifest["player:main"] = entry

    for idx, enemy in enumerate(entities.get("enemies", [])):
        brief_obj = enemy.get("asset_brief")
        if not brief_obj:
            continue
        # The brief chooses the body; the placement index is only the tie-break
        # when the library holds nothing the brief actually describes.
        model_rel = _curated_pick(
            brief_obj["brief"], ENEMY_MODELS[idx % len(ENEMY_MODELS)], "character"
        )
        # Sound follows the body it ends up wearing, not the one the cycle guessed.
        _resolve_character_sounds(f"enemy:{enemy['enemy_id']}", brief_obj["brief"], model_rel)
        entry = _resolve_one(
            AssetBrief.from_spec(brief_obj), _curated_path(model_rel), backend, cache,
            work_dir, ledger_path, embed_base_url,
        )
        entry["curated_rel"] = model_rel
        manifest[f"enemy:{enemy['enemy_id']}"] = entry

    # Composite object BODIES (ADR-0008): the shell a car/house wears UNDER its
    # affordances. Resolved like a prop (a static building_module mesh). We own no
    # curated vehicles/buildings yet, so with no match the body ships only when a
    # generator runs; otherwise the object is its (working) doors alone until a
    # curated vehicle/building kit lands. The affordances never depend on it.
    for obj in entities.get("objects", []):
        brief_text = obj.get("brief")
        if not brief_text:
            continue
        body_brief = AssetBrief(
            brief=brief_text,
            category="building_module",
            tri_budget=int(obj.get("tri_budget", 3000)),
        )
        entry = _resolve_one(
            body_brief, None, backend, cache, work_dir, ledger_path, embed_base_url
        )
        entry["curated_rel"] = None
        manifest[f"object:{obj['object_id']}"] = entry

    return manifest


def _resolve_one(
    brief: AssetBrief,
    curated: Path | None,
    backend: GenerationBackend | None,
    cache: AssetCache | None,
    work_dir: Path | None,
    ledger_path: str | None,
    embed_base_url: str | None = None,
    palette_hex: list[str] | None = None,
    curated_is_match: bool = False,
) -> dict:
    try:
        resolved = resolve_asset(
            brief,
            curated,
            backend=backend,
            cache=cache,
            work_dir=work_dir,
            ledger_path=ledger_path,
            embed_base_url=embed_base_url,
            # Only a MATCH outranks generation; a typed default does not.
            curated_is_match=curated_is_match,
        )
        entry = resolved.to_dict()
    except Exception as exc:  # a single unresolved asset must not fail the job
        # The floor: a sized box, never a hole.
        #
        # The curated tier is meant to guarantee playability -- a failure should
        # degrade the LOOK of a world, not its existence -- but a kind the kit
        # has no model for and generation refuses still fell through to nothing.
        # A farm's tractor (`vehicle`, excluded from generation) and its
        # chickens (an animal asked for as mass content) both came back
        # `unresolved`, the mandatory asset gate failed, and a world that was
        # otherwise complete could not be built. A plain box of roughly the
        # right size is a worse tractor than a tractor and an immeasurably
        # better one than empty space.
        #
        # Everything here is defensive on purpose: this runs only after every
        # other tier has already failed, so it is the one path that must not be
        # able to raise. A previous attempt shipped a NameError here and
        # crashed every run for a day, because nothing exercised it.
        entry = None
        if work_dir is not None:
            try:
                from asset_farm.procedural import resolve_procedural_asset

                # A cube sized by the tri budget's rough scale class. The
                # descriptor rescales it to the entity's declared bbox
                # downstream, so this only has to be a valid, watertight mesh.
                stand_in = {
                    "entity_id": brief.hash(),
                    "semantic_type": brief.category,
                    "asset": {
                        # The builder reads `brief` for lineage; carrying the
                        # real one keeps the manifest honest about what this box
                        # was standing in for.
                        "brief": brief.brief,
                        "procedural_type": "semantic_box",
                        # The one box a viewer is most likely to actually see, so
                        # the planner's colour matters here more than anywhere:
                        # this is the grey box in the render.
                        **({"palette_hex": palette_hex} if palette_hex else {}),
                    },
                    "physical": {"bbox_m": [1.0, 1.0, 1.0]},
                }
                candidate = resolve_procedural_asset(
                    stand_in, Path(work_dir) / "procedural"
                )
                if candidate.get("tier") != "unresolved":
                    candidate.setdefault("notes", []).append(
                        "no curated model and no generation path for this kind "
                        f"({type(exc).__name__}: {exc}); shipped as a sized box"
                    )
                    entry = candidate
            except Exception as floor_exc:  # noqa: BLE001 -- the floor cannot raise
                log.warning("resolution floor unavailable: %s", floor_exc)
        if entry is None:
            entry = ResolvedAsset(
                path=curated or Path(),
                tier="unresolved",
                component="none",
                brief_hash=brief.hash(),
                notes=[f"resolution error: {type(exc).__name__}: {exc}"],
            ).to_dict()

    # What this asset DISPLACED. Lineage should say what you would have seen
    # instead, and the shipping policy needs it to compare the two.
    entry["fallback"] = str(curated) if curated is not None else None
    return entry


def shippable_models(manifest: dict[str, dict]) -> dict[str, Path]:
    """What each entity actually WEARS — `{label: path}` for the project writer.

    Curated picks are included, not just generated ones: since the curated tier
    became semantic, the writer's own default (an index cycle) is no longer
    authoritative — the farm decides the body, the writer only draws it.
    Resolving an asset is still not the same as being allowed to ship it.

    **One rule: a generated asset must be at least as ALIVE as the thing it
    displaces.** Uniqueness is worthless if it costs motion — a static mesh in
    place of a walking skeleton turns a living enemy back into a statue, which is
    a worse game than a curated body that moves.

    That single rule covers every case without naming any of them:

    - a **prop** displaces a static prop -> a unique generated one always wins;
    - an **enemy** that must walk displaces a rigged, animated skeleton -> a raw
      unrigged mesh loses (right species and dead vs. wrong species and alive:
      take alive);
    - a **static character** -- a visitor, a bystander, anything the spec did not
      mark `requires_animation` -- loses no motion by being itself, so the
      generated body wins even against a rigged stand-in.

    "Needs to move" is the entity's own requirement, never a property of whatever
    it displaces. Reading it off the fallback was the bug: the library's only
    humanoid is a rigged skeleton, so every unmatched character looked like it
    was displacing motion, and open-vocabulary worlds filled up with skeletons.

    The rule is written against the mesh's *capabilities*, never against today's
    limitations: the day auto-rigging lands, rigged characters start shipping with
    no change here. Equally, the day the player gains a rigged curated body, the
    same rule starts demanding rigging of generated players — automatically.

    Every rejection is recorded in the manifest entry's notes — the lineage must
    say what was generated AND why it isn't what you see (§11).
    """
    shippable: dict[str, Path] = {}
    for label, entry in manifest.items():
        if label.startswith("sound:"):
            continue  # sound has its own function; this one is about bodies
        if entry.get("tier") not in ("generated", "cache", "curated"):
            continue  # unresolved: nothing to wear
        path = Path(entry["path"])
        if not path.is_file():
            entry.setdefault("notes", []).append("not shipped: resolved file is missing")
            continue

        fallback = entry.get("fallback")
        if fallback is not None and Path(fallback).is_file():
            displaced = mesh_capabilities(Path(fallback))
            caps = mesh_capabilities(path)
            # Motion is only worth a wrong species when this entity actually
            # NEEDS to move. Testing the fallback alone made every unmatched
            # character "displace an animated asset", because the only humanoid
            # in the library is a rigged skeleton — so a jungle visitor shipped
            # as a skeleton purely because its stand-in happened to have clips.
            # A missing flag is read as "needs motion": not knowing is not a
            # reason to lose it.
            needs_animation = entry.get("requires_animation", True)
            if needs_animation and displaced["animated"] and not caps["animated"]:
                entry.setdefault("notes", []).append(
                    f"not shipped: generated mesh is not rigged/animated (skins={caps['skins']}, "
                    f"clips={caps['animations']}) and would replace an animated asset "
                    f"({displaced['animations']} clips); the animated one ships instead so it "
                    "still moves"
                )
                # Structured, not just prose (rule 13): "why am I looking at a
                # skeleton?" has to be answerable in the UI, not only in a log.
                entry["substitution"] = {
                    "code": "GENERATED_BODY_NOT_RIGGED",
                    "shipped": str(fallback),
                    "instead_of": str(path),
                    "reason": (
                        "this entity has to animate and the generated mesh has no rig, "
                        "so a rigged stand-in of the wrong kind ships instead"
                    ),
                    "user_visible": True,
                }
                continue
        shippable[label] = path
    return shippable


def shippable_sounds(manifest: dict[str, dict]) -> dict[str, dict[str, Path]]:
    """Which generated sounds the game may play — `{entity_label: {activity: path}}`.

    Simpler than the model rule, because sound has no aliveness to lose: a clip
    that passed qa_audio is a clip, so a generated one is unique where a curated
    one is shared, and unique wins. Anything that failed generation or QA never
    reaches here — the resolver already fell back to the curated clip, and the
    writer's curated banks cover every activity this doesn't.
    """
    shippable: dict[str, dict[str, Path]] = {}
    for label, entry in manifest.items():
        if not label.startswith("sound:") or entry.get("tier") not in ("generated", "cache"):
            continue
        _, kind, source_id, activity = label.split(":", 3)
        path = Path(entry["path"])
        if not path.is_file():
            entry.setdefault("notes", []).append("not shipped: resolved clip is missing")
            continue
        shippable.setdefault(f"{kind}:{source_id}", {})[activity] = path
    return shippable


def resolution_summary(manifest: dict[str, dict]) -> dict[str, int]:
    """Compact tier counts for the job detail UI: how many generated vs curated."""
    counts: dict[str, int] = {}
    for entry in manifest.values():
        counts[entry["tier"]] = counts.get(entry["tier"], 0) + 1
    return counts
