"""AssetBrief + brief_hash — the content-addressed key for every asset.

`brief_hash` is how the cache, the lineage record, and the artifact filename all
refer to the same asset (§9: "assets keyed by brief_hash"). It is deterministic
and seed-independent: the SAME brief always hashes the same, so a prop authored
identically in two games resolves to one cached asset, and lineage is reproducible.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

# Categories from contracts/game_spec.schema.json $defs.asset_brief.
CATEGORIES = frozenset(
    {
        "prop",
        "building_module",
        "character",
        "foliage",
        "skybox",
        "texture",
        "audio_sfx",
        "audio_loop",
    }
)

# Default triangle ceiling per category when a brief omits tri_budget. Kept
# conservative for the ≤90 MB web build; a brief may raise it up to the schema's
# 20000 cap. Audio categories carry no tri budget.
DEFAULT_TRI_BUDGET: dict[str, int] = {
    "prop": 2000,
    "building_module": 3000,
    "character": 8000,
    "foliage": 1500,
    "skybox": 12,  # a cube; the detail is in the texture, not the mesh
}


@dataclass(frozen=True)
class AssetBrief:
    """One asset the farm must resolve. Mirrors the spec's asset_brief object."""

    brief: str
    category: str
    tri_budget: int | None = None

    def __post_init__(self) -> None:
        if self.category not in CATEGORIES:
            raise ValueError(
                f"unknown asset category {self.category!r}; allowed: {sorted(CATEGORIES)}"
            )
        if not (3 <= len(self.brief) <= 200):
            raise ValueError("brief must be 3..200 characters (matches the schema)")

    @property
    def effective_tri_budget(self) -> int:
        """The tri ceiling QA enforces — the brief's, else the category default."""
        if self.tri_budget is not None:
            return self.tri_budget
        return DEFAULT_TRI_BUDGET.get(self.category, 2000)

    @property
    def is_audio(self) -> bool:
        return self.category in ("audio_sfx", "audio_loop")

    @classmethod
    def from_spec(cls, obj: dict) -> AssetBrief:
        return cls(
            brief=obj["brief"],
            category=obj["category"],
            tri_budget=obj.get("tri_budget"),
        )

    def hash(self) -> str:
        """Stable content address. Canonical JSON (sorted keys) so field order
        and whitespace can never change the key."""
        payload = json.dumps(
            {"brief": self.brief, "category": self.category, "tri_budget": self.tri_budget},
            sort_keys=True,
            separators=(",", ":"),
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]
