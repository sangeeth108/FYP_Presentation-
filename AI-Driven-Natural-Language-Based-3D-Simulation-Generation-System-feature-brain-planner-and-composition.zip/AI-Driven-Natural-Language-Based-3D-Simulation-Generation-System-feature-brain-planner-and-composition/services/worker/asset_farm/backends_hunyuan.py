"""In-process SDXL -> Hunyuan3D-2.1 shape -> GLB on the local CUDA GPU.

The successor to `backends_local`, which used TripoSR. The reason for the swap
is measured rather than aesthetic: TripoSR output was vertex-coloured with a
mean saturation of 5/255 -- grey blobs -- and roughly 120k triangles of slivers
that the visual-semantic gate correctly refused. Hunyuan3D-2.1's shape model
produces watertight, correctly proportioned geometry in ~30 s at ~8 GB peak.

WHAT THIS BACKEND DOES NOT DO, said plainly: Hunyuan3D-2.1 splits shape from
texture into two models, and only the shape half is installed here. The texture
half needs a custom CUDA rasteriser that will not build on this toolchain --
the same obstacle that made TRELLIS unavailable. So the geometry is markedly
better than TripoSR's and carries NO colour at all, where TripoSR carried bad
colour. A flat material is assigned downstream. That is an honest trade, not an
unqualified upgrade, and the asset resolver still prefers procedural forms for
mass content because those carry real materials for a fraction of the cost.

SAFETY (same contract as every backend): any failure raises
`GenerationBackendError`, which the resolver treats as "generation failed" and
falls back to the curated asset. Heavy imports are lazy so the module imports
for tests and for curated-only deployments with no GPU stack. Models load once
per process because a cold load is ~18 s.

MEMORY: the shape model peaks at ~8.2 GB, which the planner's 17.4 GB cannot
join on a 31.8 GB card once anything else is resident. `unload_models()` is the
other half of plan->assets sequencing and must be called when the asset phase
ends.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

from asset_farm.backends import GenerationResult
from asset_farm.backends_gpu import GenerationBackendError
from asset_farm.brief import AssetBrief

log = logging.getLogger(__name__)

# Ledger components (rule 12). PRIMARY is what the manifest attributes the mesh to.
COMPONENTS = ("sdxl", "hunyuan3d-2.1-shape", "u2net")
PRIMARY_COMPONENT = "hunyuan3d-2.1-shape"

# One art direction cannot rig a character, so generation stays mesh-only for
# these kinds; characters resolve to a curated rigged body rather than a statue.
_MESH_CATEGORIES = frozenset({"prop", "building_module", "foliage", "environment"})

# Sampling settings. 30 steps at octree resolution 256 is the point past which
# measured surface detail stopped improving for the sizes this system ships.
_INFERENCE_STEPS = 30
_OCTREE_RESOLUTION = 256
_GUIDANCE_SCALE = 5.0

# A generated body is normalised to this longest dimension in metres; the
# descriptor scales it to the entity's declared bbox afterwards.
TARGET_SIZE_M = 1.5

_pipeline = None


def _seed(brief: AssetBrief) -> int:
    """Stable per-brief seed: the same brief regenerates the same asset (rule 14)."""
    return int(brief.hash(), 16) % (2**31)


def unload_models() -> bool:
    """Free the shape model from the GPU. Returns True if anything was freed.

    The planner needs 17.4 GB and this needs 8.2 GB; on a 31.8 GB card they fit
    together only until anything else appears, so the worker sequences its modes
    and calls this when the asset phase ends.
    """
    global _pipeline
    import gc

    freed = _pipeline is not None
    _pipeline = None
    gc.collect()
    try:
        import torch

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:  # noqa: BLE001 -- torch may be absent in curated-only deploys
        pass
    return freed


class Hunyuan3DBackend:
    """Real, in-process SDXL -> Hunyuan3D-2.1 shape -> GLB pipeline."""

    component = PRIMARY_COMPONENT

    def __init__(
        self,
        checkpoint_dir: str = "",
        package_dir: str = "",
        device: str = "cuda",
        concept_vision_base_url: str = "",
        concept_vision_model: str = "",
        concept_vision_timeout_seconds: float = 180.0,
        require_concept_vision: bool = True,
    ) -> None:
        self.checkpoint_dir = checkpoint_dir or os.environ.get("HUNYUAN3D_CHECKPOINT", "")
        self.package_dir = package_dir or os.environ.get("HUNYUAN3D_PACKAGE", "")
        self.device = device
        self.concept_vision_base_url = concept_vision_base_url
        self.concept_vision_model = concept_vision_model
        self.concept_vision_timeout_seconds = concept_vision_timeout_seconds
        self.require_concept_vision = require_concept_vision

    # -- model loading -----------------------------------------------------

    def _assert_configured(self) -> tuple[Path, Path]:
        """Check the weights are present. Cheap, and called before anything costly."""
        if not self.checkpoint_dir:
            raise GenerationBackendError(
                "Hunyuan3D checkpoint directory is not configured "
                "(set HUNYUAN3D_CHECKPOINT or hunyuan3d_checkpoint_dir)"
            )
        checkpoint = Path(self.checkpoint_dir)
        weights = checkpoint / "model.fp16.ckpt"
        config = checkpoint / "config.yaml"
        for path in (weights, config):
            if not path.is_file():
                raise GenerationBackendError(f"Hunyuan3D asset missing: {path}")
        return weights, config

    def _load(self):
        """Load the shape pipeline once per process."""
        global _pipeline
        if _pipeline is not None:
            return _pipeline

        weights, config = self._assert_configured()

        # The published package nests its importable root one level down, which
        # is not obvious and produces a confusing ModuleNotFoundError otherwise.
        if self.package_dir:
            import sys

            root = str(Path(self.package_dir))
            if root not in sys.path:
                sys.path.insert(0, root)

        try:
            import torch
            from hy3dshape.pipelines import Hunyuan3DDiTFlowMatchingPipeline
        except Exception as exc:  # noqa: BLE001
            raise GenerationBackendError(
                f"Hunyuan3D shape package unavailable: {type(exc).__name__}: {exc}"
            ) from exc

        try:
            _pipeline = Hunyuan3DDiTFlowMatchingPipeline.from_single_file(
                ckpt_path=str(weights),
                config_path=str(config),
                device=self.device,
                dtype=torch.float16,
            )
        except Exception as exc:  # noqa: BLE001
            raise GenerationBackendError(
                f"Hunyuan3D shape model failed to load: {type(exc).__name__}: {exc}"
            ) from exc
        return _pipeline

    # -- generation --------------------------------------------------------

    def generate(self, brief: AssetBrief, out_dir: Path) -> GenerationResult:
        if brief.is_audio:
            raise GenerationBackendError("Hunyuan3DBackend makes meshes, not audio")
        if brief.category not in _MESH_CATEGORIES:
            # Characters must not ship as a rig-less statue.
            raise GenerationBackendError(
                f"Hunyuan3DBackend does not generate {brief.category!r} "
                "(rig-less mesh generation is for props/buildings/foliage only)"
            )

        # Configuration is checked BEFORE the concept image, because that image
        # costs a full diffusion pass on the GPU and there is no point paying it
        # only to discover the mesh model was never configured.
        self._assert_configured()

        out_dir.mkdir(parents=True, exist_ok=True)
        stem = brief.hash()

        # Stage 1: a concept image. Reuses the SDXL path already proven by the
        # TripoSR backend rather than duplicating prompt engineering.
        from asset_farm.backends_local import LocalGenBackend

        concept = LocalGenBackend(
            device=self.device,
            concept_vision_base_url=self.concept_vision_base_url,
            concept_vision_model=self.concept_vision_model,
            concept_vision_timeout_seconds=self.concept_vision_timeout_seconds,
            require_concept_vision=self.require_concept_vision,
        )
        try:
            raw = concept._sdxl_image(brief, out_dir / f"{stem}_concept.png")
            image_path = concept._remove_background(
                raw, out_dir / f"{stem}_concept_nobg.png"
            )
        except GenerationBackendError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise GenerationBackendError(
                f"concept image generation failed: {type(exc).__name__}: {exc}"
            ) from exc

        # Stage 2: image -> mesh.
        try:
            import torch
            from PIL import Image

            pipeline = self._load()
            image = Image.open(image_path).convert("RGBA")
            mesh = pipeline(
                image=image,
                num_inference_steps=_INFERENCE_STEPS,
                octree_resolution=_OCTREE_RESOLUTION,
                guidance_scale=_GUIDANCE_SCALE,
                generator=torch.manual_seed(_seed(brief)),
            )[0]
        except GenerationBackendError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise GenerationBackendError(
                f"Hunyuan3D shape generation failed: {type(exc).__name__}: {exc}"
            ) from exc

        # Stage 3: decimate to the brief's budget and normalise.
        path = out_dir / f"{stem}.glb"
        try:
            tri_count = _finalise(mesh, brief, path)
        except Exception as exc:  # noqa: BLE001
            raise GenerationBackendError(
                f"Hunyuan3D mesh post-processing failed: {type(exc).__name__}: {exc}"
            ) from exc

        return GenerationResult(path=path, component=self.component, tri_count=tri_count)


def _finalise(mesh, brief: AssetBrief, path: Path) -> int:
    """Decimate, recentre, scale and export. Returns the final triangle count.

    The raw model produces ~417k faces, which is two orders of magnitude over
    the browser budget, so decimation is mandatory rather than an optimisation.
    """
    import numpy as np
    import trimesh

    if not isinstance(mesh, trimesh.Trimesh):
        mesh = trimesh.Trimesh(vertices=np.asarray(mesh.vertices), faces=np.asarray(mesh.faces))

    budget = max(200, int(getattr(brief, "tri_budget", 2000)))
    if len(mesh.faces) > budget:
        try:
            import fast_simplification

            vertices, faces = fast_simplification.simplify(
                mesh.vertices, mesh.faces, target_count=budget
            )
            mesh = trimesh.Trimesh(vertices=vertices, faces=faces)
        except Exception as exc:  # noqa: BLE001
            # Decimation is best-effort: a heavy mesh still beats no mesh, and
            # the QA gate will reject it if it is genuinely unusable.
            log.warning("Hunyuan3D decimation unavailable (%s); shipping full mesh", exc)

    # Normalise: recentre on the origin and scale the longest axis to target.
    mesh.apply_translation(-mesh.bounds.mean(axis=0))
    longest = float(max(mesh.extents)) or 1.0
    mesh.apply_scale(TARGET_SIZE_M / longest)

    # The shape model returns geometry only, so give it a neutral material
    # rather than leaving the exporter to invent one.
    mesh.visual = trimesh.visual.TextureVisuals(
        material=trimesh.visual.material.PBRMaterial(
            baseColorFactor=[168, 162, 152, 255],
            metallicFactor=0.0,
            roughnessFactor=0.85,
        )
    )
    path.write_bytes(trimesh.Scene(mesh).export(file_type="glb"))
    return int(len(mesh.faces))
