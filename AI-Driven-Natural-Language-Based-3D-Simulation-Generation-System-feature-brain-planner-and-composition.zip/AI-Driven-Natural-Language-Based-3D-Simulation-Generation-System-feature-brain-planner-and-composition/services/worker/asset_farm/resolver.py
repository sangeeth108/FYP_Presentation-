"""S5 asset resolution — the deterministic decision tree.

    cache -> curated -> generate -> QA -> curated fallback

Given an AssetBrief and the curated asset the caller already knows (from
asset_kit), decide where the concrete file comes from and record why. The single
AI step (the backend) is optional and license-checked; everything else is
deterministic and seeded.

The build NEVER blocks: if generation is unavailable, unlicensed, fails, or its
output flunks QA, the curated asset ships. Every outcome — which tier won, and
why the others didn't — is captured in the ResolvedAsset for the lineage record.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

from asset_farm.backends import GenerationBackend
from asset_farm.brief import AssetBrief
from asset_farm.cache import AssetCache
from asset_farm.license_guard import LicenseError, assert_product_safe
from asset_farm.qa_audio import AudioQAReport, qa_audio
from asset_farm.qa_gate import QAReport, qa_mesh
from asset_farm.semantic import SIMILARITY_FLOOR

log = logging.getLogger(__name__)


@dataclass
class ResolvedAsset:
    path: Path
    tier: str  # "cache" | "generated" | "curated"
    component: str  # the licensed source of the shipped asset
    brief_hash: str
    qa: QAReport | AudioQAReport | None = None  # whichever gate judged it
    notes: list[str] = field(default_factory=list)  # why the higher tiers were skipped

    def to_dict(self) -> dict:
        return {
            "path": str(self.path),
            "tier": self.tier,
            "component": self.component,
            "brief_hash": self.brief_hash,
            "qa": self.qa.to_dict() if self.qa else None,
            "notes": self.notes,
        }


CURATED_COMPONENT = "kaykit-dungeon-remastered"  # the vetted CC0 fallback kit


# Categories whose assets must carry a skeleton. A cached mesh is reused on a brief
# HASH, and the hash says nothing about rigging -- so an unrigged mesh once written under
# a character's brief is served forever after, to every run.
#
# Measured: Phase A's mesh generator produced an unrigged dog, it was cached under
# `f33cb98b1217b2a3`, and from then on every run -- the unit tests included -- resolved
# the controlled actor from cache as a statue, silently beating the curated Husky and its
# 24 clips that was sitting right there as the fallback.
_RIGGED_CATEGORIES = frozenset({"character"})

# Generators this project has replaced. A cached asset from one of them must not be
# served, because the cache is consulted BEFORE the curated library and before
# generation -- so a blob made by a superseded generator outranks every better answer
# that has since become available, permanently and silently.
#
# Measured on run_43472534e4a94d049e2d9ae768f277f6, which published 17/18 and looked
# exactly like the runs before it: 424 of 428 cached assets came from `triposr`, and of
# eighteen resolved assets **zero** used the 1,034-model curated library vendored the
# same day. Every dwelling was a TripoSR blob the cache had held since July.
#
# The cache is for not repeating expensive work. It is not for freezing the worst answer
# the system ever gave.
_SUPERSEDED_COMPONENTS = frozenset({"triposr"})


def _cache_entry_is_current(entry) -> bool:
    """Whether this cached asset came from a generator we still stand behind."""
    return getattr(entry, "component", None) not in _SUPERSEDED_COMPONENTS


def _cache_entry_names_the_same_kind(brief: AssetBrief, path) -> bool:
    """Whether a cached LIBRARY model is still the same kind of thing as this brief.

    The cache remembers answers, including the wrong ones. `names_the_same_kind` stopped
    the matcher offering a Cow for a squirrel, but a Cow already written into the cache by
    an earlier run is served straight back without the matcher being consulted at all.
    Measured immediately after the gate shipped:

        ent_stump -> cabin-roof-point.glb      served from cache, tier "cache"
        ent_cedar -> structure-canvas.glb      served from cache, tier "cache"

    Only entries pointing INTO the curated library are checked. A generated mesh is named
    by its brief hash and has no words to compare, so there is nothing to disagree with --
    and this must never reject a generated asset merely for being unnamed.

    Rejecting only sends the brief on down the ladder, exactly as a cache miss does.
    """
    text = str(path).replace("\\", "/")
    if "/content/kits/" not in text and "content/kits/" not in text:
        return True  # not a library model; nothing to compare
    from asset_farm.curated_match import names_the_same_kind

    return names_the_same_kind(brief.brief, Path(text).stem.replace("-", " "))


def _cache_entry_satisfies(brief: AssetBrief, report) -> bool:
    """Whether a cached asset is still an answer to THIS brief.

    QA asks "is this a usable mesh"; it does not ask "is this the KIND of thing that was
    requested". A rig cannot be added afterwards, so a character served from cache
    without one is a dead end no later stage can repair: it fails
    `asset_animation_compatibility` and takes the whole run with it.
    """
    if brief.category not in _RIGGED_CATEGORIES:
        return True
    capabilities = getattr(report, "capabilities", None) or {}
    return bool(capabilities.get("rigged"))


def resolve_asset(
    brief: AssetBrief,
    curated_fallback: Path | None,
    *,
    backend: GenerationBackend | None = None,
    cache: AssetCache | None = None,
    work_dir: Path | None = None,
    ledger_path: str | None = None,
    embed_base_url: str | None = None,
    curated_is_match: bool = False,
) -> ResolvedAsset:
    """Resolve one brief to a concrete, QA-passed, product-licensed asset.

    `curated_is_match` says the curated path is a MODEL THE LIBRARY MATCHED, not the
    typed default the writer would have used anyway. It is what separates "we own this
    exact thing" from "here is a barrel", and only the former outranks generation.
    """
    brief_hash = brief.hash()
    notes: list[str] = []

    # A brief embedding, computed once and shared by the semantic-cache lookup and
    # the store below. None unless an embedder is configured and reachable.
    embedding = _embed_brief(brief, embed_base_url, notes)

    # Tier 0 — the library MATCHED this brief, so nothing else can do better.
    #
    # A DELIBERATE deviation from CLAUDE.md S5, which orders this
    # cache -> curated -> generate. That order assumes the cache holds the best
    # answer the system had; once a library is vendored, it does not. The code ran
    # cache -> generate -> curated-as-fallback, so a matched library model was only ever
    # reached when generation FAILED. Measured on
    # run_09ad660cc1664a3680347556ba25a8c1: nine assets were generated and **zero** of
    # twenty used the 1,034-model library, including two dwellings that
    # `kenney-city/building-a.glb` matches directly.
    #
    # Moving it ahead of the CACHE as well, because a cached asset is only the best
    # answer of whenever it was made: re-resolving the same spec after one generating
    # run still gave 0 of 20 library models, every one served from a cache written
    # minutes earlier. A model somebody modelled beats one inferred from a picture,
    # and it is free and instant, so there is no cost argument for the stale one.
    #
    # Only a real match qualifies -- a typed DEFAULT (a barrel for an unknown prop)
    # must still lose to both cache and generation, which is why `curated_is_match`
    # exists rather than testing `curated_fallback is not None`.
    if curated_is_match and curated_fallback is not None and curated_fallback.is_file():
        report = _qa_resolved_path(curated_fallback, brief)
        if report.passed and _cache_entry_satisfies(brief, report):
            notes.append("curated match preferred over generation")
            return ResolvedAsset(
                curated_fallback,
                "curated",
                "curated-library",
                brief_hash,
                qa=report,
                notes=notes,
            )
        notes.append("curated match did not qualify; falling through to generation")

    # Tier 1a — exact cache. An identical brief already resolved: reuse it.
    if cache is not None:
        hit = cache.get(brief_hash)
        if hit is not None:
            if not _cache_entry_is_current(hit):
                notes.append(
                    f"exact cache entry ignored: made by {hit.component!r}, "
                    "which has been superseded"
                )
                hit = None
            elif not _cache_entry_names_the_same_kind(brief, hit.path):
                notes.append(
                    f"exact cache entry ignored: {Path(str(hit.path)).name!r} is not "
                    "the kind of thing this brief asks for"
                )
                hit = None
        if hit is not None:
            report = _qa_resolved_path(hit.path, brief)
            if report.passed and not _cache_entry_satisfies(brief, report):
                notes.append(
                    f"exact cache entry rejected: a {brief.category} needs a rig "
                    "and this mesh has none"
                )
            elif report.passed:
                return ResolvedAsset(
                    hit.path,
                    "cache",
                    hit.component,
                    brief_hash,
                    qa=report,
                    notes=notes,
                )
            else:
                notes.append(
                    "exact cache entry rejected by QA: "
                    + ",".join(error.code for error in report.errors)
                )
    notes.append("cache miss")

    # Tier 1b — semantic cache. A *similar* brief (cosine >= 0.92) already
    # generated an asset: reuse it rather than spend minutes regenerating. Only
    # when we have an embedding; degrades silently to generation otherwise.
    if cache is not None and embedding is not None:
        near = cache.nearest(embedding, SIMILARITY_FLOOR)
        if near is not None:
            entry, score = near
            if not _cache_entry_names_the_same_kind(brief, entry.path):
                notes.append(
                    f"semantic cache entry ignored: {Path(str(entry.path)).name!r} is "
                    "not the kind of thing this brief asks for"
                )
                entry = None
            elif not _cache_entry_is_current(entry):
                notes.append(
                    f"semantic cache entry ignored: made by {entry.component!r}, "
                    "which has been superseded"
                )
                entry = None
        if cache is not None and embedding is not None and near is not None and entry is not None:
            report = _qa_resolved_path(entry.path, brief)
            if report.passed and not _cache_entry_satisfies(brief, report):
                notes.append(
                    f"semantic cache entry rejected (cosine {score:.3f}): a "
                    f"{brief.category} needs a rig and this mesh has none"
                )
            elif report.passed:
                notes.append(f"semantic cache hit (cosine {score:.3f})")
                return ResolvedAsset(
                    entry.path,
                    "cache",
                    entry.component,
                    brief_hash,
                    qa=report,
                    notes=notes,
                )
            notes.append(
                "semantic cache entry rejected by QA: "
                + ",".join(error.code for error in report.errors)
            )

    # Tier 3 — generate (tier 2, curated, is the fallback below). Only attempt it
    # when a backend exists AND its model is cleared for the product path. An
    # unlicensed backend is skipped, loudly, never silently shipped.
    # Audio used to be excluded here because the QA step below could only judge a
    # mesh. It is gated by qa_audio now, so a sound generator is a first-class
    # backend — the caller passes whichever backend can build THIS category.
    if backend is not None and work_dir is not None:
        try:
            assert_product_safe(backend_component(backend), ledger_path)
        except LicenseError as exc:
            log.warning("generation skipped — %s", exc)
            notes.append(f"generation skipped: {exc.reason}")
        else:
            resolved = _try_generate(brief, backend, cache, work_dir, brief_hash, notes, embedding)
            if resolved is not None:
                return resolved

    # Tier 2 — curated. Always available, always valid: the floor that guarantees
    # the build never blocks.
    if curated_fallback is not None and curated_fallback.is_file():
        report = _qa_resolved_path(curated_fallback, brief)
        if not report.passed:
            notes.append(
                "curated fallback rejected by QA: "
                + ",".join(error.code for error in report.errors)
            )
            raise ResolutionError(
                code="NO_VALID_ASSET",
                message=f"curated fallback for {brief.category} failed deterministic QA",
                brief_hash=brief_hash,
            )
        return ResolvedAsset(
            curated_fallback,
            "curated",
            CURATED_COMPONENT,
            brief_hash,
            qa=report,
            notes=notes,
        )

    raise ResolutionError(
        code="NO_ASSET",
        message=f"no asset for {brief.category} brief and no curated fallback given",
        brief_hash=brief_hash,
    )


def _embed_brief(
    brief: AssetBrief, embed_base_url: str | None, notes: list[str]
) -> list[float] | None:
    """Embed the brief for the semantic tier. None if no embedder or it is down —
    the resolver then behaves exactly as the exact-match-only version did."""
    if not embed_base_url:
        return None
    from asset_farm.semantic import embed

    vector = embed(brief.brief, embed_base_url)
    if vector is None:
        notes.append("embedder unavailable — semantic tier skipped")
    return vector


def _try_generate(
    brief: AssetBrief,
    backend: GenerationBackend,
    cache: AssetCache | None,
    work_dir: Path,
    brief_hash: str,
    notes: list[str],
    embedding: list[float] | None = None,
) -> ResolvedAsset | None:
    """Generate + QA. Returns the accepted asset, or None to fall through to curated."""
    try:
        result = backend.generate(brief, work_dir)
    except Exception as exc:  # a backend crash must never crash the job
        log.warning("generation failed for %s: %s", brief_hash, exc)
        # The message, not just the class. Measured: 68 stored failures all read
        # "generation failed: GenerationBackendError" and none could be diagnosed,
        # because the reason -- which stage, which model, which timeout -- was logged
        # and then discarded. The note is the record that survives the run.
        notes.append(f"generation failed: {type(exc).__name__}: {exc}"[:400])
        return None

    # Each kind of asset is judged by its own gate: a WAV cannot be parsed as a
    # GLB, and a mesh has no duration. Audio is held to the same standard as a
    # mesh — produced or curated, nothing ships un-gated.
    report = _qa_resolved_path(result.path, brief)
    if not report.passed:
        notes.append("generated asset failed QA: " + ",".join(e.code for e in report.errors))
        return None

    if cache is not None:
        # Store the embedding too, so a later *similar* brief hits the semantic tier.
        tri_count = None if brief.is_audio else report.tri_count
        entry = cache.put(brief_hash, result.path, result.component, tri_count, embedding)
        path = entry.path
    else:
        path = result.path
    return ResolvedAsset(path, "generated", result.component, brief_hash, qa=report, notes=notes)


def _qa_resolved_path(path: Path, brief: AssetBrief) -> QAReport | AudioQAReport:
    """Every resolution tier is checked; cache and curated are not trust bypasses."""
    return qa_audio(path, brief) if brief.is_audio else qa_mesh(path, brief)


def backend_component(backend: GenerationBackend) -> str:
    """The ledger component a backend declares (attribute or method)."""
    component = getattr(backend, "component", None)
    if callable(component):
        component = component()
    if not component:
        raise LicenseError("<unknown-backend>", "backend declares no ledger component")
    return component


class ResolutionError(RuntimeError):
    def __init__(self, code: str, message: str, brief_hash: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.brief_hash = brief_hash

    def to_dict(self) -> dict:
        return {"code": self.code, "message": self.message, "brief_hash": self.brief_hash}
