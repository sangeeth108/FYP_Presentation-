"""The ablation conditions A–F, as data.

Each is a set of toggles on the SHIPPED pipeline (`run_benchmark._run_one`), not
a fork of it — an ablation that runs different code measures the fork. Adding a
condition is a row here, not a new runner.

The comparison the dissertation actually turns on is **C vs A**: does the
deterministic spine + gates + repair beat one-shot free generation? Everything
else isolates one contribution:

    A  one-shot free LLM            the baseline we expect to beat (NOT the product)
    B  structured, no repair        what the schema alone buys
    C  structured + repair          the product path
    D  C + RAG                      what retrieval buys        (RQ3)
    E  C + tuned 8B                 what fine-tuning buys      (RQ4, needs P4 weights)
    F  deterministic assembly       vs free LLM assembly       (see note below)

Ablation A is deliberately NOT implemented as a code path in this system: free
LLM gameplay generation is banned (CLAUDE.md rule 10, L5), and building it just to
lose to it would mean shipping the thing the whole architecture exists to avoid.
It is measured as an EXTERNAL baseline — a separate script prompting the same
model for a whole game with no schema, no registry, no gates — and scored by the
same gates afterwards. Same for F's "free assembly" arm.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from dataclasses import dataclass, field

_OLLAMA = os.environ.get("LLM_BASE_URL", "http://127.0.0.1:11434")


def _ollama_serves(model: str) -> bool:
    """Does the local model server actually hold this model?

    Ollama reports names as `name:tag`; a condition names the bare model, so a
    plain equality test says no to a model that is present. Compare on the part
    before the colon as well as the whole string.
    """
    try:
        with urllib.request.urlopen(f"{_OLLAMA}/api/tags", timeout=5) as response:
            tags = json.loads(response.read()).get("models", [])
    except (urllib.error.URLError, OSError, ValueError, TimeoutError):
        return False
    names = {entry.get("name", "") for entry in tags}
    return model in names or any(name.split(":", 1)[0] == model for name in names)


@dataclass(frozen=True)
class Condition:
    """One arm of the study. `toggles` are forwarded to `run_benchmark._run_one`."""

    id: str
    label: str
    question: str  # what this arm exists to answer
    toggles: dict = field(default_factory=dict)
    external: bool = False  # not a toggle on our pipeline; run by a separate harness
    requires: str = ""  # what must exist first (empty = runnable today)

    def is_runnable(self) -> bool:
        """Whether this arm can run NOW, checked rather than declared.

        `requires` used to gate this on its own, which made it a comment that
        happened to block execution: condition E stayed unrunnable after its
        model existed, because the string describing the precondition was still
        set. An arm naming a model is now gated on the server actually holding
        it, so the answer tracks reality in both directions.
        """
        if self.external:
            return False
        model = self.toggles.get("model")
        if model:
            return _ollama_serves(model)
        return not self.requires


CONDITIONS: dict[str, Condition] = {
    "A": Condition(
        id="A",
        label="one-shot free generation",
        question="does an unstructured LLM produce a playable game at all?",
        external=True,
        requires="an external baseline harness (free generation is banned in-product, rule 10)",
    ),
    "B": Condition(
        id="B",
        label="structured, no repair",
        question="what does the schema + registry buy on their own?",
        toggles={"use_llm": True, "repair": False, "rag": False},
    ),
    "C": Condition(
        id="C",
        label="structured + repair (the product path)",
        question="what does bounded localized repair add on top of structure?",
        toggles={"use_llm": True, "repair": True, "rag": False},
    ),
    "D": Condition(
        id="D",
        label="structured + repair + RAG",
        question="does retrieving design knowledge improve controllability? (RQ3)",
        toggles={"use_llm": True, "repair": True, "rag": True},
    ),
    "E": Condition(
        id="E",
        label="tuned 8B vs untuned planner",
        question="does distillation match the teacher at a fraction of the cost? (RQ4)",
        toggles={"use_llm": True, "repair": True, "rag": True, "model": "promptplay-planner-8b"},
        requires="a fine-tuned model served by Ollama (docs/runbooks/FINE_TUNING.md)",
    ),
    "F": Condition(
        id="F",
        label="deterministic assembly vs free LLM assembly",
        question="does deterministic assembly beat letting the LLM write the scene?",
        external=True,
        requires="an external baseline harness (LLM-authored assembly is banned, rule 10)",
    ),
    # The control. Not lettered in the plan, but a study without it cannot say
    # whether the LLM contributed anything at all: rules mode is the same spine
    # with the planner removed.
    "R": Condition(
        id="R",
        label="rules-mode control (no LLM)",
        question="how much of the pass rate is the deterministic spine alone?",
        toggles={"use_llm": False, "repair": True, "rag": False},
    ),
}


def runnable() -> list[Condition]:
    """Conditions that can run right now, in report order."""
    return [c for c in CONDITIONS.values() if c.is_runnable()]
