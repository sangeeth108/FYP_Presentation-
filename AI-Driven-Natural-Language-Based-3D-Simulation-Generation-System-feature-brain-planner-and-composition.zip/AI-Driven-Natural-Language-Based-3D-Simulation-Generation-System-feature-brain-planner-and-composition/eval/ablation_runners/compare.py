"""Turn ablation runs into a defensible results table.

    python eval/ablation_runners/compare.py eval/reports/ablation_*.json
    python eval/ablation_runners/compare.py --baseline R eval/reports/*.json

Reads the JSON the runners wrote; runs no games. Re-running a GPU-hour to
recompute a p-value would be absurd, so analysis is a separate step over the
artifacts — and the artifacts carry their seeds and prompt-set version, so a
result can be regenerated exactly (eval/README.md).

Pairing is by (prompt_id, replicate): the arms saw the SAME prompt with the SAME
seed, so the comparison is paired. Unpaired arms are refused rather than silently
compared, because comparing different prompt sets measures the prompt sets.

Test choice is per metric, not per convenience:
    pass / schema_valid / played  (paired binary)     -> McNemar exact
    latency                       (paired continuous) -> Wilcoxon signed-rank
See eval/metrics/significance.py for why Wilcoxon on binary is a false-positive
machine.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "eval"))

from metrics.significance import (  # noqa: E402
    bootstrap_ci,
    cliffs_delta,
    holm_bonferroni,
    mcnemar_exact,
    wilcoxon,
)

BINARY_METRICS = ("passed", "schema_valid", "genre_match")
CONTINUOUS_METRICS = ("latency_ms",)


def _load(paths: list[Path]) -> dict[str, dict]:
    """condition id -> {"summary":…, "rows":…}, latest file wins."""
    arms: dict[str, dict] = {}
    for path in paths:
        data = json.loads(path.read_text(encoding="utf-8"))
        for cond_id, payload in data.get("conditions", {}).items():
            arms[cond_id] = payload
    return arms


def _key(row: dict) -> tuple:
    return (row["prompt_id"], row["replicate"])


def _paired(a: dict, b: dict) -> tuple[list[dict], list[dict]]:
    """Rows of a and b over the prompts they SHARE, aligned and ordered."""
    by_a = {_key(r): r for r in a["rows"]}
    by_b = {_key(r): r for r in b["rows"]}
    shared = sorted(set(by_a) & set(by_b))
    if not shared:
        raise SystemExit(
            f"{a['summary']['condition']} and {b['summary']['condition']} share no "
            "(prompt, seed) pairs — they cannot be compared. Were they run on the "
            "same prompt-set version and seeds?"
        )
    return [by_a[k] for k in shared], [by_b[k] for k in shared]


def _metric(row: dict, name: str) -> float:
    if name == "passed":
        return 1.0 if row["verdict"] == "PASS" else 0.0
    if name == "schema_valid":
        return 1.0 if row["schema_valid"] else 0.0
    if name == "genre_match":
        return 1.0 if row["genre_match"] else 0.0
    return float(row[name])


def compare(arms: dict[str, dict], baseline: str) -> dict:
    if baseline not in arms:
        raise SystemExit(f"baseline {baseline!r} not in the loaded runs: {sorted(arms)}")

    comparisons: dict[str, dict] = {}
    p_values: dict[str, float] = {}

    for cond_id, arm in sorted(arms.items()):
        if cond_id == baseline:
            continue
        rows_x, rows_y = _paired(arm, arms[baseline])
        per_metric: dict[str, dict] = {}

        for name in BINARY_METRICS + CONTINUOUS_METRICS:
            x = [_metric(r, name) for r in rows_x]
            y = [_metric(r, name) for r in rows_y]
            if name in BINARY_METRICS:
                result = mcnemar_exact([int(v) for v in x], [int(v) for v in y])
            else:
                result = wilcoxon(x, y)
            delta, magnitude = cliffs_delta(x, y)
            lo, hi = bootstrap_ci([xi - yi for xi, yi in zip(x, y, strict=True)])
            key = f"{cond_id}_vs_{baseline}:{name}"
            p_values[key] = result.p_value
            per_metric[name] = {
                **result.to_dict(),
                "mean_arm": round(sum(x) / len(x), 4),
                "mean_baseline": round(sum(y) / len(y), 4),
                "cliffs_delta": round(delta, 4),
                "magnitude": magnitude,
                "mean_difference_ci95": [round(lo, 4), round(hi, 4)],
                "holm_key": key,
            }
        comparisons[cond_id] = {
            "label": arm["summary"]["label"],
            "question": arm["summary"]["question"],
            "paired_n": len(rows_x),
            "metrics": per_metric,
        }

    # One family: every comparison in this report is corrected together.
    corrected = holm_bonferroni(p_values)
    for block in comparisons.values():
        for metric in block["metrics"].values():
            metric["holm"] = corrected[metric.pop("holm_key")]
    return {"baseline": baseline, "comparisons": comparisons, "family_size": len(p_values)}


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("files", nargs="+", type=Path)
    ap.add_argument("--baseline", default="R", help="the arm everything is compared against")
    ap.add_argument("--out", type=Path, default=None)
    args = ap.parse_args(argv)

    arms = _load(args.files)
    if len(arms) < 2:
        raise SystemExit(f"need >=2 conditions to compare; loaded: {sorted(arms)}")

    report = compare(arms, args.baseline)

    print(f"baseline: {args.baseline}  ({arms[args.baseline]['summary']['label']})")
    print(f"family: {report['family_size']} tests, Holm-Bonferroni corrected together\n")
    header = (
        f"{'arm':4s} {'metric':14s} {'arm':>8s} {'base':>8s} "
        f"{'p':>8s} {'p_holm':>8s} {'sig':>4s}  effect"
    )
    print(header)
    print("-" * len(header))
    for cond_id, block in report["comparisons"].items():
        for name, m in block["metrics"].items():
            sig = "YES" if m["holm"]["significant"] else "-"
            print(
                f"{cond_id:4s} {name:14s} {m['mean_arm']:>8.3f} {m['mean_baseline']:>8.3f} "
                f"{m['p_value']:>8.4f} {m['holm']['p_adjusted']:>8.4f} {sig:>4s}  "
                f"{m['cliffs_delta']:+.3f} ({m['magnitude']})"
            )
        print()

    print("Cliff's delta is DOMINANCE, not magnitude — read it for direction and")
    print("consistency, and the means above for how much. A 'large' delta can sit")
    print("on a difference no player could perceive.")

    if args.out:
        args.out.write_text(json.dumps(report, indent=2), encoding="utf-8", newline="\n")
        print(f"\nwrote {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
