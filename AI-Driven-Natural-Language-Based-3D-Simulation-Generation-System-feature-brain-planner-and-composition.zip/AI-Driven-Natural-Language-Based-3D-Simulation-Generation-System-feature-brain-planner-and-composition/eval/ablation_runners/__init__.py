"""Ablation conditions (eval/README.md: A–F).

The dissertation's central claim is that **reliability comes from the
architecture, not the model** — a deterministic spine, gates, and bounded repair.
An ablation is how that claim gets tested instead of asserted: run the *same*
frozen prompts through the *same* pipeline with one thing removed, and measure
what breaks.

Every condition here is a set of toggles on the production path, never a fork of
it. If an ablation runs different code from the product, it measures the fork.
"""
