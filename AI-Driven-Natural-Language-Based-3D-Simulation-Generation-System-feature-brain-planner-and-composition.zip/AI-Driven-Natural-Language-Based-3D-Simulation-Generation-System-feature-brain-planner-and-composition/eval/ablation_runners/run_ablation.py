"""Run the ablations: frozen prompts × 3 seeds × condition (eval/README.md).

    python eval/ablation_runners/run_ablation.py --conditions R              # no GPU
    python eval/ablation_runners/run_ablation.py --conditions B,C,D --seeds 3
    python eval/ablation_runners/run_ablation.py --list

Every arm is the SAME pipeline with one thing toggled — never a fork, or the
study measures the fork. Results are written per-run with their seeds and the
prompt-set version, because a result without them is unusable in a dissertation
(eval/README.md: "Results without seeds/lineage — irreproducible = unusable").

This produces the RESULTS TABLE. Significance testing (Wilcoxon, Cliff's delta,
bootstrap CIs, Holm–Bonferroni) reads these JSON files; it is deliberately a
separate step so nobody re-runs a GPU-hour to recompute a p-value.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "eval"))
sys.path.insert(0, str(REPO / "services" / "brain"))
sys.path.insert(0, str(REPO / "services" / "worker"))

from metrics.collectors import percentile  # noqa: E402
from run_benchmark import PROMPTS, _run_one  # noqa: E402

from ablation_runners.conditions import CONDITIONS, runnable  # noqa: E402

OUT_DIR = REPO / "eval" / "reports"

# Seeds are FIXED, not random: an ablation that reseeds per run cannot be
# reproduced, and "3 seeds" in the plan means these three, every time (rule 14).
SEEDS = (0, 1, 2)


def _seed_for(entry: dict, replicate: int) -> int:
    """A distinct but deterministic seed per (prompt, replicate)."""
    return entry["seed"] + replicate * 10_000


def _warm_up_planner() -> None:
    """Load the planner into VRAM before the TIMED runs begin.

    A cold 27B reload on the first call can exceed the per-call timeout and cause
    a spurious rules fallback — measured once on a real run, on `surv_01`. Warming
    first means the fallback count reflects the MODEL, not the load. Best-effort:
    if the warmup itself fails, the run proceeds and the honest fallback counter
    catches whatever happens.
    """
    import contextlib

    from core.config import get_settings
    from run_benchmark import _context  # same context the runs use

    with contextlib.suppress(Exception):
        from agents.llm_planner import llm_brief

        s = get_settings()
        ctx = _context("warmup: a small test dungeon", 0, use_llm=True)
        llm_brief("warmup: a small test dungeon", None, None, ctx, knowledge="")
        print(f"  (planner warmed: {s.llm_model})", flush=True)


def run_condition(cond_id: str, seeds: int, full: bool, prompts_path: Path = PROMPTS) -> dict:
    cond = CONDITIONS[cond_id]
    if not cond.is_runnable():
        raise SystemExit(
            f"condition {cond_id} ({cond.label}) cannot run yet: {cond.requires}"
        )
    if cond.toggles.get("use_llm"):
        _warm_up_planner()
    data = json.loads(prompts_path.read_text(encoding="utf-8"))
    rows: list[dict] = []
    started = time.perf_counter()

    for replicate in SEEDS[:seeds]:
        for entry in data["prompts"]:
            result = _run_one(
                entry, full=full, seed_override=_seed_for(entry, replicate), **cond.toggles
            )
            row = result.to_dict()
            row["replicate"] = replicate
            rows.append(row)
            mark = "." if row["verdict"] == "PASS" else "x"
            print(mark, end="", flush=True)
    print()

    passed = [r for r in rows if r["verdict"] == "PASS"]
    latencies = [r["latency_ms"] for r in rows]
    llm_rows = sum(1 for r in rows if r["brief_source"] == "llm")
    summary = {
        "condition": cond_id,
        "label": cond.label,
        "question": cond.question,
        "toggles": cond.toggles,
        "prompt_set_version": data["version"],
        "seeds": list(SEEDS[:seeds]),
        "runs": len(rows),
        "passed": len(passed),
        "pass_rate": round(len(passed) / len(rows), 4) if rows else 0.0,
        "schema_valid": sum(1 for r in rows if r["schema_valid"]),
        "repaired": sum(1 for r in rows if r["repaired"]),
        "genre_matched": sum(1 for r in rows if r["genre_match"]),
        "played": sum(1 for r in rows if (r["bot_verdict"] or "").startswith("GREEDYBOT_OK")),
        "latency_p50_ms": round(percentile(latencies, 50), 1),
        "latency_p95_ms": round(percentile(latencies, 95), 1),
        # An --llm arm that silently fell back to rules is not an LLM result. This
        # is the number that catches a dead GPU reported as a finding.
        "llm_planned": llm_rows,
        "llm_fallbacks": (len(rows) - llm_rows) if cond.toggles.get("use_llm") else 0,
        "wall_seconds": round(time.perf_counter() - started, 1),
        "ran_at": datetime.now(UTC).isoformat(),
    }
    return {"summary": summary, "rows": rows}


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--conditions", default="R", help="comma-separated ids, e.g. B,C,D")
    ap.add_argument("--seeds", type=int, default=3, choices=(1, 2, 3))
    ap.add_argument("--full", action="store_true", help="also export + play (slow, needs Godot)")
    ap.add_argument("--out", type=Path, default=None)
    ap.add_argument(
        "--prompts", type=Path, default=PROMPTS,
        help="prompt-set JSON (default: v1_frozen; e.g. eval/benchmark_prompts/v2_ambiguous.json)",
    )
    ap.add_argument("--list", action="store_true", help="show conditions and exit")
    args = ap.parse_args(argv)

    if args.list:
        print(f"{'id':3s} {'runnable':9s} {'label':42s} question / blocker")
        for c in CONDITIONS.values():
            state = "yes" if c.is_runnable() else "NO"
            note = c.question if c.is_runnable() else f"BLOCKED: {c.requires}"
            print(f"{c.id:3s} {state:9s} {c.label:42s} {note}")
        print(f"\nrunnable today: {', '.join(c.id for c in runnable())}")
        return 0

    ids = [c.strip().upper() for c in args.conditions.split(",") if c.strip()]
    unknown = [i for i in ids if i not in CONDITIONS]
    if unknown:
        raise SystemExit(f"unknown condition(s): {unknown}; known: {list(CONDITIONS)}")

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    results = {}
    for cond_id in ids:
        print(f"\n--- {cond_id}: {CONDITIONS[cond_id].label} ---")
        results[cond_id] = run_condition(cond_id, args.seeds, args.full, args.prompts)
        s = results[cond_id]["summary"]
        print(
            f"  pass {s['passed']}/{s['runs']} ({s['pass_rate']:.0%})  "
            f"repaired {s['repaired']}  p50 {s['latency_p50_ms']}ms  "
            f"llm {s['llm_planned']}/{s['runs']}"
        )
        if s["llm_fallbacks"]:
            print(
                f"  WARNING: {s['llm_fallbacks']} run(s) fell back to rules — "
                "this arm is NOT an LLM result. Check the planner is up."
            )

    out = args.out or (OUT_DIR / f"ablation_{'-'.join(ids)}_{stamp}.json")
    out.write_text(
        json.dumps({"conditions": results}, indent=2, ensure_ascii=False),
        encoding="utf-8",
        newline="\n",
    )
    print(f"\nwrote {out}")

    if len(ids) > 1:
        print("\n--- comparison ---")
        print(f"{'id':3s} {'pass':>7s} {'repaired':>9s} {'p50 ms':>8s}  label")
        for cond_id in ids:
            s = results[cond_id]["summary"]
            print(
                f"{cond_id:3s} {s['pass_rate']:>6.0%} {s['repaired']:>9d} "
                f"{s['latency_p50_ms']:>8.0f}  {s['label']}"
            )
        print("\nDifferences here are DESCRIPTIVE. Significance (Wilcoxon + Cliff's")
        print("delta + bootstrap CIs, Holm-Bonferroni) is a separate step over these files.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
