# eval/ — benchmarks, ablations, metrics

**What this is:** the dissertation's evidence machinery. Built as **product telemetry from P2 onward** (building it late is a named top-10 risk).

| Folder | Purpose |
|---|---|
| `benchmark_prompts/` | Frozen prompt sets: 20 nightly-regression prompts (P2) → 50–100 study prompts × 4 genres (P4). Once frozen, **never edited** — only versioned additions |
| `ablation_runners/` | Runners for ablations A (one-shot), B (structured no-repair), C (structured+repair), D (+RAG), E (tuned-8B vs untuned-32B), F (deterministic vs free LLM assembly) |
| `metrics/` | Metric definitions + collectors: schema validity, build success, playability pass, repair success, latency p50/p95, cost/build, crash-free rate, fidelity, bundle size |
| `reports/` | Generated results (gitignored where heavy): results tables, significance tests (Wilcoxon, Cliff's delta, bootstrap CIs, Holm-Bonferroni), nightly benchmark history |

**Owner:** M2 (Brain/ML), metrics dashboards with M4.

**When updated:** first 20 frozen prompts at P2 start; nightly benchmark from the P2 gate; ablation runs in P5.

**Common mistakes to avoid:**
- Cherry-picked demo prompts — the mid-demo uses the fixed set.
- Editing a frozen prompt after results exist — invalidates comparisons.
- Results without seeds/lineage — irreproducible = unusable in the dissertation.
- Building the harness in P5 — it must accumulate telemetry from P2.
