"""Nightly benchmark runner (P2 MID-DEMO gate instrument).

Runs every frozen prompt through the real brain-side pipeline
(intent -> spec_builder -> schema -> PCG -> 8-gate validation, plus one
localized repair pass on failure) and reports the unaided pass rate against
the 80% gate threshold. Deterministic by design: rule-based intent + fixed
per-prompt seeds, so two runs produce byte-identical results (the runner
can assert this with --verify-reproducible).

Godot is NOT required — this measures the deterministic core the gate is
about (does a prompt yield a schema-valid, statically-playable game?).
Gates 4/6 (export/bot) are exercised separately when a build is present.

Usage (from repo root):
  python eval/run_benchmark.py
  python eval/run_benchmark.py --verify-reproducible
  python eval/run_benchmark.py --out eval/reports/benchmark_2026-07-13.json
"""

from __future__ import annotations

import argparse
import json
import sys
import tempfile
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "services" / "brain"))
sys.path.insert(0, str(REPO / "services" / "worker"))

from agents.chain import AgentContext, author_spec  # noqa: E402
from pcg.pipeline import run_pcg  # noqa: E402
from pcg.serialize import to_level_plan, to_level_plan_json  # noqa: E402
from repair.loop import deterministic_spec_fixes, level_reroll_seed  # noqa: E402
from validators.gates import collect_quest_of, run_gates  # noqa: E402

sys.path.insert(0, str(REPO / "eval"))
from metrics.collectors import (  # noqa: E402
    BenchmarkSummary,
    PromptResult,
    percentile,
)

PROMPTS = REPO / "eval" / "benchmark_prompts" / "v1_frozen.json"
SCHEMA = json.loads((REPO / "contracts" / "game_spec.schema.json").read_text(encoding="utf-8"))
BASE_SPEC = json.loads(
    (REPO / "contracts" / "examples" / "golden_game.spec.json").read_text(encoding="utf-8")
)


def _context(
    prompt: str, seed: int, use_llm: bool, *, rag: bool = True, model: str | None = None
) -> AgentContext:
    """Rules mode by default: CI has no GPU, and the gate must be reproducible.
    `--llm` grades the real product path — which explores design space the rule
    parser never reaches (a 3-tier 'descend the crypts' brief found a latent
    unsolvable-level bug that 20/20 rules runs had sailed straight past)."""
    if not use_llm:
        return AgentContext(prompt=prompt, seed=seed, rag_enabled=rag)

    from core.config import get_settings

    settings = get_settings()
    return AgentContext(
        prompt=prompt,
        seed=seed,
        llm_enabled=True,
        llm_base_url=settings.llm_base_url,
        llm_model=model or settings.llm_model,  # ablation E swaps the planner here
        llm_timeout_seconds=settings.llm_timeout_seconds,
        rag_enabled=rag,  # ablation D toggles retrieval
    )


def _build_and_play(spec: dict, plan: dict, out_dir: Path) -> tuple[dict | None, str | None]:
    """Assemble → export → PLAY. The MID-DEMO gate is 'a playable game', not 'a
    valid plan', so the benchmark has to actually build the thing and finish it.

    Returns (build_result, bot_verdict); either is None when Godot is unavailable,
    in which case the corresponding gate records SKIPPED rather than failing.
    """
    from bots.runner import run_greedy_bot
    from godot_client.exporter import export_web
    from godot_client.project_writer import write_project

    godot = _settings().godot_bin
    if not godot:
        return None, None

    project = out_dir / "project"
    write_project(
        plan,
        spec["meta"]["title"],
        project,
        templates_dir=REPO / "engine" / "templates",
        player_config=spec["player"],
        enemy_configs={e["enemy_id"]: e.get("stats", {}) for e in spec["entities"]["enemies"]},
        lighting_preset=spec["world"].get("lighting_preset_id", "overcast_day"),
        prop_configs={
            p["prop_id"]: p.get("interactable_template_id") for p in spec["entities"]["props"]
        },
        collect_quest=collect_quest_of(spec),
    )
    build = export_web(project, Path(godot))
    verdict = run_greedy_bot(godot, project)
    return build, verdict


def _settings():
    from core.config import get_settings

    return get_settings()


def _content_metrics(spec: dict) -> dict:
    """What the planner DESIGNED, not whether it passed a gate.

    The win condition it chose, whether it authored a player identity, and how
    much distinct content it wrote — the axes on which rules mode and the LLM
    actually differ, and which the static gates (all 100%) cannot show.
    """
    objectives = spec.get("objectives", [])
    # The DESIGN CHOICE is "is this a collect hunt?", not "which objective carries
    # the win flag" — a collect_n game gathers N *then escapes*, so the escape
    # keeps is_win_condition and reading that flag always says reach_zone. What
    # the Game Designer actually decided is whether a collect_n objective EXISTS.
    kinds = {o.get("objective_template_id") for o in objectives}
    objective_kind = "collect_n" if "collect_n" in kinds else "reach_zone"
    props = spec.get("entities", {}).get("props", [])
    enemies = spec.get("entities", {}).get("enemies", [])
    return {
        "objective_kind": objective_kind,
        "player_identity": bool(spec.get("player", {}).get("asset_brief")),
        "prop_count": len({p.get("prop_id") for p in props}),
        "enemy_kind_count": len({e.get("enemy_id") for e in enemies}),
    }


def _run_one(
    entry: dict,
    use_llm: bool = False,
    full: bool = False,
    *,
    repair: bool = True,
    rag: bool = True,
    model: str | None = None,
    seed_override: int | None = None,
) -> PromptResult:
    """One prompt through the production path.

    The keyword-only toggles exist for the ablation runners: every default
    reproduces the shipped pipeline exactly, so the CI benchmark gate that
    calls this measures the product, not an experiment.
    """
    import jsonschema

    start = time.perf_counter()
    prompt = entry["prompt"]
    seed = entry["seed"] if seed_override is None else seed_override
    # The same production path the pipeline runs: the multi-agent chain.
    chain = author_spec(
        BASE_SPEC,
        _context(prompt, seed, use_llm, rag=rag, model=model),
        f"g3d_bench_{entry['id']}_00000000",
        prompt,
    )
    brief = chain.brief
    try:
        spec = chain.spec
        content = _content_metrics(spec)
        spec["lineage"] = {"prompt": prompt, "build_hash": "benchmark"}
        schema_valid = True
        try:
            jsonschema.validate(spec, SCHEMA)
        except jsonschema.ValidationError:
            schema_valid = False

        plan = to_level_plan(run_pcg(spec))
        report = run_gates(spec, plan, schema=SCHEMA, build_result=None)

        repaired = False
        if repair and report["verdict"] != "PASS":
            # One localized repair pass (the gate is judged "unaided" but the
            # pipeline's own repair is part of the product path — recorded).
            errors = report["errors"]
            fclass = errors[0]["failure_class"]
            if fclass == "schema" and deterministic_spec_fixes(spec, errors):
                repaired = True
            elif fclass == "logic":
                spec["meta"]["seed"] = level_reroll_seed(seed, 1)
                repaired = True
            if repaired:
                plan = to_level_plan(run_pcg(spec))
                report = run_gates(spec, plan, schema=SCHEMA, build_result=None)

        build: dict | None = None
        bot_verdict: str | None = None
        if full and report["verdict"] == "PASS":
            # Only build what the static gates already accepted — exporting a game
            # we know is broken burns four minutes to learn nothing.
            with tempfile.TemporaryDirectory(prefix=f"bench_{entry['id']}_") as tmp:
                build, bot_verdict = _build_and_play(spec, plan, Path(tmp))
            report = run_gates(
                spec, plan, schema=SCHEMA, build_result=build, bot_verdict=bot_verdict
            )

        latency = (time.perf_counter() - start) * 1000
        return PromptResult(
            prompt_id=entry["id"],
            seed=seed,
            prompt=prompt,
            genre=brief.genre,
            expect_genre=entry["expect_genre"],
            genre_match=brief.genre == entry["expect_genre"],
            schema_valid=schema_valid,
            verdict=report["verdict"],
            gate_verdicts={str(g["gate"]): g["verdict"] for g in report["gates"]},
            error_codes=[e["code"] for e in report["errors"]],
            zones=len(plan["zones"]),
            entities=len(plan["entities"]),
            level_plan_hash=to_level_plan_json(run_pcg(spec)),
            repaired=repaired,
            latency_ms=round(latency, 2),
            brief_source=chain.brief_source,
            build_mb=round(build["total_bytes"] / 1_000_000, 1) if build else None,
            bot_verdict=bot_verdict,
            **content,
        )
    except Exception as exc:  # a crash is a benchmark failure, recorded honestly
        return PromptResult(
            prompt_id=entry["id"],
            seed=seed,
            prompt=prompt,
            genre=brief.genre,
            expect_genre=entry["expect_genre"],
            genre_match=brief.genre == entry["expect_genre"],
            schema_valid=False,
            verdict="FAIL",
            latency_ms=round((time.perf_counter() - start) * 1000, 2),
            brief_source=chain.brief_source,
            error=f"{type(exc).__name__}: {exc}",
        )


def run_benchmark(
    use_llm: bool = False, full: bool = False, **conditions
) -> tuple[BenchmarkSummary, list[PromptResult]]:
    """The frozen set through the pipeline. `**conditions` forwards the
    ablation toggles (repair/rag/model/seed_override) to `_run_one`."""
    data = json.loads(PROMPTS.read_text(encoding="utf-8"))
    results = [_run_one(e, use_llm, full, **conditions) for e in data["prompts"]]
    latencies = [r.latency_ms for r in results]
    required_production_gates = {"1", "2", "3", "4", "5", "6", "8"}

    def is_production_pass(result: PromptResult) -> bool:
        return (
            result.verdict == "PASS"
            and result.build_mb is not None
            and (result.bot_verdict or "").startswith("GREEDYBOT_OK")
            and all(
                result.gate_verdicts.get(gate) == "PASS"
                for gate in required_production_gates
            )
        )

    summary = BenchmarkSummary(
        benchmark_version=data["version"],
        total=len(results),
        passed=sum(1 for r in results if r.verdict == "PASS"),
        genre_matched=sum(1 for r in results if r.genre_match),
        schema_valid=sum(1 for r in results if r.schema_valid),
        repaired=sum(1 for r in results if r.repaired),
        latency_p50_ms=percentile(latencies, 50),
        latency_p95_ms=percentile(latencies, 95),
        llm_briefs=sum(1 for r in results if r.brief_source == "llm"),
        built=sum(1 for r in results if r.build_mb is not None),
        played=sum(1 for r in results if (r.bot_verdict or "").startswith("GREEDYBOT_OK")),
        production_passed=sum(1 for r in results if is_production_pass(r)),
    )
    return summary, results


def to_markdown(summary: BenchmarkSummary, results: list[PromptResult]) -> str:
    s = summary
    lines = [
        f"# Benchmark {s.benchmark_version}",
        "",
        f"- **Pass rate: {s.pass_rate:.0%}** ({s.passed}/{s.total}) — "
        f"gate {'MET ✅' if s.gate_met else 'NOT met ❌'} (threshold {s.gate_threshold:.0%})",
        f"- Genre match: {s.genre_matched}/{s.total} · schema-valid: {s.schema_valid}/{s.total} "
        f"· repaired: {s.repaired}",
        f"- Latency p50 {s.latency_p50_ms:.1f} ms · p95 {s.latency_p95_ms:.1f} ms",
        f"- Planned by the LLM: {s.llm_briefs}/{s.total} "
        f"({'rules mode' if not s.llm_briefs else 'rest fell back to rules'})",
        f"- **Played to completion by the bot: {s.played}/{s.total}** "
        "(gate 6 — a game that cannot be finished is not a game)",
        "",
        "| id | plan | genre✓ | verdict | zones | entities | build | bot | repaired | codes |",
        "|---|---|---|---|---|---|---|---|---|---|",
    ]
    lines.insert(
        -3,
        f"- **Production-ready: {s.production_passed}/{s.total}** "
        f"({'YES' if s.production_ready else 'NO'}; requires build, play, and "
        "every mandatory gate)",
    )
    for r in results:
        codes = ",".join(r.error_codes) or ("—" if r.error is None else r.error)
        bot = "—"
        if r.bot_verdict:
            bot = "✅ won" if r.bot_verdict.startswith("GREEDYBOT_OK") else f"❌ {r.bot_verdict}"
        lines.append(
            f"| {r.prompt_id} | {r.brief_source} | {'✓' if r.genre_match else '✗'} | {r.verdict} | "
            f"{r.zones} | {r.entities} | {f'{r.build_mb} MB' if r.build_mb else '—'} | {bot} | "
            f"{'yes' if r.repaired else '—'} | {codes} |"
        )
    return "\n".join(lines) + "\n"


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, help="write the JSON report here")
    parser.add_argument("--md", type=Path, help="write a Markdown summary here")
    parser.add_argument(
        "--verify-reproducible",
        action="store_true",
        help="run twice; nonzero exit if any level_plan_hash differs",
    )
    parser.add_argument(
        "--llm",
        action="store_true",
        help="plan with the real LLM (needs the GPU box) instead of the rule parser. "
        "This is the product path; CI runs rules mode because it has no GPU.",
    )
    parser.add_argument(
        "--full",
        action="store_true",
        help="also ASSEMBLE, EXPORT and PLAY each game (gates 4 and 6) — needs GODOT_BIN. "
        "This is the MID-DEMO gate: a playable game, not merely a valid plan. Slow.",
    )
    args = parser.parse_args(argv)
    if args.llm and args.verify_reproducible:
        parser.error("--llm is not bit-reproducible across runs; drop --verify-reproducible")
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")  # emoji-safe on Windows cp1252

    summary, results = run_benchmark(use_llm=args.llm, full=args.full)
    report = {"summary": summary.to_dict(), "results": [r.to_dict() for r in results]}

    if args.verify_reproducible:
        _, results2 = run_benchmark()
        drift = [
            r.prompt_id
            for r, r2 in zip(results, results2, strict=True)
            if r.level_plan_hash != r2.level_plan_hash
        ]
        if drift:
            print(f"REPRODUCIBILITY FAILURE: hashes drifted for {drift}")
            return 1
        print(f"reproducible: all {len(results)} level-plan hashes identical across two runs")

    print(to_markdown(summary, results))
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
        print(f"wrote {args.out}")
    if args.md:
        args.md.parent.mkdir(parents=True, exist_ok=True)
        args.md.write_text(to_markdown(summary, results), encoding="utf-8")
    if args.full:
        return 0 if summary.production_ready else 2
    return 0 if summary.gate_met else 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
