"""Deterministic benchmark for the SIMULATION path.

WHY THIS EXISTS. `eval/run_benchmark.py` is the P2 gate instrument and it measures the
game_spec path only. The simulation path -- planner, composition, PCG, placement,
contract verification -- had no reproducible instrument at all, and the only thing being
used in its place was `scripts/corpus_loop.py`.

That was the wrong tool, and it cost a day to notice. The corpus loop is a TRAINING DATA
COLLECTOR: an LLM writes fresh prompts each run and the planner is nondeterministic, so
twelve different specs come back every time. It cannot attribute a change to a cause,
which is exactly what it kept being asked to do. It also takes about four hours, so every
wrong answer was a four-hour wrong answer -- and two of those runs measured mistakes of
mine rather than the system.

This runs the same pipeline against FROZEN prompts with FIXED seeds, in rules mode, with
no Godot, no GPU and no network. It takes seconds. A change either moves the number or it
does not, and `--verify-reproducible` proves the run is byte-stable so a difference can
only have come from the code.

WHAT IT MEASURES. Everything the brain owns and nothing it does not:

    plan -> schema -> composition expansion -> PCG/placement -> world-plan schema
         -> independent world-plan validation -> requirement traceability
         -> deterministic critic

Asset generation, export, and the playtest bot are deliberately out of scope. They need a
GPU and an engine, they are where the four hours went, and they are measured by the
corpus and the showcase runs instead. What is left is the part where a change to planning
or placement shows up.

RULES MODE BY DEFAULT. Without a planner model, `plan_simulation` uses its built-in
deterministic draft, which is reproducible by construction. `--llm` grades the real
product path and is NOT reproducible -- the flag says so and the report records which
mode produced it, because a number whose provenance is unclear is worse than no number.

Usage (from the repo root):
    python eval/run_simulation_benchmark.py
    python eval/run_simulation_benchmark.py --verify-reproducible
    python eval/run_simulation_benchmark.py --kind settlement
    python eval/run_simulation_benchmark.py --out eval/reports/sim_bench.json
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "services" / "brain"))
sys.path.insert(0, str(REPO / "services" / "worker"))

from agents.simulation_planner import (  # noqa: E402
    plan_simulation,
    validate_simulation_spec,
)
from agents.brief_extractor import (  # noqa: E402
    brief_as_planner_input,
    extract_brief,
)
from agents.prompt_expander import expand_prompt  # noqa: E402
from behaviors.compiler import compile_behavior_plan  # noqa: E402
from core.config import get_settings  # noqa: E402
from pcg.semantic import (  # noqa: E402
    generate_semantic_world_plan,
    validate_semantic_world_plan,
)
from verification.contracts import (  # noqa: E402
    deterministic_independent_critique,
    verify_requirement_traceability,
)

PROMPTS = REPO / "eval" / "simulation_prompts" / "v1_frozen.json"

# The composition vocabulary, reported separately from pass/fail. A settlement prompt
# that plans cleanly but uses none of it is a PASS that has still not produced a
# settlement, and that distinction is the whole reason these prompts were added.
COMPOSITION_FIELDS = ("routes", "regions", "linear_structures")


def _load(kind: str | None) -> list[dict]:
    data = json.loads(PROMPTS.read_text(encoding="utf-8"))
    prompts = data["prompts"]
    if kind:
        prompts = [item for item in prompts if item.get("kind") == kind]
    return prompts


def _measure_one(entry: dict, *, use_llm: bool, settings) -> dict:
    """Run one prompt through the brain and report what survived.

    Every stage is caught individually: a benchmark that stops at the first exception
    tells you one thing about one prompt, where the useful output is which stage each
    prompt reached.
    """
    started = time.perf_counter()
    result: dict = {
        "id": entry["id"],
        "kind": entry.get("kind"),
        "seed": entry["seed"],
        "stage_reached": "plan",
        "errors": [],
    }
    # expand -> extract -> plan, the way the product runs it.
    #
    # The first version called `plan_simulation` with no brief, so the whole
    # expand/extract half of the pipeline was absent from every measurement -- and the
    # brief's `layout` list, which is where streets and paved areas are decided, did not
    # exist in the path being graded. Three experiments were run against that gap before
    # it was noticed. A benchmark that skips a stage measures a system nobody ships.
    brief_text: str | None = None
    if use_llm:
        expansion = expand_prompt(
            entry["prompt"],
            settings=settings,
            model_id=settings.llm_model,
            base_url=settings.llm_base_url,
            seed=entry["seed"],
        )
        description = expansion.description if expansion else entry["prompt"]
        extraction = extract_brief(
            description,
            settings=settings,
            model_id=settings.llm_model,
            base_url=settings.llm_base_url,
            seed=entry["seed"],
        )
        if extraction is not None:
            brief_text = brief_as_planner_input(extraction)
            result["brief_layout"] = [
                item.get("shape") for item in (extraction.brief.get("layout") or [])
            ]

    try:
        spec, planner = plan_simulation(
            prompt=entry["prompt"],
            simulation_id=f"sim_{entry['id']}_{entry['seed']:08x}",
            seed=entry["seed"],
            size_profile="medium",
            target_platforms=["web"],
            domain_constraints=None,
            settings=settings,
            planner_model_id=(settings.llm_model if use_llm else None),
            planner_base_url=(settings.llm_base_url if use_llm else None),
            brief=brief_text,
        )
        result["planner"] = planner
        # Carried out so a training-set builder does not have to re-plan to get
        # it. Popped by that caller; the benchmark report never serialises it.
        result["spec_body"] = spec
    except Exception as exc:  # a planner failure is a result, not a crash
        result["errors"].append({"stage": "plan", "error": str(exc)[:200]})
        result["duration_ms"] = round((time.perf_counter() - started) * 1000, 1)
        return result

    result["entities"] = len(spec.get("entities") or [])
    result["scatter_species"] = len(spec.get("scatter") or [])
    result["composition"] = {
        field: len(spec.get(field) or []) for field in COMPOSITION_FIELDS
    }
    assets = [
        entity.get("asset") or {} for entity in (spec.get("entities") or [])
    ]
    result["palette_coverage"] = (
        sum(1 for asset in assets if asset.get("palette_hex")) / len(assets)
        if assets
        else None
    )

    result["stage_reached"] = "schema"
    try:
        validate_simulation_spec(spec)
    except Exception as exc:
        result["errors"].append({"stage": "schema", "error": str(exc)[:200]})
        result["duration_ms"] = round((time.perf_counter() - started) * 1000, 1)
        return result

    # Behaviours are compiled for real, not stubbed. The first version passed an empty
    # graph list and the report came back dominated by CAPABILITY_BEHAVIOR_OMITTED and
    # REQUIRED_BEHAVIOR_GRAPH_MISSING -- thirty and nineteen of them -- which were
    # artefacts of the instrument rather than findings about the system. A benchmark
    # that manufactures its own failures is worse than none.
    result["stage_reached"] = "behaviours"
    behavior_plan, behavior_errors = compile_behavior_plan(spec)
    for error in behavior_errors:
        result["errors"].append({"stage": "behaviours", **error})

    result["stage_reached"] = "layout"
    try:
        plan = generate_semantic_world_plan(spec, behaviour_graphs=behavior_plan["graphs"])
    except Exception as exc:
        result["errors"].append({"stage": "layout", "error": str(exc)[:200]})
        result["duration_ms"] = round((time.perf_counter() - started) * 1000, 1)
        return result

    unplaced = plan["constraint_summary"]["unplaced_entities"]
    result["unplaced"] = list(unplaced)
    for entity_id in unplaced:
        result["errors"].append({"stage": "layout", "code": "ENTITY_UNPLACED", "entity_id": entity_id})

    result["stage_reached"] = "verify"
    # Measured assets are a GPU concern and out of scope here; the geometry rule this
    # exercises is placement, not resolution.
    report = validate_semantic_world_plan(plan, require_measured_assets=False)
    for error in report.get("errors") or []:
        result["errors"].append({"stage": "world_plan", **error})

    traceability = verify_requirement_traceability(spec, plan, behavior_plan)
    for error in traceability.get("errors") or []:
        result["errors"].append({"stage": "traceability", **error})

    critique = deterministic_independent_critique(spec, plan, behavior_plan)
    for error in critique.get("errors") or []:
        result["errors"].append({"stage": "critic", **error})

    result["stage_reached"] = "done"
    result["passed"] = not result["errors"]
    result["duration_ms"] = round((time.perf_counter() - started) * 1000, 1)
    return result


def run(*, use_llm: bool, kind: str | None) -> dict:
    settings = get_settings()
    entries = _load(kind)
    results = [_measure_one(entry, use_llm=use_llm, settings=settings) for entry in entries]

    passed = [item for item in results if item.get("passed")]
    codes: dict[str, int] = {}
    for item in results:
        for error in item["errors"]:
            key = error.get("code") or f"{error.get('stage')}:exception"
            codes[key] = codes.get(key, 0) + 1

    settlements = [item for item in results if item.get("kind") == "settlement"]
    using_composition = [
        item
        for item in settlements
        if any((item.get("composition") or {}).get(field) for field in COMPOSITION_FIELDS)
    ]

    return {
        "mode": "llm" if use_llm else "rules",
        "reproducible": not use_llm,
        "prompts": len(results),
        "passed": len(passed),
        "pass_rate": round(len(passed) / len(results), 4) if results else 0.0,
        # Reported on its own because a settlement that plans cleanly and uses none of
        # the composition vocabulary is a pass that is still not a settlement.
        "settlements": len(settlements),
        "settlements_using_composition": len(using_composition),
        "failures_by_code": dict(sorted(codes.items(), key=lambda kv: -kv[1])),
        "total_ms": round(sum(item.get("duration_ms") or 0 for item in results), 1),
        "results": results,
    }


def _comparable(summary: dict) -> str:
    """The part of a report that must not move between two identical runs.

    Timings are excluded: they vary with the machine and would make every
    reproducibility check fail for a reason that has nothing to do with the code.
    """
    stripped = {
        key: value for key, value in summary.items() if key not in {"total_ms", "results"}
    }
    # `spec_body` is excluded as well as timings. It was added so the dataset builder
    # need not re-plan, and it carries the spec's lineage block -- which contains a
    # generation timestamp, so comparing it made two identical runs disagree and the
    # reproducibility check failed on a field that has nothing to do with reproducibility.
    stripped["results"] = [
        {k: v for k, v in item.items() if k not in {"duration_ms", "spec_body"}}
        for item in summary["results"]
    ]
    return json.dumps(stripped, sort_keys=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--llm", action="store_true", help="grade the real planner (NOT reproducible)")
    parser.add_argument("--kind", help="only prompts of this kind (settlement/interior/outdoor)")
    parser.add_argument("--out", type=Path, help="write the full report as JSON")
    parser.add_argument(
        "--verify-reproducible",
        action="store_true",
        help="run twice and assert the reports match",
    )
    args = parser.parse_args()

    summary = run(use_llm=args.llm, kind=args.kind)

    if args.verify_reproducible:
        if args.llm:
            print("--verify-reproducible is meaningless with --llm: the planner is not deterministic")
            return 2
        again = run(use_llm=False, kind=args.kind)
        if _comparable(summary) != _comparable(again):
            print("NOT REPRODUCIBLE: two identical runs disagreed")
            return 1
        print("reproducible: two runs byte-identical")

    print(f"mode              {summary['mode']}")
    print(f"prompts           {summary['prompts']}")
    print(f"passed            {summary['passed']}  ({summary['pass_rate']:.0%})")
    print(
        f"settlements       {summary['settlements_using_composition']}"
        f"/{summary['settlements']} used composition vocabulary"
    )
    print(f"time              {summary['total_ms']:.0f} ms")
    if summary["failures_by_code"]:
        print("failures:")
        for code, count in summary["failures_by_code"].items():
            print(f"   {count:3d}  {code}")

    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
        print(f"\nwrote {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
