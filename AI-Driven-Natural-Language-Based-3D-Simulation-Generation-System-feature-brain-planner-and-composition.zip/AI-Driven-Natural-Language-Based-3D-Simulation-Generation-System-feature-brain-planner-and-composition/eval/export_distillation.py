"""Export a governance-qualified, validator-filtered distillation set.

    prompt -> game_spec, keeping only the pairs the system PROVED were good.

This is the whole trick of the fine-tune, and why it is scheduled late rather
than early: nobody labels anything. Every job already emits the exact pair a
planner would train on, and the pipeline already judges it — 8 validation gates,
plus a bot that has to actually WIN the game before it can ship (gate 6). So the
label is free and it is honest: `verdict == PASS` means this spec built, and was
played to completion, by a machine that does not care about our feelings.

Default filter is deliberately strict:
  * brief_source == "llm"  — teach the student what the TEACHER did. Rules-mode
    rows are the deterministic control group, not training data; training on them
    would teach the 8B to imitate a regex.
  * validation verdict == PASS — a spec that failed its gates is a counter-example.
  * state == DEPLOYED — it really shipped.

Usage:
    python eval/export_distillation.py                     # -> eval/reports/distill.jsonl
    python eval/export_distillation.py --out x.jsonl --include-failures --stats-only

Output is JSONL, one training pair per line, in the messages shape every SFT
trainer (TRL, Axolotl, Unsloth) reads directly.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from collections import Counter
from pathlib import Path

_REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_REPO / "services" / "brain"))

DEFAULT_OUT = _REPO / "eval" / "reports" / "distill.jsonl"

SYSTEM_PROMPT = (
    "You are the simulation planner for Serendib. Given a user's request, emit "
    "the canonical structured specification as JSON only."
)

ALLOWED_TRAINING_SOURCES = frozenset({"synthetic", "controlled"})


def _governance_eligible(spec) -> bool:
    """Return true only for explicitly eligible, non-production records."""
    return bool(
        getattr(spec, "training_eligible", False)
        and getattr(spec, "data_source", None) in ALLOWED_TRAINING_SOURCES
    )


def _rows(include_failures: bool, include_rules: bool):
    """(prompt, spec_body, verdict, brief_source, state) per stored spec."""
    from core import db
    from core.models import (
        Game,
        GenerationRun,
        Job,
        Simulation,
        SimulationSpecRecord,
        Spec,
    )

    with db.session_scope() as session:
        # The simulation path first: it is what this project generates now, and the
        # reason this exporter reported zero rows for months was that it only knew
        # about the older table.
        simulation_query = (
            session.query(SimulationSpecRecord, Simulation, GenerationRun)
            .join(Simulation, SimulationSpecRecord.simulation_id == Simulation.id)
            .join(GenerationRun, GenerationRun.spec_id == SimulationSpecRecord.id)
        )
        for spec, simulation, run in simulation_query.all():
            if not _governance_eligible(spec):
                continue
            detail = run.detail or {}
            mandatory = detail.get("mandatory_failures") or []
            # A simulation run has no single `verdict` field: the gates are the
            # verdict, and an empty mandatory-failure list is what PASS means here.
            verdict = "PASS" if not mandatory else "FAIL"
            source = getattr(spec, "source", None)
            if not include_rules and source not in {"llm", None}:
                continue
            if not include_failures and not (
                verdict == "PASS" and run.state in {"completed", "DEPLOYED"}
            ):
                continue
            yield {
                "path": "simulation",
                "prompt": simulation.prompt,
                "spec": spec.body,
                "verdict": verdict,
                "brief_source": source,
                "state": run.state,
                "planner_model": spec.planner_model,
                "spec_hash": spec.spec_hash,
                "data_source": spec.data_source,
            }

        query = session.query(Spec, Game, Job).join(Game, Spec.game_id == Game.id).join(
            Job, Spec.job_id == Job.id
        )
        for spec, game, job in query.all():
            if not _governance_eligible(spec):
                continue
            detail = job.detail or {}
            verdict = (detail.get("validation") or {}).get("verdict")
            if not include_rules and spec.brief_source != "llm":
                continue
            if not include_failures and not (verdict == "PASS" and job.state == "DEPLOYED"):
                continue
            yield {
                # Kept alongside the simulation rows rather than replaced: these are
                # still legitimate pairs, and the two spec FORMATS are not
                # interchangeable, so a training run has to be able to filter.
                "path": "game_spec",
                "prompt": game.prompt,
                "spec": spec.body,
                "verdict": verdict,
                "brief_source": spec.brief_source,
                "state": job.state,
                "planner_model": spec.planner_model,
                "spec_hash": spec.spec_hash,
                "data_source": spec.data_source,
            }


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--out", type=Path, default=DEFAULT_OUT)
    ap.add_argument("--include-failures", action="store_true",
                    help="also emit specs that failed validation (analysis, NOT training)")
    ap.add_argument("--include-rules", action="store_true",
                    help="also emit rules-mode specs (the control group, NOT training)")
    ap.add_argument("--stats-only", action="store_true", help="report what is there; write nothing")
    args = ap.parse_args(argv)

    try:
        rows = list(_rows(args.include_failures, args.include_rules))
    except Exception as exc:  # a fresh DB, no DATABASE_URL, no migration yet
        print(f"could not read specs: {type(exc).__name__}: {exc}", file=sys.stderr)
        print("is DATABASE_URL set, and has `alembic upgrade head` run?", file=sys.stderr)
        return 2

    by_source = Counter(r["brief_source"] for r in rows)
    by_verdict = Counter(str(r["verdict"]) for r in rows)
    print(f"specs matching the filter : {len(rows)}")
    print(f"  by brief_source         : {dict(by_source)}")
    print(f"  by validation verdict   : {dict(by_verdict)}")
    print(f"  distinct prompts        : {len({r['prompt'] for r in rows})}")
    print(f"  distinct specs          : {len({r['spec_hash'] for r in rows})}")

    if args.stats_only:
        return 0
    if not rows:
        print("\nnothing to export yet — run some prompts with LLM_ENABLED=true first.")
        return 0

    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", encoding="utf-8", newline="\n") as fh:
        for row in rows:
            fh.write(json.dumps({
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": row["prompt"]},
                    {
                        "role": "assistant",
                        "content": json.dumps(row["spec"], separators=(",", ":")),
                    },
                ],
                # provenance so a training run is reproducible + auditable (§11)
                "meta": {
                    "spec_hash": row["spec_hash"],
                    "verdict": row["verdict"],
                    "brief_source": row["brief_source"],
                    "teacher": row["planner_model"],
                    "data_source": row["data_source"],
                },
            }, ensure_ascii=False) + "\n")
    print(f"\nwrote {len(rows)} pairs -> {args.out}")
    if len(rows) < 200:
        print("NOTE: a QLoRA SFT wants ~500-2000 governed, high-quality pairs.")
        print("      Do not loosen eligibility filters to inflate the dataset.")
    return 0


if __name__ == "__main__":
    os.environ.setdefault("DATABASE_URL", "postgresql+psycopg://promptplay:promptplay@localhost:5432/promptplay")
    raise SystemExit(main(sys.argv[1:]))
