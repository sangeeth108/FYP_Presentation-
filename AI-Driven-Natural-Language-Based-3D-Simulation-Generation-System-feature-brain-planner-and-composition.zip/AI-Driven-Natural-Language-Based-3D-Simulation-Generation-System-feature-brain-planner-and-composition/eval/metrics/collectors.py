"""Metric definitions for the benchmark (docs/eval README).

Kept deliberately small and honest: these are the metrics the P2 MID-DEMO
gate is judged on. Heavier study metrics (fidelity, cost/build, crash-free
rate) arrive with the asset farm + user study (P3/P5).
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field


@dataclass
class PromptResult:
    prompt_id: str
    seed: int
    prompt: str
    genre: str  # what the parser chose
    expect_genre: str  # what the frozen set expects
    genre_match: bool
    schema_valid: bool  # gate 1
    verdict: str  # PASS | FAIL (gates runnable without Godot)
    gate_verdicts: dict[str, str] = field(default_factory=dict)  # "1".."8" -> PASS/FAIL/SKIPPED
    error_codes: list[str] = field(default_factory=list)
    zones: int = 0
    entities: int = 0
    level_plan_hash: str = ""
    repaired: bool = False
    latency_ms: float = 0.0
    brief_source: str = "rules"  # "llm" | "rules" — an --llm run that silently
    # fell back (GPU down, timeout) must be visible, never reported as an LLM result
    build_mb: float | None = None  # --full only: the exported web build
    bot_verdict: str | None = None  # --full only: gate 6 — did the bot WIN it?
    error: str | None = None  # pipeline exception, if any
    # --- content-semantic metrics (what the LLM actually DESIGNS) -------------
    # The static gates ceiling at 100% for every arm, so they cannot show what
    # the planner contributes. These do: rules mode always picks reach_zone,
    # never gives the player a body, and emits the fixed base roster; the LLM
    # chooses the win condition, authors "who you are", and writes unique content.
    objective_kind: str = "reach_zone"  # the WIN condition chosen (reach_zone|collect_n)
    player_identity: bool = False  # did the planner author player.asset_brief?
    prop_count: int = 0  # distinct authored props
    enemy_kind_count: int = 0  # distinct authored enemy kinds

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class BenchmarkSummary:
    benchmark_version: str
    total: int
    passed: int
    genre_matched: int
    schema_valid: int
    repaired: int
    latency_p50_ms: float
    latency_p95_ms: float
    gate_threshold: float = 0.80
    llm_briefs: int = 0  # how many prompts were actually planned by the LLM
    built: int = 0  # worlds with a real engine export
    played: int = 0  # --full only: games the playtest bot actually WON (gate 6)
    production_passed: int = 0  # all mandatory production gates passed
    production_threshold: float = 0.95

    @property
    def pass_rate(self) -> float:
        return self.passed / self.total if self.total else 0.0

    @property
    def gate_met(self) -> bool:
        return self.pass_rate >= self.gate_threshold

    @property
    def production_pass_rate(self) -> float:
        return self.production_passed / self.total if self.total else 0.0

    @property
    def production_ready(self) -> bool:
        return self.production_pass_rate >= self.production_threshold

    def to_dict(self) -> dict:
        d = asdict(self)
        d["pass_rate"] = round(self.pass_rate, 4)
        d["gate_met"] = self.gate_met
        d["production_pass_rate"] = round(self.production_pass_rate, 4)
        d["production_ready"] = self.production_ready
        return d


def percentile(values: list[float], pct: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    rank = max(0, min(len(ordered) - 1, round(pct / 100 * (len(ordered) - 1))))
    return ordered[rank]
