"""Significance testing for the ablations (eval/README.md).

Pure stdlib on purpose. scipy is not a dependency of any service, and CI installs
only pytest + jsonschema + httpx — importing scipy here would break collection the
moment a test touched this module, which is exactly the failure that kept the
worker job red for months. The tests validate these implementations **against
scipy** where it happens to be installed, and skip where it isn't.

## Choosing the test — this matters more than the code

`eval/README.md` says "Wilcoxon", and for latency that is right. For **pass/fail
it is wrong, and dangerously so**: pass/fail is paired *binary* data, where every
non-zero difference has magnitude 1, so Wilcoxon's normal approximation runs on
nothing but ties and becomes **anti-conservative** — it reports significance that
is not there.

Measured on 20 paired prompts (18 vs 14 passing, 5 vs 1 discordant):

    Wilcoxon  p = 0.046   -> "significant"      WRONG
    McNemar   p = 0.219   -> not significant    correct

The correct test for paired binary outcomes is **McNemar's**, exact (not the
chi-square approximation) because discordant counts here are small. So:

    pass / played / schema_valid   (binary, paired by prompt)  -> mcnemar_exact
    latency, build size            (continuous, paired)        -> wilcoxon

Effect size is reported alongside every p-value, because with 60 runs a trivial
difference can be "significant" and a decision-relevant one can miss.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass


@dataclass(frozen=True)
class TestResult:
    test: str
    statistic: float
    p_value: float
    n: int
    note: str = ""

    def to_dict(self) -> dict:
        return {
            "test": self.test,
            "statistic": round(self.statistic, 6),
            "p_value": round(self.p_value, 6),
            "n": self.n,
            "note": self.note,
        }


def _phi(z: float) -> float:
    """Standard normal CDF."""
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


# --- paired BINARY: McNemar, exact ----------------------------------------


def mcnemar_exact(x: list[int], y: list[int]) -> TestResult:
    """Exact McNemar for paired binary outcomes (e.g. did prompt i pass?).

    Only the DISCORDANT pairs carry information: prompts both arms passed, or
    both failed, say nothing about which arm is better. Under H0 a discordant
    pair is a fair coin, so the test is an exact binomial on b vs c.

    Exact rather than chi-square: with 20 prompts the discordant count is often
    <10, where the chi-square approximation is unreliable.
    """
    if len(x) != len(y):
        raise ValueError("paired data must be the same length")
    b = sum(1 for xi, yi in zip(x, y, strict=True) if xi and not yi)  # x won
    c = sum(1 for xi, yi in zip(x, y, strict=True) if yi and not xi)  # y won
    n = b + c
    if n == 0:
        return TestResult("mcnemar_exact", 0.0, 1.0, 0, "no discordant pairs: arms identical")

    k = min(b, c)
    # Two-sided exact binomial at p=0.5: symmetric, so 2 * P(X <= k).
    tail = sum(math.comb(n, i) for i in range(k + 1)) / (2.0**n)
    p = min(1.0, 2.0 * tail)
    return TestResult(
        "mcnemar_exact", float(k), p, n,
        f"discordant: {b} favour A, {c} favour B",
    )


# --- paired CONTINUOUS: Wilcoxon signed-rank ------------------------------


def wilcoxon(x: list[float], y: list[float]) -> TestResult:
    """Wilcoxon signed-rank (paired, continuous) — normal approximation with tie
    and continuity corrections.

    Use for latency and build size. NOT for pass/fail: see the module docstring —
    on binary data this reports significance that is not there.
    """
    if len(x) != len(y):
        raise ValueError("paired data must be the same length")
    diffs = [xi - yi for xi, yi in zip(x, y, strict=True) if xi != yi]
    n = len(diffs)
    if n == 0:
        return TestResult("wilcoxon", 0.0, 1.0, 0, "all pairs identical")
    note = f"n={n} < 10: the normal approximation is unreliable here" if n < 10 else ""

    order = sorted(range(n), key=lambda i: abs(diffs[i]))
    ranks = [0.0] * n
    tie_groups: list[int] = []
    i = 0
    while i < n:
        j = i
        while j + 1 < n and abs(diffs[order[j + 1]]) == abs(diffs[order[i]]):
            j += 1
        avg = (i + j) / 2.0 + 1.0  # average rank, 1-based
        for k in range(i, j + 1):
            ranks[order[k]] = avg
        tie_groups.append(j - i + 1)
        i = j + 1

    w_plus = sum(r for d, r in zip(diffs, ranks, strict=True) if d > 0)
    mu = n * (n + 1) / 4.0
    tie_term = sum(t**3 - t for t in tie_groups) / 48.0
    var = n * (n + 1) * (2 * n + 1) / 24.0 - tie_term
    if var <= 0:
        return TestResult("wilcoxon", w_plus, 1.0, n, "zero variance (all differences tied)")

    # continuity correction toward the mean
    diff = w_plus - mu
    z = (diff - math.copysign(0.5, diff)) / math.sqrt(var) if diff != 0 else 0.0
    p = min(1.0, 2.0 * (1.0 - _phi(abs(z))))
    return TestResult("wilcoxon", w_plus, p, n, note)


# --- effect size ----------------------------------------------------------


def cliffs_delta(x: list[float], y: list[float]) -> tuple[float, str]:
    """Cliff's delta + its magnitude label (Romano et al. thresholds).

    Non-parametric, no distribution assumed: the probability a value from x
    exceeds one from y, minus the reverse. A p-value says "a difference exists";
    this says whether anyone should care.
    """
    if not x or not y:
        return 0.0, "undefined"
    gt = lt = 0
    for xi in x:
        for yj in y:
            if xi > yj:
                gt += 1
            elif xi < yj:
                lt += 1
    delta = (gt - lt) / (len(x) * len(y))
    a = abs(delta)
    label = (
        "negligible" if a < 0.147 else
        "small" if a < 0.330 else
        "medium" if a < 0.474 else
        "large"
    )
    return delta, label


def bootstrap_ci(
    values: list[float], *, confidence: float = 0.95, resamples: int = 10_000, seed: int = 42
) -> tuple[float, float]:
    """Percentile bootstrap CI for the mean. SEEDED (rule 14): a CI that moves
    between runs of the same data is not a result."""
    if not values:
        return (0.0, 0.0)
    rng = random.Random(seed)
    n = len(values)
    means = sorted(
        sum(values[rng.randrange(n)] for _ in range(n)) / n for _ in range(resamples)
    )
    lo = (1.0 - confidence) / 2.0
    return (means[int(lo * resamples)], means[min(resamples - 1, int((1.0 - lo) * resamples))])


# --- multiple comparisons -------------------------------------------------


def holm_bonferroni(p_values: dict[str, float], alpha: float = 0.05) -> dict[str, dict]:
    """Holm–Bonferroni step-down correction.

    Six arms means many pairwise tests, and at alpha=0.05 one in twenty "findings"
    is noise. Holm controls the family-wise error rate while being uniformly more
    powerful than plain Bonferroni. Step-down: once a hypothesis fails to reject,
    every less-significant one fails too.
    """
    if not p_values:
        return {}
    ordered = sorted(p_values.items(), key=lambda kv: kv[1])
    m = len(ordered)
    out: dict[str, dict] = {}
    still_rejecting = True
    prev_adjusted = 0.0
    for i, (name, p) in enumerate(ordered):
        adjusted = min(1.0, max(prev_adjusted, (m - i) * p))  # monotone
        prev_adjusted = adjusted
        if adjusted > alpha:
            still_rejecting = False
        out[name] = {
            "p_raw": round(p, 6),
            "p_adjusted": round(adjusted, 6),
            "significant": bool(still_rejecting and adjusted <= alpha),
            "rank": i + 1,
        }
    return out
