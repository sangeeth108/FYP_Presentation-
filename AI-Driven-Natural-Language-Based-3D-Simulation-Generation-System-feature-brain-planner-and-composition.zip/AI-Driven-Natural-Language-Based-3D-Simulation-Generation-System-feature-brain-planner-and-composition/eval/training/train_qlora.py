"""QLoRA challenger training on a consent-qualified SimulationSpec dataset.

The production worker trains a LoRA adapter only on governed prompt-to-
SimulationSpec pairs, preserves preassigned leakage-resistant splits, and
exports GGUF for
Ollama. The untuned 32B stays the product default; this produces the *challenger*
that Ablation E measures — and "the 8B doesn't match" is itself a publishable
result, so this script's job is an honest run, not a good number.

Legacy game-spec data requires ``--allow-legacy-research-data`` and is never
accepted by the production worker.

Heavy deps (unsloth/trl/peft/bitsandbytes) are imported INSIDE main so the file
imports cleanly for tests without a GPU stack. Everything is seeded (rule 14).

⚠ LICENCE (rule 12): Qwen3-8B needs its own ledger row before this ships a
planner — the qwen-planner row covers the 27B SKU only, and Qwen cards are not
uniformly Apache across the family. Verify the exact card, add the row, keep
`python scripts/check_licenses.py` green. The adapter is a derivative: its
licence follows the base.
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
SEED = 42
_SYSTEM_PROMPT = (
    "You are the Serendib simulation planner. Emit only a valid canonical "
    "SimulationSpec JSON object."
)


def load_pairs(paths: list[Path]) -> list[dict]:
    """Read one or more JSONL distillation files (generated + DB export merge)."""
    seen: set[str] = set()
    pairs: list[dict] = []
    for path in paths:
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            rec = json.loads(line)
            metadata = rec.get("meta", {})
            h = metadata.get("spec_hash") or metadata.get("content_hash") or ""
            if not h:
                raise ValueError(f"{path} contains a row without a governed content hash")
            if h and h in seen:
                continue  # the same spec from two sources is one training example
            seen.add(h)
            pairs.append(rec)
    return pairs


def split_by_spec_hash(pairs: list[dict], test_frac: float = 0.15) -> tuple[list, list]:
    """Hold out a test split BY spec_hash, seeded. Splitting by row would let an
    identical spec sit in both train and test and inflate the score."""
    rng = random.Random(SEED)
    by_hash: dict[str, list[dict]] = {}
    for p in pairs:
        metadata = p["meta"]
        content_hash = metadata.get("spec_hash") or metadata.get("content_hash")
        by_hash.setdefault(content_hash, []).append(p)
    hashes = sorted(by_hash)
    rng.shuffle(hashes)
    n_test = max(1, int(len(hashes) * test_frac)) if len(hashes) > 6 else 0
    test_h = set(hashes[:n_test])
    train = [p for h in hashes if h not in test_h for p in by_hash[h]]
    test = [p for h in test_h for p in by_hash[h]]
    return train, test


def validate_neutral_pairs(pairs: list[dict]) -> None:
    for row in pairs:
        messages = row.get("messages")
        if not isinstance(messages, list) or len(messages) != 3:
            raise ValueError("planner row must contain system, user and assistant messages")
        if messages[0] != {"role": "system", "content": _SYSTEM_PROMPT}:
            raise ValueError("planner row does not use the canonical neutral system prompt")
        if messages[1].get("role") != "user" or messages[2].get("role") != "assistant":
            raise ValueError("planner message roles are invalid")
        spec = json.loads(messages[2].get("content") or "null")
        if not isinstance(spec, dict) or not all(
            key in spec
            for key in ("schema_version", "requirements", "entities", "environment")
        ):
            raise ValueError("assistant target is not a neutral SimulationSpec")


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--data", type=Path, nargs="+", required=True)
    ap.add_argument("--validation-data", type=Path, nargs="*", default=[])
    ap.add_argument("--test-data", type=Path, nargs="*", default=[])
    ap.add_argument(
        "--manifest",
        type=Path,
        default=None,
        help="governed dataset manifest; preserves its preassigned splits",
    )
    ap.add_argument("--base", default="Qwen/Qwen3-8B")
    ap.add_argument("--out", type=Path, default=REPO / "artifacts" / "qlora-qwen3-8b")
    ap.add_argument("--epochs", type=float, default=2.0)
    ap.add_argument("--dry-run", action="store_true", help="prep + split + report, no training")
    ap.add_argument(
        "--allow-legacy-research-data",
        action="store_true",
        help="research-only escape hatch; never used by the governed worker",
    )
    args = ap.parse_args(argv)

    present = [p for p in args.data if p.is_file()]
    if not present:
        raise SystemExit(f"no dataset found: {[str(p) for p in args.data]} — generate it first")
    pairs = load_pairs(present)
    validation_paths = [p for p in args.validation_data if p.is_file()]
    test_paths = [p for p in args.test_data if p.is_file()]
    governed = args.manifest is not None
    if not governed and not args.allow_legacy_research_data:
        raise SystemExit("a governed dataset manifest is required")
    if governed:
        if not args.manifest.is_file():
            raise SystemExit(f"governed manifest is missing: {args.manifest}")
        manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
        expected = manifest.get("manifest_hash")
        if not expected:
            raise SystemExit("governed manifest lacks manifest_hash")
        if manifest.get("target") != "planner":
            raise SystemExit("governed manifest target is not planner")
        all_rows = [
            *pairs,
            *load_pairs(validation_paths),
            *load_pairs(test_paths),
        ]
        if any(
            row.get("meta", {}).get("dataset_manifest_hash") != expected
            for row in all_rows
        ):
            raise SystemExit("a dataset row does not match the governed manifest")
        validate_neutral_pairs(all_rows)
        train = pairs
        validation = load_pairs(validation_paths)
        test = load_pairs(test_paths)
    else:
        train, test = split_by_spec_hash(pairs)
        validation = []
    print(
        f"pairs: {len(train) + len(validation) + len(test)} unique"
        f"  ->  train {len(train)}  validation {len(validation)}  test {len(test)}"
    )
    if len(train) < 100:
        print(f"WARNING: {len(train)} training pairs is thin for a QLoRA (~500+ preferred).")

    if args.dry_run:
        print("dry-run: data prepared and split; not training.")
        return 0
    if len(train) < 20:
        raise SystemExit("too few pairs to train meaningfully — grow the dataset first")

    # Heavy, GPU-only imports live here so the module imports for tests without them.
    from datasets import Dataset  # noqa: PLC0415
    from trl import SFTConfig, SFTTrainer  # noqa: PLC0415
    from unsloth import FastLanguageModel  # noqa: PLC0415

    model, tok = FastLanguageModel.from_pretrained(
        args.base, load_in_4bit=True, max_seq_length=8192
    )
    model = FastLanguageModel.get_peft_model(
        model, r=16, lora_alpha=32, random_state=SEED,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                        "gate_proj", "up_proj", "down_proj"],
    )
    ds = Dataset.from_list([{"messages": p["messages"]} for p in train])
    eval_ds = (
        Dataset.from_list([{"messages": p["messages"]} for p in validation])
        if validation
        else None
    )
    SFTTrainer(
        model=model, tokenizer=tok, train_dataset=ds,
        eval_dataset=eval_ds,
        args=SFTConfig(
            output_dir=str(args.out), num_train_epochs=args.epochs,
            per_device_train_batch_size=1, gradient_accumulation_steps=8,
            learning_rate=2e-4, seed=SEED, logging_steps=10,
        ),
    ).train()
    args.out.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(str(args.out / "adapter"))
    tok.save_pretrained(str(args.out / "adapter"))
    model.save_pretrained_gguf(
        str(args.out / "gguf"), tok, quantization_method="q4_k_m"
    )

    # The held-out test set is written for Ablation E to score against, never
    # trained on — proof the comparison is on unseen prompts.
    (args.out.parent / "qlora_test_holdout.jsonl").write_text(
        "\n".join(json.dumps(p) for p in test), encoding="utf-8"
    )
    print(f"done -> {args.out / 'gguf'} ; held-out test -> qlora_test_holdout.jsonl")
    print("next: `ollama create promptplay-planner-8b -f Modelfile`, then Ablation E.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
