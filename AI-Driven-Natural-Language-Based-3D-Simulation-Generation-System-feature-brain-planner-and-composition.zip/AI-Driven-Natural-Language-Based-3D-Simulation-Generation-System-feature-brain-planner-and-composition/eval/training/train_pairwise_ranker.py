"""Train a deterministic pairwise linear asset or placement ranker.

Hard licence, collision, reachability, capability and performance constraints
must be applied before this model is called. The ranker only orders candidates
that already passed those deterministic gates.
"""

from __future__ import annotations

import argparse
import json
import math
import random
import sys
from pathlib import Path

SEED = 42


def _flatten(value: dict, prefix: str = "") -> dict[str, float]:
    features: dict[str, float] = {}
    for key, item in sorted(value.items()):
        name = f"{prefix}.{key}" if prefix else str(key)
        if isinstance(item, bool):
            features[name] = 1.0 if item else 0.0
        elif isinstance(item, (int, float)) and math.isfinite(float(item)):
            features[name] = float(item)
        elif isinstance(item, dict):
            features.update(_flatten(item, name))
    return features


def _pairs(record: dict) -> list[tuple[dict[str, float], dict[str, float]]]:
    payload = record.get("features")
    if not isinstance(payload, dict):
        return []
    chosen = payload.get("chosen") or payload.get("selected") or payload.get("accepted")
    rejected = payload.get("rejected_candidates") or payload.get("rejected")
    if isinstance(rejected, dict):
        rejected = [rejected]
    if isinstance(chosen, dict) and isinstance(rejected, list):
        return [
            (_flatten(chosen), _flatten(candidate))
            for candidate in rejected
            if isinstance(candidate, dict)
        ]
    left, right = payload.get("candidate_a"), payload.get("candidate_b")
    preferred = str(payload.get("preferred") or "").lower()
    if isinstance(left, dict) and isinstance(right, dict) and preferred in {"a", "b"}:
        return [(_flatten(left), _flatten(right))] if preferred == "a" else [
            (_flatten(right), _flatten(left))
        ]
    return []


def _load(paths: list[Path]) -> list[tuple[dict[str, float], dict[str, float]]]:
    result = []
    for path in paths:
        if not path.is_file():
            continue
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                result.extend(_pairs(json.loads(line)))
    return result


def _difference(
    chosen: dict[str, float], rejected: dict[str, float], names: list[str]
) -> list[float]:
    return [chosen.get(name, 0.0) - rejected.get(name, 0.0) for name in names]


def _accuracy(
    rows: list[tuple[dict[str, float], dict[str, float]]],
    names: list[str],
    weights: list[float],
) -> float | None:
    if not rows:
        return None
    correct = 0
    for chosen, rejected in rows:
        vector = _difference(chosen, rejected, names)
        correct += sum(w * x for w, x in zip(weights, vector, strict=True)) > 0
    return correct / len(rows)


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--data", type=Path, nargs="+", required=True)
    parser.add_argument("--validation-data", type=Path, nargs="*", default=[])
    parser.add_argument("--test-data", type=Path, nargs="*", default=[])
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument(
        "--target", choices=["asset_ranker", "placement_ranker"], required=True
    )
    args = parser.parse_args(argv)
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    if manifest.get("target") != args.target or not manifest.get("manifest_hash"):
        raise SystemExit("governed manifest target or hash is invalid")
    train = _load(args.data)
    validation = _load(args.validation_data)
    test = _load(args.test_data)
    if not train:
        raise SystemExit("no valid chosen/rejected preference pairs in training split")
    names = sorted(
        {
            name
            for pair in train
            for candidate in pair
            for name in candidate
        }
    )
    if not names:
        raise SystemExit("preference pairs contain no numeric or boolean features")
    weights = [0.0] * len(names)
    rows = list(train)
    rng = random.Random(SEED)
    for epoch in range(100):
        rng.shuffle(rows)
        learning_rate = 0.05 / (1.0 + epoch * 0.02)
        for chosen, rejected in rows:
            vector = _difference(chosen, rejected, names)
            margin = sum(w * x for w, x in zip(weights, vector, strict=True))
            gradient = 1.0 / (1.0 + math.exp(min(40.0, max(-40.0, margin))))
            for index, value in enumerate(vector):
                weights[index] += learning_rate * gradient * value
    metrics = {
        "train_pairwise_accuracy": _accuracy(train, names, weights),
        "validation_pairwise_accuracy": _accuracy(validation, names, weights),
        "test_pairwise_accuracy": _accuracy(test, names, weights),
        "train_pairs": len(train),
        "validation_pairs": len(validation),
        "test_pairs": len(test),
    }
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "ranker.json").write_text(
        json.dumps(
            {
                "format": "serendib_pairwise_linear_v1",
                "target": args.target,
                "seed": SEED,
                "dataset_manifest_hash": manifest["manifest_hash"],
                "feature_names": names,
                "weights": weights,
                "metrics": metrics,
                "hard_constraints_must_be_pre_filtered": True,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(json.dumps(metrics, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
