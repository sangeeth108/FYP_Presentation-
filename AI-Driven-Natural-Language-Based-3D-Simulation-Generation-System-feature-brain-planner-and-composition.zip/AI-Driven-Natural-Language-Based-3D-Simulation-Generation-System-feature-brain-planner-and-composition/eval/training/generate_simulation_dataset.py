"""Build fine-tune pairs for the SIMULATION planner.

`generate_dataset.py` beside this file targets the game_spec path -- `author_spec`,
`run_pcg`, the game_spec schema. The simulation planner writes a different document
entirely, so training on those pairs would teach the student the wrong format. That is
the same gap `export_distillation.py` had, and it is why months of runs produced no
usable training data for the planner that is actually shipping.

WHAT A PAIR IS. prompt -> SimulationSpec, kept only when the deterministic gates pass:
schema, behaviour compilation, placement, world-plan validation, requirement
traceability and the deterministic critic. Godot is not involved -- the training target
is the planner's document, not a built world, so export and the playtest bot are out of
scope and the run costs minutes per prompt rather than twenty.

The label is the pipeline's own verdict, which is what makes it free and honest: a spec
that failed its gates is a counter-example, not a lesson.

GOVERNANCE. Every row is written with `data_source: "synthetic_eval"`. The specs sitting
in the production database are all `production_user` and all `training_eligible=False`,
which is the DPIA control working as designed -- training on them is a consent decision
belonging to the ethics process, not a flag to flip. Prompts here come from a seeded
file, so nothing a real person typed reaches a training set.

Usage (from the repo root):
    python eval/training/generate_simulation_dataset.py --limit 5      # smoke test
    python eval/training/generate_simulation_dataset.py                # the lot
    python eval/training/generate_simulation_dataset.py --out x.jsonl
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "services" / "brain"))
sys.path.insert(0, str(REPO / "services" / "worker"))
sys.path.insert(0, str(REPO / "eval"))

from core.config import get_settings  # noqa: E402
from run_simulation_benchmark import _measure_one  # noqa: E402

PROMPTS = REPO / "eval" / "training" / "simulation_train_prompts.json"
DEFAULT_OUT = REPO / "eval" / "reports" / "simulation_distill.jsonl"

# The instruction the student is trained against. Kept minimal and identical for every
# row: the spec is the lesson, and varying the framing per row would teach the model
# that the framing matters.
SYSTEM_PROMPT = (
    "Create a neutral executable 3D SimulationSpec for the described place. "
    "Return only JSON matching the SimulationSpec contract."
)


def _already_done(out: Path) -> set[str]:
    """Prompts already in the file, so an interrupted run resumes rather than repeats."""
    if not out.is_file():
        return set()
    done: set[str] = set()
    for line in out.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            done.add(json.loads(line)["prompt"])
        except (ValueError, KeyError):
            continue
    return done


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--limit", type=int, help="stop after this many prompts")
    parser.add_argument(
        "--keep-failures",
        action="store_true",
        help="also write specs that failed their gates (analysis, NOT training)",
    )
    args = parser.parse_args(argv)

    if not PROMPTS.is_file():
        print(f"no prompt file at {PROMPTS}", file=sys.stderr)
        return 2
    entries = json.loads(PROMPTS.read_text(encoding="utf-8"))["prompts"]
    if args.limit:
        entries = entries[: args.limit]

    settings = get_settings()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    done = _already_done(args.out)
    kept = seen = 0
    started = time.perf_counter()

    # Appended and flushed per pair, so a long run that is interrupted keeps everything
    # it produced and resumes past it.
    with args.out.open("a", encoding="utf-8") as handle:
        for entry in entries:
            if entry["prompt"] in done:
                continue
            seen += 1
            result = _measure_one(entry, use_llm=True, settings=settings)
            passed = bool(result.get("passed"))
            spec = result.pop("spec", None)
            if spec is None:
                # `_measure_one` reports rather than returns the spec; re-planning to
                # get it would double the cost, so the row carries what it measured.
                spec = result.get("spec_body")
            if not passed and not args.keep_failures:
                print(f"  drop  {entry['id']}: {len(result.get('errors') or [])} gate errors")
                continue
            handle.write(
                json.dumps(
                    {
                        "prompt": entry["prompt"],
                        "system": SYSTEM_PROMPT,
                        "spec": spec,
                        "verdict": "PASS" if passed else "FAIL",
                        "errors": result.get("errors"),
                        "planner_model": result.get("planner"),
                        # Never production user data: these prompts are seeded, and the
                        # DPIA control on the live database is a consent decision rather
                        # than a flag to work around.
                        "data_source": "synthetic_eval",
                        "path": "simulation",
                    },
                    ensure_ascii=False,
                )
                + "\n"
            )
            handle.flush()
            kept += 1
            print(f"  keep  {entry['id']}  ({kept} kept / {seen} tried)")

    elapsed = time.perf_counter() - started
    print(f"\n{kept} pairs kept of {seen} tried in {elapsed / 60:.1f} min -> {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
