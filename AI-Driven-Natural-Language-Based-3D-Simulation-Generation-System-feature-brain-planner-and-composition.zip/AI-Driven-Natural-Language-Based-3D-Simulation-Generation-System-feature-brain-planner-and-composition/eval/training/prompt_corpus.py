"""Training-prompt corpus for the distillation fine-tune (P4, RQ4).

Combinatorial and SEEDED, so a large, varied, reproducible set of natural-ish
prompts comes from a small amount of code — spanning all four genres, character
identities (for player_identity), and collection goals (for collect_n), which is
the design space the student model must learn to map.

CRITICAL — no train/test contamination: this corpus is held DISJOINT from the
evaluation sets (v1_frozen, v2_ambiguous). Training the 8B on an eval prompt
would invalidate Ablation E. `disjoint_corpus()` enforces it and a test asserts
it; if a generated prompt ever collides with an eval prompt, it is dropped.
"""

from __future__ import annotations

import json
import random
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
EVAL_SETS = (
    REPO / "eval" / "benchmark_prompts" / "v1_frozen.json",
    REPO / "eval" / "benchmark_prompts" / "v2_ambiguous.json",
)

# Genre-shaped templates. Each is a natural sentence with slots; the mix across
# genres is deliberate so the student sees the whole design space, and the
# collection/character templates exercise collect_n and player_identity.
_TEMPLATES = [
    # survival / escape
    "escape the {adj} {place} before the {threat} overrun it",
    "flee the {adj} {place} as the {threat} close every exit",
    "survive the {adj} {place} and reach the {exit}",
    # arena / combat
    "battle waves of {foe} in the {adj} {arena}",
    "duel the champions of the {adj} {arena}",
    "as a {hero}, fight through the {adj} {arena}",
    # collect / explore
    "gather the {n} {loot} scattered across the {adj} {place}",
    "explore the {adj} {place} and collect its {loot}",
    "as a {critter}, roam the {adj} {place} and sniff out {loot}",
    # dungeon crawl
    "descend the {adj} {dungeon}, room by room",
    "delve the {adj} {dungeon} and face what stirs below",
    "as a {hero}, crawl the {adj} {dungeon}",
]

_SLOTS = {
    "adj": ["foggy", "ruined", "sunlit", "frozen", "haunted", "overgrown", "shadowed",
            "gilded", "flooded", "crumbling", "moonlit", "ashen", "verdant", "storm-wracked"],
    "place": ["village", "harbor town", "monastery", "outpost", "market square", "orchard",
              "railyard", "lighthouse coast", "hill fort", "riverside camp", "clocktower district"],
    "threat": ["risen dead", "raiders", "swarm", "wolves", "cultists", "spider-kin", "the blight"],
    "exit": ["last airship", "mountain pass", "signal tower", "harbor gate", "old bridge"],
    "foe": ["gladiators", "iron golems", "berserkers", "revenants", "mercenaries", "hound-riders"],
    "arena": ["colosseum", "sand pit", "fortress ring", "sky arena", "frozen amphitheatre"],
    "hero": ["knight", "monk", "ranger", "sellsword", "witch-hunter", "clockwork automaton"],
    "n": ["three", "four", "five", "six", "seven"],
    "loot": ["cursed relics", "star-shards", "lost journals", "rune stones", "seed pods",
             "brass keys", "amber beetles", "sunken coins"],
    "critter": ["scruffy dog", "curious fox", "tin robot", "one-eyed cat", "hungry raccoon"],
    "dungeon": ["catacombs", "sunken crypt", "goblin warren", "mine shafts", "temple vaults"],
}


def _fill(template: str, rng: random.Random) -> str:
    out = template
    for slot in _SLOTS:
        while "{" + slot + "}" in out:
            out = out.replace("{" + slot + "}", rng.choice(_SLOTS[slot]), 1)
    return out


def _eval_prompts() -> set[str]:
    seen: set[str] = set()
    for path in EVAL_SETS:
        if path.is_file():
            seen |= {p["prompt"].strip().lower() for p in json.loads(path.read_text())["prompts"]}
    return seen


def disjoint_corpus(n: int = 150, seed: int = 20260718) -> list[dict]:
    """`n` unique training prompts, deterministic in `seed`, DISJOINT from eval.

    Returns [{id, seed, prompt}], ids stable for a given (n, seed) so a training
    run is reproducible and re-freezable.
    """
    rng = random.Random(seed)
    banned = _eval_prompts()
    seen: set[str] = set()
    out: list[dict] = []
    attempts = 0
    while len(out) < n and attempts < n * 50:
        attempts += 1
        prompt = _fill(rng.choice(_TEMPLATES), rng)
        key = prompt.strip().lower()
        if key in banned or key in seen:
            continue  # never a duplicate, never an eval prompt
        seen.add(key)
        out.append({"id": f"train_{len(out):04d}", "seed": 30000 + len(out), "prompt": prompt})
    return out


def main() -> int:
    corpus = disjoint_corpus()
    out = REPO / "eval" / "training" / "train_corpus.json"
    out.write_text(
        json.dumps(
            {"version": "train-1", "seed": 20260718, "count": len(corpus), "prompts": corpus},
            indent=2,
        ),
        encoding="utf-8",
        newline="\n",
    )
    print(f"wrote {len(corpus)} training prompts -> {out}")
    print("sample:")
    for p in corpus[:6]:
        print(f"  {p['prompt']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
