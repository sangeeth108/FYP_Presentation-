"""Generate the distillation dataset by running the training corpus (P4, RQ4).

    prompt -> game_spec, keeping only what the validator PASSED and the LLM planned.

Distinct from `eval/export_distillation.py`, which reads specs the full worker
pipeline already stored in Postgres. This runs the multi-agent chain + static
validation DIRECTLY (no Godot export, no DB), because the training target is the
planner's spec, not a built game — which makes it ~3x faster per prompt (no
3-minute export) and independent of the DB. Same JSONL output shape, so the two
sources merge into one training file.

The label is the pipeline's own verdict: keep a pair only when static gates PASS
(1 schema, 2 constraints, 3 asset QA, 5 static playability) AND the brief was
LLM-planned. A rules-mode fallback is not the teacher and must never be trained
on (it would teach the 8B to imitate a regex).

Writes JSONL INCREMENTALLY (one pair per line, flushed), so a ~4-hour run that
is interrupted keeps everything produced so far, and re-running resumes past what
is already in the file.

    python eval/training/generate_dataset.py                 # full corpus, 1 seed
    python eval/training/generate_dataset.py --seeds 2 --limit 40
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "eval"))
sys.path.insert(0, str(REPO / "eval" / "training"))
sys.path.insert(0, str(REPO / "services" / "brain"))
sys.path.insert(0, str(REPO / "services" / "worker"))

import jsonschema  # noqa: E402
from agents.chain import AgentContext, author_spec  # noqa: E402
from export_distillation import SYSTEM_PROMPT  # noqa: E402 — same training format
from pcg.pipeline import run_pcg  # noqa: E402
from pcg.serialize import to_level_plan  # noqa: E402
from prompt_corpus import _eval_prompts, disjoint_corpus  # noqa: E402
from run_benchmark import BASE_SPEC, SCHEMA  # noqa: E402
from validators.gates import run_gates  # noqa: E402

OUT = REPO / "eval" / "reports" / "distill_generated.jsonl"


def _context(prompt: str, seed: int) -> AgentContext:
    from core.config import get_settings

    s = get_settings()
    return AgentContext(
        prompt=prompt, seed=seed, llm_enabled=True,
        llm_base_url=s.llm_base_url, llm_model=s.llm_model,
        llm_timeout_seconds=s.llm_timeout_seconds, rag_enabled=True,
    )


def _already_done(out: Path) -> set[str]:
    """spec_hashes already in the file, so a re-run resumes rather than duplicates."""
    if not out.is_file():
        return set()
    done = set()
    for line in out.read_text(encoding="utf-8").splitlines():
        try:
            done.add(json.loads(line)["meta"]["spec_hash"])
        except Exception:
            continue
    return done


def _one(prompt: str, seed: int) -> tuple[dict | None, str]:
    """Return (training pair, status). status is why it was kept or dropped."""
    import hashlib

    chain = author_spec(BASE_SPEC, _context(prompt, seed), "g3d_train_00000000", prompt)
    if chain.brief_source != "llm":
        return None, "fallback"  # planner was down; not a teacher example
    spec = chain.spec
    try:
        jsonschema.validate(spec, SCHEMA)
    except jsonschema.ValidationError:
        return None, "schema"
    report = run_gates(spec, to_level_plan(run_pcg(spec)), schema=SCHEMA, build_result=None)
    if report["verdict"] != "PASS":
        return None, "gate:" + (report["errors"][0]["code"] if report["errors"] else "?")
    body = json.dumps(spec, separators=(",", ":"))
    spec_hash = hashlib.sha256(body.encode()).hexdigest()[:16]
    pair = {
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": body},
        ],
        "meta": {"spec_hash": spec_hash, "verdict": "PASS", "brief_source": "llm",
                 "source": "generated", "seed": seed},
    }
    return pair, "PASS"


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--seeds", type=int, default=1, help="replicates per prompt (variety)")
    ap.add_argument("--limit", type=int, default=0, help="cap prompts (0 = whole corpus)")
    ap.add_argument("--out", type=Path, default=OUT)
    args = ap.parse_args(argv)

    corpus = disjoint_corpus()
    if args.limit:
        corpus = corpus[: args.limit]
    # Contamination guard, enforced not just documented: refuse to proceed if any
    # training prompt is an eval prompt.
    banned = _eval_prompts()
    if any(c["prompt"].strip().lower() in banned for c in corpus):
        raise SystemExit("ABORT: a training prompt collides with an eval prompt (contamination)")

    # Warm the 27B into VRAM before the run: a cold load on the first call
    # exceeds the timeout and wastes a prompt on a rules fallback (seen repeatedly).
    import contextlib

    from agents.llm_planner import llm_brief

    with contextlib.suppress(Exception):
        llm_brief("warmup: a small test dungeon", None, None, _context("warmup", 0))
        print("(planner warmed)", flush=True)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    done = _already_done(args.out)
    if done:
        print(f"resuming: {len(done)} pairs already in {args.out.name}")

    kept = len(done)
    dropped: dict[str, int] = {}
    started = time.perf_counter()
    with args.out.open("a", encoding="utf-8", newline="\n") as fh:
        for rep in range(args.seeds):
            for c in corpus:
                seed = c["seed"] + rep * 100_000  # distinct design per replicate (seed varies it)
                pair, status = _one(c["prompt"], seed)
                if pair and pair["meta"]["spec_hash"] not in done:
                    fh.write(json.dumps(pair, ensure_ascii=False) + "\n")
                    fh.flush()
                    done.add(pair["meta"]["spec_hash"])
                    kept += 1
                    print(".", end="", flush=True)
                elif pair:
                    print("=", end="", flush=True)  # duplicate spec, skipped
                else:
                    dropped[status] = dropped.get(status, 0) + 1
                    print("x", end="", flush=True)
        print()

    mins = (time.perf_counter() - started) / 60
    print(f"\nkept {kept} PASS pairs in {args.out} ({mins:.1f} min)")
    if dropped:
        print(f"dropped: {dropped}")
    if kept < 500:
        print(f"NOTE: {kept} pairs — a QLoRA SFT wants ~500-2000.")
        print("      Add --seeds or re-run (it resumes) to grow the set.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
