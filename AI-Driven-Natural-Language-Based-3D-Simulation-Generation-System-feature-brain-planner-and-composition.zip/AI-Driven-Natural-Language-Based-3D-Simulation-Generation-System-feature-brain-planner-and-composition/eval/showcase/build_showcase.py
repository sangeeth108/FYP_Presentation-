"""Build the defense showcase (P4/P6 gate: 5 cached games + 1 live, with a script).

Runs the curated prompts through the REAL product pipeline — the same
`POST /api/v1/games` a user hits — so every showcase game is an honest product
output with a web build, a downloadable project, a validation verdict, a
playtest-bot result, and full lineage. A showcase should be SELECTED from real
runs, not hand-picked hopes.

    python eval/showcase/build_showcase.py --generate     # run candidates, keep artifacts
    python eval/showcase/build_showcase.py --select       # pick the demo 5 from the manifest
    python eval/showcase/build_showcase.py --live         # rehearse the live generation
    python eval/showcase/build_showcase.py --demo-script  # write the defense runbook

Needs GODOT_BIN (real export), a reachable Postgres, and the LLM. Artifacts land
under ARTIFACTS_DIR/<game_id>/ (gitignored, regenerable); the manifest and demo
script are written beside them. Running --generate also fills the `specs` table —
free distillation data (docs/runbooks/FINE_TUNING.md).

Selection rule: a demo game must pass EVERY runnable gate and be WON by the bot,
and the five are chosen for genre spread — a defense should show range, not five
dungeons. If fewer than five qualify, that is reported honestly, not padded.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
PROMPTS = REPO / "eval" / "showcase" / "showcase_prompts.json"
DEFAULT_ARTIFACTS = REPO / "artifacts"


def _client():
    """A TestClient bound to the real pipeline in eager mode: POST returns after
    the whole build (LLM -> PCG -> export -> bot), so this is synchronous."""
    os.environ.setdefault("CELERY_TASK_ALWAYS_EAGER", "true")
    os.environ.setdefault(
        "DATABASE_URL", "postgresql+psycopg://promptplay:change-me@localhost:5433/promptplay"
    )
    sys.path.insert(0, str(REPO / "services" / "brain"))
    sys.path.insert(0, str(REPO / "services" / "worker"))
    from fastapi.testclient import TestClient
    from main import app

    return TestClient(app)


def _manifest_path() -> Path:
    return Path(os.environ.get("ARTIFACTS_DIR", DEFAULT_ARTIFACTS)) / "showcase_manifest.json"


def _row_from_job(cand: dict, created: dict, job: dict) -> dict:
    d = job.get("detail", {})
    gates = {g["gate"]: g["verdict"] for g in d.get("validation", {}).get("gates", [])}
    return {
        "id": cand["id"],
        "prompt": cand["prompt"],
        "seed": cand["seed"],
        "game_id": created["game_id"],
        "state": job["state"],
        "genre": d.get("genre"),
        "verdict": d.get("validation", {}).get("verdict"),
        "gates": {str(k): v for k, v in gates.items()},
        "bot_verdict": d.get("bot_verdict"),
        "won": (d.get("bot_verdict") or "").startswith("GREEDYBOT_OK"),
        "build_mb": d.get("build_mb"),
        "play_path": d.get("play_path"),
        "download_path": d.get("download_path"),
        "spec_hash": d.get("spec_hash"),
        "asset_tiers": d.get("asset_tiers"),
    }


def generate(only: list[str] | None) -> list[dict]:
    data = json.loads(PROMPTS.read_text(encoding="utf-8"))
    cands = [c for c in data["candidates"] if not only or c["id"] in only]
    rows: list[dict] = []
    with _client() as client:
        for cand in cands:
            print(f"--- {cand['id']}: {cand['prompt'][:56]} ---", flush=True)
            t = time.perf_counter()
            created = client.post(
                "/api/v1/games", json={"prompt": cand["prompt"], "seed": cand["seed"]}
            ).json()
            job = client.get(f"/api/v1/jobs/{created['job_id']}").json()
            row = _row_from_job(cand, created, job)
            row["build_seconds"] = round(time.perf_counter() - t, 1)
            rows.append(row)
            flag = "OK " if row["won"] else ("built" if row["verdict"] == "PASS" else "FAIL")
            print(
                f"  {flag} {row['state']} genre={row['genre']} verdict={row['verdict']} "
                f"bot={row['bot_verdict']} {row['build_mb']}MB {row['build_seconds']}s",
                flush=True,
            )
    mp = _manifest_path()
    mp.parent.mkdir(parents=True, exist_ok=True)
    mp.write_text(json.dumps({"candidates": rows}, indent=2), encoding="utf-8", newline="\n")
    print(f"\nwrote {mp}")
    return rows


def select(rows: list[dict], want: int = 5) -> list[dict]:
    """The demo set: only games that PASS and are WON, chosen for genre spread."""
    eligible = [r for r in rows if r["verdict"] == "PASS" and r["won"]]
    chosen: list[dict] = []
    seen_genres: set[str] = set()
    # first pass: one per genre, for range
    for r in eligible:
        if r["genre"] not in seen_genres:
            chosen.append(r)
            seen_genres.add(r["genre"])
    # fill remaining slots with the rest
    for r in eligible:
        if len(chosen) >= want:
            break
        if r not in chosen:
            chosen.append(r)
    return chosen[:want]


def demo_script(chosen: list[dict], live: dict) -> str:
    lines = [
        "# Defense demo script (generated by build_showcase.py)",
        "",
        "**Backup plan:** every cached game below is a pre-built, gate-passed, "
        "bot-won artifact under `artifacts/<game_id>/`. If the live generation "
        "fails on the day, open the cached `live_meadow` build instead — same "
        "product path, already proven.",
        "",
        "## Cached showcase (open each `play_path` in a browser)",
        "",
        "| # | game | genre | won | size | play |",
        "|---|---|---|---|---|---|",
    ]
    for i, r in enumerate(chosen, 1):
        lines.append(
            f"| {i} | {r['id']} — *{r['prompt'][:40]}* | {r['genre']} | "
            f"{'✅' if r['won'] else '—'} | {r['build_mb']}MB | `{r['play_path']}` |"
        )
    lines += [
        "",
        "## Live generation (rehearsed)",
        "",
        f"Type live: **\"{live['prompt']}\"** (seed {live['seed']}).",
        f"Rehearsed build time: ~{live.get('build_seconds', '?')}s. If it stalls, "
        "cut to the cached copy (same game_id, already built).",
        "",
        "Every game carries full lineage (prompt, seed, spec_hash, gates, bot verdict) "
        "in the manifest — reproducible from the seed alone.",
    ]
    return "\n".join(lines) + "\n"


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--generate", action="store_true", help="run candidates through the pipeline")
    ap.add_argument("--select", action="store_true", help="pick the demo 5 from the manifest")
    ap.add_argument("--live", action="store_true", help="rehearse the live generation")
    ap.add_argument("--demo-script", action="store_true", help="write the defense runbook")
    ap.add_argument("--only", default="", help="comma-separated candidate ids (with --generate)")
    args = ap.parse_args(argv)

    if not any((args.generate, args.select, args.live, args.demo_script)):
        ap.error("choose at least one of --generate/--select/--live/--demo-script")

    # The manifest carries BOTH the candidate runs and the live rehearsal, so the
    # demo script can be regenerated with the real live timing without re-running.
    manifest = (
        json.loads(_manifest_path().read_text(encoding="utf-8"))
        if _manifest_path().is_file()
        else {}
    )
    rows: list[dict] = manifest.get("candidates", [])
    if args.generate:
        rows = generate([c.strip() for c in args.only.split(",") if c.strip()] or None)
        manifest = json.loads(_manifest_path().read_text(encoding="utf-8"))

    live_row = manifest.get("live", {})
    if args.live:
        data = json.loads(PROMPTS.read_text(encoding="utf-8"))
        live = data["live_demo"]
        print(f"--- LIVE: {live['prompt']} ---", flush=True)
        t = time.perf_counter()
        with _client() as client:
            created = client.post(
                "/api/v1/games", json={"prompt": live["prompt"], "seed": live["seed"]}
            ).json()
            job = client.get(f"/api/v1/jobs/{created['job_id']}").json()
        live_row = _row_from_job(live, created, job)
        live_row["build_seconds"] = round(time.perf_counter() - t, 1)
        print(f"  live build: {live_row['state']} in {live_row['build_seconds']}s "
              f"(won={live_row['won']}) — this is the fallback if the day's run fails")
        # Persist it alongside the candidates so --demo-script reads the real time.
        manifest["live"] = live_row
        _manifest_path().write_text(json.dumps(manifest, indent=2), encoding="utf-8", newline="\n")

    if args.select or args.demo_script:
        if not rows:
            print("no manifest yet — run --generate first", file=sys.stderr)
            return 2
        chosen = select(rows)
        print(f"\n=== showcase set: {len(chosen)}/5 (PASS + bot-won, genre-spread) ===")
        for r in chosen:
            print(f"  {r['id']:16s} {r['genre']:26s} {r['build_mb']}MB  {r['play_path']}")
        if len(chosen) < 5:
            print(f"  NOTE: only {len(chosen)} qualified — reported honestly, not padded.")
        if args.demo_script:
            out = Path(os.environ.get("ARTIFACTS_DIR", DEFAULT_ARTIFACTS)) / "DEMO_SCRIPT.md"
            live = live_row or json.loads(PROMPTS.read_text(encoding="utf-8"))["live_demo"]
            if not live.get("build_seconds"):
                print("  NOTE: no live rehearsal recorded yet — run --live for a real time.")
            out.write_text(demo_script(chosen, live), encoding="utf-8", newline="\n")
            print(f"\nwrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
