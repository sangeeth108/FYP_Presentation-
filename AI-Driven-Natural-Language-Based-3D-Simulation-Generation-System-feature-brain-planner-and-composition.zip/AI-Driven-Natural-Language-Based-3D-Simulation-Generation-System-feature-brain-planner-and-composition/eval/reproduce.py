"""Reproducibility package for the dissertation's ablation evidence.

The problem this solves: the raw ablation runs live under eval/reports/**, which
is gitignored (regenerable scratch, and 140-528 KB each because every row
carries a full level-plan). So the specific numbers the thesis cites are not
version-controlled — they would be lost, and a reader could not check them.

    python eval/reproduce.py --freeze    # distil the raw runs -> tracked evidence
    python eval/reproduce.py             # VERIFY the cited stats regenerate + provenance

--freeze reads the raw runs and writes SLIM, tracked evidence to
docs/dissertation/results/: per-prompt metric rows (no 4.7 KB level-plan bulk),
the comparison stats, and a PROVENANCE record (git SHA, planner model, seeds).

--verify (the default, and what a reviewer runs) recomputes every reported
p-value and effect size FROM the frozen slim rows and asserts they match the
frozen comparison JSON — proving the numbers were not fudged and regenerate
deterministically. It also re-runs the rules-mode control live (instant, no GPU)
to confirm the spine still passes 100%, and prints the exact commands + seeds to
reproduce the expensive LLM arms.

A reproducibility package that needs 5 GPU-hours to run is not one; this verifies
the cheap deterministic core instantly and DOCUMENTS the expensive part exactly.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
RAW = REPO / "eval" / "reports"
EVIDENCE = REPO / "docs" / "dissertation" / "results"
sys.path.insert(0, str(REPO / "eval"))

# The runs the thesis cites: raw ablation file -> its comparison file (if any).
CITED = [
    ("ablation_RBCD_seed1.json", "comparison_RBCD_seed1.json", "R"),
    ("ablation_RC_content.json", None, "R"),
    ("ablation_v2_RC.json", "comparison_v2_RC.json", "R"),
]

# Fields kept per row: the metrics, not the 4.7 KB level-plan bulk.
SLIM_FIELDS = (
    "prompt_id", "replicate", "seed", "prompt", "genre", "expect_genre",
    "genre_match", "schema_valid", "verdict", "bot_verdict", "latency_ms",
    "objective_kind", "player_identity", "brief_source",
)


def _slim(raw: dict) -> dict:
    out = {"conditions": {}}
    for cid, payload in raw["conditions"].items():
        out["conditions"][cid] = {
            "summary": payload["summary"],
            "rows": [{k: r.get(k) for k in SLIM_FIELDS} for r in payload["rows"]],
        }
    return out


def _git_sha() -> str:
    try:
        return subprocess.check_output(
            ["git", "-C", str(REPO), "rev-parse", "--short", "HEAD"], text=True
        ).strip()
    except Exception:
        return "unknown"


def freeze() -> int:
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    frozen = []
    for raw_name, cmp_name, _base in CITED:
        raw_path = RAW / raw_name
        if not raw_path.is_file():
            print(f"  skip {raw_name} (not present)", file=sys.stderr)
            continue
        slim = _slim(json.loads(raw_path.read_text(encoding="utf-8")))
        (EVIDENCE / raw_name).write_text(
            json.dumps(slim, indent=2), encoding="utf-8", newline="\n"
        )
        frozen.append(raw_name)
        if cmp_name and (RAW / cmp_name).is_file():
            (EVIDENCE / cmp_name).write_text(
                (RAW / cmp_name).read_text(encoding="utf-8"), encoding="utf-8", newline="\n"
            )
            frozen.append(cmp_name)
    prov = {
        "frozen_at": datetime.now(UTC).isoformat(),
        "git_sha": _git_sha(),
        "planner_model": "qwen3.6:27b (local Ollama)",
        "seeds": "fixed per prompt set; see each run's summary.seeds",
        "files": frozen,
        "note": "Slim metric rows (level-plan bulk removed). Re-verify with "
                "`python eval/reproduce.py`.",
    }
    (EVIDENCE / "PROVENANCE.json").write_text(
        json.dumps(prov, indent=2), encoding="utf-8", newline="\n"
    )
    print(f"froze {len(frozen)} evidence files -> {EVIDENCE}")
    return 0


def _recompute_and_check(slim_path: Path, cmp_path: Path, baseline: str) -> list[str]:
    """Recompute the comparison from the SLIM rows; return mismatches vs the
    frozen comparison JSON."""
    from ablation_runners.compare import compare

    arms = json.loads(slim_path.read_text(encoding="utf-8"))["conditions"]
    reported = json.loads(cmp_path.read_text(encoding="utf-8"))
    recomputed = compare(arms, baseline)

    problems: list[str] = []
    for cond_id, block in reported["comparisons"].items():
        for metric, m in block["metrics"].items():
            got = recomputed["comparisons"][cond_id]["metrics"][metric]
            for field in ("p_value", "cliffs_delta"):
                if abs(got[field] - m[field]) > 1e-6:
                    problems.append(
                        f"{cond_id}:{metric}:{field} frozen={m[field]} recomputed={got[field]}"
                    )
            if got["holm"]["significant"] != m["holm"]["significant"]:
                problems.append(f"{cond_id}:{metric} significance flipped")
    return problems


def verify() -> int:
    if not EVIDENCE.is_dir():
        print("no frozen evidence — run `python eval/reproduce.py --freeze` first",
              file=sys.stderr)
        return 2

    ok = True
    print("=== 1. cited statistics regenerate from the frozen rows ===")
    for raw_name, cmp_name, base in CITED:
        if not cmp_name:
            continue
        slim, cmp = EVIDENCE / raw_name, EVIDENCE / cmp_name
        if not (slim.is_file() and cmp.is_file()):
            print(f"  SKIP {cmp_name} (not frozen)")
            continue
        problems = _recompute_and_check(slim, cmp, base)
        if problems:
            ok = False
            print(f"  FAIL {cmp_name}:")
            for p in problems:
                print(f"       {p}")
        else:
            print(f"  OK   {cmp_name}: every p-value and effect size reproduces exactly")

    print("\n=== 2. the deterministic control still holds (live, no GPU) ===")
    try:
        from ablation_runners.run_ablation import run_condition

        s = run_condition("R", seeds=1, full=False)["summary"]
        spine_ok = s["pass_rate"] == 1.0 and s["llm_planned"] == 0
        ok &= spine_ok
        print(f"  {'OK  ' if spine_ok else 'FAIL'} rules-mode R: {s['passed']}/{s['runs']} pass, "
              f"0 LLM — the spine passes unaided (the thesis's first claim)")
    except Exception as exc:  # noqa: BLE001
        print(f"  SKIP live control ({type(exc).__name__}: {exc})")

    print("\n=== 3. to reproduce the expensive LLM arms (needs the GPU) ===")
    print("  LLM_ENABLED=true LLM_MODEL=qwen3.6:27b \\")
    print("    python eval/ablation_runners/run_ablation.py --conditions R,B,C,D --seeds 1")
    print("    python eval/ablation_runners/run_ablation.py --conditions R,C --prompts \\")
    print("      eval/benchmark_prompts/v2_ambiguous.json --seeds 1")
    print("  then: python eval/ablation_runners/compare.py <the ablation json> --baseline R")

    print("\n" + ("REPRODUCIBILITY: PASS" if ok else "REPRODUCIBILITY: FAIL"))
    return 0 if ok else 1


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--freeze", action="store_true", help="distil raw runs -> tracked evidence")
    args = ap.parse_args(argv)
    return freeze() if args.freeze else verify()


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
