# contracts/ — the single source of truth

**What this is:** the canonical `game_spec.schema.json` (JSON Schema 2020-12) that every part of the system agrees on. Agents emit patches against it, guided decoding enforces it token-by-token, validators check it, the project writer consumes it, and the Serendib Assist dock edits it.

**What belongs here:** `game_spec.schema.json` (and future sub-schemas: brief, patches), `examples/` with valid + deliberately-invalid fixture specs.

**Owner:** M2 (Brain/ML) — but changes require **two-person review and a design signoff**, because everything depends on this file.

**When updated:** schema is DRAFT until the P0 gate, then **frozen as v2.0.0**. After freezing, changes bump `schema_version` and the validator must support N-1.

**Version history:**

| Version | Date | Change |
|---|---|---|
| 2.0.0 | 2026-07-09 | Frozen at the P0 gate (golden game passed). |
| 2.1.0 | 2026-07-17 | Adds optional `player.asset_brief` — WHO the player is. Additive and backward-compatible: `schema_version` accepts `2.1.0` and `2.0.0` (N-1), and a v2.0.0 spec still validates untouched. **Team-approved 2026-07-17** (the review + sign-off required above and by `docs/SCOPE_FREEZE_MEMO.md` §61); see ADR-0005 for the record. |

**Common mistakes to avoid:**
- Changing the schema after agents are built without versioning — breaks everything silently.
- Adding xgrammar-unfriendly constructs (complex `if/then`, deep `oneOf` chains) — guided decoding falls back and you lose schema-validity-by-construction.
- Putting allowlist checks *in* the schema — template/kit ID existence is a **registry** (constraint gate) concern; the schema checks shape, not catalog membership.
- Letting the LLM write the `lineage` block — the system fills it at S8.

**Validate:** `python scripts/validate_contracts.py` (checks the schema itself compiles + all examples validate).
