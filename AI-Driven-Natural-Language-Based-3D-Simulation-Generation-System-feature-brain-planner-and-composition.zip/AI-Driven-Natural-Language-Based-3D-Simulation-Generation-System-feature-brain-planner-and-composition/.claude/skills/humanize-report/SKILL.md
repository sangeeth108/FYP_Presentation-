---
name: humanize-report
description: Rewrite academic or project-report prose so it reads as clear, natural, professional engineering writing without altering technical meaning. Use when asked to humanize, de-AI, tighten, or improve the readability of report chapters, dissertation sections, or documentation prose. Verifies technical claims against the actual source code and never invents results, measurements, features, citations or references.
---

# Humanizing an academic engineering report

Improve how a report reads. Do not change what it says.

The target voice is an engineering student explaining work that was genuinely
done: precise, plain, confident, specific to this project. Not a brochure, not a
textbook, and not a language model producing paragraphs of even length that all
begin with a connective.

## The one rule that outranks everything else

**Never invent technical content.** Not features, implementation details,
algorithms, source-code behaviour, tests, experimental results, measurements,
accuracy or performance figures, user feedback, datasets, references, citations,
figures or tables.

Rewriting is a language operation. If a rewrite would require a fact that is not
already on the page or verifiable in the repository, the rewrite is wrong — go
back and rephrase what is actually there.

**The implementation is the source of truth.** When a sentence makes a claim
about how the system works, read the code before rewording it. A fluent sentence
describing behaviour the system does not have is worse than the clumsy sentence
it replaced.

When a claim cannot be verified from the available files, leave the wording as
close to the original as possible and mark it:

```
[VERIFY: evidence required]
```

Add the marker; never quietly resolve the uncertainty by guessing. If a claim is
contradicted by the code, say so in the summary rather than silently "fixing" the
prose to match either side.

## Preserve exactly

Carry these through unchanged unless the user asks otherwise:

- numerical values, equations, calculations, units
- citations, reference numbers, `\cite` keys
- figure, table, section, chapter and label references
- technology, software, model, library and product names
- algorithm names and technical terminology
- code identifiers, file paths, command lines
- markup structure: environments, labels, macros, cross-references

Renaming a concept mid-report breaks the reader's index of it. Keep whatever term
the report already established, even where a different word would read better.

## What natural writing means here

Prefer direct constructions:

- "The system uses…"
- "We developed…"
- "During implementation…"
- "This component handles…"
- "This approach was selected because…"
- "The module communicates with…"
- "The results show…"
- "One limitation of this approach is…"

Use "we" only for work the project team actually did. Deterministic machinery
does things on its own — "the sampler places what fits" is better than "we made
the sampler place what fits" when describing runtime behaviour.

Achieve naturalness through **content and rhythm**, not vocabulary inflation:

- vary sentence length; a short sentence after two long ones does more for
  readability than any word choice
- put the subject early and the verb close to it
- prefer the concrete noun to the abstract one ("the ground mesh" over "the
  terrain representation component")
- cut filler that carries no information
- let paragraphs differ in shape and length
- keep transitions logical rather than decorative

Avoid marketing vocabulary — groundbreaking, revolutionary, cutting-edge,
remarkable, highly innovative, state-of-the-art — unless it is technically
justified and defensible.

Avoid needless complexity. "Utilise" is "use". "In order to" is "to".
"Functionality" is usually "features" or nothing at all.

## AI-writing patterns to remove

These are not banned words; they are banned *habits*. Each may appear where it
genuinely fits. None may appear as a reflex paragraph opener:

- "In today's rapidly evolving technological landscape", "In the modern era"
- "It is important to note that", "It is worth mentioning that"
- "Furthermore", "Moreover", "Additionally", "Overall"
- "This innovative solution", "The aforementioned system"
- "This demonstrates the effectiveness of…"

Other tells worth hunting:

- every paragraph the same length and shape
- tricolon everywhere ("robust, scalable, and maintainable")
- a summary sentence restating the paragraph that just ended
- hedging stacked on hedging ("may potentially be able to")
- "delve into", "leverage", "seamless", "robust" used as filler
- signposting that outruns the content ("This section will explore…")

**Never fake humanity.** Do not introduce grammar errors, spelling mistakes,
typos, contractions-for-effect or deliberate informality. Naturalness comes from
clear thinking on the page, not from simulated imperfection.

## Procedure

Work section by section. Do not rewrite a whole document in one pass.

1. **Read the complete section** before editing any of it.
2. **Understand what it is explaining** — the claim, not just the sentences.
3. **Read neighbouring sections** where context is needed, so terminology and
   cross-references stay consistent.
4. **Inspect the code** for any technical claim you are about to reword.
5. **Identify** the repetitive, generic, awkward or AI-patterned writing. If a
   passage is already good, leave it alone and say so.
6. **Rewrite** into clear natural academic English.
7. **Preserve** every piece of technical information, including detail that makes
   a sentence longer.
8. **Remove** repetition and filler.
9. **Check** that nothing unsupported was introduced.
10. **Re-read** the result for flow and accuracy.

Do not summarise a section unless summarisation was requested. Do not reduce
technical detail. Length may fall because filler was cut; it must not fall
because content was dropped.

## Working on a LaTeX report

- Edit only prose. Leave preamble, environments, `\label`, `\ref`, `\cite`,
  `\input` and figure/table bodies alone.
- Text inside `\caption{}` is prose and is usually the highest-value target.
- Never reflow a `lstlisting`, `verbatim`, `tabular` or `tikzpicture` body.
- Keep `\code{}`, `\texttt{}` and `\emph{}` wrappers on the terms that carry
  them.
- Recompile after a batch of edits and confirm the page count, that no
  references broke, and that no new overfull boxes appeared.

## Reporting back

After each batch, state plainly:

- which sections were rewritten, and what the actual problem was in each
- which sections were left alone because they were already well written
- every `[VERIFY: …]` marker added, and what evidence would settle it
- anything the code contradicted
- what remains unprocessed

Do not claim a section reads better without saying what changed about it.
